import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408690490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408690490 : Closed e2422408690490 ∧ code e2422408690490 = 11218501712698 := by decide
theorem cert_e2422408690490 : check e2422408690490 [[],[]] .chain = true := by decide
def e2422408690562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422408690562 : Closed e2422408690562 ∧ code e2422408690562 = 11218501712770 := by decide
theorem cert_e2422408690562 : check e2422408690562 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2422408690574 : Closed e2422408690574 ∧ code e2422408690574 = 11218501712782 := by decide
theorem cert_e2422408690574 : check e2422408690574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408690586 : Closed e2422408690586 ∧ code e2422408690586 = 11218501712794 := by decide
theorem cert_e2422408690586 : check e2422408690586 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408690710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408690710 : Closed e2422408690710 ∧ code e2422408690710 = 11218501712918 := by decide
theorem cert_e2422408690710 : check e2422408690710 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408690806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422408690806 : Closed e2422408690806 ∧ code e2422408690806 = 11218501713014 := by decide
theorem cert_e2422408690806 : check e2422408690806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408690902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422408690902 : Closed e2422408690902 ∧ code e2422408690902 = 11218501713110 := by decide
def e2422408690906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2422408690906 : Closed e2422408690906 ∧ code e2422408690906 = 11218501713114 := by decide
theorem cert_e2422408690906 : check e2422408690906 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408690922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2422408690922 : Closed e2422408690922 ∧ code e2422408690922 = 11218501713130 := by decide
theorem cert_e2422408690922 : check e2422408690922 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408690998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408690998 : Closed e2422408690998 ∧ code e2422408690998 = 11218501713206 := by decide
theorem cert_e2422408690998 : check e2422408690998 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422408691002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408691002 : Closed e2422408691002 ∧ code e2422408691002 = 11218501713210 := by decide
theorem cert_e2422408691002 : check e2422408691002 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408691074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 0))))))))
theorem wire_e2422408691074 : Closed e2422408691074 ∧ code e2422408691074 = 11218501713282 := by decide
theorem cert_e2422408691074 : check e2422408691074 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408691086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422408691086 : Closed e2422408691086 ∧ code e2422408691086 = 11218501713294 := by decide
theorem cert_e2422408691086 : check e2422408691086 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408691098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422408691098 : Closed e2422408691098 ∧ code e2422408691098 = 11218501713306 := by decide
theorem cert_e2422408691098 : check e2422408691098 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408691934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422408691934 : Closed e2422408691934 ∧ code e2422408691934 = 11218501714142 := by decide
theorem cert_e2422408691934 : check e2422408691934 [[],[]] .chain = true := by decide
def e2422408691962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422408691962 : Closed e2422408691962 ∧ code e2422408691962 = 11218501714170 := by decide
theorem cert_e2422408691962 : check e2422408691962 [[],[]] .chain = true := by decide
def e2422408692510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422408692510 : Closed e2422408692510 ∧ code e2422408692510 = 11218501714718 := by decide
theorem cert_e2422408692510 : check e2422408692510 [[],[]] .chain = true := by decide
def e2422408692678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422408692678 : Closed e2422408692678 ∧ code e2422408692678 = 11218501714886 := by decide
theorem cert_e2422408692678 : check e2422408692678 [[],[]] .chain = true := by decide
def e2422408692702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422408692702 : Closed e2422408692702 ∧ code e2422408692702 = 11218501714910 := by decide
theorem cert_e2422408692702 : check e2422408692702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422408692718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422408692718 : Closed e2422408692718 ∧ code e2422408692718 = 11218501714926 := by decide
theorem cert_e2422408692718 : check e2422408692718 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2422408694550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422408694550 : Closed e2422408694550 ∧ code e2422408694550 = 11218501716758 := by decide
theorem cert_e2422408694550 : check e2422408694550 [[],[]] .chain = true := by decide
def e2422408694626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422408694626 : Closed e2422408694626 ∧ code e2422408694626 = 11218501716834 := by decide
theorem cert_e2422408694626 : check e2422408694626 [[],[]] .chain = true := by decide
def e2422408694638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422408694638 : Closed e2422408694638 ∧ code e2422408694638 = 11218501716846 := by decide
theorem cert_e2422408694638 : check e2422408694638 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408694646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422408694646 : Closed e2422408694646 ∧ code e2422408694646 = 11218501716854 := by decide
theorem cert_e2422408694646 : check e2422408694646 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422408694666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422408694666 : Closed e2422408694666 ∧ code e2422408694666 = 11218501716874 := by decide
theorem cert_e2422408694666 : check e2422408694666 [[],[]] .chain = true := by decide
def e2422408694690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422408694690 : Closed e2422408694690 ∧ code e2422408694690 = 11218501716898 := by decide
theorem cert_e2422408694690 : check e2422408694690 [[],[]] .chain = true := by decide
def e2422408694702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422408694702 : Closed e2422408694702 ∧ code e2422408694702 = 11218501716910 := by decide
theorem cert_e2422408694702 : check e2422408694702 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408694710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2422408694710 : Closed e2422408694710 ∧ code e2422408694710 = 11218501716918 := by decide
theorem cert_e2422408694710 : check e2422408694710 [[],[]] .chain = true := by decide
def e2422408694714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422408694714 : Closed e2422408694714 ∧ code e2422408694714 = 11218501716922 := by decide
theorem cert_e2422408694714 : check e2422408694714 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408694742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422408694742 : Closed e2422408694742 ∧ code e2422408694742 = 11218501716950 := by decide
theorem cert_e2422408694742 : check e2422408694742 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408694746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422408694746 : Closed e2422408694746 ∧ code e2422408694746 = 11218501716954 := by decide
theorem cert_e2422408694746 : check e2422408694746 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408694814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2422408694814 : Closed e2422408694814 ∧ code e2422408694814 = 11218501717022 := by decide
theorem cert_e2422408694814 : check e2422408694814 [[],[]] .chain = true := by decide
def e2422408695010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422408695010 : Closed e2422408695010 ∧ code e2422408695010 = 11218501717218 := by decide
theorem cert_e2422408695010 : check e2422408695010 [[],[]] .chain = true := by decide
def e2422408695022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408695022 : Closed e2422408695022 ∧ code e2422408695022 = 11218501717230 := by decide
theorem cert_e2422408695022 : check e2422408695022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422408695030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408695030 : Closed e2422408695030 ∧ code e2422408695030 = 11218501717238 := by decide
theorem cert_e2422408695030 : check e2422408695030 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .identityHead = true := by decide
def e2422408695298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422408695298 : Closed e2422408695298 ∧ code e2422408695298 = 11218501717506 := by decide
theorem cert_e2422408695298 : check e2422408695298 [[],[]] .chain = true := by decide
def e2422408695310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2422408695310 : Closed e2422408695310 ∧ code e2422408695310 = 11218501717518 := by decide
theorem cert_e2422408695310 : check e2422408695310 [[],[]] .chain = true := by decide
def e2422408695322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408695322 : Closed e2422408695322 ∧ code e2422408695322 = 11218501717530 := by decide
theorem cert_e2422408695322 : check e2422408695322 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422408695394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422408695394 : Closed e2422408695394 ∧ code e2422408695394 = 11218501717602 := by decide
theorem cert_e2422408695394 : check e2422408695394 [[],[]] .chain = true := by decide
def e2422408695406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408695406 : Closed e2422408695406 ∧ code e2422408695406 = 11218501717614 := by decide
theorem cert_e2422408695406 : check e2422408695406 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408695414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2422408695414 : Closed e2422408695414 ∧ code e2422408695414 = 11218501717622 := by decide
theorem cert_e2422408695414 : check e2422408695414 [[],[]] .chain = true := by decide
def e2422408695418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408695418 : Closed e2422408695418 ∧ code e2422408695418 = 11218501717626 := by decide
theorem cert_e2422408695418 : check e2422408695418 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408695606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408695606 : Closed e2422408695606 ∧ code e2422408695606 = 11218501717814 := by decide
theorem cert_e2422408695606 : check e2422408695606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422408695610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408695610 : Closed e2422408695610 ∧ code e2422408695610 = 11218501717818 := by decide
theorem cert_e2422408695610 : check e2422408695610 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408699930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422408699930 : Closed e2422408699930 ∧ code e2422408699930 = 11218501722138 := by decide
theorem cert_e2422408699930 : check e2422408699930 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408699966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422408699966 : Closed e2422408699966 ∧ code e2422408699966 = 11218501722174 := by decide
theorem cert_e2422408699966 : check e2422408699966 [[],[]] .chain = true := by decide
def e2422408700014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408700014 : Closed e2422408700014 ∧ code e2422408700014 = 11218501722222 := by decide
theorem cert_e2422408700014 : check e2422408700014 [[],[]] .chain = true := by decide
def e2422408700022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422408700022 : Closed e2422408700022 ∧ code e2422408700022 = 11218501722230 := by decide
theorem cert_e2422408700022 : check e2422408700022 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408700026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408700026 : Closed e2422408700026 ∧ code e2422408700026 = 11218501722234 := by decide
theorem cert_e2422408700026 : check e2422408700026 [[],[]] .chain = true := by decide
def e2422408700266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422408700266 : Closed e2422408700266 ∧ code e2422408700266 = 11218501722474 := by decide
theorem cert_e2422408700266 : check e2422408700266 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408700302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422408700302 : Closed e2422408700302 ∧ code e2422408700302 = 11218501722510 := by decide
theorem cert_e2422408700302 : check e2422408700302 [[],[]] .chain = true := by decide
def e2422408700314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408700314 : Closed e2422408700314 ∧ code e2422408700314 = 11218501722522 := by decide
theorem cert_e2422408700314 : check e2422408700314 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408700358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422408700358 : Closed e2422408700358 ∧ code e2422408700358 = 11218501722566 := by decide
theorem cert_e2422408700358 : check e2422408700358 [[],[]] .chain = true := by decide
def e2422408700382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422408700382 : Closed e2422408700382 ∧ code e2422408700382 = 11218501722590 := by decide
theorem cert_e2422408700382 : check e2422408700382 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408700386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422408700386 : Closed e2422408700386 ∧ code e2422408700386 = 11218501722594 := by decide
theorem cert_e2422408700386 : check e2422408700386 [[],[]] .chain = true := by decide
def e2422408700398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422408700398 : Closed e2422408700398 ∧ code e2422408700398 = 11218501722606 := by decide
theorem cert_e2422408700398 : check e2422408700398 [[],[]] .chain = true := by decide
def e2422408700406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422408700406 : Closed e2422408700406 ∧ code e2422408700406 = 11218501722614 := by decide
theorem cert_e2422408700406 : check e2422408700406 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422408701322 : Closed e2422408701322 ∧ code e2422408701322 = 11218501723530 := by decide
theorem cert_e2422408701322 : check e2422408701322 [[],[]] .chain = true := by decide
def e2422408701346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422408701346 : Closed e2422408701346 ∧ code e2422408701346 = 11218501723554 := by decide
theorem cert_e2422408701346 : check e2422408701346 [[],[]] .chain = true := by decide
def e2422408701358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422408701358 : Closed e2422408701358 ∧ code e2422408701358 = 11218501723566 := by decide
theorem cert_e2422408701358 : check e2422408701358 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422408701366 : Closed e2422408701366 ∧ code e2422408701366 = 11218501723574 := by decide
theorem cert_e2422408701366 : check e2422408701366 [[],[]] .chain = true := by decide
def e2422408701370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422408701370 : Closed e2422408701370 ∧ code e2422408701370 = 11218501723578 := by decide
theorem cert_e2422408701370 : check e2422408701370 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422408701398 : Closed e2422408701398 ∧ code e2422408701398 = 11218501723606 := by decide
theorem cert_e2422408701398 : check e2422408701398 [[],[]] .chain = true := by decide
def e2422408701402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422408701402 : Closed e2422408701402 ∧ code e2422408701402 = 11218501723610 := by decide
theorem cert_e2422408701402 : check e2422408701402 [[],[]] .chain = true := by decide
def e2422408701418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422408701418 : Closed e2422408701418 ∧ code e2422408701418 = 11218501723626 := by decide
theorem cert_e2422408701418 : check e2422408701418 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422408701442 : Closed e2422408701442 ∧ code e2422408701442 = 11218501723650 := by decide
theorem cert_e2422408701442 : check e2422408701442 [[],[]] .chain = true := by decide
def e2422408701454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422408701454 : Closed e2422408701454 ∧ code e2422408701454 = 11218501723662 := by decide
theorem cert_e2422408701454 : check e2422408701454 [[],[]] .chain = true := by decide
def e2422408701466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422408701466 : Closed e2422408701466 ∧ code e2422408701466 = 11218501723674 := by decide
theorem cert_e2422408701466 : check e2422408701466 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422408701538 : Closed e2422408701538 ∧ code e2422408701538 = 11218501723746 := by decide
theorem cert_e2422408701538 : check e2422408701538 [[],[]] .chain = true := by decide
def e2422408701550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408701550 : Closed e2422408701550 ∧ code e2422408701550 = 11218501723758 := by decide
theorem cert_e2422408701550 : check e2422408701550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422408701558 : Closed e2422408701558 ∧ code e2422408701558 = 11218501723766 := by decide
theorem cert_e2422408701558 : check e2422408701558 [[],[]] .chain = true := by decide
def e2422408701562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408701562 : Closed e2422408701562 ∧ code e2422408701562 = 11218501723770 := by decide
theorem cert_e2422408701562 : check e2422408701562 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422408701702 : Closed e2422408701702 ∧ code e2422408701702 = 11218501723910 := by decide
theorem cert_e2422408701702 : check e2422408701702 [[],[]] .chain = true := by decide
def e2422408701726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422408701726 : Closed e2422408701726 ∧ code e2422408701726 = 11218501723934 := by decide
theorem cert_e2422408701726 : check e2422408701726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408701750 : Closed e2422408701750 ∧ code e2422408701750 = 11218501723958 := by decide
theorem cert_e2422408701750 : check e2422408701750 [[],[]] .chain = true := by decide
def e2422408701754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408701754 : Closed e2422408701754 ∧ code e2422408701754 = 11218501723962 := by decide
theorem cert_e2422408701754 : check e2422408701754 [[],[]] .chain = true := by decide
def e2422408701826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422408701826 : Closed e2422408701826 ∧ code e2422408701826 = 11218501724034 := by decide
theorem cert_e2422408701826 : check e2422408701826 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422408701838 : Closed e2422408701838 ∧ code e2422408701838 = 11218501724046 := by decide
theorem cert_e2422408701838 : check e2422408701838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408701850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422408701850 : Closed e2422408701850 ∧ code e2422408701850 = 11218501724058 := by decide
theorem cert_e2422408701850 : check e2422408701850 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2422408704238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422408704238 : Closed e2422408704238 ∧ code e2422408704238 = 11218501726446 := by decide
theorem cert_e2422408704238 : check e2422408704238 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422408704246 : Closed e2422408704246 ∧ code e2422408704246 = 11218501726454 := by decide
theorem cert_e2422408704246 : check e2422408704246 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422408704726 : Closed e2422408704726 ∧ code e2422408704726 = 11218501726934 := by decide
theorem cert_e2422408704726 : check e2422408704726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422408704730 : Closed e2422408704730 ∧ code e2422408704730 = 11218501726938 := by decide
theorem cert_e2422408704730 : check e2422408704730 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422408704746 : Closed e2422408704746 ∧ code e2422408704746 = 11218501726954 := by decide
theorem cert_e2422408704746 : check e2422408704746 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408704822 : Closed e2422408704822 ∧ code e2422408704822 = 11218501727030 := by decide
theorem cert_e2422408704822 : check e2422408704822 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408704826 : Closed e2422408704826 ∧ code e2422408704826 = 11218501727034 := by decide
theorem cert_e2422408704826 : check e2422408704826 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e2422408704898 : Closed e2422408704898 ∧ code e2422408704898 = 11218501727106 := by decide
theorem cert_e2422408704898 : check e2422408704898 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422408704910 : Closed e2422408704910 ∧ code e2422408704910 = 11218501727118 := by decide
theorem cert_e2422408704910 : check e2422408704910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408704922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422408704922 : Closed e2422408704922 ∧ code e2422408704922 = 11218501727130 := by decide
theorem cert_e2422408704922 : check e2422408704922 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408743790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422408743790 : Closed e2422408743790 ∧ code e2422408743790 = 11218501765998 := by decide
theorem cert_e2422408743790 : check e2422408743790 [[],[]] .smaller = true := by decide
def e2422408743798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422408743798 : Closed e2422408743798 ∧ code e2422408743798 = 11218501766006 := by decide
theorem cert_e2422408743798 : check e2422408743798 [[],[]] .smaller = true := by decide
def e2422408743854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422408743854 : Closed e2422408743854 ∧ code e2422408743854 = 11218501766062 := by decide
theorem cert_e2422408743854 : check e2422408743854 [[],[]] .smaller = true := by decide
def e2422408743866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422408743866 : Closed e2422408743866 ∧ code e2422408743866 = 11218501766074 := by decide
theorem cert_e2422408743866 : check e2422408743866 [[],[]] .smaller = true := by decide
def e2422408743894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422408743894 : Closed e2422408743894 ∧ code e2422408743894 = 11218501766102 := by decide
theorem cert_e2422408743894 : check e2422408743894 [[],[]] .smaller = true := by decide
def e2422408743898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422408743898 : Closed e2422408743898 ∧ code e2422408743898 = 11218501766106 := by decide
theorem cert_e2422408743898 : check e2422408743898 [[],[]] .smaller = true := by decide
def e2422408744174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422408744174 : Closed e2422408744174 ∧ code e2422408744174 = 11218501766382 := by decide
theorem cert_e2422408744174 : check e2422408744174 [[],[]] .smaller = true := by decide
def e2422408744182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422408744182 : Closed e2422408744182 ∧ code e2422408744182 = 11218501766390 := by decide
theorem cert_e2422408744182 : check e2422408744182 [[],[]] .smaller = true := by decide
def e2422408744558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422408744558 : Closed e2422408744558 ∧ code e2422408744558 = 11218501766766 := by decide
theorem cert_e2422408744558 : check e2422408744558 [[],[]] .smaller = true := by decide
def e2422408744570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422408744570 : Closed e2422408744570 ∧ code e2422408744570 = 11218501766778 := by decide
theorem cert_e2422408744570 : check e2422408744570 [[],[]] .smaller = true := by decide
def e2422408744758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422408744758 : Closed e2422408744758 ∧ code e2422408744758 = 11218501766966 := by decide
theorem cert_e2422408744758 : check e2422408744758 [[],[]] .smaller = true := by decide
def e2422408744762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422408744762 : Closed e2422408744762 ∧ code e2422408744762 = 11218501766970 := by decide
theorem cert_e2422408744762 : check e2422408744762 [[],[]] .smaller = true := by decide
def e2422408752574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2422408752574 : Closed e2422408752574 ∧ code e2422408752574 = 11218501774782 := by decide
theorem cert_e2422408752574 : check e2422408752574 [[],[]] .chain = true := by decide
def e2422408752606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2422408752606 : Closed e2422408752606 ∧ code e2422408752606 = 11218501774814 := by decide
theorem cert_e2422408752606 : check e2422408752606 [[],[]] .smaller = true := by decide
def e2422408752622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2422408752622 : Closed e2422408752622 ∧ code e2422408752622 = 11218501774830 := by decide
theorem cert_e2422408752622 : check e2422408752622 [[],[]] .smaller = true := by decide
def e2422408752630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2422408752630 : Closed e2422408752630 ∧ code e2422408752630 = 11218501774838 := by decide
theorem cert_e2422408752630 : check e2422408752630 [[],[]] .chain = true := by decide
def e2422408752830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2422408752830 : Closed e2422408752830 ∧ code e2422408752830 = 11218501775038 := by decide
theorem cert_e2422408752830 : check e2422408752830 [[],[]] .chain = true := by decide
def e2422408752890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2422408752890 : Closed e2422408752890 ∧ code e2422408752890 = 11218501775098 := by decide
theorem cert_e2422408752890 : check e2422408752890 [[],[]] .chain = true := by decide
def e2422408752990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2422408752990 : Closed e2422408752990 ∧ code e2422408752990 = 11218501775198 := by decide
theorem cert_e2422408752990 : check e2422408752990 [[],[]] .smaller = true := by decide
def e2422408753018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2422408753018 : Closed e2422408753018 ∧ code e2422408753018 = 11218501775226 := by decide
theorem cert_e2422408753018 : check e2422408753018 [[],[]] .smaller = true := by decide
def e2422408753070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2422408753070 : Closed e2422408753070 ∧ code e2422408753070 = 11218501775278 := by decide
theorem cert_e2422408753070 : check e2422408753070 [[],[]] .smaller = true := by decide
def e2422408753082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2422408753082 : Closed e2422408753082 ∧ code e2422408753082 = 11218501775290 := by decide
theorem cert_e2422408753082 : check e2422408753082 [[],[]] .smaller = true := by decide
def e2422408753110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2422408753110 : Closed e2422408753110 ∧ code e2422408753110 = 11218501775318 := by decide
theorem cert_e2422408753110 : check e2422408753110 [[],[]] .chain = true := by decide
def e2422408753114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2422408753114 : Closed e2422408753114 ∧ code e2422408753114 = 11218501775322 := by decide
theorem cert_e2422408753114 : check e2422408753114 [[],[]] .chain = true := by decide
def e2422408754110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422408754110 : Closed e2422408754110 ∧ code e2422408754110 = 11218501776318 := by decide
theorem cert_e2422408754110 : check e2422408754110 [[],[]] .chain = true := by decide
def e2422408754142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422408754142 : Closed e2422408754142 ∧ code e2422408754142 = 11218501776350 := by decide
theorem cert_e2422408754142 : check e2422408754142 [[],[]] .smaller = true := by decide
def e2422408754158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422408754158 : Closed e2422408754158 ∧ code e2422408754158 = 11218501776366 := by decide
theorem cert_e2422408754158 : check e2422408754158 [[],[]] .smaller = true := by decide
def e2422408754166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422408754166 : Closed e2422408754166 ∧ code e2422408754166 = 11218501776374 := by decide
theorem cert_e2422408754166 : check e2422408754166 [[],[]] .chain = true := by decide
def e2422408755646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422408755646 : Closed e2422408755646 ∧ code e2422408755646 = 11218501777854 := by decide
theorem cert_e2422408755646 : check e2422408755646 [[],[]] .chain = true := by decide
def e2422408755706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422408755706 : Closed e2422408755706 ∧ code e2422408755706 = 11218501777914 := by decide
theorem cert_e2422408755706 : check e2422408755706 [[],[]] .chain = true := by decide
def e2422408756446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422408756446 : Closed e2422408756446 ∧ code e2422408756446 = 11218501778654 := by decide
theorem cert_e2422408756446 : check e2422408756446 [[],[]] .smaller = true := by decide
def e2422408756474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422408756474 : Closed e2422408756474 ∧ code e2422408756474 = 11218501778682 := by decide
theorem cert_e2422408756474 : check e2422408756474 [[],[]] .smaller = true := by decide
def e2422408756846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422408756846 : Closed e2422408756846 ∧ code e2422408756846 = 11218501779054 := by decide
theorem cert_e2422408756846 : check e2422408756846 [[],[]] .smaller = true := by decide
def e2422408756858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422408756858 : Closed e2422408756858 ∧ code e2422408756858 = 11218501779066 := by decide
theorem cert_e2422408756858 : check e2422408756858 [[],[]] .smaller = true := by decide
def e2422408757046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422408757046 : Closed e2422408757046 ∧ code e2422408757046 = 11218501779254 := by decide
theorem cert_e2422408757046 : check e2422408757046 [[],[]] .chain = true := by decide
def e2422408757050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422408757050 : Closed e2422408757050 ∧ code e2422408757050 = 11218501779258 := by decide
theorem cert_e2422408757050 : check e2422408757050 [[],[]] .chain = true := by decide
def e2422408785262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422408785262 : Closed e2422408785262 ∧ code e2422408785262 = 11218501807470 := by decide
theorem cert_e2422408785262 : check e2422408785262 [[],[]] .smaller = true := by decide
def e2422408785270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422408785270 : Closed e2422408785270 ∧ code e2422408785270 = 11218501807478 := by decide
theorem cert_e2422408785270 : check e2422408785270 [[],[]] .smaller = true := by decide
def e2422408785326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422408785326 : Closed e2422408785326 ∧ code e2422408785326 = 11218501807534 := by decide
theorem cert_e2422408785326 : check e2422408785326 [[],[]] .smaller = true := by decide
def e2422408785338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422408785338 : Closed e2422408785338 ∧ code e2422408785338 = 11218501807546 := by decide
theorem cert_e2422408785338 : check e2422408785338 [[],[]] .smaller = true := by decide
def e2422408785366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422408785366 : Closed e2422408785366 ∧ code e2422408785366 = 11218501807574 := by decide
theorem cert_e2422408785366 : check e2422408785366 [[],[]] .smaller = true := by decide
def e2422408785370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422408785370 : Closed e2422408785370 ∧ code e2422408785370 = 11218501807578 := by decide
theorem cert_e2422408785370 : check e2422408785370 [[],[]] .smaller = true := by decide
def e2422408785582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422408785582 : Closed e2422408785582 ∧ code e2422408785582 = 11218501807790 := by decide
theorem cert_e2422408785582 : check e2422408785582 [[],[]] .smaller = true := by decide
def e2422408785594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422408785594 : Closed e2422408785594 ∧ code e2422408785594 = 11218501807802 := by decide
theorem cert_e2422408785594 : check e2422408785594 [[],[]] .smaller = true := by decide
def e2422408785642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422408785642 : Closed e2422408785642 ∧ code e2422408785642 = 11218501807850 := by decide
theorem cert_e2422408785642 : check e2422408785642 [[],[]] .smaller = true := by decide
def e2422408785750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422408785750 : Closed e2422408785750 ∧ code e2422408785750 = 11218501807958 := by decide
theorem cert_e2422408785750 : check e2422408785750 [[],[]] .smaller = true := by decide
def e2422408785754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422408785754 : Closed e2422408785754 ∧ code e2422408785754 = 11218501807962 := by decide
theorem cert_e2422408785754 : check e2422408785754 [[],[]] .smaller = true := by decide
def e2422408785770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422408785770 : Closed e2422408785770 ∧ code e2422408785770 = 11218501807978 := by decide
theorem cert_e2422408785770 : check e2422408785770 [[],[]] .smaller = true := by decide
def e2422408786398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2422408786398 : Closed e2422408786398 ∧ code e2422408786398 = 11218501808606 := by decide
theorem cert_e2422408786398 : check e2422408786398 [[],[]] .chain = true := by decide
def e2422408786422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2422408786422 : Closed e2422408786422 ∧ code e2422408786422 = 11218501808630 := by decide
theorem cert_e2422408786422 : check e2422408786422 [[],[]] .chain = true := by decide
def e2422408786798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422408786798 : Closed e2422408786798 ∧ code e2422408786798 = 11218501809006 := by decide
theorem cert_e2422408786798 : check e2422408786798 [[],[]] .smaller = true := by decide
def e2422408786806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422408786806 : Closed e2422408786806 ∧ code e2422408786806 = 11218501809014 := by decide
theorem cert_e2422408786806 : check e2422408786806 [[],[]] .smaller = true := by decide
def e2422408786862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422408786862 : Closed e2422408786862 ∧ code e2422408786862 = 11218501809070 := by decide
theorem cert_e2422408786862 : check e2422408786862 [[],[]] .smaller = true := by decide
def e2422408786874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422408786874 : Closed e2422408786874 ∧ code e2422408786874 = 11218501809082 := by decide
theorem cert_e2422408786874 : check e2422408786874 [[],[]] .smaller = true := by decide
def e2422408786902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422408786902 : Closed e2422408786902 ∧ code e2422408786902 = 11218501809110 := by decide
theorem cert_e2422408786902 : check e2422408786902 [[],[]] .smaller = true := by decide
def e2422408786906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422408786906 : Closed e2422408786906 ∧ code e2422408786906 = 11218501809114 := by decide
theorem cert_e2422408786906 : check e2422408786906 [[],[]] .smaller = true := by decide
def e2422408787182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422408787182 : Closed e2422408787182 ∧ code e2422408787182 = 11218501809390 := by decide
theorem cert_e2422408787182 : check e2422408787182 [[],[]] .smaller = true := by decide
def e2422408787190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422408787190 : Closed e2422408787190 ∧ code e2422408787190 = 11218501809398 := by decide
theorem cert_e2422408787190 : check e2422408787190 [[],[]] .smaller = true := by decide
def e2422408787518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2422408787518 : Closed e2422408787518 ∧ code e2422408787518 = 11218501809726 := by decide
theorem cert_e2422408787518 : check e2422408787518 [[],[]] .chain = true := by decide
def e2422408787566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408787566 : Closed e2422408787566 ∧ code e2422408787566 = 11218501809774 := by decide
theorem cert_e2422408787566 : check e2422408787566 [[],[]] .smaller = true := by decide
def e2422408787578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422408787578 : Closed e2422408787578 ∧ code e2422408787578 = 11218501809786 := by decide
theorem cert_e2422408787578 : check e2422408787578 [[],[]] .smaller = true := by decide
def e2422408787766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422408787766 : Closed e2422408787766 ∧ code e2422408787766 = 11218501809974 := by decide
theorem cert_e2422408787766 : check e2422408787766 [[],[]] .smaller = true := by decide
def e2422408787770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422408787770 : Closed e2422408787770 ∧ code e2422408787770 = 11218501809978 := by decide
theorem cert_e2422408787770 : check e2422408787770 [[],[]] .smaller = true := by decide
def e2422408787854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2422408787854 : Closed e2422408787854 ∧ code e2422408787854 = 11218501810062 := by decide
theorem cert_e2422408787854 : check e2422408787854 [[],[]] .chain = true := by decide
def e2422408788190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422408788190 : Closed e2422408788190 ∧ code e2422408788190 = 11218501810398 := by decide
theorem cert_e2422408788190 : check e2422408788190 [[],[]] .chain = true := by decide
def e2422408788218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422408788218 : Closed e2422408788218 ∧ code e2422408788218 = 11218501810426 := by decide
theorem cert_e2422408788218 : check e2422408788218 [[],[]] .chain = true := by decide
def e2422408788398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422408788398 : Closed e2422408788398 ∧ code e2422408788398 = 11218501810606 := by decide
theorem cert_e2422408788398 : check e2422408788398 [[],[]] .smaller = true := by decide
def e2422408788410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422408788410 : Closed e2422408788410 ∧ code e2422408788410 = 11218501810618 := by decide
theorem cert_e2422408788410 : check e2422408788410 [[],[]] .smaller = true := by decide
def e2422408788458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422408788458 : Closed e2422408788458 ∧ code e2422408788458 = 11218501810666 := by decide
theorem cert_e2422408788458 : check e2422408788458 [[],[]] .smaller = true := by decide
def e2422408788542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422408788542 : Closed e2422408788542 ∧ code e2422408788542 = 11218501810750 := by decide
theorem cert_e2422408788542 : check e2422408788542 [[],[]] .chain = true := by decide
def e2422408788590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422408788590 : Closed e2422408788590 ∧ code e2422408788590 = 11218501810798 := by decide
theorem cert_e2422408788590 : check e2422408788590 [[],[]] .smaller = true := by decide
end Blc.Floor43
