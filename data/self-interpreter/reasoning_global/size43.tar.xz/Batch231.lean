import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393371520890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2393371520890 : Closed e2393371520890 ∧ code e2393371520890 = 11189464543098 := by decide
theorem cert_e2393371520890 : check e2393371520890 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371520942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2393371520942 : Closed e2393371520942 ∧ code e2393371520942 = 11189464543150 := by decide
theorem cert_e2393371520942 : check e2393371520942 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371520950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2393371520950 : Closed e2393371520950 ∧ code e2393371520950 = 11189464543158 := by decide
theorem cert_e2393371520950 : check e2393371520950 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371520954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2393371520954 : Closed e2393371520954 ∧ code e2393371520954 = 11189464543162 := by decide
theorem cert_e2393371520954 : check e2393371520954 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371521262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2393371521262 : Closed e2393371521262 ∧ code e2393371521262 = 11189464543470 := by decide
theorem cert_e2393371521262 : check e2393371521262 [[],[.left],[]] .chain = true := by decide
def e2393371521270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2393371521270 : Closed e2393371521270 ∧ code e2393371521270 = 11189464543478 := by decide
theorem cert_e2393371521270 : check e2393371521270 [[],[.left],[]] .chain = true := by decide
def e2393371521750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2393371521750 : Closed e2393371521750 ∧ code e2393371521750 = 11189464543958 := by decide
theorem cert_e2393371521750 : check e2393371521750 [[],[.left],[]] .chain = true := by decide
def e2393371521754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2393371521754 : Closed e2393371521754 ∧ code e2393371521754 = 11189464543962 := by decide
theorem cert_e2393371521754 : check e2393371521754 [[],[.left],[]] .chain = true := by decide
def e2393371521770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2393371521770 : Closed e2393371521770 ∧ code e2393371521770 = 11189464543978 := by decide
theorem cert_e2393371521770 : check e2393371521770 [[],[.left],[]] .chain = true := by decide
def e2393371521846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393371521846 : Closed e2393371521846 ∧ code e2393371521846 = 11189464544054 := by decide
theorem cert_e2393371521846 : check e2393371521846 [[],[.left],[]] .chain = true := by decide
def e2393371521850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393371521850 : Closed e2393371521850 ∧ code e2393371521850 = 11189464544058 := by decide
theorem cert_e2393371521850 : check e2393371521850 [[],[.left],[]] .chain = true := by decide
def e2393371521934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2393371521934 : Closed e2393371521934 ∧ code e2393371521934 = 11189464544142 := by decide
theorem cert_e2393371521934 : check e2393371521934 [[],[.left],[]] .chain = true := by decide
def e2393371521946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393371521946 : Closed e2393371521946 ∧ code e2393371521946 = 11189464544154 := by decide
theorem cert_e2393371521946 : check e2393371521946 [[],[.left],[]] .chain = true := by decide
def e2393371522014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393371522014 : Closed e2393371522014 ∧ code e2393371522014 = 11189464544222 := by decide
theorem cert_e2393371522014 : check e2393371522014 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371522030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393371522030 : Closed e2393371522030 ∧ code e2393371522030 = 11189464544238 := by decide
theorem cert_e2393371522030 : check e2393371522030 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371523190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2393371523190 : Closed e2393371523190 ∧ code e2393371523190 = 11189464545398 := by decide
theorem cert_e2393371523190 : check e2393371523190 [[],[.left],[]] .chain = true := by decide
def e2393371523434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2393371523434 : Closed e2393371523434 ∧ code e2393371523434 = 11189464545642 := by decide
theorem cert_e2393371523434 : check e2393371523434 [[],[.left],[]] .chain = true := by decide
def e2393371523470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2393371523470 : Closed e2393371523470 ∧ code e2393371523470 = 11189464545678 := by decide
theorem cert_e2393371523470 : check e2393371523470 [[],[.left],[]] .chain = true := by decide
def e2393371523482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2393371523482 : Closed e2393371523482 ∧ code e2393371523482 = 11189464545690 := by decide
theorem cert_e2393371523482 : check e2393371523482 [[],[.left],[]] .chain = true := by decide
def e2393371523526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2393371523526 : Closed e2393371523526 ∧ code e2393371523526 = 11189464545734 := by decide
theorem cert_e2393371523526 : check e2393371523526 [[],[.left],[]] .chain = true := by decide
def e2393371523550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393371523550 : Closed e2393371523550 ∧ code e2393371523550 = 11189464545758 := by decide
theorem cert_e2393371523550 : check e2393371523550 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371523574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393371523574 : Closed e2393371523574 ∧ code e2393371523574 = 11189464545782 := by decide
theorem cert_e2393371523574 : check e2393371523574 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371524318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2393371524318 : Closed e2393371524318 ∧ code e2393371524318 = 11189464546526 := by decide
theorem cert_e2393371524318 : check e2393371524318 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371524346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2393371524346 : Closed e2393371524346 ∧ code e2393371524346 = 11189464546554 := by decide
theorem cert_e2393371524346 : check e2393371524346 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371524718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371524718 : Closed e2393371524718 ∧ code e2393371524718 = 11189464546926 := by decide
theorem cert_e2393371524718 : check e2393371524718 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371524726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393371524726 : Closed e2393371524726 ∧ code e2393371524726 = 11189464546934 := by decide
theorem cert_e2393371524726 : check e2393371524726 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371524730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371524730 : Closed e2393371524730 ∧ code e2393371524730 = 11189464546938 := by decide
theorem cert_e2393371524730 : check e2393371524730 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2393371547190 : Closed e2393371547190 ∧ code e2393371547190 = 11189464569398 := by decide
theorem cert_e2393371547190 : check e2393371547190 [[],[.left],[]] .chain = true := by decide
def e2393371547194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2393371547194 : Closed e2393371547194 ∧ code e2393371547194 = 11189464569402 := by decide
theorem cert_e2393371547194 : check e2393371547194 [[],[.left],[]] .chain = true := by decide
def e2393371547278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2393371547278 : Closed e2393371547278 ∧ code e2393371547278 = 11189464569486 := by decide
theorem cert_e2393371547278 : check e2393371547278 [[],[.left],[]] .chain = true := by decide
def e2393371547334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2393371547334 : Closed e2393371547334 ∧ code e2393371547334 = 11189464569542 := by decide
theorem cert_e2393371547334 : check e2393371547334 [[],[.left],[]] .chain = true := by decide
def e2393371547358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2393371547358 : Closed e2393371547358 ∧ code e2393371547358 = 11189464569566 := by decide
theorem cert_e2393371547358 : check e2393371547358 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2393371547374 : Closed e2393371547374 ∧ code e2393371547374 = 11189464569582 := by decide
theorem cert_e2393371547374 : check e2393371547374 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2393371547382 : Closed e2393371547382 ∧ code e2393371547382 = 11189464569590 := by decide
theorem cert_e2393371547382 : check e2393371547382 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2393371547418 : Closed e2393371547418 ∧ code e2393371547418 = 11189464569626 := by decide
theorem cert_e2393371547418 : check e2393371547418 [[],[.left],[]] .chain = true := by decide
def e2393371547462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2393371547462 : Closed e2393371547462 ∧ code e2393371547462 = 11189464569670 := by decide
theorem cert_e2393371547462 : check e2393371547462 [[],[.left],[]] .chain = true := by decide
def e2393371547486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2393371547486 : Closed e2393371547486 ∧ code e2393371547486 = 11189464569694 := by decide
theorem cert_e2393371547486 : check e2393371547486 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2393371547502 : Closed e2393371547502 ∧ code e2393371547502 = 11189464569710 := by decide
theorem cert_e2393371547502 : check e2393371547502 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2393371547510 : Closed e2393371547510 ∧ code e2393371547510 = 11189464569718 := by decide
theorem cert_e2393371547510 : check e2393371547510 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2393371547514 : Closed e2393371547514 ∧ code e2393371547514 = 11189464569722 := by decide
theorem cert_e2393371547514 : check e2393371547514 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2393371547566 : Closed e2393371547566 ∧ code e2393371547566 = 11189464569774 := by decide
theorem cert_e2393371547566 : check e2393371547566 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2393371547574 : Closed e2393371547574 ∧ code e2393371547574 = 11189464569782 := by decide
theorem cert_e2393371547574 : check e2393371547574 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2393371547578 : Closed e2393371547578 ∧ code e2393371547578 = 11189464569786 := by decide
theorem cert_e2393371547578 : check e2393371547578 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2393371547606 : Closed e2393371547606 ∧ code e2393371547606 = 11189464569814 := by decide
theorem cert_e2393371547606 : check e2393371547606 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371547610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2393371547610 : Closed e2393371547610 ∧ code e2393371547610 = 11189464569818 := by decide
theorem cert_e2393371547610 : check e2393371547610 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371548046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2393371548046 : Closed e2393371548046 ∧ code e2393371548046 = 11189464570254 := by decide
theorem cert_e2393371548046 : check e2393371548046 [[],[.left],[]] .chain = true := by decide
def e2393371548102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2393371548102 : Closed e2393371548102 ∧ code e2393371548102 = 11189464570310 := by decide
theorem cert_e2393371548102 : check e2393371548102 [[],[.left],[]] .chain = true := by decide
def e2393371548126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393371548126 : Closed e2393371548126 ∧ code e2393371548126 = 11189464570334 := by decide
theorem cert_e2393371548126 : check e2393371548126 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371548142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393371548142 : Closed e2393371548142 ∧ code e2393371548142 = 11189464570350 := by decide
theorem cert_e2393371548142 : check e2393371548142 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371548150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393371548150 : Closed e2393371548150 ∧ code e2393371548150 = 11189464570358 := by decide
theorem cert_e2393371548150 : check e2393371548150 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371548870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2393371548870 : Closed e2393371548870 ∧ code e2393371548870 = 11189464571078 := by decide
theorem cert_e2393371548870 : check e2393371548870 [[],[.left],[]] .chain = true := by decide
def e2393371548894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2393371548894 : Closed e2393371548894 ∧ code e2393371548894 = 11189464571102 := by decide
theorem cert_e2393371548894 : check e2393371548894 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371548910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393371548910 : Closed e2393371548910 ∧ code e2393371548910 = 11189464571118 := by decide
theorem cert_e2393371548910 : check e2393371548910 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371548918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393371548918 : Closed e2393371548918 ∧ code e2393371548918 = 11189464571126 := by decide
theorem cert_e2393371548918 : check e2393371548918 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371548922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2393371548922 : Closed e2393371548922 ∧ code e2393371548922 = 11189464571130 := by decide
theorem cert_e2393371548922 : check e2393371548922 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371549294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371549294 : Closed e2393371549294 ∧ code e2393371549294 = 11189464571502 := by decide
theorem cert_e2393371549294 : check e2393371549294 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371549302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393371549302 : Closed e2393371549302 ∧ code e2393371549302 = 11189464571510 := by decide
theorem cert_e2393371549302 : check e2393371549302 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371549306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371549306 : Closed e2393371549306 ∧ code e2393371549306 = 11189464571514 := by decide
theorem cert_e2393371549306 : check e2393371549306 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371549494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393371549494 : Closed e2393371549494 ∧ code e2393371549494 = 11189464571702 := by decide
theorem cert_e2393371549494 : check e2393371549494 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393371549498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393371549498 : Closed e2393371549498 ∧ code e2393371549498 = 11189464571706 := by decide
theorem cert_e2393371549498 : check e2393371549498 [[],[.left],[],[.under,.under]] .three = true := by decide
def e2393372838766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393372838766 : Closed e2393372838766 ∧ code e2393372838766 = 11189465860974 := by decide
theorem cert_e2393372838766 : check e2393372838766 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2393372838774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393372838774 : Closed e2393372838774 ∧ code e2393372838774 = 11189465860982 := by decide
theorem cert_e2393372838774 : check e2393372838774 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2393372838830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393372838830 : Closed e2393372838830 ∧ code e2393372838830 = 11189465861038 := by decide
theorem cert_e2393372838830 : check e2393372838830 [[],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393372838842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393372838842 : Closed e2393372838842 ∧ code e2393372838842 = 11189465861050 := by decide
theorem cert_e2393372838842 : check e2393372838842 [[],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393372838870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393372838870 : Closed e2393372838870 ∧ code e2393372838870 = 11189465861078 := by decide
theorem cert_e2393372838870 : check e2393372838870 [[],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393372838874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393372838874 : Closed e2393372838874 ∧ code e2393372838874 = 11189465861082 := by decide
theorem cert_e2393372838874 : check e2393372838874 [[],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393372839150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393372839150 : Closed e2393372839150 ∧ code e2393372839150 = 11189465861358 := by decide
theorem cert_e2393372839150 : check e2393372839150 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2393372839158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393372839158 : Closed e2393372839158 ∧ code e2393372839158 = 11189465861366 := by decide
theorem cert_e2393372839158 : check e2393372839158 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2393372839534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393372839534 : Closed e2393372839534 ∧ code e2393372839534 = 11189465861742 := by decide
def e2393372839546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393372839546 : Closed e2393372839546 ∧ code e2393372839546 = 11189465861754 := by decide
def e2393372839734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393372839734 : Closed e2393372839734 ∧ code e2393372839734 = 11189465861942 := by decide
theorem cert_e2393372839734 : check e2393372839734 [[],[.left],[],[.under],[.under,.left],[.under],[.under,.under]] .sourceHead = true := by decide
def e2393372839738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393372839738 : Closed e2393372839738 ∧ code e2393372839738 = 11189465861946 := by decide
def e2393373201270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2393373201270 : Closed e2393373201270 ∧ code e2393373201270 = 11189466223478 := by decide
theorem cert_e2393373201270 : check e2393373201270 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2393373201338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2393373201338 : Closed e2393373201338 ∧ code e2393373201338 = 11189466223546 := by decide
def e2393373201366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2393373201366 : Closed e2393373201366 ∧ code e2393373201366 = 11189466223574 := by decide
theorem cert_e2393373201366 : check e2393373201366 [[],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e2393373201370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2393373201370 : Closed e2393373201370 ∧ code e2393373201370 = 11189466223578 := by decide
def e2393373328750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2393373328750 : Closed e2393373328750 ∧ code e2393373328750 = 11189466350958 := by decide
theorem cert_e2393373328750 : check e2393373328750 [[],[.left],[]] .sourceHead = true := by decide
def e2393373328758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2393373328758 : Closed e2393373328758 ∧ code e2393373328758 = 11189466350966 := by decide
theorem cert_e2393373328758 : check e2393373328758 [[],[.left],[]] .sourceHead = true := by decide
def e2393373328814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2393373328814 : Closed e2393373328814 ∧ code e2393373328814 = 11189466351022 := by decide
theorem cert_e2393373328814 : check e2393373328814 [[],[.left],[]] .sourceHead = true := by decide
def e2393373328826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2393373328826 : Closed e2393373328826 ∧ code e2393373328826 = 11189466351034 := by decide
theorem cert_e2393373328826 : check e2393373328826 [[],[.left],[]] .sourceHead = true := by decide
def e2393373328854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2393373328854 : Closed e2393373328854 ∧ code e2393373328854 = 11189466351062 := by decide
theorem cert_e2393373328854 : check e2393373328854 [[],[.left],[]] .sourceHead = true := by decide
def e2393373328858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2393373328858 : Closed e2393373328858 ∧ code e2393373328858 = 11189466351066 := by decide
theorem cert_e2393373328858 : check e2393373328858 [[],[.left],[]] .sourceHead = true := by decide
def e2393373331822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2393373331822 : Closed e2393373331822 ∧ code e2393373331822 = 11189466354030 := by decide
theorem cert_e2393373331822 : check e2393373331822 [[],[.left],[]] .sourceHead = true := by decide
def e2393373331830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2393373331830 : Closed e2393373331830 ∧ code e2393373331830 = 11189466354038 := by decide
theorem cert_e2393373331830 : check e2393373331830 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2393373333038 : Closed e2393373333038 ∧ code e2393373333038 = 11189466355246 := by decide
theorem cert_e2393373333038 : check e2393373333038 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2393373333218 : Closed e2393373333218 ∧ code e2393373333218 = 11189466355426 := by decide
theorem cert_e2393373333218 : check e2393373333218 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2393373333230 : Closed e2393373333230 ∧ code e2393373333230 = 11189466355438 := by decide
theorem cert_e2393373333230 : check e2393373333230 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2393373333270 : Closed e2393373333270 ∧ code e2393373333270 = 11189466355478 := by decide
theorem cert_e2393373333270 : check e2393373333270 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2393373333346 : Closed e2393373333346 ∧ code e2393373333346 = 11189466355554 := by decide
theorem cert_e2393373333346 : check e2393373333346 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2393373333358 : Closed e2393373333358 ∧ code e2393373333358 = 11189466355566 := by decide
theorem cert_e2393373333358 : check e2393373333358 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2393373333366 : Closed e2393373333366 ∧ code e2393373333366 = 11189466355574 := by decide
theorem cert_e2393373333366 : check e2393373333366 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2393373333678 : Closed e2393373333678 ∧ code e2393373333678 = 11189466355886 := by decide
theorem cert_e2393373333678 : check e2393373333678 [[],[.left],[]] .sourceHead = true := by decide
def e2393373333690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2393373333690 : Closed e2393373333690 ∧ code e2393373333690 = 11189466355898 := by decide
theorem cert_e2393373333690 : check e2393373333690 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2393373334062 : Closed e2393373334062 ∧ code e2393373334062 = 11189466356270 := by decide
theorem cert_e2393373334062 : check e2393373334062 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2393373334242 : Closed e2393373334242 ∧ code e2393373334242 = 11189466356450 := by decide
theorem cert_e2393373334242 : check e2393373334242 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2393373334254 : Closed e2393373334254 ∧ code e2393373334254 = 11189466356462 := by decide
theorem cert_e2393373334254 : check e2393373334254 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2393373334382 : Closed e2393373334382 ∧ code e2393373334382 = 11189466356590 := by decide
theorem cert_e2393373334382 : check e2393373334382 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2393373334390 : Closed e2393373334390 ∧ code e2393373334390 = 11189466356598 := by decide
theorem cert_e2393373334390 : check e2393373334390 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373334410 : Closed e2393373334410 ∧ code e2393373334410 = 11189466356618 := by decide
theorem cert_e2393373334410 : check e2393373334410 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373334434 : Closed e2393373334434 ∧ code e2393373334434 = 11189466356642 := by decide
theorem cert_e2393373334434 : check e2393373334434 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2393373334446 : Closed e2393373334446 ∧ code e2393373334446 = 11189466356654 := by decide
theorem cert_e2393373334446 : check e2393373334446 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2393373334454 : Closed e2393373334454 ∧ code e2393373334454 = 11189466356662 := by decide
theorem cert_e2393373334454 : check e2393373334454 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2393373334458 : Closed e2393373334458 ∧ code e2393373334458 = 11189466356666 := by decide
theorem cert_e2393373334458 : check e2393373334458 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2393373334614 : Closed e2393373334614 ∧ code e2393373334614 = 11189466356822 := by decide
theorem cert_e2393373334614 : check e2393373334614 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2393373334618 : Closed e2393373334618 ∧ code e2393373334618 = 11189466356826 := by decide
theorem cert_e2393373334618 : check e2393373334618 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2393373334806 : Closed e2393373334806 ∧ code e2393373334806 = 11189466357014 := by decide
theorem cert_e2393373334806 : check e2393373334806 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2393373334882 : Closed e2393373334882 ∧ code e2393373334882 = 11189466357090 := by decide
theorem cert_e2393373334882 : check e2393373334882 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2393373334894 : Closed e2393373334894 ∧ code e2393373334894 = 11189466357102 := by decide
theorem cert_e2393373334894 : check e2393373334894 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2393373334902 : Closed e2393373334902 ∧ code e2393373334902 = 11189466357110 := by decide
theorem cert_e2393373334902 : check e2393373334902 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373334922 : Closed e2393373334922 ∧ code e2393373334922 = 11189466357130 := by decide
theorem cert_e2393373334922 : check e2393373334922 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373334946 : Closed e2393373334946 ∧ code e2393373334946 = 11189466357154 := by decide
theorem cert_e2393373334946 : check e2393373334946 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2393373334958 : Closed e2393373334958 ∧ code e2393373334958 = 11189466357166 := by decide
theorem cert_e2393373334958 : check e2393373334958 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2393373334966 : Closed e2393373334966 ∧ code e2393373334966 = 11189466357174 := by decide
theorem cert_e2393373334966 : check e2393373334966 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2393373334970 : Closed e2393373334970 ∧ code e2393373334970 = 11189466357178 := by decide
theorem cert_e2393373334970 : check e2393373334970 [[],[.left],[]] .sourceHead = true := by decide
def e2393373334998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2393373334998 : Closed e2393373334998 ∧ code e2393373334998 = 11189466357206 := by decide
theorem cert_e2393373334998 : check e2393373334998 [[],[.left],[]] .sourceHead = true := by decide
def e2393373335002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2393373335002 : Closed e2393373335002 ∧ code e2393373335002 = 11189466357210 := by decide
theorem cert_e2393373335002 : check e2393373335002 [[],[.left],[]] .sourceHead = true := by decide
def e2393373336238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2393373336238 : Closed e2393373336238 ∧ code e2393373336238 = 11189466358446 := by decide
theorem cert_e2393373336238 : check e2393373336238 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373336250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2393373336250 : Closed e2393373336250 ∧ code e2393373336250 = 11189466358458 := by decide
theorem cert_e2393373336250 : check e2393373336250 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373336298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2393373336298 : Closed e2393373336298 ∧ code e2393373336298 = 11189466358506 := by decide
theorem cert_e2393373336298 : check e2393373336298 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373337774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2393373337774 : Closed e2393373337774 ∧ code e2393373337774 = 11189466359982 := by decide
theorem cert_e2393373337774 : check e2393373337774 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373337786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2393373337786 : Closed e2393373337786 ∧ code e2393373337786 = 11189466359994 := by decide
theorem cert_e2393373337786 : check e2393373337786 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373338158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2393373338158 : Closed e2393373338158 ∧ code e2393373338158 = 11189466360366 := by decide
theorem cert_e2393373338158 : check e2393373338158 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373338338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2393373338338 : Closed e2393373338338 ∧ code e2393373338338 = 11189466360546 := by decide
theorem cert_e2393373338338 : check e2393373338338 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373338350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2393373338350 : Closed e2393373338350 ∧ code e2393373338350 = 11189466360558 := by decide
theorem cert_e2393373338350 : check e2393373338350 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373338478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2393373338478 : Closed e2393373338478 ∧ code e2393373338478 = 11189466360686 := by decide
def e2393373338486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2393373338486 : Closed e2393373338486 ∧ code e2393373338486 = 11189466360694 := by decide
def e2393373338506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373338506 : Closed e2393373338506 ∧ code e2393373338506 = 11189466360714 := by decide
theorem cert_e2393373338506 : check e2393373338506 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373338530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373338530 : Closed e2393373338530 ∧ code e2393373338530 = 11189466360738 := by decide
theorem cert_e2393373338530 : check e2393373338530 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373338542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2393373338542 : Closed e2393373338542 ∧ code e2393373338542 = 11189466360750 := by decide
theorem cert_e2393373338542 : check e2393373338542 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373338550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2393373338550 : Closed e2393373338550 ∧ code e2393373338550 = 11189466360758 := by decide
theorem cert_e2393373338550 : check e2393373338550 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373338554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2393373338554 : Closed e2393373338554 ∧ code e2393373338554 = 11189466360762 := by decide
theorem cert_e2393373338554 : check e2393373338554 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373338990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2393373338990 : Closed e2393373338990 ∧ code e2393373338990 = 11189466361198 := by decide
theorem cert_e2393373338990 : check e2393373338990 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373338998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2393373338998 : Closed e2393373338998 ∧ code e2393373338998 = 11189466361206 := by decide
theorem cert_e2393373338998 : check e2393373338998 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373339054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2393373339054 : Closed e2393373339054 ∧ code e2393373339054 = 11189466361262 := by decide
def e2393373339066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2393373339066 : Closed e2393373339066 ∧ code e2393373339066 = 11189466361274 := by decide
def e2393373339094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2393373339094 : Closed e2393373339094 ∧ code e2393373339094 = 11189466361302 := by decide
def e2393373339098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2393373339098 : Closed e2393373339098 ∧ code e2393373339098 = 11189466361306 := by decide
def e2393373339178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2393373339178 : Closed e2393373339178 ∧ code e2393373339178 = 11189466361386 := by decide
theorem cert_e2393373339178 : check e2393373339178 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393373339274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373339274 : Closed e2393373339274 ∧ code e2393373339274 = 11189466361482 := by decide
theorem cert_e2393373339274 : check e2393373339274 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393373339298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373339298 : Closed e2393373339298 ∧ code e2393373339298 = 11189466361506 := by decide
theorem cert_e2393373339298 : check e2393373339298 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393373339310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2393373339310 : Closed e2393373339310 ∧ code e2393373339310 = 11189466361518 := by decide
theorem cert_e2393373339310 : check e2393373339310 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373339318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2393373339318 : Closed e2393373339318 ∧ code e2393373339318 = 11189466361526 := by decide
theorem cert_e2393373339318 : check e2393373339318 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373339322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2393373339322 : Closed e2393373339322 ∧ code e2393373339322 = 11189466361530 := by decide
theorem cert_e2393373339322 : check e2393373339322 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373339350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2393373339350 : Closed e2393373339350 ∧ code e2393373339350 = 11189466361558 := by decide
def e2393373339354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2393373339354 : Closed e2393373339354 ∧ code e2393373339354 = 11189466361562 := by decide
def e2393373339370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2393373339370 : Closed e2393373339370 ∧ code e2393373339370 = 11189466361578 := by decide
def e2393373339990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2393373339990 : Closed e2393373339990 ∧ code e2393373339990 = 11189466362198 := by decide
theorem cert_e2393373339990 : check e2393373339990 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373339994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2393373339994 : Closed e2393373339994 ∧ code e2393373339994 = 11189466362202 := by decide
theorem cert_e2393373339994 : check e2393373339994 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373340010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2393373340010 : Closed e2393373340010 ∧ code e2393373340010 = 11189466362218 := by decide
theorem cert_e2393373340010 : check e2393373340010 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373340758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2393373340758 : Closed e2393373340758 ∧ code e2393373340758 = 11189466362966 := by decide
theorem cert_e2393373340758 : check e2393373340758 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373340762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2393373340762 : Closed e2393373340762 ∧ code e2393373340762 = 11189466362970 := by decide
theorem cert_e2393373340762 : check e2393373340762 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373340950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2393373340950 : Closed e2393373340950 ∧ code e2393373340950 = 11189466363158 := by decide
theorem cert_e2393373340950 : check e2393373340950 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373341026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2393373341026 : Closed e2393373341026 ∧ code e2393373341026 = 11189466363234 := by decide
theorem cert_e2393373341026 : check e2393373341026 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373341038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2393373341038 : Closed e2393373341038 ∧ code e2393373341038 = 11189466363246 := by decide
theorem cert_e2393373341038 : check e2393373341038 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373341046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2393373341046 : Closed e2393373341046 ∧ code e2393373341046 = 11189466363254 := by decide
theorem cert_e2393373341046 : check e2393373341046 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373341066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373341066 : Closed e2393373341066 ∧ code e2393373341066 = 11189466363274 := by decide
theorem cert_e2393373341066 : check e2393373341066 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373341090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373341090 : Closed e2393373341090 ∧ code e2393373341090 = 11189466363298 := by decide
theorem cert_e2393373341090 : check e2393373341090 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373341102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2393373341102 : Closed e2393373341102 ∧ code e2393373341102 = 11189466363310 := by decide
theorem cert_e2393373341102 : check e2393373341102 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373341110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2393373341110 : Closed e2393373341110 ∧ code e2393373341110 = 11189466363318 := by decide
theorem cert_e2393373341110 : check e2393373341110 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373341114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2393373341114 : Closed e2393373341114 ∧ code e2393373341114 = 11189466363322 := by decide
theorem cert_e2393373341114 : check e2393373341114 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
end Blc.Floor43
