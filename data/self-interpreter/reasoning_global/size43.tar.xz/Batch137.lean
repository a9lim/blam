import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2215384581946 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2215384581946 : Closed e2215384581946 ∧ code e2215384581946 = 11011477604154 := by decide
theorem cert_e2215384581946 : check e2215384581946 [[]] .width = true := by decide
def e2215384585642 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2215384585642 : Closed e2215384585642 ∧ code e2215384585642 = 11011477607850 := by decide
theorem cert_e2215384585642 : check e2215384585642 [[]] .width = true := by decide
def e2215384585738 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2215384585738 : Closed e2215384585738 ∧ code e2215384585738 = 11011477607946 := by decide
theorem cert_e2215384585738 : check e2215384585738 [[]] .width = true := by decide
def e2215384585834 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2215384585834 : Closed e2215384585834 ∧ code e2215384585834 = 11011477608042 := by decide
theorem cert_e2215384585834 : check e2215384585834 [[]] .width = true := by decide
def e2215384585858 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2215384585858 : Closed e2215384585858 ∧ code e2215384585858 = 11011477608066 := by decide
theorem cert_e2215384585858 : check e2215384585858 [[]] .width = true := by decide
def e2215384585882 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2215384585882 : Closed e2215384585882 ∧ code e2215384585882 = 11011477608090 := by decide
theorem cert_e2215384585882 : check e2215384585882 [[]] .width = true := by decide
def e2215384586266 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2215384586266 : Closed e2215384586266 ∧ code e2215384586266 = 11011477608474 := by decide
theorem cert_e2215384586266 : check e2215384586266 [[]] .width = true := by decide
def e2215384586358 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2215384586358 : Closed e2215384586358 ∧ code e2215384586358 = 11011477608566 := by decide
theorem cert_e2215384586358 : check e2215384586358 [[]] .width = true := by decide
def e2215384586602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2215384586602 : Closed e2215384586602 ∧ code e2215384586602 = 11011477608810 := by decide
theorem cert_e2215384586602 : check e2215384586602 [[]] .width = true := by decide
def e2215384586626 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2215384586626 : Closed e2215384586626 ∧ code e2215384586626 = 11011477608834 := by decide
theorem cert_e2215384586626 : check e2215384586626 [[]] .width = true := by decide
def e2215384586650 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2215384586650 : Closed e2215384586650 ∧ code e2215384586650 = 11011477608858 := by decide
theorem cert_e2215384586650 : check e2215384586650 [[]] .width = true := by decide
def e2215384760518 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2215384760518 : Closed e2215384760518 ∧ code e2215384760518 = 11011477782726 := by decide
theorem cert_e2215384760518 : check e2215384760518 [[]] .width = true := by decide
def e2215384817690 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2215384817690 : Closed e2215384817690 ∧ code e2215384817690 = 11011477839898 := by decide
theorem cert_e2215384817690 : check e2215384817690 [[]] .width = true := by decide
def e2215384817782 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2215384817782 : Closed e2215384817782 ∧ code e2215384817782 = 11011477839990 := by decide
theorem cert_e2215384817782 : check e2215384817782 [[]] .width = true := by decide
def e2215384818026 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2215384818026 : Closed e2215384818026 ∧ code e2215384818026 = 11011477840234 := by decide
theorem cert_e2215384818026 : check e2215384818026 [[]] .width = true := by decide
def e2215384818074 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2215384818074 : Closed e2215384818074 ∧ code e2215384818074 = 11011477840282 := by decide
theorem cert_e2215384818074 : check e2215384818074 [[]] .width = true := by decide
def e2215384823834 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215384823834 : Closed e2215384823834 ∧ code e2215384823834 = 11011477846042 := by decide
theorem cert_e2215384823834 : check e2215384823834 [[]] .width = true := by decide
def e2215384836122 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215384836122 : Closed e2215384836122 ∧ code e2215384836122 = 11011477858330 := by decide
theorem cert_e2215384836122 : check e2215384836122 [[]] .width = true := by decide
def e2215384842266 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2215384842266 : Closed e2215384842266 ∧ code e2215384842266 = 11011477864474 := by decide
theorem cert_e2215384842266 : check e2215384842266 [[]] .width = true := by decide
def e2215384842358 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2215384842358 : Closed e2215384842358 ∧ code e2215384842358 = 11011477864566 := by decide
theorem cert_e2215384842358 : check e2215384842358 [[]] .width = true := by decide
def e2215384842602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2215384842602 : Closed e2215384842602 ∧ code e2215384842602 = 11011477864810 := by decide
theorem cert_e2215384842602 : check e2215384842602 [[]] .width = true := by decide
def e2215384842650 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2215384842650 : Closed e2215384842650 ∧ code e2215384842650 = 11011477864858 := by decide
theorem cert_e2215384842650 : check e2215384842650 [[]] .width = true := by decide
def e2215384842734 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2215384842734 : Closed e2215384842734 ∧ code e2215384842734 = 11011477864942 := by decide
theorem cert_e2215384842734 : check e2215384842734 [[]] .width = true := by decide
def e2215384843658 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2215384843658 : Closed e2215384843658 ∧ code e2215384843658 = 11011477865866 := by decide
theorem cert_e2215384843658 : check e2215384843658 [[]] .width = true := by decide
def e2215384843682 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2215384843682 : Closed e2215384843682 ∧ code e2215384843682 = 11011477865890 := by decide
theorem cert_e2215384843682 : check e2215384843682 [[]] .width = true := by decide
def e2215384843702 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2215384843702 : Closed e2215384843702 ∧ code e2215384843702 = 11011477865910 := by decide
theorem cert_e2215384843702 : check e2215384843702 [[]] .width = true := by decide
def e2215384843734 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2215384843734 : Closed e2215384843734 ∧ code e2215384843734 = 11011477865942 := by decide
theorem cert_e2215384843734 : check e2215384843734 [[]] .width = true := by decide
def e2215384843738 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2215384843738 : Closed e2215384843738 ∧ code e2215384843738 = 11011477865946 := by decide
theorem cert_e2215384843738 : check e2215384843738 [[]] .width = true := by decide
def e2215384843790 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2215384843790 : Closed e2215384843790 ∧ code e2215384843790 = 11011477865998 := by decide
theorem cert_e2215384843790 : check e2215384843790 [[]] .width = true := by decide
def e2215384843802 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2215384843802 : Closed e2215384843802 ∧ code e2215384843802 = 11011477866010 := by decide
theorem cert_e2215384843802 : check e2215384843802 [[]] .width = true := by decide
def e2215384843874 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2215384843874 : Closed e2215384843874 ∧ code e2215384843874 = 11011477866082 := by decide
theorem cert_e2215384843874 : check e2215384843874 [[]] .width = true := by decide
def e2215384843894 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2215384843894 : Closed e2215384843894 ∧ code e2215384843894 = 11011477866102 := by decide
theorem cert_e2215384843894 : check e2215384843894 [[]] .width = true := by decide
def e2215384844086 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2215384844086 : Closed e2215384844086 ∧ code e2215384844086 = 11011477866294 := by decide
theorem cert_e2215384844086 : check e2215384844086 [[]] .width = true := by decide
def e2215384844090 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2215384844090 : Closed e2215384844090 ∧ code e2215384844090 = 11011477866298 := by decide
theorem cert_e2215384844090 : check e2215384844090 [[]] .width = true := by decide
def e2215384847786 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2215384847786 : Closed e2215384847786 ∧ code e2215384847786 = 11011477869994 := by decide
theorem cert_e2215384847786 : check e2215384847786 [[]] .width = true := by decide
def e2215384847882 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2215384847882 : Closed e2215384847882 ∧ code e2215384847882 = 11011477870090 := by decide
theorem cert_e2215384847882 : check e2215384847882 [[]] .width = true := by decide
def e2215384847978 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2215384847978 : Closed e2215384847978 ∧ code e2215384847978 = 11011477870186 := by decide
theorem cert_e2215384847978 : check e2215384847978 [[]] .width = true := by decide
def e2215384848002 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2215384848002 : Closed e2215384848002 ∧ code e2215384848002 = 11011477870210 := by decide
theorem cert_e2215384848002 : check e2215384848002 [[]] .width = true := by decide
def e2215384848026 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2215384848026 : Closed e2215384848026 ∧ code e2215384848026 = 11011477870234 := by decide
theorem cert_e2215384848026 : check e2215384848026 [[]] .width = true := by decide
def e2215384848410 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2215384848410 : Closed e2215384848410 ∧ code e2215384848410 = 11011477870618 := by decide
theorem cert_e2215384848410 : check e2215384848410 [[]] .width = true := by decide
def e2215384848502 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2215384848502 : Closed e2215384848502 ∧ code e2215384848502 = 11011477870710 := by decide
theorem cert_e2215384848502 : check e2215384848502 [[]] .width = true := by decide
def e2215384848746 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2215384848746 : Closed e2215384848746 ∧ code e2215384848746 = 11011477870954 := by decide
theorem cert_e2215384848746 : check e2215384848746 [[]] .width = true := by decide
def e2215384848770 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2215384848770 : Closed e2215384848770 ∧ code e2215384848770 = 11011477870978 := by decide
theorem cert_e2215384848770 : check e2215384848770 [[]] .width = true := by decide
def e2215384848794 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2215384848794 : Closed e2215384848794 ∧ code e2215384848794 = 11011477871002 := by decide
theorem cert_e2215384848794 : check e2215384848794 [[]] .width = true := by decide
def e2215385028634 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215385028634 : Closed e2215385028634 ∧ code e2215385028634 = 11011478050842 := by decide
theorem cert_e2215385028634 : check e2215385028634 [[]] .width = true := by decide
def e2215385032730 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2215385032730 : Closed e2215385032730 ∧ code e2215385032730 = 11011478054938 := by decide
theorem cert_e2215385032730 : check e2215385032730 [[]] .width = true := by decide
def e2215599189358 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2215599189358 : Closed e2215599189358 ∧ code e2215599189358 = 11011692211566 := by decide
theorem cert_e2215599189358 : check e2215599189358 [[],[.under,.under]] .smaller = true := by decide
def e2215599189366 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2215599189366 : Closed e2215599189366 ∧ code e2215599189366 = 11011692211574 := by decide
theorem cert_e2215599189366 : check e2215599189366 [[],[.under,.under]] .smaller = true := by decide
def e2215599189422 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2215599189422 : Closed e2215599189422 ∧ code e2215599189422 = 11011692211630 := by decide
theorem cert_e2215599189422 : check e2215599189422 [[],[.under,.under]] .smaller = true := by decide
def e2215599189434 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2215599189434 : Closed e2215599189434 ∧ code e2215599189434 = 11011692211642 := by decide
theorem cert_e2215599189434 : check e2215599189434 [[],[.under,.under]] .smaller = true := by decide
def e2215599189462 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2215599189462 : Closed e2215599189462 ∧ code e2215599189462 = 11011692211670 := by decide
theorem cert_e2215599189462 : check e2215599189462 [[],[.under,.under]] .smaller = true := by decide
def e2215599189466 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2215599189466 : Closed e2215599189466 ∧ code e2215599189466 = 11011692211674 := by decide
theorem cert_e2215599189466 : check e2215599189466 [[],[.under,.under]] .smaller = true := by decide
def e2215599189678 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2215599189678 : Closed e2215599189678 ∧ code e2215599189678 = 11011692211886 := by decide
theorem cert_e2215599189678 : check e2215599189678 [[],[.under,.under]] .smaller = true := by decide
def e2215599189690 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2215599189690 : Closed e2215599189690 ∧ code e2215599189690 = 11011692211898 := by decide
theorem cert_e2215599189690 : check e2215599189690 [[],[.under,.under]] .smaller = true := by decide
def e2215599189738 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2215599189738 : Closed e2215599189738 ∧ code e2215599189738 = 11011692211946 := by decide
theorem cert_e2215599189738 : check e2215599189738 [[],[.under,.under]] .smaller = true := by decide
def e2215599189846 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2215599189846 : Closed e2215599189846 ∧ code e2215599189846 = 11011692212054 := by decide
theorem cert_e2215599189846 : check e2215599189846 [[],[.under,.under]] .smaller = true := by decide
def e2215599189850 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2215599189850 : Closed e2215599189850 ∧ code e2215599189850 = 11011692212058 := by decide
theorem cert_e2215599189850 : check e2215599189850 [[],[.under,.under]] .smaller = true := by decide
def e2215599189866 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2215599189866 : Closed e2215599189866 ∧ code e2215599189866 = 11011692212074 := by decide
theorem cert_e2215599189866 : check e2215599189866 [[],[.under,.under]] .smaller = true := by decide
def e2215599190894 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2215599190894 : Closed e2215599190894 ∧ code e2215599190894 = 11011692213102 := by decide
theorem cert_e2215599190894 : check e2215599190894 [[],[.under,.under]] .smaller = true := by decide
def e2215599190902 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2215599190902 : Closed e2215599190902 ∧ code e2215599190902 = 11011692213110 := by decide
theorem cert_e2215599190902 : check e2215599190902 [[],[.under,.under]] .smaller = true := by decide
def e2215599190958 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2215599190958 : Closed e2215599190958 ∧ code e2215599190958 = 11011692213166 := by decide
theorem cert_e2215599190958 : check e2215599190958 [[],[.under,.under]] .smaller = true := by decide
def e2215599190970 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2215599190970 : Closed e2215599190970 ∧ code e2215599190970 = 11011692213178 := by decide
theorem cert_e2215599190970 : check e2215599190970 [[],[.under,.under]] .smaller = true := by decide
def e2215599190998 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2215599190998 : Closed e2215599190998 ∧ code e2215599190998 = 11011692213206 := by decide
theorem cert_e2215599190998 : check e2215599190998 [[],[.under,.under]] .smaller = true := by decide
def e2215599191002 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2215599191002 : Closed e2215599191002 ∧ code e2215599191002 = 11011692213210 := by decide
theorem cert_e2215599191002 : check e2215599191002 [[],[.under,.under]] .smaller = true := by decide
def e2215599191278 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2215599191278 : Closed e2215599191278 ∧ code e2215599191278 = 11011692213486 := by decide
theorem cert_e2215599191278 : check e2215599191278 [[],[.under,.under]] .smaller = true := by decide
def e2215599191286 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2215599191286 : Closed e2215599191286 ∧ code e2215599191286 = 11011692213494 := by decide
theorem cert_e2215599191286 : check e2215599191286 [[],[.under,.under]] .smaller = true := by decide
def e2215599191662 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2215599191662 : Closed e2215599191662 ∧ code e2215599191662 = 11011692213870 := by decide
theorem cert_e2215599191662 : check e2215599191662 [[],[.under,.under]] .smaller = true := by decide
def e2215599191674 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2215599191674 : Closed e2215599191674 ∧ code e2215599191674 = 11011692213882 := by decide
theorem cert_e2215599191674 : check e2215599191674 [[],[.under,.under]] .smaller = true := by decide
def e2215599191862 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2215599191862 : Closed e2215599191862 ∧ code e2215599191862 = 11011692214070 := by decide
theorem cert_e2215599191862 : check e2215599191862 [[],[.under,.under]] .smaller = true := by decide
def e2215599191866 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2215599191866 : Closed e2215599191866 ∧ code e2215599191866 = 11011692214074 := by decide
theorem cert_e2215599191866 : check e2215599191866 [[],[.under,.under]] .smaller = true := by decide
def e2215599192494 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2215599192494 : Closed e2215599192494 ∧ code e2215599192494 = 11011692214702 := by decide
theorem cert_e2215599192494 : check e2215599192494 [[],[.under,.under]] .smaller = true := by decide
def e2215599192506 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2215599192506 : Closed e2215599192506 ∧ code e2215599192506 = 11011692214714 := by decide
theorem cert_e2215599192506 : check e2215599192506 [[],[.under,.under]] .smaller = true := by decide
def e2215599192554 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2215599192554 : Closed e2215599192554 ∧ code e2215599192554 = 11011692214762 := by decide
theorem cert_e2215599192554 : check e2215599192554 [[],[.under,.under]] .smaller = true := by decide
def e2215599192686 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2215599192686 : Closed e2215599192686 ∧ code e2215599192686 = 11011692214894 := by decide
theorem cert_e2215599192686 : check e2215599192686 [[],[.under,.under]] .smaller = true := by decide
def e2215599192698 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2215599192698 : Closed e2215599192698 ∧ code e2215599192698 = 11011692214906 := by decide
theorem cert_e2215599192698 : check e2215599192698 [[],[.under,.under]] .smaller = true := by decide
def e2215599192986 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2215599192986 : Closed e2215599192986 ∧ code e2215599192986 = 11011692215194 := by decide
theorem cert_e2215599192986 : check e2215599192986 [[],[.under,.under]] .smaller = true := by decide
def e2215599193302 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2215599193302 : Closed e2215599193302 ∧ code e2215599193302 = 11011692215510 := by decide
theorem cert_e2215599193302 : check e2215599193302 [[],[.under,.under]] .smaller = true := by decide
def e2215599193306 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2215599193306 : Closed e2215599193306 ∧ code e2215599193306 = 11011692215514 := by decide
theorem cert_e2215599193306 : check e2215599193306 [[],[.under,.under]] .smaller = true := by decide
def e2215599193322 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2215599193322 : Closed e2215599193322 ∧ code e2215599193322 = 11011692215530 := by decide
theorem cert_e2215599193322 : check e2215599193322 [[],[.under,.under]] .smaller = true := by decide
def e2215599193398 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2215599193398 : Closed e2215599193398 ∧ code e2215599193398 = 11011692215606 := by decide
theorem cert_e2215599193398 : check e2215599193398 [[],[.under,.under]] .smaller = true := by decide
def e2215599193402 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2215599193402 : Closed e2215599193402 ∧ code e2215599193402 = 11011692215610 := by decide
theorem cert_e2215599193402 : check e2215599193402 [[],[.under,.under]] .smaller = true := by decide
def e2215599193498 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2215599193498 : Closed e2215599193498 ∧ code e2215599193498 = 11011692215706 := by decide
theorem cert_e2215599193498 : check e2215599193498 [[],[.under,.under]] .smaller = true := by decide
def e2215599197038 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2215599197038 : Closed e2215599197038 ∧ code e2215599197038 = 11011692219246 := by decide
theorem cert_e2215599197038 : check e2215599197038 [[],[.under,.under]] .smaller = true := by decide
def e2215599197046 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2215599197046 : Closed e2215599197046 ∧ code e2215599197046 = 11011692219254 := by decide
theorem cert_e2215599197046 : check e2215599197046 [[],[.under,.under]] .smaller = true := by decide
def e2215599197102 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2215599197102 : Closed e2215599197102 ∧ code e2215599197102 = 11011692219310 := by decide
theorem cert_e2215599197102 : check e2215599197102 [[],[.under,.under]] .smaller = true := by decide
def e2215599197114 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2215599197114 : Closed e2215599197114 ∧ code e2215599197114 = 11011692219322 := by decide
theorem cert_e2215599197114 : check e2215599197114 [[],[.under,.under]] .smaller = true := by decide
def e2215599197142 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2215599197142 : Closed e2215599197142 ∧ code e2215599197142 = 11011692219350 := by decide
theorem cert_e2215599197142 : check e2215599197142 [[],[.under,.under]] .smaller = true := by decide
def e2215599197146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2215599197146 : Closed e2215599197146 ∧ code e2215599197146 = 11011692219354 := by decide
theorem cert_e2215599197146 : check e2215599197146 [[],[.under,.under]] .smaller = true := by decide
def e2215599197422 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2215599197422 : Closed e2215599197422 ∧ code e2215599197422 = 11011692219630 := by decide
theorem cert_e2215599197422 : check e2215599197422 [[],[.under,.under]] .smaller = true := by decide
def e2215599197430 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2215599197430 : Closed e2215599197430 ∧ code e2215599197430 = 11011692219638 := by decide
theorem cert_e2215599197430 : check e2215599197430 [[],[.under,.under]] .smaller = true := by decide
def e2215599197806 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2215599197806 : Closed e2215599197806 ∧ code e2215599197806 = 11011692220014 := by decide
theorem cert_e2215599197806 : check e2215599197806 [[],[.under,.under]] .smaller = true := by decide
def e2215599197818 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2215599197818 : Closed e2215599197818 ∧ code e2215599197818 = 11011692220026 := by decide
theorem cert_e2215599197818 : check e2215599197818 [[],[.under,.under]] .smaller = true := by decide
def e2215599198006 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2215599198006 : Closed e2215599198006 ∧ code e2215599198006 = 11011692220214 := by decide
theorem cert_e2215599198006 : check e2215599198006 [[],[.under,.under]] .smaller = true := by decide
def e2215599198010 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2215599198010 : Closed e2215599198010 ∧ code e2215599198010 = 11011692220218 := by decide
theorem cert_e2215599198010 : check e2215599198010 [[],[.under,.under]] .smaller = true := by decide
def e2215599203758 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2215599203758 : Closed e2215599203758 ∧ code e2215599203758 = 11011692225966 := by decide
theorem cert_e2215599203758 : check e2215599203758 [[],[.under,.under]] .smaller = true := by decide
def e2215599203770 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2215599203770 : Closed e2215599203770 ∧ code e2215599203770 = 11011692225978 := by decide
theorem cert_e2215599203770 : check e2215599203770 [[],[.under,.under]] .smaller = true := by decide
def e2215599203818 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2215599203818 : Closed e2215599203818 ∧ code e2215599203818 = 11011692226026 := by decide
theorem cert_e2215599203818 : check e2215599203818 [[],[.under,.under]] .smaller = true := by decide
def e2215599203950 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2215599203950 : Closed e2215599203950 ∧ code e2215599203950 = 11011692226158 := by decide
theorem cert_e2215599203950 : check e2215599203950 [[],[.under,.under]] .smaller = true := by decide
def e2215599203962 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2215599203962 : Closed e2215599203962 ∧ code e2215599203962 = 11011692226170 := by decide
theorem cert_e2215599203962 : check e2215599203962 [[],[.under,.under]] .smaller = true := by decide
def e2215599204250 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2215599204250 : Closed e2215599204250 ∧ code e2215599204250 = 11011692226458 := by decide
theorem cert_e2215599204250 : check e2215599204250 [[],[.under,.under]] .smaller = true := by decide
def e2215599207126 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2215599207126 : Closed e2215599207126 ∧ code e2215599207126 = 11011692229334 := by decide
theorem cert_e2215599207126 : check e2215599207126 [[],[.under,.under]] .smaller = true := by decide
def e2215599207130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2215599207130 : Closed e2215599207130 ∧ code e2215599207130 = 11011692229338 := by decide
theorem cert_e2215599207130 : check e2215599207130 [[],[.under,.under]] .smaller = true := by decide
def e2215599207146 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2215599207146 : Closed e2215599207146 ∧ code e2215599207146 = 11011692229354 := by decide
theorem cert_e2215599207146 : check e2215599207146 [[],[.under,.under]] .smaller = true := by decide
def e2215599207222 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2215599207222 : Closed e2215599207222 ∧ code e2215599207222 = 11011692229430 := by decide
theorem cert_e2215599207222 : check e2215599207222 [[],[.under,.under]] .smaller = true := by decide
def e2215599207226 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2215599207226 : Closed e2215599207226 ∧ code e2215599207226 = 11011692229434 := by decide
theorem cert_e2215599207226 : check e2215599207226 [[],[.under,.under]] .smaller = true := by decide
def e2215599207322 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2215599207322 : Closed e2215599207322 ∧ code e2215599207322 = 11011692229530 := by decide
theorem cert_e2215599207322 : check e2215599207322 [[],[.under,.under]] .smaller = true := by decide
def e2215599322862 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2215599322862 : Closed e2215599322862 ∧ code e2215599322862 = 11011692345070 := by decide
theorem cert_e2215599322862 : check e2215599322862 [[],[.under,.under]] .three = true := by decide
def e2215599322990 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2215599322990 : Closed e2215599322990 ∧ code e2215599322990 = 11011692345198 := by decide
theorem cert_e2215599322990 : check e2215599322990 [[],[.under,.under]] .three = true := by decide
def e2215599322998 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2215599322998 : Closed e2215599322998 ∧ code e2215599322998 = 11011692345206 := by decide
theorem cert_e2215599322998 : check e2215599322998 [[],[.under,.under]] .three = true := by decide
def e2215599323886 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2215599323886 : Closed e2215599323886 ∧ code e2215599323886 = 11011692346094 := by decide
theorem cert_e2215599323886 : check e2215599323886 [[],[.under,.under]] .three = true := by decide
def e2215599324078 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2215599324078 : Closed e2215599324078 ∧ code e2215599324078 = 11011692346286 := by decide
theorem cert_e2215599324078 : check e2215599324078 [[],[.under,.under]] .three = true := by decide
def e2215599324090 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2215599324090 : Closed e2215599324090 ∧ code e2215599324090 = 11011692346298 := by decide
theorem cert_e2215599324090 : check e2215599324090 [[],[.under,.under]] .three = true := by decide
def e2215599324526 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2215599324526 : Closed e2215599324526 ∧ code e2215599324526 = 11011692346734 := by decide
theorem cert_e2215599324526 : check e2215599324526 [[],[.under,.under]] .three = true := by decide
def e2215599324534 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2215599324534 : Closed e2215599324534 ∧ code e2215599324534 = 11011692346742 := by decide
theorem cert_e2215599324534 : check e2215599324534 [[],[.under,.under]] .three = true := by decide
def e2215599324590 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2215599324590 : Closed e2215599324590 ∧ code e2215599324590 = 11011692346798 := by decide
theorem cert_e2215599324590 : check e2215599324590 [[],[.under,.under]] .three = true := by decide
def e2215599324602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2215599324602 : Closed e2215599324602 ∧ code e2215599324602 = 11011692346810 := by decide
theorem cert_e2215599324602 : check e2215599324602 [[],[.under,.under]] .three = true := by decide
def e2215599324630 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2215599324630 : Closed e2215599324630 ∧ code e2215599324630 = 11011692346838 := by decide
private def t_e2215599324630 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2215599324630 : ¬ IsSelfInterpreter e2215599324630 :=
  wSource (t := t_e2215599324630) (replay_sound (ps := []) (t := e2215599324630) (by decide)) (by decide)
def e2215599324634 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2215599324634 : Closed e2215599324634 ∧ code e2215599324634 = 11011692346842 := by decide
private def t_e2215599324634 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2215599324634 : ¬ IsSelfInterpreter e2215599324634 :=
  wSource (t := t_e2215599324634) (replay_sound (ps := []) (t := e2215599324634) (by decide)) (by decide)
def e2215599329006 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2215599329006 : Closed e2215599329006 ∧ code e2215599329006 = 11011692351214 := by decide
theorem cert_e2215599329006 : check e2215599329006 [[],[.under,.under]] .three = true := by decide
def e2215599329134 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2215599329134 : Closed e2215599329134 ∧ code e2215599329134 = 11011692351342 := by decide
theorem cert_e2215599329134 : check e2215599329134 [[],[.under,.under]] .three = true := by decide
def e2215599329142 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2215599329142 : Closed e2215599329142 ∧ code e2215599329142 = 11011692351350 := by decide
theorem cert_e2215599329142 : check e2215599329142 [[],[.under,.under]] .three = true := by decide
def e2215599331822 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2215599331822 : Closed e2215599331822 ∧ code e2215599331822 = 11011692354030 := by decide
theorem cert_e2215599331822 : check e2215599331822 [[],[.under,.under]] .three = true := by decide
def e2215599332590 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2215599332590 : Closed e2215599332590 ∧ code e2215599332590 = 11011692354798 := by decide
theorem cert_e2215599332590 : check e2215599332590 [[],[.under,.under]] .three = true := by decide
def e2215599332598 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2215599332598 : Closed e2215599332598 ∧ code e2215599332598 = 11011692354806 := by decide
theorem cert_e2215599332598 : check e2215599332598 [[],[.under,.under]] .three = true := by decide
def e2215599335150 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2215599335150 : Closed e2215599335150 ∧ code e2215599335150 = 11011692357358 := by decide
theorem cert_e2215599335150 : check e2215599335150 [[],[.under,.under]] .three = true := by decide
def e2215599335342 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2215599335342 : Closed e2215599335342 ∧ code e2215599335342 = 11011692357550 := by decide
theorem cert_e2215599335342 : check e2215599335342 [[],[.under,.under]] .three = true := by decide
def e2215599335354 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2215599335354 : Closed e2215599335354 ∧ code e2215599335354 = 11011692357562 := by decide
theorem cert_e2215599335354 : check e2215599335354 [[],[.under,.under]] .three = true := by decide
def e2215599335918 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2215599335918 : Closed e2215599335918 ∧ code e2215599335918 = 11011692358126 := by decide
theorem cert_e2215599335918 : check e2215599335918 [[],[.under,.under]] .three = true := by decide
def e2215599337070 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2215599337070 : Closed e2215599337070 ∧ code e2215599337070 = 11011692359278 := by decide
theorem cert_e2215599337070 : check e2215599337070 [[],[.under,.under]] .three = true := by decide
def e2215599337082 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2215599337082 : Closed e2215599337082 ∧ code e2215599337082 = 11011692359290 := by decide
theorem cert_e2215599337082 : check e2215599337082 [[],[.under,.under]] .three = true := by decide
def e2215599338350 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2215599338350 : Closed e2215599338350 ∧ code e2215599338350 = 11011692360558 := by decide
theorem cert_e2215599338350 : check e2215599338350 [[],[.under,.under]] .three = true := by decide
def e2215599338358 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2215599338358 : Closed e2215599338358 ∧ code e2215599338358 = 11011692360566 := by decide
theorem cert_e2215599338358 : check e2215599338358 [[],[.under,.under]] .three = true := by decide
def e2215599338414 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2215599338414 : Closed e2215599338414 ∧ code e2215599338414 = 11011692360622 := by decide
theorem cert_e2215599338414 : check e2215599338414 [[],[.under,.under]] .three = true := by decide
def e2215599338426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2215599338426 : Closed e2215599338426 ∧ code e2215599338426 = 11011692360634 := by decide
theorem cert_e2215599338426 : check e2215599338426 [[],[.under,.under]] .three = true := by decide
def e2215599338454 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2215599338454 : Closed e2215599338454 ∧ code e2215599338454 = 11011692360662 := by decide
theorem cert_e2215599338454 : check e2215599338454 [[],[.under,.under]] .three = true := by decide
def e2215599338458 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2215599338458 : Closed e2215599338458 ∧ code e2215599338458 = 11011692360666 := by decide
theorem cert_e2215599338458 : check e2215599338458 [[],[.under,.under]] .three = true := by decide
def e2215599338734 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2215599338734 : Closed e2215599338734 ∧ code e2215599338734 = 11011692360942 := by decide
theorem cert_e2215599338734 : check e2215599338734 [[],[.under,.under]] .three = true := by decide
def e2215599338742 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2215599338742 : Closed e2215599338742 ∧ code e2215599338742 = 11011692360950 := by decide
theorem cert_e2215599338742 : check e2215599338742 [[],[.under,.under]] .three = true := by decide
def e2215599339118 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2215599339118 : Closed e2215599339118 ∧ code e2215599339118 = 11011692361326 := by decide
theorem cert_e2215599339118 : check e2215599339118 [[],[.under,.under]] .three = true := by decide
def e2215599339130 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2215599339130 : Closed e2215599339130 ∧ code e2215599339130 = 11011692361338 := by decide
theorem cert_e2215599339130 : check e2215599339130 [[],[.under,.under]] .three = true := by decide
def e2215599339318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2215599339318 : Closed e2215599339318 ∧ code e2215599339318 = 11011692361526 := by decide
private def t_e2215599339318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2215599339318 : ¬ IsSelfInterpreter e2215599339318 :=
  wSource (t := t_e2215599339318) (replay_sound (ps := []) (t := e2215599339318) (by decide)) (by decide)
def e2215599339322 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2215599339322 : Closed e2215599339322 ∧ code e2215599339322 = 11011692361530 := by decide
private def t_e2215599339322 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2215599339322 : ¬ IsSelfInterpreter e2215599339322 :=
  wSource (t := t_e2215599339322) (replay_sound (ps := []) (t := e2215599339322) (by decide)) (by decide)
def e2215599344494 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2215599344494 : Closed e2215599344494 ∧ code e2215599344494 = 11011692366702 := by decide
theorem cert_e2215599344494 : check e2215599344494 [[],[.under,.under]] .smaller = true := by decide
def e2215599344502 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2215599344502 : Closed e2215599344502 ∧ code e2215599344502 = 11011692366710 := by decide
theorem cert_e2215599344502 : check e2215599344502 [[],[.under,.under]] .smaller = true := by decide
def e2215599344558 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2215599344558 : Closed e2215599344558 ∧ code e2215599344558 = 11011692366766 := by decide
theorem cert_e2215599344558 : check e2215599344558 [[],[.under,.under]] .smaller = true := by decide
def e2215599344570 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2215599344570 : Closed e2215599344570 ∧ code e2215599344570 = 11011692366778 := by decide
theorem cert_e2215599344570 : check e2215599344570 [[],[.under,.under]] .smaller = true := by decide
def e2215599344598 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2215599344598 : Closed e2215599344598 ∧ code e2215599344598 = 11011692366806 := by decide
theorem cert_e2215599344598 : check e2215599344598 [[],[.under,.under]] .smaller = true := by decide
def e2215599344602 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2215599344602 : Closed e2215599344602 ∧ code e2215599344602 = 11011692366810 := by decide
theorem cert_e2215599344602 : check e2215599344602 [[],[.under,.under]] .smaller = true := by decide
def e2215599344878 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2215599344878 : Closed e2215599344878 ∧ code e2215599344878 = 11011692367086 := by decide
theorem cert_e2215599344878 : check e2215599344878 [[],[.under,.under]] .smaller = true := by decide
def e2215599344886 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2215599344886 : Closed e2215599344886 ∧ code e2215599344886 = 11011692367094 := by decide
theorem cert_e2215599344886 : check e2215599344886 [[],[.under,.under]] .smaller = true := by decide
def e2215599345262 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2215599345262 : Closed e2215599345262 ∧ code e2215599345262 = 11011692367470 := by decide
theorem cert_e2215599345262 : check e2215599345262 [[],[.under,.under]] .smaller = true := by decide
def e2215599345274 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2215599345274 : Closed e2215599345274 ∧ code e2215599345274 = 11011692367482 := by decide
theorem cert_e2215599345274 : check e2215599345274 [[],[.under,.under]] .smaller = true := by decide
def e2215599345462 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2215599345462 : Closed e2215599345462 ∧ code e2215599345462 = 11011692367670 := by decide
theorem cert_e2215599345462 : check e2215599345462 [[],[.under,.under]] .smaller = true := by decide
def e2215599345466 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2215599345466 : Closed e2215599345466 ∧ code e2215599345466 = 11011692367674 := by decide
theorem cert_e2215599345466 : check e2215599345466 [[],[.under,.under]] .smaller = true := by decide
def e2215599353582 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2215599353582 : Closed e2215599353582 ∧ code e2215599353582 = 11011692375790 := by decide
theorem cert_e2215599353582 : check e2215599353582 [[],[.under,.under]] .three = true := by decide
def e2215599353710 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2215599353710 : Closed e2215599353710 ∧ code e2215599353710 = 11011692375918 := by decide
theorem cert_e2215599353710 : check e2215599353710 [[],[.under,.under]] .three = true := by decide
def e2215599353718 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2215599353718 : Closed e2215599353718 ∧ code e2215599353718 = 11011692375926 := by decide
theorem cert_e2215599353718 : check e2215599353718 [[],[.under,.under]] .three = true := by decide
def e2215599356398 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2215599356398 : Closed e2215599356398 ∧ code e2215599356398 = 11011692378606 := by decide
theorem cert_e2215599356398 : check e2215599356398 [[],[.under,.under]] .three = true := by decide
def e2215599357166 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2215599357166 : Closed e2215599357166 ∧ code e2215599357166 = 11011692379374 := by decide
theorem cert_e2215599357166 : check e2215599357166 [[],[.under,.under]] .three = true := by decide
def e2215599357174 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2215599357174 : Closed e2215599357174 ∧ code e2215599357174 = 11011692379382 := by decide
theorem cert_e2215599357174 : check e2215599357174 [[],[.under,.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2215599324630
#print axioms Blc.Floor43.cert_e2215599324634
#print axioms Blc.Floor43.cert_e2215599339318
#print axioms Blc.Floor43.cert_e2215599339322
