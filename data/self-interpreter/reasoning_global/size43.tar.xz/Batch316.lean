import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411649399918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411649399918 : Closed e2411649399918 ∧ code e2411649399918 = 11207742422126 := by decide
theorem cert_e2411649399918 : check e2411649399918 [[],[]] .chain = true := by decide
def e2411649399930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411649399930 : Closed e2411649399930 ∧ code e2411649399930 = 11207742422138 := by decide
theorem cert_e2411649399930 : check e2411649399930 [[],[]] .chain = true := by decide
def e2411649400022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411649400022 : Closed e2411649400022 ∧ code e2411649400022 = 11207742422230 := by decide
theorem cert_e2411649400022 : check e2411649400022 [[],[]] .chain = true := by decide
def e2411649400026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411649400026 : Closed e2411649400026 ∧ code e2411649400026 = 11207742422234 := by decide
theorem cert_e2411649400026 : check e2411649400026 [[],[]] .chain = true := by decide
def e2411649400042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411649400042 : Closed e2411649400042 ∧ code e2411649400042 = 11207742422250 := by decide
theorem cert_e2411649400042 : check e2411649400042 [[],[]] .chain = true := by decide
def e2411649400094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411649400094 : Closed e2411649400094 ∧ code e2411649400094 = 11207742422302 := by decide
theorem cert_e2411649400094 : check e2411649400094 [[],[]] .chain = true := by decide
def e2411649400118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411649400118 : Closed e2411649400118 ∧ code e2411649400118 = 11207742422326 := by decide
theorem cert_e2411649400118 : check e2411649400118 [[],[]] .chain = true := by decide
def e2411649400122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411649400122 : Closed e2411649400122 ∧ code e2411649400122 = 11207742422330 := by decide
theorem cert_e2411649400122 : check e2411649400122 [[],[]] .chain = true := by decide
def e2411649400218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411649400218 : Closed e2411649400218 ∧ code e2411649400218 = 11207742422426 := by decide
theorem cert_e2411649400218 : check e2411649400218 [[],[]] .chain = true := by decide
def e2411649400262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411649400262 : Closed e2411649400262 ∧ code e2411649400262 = 11207742422470 := by decide
theorem cert_e2411649400262 : check e2411649400262 [[],[]] .chain = true := by decide
def e2411649406686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411649406686 : Closed e2411649406686 ∧ code e2411649406686 = 11207742428894 := by decide
theorem cert_e2411649406686 : check e2411649406686 [[],[]] .chain = true := by decide
def e2411649406710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411649406710 : Closed e2411649406710 ∧ code e2411649406710 = 11207742428918 := by decide
theorem cert_e2411649406710 : check e2411649406710 [[],[]] .chain = true := by decide
def e2411649406814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411649406814 : Closed e2411649406814 ∧ code e2411649406814 = 11207742429022 := by decide
theorem cert_e2411649406814 : check e2411649406814 [[],[]] .chain = true := by decide
def e2411649406830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2411649406830 : Closed e2411649406830 ∧ code e2411649406830 = 11207742429038 := by decide
theorem cert_e2411649406830 : check e2411649406830 [[],[]] .smaller = true := by decide
def e2411649406838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2411649406838 : Closed e2411649406838 ∧ code e2411649406838 = 11207742429046 := by decide
theorem cert_e2411649406838 : check e2411649406838 [[],[]] .smaller = true := by decide
def e2411649406842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411649406842 : Closed e2411649406842 ∧ code e2411649406842 = 11207742429050 := by decide
theorem cert_e2411649406842 : check e2411649406842 [[],[]] .chain = true := by decide
def e2411649406902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2411649406902 : Closed e2411649406902 ∧ code e2411649406902 = 11207742429110 := by decide
theorem cert_e2411649406902 : check e2411649406902 [[],[]] .smaller = true := by decide
def e2411649406934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411649406934 : Closed e2411649406934 ∧ code e2411649406934 = 11207742429142 := by decide
theorem cert_e2411649406934 : check e2411649406934 [[],[]] .chain = true := by decide
def e2411649406938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411649406938 : Closed e2411649406938 ∧ code e2411649406938 = 11207742429146 := by decide
theorem cert_e2411649406938 : check e2411649406938 [[],[]] .chain = true := by decide
def e2411649407454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411649407454 : Closed e2411649407454 ∧ code e2411649407454 = 11207742429662 := by decide
theorem cert_e2411649407454 : check e2411649407454 [[],[]] .chain = true := by decide
def e2411649407478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411649407478 : Closed e2411649407478 ∧ code e2411649407478 = 11207742429686 := by decide
theorem cert_e2411649407478 : check e2411649407478 [[],[]] .chain = true := by decide
def e2411649408222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411649408222 : Closed e2411649408222 ∧ code e2411649408222 = 11207742430430 := by decide
theorem cert_e2411649408222 : check e2411649408222 [[],[]] .chain = true := by decide
def e2411649408238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411649408238 : Closed e2411649408238 ∧ code e2411649408238 = 11207742430446 := by decide
theorem cert_e2411649408238 : check e2411649408238 [[],[]] .smaller = true := by decide
def e2411649408246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411649408246 : Closed e2411649408246 ∧ code e2411649408246 = 11207742430454 := by decide
theorem cert_e2411649408246 : check e2411649408246 [[],[]] .smaller = true := by decide
def e2411649408250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411649408250 : Closed e2411649408250 ∧ code e2411649408250 = 11207742430458 := by decide
theorem cert_e2411649408250 : check e2411649408250 [[],[]] .chain = true := by decide
def e2411649408574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2411649408574 : Closed e2411649408574 ∧ code e2411649408574 = 11207742430782 := by decide
theorem cert_e2411649408574 : check e2411649408574 [[],[]] .chain = true := by decide
def e2411649408630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411649408630 : Closed e2411649408630 ∧ code e2411649408630 = 11207742430838 := by decide
theorem cert_e2411649408630 : check e2411649408630 [[],[]] .smaller = true := by decide
def e2411649408798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2411649408798 : Closed e2411649408798 ∧ code e2411649408798 = 11207742431006 := by decide
theorem cert_e2411649408798 : check e2411649408798 [[],[]] .chain = true := by decide
def e2411649408822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649408822 : Closed e2411649408822 ∧ code e2411649408822 = 11207742431030 := by decide
theorem cert_e2411649408822 : check e2411649408822 [[],[]] .chain = true := by decide
def e2411649408826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649408826 : Closed e2411649408826 ∧ code e2411649408826 = 11207742431034 := by decide
theorem cert_e2411649408826 : check e2411649408826 [[],[]] .chain = true := by decide
def e2411649420126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e2411649420126 : Closed e2411649420126 ∧ code e2411649420126 = 11207742442334 := by decide
theorem cert_e2411649420126 : check e2411649420126 [[],[]] .chain = true := by decide
def e2411649420142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411649420142 : Closed e2411649420142 ∧ code e2411649420142 = 11207742442350 := by decide
theorem cert_e2411649420142 : check e2411649420142 [[],[]] .smaller = true := by decide
def e2411649420150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411649420150 : Closed e2411649420150 ∧ code e2411649420150 = 11207742442358 := by decide
theorem cert_e2411649420150 : check e2411649420150 [[],[]] .smaller = true := by decide
def e2411649420154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e2411649420154 : Closed e2411649420154 ∧ code e2411649420154 = 11207742442362 := by decide
theorem cert_e2411649420154 : check e2411649420154 [[],[]] .chain = true := by decide
def e2411649420206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411649420206 : Closed e2411649420206 ∧ code e2411649420206 = 11207742442414 := by decide
theorem cert_e2411649420206 : check e2411649420206 [[],[]] .smaller = true := by decide
def e2411649420218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411649420218 : Closed e2411649420218 ∧ code e2411649420218 = 11207742442426 := by decide
theorem cert_e2411649420218 : check e2411649420218 [[],[]] .smaller = true := by decide
def e2411649420246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411649420246 : Closed e2411649420246 ∧ code e2411649420246 = 11207742442454 := by decide
theorem cert_e2411649420246 : check e2411649420246 [[],[]] .smaller = true := by decide
def e2411649420250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411649420250 : Closed e2411649420250 ∧ code e2411649420250 = 11207742442458 := by decide
theorem cert_e2411649420250 : check e2411649420250 [[],[]] .smaller = true := by decide
def e2411649420266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e2411649420266 : Closed e2411649420266 ∧ code e2411649420266 = 11207742442474 := by decide
theorem cert_e2411649420266 : check e2411649420266 [[],[]] .chain = true := by decide
def e2411649420510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411649420510 : Closed e2411649420510 ∧ code e2411649420510 = 11207742442718 := by decide
theorem cert_e2411649420510 : check e2411649420510 [[],[]] .chain = true := by decide
def e2411649420526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411649420526 : Closed e2411649420526 ∧ code e2411649420526 = 11207742442734 := by decide
theorem cert_e2411649420526 : check e2411649420526 [[],[]] .smaller = true := by decide
def e2411649420534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411649420534 : Closed e2411649420534 ∧ code e2411649420534 = 11207742442742 := by decide
theorem cert_e2411649420534 : check e2411649420534 [[],[]] .smaller = true := by decide
def e2411649420538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411649420538 : Closed e2411649420538 ∧ code e2411649420538 = 11207742442746 := by decide
theorem cert_e2411649420538 : check e2411649420538 [[],[]] .chain = true := by decide
def e2411649420910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411649420910 : Closed e2411649420910 ∧ code e2411649420910 = 11207742443118 := by decide
theorem cert_e2411649420910 : check e2411649420910 [[],[]] .smaller = true := by decide
def e2411649420922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411649420922 : Closed e2411649420922 ∧ code e2411649420922 = 11207742443130 := by decide
theorem cert_e2411649420922 : check e2411649420922 [[],[]] .smaller = true := by decide
def e2411649421110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649421110 : Closed e2411649421110 ∧ code e2411649421110 = 11207742443318 := by decide
theorem cert_e2411649421110 : check e2411649421110 [[],[]] .smaller = true := by decide
def e2411649421114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649421114 : Closed e2411649421114 ∧ code e2411649421114 = 11207742443322 := by decide
theorem cert_e2411649421114 : check e2411649421114 [[],[]] .smaller = true := by decide
def e2411649421210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411649421210 : Closed e2411649421210 ∧ code e2411649421210 = 11207742443418 := by decide
theorem cert_e2411649421210 : check e2411649421210 [[],[]] .chain = true := by decide
def e2411649426870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2411649426870 : Closed e2411649426870 ∧ code e2411649426870 = 11207742449078 := by decide
theorem cert_e2411649426870 : check e2411649426870 [[],[]] .smaller = true := by decide
def e2411649426902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2411649426902 : Closed e2411649426902 ∧ code e2411649426902 = 11207742449110 := by decide
theorem cert_e2411649426902 : check e2411649426902 [[],[]] .smaller = true := by decide
def e2411649426906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2411649426906 : Closed e2411649426906 ∧ code e2411649426906 = 11207742449114 := by decide
theorem cert_e2411649426906 : check e2411649426906 [[],[]] .smaller = true := by decide
def e2411649427006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2411649427006 : Closed e2411649427006 ∧ code e2411649427006 = 11207742449214 := by decide
theorem cert_e2411649427006 : check e2411649427006 [[],[]] .chain = true := by decide
def e2411649427062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411649427062 : Closed e2411649427062 ∧ code e2411649427062 = 11207742449270 := by decide
theorem cert_e2411649427062 : check e2411649427062 [[],[]] .smaller = true := by decide
def e2411649427254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649427254 : Closed e2411649427254 ∧ code e2411649427254 = 11207742449462 := by decide
theorem cert_e2411649427254 : check e2411649427254 [[],[]] .smaller = true := by decide
def e2411649427258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649427258 : Closed e2411649427258 ∧ code e2411649427258 = 11207742449466 := by decide
theorem cert_e2411649427258 : check e2411649427258 [[],[]] .smaller = true := by decide
def e2411649427398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2411649427398 : Closed e2411649427398 ∧ code e2411649427398 = 11207742449606 := by decide
theorem cert_e2411649427398 : check e2411649427398 [[],[]] .chain = true := by decide
def e2411649430230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411649430230 : Closed e2411649430230 ∧ code e2411649430230 = 11207742452438 := by decide
theorem cert_e2411649430230 : check e2411649430230 [[],[]] .chain = true := by decide
def e2411649430234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411649430234 : Closed e2411649430234 ∧ code e2411649430234 = 11207742452442 := by decide
theorem cert_e2411649430234 : check e2411649430234 [[],[]] .chain = true := by decide
def e2411649430250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411649430250 : Closed e2411649430250 ∧ code e2411649430250 = 11207742452458 := by decide
theorem cert_e2411649430250 : check e2411649430250 [[],[]] .chain = true := by decide
def e2411649430302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411649430302 : Closed e2411649430302 ∧ code e2411649430302 = 11207742452510 := by decide
theorem cert_e2411649430302 : check e2411649430302 [[],[]] .chain = true := by decide
def e2411649430326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649430326 : Closed e2411649430326 ∧ code e2411649430326 = 11207742452534 := by decide
theorem cert_e2411649430326 : check e2411649430326 [[],[]] .chain = true := by decide
def e2411649430330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649430330 : Closed e2411649430330 ∧ code e2411649430330 = 11207742452538 := by decide
theorem cert_e2411649430330 : check e2411649430330 [[],[]] .chain = true := by decide
def e2411649430426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411649430426 : Closed e2411649430426 ∧ code e2411649430426 = 11207742452634 := by decide
theorem cert_e2411649430426 : check e2411649430426 [[],[]] .chain = true := by decide
def e2411649430470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411649430470 : Closed e2411649430470 ∧ code e2411649430470 = 11207742452678 := by decide
theorem cert_e2411649430470 : check e2411649430470 [[],[]] .chain = true := by decide
def e2411649655662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2411649655662 : Closed e2411649655662 ∧ code e2411649655662 = 11207742677870 := by decide
theorem cert_e2411649655662 : check e2411649655662 [[],[]] .chain = true := by decide
def e2411649655670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2411649655670 : Closed e2411649655670 ∧ code e2411649655670 = 11207742677878 := by decide
theorem cert_e2411649655670 : check e2411649655670 [[],[]] .chain = true := by decide
def e2411649655726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2411649655726 : Closed e2411649655726 ∧ code e2411649655726 = 11207742677934 := by decide
theorem cert_e2411649655726 : check e2411649655726 [[],[]] .chain = true := by decide
def e2411649655738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2411649655738 : Closed e2411649655738 ∧ code e2411649655738 = 11207742677946 := by decide
theorem cert_e2411649655738 : check e2411649655738 [[],[]] .chain = true := by decide
def e2411649655766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2411649655766 : Closed e2411649655766 ∧ code e2411649655766 = 11207742677974 := by decide
theorem cert_e2411649655766 : check e2411649655766 [[],[]] .chain = true := by decide
def e2411649655770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2411649655770 : Closed e2411649655770 ∧ code e2411649655770 = 11207742677978 := by decide
theorem cert_e2411649655770 : check e2411649655770 [[],[]] .chain = true := by decide
def e2411649657070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411649657070 : Closed e2411649657070 ∧ code e2411649657070 = 11207742679278 := by decide
theorem cert_e2411649657070 : check e2411649657070 [[],[]] .chain = true := by decide
def e2411649657078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411649657078 : Closed e2411649657078 ∧ code e2411649657078 = 11207742679286 := by decide
theorem cert_e2411649657078 : check e2411649657078 [[],[]] .chain = true := by decide
def e2411649657630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411649657630 : Closed e2411649657630 ∧ code e2411649657630 = 11207742679838 := by decide
theorem cert_e2411649657630 : check e2411649657630 [[],[]] .chain = true := by decide
def e2411649657742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411649657742 : Closed e2411649657742 ∧ code e2411649657742 = 11207742679950 := by decide
theorem cert_e2411649657742 : check e2411649657742 [[],[]] .chain = true := by decide
def e2411649657966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411649657966 : Closed e2411649657966 ∧ code e2411649657966 = 11207742680174 := by decide
theorem cert_e2411649657966 : check e2411649657966 [[],[]] .chain = true := by decide
def e2411649657978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411649657978 : Closed e2411649657978 ∧ code e2411649657978 = 11207742680186 := by decide
theorem cert_e2411649657978 : check e2411649657978 [[],[]] .chain = true := by decide
def e2411649658142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411649658142 : Closed e2411649658142 ∧ code e2411649658142 = 11207742680350 := by decide
theorem cert_e2411649658142 : check e2411649658142 [[],[]] .chain = true := by decide
def e2411649658310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411649658310 : Closed e2411649658310 ∧ code e2411649658310 = 11207742680518 := by decide
theorem cert_e2411649658310 : check e2411649658310 [[],[]] .chain = true := by decide
def e2411649658422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411649658422 : Closed e2411649658422 ∧ code e2411649658422 = 11207742680630 := by decide
theorem cert_e2411649658422 : check e2411649658422 [[],[]] .chain = true := by decide
def e2411649658426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411649658426 : Closed e2411649658426 ∧ code e2411649658426 = 11207742680634 := by decide
theorem cert_e2411649658426 : check e2411649658426 [[],[]] .chain = true := by decide
def e2411649658510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411649658510 : Closed e2411649658510 ∧ code e2411649658510 = 11207742680718 := by decide
theorem cert_e2411649658510 : check e2411649658510 [[],[]] .chain = true := by decide
def e2411649658566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411649658566 : Closed e2411649658566 ∧ code e2411649658566 = 11207742680774 := by decide
theorem cert_e2411649658566 : check e2411649658566 [[],[]] .chain = true := by decide
def e2411649659310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2411649659310 : Closed e2411649659310 ∧ code e2411649659310 = 11207742681518 := by decide
theorem cert_e2411649659310 : check e2411649659310 [[],[]] .chain = true := by decide
def e2411649659322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2411649659322 : Closed e2411649659322 ∧ code e2411649659322 = 11207742681530 := by decide
theorem cert_e2411649659322 : check e2411649659322 [[],[]] .chain = true := by decide
def e2411649659370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e2411649659370 : Closed e2411649659370 ∧ code e2411649659370 = 11207742681578 := by decide
theorem cert_e2411649659370 : check e2411649659370 [[],[]] .chain = true := by decide
def e2411649660014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411649660014 : Closed e2411649660014 ∧ code e2411649660014 = 11207742682222 := by decide
theorem cert_e2411649660014 : check e2411649660014 [[],[]] .chain = true := by decide
def e2411649660026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411649660026 : Closed e2411649660026 ∧ code e2411649660026 = 11207742682234 := by decide
theorem cert_e2411649660026 : check e2411649660026 [[],[]] .chain = true := by decide
def e2411649660190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411649660190 : Closed e2411649660190 ∧ code e2411649660190 = 11207742682398 := by decide
theorem cert_e2411649660190 : check e2411649660190 [[],[]] .chain = true := by decide
def e2411649660358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411649660358 : Closed e2411649660358 ∧ code e2411649660358 = 11207742682566 := by decide
theorem cert_e2411649660358 : check e2411649660358 [[],[]] .chain = true := by decide
def e2411649660698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411649660698 : Closed e2411649660698 ∧ code e2411649660698 = 11207742682906 := by decide
theorem cert_e2411649660698 : check e2411649660698 [[],[]] .chain = true := by decide
def e2411649660742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411649660742 : Closed e2411649660742 ∧ code e2411649660742 = 11207742682950 := by decide
theorem cert_e2411649660742 : check e2411649660742 [[],[]] .chain = true := by decide
def e2411649661142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2411649661142 : Closed e2411649661142 ∧ code e2411649661142 = 11207742683350 := by decide
theorem cert_e2411649661142 : check e2411649661142 [[],[]] .chain = true := by decide
def e2411649661146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2411649661146 : Closed e2411649661146 ∧ code e2411649661146 = 11207742683354 := by decide
theorem cert_e2411649661146 : check e2411649661146 [[],[]] .chain = true := by decide
def e2411649661162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2411649661162 : Closed e2411649661162 ∧ code e2411649661162 = 11207742683370 := by decide
theorem cert_e2411649661162 : check e2411649661162 [[],[]] .chain = true := by decide
def e2411649661494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411649661494 : Closed e2411649661494 ∧ code e2411649661494 = 11207742683702 := by decide
theorem cert_e2411649661494 : check e2411649661494 [[],[]] .chain = true := by decide
def e2411649661498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411649661498 : Closed e2411649661498 ∧ code e2411649661498 = 11207742683706 := by decide
theorem cert_e2411649661498 : check e2411649661498 [[],[]] .chain = true := by decide
def e2411649661582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411649661582 : Closed e2411649661582 ∧ code e2411649661582 = 11207742683790 := by decide
theorem cert_e2411649661582 : check e2411649661582 [[],[]] .chain = true := by decide
def e2411649661638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411649661638 : Closed e2411649661638 ∧ code e2411649661638 = 11207742683846 := by decide
theorem cert_e2411649661638 : check e2411649661638 [[],[]] .chain = true := by decide
def e2411649661722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411649661722 : Closed e2411649661722 ∧ code e2411649661722 = 11207742683930 := by decide
theorem cert_e2411649661722 : check e2411649661722 [[],[]] .chain = true := by decide
def e2411649661766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411649661766 : Closed e2411649661766 ∧ code e2411649661766 = 11207742683974 := by decide
theorem cert_e2411649661766 : check e2411649661766 [[],[]] .chain = true := by decide
def e2411649664750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2411649664750 : Closed e2411649664750 ∧ code e2411649664750 = 11207742686958 := by decide
theorem cert_e2411649664750 : check e2411649664750 [[],[]] .chain = true := by decide
def e2411649664758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2411649664758 : Closed e2411649664758 ∧ code e2411649664758 = 11207742686966 := by decide
theorem cert_e2411649664758 : check e2411649664758 [[],[]] .chain = true := by decide
def e2411649664942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2411649664942 : Closed e2411649664942 ∧ code e2411649664942 = 11207742687150 := by decide
theorem cert_e2411649664942 : check e2411649664942 [[],[]] .chain = true := by decide
def e2411649664982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2411649664982 : Closed e2411649664982 ∧ code e2411649664982 = 11207742687190 := by decide
theorem cert_e2411649664982 : check e2411649664982 [[],[]] .chain = true := by decide
def e2411649666286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2411649666286 : Closed e2411649666286 ∧ code e2411649666286 = 11207742688494 := by decide
theorem cert_e2411649666286 : check e2411649666286 [[],[]] .chain = true := by decide
def e2411649666294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2411649666294 : Closed e2411649666294 ∧ code e2411649666294 = 11207742688502 := by decide
theorem cert_e2411649666294 : check e2411649666294 [[],[]] .chain = true := by decide
def e2411649666670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411649666670 : Closed e2411649666670 ∧ code e2411649666670 = 11207742688878 := by decide
theorem cert_e2411649666670 : check e2411649666670 [[],[]] .chain = true := by decide
def e2411649666682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411649666682 : Closed e2411649666682 ∧ code e2411649666682 = 11207742688890 := by decide
theorem cert_e2411649666682 : check e2411649666682 [[],[]] .chain = true := by decide
def e2411649666870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411649666870 : Closed e2411649666870 ∧ code e2411649666870 = 11207742689078 := by decide
theorem cert_e2411649666870 : check e2411649666870 [[],[]] .chain = true := by decide
def e2411649666874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411649666874 : Closed e2411649666874 ∧ code e2411649666874 = 11207742689082 := by decide
theorem cert_e2411649666874 : check e2411649666874 [[],[]] .chain = true := by decide
def e2411649669358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2411649669358 : Closed e2411649669358 ∧ code e2411649669358 = 11207742691566 := by decide
theorem cert_e2411649669358 : check e2411649669358 [[],[]] .chain = true := by decide
def e2411649669366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2411649669366 : Closed e2411649669366 ∧ code e2411649669366 = 11207742691574 := by decide
theorem cert_e2411649669366 : check e2411649669366 [[],[]] .chain = true := by decide
def e2411649669918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2411649669918 : Closed e2411649669918 ∧ code e2411649669918 = 11207742692126 := by decide
theorem cert_e2411649669918 : check e2411649669918 [[],[]] .chain = true := by decide
def e2411649670030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2411649670030 : Closed e2411649670030 ∧ code e2411649670030 = 11207742692238 := by decide
theorem cert_e2411649670030 : check e2411649670030 [[],[]] .chain = true := by decide
def e2411649670254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411649670254 : Closed e2411649670254 ∧ code e2411649670254 = 11207742692462 := by decide
theorem cert_e2411649670254 : check e2411649670254 [[],[]] .chain = true := by decide
def e2411649670266 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411649670266 : Closed e2411649670266 ∧ code e2411649670266 = 11207742692474 := by decide
theorem cert_e2411649670266 : check e2411649670266 [[],[]] .chain = true := by decide
def e2411649670430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411649670430 : Closed e2411649670430 ∧ code e2411649670430 = 11207742692638 := by decide
theorem cert_e2411649670430 : check e2411649670430 [[],[]] .chain = true := by decide
def e2411649670598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411649670598 : Closed e2411649670598 ∧ code e2411649670598 = 11207742692806 := by decide
theorem cert_e2411649670598 : check e2411649670598 [[],[]] .chain = true := by decide
def e2411649670710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411649670710 : Closed e2411649670710 ∧ code e2411649670710 = 11207742692918 := by decide
theorem cert_e2411649670710 : check e2411649670710 [[],[]] .chain = true := by decide
def e2411649670714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411649670714 : Closed e2411649670714 ∧ code e2411649670714 = 11207742692922 := by decide
theorem cert_e2411649670714 : check e2411649670714 [[],[]] .chain = true := by decide
def e2411649670798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411649670798 : Closed e2411649670798 ∧ code e2411649670798 = 11207742693006 := by decide
theorem cert_e2411649670798 : check e2411649670798 [[],[]] .chain = true := by decide
def e2411649670854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411649670854 : Closed e2411649670854 ∧ code e2411649670854 = 11207742693062 := by decide
theorem cert_e2411649670854 : check e2411649670854 [[],[]] .chain = true := by decide
def e2411649672990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411649672990 : Closed e2411649672990 ∧ code e2411649672990 = 11207742695198 := by decide
theorem cert_e2411649672990 : check e2411649672990 [[],[]] .chain = true := by decide
def e2411649673102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411649673102 : Closed e2411649673102 ∧ code e2411649673102 = 11207742695310 := by decide
theorem cert_e2411649673102 : check e2411649673102 [[],[]] .chain = true := by decide
def e2411649675486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411649675486 : Closed e2411649675486 ∧ code e2411649675486 = 11207742697694 := by decide
theorem cert_e2411649675486 : check e2411649675486 [[],[]] .chain = true := by decide
def e2411649675514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411649675514 : Closed e2411649675514 ∧ code e2411649675514 = 11207742697722 := by decide
theorem cert_e2411649675514 : check e2411649675514 [[],[]] .chain = true := by decide
def e2411649676062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411649676062 : Closed e2411649676062 ∧ code e2411649676062 = 11207742698270 := by decide
theorem cert_e2411649676062 : check e2411649676062 [[],[]] .chain = true := by decide
def e2411649676230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411649676230 : Closed e2411649676230 ∧ code e2411649676230 = 11207742698438 := by decide
theorem cert_e2411649676230 : check e2411649676230 [[],[]] .chain = true := by decide
def e2411649677422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411649677422 : Closed e2411649677422 ∧ code e2411649677422 = 11207742699630 := by decide
theorem cert_e2411649677422 : check e2411649677422 [[],[]] .chain = true := by decide
def e2411649677434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411649677434 : Closed e2411649677434 ∧ code e2411649677434 = 11207742699642 := by decide
theorem cert_e2411649677434 : check e2411649677434 [[],[]] .chain = true := by decide
def e2411649677710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411649677710 : Closed e2411649677710 ∧ code e2411649677710 = 11207742699918 := by decide
theorem cert_e2411649677710 : check e2411649677710 [[],[]] .chain = true := by decide
def e2411649677766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411649677766 : Closed e2411649677766 ∧ code e2411649677766 = 11207742699974 := by decide
theorem cert_e2411649677766 : check e2411649677766 [[],[]] .chain = true := by decide
def e2411649680238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2411649680238 : Closed e2411649680238 ∧ code e2411649680238 = 11207742702446 := by decide
theorem cert_e2411649680238 : check e2411649680238 [[],[]] .chain = true := by decide
def e2411649680250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2411649680250 : Closed e2411649680250 ∧ code e2411649680250 = 11207742702458 := by decide
theorem cert_e2411649680250 : check e2411649680250 [[],[]] .chain = true := by decide
def e2411649680302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2411649680302 : Closed e2411649680302 ∧ code e2411649680302 = 11207742702510 := by decide
theorem cert_e2411649680302 : check e2411649680302 [[],[]] .chain = true := by decide
def e2411649680362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2411649680362 : Closed e2411649680362 ∧ code e2411649680362 = 11207742702570 := by decide
theorem cert_e2411649680362 : check e2411649680362 [[],[]] .chain = true := by decide
def e2411649681006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2411649681006 : Closed e2411649681006 ∧ code e2411649681006 = 11207742703214 := by decide
theorem cert_e2411649681006 : check e2411649681006 [[],[]] .chain = true := by decide
def e2411649681018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2411649681018 : Closed e2411649681018 ∧ code e2411649681018 = 11207742703226 := by decide
theorem cert_e2411649681018 : check e2411649681018 [[],[]] .chain = true := by decide
def e2411649681306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411649681306 : Closed e2411649681306 ∧ code e2411649681306 = 11207742703514 := by decide
theorem cert_e2411649681306 : check e2411649681306 [[],[]] .chain = true := by decide
def e2411649682542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2411649682542 : Closed e2411649682542 ∧ code e2411649682542 = 11207742704750 := by decide
theorem cert_e2411649682542 : check e2411649682542 [[],[]] .chain = true := by decide
def e2411649682554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2411649682554 : Closed e2411649682554 ∧ code e2411649682554 = 11207742704762 := by decide
theorem cert_e2411649682554 : check e2411649682554 [[],[]] .chain = true := by decide
def e2411649682718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2411649682718 : Closed e2411649682718 ∧ code e2411649682718 = 11207742704926 := by decide
theorem cert_e2411649682718 : check e2411649682718 [[],[]] .chain = true := by decide
def e2411649682886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2411649682886 : Closed e2411649682886 ∧ code e2411649682886 = 11207742705094 := by decide
theorem cert_e2411649682886 : check e2411649682886 [[],[]] .chain = true := by decide
def e2411649683226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411649683226 : Closed e2411649683226 ∧ code e2411649683226 = 11207742705434 := by decide
theorem cert_e2411649683226 : check e2411649683226 [[],[]] .chain = true := by decide
def e2411649683270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411649683270 : Closed e2411649683270 ∧ code e2411649683270 = 11207742705478 := by decide
theorem cert_e2411649683270 : check e2411649683270 [[],[]] .chain = true := by decide
def e2411649683678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411649683678 : Closed e2411649683678 ∧ code e2411649683678 = 11207742705886 := by decide
theorem cert_e2411649683678 : check e2411649683678 [[],[]] .chain = true := by decide
def e2411649683706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411649683706 : Closed e2411649683706 ∧ code e2411649683706 = 11207742705914 := by decide
theorem cert_e2411649683706 : check e2411649683706 [[],[]] .chain = true := by decide
def e2411649684254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411649684254 : Closed e2411649684254 ∧ code e2411649684254 = 11207742706462 := by decide
theorem cert_e2411649684254 : check e2411649684254 [[],[]] .chain = true := by decide
def e2411649684422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411649684422 : Closed e2411649684422 ∧ code e2411649684422 = 11207742706630 := by decide
theorem cert_e2411649684422 : check e2411649684422 [[],[]] .chain = true := by decide
def e2411649686582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411649686582 : Closed e2411649686582 ∧ code e2411649686582 = 11207742708790 := by decide
theorem cert_e2411649686582 : check e2411649686582 [[],[]] .chain = true := by decide
def e2411649686586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411649686586 : Closed e2411649686586 ∧ code e2411649686586 = 11207742708794 := by decide
theorem cert_e2411649686586 : check e2411649686586 [[],[]] .chain = true := by decide
def e2411649686726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411649686726 : Closed e2411649686726 ∧ code e2411649686726 = 11207742708934 := by decide
theorem cert_e2411649686726 : check e2411649686726 [[],[]] .chain = true := by decide
def e2411649687990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2411649687990 : Closed e2411649687990 ∧ code e2411649687990 = 11207742710198 := by decide
theorem cert_e2411649687990 : check e2411649687990 [[],[]] .chain = true := by decide
def e2411649687994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2411649687994 : Closed e2411649687994 ∧ code e2411649687994 = 11207742710202 := by decide
theorem cert_e2411649687994 : check e2411649687994 [[],[]] .chain = true := by decide
def e2411649688022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2411649688022 : Closed e2411649688022 ∧ code e2411649688022 = 11207742710230 := by decide
theorem cert_e2411649688022 : check e2411649688022 [[],[]] .chain = true := by decide
def e2411649688042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2411649688042 : Closed e2411649688042 ∧ code e2411649688042 = 11207742710250 := by decide
theorem cert_e2411649688042 : check e2411649688042 [[],[]] .chain = true := by decide
def e2411649688374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2411649688374 : Closed e2411649688374 ∧ code e2411649688374 = 11207742710582 := by decide
theorem cert_e2411649688374 : check e2411649688374 [[],[]] .chain = true := by decide
def e2411649688378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2411649688378 : Closed e2411649688378 ∧ code e2411649688378 = 11207742710586 := by decide
theorem cert_e2411649688378 : check e2411649688378 [[],[]] .chain = true := by decide
def e2411649688474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2411649688474 : Closed e2411649688474 ∧ code e2411649688474 = 11207742710682 := by decide
theorem cert_e2411649688474 : check e2411649688474 [[],[]] .chain = true := by decide
def e2411649689142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2411649689142 : Closed e2411649689142 ∧ code e2411649689142 = 11207742711350 := by decide
theorem cert_e2411649689142 : check e2411649689142 [[],[]] .chain = true := by decide
end Blc.Floor43
