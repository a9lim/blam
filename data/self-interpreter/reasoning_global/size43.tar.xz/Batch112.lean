import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e871890136602 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890136602 : Closed e871890136602 ∧ code e871890136602 = 9667983158810 := by decide
theorem cert_e871890136602 : check e871890136602 [] .sourceHead = true := by decide
def e871890139674 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890139674 : Closed e871890139674 ∧ code e871890139674 = 9667983161882 := by decide
theorem cert_e871890139674 : check e871890139674 [] .sourceHead = true := by decide
def e871890146842 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890146842 : Closed e871890146842 ∧ code e871890146842 = 9667983169050 := by decide
theorem cert_e871890146842 : check e871890146842 [] .sourceHead = true := by decide
def e871890147866 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890147866 : Closed e871890147866 ∧ code e871890147866 = 9667983170074 := by decide
theorem cert_e871890147866 : check e871890147866 [] .sourceHead = true := by decide
def e871890218522 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890218522 : Closed e871890218522 ∧ code e871890218522 = 9667983240730 := by decide
theorem cert_e871890218522 : check e871890218522 [] .sourceHead = true := by decide
def e871890220570 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890220570 : Closed e871890220570 ∧ code e871890220570 = 9667983242778 := by decide
theorem cert_e871890220570 : check e871890220570 [] .sourceHead = true := by decide
def e871890316826 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890316826 : Closed e871890316826 ∧ code e871890316826 = 9667983339034 := by decide
theorem cert_e871890316826 : check e871890316826 [] .sourceHead = true := by decide
def e871890319898 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890319898 : Closed e871890319898 ∧ code e871890319898 = 9667983342106 := by decide
theorem cert_e871890319898 : check e871890319898 [] .sourceHead = true := by decide
def e871890368026 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890368026 : Closed e871890368026 ∧ code e871890368026 = 9667983390234 := by decide
theorem cert_e871890368026 : check e871890368026 [] .sourceHead = true := by decide
def e871890369050 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890369050 : Closed e871890369050 ∧ code e871890369050 = 9667983391258 := by decide
theorem cert_e871890369050 : check e871890369050 [] .sourceHead = true := by decide
def e871890529818 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890529818 : Closed e871890529818 ∧ code e871890529818 = 9667983552026 := by decide
theorem cert_e871890529818 : check e871890529818 [] .sourceHead = true := by decide
def e871890532890 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890532890 : Closed e871890532890 ∧ code e871890532890 = 9667983555098 := by decide
theorem cert_e871890532890 : check e871890532890 [] .sourceHead = true := by decide
def e871890545178 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890545178 : Closed e871890545178 ∧ code e871890545178 = 9667983567386 := by decide
theorem cert_e871890545178 : check e871890545178 [] .sourceHead = true := by decide
def e871890578970 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890578970 : Closed e871890578970 ∧ code e871890578970 = 9667983601178 := by decide
theorem cert_e871890578970 : check e871890578970 [] .sourceHead = true := by decide
def e871890582042 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890582042 : Closed e871890582042 ∧ code e871890582042 = 9667983604250 := by decide
theorem cert_e871890582042 : check e871890582042 [] .sourceHead = true := by decide
def e871890655770 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890655770 : Closed e871890655770 ∧ code e871890655770 = 9667983677978 := by decide
theorem cert_e871890655770 : check e871890655770 [] .sourceHead = true := by decide
def e871890736666 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890736666 : Closed e871890736666 ∧ code e871890736666 = 9667983758874 := by decide
theorem cert_e871890736666 : check e871890736666 [] .sourceHead = true := by decide
def e871890737690 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890737690 : Closed e871890737690 ∧ code e871890737690 = 9667983759898 := by decide
theorem cert_e871890737690 : check e871890737690 [] .sourceHead = true := by decide
def e871890741786 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890741786 : Closed e871890741786 ∧ code e871890741786 = 9667983763994 := by decide
theorem cert_e871890741786 : check e871890741786 [] .sourceHead = true := by decide
def e871890761242 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890761242 : Closed e871890761242 ∧ code e871890761242 = 9667983783450 := by decide
theorem cert_e871890761242 : check e871890761242 [] .sourceHead = true := by decide
def e871890762266 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890762266 : Closed e871890762266 ∧ code e871890762266 = 9667983784474 := by decide
theorem cert_e871890762266 : check e871890762266 [] .sourceHead = true := by decide
def e871890786842 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871890786842 : Closed e871890786842 ∧ code e871890786842 = 9667983809050 := by decide
theorem cert_e871890786842 : check e871890786842 [] .sourceHead = true := by decide
def e871891693082 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891693082 : Closed e871891693082 ∧ code e871891693082 = 9667984715290 := by decide
theorem cert_e871891693082 : check e871891693082 [] .sourceHead = true := by decide
def e871891695130 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891695130 : Closed e871891695130 ∧ code e871891695130 = 9667984717338 := by decide
theorem cert_e871891695130 : check e871891695130 [] .sourceHead = true := by decide
def e871891709466 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891709466 : Closed e871891709466 ∧ code e871891709466 = 9667984731674 := by decide
theorem cert_e871891709466 : check e871891709466 [] .sourceHead = true := by decide
def e871891712538 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891712538 : Closed e871891712538 ∧ code e871891712538 = 9667984734746 := by decide
theorem cert_e871891712538 : check e871891712538 [] .sourceHead = true := by decide
def e871891719706 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891719706 : Closed e871891719706 ∧ code e871891719706 = 9667984741914 := by decide
theorem cert_e871891719706 : check e871891719706 [] .sourceHead = true := by decide
def e871891720730 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891720730 : Closed e871891720730 ∧ code e871891720730 = 9667984742938 := by decide
theorem cert_e871891720730 : check e871891720730 [] .sourceHead = true := by decide
def e871891791386 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891791386 : Closed e871891791386 ∧ code e871891791386 = 9667984813594 := by decide
theorem cert_e871891791386 : check e871891791386 [] .sourceHead = true := by decide
def e871891793434 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891793434 : Closed e871891793434 ∧ code e871891793434 = 9667984815642 := by decide
theorem cert_e871891793434 : check e871891793434 [] .sourceHead = true := by decide
def e871891889690 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891889690 : Closed e871891889690 ∧ code e871891889690 = 9667984911898 := by decide
theorem cert_e871891889690 : check e871891889690 [] .sourceHead = true := by decide
def e871891892762 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891892762 : Closed e871891892762 ∧ code e871891892762 = 9667984914970 := by decide
theorem cert_e871891892762 : check e871891892762 [] .sourceHead = true := by decide
def e871891940890 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891940890 : Closed e871891940890 ∧ code e871891940890 = 9667984963098 := by decide
theorem cert_e871891940890 : check e871891940890 [] .sourceHead = true := by decide
def e871891941914 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871891941914 : Closed e871891941914 ∧ code e871891941914 = 9667984964122 := by decide
theorem cert_e871891941914 : check e871891941914 [] .sourceHead = true := by decide
def e871893413402 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871893413402 : Closed e871893413402 ∧ code e871893413402 = 9667986435610 := by decide
theorem cert_e871893413402 : check e871893413402 [] .sourceHead = true := by decide
def e871893416474 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871893416474 : Closed e871893416474 ∧ code e871893416474 = 9667986438682 := by decide
theorem cert_e871893416474 : check e871893416474 [] .sourceHead = true := by decide
def e871893428762 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871893428762 : Closed e871893428762 ∧ code e871893428762 = 9667986450970 := by decide
theorem cert_e871893428762 : check e871893428762 [] .sourceHead = true := by decide
def e871893462554 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871893462554 : Closed e871893462554 ∧ code e871893462554 = 9667986484762 := by decide
theorem cert_e871893462554 : check e871893462554 [] .sourceHead = true := by decide
def e871893465626 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871893465626 : Closed e871893465626 ∧ code e871893465626 = 9667986487834 := by decide
theorem cert_e871893465626 : check e871893465626 [] .sourceHead = true := by decide
def e871893539354 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871893539354 : Closed e871893539354 ∧ code e871893539354 = 9667986561562 := by decide
theorem cert_e871893539354 : check e871893539354 [] .sourceHead = true := by decide
def e871894275610 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871894275610 : Closed e871894275610 ∧ code e871894275610 = 9667987297818 := by decide
theorem cert_e871894275610 : check e871894275610 [] .sourceHead = true := by decide
def e871894276634 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871894276634 : Closed e871894276634 ∧ code e871894276634 = 9667987298842 := by decide
theorem cert_e871894276634 : check e871894276634 [] .sourceHead = true := by decide
def e871894280730 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871894280730 : Closed e871894280730 ∧ code e871894280730 = 9667987302938 := by decide
theorem cert_e871894280730 : check e871894280730 [] .sourceHead = true := by decide
def e871894300186 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871894300186 : Closed e871894300186 ∧ code e871894300186 = 9667987322394 := by decide
theorem cert_e871894300186 : check e871894300186 [] .sourceHead = true := by decide
def e871894301210 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871894301210 : Closed e871894301210 ∧ code e871894301210 = 9667987323418 := by decide
theorem cert_e871894301210 : check e871894301210 [] .sourceHead = true := by decide
def e871894325786 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871894325786 : Closed e871894325786 ∧ code e871894325786 = 9667987347994 := by decide
theorem cert_e871894325786 : check e871894325786 [] .sourceHead = true := by decide
def e871929441818 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929441818 : Closed e871929441818 ∧ code e871929441818 = 9668022464026 := by decide
theorem cert_e871929441818 : check e871929441818 [] .sourceHead = true := by decide
def e871929443866 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929443866 : Closed e871929443866 ∧ code e871929443866 = 9668022466074 := by decide
theorem cert_e871929443866 : check e871929443866 [] .sourceHead = true := by decide
def e871929458202 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929458202 : Closed e871929458202 ∧ code e871929458202 = 9668022480410 := by decide
theorem cert_e871929458202 : check e871929458202 [] .sourceHead = true := by decide
def e871929461274 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929461274 : Closed e871929461274 ∧ code e871929461274 = 9668022483482 := by decide
theorem cert_e871929461274 : check e871929461274 [] .sourceHead = true := by decide
def e871929468442 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929468442 : Closed e871929468442 ∧ code e871929468442 = 9668022490650 := by decide
theorem cert_e871929468442 : check e871929468442 [] .sourceHead = true := by decide
def e871929469466 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929469466 : Closed e871929469466 ∧ code e871929469466 = 9668022491674 := by decide
theorem cert_e871929469466 : check e871929469466 [] .sourceHead = true := by decide
def e871929540122 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929540122 : Closed e871929540122 ∧ code e871929540122 = 9668022562330 := by decide
theorem cert_e871929540122 : check e871929540122 [] .sourceHead = true := by decide
def e871929542170 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929542170 : Closed e871929542170 ∧ code e871929542170 = 9668022564378 := by decide
theorem cert_e871929542170 : check e871929542170 [] .sourceHead = true := by decide
def e871929638426 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929638426 : Closed e871929638426 ∧ code e871929638426 = 9668022660634 := by decide
theorem cert_e871929638426 : check e871929638426 [] .sourceHead = true := by decide
def e871929641498 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929641498 : Closed e871929641498 ∧ code e871929641498 = 9668022663706 := by decide
theorem cert_e871929641498 : check e871929641498 [] .sourceHead = true := by decide
def e871929689626 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929689626 : Closed e871929689626 ∧ code e871929689626 = 9668022711834 := by decide
theorem cert_e871929689626 : check e871929689626 [] .sourceHead = true := by decide
def e871929690650 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e871929690650 : Closed e871929690650 ∧ code e871929690650 = 9668022712858 := by decide
theorem cert_e871929690650 : check e871929690650 [] .sourceHead = true := by decide
def e872080436762 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080436762 : Closed e872080436762 ∧ code e872080436762 = 9668173458970 := by decide
theorem cert_e872080436762 : check e872080436762 [] .sourceHead = true := by decide
def e872080438810 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080438810 : Closed e872080438810 ∧ code e872080438810 = 9668173461018 := by decide
theorem cert_e872080438810 : check e872080438810 [] .sourceHead = true := by decide
def e872080453146 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080453146 : Closed e872080453146 ∧ code e872080453146 = 9668173475354 := by decide
theorem cert_e872080453146 : check e872080453146 [] .sourceHead = true := by decide
def e872080456218 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080456218 : Closed e872080456218 ∧ code e872080456218 = 9668173478426 := by decide
theorem cert_e872080456218 : check e872080456218 [] .sourceHead = true := by decide
def e872080463386 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080463386 : Closed e872080463386 ∧ code e872080463386 = 9668173485594 := by decide
theorem cert_e872080463386 : check e872080463386 [] .sourceHead = true := by decide
def e872080464410 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080464410 : Closed e872080464410 ∧ code e872080464410 = 9668173486618 := by decide
theorem cert_e872080464410 : check e872080464410 [] .sourceHead = true := by decide
def e872080535066 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080535066 : Closed e872080535066 ∧ code e872080535066 = 9668173557274 := by decide
theorem cert_e872080535066 : check e872080535066 [] .sourceHead = true := by decide
def e872080537114 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080537114 : Closed e872080537114 ∧ code e872080537114 = 9668173559322 := by decide
theorem cert_e872080537114 : check e872080537114 [] .sourceHead = true := by decide
def e872080633370 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080633370 : Closed e872080633370 ∧ code e872080633370 = 9668173655578 := by decide
theorem cert_e872080633370 : check e872080633370 [] .sourceHead = true := by decide
def e872080636442 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080636442 : Closed e872080636442 ∧ code e872080636442 = 9668173658650 := by decide
theorem cert_e872080636442 : check e872080636442 [] .sourceHead = true := by decide
def e872080684570 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080684570 : Closed e872080684570 ∧ code e872080684570 = 9668173706778 := by decide
theorem cert_e872080684570 : check e872080684570 [] .sourceHead = true := by decide
def e872080685594 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e872080685594 : Closed e872080685594 ∧ code e872080685594 = 9668173707802 := by decide
theorem cert_e872080685594 : check e872080685594 [] .sourceHead = true := by decide
def e872096509294 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e872096509294 : Closed e872096509294 ∧ code e872096509294 = 9668189531502 := by decide
theorem cert_e872096509294 : check e872096509294 [] .sourceHead = true := by decide
def e872096509302 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e872096509302 : Closed e872096509302 ∧ code e872096509302 = 9668189531510 := by decide
theorem cert_e872096509302 : check e872096509302 [] .sourceHead = true := by decide
def e872096509358 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e872096509358 : Closed e872096509358 ∧ code e872096509358 = 9668189531566 := by decide
theorem cert_e872096509358 : check e872096509358 [] .sourceHead = true := by decide
def e872096509370 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e872096509370 : Closed e872096509370 ∧ code e872096509370 = 9668189531578 := by decide
theorem cert_e872096509370 : check e872096509370 [] .sourceHead = true := by decide
def e872096509398 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e872096509398 : Closed e872096509398 ∧ code e872096509398 = 9668189531606 := by decide
theorem cert_e872096509398 : check e872096509398 [] .sourceHead = true := by decide
def e872096509402 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e872096509402 : Closed e872096509402 ∧ code e872096509402 = 9668189531610 := by decide
theorem cert_e872096509402 : check e872096509402 [] .sourceHead = true := by decide
def e872096509614 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e872096509614 : Closed e872096509614 ∧ code e872096509614 = 9668189531822 := by decide
theorem cert_e872096509614 : check e872096509614 [] .sourceHead = true := by decide
def e872096509626 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e872096509626 : Closed e872096509626 ∧ code e872096509626 = 9668189531834 := by decide
theorem cert_e872096509626 : check e872096509626 [] .sourceHead = true := by decide
def e872096509674 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e872096509674 : Closed e872096509674 ∧ code e872096509674 = 9668189531882 := by decide
theorem cert_e872096509674 : check e872096509674 [] .sourceHead = true := by decide
def e872096509782 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e872096509782 : Closed e872096509782 ∧ code e872096509782 = 9668189531990 := by decide
theorem cert_e872096509782 : check e872096509782 [] .sourceHead = true := by decide
def e872096509786 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e872096509786 : Closed e872096509786 ∧ code e872096509786 = 9668189531994 := by decide
theorem cert_e872096509786 : check e872096509786 [] .sourceHead = true := by decide
def e872096509802 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e872096509802 : Closed e872096509802 ∧ code e872096509802 = 9668189532010 := by decide
theorem cert_e872096509802 : check e872096509802 [] .sourceHead = true := by decide
def e872096510830 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e872096510830 : Closed e872096510830 ∧ code e872096510830 = 9668189533038 := by decide
theorem cert_e872096510830 : check e872096510830 [] .sourceHead = true := by decide
def e872096510838 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e872096510838 : Closed e872096510838 ∧ code e872096510838 = 9668189533046 := by decide
theorem cert_e872096510838 : check e872096510838 [] .sourceHead = true := by decide
def e872096510894 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e872096510894 : Closed e872096510894 ∧ code e872096510894 = 9668189533102 := by decide
theorem cert_e872096510894 : check e872096510894 [] .sourceHead = true := by decide
def e872096510906 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e872096510906 : Closed e872096510906 ∧ code e872096510906 = 9668189533114 := by decide
theorem cert_e872096510906 : check e872096510906 [] .sourceHead = true := by decide
def e872096510934 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e872096510934 : Closed e872096510934 ∧ code e872096510934 = 9668189533142 := by decide
theorem cert_e872096510934 : check e872096510934 [] .sourceHead = true := by decide
def e872096510938 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e872096510938 : Closed e872096510938 ∧ code e872096510938 = 9668189533146 := by decide
theorem cert_e872096510938 : check e872096510938 [] .sourceHead = true := by decide
def e872096511214 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e872096511214 : Closed e872096511214 ∧ code e872096511214 = 9668189533422 := by decide
theorem cert_e872096511214 : check e872096511214 [] .sourceHead = true := by decide
def e872096511222 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e872096511222 : Closed e872096511222 ∧ code e872096511222 = 9668189533430 := by decide
theorem cert_e872096511222 : check e872096511222 [] .sourceHead = true := by decide
def e872096511598 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e872096511598 : Closed e872096511598 ∧ code e872096511598 = 9668189533806 := by decide
theorem cert_e872096511598 : check e872096511598 [] .sourceHead = true := by decide
def e872096511610 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e872096511610 : Closed e872096511610 ∧ code e872096511610 = 9668189533818 := by decide
theorem cert_e872096511610 : check e872096511610 [] .sourceHead = true := by decide
def e872096511798 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e872096511798 : Closed e872096511798 ∧ code e872096511798 = 9668189534006 := by decide
theorem cert_e872096511798 : check e872096511798 [] .sourceHead = true := by decide
def e872096511802 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e872096511802 : Closed e872096511802 ∧ code e872096511802 = 9668189534010 := by decide
theorem cert_e872096511802 : check e872096511802 [] .sourceHead = true := by decide
def e872096512430 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e872096512430 : Closed e872096512430 ∧ code e872096512430 = 9668189534638 := by decide
theorem cert_e872096512430 : check e872096512430 [] .sourceHead = true := by decide
def e872096512442 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e872096512442 : Closed e872096512442 ∧ code e872096512442 = 9668189534650 := by decide
theorem cert_e872096512442 : check e872096512442 [] .sourceHead = true := by decide
def e872096512490 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e872096512490 : Closed e872096512490 ∧ code e872096512490 = 9668189534698 := by decide
theorem cert_e872096512490 : check e872096512490 [] .sourceHead = true := by decide
def e872096512622 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e872096512622 : Closed e872096512622 ∧ code e872096512622 = 9668189534830 := by decide
theorem cert_e872096512622 : check e872096512622 [] .sourceHead = true := by decide
def e872096512634 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e872096512634 : Closed e872096512634 ∧ code e872096512634 = 9668189534842 := by decide
theorem cert_e872096512634 : check e872096512634 [] .sourceHead = true := by decide
def e872096512922 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e872096512922 : Closed e872096512922 ∧ code e872096512922 = 9668189535130 := by decide
theorem cert_e872096512922 : check e872096512922 [] .sourceHead = true := by decide
def e872096513238 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e872096513238 : Closed e872096513238 ∧ code e872096513238 = 9668189535446 := by decide
theorem cert_e872096513238 : check e872096513238 [] .sourceHead = true := by decide
def e872096513242 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e872096513242 : Closed e872096513242 ∧ code e872096513242 = 9668189535450 := by decide
theorem cert_e872096513242 : check e872096513242 [] .sourceHead = true := by decide
def e872096513258 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e872096513258 : Closed e872096513258 ∧ code e872096513258 = 9668189535466 := by decide
theorem cert_e872096513258 : check e872096513258 [] .sourceHead = true := by decide
def e872096513334 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e872096513334 : Closed e872096513334 ∧ code e872096513334 = 9668189535542 := by decide
theorem cert_e872096513334 : check e872096513334 [] .sourceHead = true := by decide
def e872096513338 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e872096513338 : Closed e872096513338 ∧ code e872096513338 = 9668189535546 := by decide
theorem cert_e872096513338 : check e872096513338 [] .sourceHead = true := by decide
def e872096513434 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e872096513434 : Closed e872096513434 ∧ code e872096513434 = 9668189535642 := by decide
theorem cert_e872096513434 : check e872096513434 [] .sourceHead = true := by decide
def e872096516974 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e872096516974 : Closed e872096516974 ∧ code e872096516974 = 9668189539182 := by decide
theorem cert_e872096516974 : check e872096516974 [] .sourceHead = true := by decide
def e872096516982 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e872096516982 : Closed e872096516982 ∧ code e872096516982 = 9668189539190 := by decide
theorem cert_e872096516982 : check e872096516982 [] .sourceHead = true := by decide
def e872096517038 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e872096517038 : Closed e872096517038 ∧ code e872096517038 = 9668189539246 := by decide
theorem cert_e872096517038 : check e872096517038 [] .sourceHead = true := by decide
def e872096517050 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e872096517050 : Closed e872096517050 ∧ code e872096517050 = 9668189539258 := by decide
theorem cert_e872096517050 : check e872096517050 [] .sourceHead = true := by decide
def e872096517078 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e872096517078 : Closed e872096517078 ∧ code e872096517078 = 9668189539286 := by decide
theorem cert_e872096517078 : check e872096517078 [] .sourceHead = true := by decide
def e872096517082 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e872096517082 : Closed e872096517082 ∧ code e872096517082 = 9668189539290 := by decide
theorem cert_e872096517082 : check e872096517082 [] .sourceHead = true := by decide
def e872096517358 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e872096517358 : Closed e872096517358 ∧ code e872096517358 = 9668189539566 := by decide
theorem cert_e872096517358 : check e872096517358 [] .sourceHead = true := by decide
def e872096517366 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e872096517366 : Closed e872096517366 ∧ code e872096517366 = 9668189539574 := by decide
theorem cert_e872096517366 : check e872096517366 [] .sourceHead = true := by decide
def e872096517742 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e872096517742 : Closed e872096517742 ∧ code e872096517742 = 9668189539950 := by decide
theorem cert_e872096517742 : check e872096517742 [] .sourceHead = true := by decide
def e872096517754 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e872096517754 : Closed e872096517754 ∧ code e872096517754 = 9668189539962 := by decide
theorem cert_e872096517754 : check e872096517754 [] .sourceHead = true := by decide
def e872096517942 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e872096517942 : Closed e872096517942 ∧ code e872096517942 = 9668189540150 := by decide
theorem cert_e872096517942 : check e872096517942 [] .sourceHead = true := by decide
def e872096517946 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e872096517946 : Closed e872096517946 ∧ code e872096517946 = 9668189540154 := by decide
theorem cert_e872096517946 : check e872096517946 [] .sourceHead = true := by decide
def e872096523694 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e872096523694 : Closed e872096523694 ∧ code e872096523694 = 9668189545902 := by decide
theorem cert_e872096523694 : check e872096523694 [] .sourceHead = true := by decide
def e872096523706 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e872096523706 : Closed e872096523706 ∧ code e872096523706 = 9668189545914 := by decide
theorem cert_e872096523706 : check e872096523706 [] .sourceHead = true := by decide
def e872096523754 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e872096523754 : Closed e872096523754 ∧ code e872096523754 = 9668189545962 := by decide
theorem cert_e872096523754 : check e872096523754 [] .sourceHead = true := by decide
def e872096523886 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e872096523886 : Closed e872096523886 ∧ code e872096523886 = 9668189546094 := by decide
theorem cert_e872096523886 : check e872096523886 [] .sourceHead = true := by decide
def e872096523898 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e872096523898 : Closed e872096523898 ∧ code e872096523898 = 9668189546106 := by decide
theorem cert_e872096523898 : check e872096523898 [] .sourceHead = true := by decide
def e872096524186 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e872096524186 : Closed e872096524186 ∧ code e872096524186 = 9668189546394 := by decide
theorem cert_e872096524186 : check e872096524186 [] .sourceHead = true := by decide
def e872096527062 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e872096527062 : Closed e872096527062 ∧ code e872096527062 = 9668189549270 := by decide
theorem cert_e872096527062 : check e872096527062 [] .sourceHead = true := by decide
def e872096527066 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e872096527066 : Closed e872096527066 ∧ code e872096527066 = 9668189549274 := by decide
theorem cert_e872096527066 : check e872096527066 [] .sourceHead = true := by decide
def e872096527082 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e872096527082 : Closed e872096527082 ∧ code e872096527082 = 9668189549290 := by decide
theorem cert_e872096527082 : check e872096527082 [] .sourceHead = true := by decide
def e872096527158 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e872096527158 : Closed e872096527158 ∧ code e872096527158 = 9668189549366 := by decide
theorem cert_e872096527158 : check e872096527158 [] .sourceHead = true := by decide
def e872096527162 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e872096527162 : Closed e872096527162 ∧ code e872096527162 = 9668189549370 := by decide
theorem cert_e872096527162 : check e872096527162 [] .sourceHead = true := by decide
def e872096527258 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e872096527258 : Closed e872096527258 ∧ code e872096527258 = 9668189549466 := by decide
theorem cert_e872096527258 : check e872096527258 [] .sourceHead = true := by decide
def e872096664430 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e872096664430 : Closed e872096664430 ∧ code e872096664430 = 9668189686638 := by decide
theorem cert_e872096664430 : check e872096664430 [] .sourceHead = true := by decide
def e872096664438 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e872096664438 : Closed e872096664438 ∧ code e872096664438 = 9668189686646 := by decide
theorem cert_e872096664438 : check e872096664438 [] .sourceHead = true := by decide
def e872096664494 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e872096664494 : Closed e872096664494 ∧ code e872096664494 = 9668189686702 := by decide
theorem cert_e872096664494 : check e872096664494 [] .sourceHead = true := by decide
def e872096664506 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e872096664506 : Closed e872096664506 ∧ code e872096664506 = 9668189686714 := by decide
theorem cert_e872096664506 : check e872096664506 [] .sourceHead = true := by decide
def e872096664534 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e872096664534 : Closed e872096664534 ∧ code e872096664534 = 9668189686742 := by decide
theorem cert_e872096664534 : check e872096664534 [] .sourceHead = true := by decide
def e872096664538 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e872096664538 : Closed e872096664538 ∧ code e872096664538 = 9668189686746 := by decide
theorem cert_e872096664538 : check e872096664538 [] .sourceHead = true := by decide
def e872096664814 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e872096664814 : Closed e872096664814 ∧ code e872096664814 = 9668189687022 := by decide
theorem cert_e872096664814 : check e872096664814 [] .sourceHead = true := by decide
def e872096664822 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e872096664822 : Closed e872096664822 ∧ code e872096664822 = 9668189687030 := by decide
theorem cert_e872096664822 : check e872096664822 [] .sourceHead = true := by decide
def e872096665198 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e872096665198 : Closed e872096665198 ∧ code e872096665198 = 9668189687406 := by decide
theorem cert_e872096665198 : check e872096665198 [] .sourceHead = true := by decide
def e872096665210 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e872096665210 : Closed e872096665210 ∧ code e872096665210 = 9668189687418 := by decide
theorem cert_e872096665210 : check e872096665210 [] .sourceHead = true := by decide
def e872096665398 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e872096665398 : Closed e872096665398 ∧ code e872096665398 = 9668189687606 := by decide
theorem cert_e872096665398 : check e872096665398 [] .sourceHead = true := by decide
def e872096665402 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e872096665402 : Closed e872096665402 ∧ code e872096665402 = 9668189687610 := by decide
theorem cert_e872096665402 : check e872096665402 [] .sourceHead = true := by decide
def e872097254254 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e872097254254 : Closed e872097254254 ∧ code e872097254254 = 9668190276462 := by decide
theorem cert_e872097254254 : check e872097254254 [] .sourceHead = true := by decide
def e872097254262 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e872097254262 : Closed e872097254262 ∧ code e872097254262 = 9668190276470 := by decide
theorem cert_e872097254262 : check e872097254262 [] .sourceHead = true := by decide
def e872097254318 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e872097254318 : Closed e872097254318 ∧ code e872097254318 = 9668190276526 := by decide
theorem cert_e872097254318 : check e872097254318 [] .sourceHead = true := by decide
def e872097254330 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e872097254330 : Closed e872097254330 ∧ code e872097254330 = 9668190276538 := by decide
theorem cert_e872097254330 : check e872097254330 [] .sourceHead = true := by decide
def e872097254358 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e872097254358 : Closed e872097254358 ∧ code e872097254358 = 9668190276566 := by decide
theorem cert_e872097254358 : check e872097254358 [] .sourceHead = true := by decide
def e872097254362 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e872097254362 : Closed e872097254362 ∧ code e872097254362 = 9668190276570 := by decide
theorem cert_e872097254362 : check e872097254362 [] .sourceHead = true := by decide
def e872097254638 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e872097254638 : Closed e872097254638 ∧ code e872097254638 = 9668190276846 := by decide
theorem cert_e872097254638 : check e872097254638 [] .sourceHead = true := by decide
def e872097254646 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e872097254646 : Closed e872097254646 ∧ code e872097254646 = 9668190276854 := by decide
theorem cert_e872097254646 : check e872097254646 [] .sourceHead = true := by decide
def e872097255022 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e872097255022 : Closed e872097255022 ∧ code e872097255022 = 9668190277230 := by decide
theorem cert_e872097255022 : check e872097255022 [] .sourceHead = true := by decide
def e872097255034 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e872097255034 : Closed e872097255034 ∧ code e872097255034 = 9668190277242 := by decide
theorem cert_e872097255034 : check e872097255034 [] .sourceHead = true := by decide
def e872097255222 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e872097255222 : Closed e872097255222 ∧ code e872097255222 = 9668190277430 := by decide
theorem cert_e872097255222 : check e872097255222 [] .sourceHead = true := by decide
def e872097255226 : Term := (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e872097255226 : Closed e872097255226 ∧ code e872097255226 = 9668190277434 := by decide
theorem cert_e872097255226 : check e872097255226 [] .sourceHead = true := by decide
def e876321221998 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e876321221998 : Closed e876321221998 ∧ code e876321221998 = 9672414244206 := by decide
theorem cert_e876321221998 : check e876321221998 [] .sourceHead = true := by decide
def e876321222006 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e876321222006 : Closed e876321222006 ∧ code e876321222006 = 9672414244214 := by decide
theorem cert_e876321222006 : check e876321222006 [] .sourceHead = true := by decide
def e876321222062 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e876321222062 : Closed e876321222062 ∧ code e876321222062 = 9672414244270 := by decide
theorem cert_e876321222062 : check e876321222062 [] .sourceHead = true := by decide
def e876321222074 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e876321222074 : Closed e876321222074 ∧ code e876321222074 = 9672414244282 := by decide
theorem cert_e876321222074 : check e876321222074 [] .sourceHead = true := by decide
def e876321222102 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e876321222102 : Closed e876321222102 ∧ code e876321222102 = 9672414244310 := by decide
theorem cert_e876321222102 : check e876321222102 [] .sourceHead = true := by decide
def e876321222106 : Term := (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e876321222106 : Closed e876321222106 ∧ code e876321222106 = 9672414244314 := by decide
theorem cert_e876321222106 : check e876321222106 [] .sourceHead = true := by decide
end Blc.Floor43
