import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701168123098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701168123098 : Closed e701168123098 ∧ code e701168123098 = 9497261145306 := by decide
theorem cert_e701168123098 : check e701168123098 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168123114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701168123114 : Closed e701168123114 ∧ code e701168123114 = 9497261145322 := by decide
theorem cert_e701168123114 : check e701168123114 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .three = true := by decide
def e701168182202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e701168182202 : Closed e701168182202 ∧ code e701168182202 = 9497261204410 := by decide
theorem cert_e701168182202 : checkPay e701168182202 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] 0 [] = true := by decide
def e701168182234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e701168182234 : Closed e701168182234 ∧ code e701168182234 = 9497261204442 := by decide
theorem cert_e701168182234 : check e701168182234 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .smaller = true := by decide
def e701168184442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701168184442 : Closed e701168184442 ∧ code e701168184442 = 9497261206650 := by decide
theorem cert_e701168184442 : check e701168184442 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .sourceHead = true := by decide
def e701168184774 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701168184774 : Closed e701168184774 ∧ code e701168184774 = 9497261206982 := by decide
theorem cert_e701168184774 : checkPay e701168184774 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left]] 0 [] = true := by decide
def e701168184890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701168184890 : Closed e701168184890 ∧ code e701168184890 = 9497261207098 := by decide
private def t_e701168184890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.var 0)))
theorem cert_e701168184890 : ¬ IsSelfInterpreter e701168184890 :=
  wSource (t := t_e701168184890) (replay_sound (ps := []) (t := e701168184890) (by decide)) (by decide)
def e701168185030 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701168185030 : Closed e701168185030 ∧ code e701168185030 = 9497261207238 := by decide
private def t_e701168185030 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.var 1))))
theorem cert_e701168185030 : ¬ IsSelfInterpreter e701168185030 :=
  wSource (t := t_e701168185030) (replay_sound (ps := []) (t := e701168185030) (by decide)) (by decide)
def e701168185786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701168185786 : Closed e701168185786 ∧ code e701168185786 = 9497261207994 := by decide
theorem cert_e701168185786 : checkPay e701168185786 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e701168185834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e701168185834 : Closed e701168185834 ∧ code e701168185834 = 9497261208042 := by decide
theorem cert_e701168185834 : checkPay e701168185834 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e701168186490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701168186490 : Closed e701168186490 ∧ code e701168186490 = 9497261208698 := by decide
theorem cert_e701168186490 : checkPay e701168186490 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [[.under,.left]] = true := by decide
def e701168186822 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701168186822 : Closed e701168186822 ∧ code e701168186822 = 9497261209030 := by decide
theorem cert_e701168186822 : check e701168186822 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .smaller = true := by decide
def e701168187162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701168187162 : Closed e701168187162 ∧ code e701168187162 = 9497261209370 := by decide
theorem cert_e701168187162 : checkPay e701168187162 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] 0 [] = true := by decide
def e701168187206 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701168187206 : Closed e701168187206 ∧ code e701168187206 = 9497261209414 := by decide
theorem cert_e701168187206 : check e701168187206 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e701168187610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e701168187610 : Closed e701168187610 ∧ code e701168187610 = 9497261209818 := by decide
theorem cert_e701168187610 : check e701168187610 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e701168187626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701168187626 : Closed e701168187626 ∧ code e701168187626 = 9497261209834 := by decide
theorem cert_e701168187626 : check e701168187626 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e701168187962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701168187962 : Closed e701168187962 ∧ code e701168187962 = 9497261210170 := by decide
private def t_e701168187962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.var 0)))
theorem cert_e701168187962 : ¬ IsSelfInterpreter e701168187962 :=
  wSource (t := t_e701168187962) (replay_sound (ps := []) (t := e701168187962) (by decide)) (by decide)
def e701168188102 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701168188102 : Closed e701168188102 ∧ code e701168188102 = 9497261210310 := by decide
private def t_e701168188102 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.var 1))))
theorem cert_e701168188102 : ¬ IsSelfInterpreter e701168188102 :=
  wSource (t := t_e701168188102) (replay_sound (ps := []) (t := e701168188102) (by decide)) (by decide)
def e701168188186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701168188186 : Closed e701168188186 ∧ code e701168188186 = 9497261210394 := by decide
theorem cert_e701168188186 : check e701168188186 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e701168188230 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701168188230 : Closed e701168188230 ∧ code e701168188230 = 9497261210438 := by decide
theorem cert_e701168188230 : check e701168188230 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e701168196730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e701168196730 : Closed e701168196730 ∧ code e701168196730 = 9497261218938 := by decide
theorem cert_e701168196730 : checkPay e701168196730 [[.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[]] 0 [] = true := by decide
def e701168197062 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e701168197062 : Closed e701168197062 ∧ code e701168197062 = 9497261219270 := by decide
theorem cert_e701168197062 : check e701168197062 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e701168197178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701168197178 : Closed e701168197178 ∧ code e701168197178 = 9497261219386 := by decide
theorem cert_e701168197178 : check e701168197178 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e701168197318 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701168197318 : Closed e701168197318 ∧ code e701168197318 = 9497261219526 := by decide
theorem cert_e701168197318 : check e701168197318 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left]] .chain = true := by decide
def e701168209018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.var 0)))
theorem wire_e701168209018 : Closed e701168209018 ∧ code e701168209018 = 9497261231226 := by decide
theorem cert_e701168209018 : check e701168209018 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e701168209350 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.var 1))))
theorem wire_e701168209350 : Closed e701168209350 ∧ code e701168209350 = 9497261231558 := by decide
theorem cert_e701168209350 : check e701168209350 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .smaller = true := by decide
def e701168209690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e701168209690 : Closed e701168209690 ∧ code e701168209690 = 9497261231898 := by decide
theorem cert_e701168209690 : check e701168209690 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e701168209734 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e701168209734 : Closed e701168209734 ∧ code e701168209734 = 9497261231942 := by decide
theorem cert_e701168209734 : check e701168209734 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .smaller = true := by decide
def e701168215610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.var 0)))
theorem wire_e701168215610 : Closed e701168215610 ∧ code e701168215610 = 9497261237818 := by decide
theorem cert_e701168215610 : check e701168215610 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e701168215750 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.var 1))))
theorem wire_e701168215750 : Closed e701168215750 ∧ code e701168215750 = 9497261237958 := by decide
theorem cert_e701168215750 : check e701168215750 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e701168215834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.var 0)))
theorem wire_e701168215834 : Closed e701168215834 ∧ code e701168215834 = 9497261238042 := by decide
theorem cert_e701168215834 : check e701168215834 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e701168215878 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.var 1))))
theorem wire_e701168215878 : Closed e701168215878 ∧ code e701168215878 = 9497261238086 := by decide
theorem cert_e701168215878 : check e701168215878 [[.under,.left],[.under,.left],[.under],[.under],[.under,.under],[.under,.under]] .three = true := by decide
def e701199595242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))) (.var 0)))
theorem wire_e701199595242 : Closed e701199595242 ∧ code e701199595242 = 9497292617450 := by decide
def e701199595370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))) (.var 0)))
theorem wire_e701199595370 : Closed e701199595370 ∧ code e701199595370 = 9497292617578 := by decide
def e701199596266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))) (.var 0)))
theorem wire_e701199596266 : Closed e701199596266 ∧ code e701199596266 = 9497292618474 := by decide
def e701199596458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))) (.var 0)))
theorem wire_e701199596458 : Closed e701199596458 ∧ code e701199596458 = 9497292618666 := by decide
private def t_e701199596458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))) (.var 0)))
theorem cert_e701199596458 : ¬ IsSelfInterpreter e701199596458 :=
  wSource (t := t_e701199596458) (replay_sound (ps := []) (t := e701199596458) (by decide)) (by decide)
def e701199596906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))) (.var 0)))
theorem wire_e701199596906 : Closed e701199596906 ∧ code e701199596906 = 9497292619114 := by decide
def e701199596970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))) (.var 0)))
theorem wire_e701199596970 : Closed e701199596970 ∧ code e701199596970 = 9497292619178 := by decide
private def t_e701199596970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))) (.var 0)))
theorem cert_e701199596970 : ¬ IsSelfInterpreter e701199596970 :=
  wSource (t := t_e701199596970) (replay_sound (ps := []) (t := e701199596970) (by decide)) (by decide)
def e701199601386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))) (.var 0)))
theorem wire_e701199601386 : Closed e701199601386 ∧ code e701199601386 = 9497292623594 := by decide
def e701199601514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))) (.var 0)))
theorem wire_e701199601514 : Closed e701199601514 ∧ code e701199601514 = 9497292623722 := by decide
def e701199607530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))) (.var 0)))
theorem wire_e701199607530 : Closed e701199607530 ∧ code e701199607530 = 9497292629738 := by decide
def e701199607722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))) (.var 0)))
theorem wire_e701199607722 : Closed e701199607722 ∧ code e701199607722 = 9497292629930 := by decide
def e701199610730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))) (.var 0)))
theorem wire_e701199610730 : Closed e701199610730 ∧ code e701199610730 = 9497292632938 := by decide
def e701199610794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))) (.var 0)))
theorem wire_e701199610794 : Closed e701199610794 ∧ code e701199610794 = 9497292633002 := by decide
def e701200608698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701200608698 : Closed e701200608698 ∧ code e701200608698 = 9497293630906 := by decide
private def t_e701200608698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem cert_e701200608698 : ¬ IsSelfInterpreter e701200608698 :=
  wSource (t := t_e701200608698) (replay_sound (ps := []) (t := e701200608698) (by decide)) (by decide)
def e701200608730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701200608730 : Closed e701200608730 ∧ code e701200608730 = 9497293630938 := by decide
private def t_e701200608730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem cert_e701200608730 : ¬ IsSelfInterpreter e701200608730 :=
  wSource (t := t_e701200608730) (replay_sound (ps := []) (t := e701200608730) (by decide)) (by decide)
def e701200608954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701200608954 : Closed e701200608954 ∧ code e701200608954 = 9497293631162 := by decide
private def t_e701200608954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem cert_e701200608954 : ¬ IsSelfInterpreter e701200608954 :=
  wSource (t := t_e701200608954) (replay_sound (ps := []) (t := e701200608954) (by decide)) (by decide)
def e701200609002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701200609002 : Closed e701200609002 ∧ code e701200609002 = 9497293631210 := by decide
private def t_e701200609002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem cert_e701200609002 : ¬ IsSelfInterpreter e701200609002 :=
  wSource (t := t_e701200609002) (replay_sound (ps := []) (t := e701200609002) (by decide)) (by decide)
def e701200609114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701200609114 : Closed e701200609114 ∧ code e701200609114 = 9497293631322 := by decide
private def t_e701200609114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem cert_e701200609114 : ¬ IsSelfInterpreter e701200609114 :=
  wSource (t := t_e701200609114) (replay_sound (ps := []) (t := e701200609114) (by decide)) (by decide)
def e701200609130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701200609130 : Closed e701200609130 ∧ code e701200609130 = 9497293631338 := by decide
private def t_e701200609130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem cert_e701200609130 : ¬ IsSelfInterpreter e701200609130 :=
  wSource (t := t_e701200609130) (replay_sound (ps := []) (t := e701200609130) (by decide)) (by decide)
def e701200610234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701200610234 : Closed e701200610234 ∧ code e701200610234 = 9497293632442 := by decide
private def t_e701200610234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem cert_e701200610234 : ¬ IsSelfInterpreter e701200610234 :=
  wSource (t := t_e701200610234) (replay_sound (ps := []) (t := e701200610234) (by decide)) (by decide)
def e701200610266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701200610266 : Closed e701200610266 ∧ code e701200610266 = 9497293632474 := by decide
private def t_e701200610266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem cert_e701200610266 : ¬ IsSelfInterpreter e701200610266 :=
  wSource (t := t_e701200610266) (replay_sound (ps := []) (t := e701200610266) (by decide)) (by decide)
def e701200611770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701200611770 : Closed e701200611770 ∧ code e701200611770 = 9497293633978 := by decide
private def t_e701200611770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem cert_e701200611770 : ¬ IsSelfInterpreter e701200611770 :=
  wSource (t := t_e701200611770) (replay_sound (ps := []) (t := e701200611770) (by decide)) (by decide)
def e701200611818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701200611818 : Closed e701200611818 ∧ code e701200611818 = 9497293634026 := by decide
private def t_e701200611818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem cert_e701200611818 : ¬ IsSelfInterpreter e701200611818 :=
  wSource (t := t_e701200611818) (replay_sound (ps := []) (t := e701200611818) (by decide)) (by decide)
def e701200612570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701200612570 : Closed e701200612570 ∧ code e701200612570 = 9497293634778 := by decide
private def t_e701200612570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem cert_e701200612570 : ¬ IsSelfInterpreter e701200612570 :=
  wSource (t := t_e701200612570) (replay_sound (ps := []) (t := e701200612570) (by decide)) (by decide)
def e701200612586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701200612586 : Closed e701200612586 ∧ code e701200612586 = 9497293634794 := by decide
private def t_e701200612586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem cert_e701200612586 : ¬ IsSelfInterpreter e701200612586 :=
  wSource (t := t_e701200612586) (replay_sound (ps := []) (t := e701200612586) (by decide)) (by decide)
def e701203789690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.var 0)))
theorem wire_e701203789690 : Closed e701203789690 ∧ code e701203789690 = 9497296811898 := by decide
theorem cert_e701203789690 : check e701203789690 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e701203789754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.var 0)))
theorem wire_e701203789754 : Closed e701203789754 ∧ code e701203789754 = 9497296811962 := by decide
theorem cert_e701203789754 : check e701203789754 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e701203791226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.var 0)))
theorem wire_e701203791226 : Closed e701203791226 ∧ code e701203791226 = 9497296813434 := by decide
theorem cert_e701203791226 : check e701203791226 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e701203791338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.var 0)))
theorem wire_e701203791338 : Closed e701203791338 ∧ code e701203791338 = 9497296813546 := by decide
private def t_e701203791338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.var 0)))
theorem cert_e701203791338 : ¬ IsSelfInterpreter e701203791338 :=
  wSource (t := t_e701203791338) (replay_sound (ps := []) (t := e701203791338) (by decide)) (by decide)
def e701203791546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701203791546 : Closed e701203791546 ∧ code e701203791546 = 9497296813754 := by decide
theorem cert_e701203791546 : check e701203791546 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e701203791594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701203791594 : Closed e701203791594 ∧ code e701203791594 = 9497296813802 := by decide
private def t_e701203791594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.var 0)))
theorem cert_e701203791594 : ¬ IsSelfInterpreter e701203791594 :=
  wSource (t := t_e701203791594) (replay_sound (ps := []) (t := e701203791594) (by decide)) (by decide)
def e701203795834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.var 0)))
theorem wire_e701203795834 : Closed e701203795834 ∧ code e701203795834 = 9497296818042 := by decide
theorem cert_e701203795834 : check e701203795834 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e701203795898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.var 0)))
theorem wire_e701203795898 : Closed e701203795898 ∧ code e701203795898 = 9497296818106 := by decide
theorem cert_e701203795898 : check e701203795898 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e701203805050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.var 0)))
theorem wire_e701203805050 : Closed e701203805050 ∧ code e701203805050 = 9497296827258 := by decide
theorem cert_e701203805050 : check e701203805050 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e701203805162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.var 0)))
theorem wire_e701203805162 : Closed e701203805162 ∧ code e701203805162 = 9497296827370 := by decide
theorem cert_e701203805162 : check e701203805162 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e701203806650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701203806650 : Closed e701203806650 ∧ code e701203806650 = 9497296828858 := by decide
theorem cert_e701203806650 : check e701203806650 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[],[.under,.under]] .identityHead = true := by decide
def e701203806698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701203806698 : Closed e701203806698 ∧ code e701203806698 = 9497296828906 := by decide
theorem cert_e701203806698 : check e701203806698 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e701203920314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701203920314 : Closed e701203920314 ∧ code e701203920314 = 9497296942522 := by decide
theorem cert_e701203920314 : check e701203920314 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203920346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701203920346 : Closed e701203920346 ∧ code e701203920346 = 9497296942554 := by decide
theorem cert_e701203920346 : check e701203920346 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203920570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701203920570 : Closed e701203920570 ∧ code e701203920570 = 9497296942778 := by decide
theorem cert_e701203920570 : check e701203920570 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203920618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701203920618 : Closed e701203920618 ∧ code e701203920618 = 9497296942826 := by decide
theorem cert_e701203920618 : check e701203920618 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203920730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701203920730 : Closed e701203920730 ∧ code e701203920730 = 9497296942938 := by decide
theorem cert_e701203920730 : check e701203920730 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203920746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701203920746 : Closed e701203920746 ∧ code e701203920746 = 9497296942954 := by decide
theorem cert_e701203920746 : check e701203920746 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203921594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701203921594 : Closed e701203921594 ∧ code e701203921594 = 9497296943802 := by decide
theorem cert_e701203921594 : check e701203921594 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e701203921642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701203921642 : Closed e701203921642 ∧ code e701203921642 = 9497296943850 := by decide
theorem cert_e701203921642 : check e701203921642 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e701203921834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701203921834 : Closed e701203921834 ∧ code e701203921834 = 9497296944042 := by decide
private def t_e701203921834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem cert_e701203921834 : ¬ IsSelfInterpreter e701203921834 :=
  wSource (t := t_e701203921834) (replay_sound (ps := []) (t := e701203921834) (by decide)) (by decide)
def e701203922266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701203922266 : Closed e701203922266 ∧ code e701203922266 = 9497296944474 := by decide
theorem cert_e701203922266 : check e701203922266 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e701203922282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701203922282 : Closed e701203922282 ∧ code e701203922282 = 9497296944490 := by decide
theorem cert_e701203922282 : check e701203922282 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e701203922346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701203922346 : Closed e701203922346 ∧ code e701203922346 = 9497296944554 := by decide
private def t_e701203922346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem cert_e701203922346 : ¬ IsSelfInterpreter e701203922346 :=
  wSource (t := t_e701203922346) (replay_sound (ps := []) (t := e701203922346) (by decide)) (by decide)
def e701203926458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701203926458 : Closed e701203926458 ∧ code e701203926458 = 9497296948666 := by decide
theorem cert_e701203926458 : check e701203926458 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203926490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701203926490 : Closed e701203926490 ∧ code e701203926490 = 9497296948698 := by decide
theorem cert_e701203926490 : check e701203926490 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203926714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701203926714 : Closed e701203926714 ∧ code e701203926714 = 9497296948922 := by decide
theorem cert_e701203926714 : check e701203926714 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203926762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701203926762 : Closed e701203926762 ∧ code e701203926762 = 9497296948970 := by decide
theorem cert_e701203926762 : check e701203926762 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203926874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701203926874 : Closed e701203926874 ∧ code e701203926874 = 9497296949082 := by decide
theorem cert_e701203926874 : check e701203926874 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203926890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701203926890 : Closed e701203926890 ∧ code e701203926890 = 9497296949098 := by decide
theorem cert_e701203926890 : check e701203926890 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203927994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701203927994 : Closed e701203927994 ∧ code e701203927994 = 9497296950202 := by decide
theorem cert_e701203927994 : check e701203927994 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203928026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701203928026 : Closed e701203928026 ∧ code e701203928026 = 9497296950234 := by decide
theorem cert_e701203928026 : check e701203928026 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203929530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701203929530 : Closed e701203929530 ∧ code e701203929530 = 9497296951738 := by decide
theorem cert_e701203929530 : check e701203929530 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203929578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701203929578 : Closed e701203929578 ∧ code e701203929578 = 9497296951786 := by decide
theorem cert_e701203929578 : check e701203929578 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203930010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203930010 : Closed e701203930010 ∧ code e701203930010 = 9497296952218 := by decide
theorem cert_e701203930010 : check e701203930010 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203930330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701203930330 : Closed e701203930330 ∧ code e701203930330 = 9497296952538 := by decide
theorem cert_e701203930330 : check e701203930330 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203930346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701203930346 : Closed e701203930346 ∧ code e701203930346 = 9497296952554 := by decide
theorem cert_e701203930346 : check e701203930346 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203930522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203930522 : Closed e701203930522 ∧ code e701203930522 = 9497296952730 := by decide
theorem cert_e701203930522 : check e701203930522 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203932858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701203932858 : Closed e701203932858 ∧ code e701203932858 = 9497296955066 := by decide
theorem cert_e701203932858 : check e701203932858 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203932906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701203932906 : Closed e701203932906 ∧ code e701203932906 = 9497296955114 := by decide
theorem cert_e701203932906 : check e701203932906 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203933098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701203933098 : Closed e701203933098 ∧ code e701203933098 = 9497296955306 := by decide
theorem cert_e701203933098 : check e701203933098 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e701203933626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701203933626 : Closed e701203933626 ∧ code e701203933626 = 9497296955834 := by decide
theorem cert_e701203933626 : check e701203933626 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203933674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701203933674 : Closed e701203933674 ∧ code e701203933674 = 9497296955882 := by decide
theorem cert_e701203933674 : check e701203933674 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203934106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203934106 : Closed e701203934106 ∧ code e701203934106 = 9497296956314 := by decide
theorem cert_e701203934106 : check e701203934106 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203934826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701203934826 : Closed e701203934826 ∧ code e701203934826 = 9497296957034 := by decide
private def t_e701203934826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem cert_e701203934826 : ¬ IsSelfInterpreter e701203934826 :=
  wSource (t := t_e701203934826) (replay_sound (ps := []) (t := e701203934826) (by decide)) (by decide)
def e701203934874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203934874 : Closed e701203934874 ∧ code e701203934874 = 9497296957082 := by decide
private def t_e701203934874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem cert_e701203934874 : ¬ IsSelfInterpreter e701203934874 :=
  wSource (t := t_e701203934874) (replay_sound (ps := []) (t := e701203934874) (by decide)) (by decide)
def e701203936090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701203936090 : Closed e701203936090 ∧ code e701203936090 = 9497296958298 := by decide
theorem cert_e701203936090 : check e701203936090 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e701203936106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701203936106 : Closed e701203936106 ∧ code e701203936106 = 9497296958314 := by decide
theorem cert_e701203936106 : check e701203936106 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e701203936170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701203936170 : Closed e701203936170 ∧ code e701203936170 = 9497296958378 := by decide
theorem cert_e701203936170 : check e701203936170 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e701203936474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701203936474 : Closed e701203936474 ∧ code e701203936474 = 9497296958682 := by decide
theorem cert_e701203936474 : check e701203936474 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e701203936490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701203936490 : Closed e701203936490 ∧ code e701203936490 = 9497296958698 := by decide
theorem cert_e701203936490 : check e701203936490 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e701203936666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203936666 : Closed e701203936666 ∧ code e701203936666 = 9497296958874 := by decide
theorem cert_e701203936666 : check e701203936666 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e701203936874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701203936874 : Closed e701203936874 ∧ code e701203936874 = 9497296959082 := by decide
private def t_e701203936874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem cert_e701203936874 : ¬ IsSelfInterpreter e701203936874 :=
  wSource (t := t_e701203936874) (replay_sound (ps := []) (t := e701203936874) (by decide)) (by decide)
def e701203936922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203936922 : Closed e701203936922 ∧ code e701203936922 = 9497296959130 := by decide
private def t_e701203936922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem cert_e701203936922 : ¬ IsSelfInterpreter e701203936922 :=
  wSource (t := t_e701203936922) (replay_sound (ps := []) (t := e701203936922) (by decide)) (by decide)
def e701203943290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.var 0)))
theorem wire_e701203943290 : Closed e701203943290 ∧ code e701203943290 = 9497296965498 := by decide
theorem cert_e701203943290 : check e701203943290 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203943354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.var 0)))
theorem wire_e701203943354 : Closed e701203943354 ∧ code e701203943354 = 9497296965562 := by decide
theorem cert_e701203943354 : check e701203943354 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203951034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701203951034 : Closed e701203951034 ∧ code e701203951034 = 9497296973242 := by decide
theorem cert_e701203951034 : check e701203951034 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203951066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701203951066 : Closed e701203951066 ∧ code e701203951066 = 9497296973274 := by decide
theorem cert_e701203951066 : check e701203951066 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203951290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701203951290 : Closed e701203951290 ∧ code e701203951290 = 9497296973498 := by decide
theorem cert_e701203951290 : check e701203951290 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203951338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701203951338 : Closed e701203951338 ∧ code e701203951338 = 9497296973546 := by decide
theorem cert_e701203951338 : check e701203951338 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203951450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701203951450 : Closed e701203951450 ∧ code e701203951450 = 9497296973658 := by decide
theorem cert_e701203951450 : check e701203951450 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203951466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701203951466 : Closed e701203951466 ∧ code e701203951466 = 9497296973674 := by decide
theorem cert_e701203951466 : check e701203951466 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203952570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701203952570 : Closed e701203952570 ∧ code e701203952570 = 9497296974778 := by decide
theorem cert_e701203952570 : check e701203952570 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203952602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701203952602 : Closed e701203952602 ∧ code e701203952602 = 9497296974810 := by decide
theorem cert_e701203952602 : check e701203952602 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203954106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701203954106 : Closed e701203954106 ∧ code e701203954106 = 9497296976314 := by decide
theorem cert_e701203954106 : check e701203954106 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203954154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701203954154 : Closed e701203954154 ∧ code e701203954154 = 9497296976362 := by decide
theorem cert_e701203954154 : check e701203954154 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203954586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203954586 : Closed e701203954586 ∧ code e701203954586 = 9497296976794 := by decide
theorem cert_e701203954586 : check e701203954586 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203954906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701203954906 : Closed e701203954906 ∧ code e701203954906 = 9497296977114 := by decide
theorem cert_e701203954906 : check e701203954906 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203954922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701203954922 : Closed e701203954922 ∧ code e701203954922 = 9497296977130 := by decide
theorem cert_e701203954922 : check e701203954922 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203955098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203955098 : Closed e701203955098 ∧ code e701203955098 = 9497296977306 := by decide
theorem cert_e701203955098 : check e701203955098 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e701203974010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.var 0)))
theorem wire_e701203974010 : Closed e701203974010 ∧ code e701203974010 = 9497296996218 := by decide
theorem cert_e701203974010 : check e701203974010 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .smaller = true := by decide
def e701203974106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.var 0)))
theorem wire_e701203974106 : Closed e701203974106 ∧ code e701203974106 = 9497296996314 := by decide
theorem cert_e701203974106 : check e701203974106 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under]] .smaller = true := by decide
def e701203977914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701203977914 : Closed e701203977914 ∧ code e701203977914 = 9497297000122 := by decide
theorem cert_e701203977914 : check e701203977914 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203977962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701203977962 : Closed e701203977962 ∧ code e701203977962 = 9497297000170 := by decide
theorem cert_e701203977962 : check e701203977962 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203978154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701203978154 : Closed e701203978154 ∧ code e701203978154 = 9497297000362 := by decide
theorem cert_e701203978154 : check e701203978154 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e701203978682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701203978682 : Closed e701203978682 ∧ code e701203978682 = 9497297000890 := by decide
theorem cert_e701203978682 : checkPay e701203978682 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e701203978730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701203978730 : Closed e701203978730 ∧ code e701203978730 = 9497297000938 := by decide
theorem cert_e701203978730 : checkPay e701203978730 [[.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[]] = true := by decide
def e701203979162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203979162 : Closed e701203979162 ∧ code e701203979162 = 9497297001370 := by decide
theorem cert_e701203979162 : check e701203979162 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203979882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701203979882 : Closed e701203979882 ∧ code e701203979882 = 9497297002090 := by decide
theorem cert_e701203979882 : check e701203979882 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .sourceHead = true := by decide
def e701203979930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203979930 : Closed e701203979930 ∧ code e701203979930 = 9497297002138 := by decide
theorem cert_e701203979930 : check e701203979930 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e701203989434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701203989434 : Closed e701203989434 ∧ code e701203989434 = 9497297011642 := by decide
theorem cert_e701203989434 : check e701203989434 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under]] .chain = true := by decide
def e701203989466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701203989466 : Closed e701203989466 ∧ code e701203989466 = 9497297011674 := by decide
theorem cert_e701203989466 : check e701203989466 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under]] .chain = true := by decide
def e701203991386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701203991386 : Closed e701203991386 ∧ code e701203991386 = 9497297013594 := by decide
theorem cert_e701203991386 : check e701203991386 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203991402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701203991402 : Closed e701203991402 ∧ code e701203991402 = 9497297013610 := by decide
theorem cert_e701203991402 : check e701203991402 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203991466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701203991466 : Closed e701203991466 ∧ code e701203991466 = 9497297013674 := by decide
theorem cert_e701203991466 : check e701203991466 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203991770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701203991770 : Closed e701203991770 ∧ code e701203991770 = 9497297013978 := by decide
theorem cert_e701203991770 : check e701203991770 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203991786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701203991786 : Closed e701203991786 ∧ code e701203991786 = 9497297013994 := by decide
theorem cert_e701203991786 : check e701203991786 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203991962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203991962 : Closed e701203991962 ∧ code e701203991962 = 9497297014170 := by decide
theorem cert_e701203991962 : check e701203991962 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e701203992170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701203992170 : Closed e701203992170 ∧ code e701203992170 = 9497297014378 := by decide
theorem cert_e701203992170 : check e701203992170 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e701203992218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.var 0))))
theorem wire_e701203992218 : Closed e701203992218 ∧ code e701203992218 = 9497297014426 := by decide
theorem cert_e701203992218 : check e701203992218 [[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under]] .sourceHead = true := by decide
def e701204540858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701204540858 : Closed e701204540858 ∧ code e701204540858 = 9497297563066 := by decide
private def t_e701204540858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem cert_e701204540858 : ¬ IsSelfInterpreter e701204540858 :=
  wSource (t := t_e701204540858) (replay_sound (ps := []) (t := e701204540858) (by decide)) (by decide)
def e701204540890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701204540890 : Closed e701204540890 ∧ code e701204540890 = 9497297563098 := by decide
private def t_e701204540890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem cert_e701204540890 : ¬ IsSelfInterpreter e701204540890 :=
  wSource (t := t_e701204540890) (replay_sound (ps := []) (t := e701204540890) (by decide)) (by decide)
def e701204541114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701204541114 : Closed e701204541114 ∧ code e701204541114 = 9497297563322 := by decide
private def t_e701204541114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem cert_e701204541114 : ¬ IsSelfInterpreter e701204541114 :=
  wSource (t := t_e701204541114) (replay_sound (ps := []) (t := e701204541114) (by decide)) (by decide)
def e701204541162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701204541162 : Closed e701204541162 ∧ code e701204541162 = 9497297563370 := by decide
private def t_e701204541162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem cert_e701204541162 : ¬ IsSelfInterpreter e701204541162 :=
  wSource (t := t_e701204541162) (replay_sound (ps := []) (t := e701204541162) (by decide)) (by decide)
def e701204541274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701204541274 : Closed e701204541274 ∧ code e701204541274 = 9497297563482 := by decide
private def t_e701204541274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem cert_e701204541274 : ¬ IsSelfInterpreter e701204541274 :=
  wSource (t := t_e701204541274) (replay_sound (ps := []) (t := e701204541274) (by decide)) (by decide)
def e701204541290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701204541290 : Closed e701204541290 ∧ code e701204541290 = 9497297563498 := by decide
private def t_e701204541290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem cert_e701204541290 : ¬ IsSelfInterpreter e701204541290 :=
  wSource (t := t_e701204541290) (replay_sound (ps := []) (t := e701204541290) (by decide)) (by decide)
def e701204542394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701204542394 : Closed e701204542394 ∧ code e701204542394 = 9497297564602 := by decide
private def t_e701204542394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem cert_e701204542394 : ¬ IsSelfInterpreter e701204542394 :=
  wSource (t := t_e701204542394) (replay_sound (ps := []) (t := e701204542394) (by decide)) (by decide)
def e701204542426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701204542426 : Closed e701204542426 ∧ code e701204542426 = 9497297564634 := by decide
private def t_e701204542426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem cert_e701204542426 : ¬ IsSelfInterpreter e701204542426 :=
  wSource (t := t_e701204542426) (replay_sound (ps := []) (t := e701204542426) (by decide)) (by decide)
def e701204543930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701204543930 : Closed e701204543930 ∧ code e701204543930 = 9497297566138 := by decide
private def t_e701204543930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem cert_e701204543930 : ¬ IsSelfInterpreter e701204543930 :=
  wSource (t := t_e701204543930) (replay_sound (ps := []) (t := e701204543930) (by decide)) (by decide)
def e701204543978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701204543978 : Closed e701204543978 ∧ code e701204543978 = 9497297566186 := by decide
private def t_e701204543978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem cert_e701204543978 : ¬ IsSelfInterpreter e701204543978 :=
  wSource (t := t_e701204543978) (replay_sound (ps := []) (t := e701204543978) (by decide)) (by decide)
def e701204544730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701204544730 : Closed e701204544730 ∧ code e701204544730 = 9497297566938 := by decide
private def t_e701204544730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem cert_e701204544730 : ¬ IsSelfInterpreter e701204544730 :=
  wSource (t := t_e701204544730) (replay_sound (ps := []) (t := e701204544730) (by decide)) (by decide)
def e701204544746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701204544746 : Closed e701204544746 ∧ code e701204544746 = 9497297566954 := by decide
private def t_e701204544746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem cert_e701204544746 : ¬ IsSelfInterpreter e701204544746 :=
  wSource (t := t_e701204544746) (replay_sound (ps := []) (t := e701204544746) (by decide)) (by decide)
def e701206900154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701206900154 : Closed e701206900154 ∧ code e701206900154 = 9497299922362 := by decide
def e701206900186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701206900186 : Closed e701206900186 ∧ code e701206900186 = 9497299922394 := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e701168184890
#print axioms Blc.Floor43.cert_e701168185030
#print axioms Blc.Floor43.cert_e701168187962
#print axioms Blc.Floor43.cert_e701168188102
#print axioms Blc.Floor43.cert_e701199596458
#print axioms Blc.Floor43.cert_e701199596970
#print axioms Blc.Floor43.cert_e701200608698
#print axioms Blc.Floor43.cert_e701200608730
#print axioms Blc.Floor43.cert_e701200608954
#print axioms Blc.Floor43.cert_e701200609002
#print axioms Blc.Floor43.cert_e701200609114
#print axioms Blc.Floor43.cert_e701200609130
#print axioms Blc.Floor43.cert_e701200610234
#print axioms Blc.Floor43.cert_e701200610266
#print axioms Blc.Floor43.cert_e701200611770
#print axioms Blc.Floor43.cert_e701200611818
#print axioms Blc.Floor43.cert_e701200612570
#print axioms Blc.Floor43.cert_e701200612586
#print axioms Blc.Floor43.cert_e701203791338
#print axioms Blc.Floor43.cert_e701203791594
#print axioms Blc.Floor43.cert_e701203921834
#print axioms Blc.Floor43.cert_e701203922346
#print axioms Blc.Floor43.cert_e701203934826
#print axioms Blc.Floor43.cert_e701203934874
#print axioms Blc.Floor43.cert_e701203936874
#print axioms Blc.Floor43.cert_e701203936922
#print axioms Blc.Floor43.cert_e701204540858
#print axioms Blc.Floor43.cert_e701204540890
#print axioms Blc.Floor43.cert_e701204541114
#print axioms Blc.Floor43.cert_e701204541162
#print axioms Blc.Floor43.cert_e701204541274
#print axioms Blc.Floor43.cert_e701204541290
#print axioms Blc.Floor43.cert_e701204542394
#print axioms Blc.Floor43.cert_e701204542426
#print axioms Blc.Floor43.cert_e701204543930
#print axioms Blc.Floor43.cert_e701204543978
#print axioms Blc.Floor43.cert_e701204544730
#print axioms Blc.Floor43.cert_e701204544746
