import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372946830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422372946830 : Closed e2422372946830 ∧ code e2422372946830 = 11218465969038 := by decide
theorem cert_e2422372946830 : check e2422372946830 [[],[]] .smaller = true := by decide
def e2422372946842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372946842 : Closed e2422372946842 ∧ code e2422372946842 = 11218465969050 := by decide
theorem cert_e2422372946842 : check e2422372946842 [[],[]] .smaller = true := by decide
def e2422372946910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2422372946910 : Closed e2422372946910 ∧ code e2422372946910 = 11218465969118 := by decide
theorem cert_e2422372946910 : check e2422372946910 [[],[]] .three = true := by decide
def e2422372946914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422372946914 : Closed e2422372946914 ∧ code e2422372946914 = 11218465969122 := by decide
theorem cert_e2422372946914 : check e2422372946914 [[],[]] .three = true := by decide
def e2422372946926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2422372946926 : Closed e2422372946926 ∧ code e2422372946926 = 11218465969134 := by decide
theorem cert_e2422372946926 : check e2422372946926 [[],[]] .three = true := by decide
def e2422372947994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422372947994 : Closed e2422372947994 ∧ code e2422372947994 = 11218465970202 := by decide
theorem cert_e2422372947994 : check e2422372947994 [[],[]] .smaller = true := by decide
def e2422372948030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422372948030 : Closed e2422372948030 ∧ code e2422372948030 = 11218465970238 := by decide
theorem cert_e2422372948030 : check e2422372948030 [[],[]] .smaller = true := by decide
def e2422372948078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422372948078 : Closed e2422372948078 ∧ code e2422372948078 = 11218465970286 := by decide
theorem cert_e2422372948078 : check e2422372948078 [[],[]] .smaller = true := by decide
def e2422372948086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422372948086 : Closed e2422372948086 ∧ code e2422372948086 = 11218465970294 := by decide
theorem cert_e2422372948086 : check e2422372948086 [[],[]] .smaller = true := by decide
def e2422372948090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422372948090 : Closed e2422372948090 ∧ code e2422372948090 = 11218465970298 := by decide
theorem cert_e2422372948090 : check e2422372948090 [[],[]] .smaller = true := by decide
def e2422372948330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422372948330 : Closed e2422372948330 ∧ code e2422372948330 = 11218465970538 := by decide
theorem cert_e2422372948330 : check e2422372948330 [[],[]] .smaller = true := by decide
def e2422372948354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422372948354 : Closed e2422372948354 ∧ code e2422372948354 = 11218465970562 := by decide
theorem cert_e2422372948354 : check e2422372948354 [[],[]] .smaller = true := by decide
def e2422372948366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422372948366 : Closed e2422372948366 ∧ code e2422372948366 = 11218465970574 := by decide
theorem cert_e2422372948366 : check e2422372948366 [[],[]] .smaller = true := by decide
def e2422372948378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372948378 : Closed e2422372948378 ∧ code e2422372948378 = 11218465970586 := by decide
theorem cert_e2422372948378 : check e2422372948378 [[],[]] .smaller = true := by decide
def e2422372948422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422372948422 : Closed e2422372948422 ∧ code e2422372948422 = 11218465970630 := by decide
theorem cert_e2422372948422 : check e2422372948422 [[],[]] .smaller = true := by decide
def e2422372948446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372948446 : Closed e2422372948446 ∧ code e2422372948446 = 11218465970654 := by decide
theorem cert_e2422372948446 : check e2422372948446 [[],[]] .three = true := by decide
def e2422372948450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422372948450 : Closed e2422372948450 ∧ code e2422372948450 = 11218465970658 := by decide
theorem cert_e2422372948450 : check e2422372948450 [[],[]] .smaller = true := by decide
def e2422372948462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372948462 : Closed e2422372948462 ∧ code e2422372948462 = 11218465970670 := by decide
theorem cert_e2422372948462 : check e2422372948462 [[],[]] .smaller = true := by decide
def e2422372948470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372948470 : Closed e2422372948470 ∧ code e2422372948470 = 11218465970678 := by decide
theorem cert_e2422372948470 : check e2422372948470 [[],[]] .three = true := by decide
def e2422372949022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422372949022 : Closed e2422372949022 ∧ code e2422372949022 = 11218465971230 := by decide
theorem cert_e2422372949022 : check e2422372949022 [[],[]] .smaller = true := by decide
def e2422372949214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372949214 : Closed e2422372949214 ∧ code e2422372949214 = 11218465971422 := by decide
theorem cert_e2422372949214 : check e2422372949214 [[],[]] .three = true := by decide
def e2422372949218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422372949218 : Closed e2422372949218 ∧ code e2422372949218 = 11218465971426 := by decide
theorem cert_e2422372949218 : check e2422372949218 [[],[]] .smaller = true := by decide
def e2422372949230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372949230 : Closed e2422372949230 ∧ code e2422372949230 = 11218465971438 := by decide
theorem cert_e2422372949230 : check e2422372949230 [[],[]] .smaller = true := by decide
def e2422372949238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372949238 : Closed e2422372949238 ∧ code e2422372949238 = 11218465971446 := by decide
theorem cert_e2422372949238 : check e2422372949238 [[],[]] .smaller = true := by decide
def e2422372949242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372949242 : Closed e2422372949242 ∧ code e2422372949242 = 11218465971450 := by decide
theorem cert_e2422372949242 : check e2422372949242 [[],[]] .three = true := by decide
def e2422372949518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422372949518 : Closed e2422372949518 ∧ code e2422372949518 = 11218465971726 := by decide
theorem cert_e2422372949518 : check e2422372949518 [[],[]] .three = true := by decide
def e2422372949530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372949530 : Closed e2422372949530 ∧ code e2422372949530 = 11218465971738 := by decide
theorem cert_e2422372949530 : check e2422372949530 [[],[]] .three = true := by decide
def e2422372949566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.var 4))))))))
theorem wire_e2422372949566 : Closed e2422372949566 ∧ code e2422372949566 = 11218465971774 := by decide
theorem cert_e2422372949566 : check e2422372949566 [[],[]] .three = true := by decide
def e2422372949602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422372949602 : Closed e2422372949602 ∧ code e2422372949602 = 11218465971810 := by decide
theorem cert_e2422372949602 : check e2422372949602 [[],[]] .three = true := by decide
def e2422372949614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372949614 : Closed e2422372949614 ∧ code e2422372949614 = 11218465971822 := by decide
theorem cert_e2422372949614 : check e2422372949614 [[],[]] .three = true := by decide
def e2422372949622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372949622 : Closed e2422372949622 ∧ code e2422372949622 = 11218465971830 := by decide
theorem cert_e2422372949622 : check e2422372949622 [[],[]] .three = true := by decide
def e2422372949626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372949626 : Closed e2422372949626 ∧ code e2422372949626 = 11218465971834 := by decide
theorem cert_e2422372949626 : check e2422372949626 [[],[]] .three = true := by decide
def e2422372950254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422372950254 : Closed e2422372950254 ∧ code e2422372950254 = 11218465972462 := by decide
theorem cert_e2422372950254 : check e2422372950254 [[],[]] .three = true := by decide
def e2422372950262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422372950262 : Closed e2422372950262 ∧ code e2422372950262 = 11218465972470 := by decide
theorem cert_e2422372950262 : check e2422372950262 [[],[]] .three = true := by decide
def e2422372950266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422372950266 : Closed e2422372950266 ∧ code e2422372950266 = 11218465972474 := by decide
theorem cert_e2422372950266 : check e2422372950266 [[],[]] .three = true := by decide
def e2422372950446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422372950446 : Closed e2422372950446 ∧ code e2422372950446 = 11218465972654 := by decide
theorem cert_e2422372950446 : check e2422372950446 [[],[]] .three = true := by decide
def e2422372950454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2422372950454 : Closed e2422372950454 ∧ code e2422372950454 = 11218465972662 := by decide
theorem cert_e2422372950454 : check e2422372950454 [[],[]] .three = true := by decide
def e2422372950458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422372950458 : Closed e2422372950458 ∧ code e2422372950458 = 11218465972666 := by decide
theorem cert_e2422372950458 : check e2422372950458 [[],[]] .three = true := by decide
def e2422372950486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2422372950486 : Closed e2422372950486 ∧ code e2422372950486 = 11218465972694 := by decide
theorem cert_e2422372950486 : check e2422372950486 [[],[]] .three = true := by decide
def e2422372950506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422372950506 : Closed e2422372950506 ∧ code e2422372950506 = 11218465972714 := by decide
theorem cert_e2422372950506 : check e2422372950506 [[],[]] .three = true := by decide
def e2422372950638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372950638 : Closed e2422372950638 ∧ code e2422372950638 = 11218465972846 := by decide
theorem cert_e2422372950638 : check e2422372950638 [[],[]] .three = true := by decide
def e2422372950646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372950646 : Closed e2422372950646 ∧ code e2422372950646 = 11218465972854 := by decide
theorem cert_e2422372950646 : check e2422372950646 [[],[]] .three = true := by decide
def e2422372950650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372950650 : Closed e2422372950650 ∧ code e2422372950650 = 11218465972858 := by decide
theorem cert_e2422372950650 : check e2422372950650 [[],[]] .three = true := by decide
def e2422372950814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422372950814 : Closed e2422372950814 ∧ code e2422372950814 = 11218465973022 := by decide
theorem cert_e2422372950814 : check e2422372950814 [[],[]] .three = true := by decide
def e2422372950838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372950838 : Closed e2422372950838 ∧ code e2422372950838 = 11218465973046 := by decide
theorem cert_e2422372950838 : check e2422372950838 [[],[]] .three = true := by decide
def e2422372950842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372950842 : Closed e2422372950842 ∧ code e2422372950842 = 11218465973050 := by decide
theorem cert_e2422372950842 : check e2422372950842 [[],[]] .three = true := by decide
def e2422372950926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422372950926 : Closed e2422372950926 ∧ code e2422372950926 = 11218465973134 := by decide
theorem cert_e2422372950926 : check e2422372950926 [[],[]] .three = true := by decide
def e2422372950938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372950938 : Closed e2422372950938 ∧ code e2422372950938 = 11218465973146 := by decide
theorem cert_e2422372950938 : check e2422372950938 [[],[]] .three = true := by decide
def e2422372950982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422372950982 : Closed e2422372950982 ∧ code e2422372950982 = 11218465973190 := by decide
theorem cert_e2422372950982 : check e2422372950982 [[],[]] .three = true := by decide
def e2422372951006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e2422372951006 : Closed e2422372951006 ∧ code e2422372951006 = 11218465973214 := by decide
theorem cert_e2422372951006 : check e2422372951006 [[],[]] .three = true := by decide
def e2422372951022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e2422372951022 : Closed e2422372951022 ∧ code e2422372951022 = 11218465973230 := by decide
theorem cert_e2422372951022 : check e2422372951022 [[],[]] .three = true := by decide
def e2422372951598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372951598 : Closed e2422372951598 ∧ code e2422372951598 = 11218465973806 := by decide
theorem cert_e2422372951598 : check e2422372951598 [[],[]] .three = true := by decide
def e2422372951606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422372951606 : Closed e2422372951606 ∧ code e2422372951606 = 11218465973814 := by decide
theorem cert_e2422372951606 : check e2422372951606 [[],[]] .three = true := by decide
def e2422372951610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422372951610 : Closed e2422372951610 ∧ code e2422372951610 = 11218465973818 := by decide
theorem cert_e2422372951610 : check e2422372951610 [[],[]] .three = true := by decide
def e2422372951694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422372951694 : Closed e2422372951694 ∧ code e2422372951694 = 11218465973902 := by decide
theorem cert_e2422372951694 : check e2422372951694 [[],[]] .three = true := by decide
def e2422372951750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422372951750 : Closed e2422372951750 ∧ code e2422372951750 = 11218465973958 := by decide
theorem cert_e2422372951750 : check e2422372951750 [[],[]] .three = true := by decide
def e2422372951774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2422372951774 : Closed e2422372951774 ∧ code e2422372951774 = 11218465973982 := by decide
theorem cert_e2422372951774 : check e2422372951774 [[],[]] .three = true := by decide
def e2422372951778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422372951778 : Closed e2422372951778 ∧ code e2422372951778 = 11218465973986 := by decide
theorem cert_e2422372951778 : check e2422372951778 [[],[]] .three = true := by decide
def e2422372951790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2422372951790 : Closed e2422372951790 ∧ code e2422372951790 = 11218465973998 := by decide
theorem cert_e2422372951790 : check e2422372951790 [[],[]] .three = true := by decide
def e2422372951798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2422372951798 : Closed e2422372951798 ∧ code e2422372951798 = 11218465974006 := by decide
theorem cert_e2422372951798 : check e2422372951798 [[],[]] .three = true := by decide
def e2422372951830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372951830 : Closed e2422372951830 ∧ code e2422372951830 = 11218465974038 := by decide
theorem cert_e2422372951830 : check e2422372951830 [[],[]] .three = true := by decide
def e2422372951834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422372951834 : Closed e2422372951834 ∧ code e2422372951834 = 11218465974042 := by decide
theorem cert_e2422372951834 : check e2422372951834 [[],[]] .three = true := by decide
def e2422372951878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422372951878 : Closed e2422372951878 ∧ code e2422372951878 = 11218465974086 := by decide
theorem cert_e2422372951878 : check e2422372951878 [[],[]] .three = true := by decide
def e2422372951902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2422372951902 : Closed e2422372951902 ∧ code e2422372951902 = 11218465974110 := by decide
theorem cert_e2422372951902 : check e2422372951902 [[],[]] .three = true := by decide
def e2422372951906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422372951906 : Closed e2422372951906 ∧ code e2422372951906 = 11218465974114 := by decide
theorem cert_e2422372951906 : check e2422372951906 [[],[]] .three = true := by decide
def e2422372951918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2422372951918 : Closed e2422372951918 ∧ code e2422372951918 = 11218465974126 := by decide
theorem cert_e2422372951918 : check e2422372951918 [[],[]] .three = true := by decide
def e2422372951926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2422372951926 : Closed e2422372951926 ∧ code e2422372951926 = 11218465974134 := by decide
theorem cert_e2422372951926 : check e2422372951926 [[],[]] .three = true := by decide
def e2422372951930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2422372951930 : Closed e2422372951930 ∧ code e2422372951930 = 11218465974138 := by decide
theorem cert_e2422372951930 : check e2422372951930 [[],[]] .three = true := by decide
def e2422372951946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372951946 : Closed e2422372951946 ∧ code e2422372951946 = 11218465974154 := by decide
theorem cert_e2422372951946 : check e2422372951946 [[],[]] .three = true := by decide
def e2422372951970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422372951970 : Closed e2422372951970 ∧ code e2422372951970 = 11218465974178 := by decide
theorem cert_e2422372951970 : check e2422372951970 [[],[]] .three = true := by decide
def e2422372951982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2422372951982 : Closed e2422372951982 ∧ code e2422372951982 = 11218465974190 := by decide
theorem cert_e2422372951982 : check e2422372951982 [[],[]] .three = true := by decide
def e2422372951990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2422372951990 : Closed e2422372951990 ∧ code e2422372951990 = 11218465974198 := by decide
theorem cert_e2422372951990 : check e2422372951990 [[],[]] .three = true := by decide
def e2422372951994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2422372951994 : Closed e2422372951994 ∧ code e2422372951994 = 11218465974202 := by decide
theorem cert_e2422372951994 : check e2422372951994 [[],[]] .three = true := by decide
def e2422372952022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2422372952022 : Closed e2422372952022 ∧ code e2422372952022 = 11218465974230 := by decide
theorem cert_e2422372952022 : check e2422372952022 [[],[]] .three = true := by decide
def e2422372952026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2422372952026 : Closed e2422372952026 ∧ code e2422372952026 = 11218465974234 := by decide
theorem cert_e2422372952026 : check e2422372952026 [[],[]] .three = true := by decide
def e2422372952126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422372952126 : Closed e2422372952126 ∧ code e2422372952126 = 11218465974334 := by decide
theorem cert_e2422372952126 : check e2422372952126 [[],[]] .three = true := by decide
def e2422372952174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422372952174 : Closed e2422372952174 ∧ code e2422372952174 = 11218465974382 := by decide
theorem cert_e2422372952174 : check e2422372952174 [[],[]] .three = true := by decide
def e2422372952186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422372952186 : Closed e2422372952186 ∧ code e2422372952186 = 11218465974394 := by decide
theorem cert_e2422372952186 : check e2422372952186 [[],[]] .three = true := by decide
def e2422372952462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422372952462 : Closed e2422372952462 ∧ code e2422372952462 = 11218465974670 := by decide
theorem cert_e2422372952462 : check e2422372952462 [[],[]] .three = true := by decide
def e2422372952518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422372952518 : Closed e2422372952518 ∧ code e2422372952518 = 11218465974726 := by decide
theorem cert_e2422372952518 : check e2422372952518 [[],[]] .three = true := by decide
def e2422372952542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372952542 : Closed e2422372952542 ∧ code e2422372952542 = 11218465974750 := by decide
theorem cert_e2422372952542 : check e2422372952542 [[],[]] .three = true := by decide
def e2422372952546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422372952546 : Closed e2422372952546 ∧ code e2422372952546 = 11218465974754 := by decide
theorem cert_e2422372952546 : check e2422372952546 [[],[]] .three = true := by decide
def e2422372952558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372952558 : Closed e2422372952558 ∧ code e2422372952558 = 11218465974766 := by decide
theorem cert_e2422372952558 : check e2422372952558 [[],[]] .three = true := by decide
def e2422372952566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372952566 : Closed e2422372952566 ∧ code e2422372952566 = 11218465974774 := by decide
theorem cert_e2422372952566 : check e2422372952566 [[],[]] .three = true := by decide
def e2422372953118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422372953118 : Closed e2422372953118 ∧ code e2422372953118 = 11218465975326 := by decide
theorem cert_e2422372953118 : check e2422372953118 [[],[]] .three = true := by decide
def e2422372953142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422372953142 : Closed e2422372953142 ∧ code e2422372953142 = 11218465975350 := by decide
theorem cert_e2422372953142 : check e2422372953142 [[],[]] .three = true := by decide
def e2422372953146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422372953146 : Closed e2422372953146 ∧ code e2422372953146 = 11218465975354 := by decide
theorem cert_e2422372953146 : check e2422372953146 [[],[]] .three = true := by decide
def e2422372953286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422372953286 : Closed e2422372953286 ∧ code e2422372953286 = 11218465975494 := by decide
theorem cert_e2422372953286 : check e2422372953286 [[],[]] .three = true := by decide
def e2422372953310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372953310 : Closed e2422372953310 ∧ code e2422372953310 = 11218465975518 := by decide
theorem cert_e2422372953310 : check e2422372953310 [[],[]] .three = true := by decide
def e2422372953314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422372953314 : Closed e2422372953314 ∧ code e2422372953314 = 11218465975522 := by decide
theorem cert_e2422372953314 : check e2422372953314 [[],[]] .three = true := by decide
def e2422372953326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372953326 : Closed e2422372953326 ∧ code e2422372953326 = 11218465975534 := by decide
theorem cert_e2422372953326 : check e2422372953326 [[],[]] .three = true := by decide
def e2422372953334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372953334 : Closed e2422372953334 ∧ code e2422372953334 = 11218465975542 := by decide
theorem cert_e2422372953334 : check e2422372953334 [[],[]] .three = true := by decide
def e2422372953338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372953338 : Closed e2422372953338 ∧ code e2422372953338 = 11218465975546 := by decide
theorem cert_e2422372953338 : check e2422372953338 [[],[]] .three = true := by decide
def e2422372953614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422372953614 : Closed e2422372953614 ∧ code e2422372953614 = 11218465975822 := by decide
theorem cert_e2422372953614 : check e2422372953614 [[],[]] .three = true := by decide
def e2422372953626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372953626 : Closed e2422372953626 ∧ code e2422372953626 = 11218465975834 := by decide
theorem cert_e2422372953626 : check e2422372953626 [[],[]] .three = true := by decide
def e2422372953662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e2422372953662 : Closed e2422372953662 ∧ code e2422372953662 = 11218465975870 := by decide
theorem cert_e2422372953662 : check e2422372953662 [[],[]] .three = true := by decide
def e2422372953698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422372953698 : Closed e2422372953698 ∧ code e2422372953698 = 11218465975906 := by decide
theorem cert_e2422372953698 : check e2422372953698 [[],[]] .three = true := by decide
def e2422372953710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372953710 : Closed e2422372953710 ∧ code e2422372953710 = 11218465975918 := by decide
theorem cert_e2422372953710 : check e2422372953710 [[],[]] .three = true := by decide
def e2422372953718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372953718 : Closed e2422372953718 ∧ code e2422372953718 = 11218465975926 := by decide
theorem cert_e2422372953718 : check e2422372953718 [[],[]] .three = true := by decide
def e2422372953722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372953722 : Closed e2422372953722 ∧ code e2422372953722 = 11218465975930 := by decide
theorem cert_e2422372953722 : check e2422372953722 [[],[]] .three = true := by decide
def e2422372953886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e2422372953886 : Closed e2422372953886 ∧ code e2422372953886 = 11218465976094 := by decide
theorem cert_e2422372953886 : check e2422372953886 [[],[]] .three = true := by decide
def e2422372953910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372953910 : Closed e2422372953910 ∧ code e2422372953910 = 11218465976118 := by decide
theorem cert_e2422372953910 : check e2422372953910 [[],[]] .three = true := by decide
def e2422372953914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372953914 : Closed e2422372953914 ∧ code e2422372953914 = 11218465976122 := by decide
theorem cert_e2422372953914 : check e2422372953914 [[],[]] .three = true := by decide
def e2422372959918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 2)))))))
theorem wire_e2422372959918 : Closed e2422372959918 ∧ code e2422372959918 = 11218465982126 := by decide
theorem cert_e2422372959918 : check e2422372959918 [[],[]] .smaller = true := by decide
def e2422372959930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)) (.var 0)))))))
theorem wire_e2422372959930 : Closed e2422372959930 ∧ code e2422372959930 = 11218465982138 := by decide
theorem cert_e2422372959930 : check e2422372959930 [[],[]] .smaller = true := by decide
def e2422372960686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372960686 : Closed e2422372960686 ∧ code e2422372960686 = 11218465982894 := by decide
theorem cert_e2422372960686 : check e2422372960686 [[],[]] .smaller = true := by decide
def e2422372960698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372960698 : Closed e2422372960698 ∧ code e2422372960698 = 11218465982906 := by decide
theorem cert_e2422372960698 : check e2422372960698 [[],[]] .smaller = true := by decide
def e2422372960746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372960746 : Closed e2422372960746 ∧ code e2422372960746 = 11218465982954 := by decide
theorem cert_e2422372960746 : check e2422372960746 [[],[]] .smaller = true := by decide
def e2422372960878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372960878 : Closed e2422372960878 ∧ code e2422372960878 = 11218465983086 := by decide
theorem cert_e2422372960878 : check e2422372960878 [[],[]] .smaller = true := by decide
def e2422372960890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372960890 : Closed e2422372960890 ∧ code e2422372960890 = 11218465983098 := by decide
theorem cert_e2422372960890 : check e2422372960890 [[],[]] .smaller = true := by decide
def e2422372961178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372961178 : Closed e2422372961178 ∧ code e2422372961178 = 11218465983386 := by decide
theorem cert_e2422372961178 : check e2422372961178 [[],[]] .smaller = true := by decide
def e2422372962014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1)) (.var 3)))))))
theorem wire_e2422372962014 : Closed e2422372962014 ∧ code e2422372962014 = 11218465984222 := by decide
theorem cert_e2422372962014 : check e2422372962014 [[],[]] .three = true := by decide
def e2422372962030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 2)))))))
theorem wire_e2422372962030 : Closed e2422372962030 ∧ code e2422372962030 = 11218465984238 := by decide
theorem cert_e2422372962030 : check e2422372962030 [[],[]] .smaller = true := by decide
def e2422372962038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 3)) (.var 1)))))))
theorem wire_e2422372962038 : Closed e2422372962038 ∧ code e2422372962038 = 11218465984246 := by decide
theorem cert_e2422372962038 : check e2422372962038 [[],[]] .three = true := by decide
def e2422372962142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372962142 : Closed e2422372962142 ∧ code e2422372962142 = 11218465984350 := by decide
theorem cert_e2422372962142 : check e2422372962142 [[],[]] .three = true := by decide
def e2422372962170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372962170 : Closed e2422372962170 ∧ code e2422372962170 = 11218465984378 := by decide
theorem cert_e2422372962170 : check e2422372962170 [[],[]] .three = true := by decide
def e2422372962222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372962222 : Closed e2422372962222 ∧ code e2422372962222 = 11218465984430 := by decide
theorem cert_e2422372962222 : check e2422372962222 [[],[]] .smaller = true := by decide
def e2422372962234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372962234 : Closed e2422372962234 ∧ code e2422372962234 = 11218465984442 := by decide
theorem cert_e2422372962234 : check e2422372962234 [[],[]] .smaller = true := by decide
def e2422372962262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372962262 : Closed e2422372962262 ∧ code e2422372962262 = 11218465984470 := by decide
theorem cert_e2422372962262 : check e2422372962262 [[],[]] .three = true := by decide
def e2422372962266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372962266 : Closed e2422372962266 ∧ code e2422372962266 = 11218465984474 := by decide
theorem cert_e2422372962266 : check e2422372962266 [[],[]] .three = true := by decide
def e2422372965214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372965214 : Closed e2422372965214 ∧ code e2422372965214 = 11218465987422 := by decide
theorem cert_e2422372965214 : check e2422372965214 [[],[]] .three = true := by decide
def e2422372965230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372965230 : Closed e2422372965230 ∧ code e2422372965230 = 11218465987438 := by decide
theorem cert_e2422372965230 : check e2422372965230 [[],[]] .smaller = true := by decide
def e2422372965238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372965238 : Closed e2422372965238 ∧ code e2422372965238 = 11218465987446 := by decide
theorem cert_e2422372965238 : check e2422372965238 [[],[]] .smaller = true := by decide
def e2422372965242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372965242 : Closed e2422372965242 ∧ code e2422372965242 = 11218465987450 := by decide
theorem cert_e2422372965242 : check e2422372965242 [[],[]] .three = true := by decide
def e2422372965294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372965294 : Closed e2422372965294 ∧ code e2422372965294 = 11218465987502 := by decide
theorem cert_e2422372965294 : check e2422372965294 [[],[]] .smaller = true := by decide
def e2422372965306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372965306 : Closed e2422372965306 ∧ code e2422372965306 = 11218465987514 := by decide
theorem cert_e2422372965306 : check e2422372965306 [[],[]] .smaller = true := by decide
def e2422372965334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372965334 : Closed e2422372965334 ∧ code e2422372965334 = 11218465987542 := by decide
theorem cert_e2422372965334 : check e2422372965334 [[],[]] .smaller = true := by decide
def e2422372965338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372965338 : Closed e2422372965338 ∧ code e2422372965338 = 11218465987546 := by decide
theorem cert_e2422372965338 : check e2422372965338 [[],[]] .smaller = true := by decide
def e2422372965354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 4)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372965354 : Closed e2422372965354 ∧ code e2422372965354 = 11218465987562 := by decide
theorem cert_e2422372965354 : check e2422372965354 [[],[]] .three = true := by decide
def e2422372965726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372965726 : Closed e2422372965726 ∧ code e2422372965726 = 11218465987934 := by decide
theorem cert_e2422372965726 : check e2422372965726 [[],[]] .three = true := by decide
def e2422372965742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372965742 : Closed e2422372965742 ∧ code e2422372965742 = 11218465987950 := by decide
theorem cert_e2422372965742 : check e2422372965742 [[],[]] .smaller = true := by decide
def e2422372965750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372965750 : Closed e2422372965750 ∧ code e2422372965750 = 11218465987958 := by decide
theorem cert_e2422372965750 : check e2422372965750 [[],[]] .smaller = true := by decide
def e2422372965754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372965754 : Closed e2422372965754 ∧ code e2422372965754 = 11218465987962 := by decide
theorem cert_e2422372965754 : check e2422372965754 [[],[]] .three = true := by decide
def e2422372965806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372965806 : Closed e2422372965806 ∧ code e2422372965806 = 11218465988014 := by decide
theorem cert_e2422372965806 : check e2422372965806 [[],[]] .smaller = true := by decide
def e2422372965818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372965818 : Closed e2422372965818 ∧ code e2422372965818 = 11218465988026 := by decide
theorem cert_e2422372965818 : check e2422372965818 [[],[]] .smaller = true := by decide
def e2422372965866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372965866 : Closed e2422372965866 ∧ code e2422372965866 = 11218465988074 := by decide
theorem cert_e2422372965866 : check e2422372965866 [[],[]] .smaller = true := by decide
def e2422372966062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372966062 : Closed e2422372966062 ∧ code e2422372966062 = 11218465988270 := by decide
theorem cert_e2422372966062 : check e2422372966062 [[],[]] .smaller = true := by decide
def e2422372966074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372966074 : Closed e2422372966074 ∧ code e2422372966074 = 11218465988282 := by decide
theorem cert_e2422372966074 : check e2422372966074 [[],[]] .smaller = true := by decide
def e2422372966230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372966230 : Closed e2422372966230 ∧ code e2422372966230 = 11218465988438 := by decide
theorem cert_e2422372966230 : check e2422372966230 [[],[]] .smaller = true := by decide
def e2422372966234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372966234 : Closed e2422372966234 ∧ code e2422372966234 = 11218465988442 := by decide
theorem cert_e2422372966234 : check e2422372966234 [[],[]] .smaller = true := by decide
def e2422372966250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372966250 : Closed e2422372966250 ∧ code e2422372966250 = 11218465988458 := by decide
theorem cert_e2422372966250 : check e2422372966250 [[],[]] .smaller = true := by decide
def e2422372966314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 4) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372966314 : Closed e2422372966314 ∧ code e2422372966314 = 11218465988522 := by decide
theorem cert_e2422372966314 : check e2422372966314 [[],[]] .three = true := by decide
def e2422372968158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2422372968158 : Closed e2422372968158 ∧ code e2422372968158 = 11218465990366 := by decide
theorem cert_e2422372968158 : check e2422372968158 [[],[]] .three = true := by decide
def e2422372968174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2422372968174 : Closed e2422372968174 ∧ code e2422372968174 = 11218465990382 := by decide
theorem cert_e2422372968174 : check e2422372968174 [[],[]] .smaller = true := by decide
def e2422372968182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2422372968182 : Closed e2422372968182 ∧ code e2422372968182 = 11218465990390 := by decide
theorem cert_e2422372968182 : check e2422372968182 [[],[]] .three = true := by decide
def e2422372968286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2422372968286 : Closed e2422372968286 ∧ code e2422372968286 = 11218465990494 := by decide
theorem cert_e2422372968286 : check e2422372968286 [[],[]] .three = true := by decide
def e2422372968314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2422372968314 : Closed e2422372968314 ∧ code e2422372968314 = 11218465990522 := by decide
theorem cert_e2422372968314 : check e2422372968314 [[],[]] .three = true := by decide
def e2422372968366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2422372968366 : Closed e2422372968366 ∧ code e2422372968366 = 11218465990574 := by decide
theorem cert_e2422372968366 : check e2422372968366 [[],[]] .smaller = true := by decide
def e2422372968378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2422372968378 : Closed e2422372968378 ∧ code e2422372968378 = 11218465990586 := by decide
theorem cert_e2422372968378 : check e2422372968378 [[],[]] .smaller = true := by decide
def e2422372968406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2422372968406 : Closed e2422372968406 ∧ code e2422372968406 = 11218465990614 := by decide
theorem cert_e2422372968406 : check e2422372968406 [[],[]] .three = true := by decide
def e2422372968410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2422372968410 : Closed e2422372968410 ∧ code e2422372968410 = 11218465990618 := by decide
theorem cert_e2422372968410 : check e2422372968410 [[],[]] .three = true := by decide
def e2422372968926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372968926 : Closed e2422372968926 ∧ code e2422372968926 = 11218465991134 := by decide
theorem cert_e2422372968926 : check e2422372968926 [[],[]] .three = true := by decide
def e2422372968942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372968942 : Closed e2422372968942 ∧ code e2422372968942 = 11218465991150 := by decide
theorem cert_e2422372968942 : check e2422372968942 [[],[]] .smaller = true := by decide
def e2422372968950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372968950 : Closed e2422372968950 ∧ code e2422372968950 = 11218465991158 := by decide
theorem cert_e2422372968950 : check e2422372968950 [[],[]] .three = true := by decide
def e2422372969694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372969694 : Closed e2422372969694 ∧ code e2422372969694 = 11218465991902 := by decide
theorem cert_e2422372969694 : check e2422372969694 [[],[]] .three = true := by decide
def e2422372969722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372969722 : Closed e2422372969722 ∧ code e2422372969722 = 11218465991930 := by decide
theorem cert_e2422372969722 : check e2422372969722 [[],[]] .three = true := by decide
def e2422372970094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372970094 : Closed e2422372970094 ∧ code e2422372970094 = 11218465992302 := by decide
theorem cert_e2422372970094 : check e2422372970094 [[],[]] .smaller = true := by decide
def e2422372970106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372970106 : Closed e2422372970106 ∧ code e2422372970106 = 11218465992314 := by decide
theorem cert_e2422372970106 : check e2422372970106 [[],[]] .smaller = true := by decide
def e2422372970294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372970294 : Closed e2422372970294 ∧ code e2422372970294 = 11218465992502 := by decide
theorem cert_e2422372970294 : check e2422372970294 [[],[]] .three = true := by decide
def e2422372970298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372970298 : Closed e2422372970298 ∧ code e2422372970298 = 11218465992506 := by decide
theorem cert_e2422372970298 : check e2422372970298 [[],[]] .three = true := by decide
end Blc.Floor43
