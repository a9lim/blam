import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407384698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407384698 : Closed e2422407384698 ∧ code e2422407384698 = 11218500406906 := by decide
theorem cert_e2422407384698 : check e2422407384698 [[],[]] .chain = true := by decide
def e2422407384838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407384838 : Closed e2422407384838 ∧ code e2422407384838 = 11218500407046 := by decide
theorem cert_e2422407384838 : check e2422407384838 [[],[]] .chain = true := by decide
def e2422407384862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e2422407384862 : Closed e2422407384862 ∧ code e2422407384862 = 11218500407070 := by decide
theorem cert_e2422407384862 : check e2422407384862 [[],[]] .sourceHead = true := by decide
def e2422407384886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407384886 : Closed e2422407384886 ∧ code e2422407384886 = 11218500407094 := by decide
theorem cert_e2422407384886 : check e2422407384886 [[],[]] .chain = true := by decide
def e2422407384890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407384890 : Closed e2422407384890 ∧ code e2422407384890 = 11218500407098 := by decide
theorem cert_e2422407384890 : check e2422407384890 [[],[]] .chain = true := by decide
def e2422407389662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407389662 : Closed e2422407389662 ∧ code e2422407389662 = 11218500411870 := by decide
theorem cert_e2422407389662 : check e2422407389662 [[],[]] .chain = true := by decide
def e2422407389686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407389686 : Closed e2422407389686 ∧ code e2422407389686 = 11218500411894 := by decide
theorem cert_e2422407389686 : check e2422407389686 [[],[]] .chain = true := by decide
def e2422407390638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407390638 : Closed e2422407390638 ∧ code e2422407390638 = 11218500412846 := by decide
theorem cert_e2422407390638 : check e2422407390638 [[],[]] .chain = true := by decide
def e2422407390650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407390650 : Closed e2422407390650 ∧ code e2422407390650 = 11218500412858 := by decide
theorem cert_e2422407390650 : check e2422407390650 [[],[]] .chain = true := by decide
def e2422407390698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407390698 : Closed e2422407390698 ∧ code e2422407390698 = 11218500412906 := by decide
theorem cert_e2422407390698 : check e2422407390698 [[],[]] .chain = true := by decide
def e2422407390830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407390830 : Closed e2422407390830 ∧ code e2422407390830 = 11218500413038 := by decide
theorem cert_e2422407390830 : check e2422407390830 [[],[]] .chain = true := by decide
def e2422407390842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407390842 : Closed e2422407390842 ∧ code e2422407390842 = 11218500413050 := by decide
theorem cert_e2422407390842 : check e2422407390842 [[],[]] .chain = true := by decide
def e2422407391130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407391130 : Closed e2422407391130 ∧ code e2422407391130 = 11218500413338 := by decide
theorem cert_e2422407391130 : check e2422407391130 [[],[]] .chain = true := by decide
def e2422407393310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e2422407393310 : Closed e2422407393310 ∧ code e2422407393310 = 11218500415518 := by decide
theorem cert_e2422407393310 : check e2422407393310 [[],[]] .chain = true := by decide
def e2422407393506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422407393506 : Closed e2422407393506 ∧ code e2422407393506 = 11218500415714 := by decide
theorem cert_e2422407393506 : check e2422407393506 [[],[]] .chain = true := by decide
def e2422407393518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407393518 : Closed e2422407393518 ∧ code e2422407393518 = 11218500415726 := by decide
theorem cert_e2422407393518 : check e2422407393518 [[],[]] .chain = true := by decide
def e2422407393526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407393526 : Closed e2422407393526 ∧ code e2422407393526 = 11218500415734 := by decide
theorem cert_e2422407393526 : check e2422407393526 [[],[]] .chain = true := by decide
def e2422407394006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407394006 : Closed e2422407394006 ∧ code e2422407394006 = 11218500416214 := by decide
theorem cert_e2422407394006 : check e2422407394006 [[],[]] .chain = true := by decide
def e2422407394010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407394010 : Closed e2422407394010 ∧ code e2422407394010 = 11218500416218 := by decide
theorem cert_e2422407394010 : check e2422407394010 [[],[]] .chain = true := by decide
def e2422407394026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407394026 : Closed e2422407394026 ∧ code e2422407394026 = 11218500416234 := by decide
theorem cert_e2422407394026 : check e2422407394026 [[],[]] .chain = true := by decide
def e2422407394054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407394054 : Closed e2422407394054 ∧ code e2422407394054 = 11218500416262 := by decide
theorem cert_e2422407394054 : check e2422407394054 [[],[]] .chain = true := by decide
def e2422407394078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407394078 : Closed e2422407394078 ∧ code e2422407394078 = 11218500416286 := by decide
theorem cert_e2422407394078 : check e2422407394078 [[],[]] .sourceHead = true := by decide
def e2422407394102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407394102 : Closed e2422407394102 ∧ code e2422407394102 = 11218500416310 := by decide
theorem cert_e2422407394102 : check e2422407394102 [[],[]] .chain = true := by decide
def e2422407394106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407394106 : Closed e2422407394106 ∧ code e2422407394106 = 11218500416314 := by decide
theorem cert_e2422407394106 : check e2422407394106 [[],[]] .chain = true := by decide
def e2422407394202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407394202 : Closed e2422407394202 ∧ code e2422407394202 = 11218500416410 := by decide
theorem cert_e2422407394202 : check e2422407394202 [[],[]] .chain = true := by decide
def e2422407394246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407394246 : Closed e2422407394246 ∧ code e2422407394246 = 11218500416454 := by decide
theorem cert_e2422407394246 : check e2422407394246 [[],[]] .sourceHead = true := by decide
def e2422407397482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e2422407397482 : Closed e2422407397482 ∧ code e2422407397482 = 11218500419690 := by decide
theorem cert_e2422407397482 : check e2422407397482 [[],[]] .sourceHead = true := by decide
def e2422407397530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407397530 : Closed e2422407397530 ∧ code e2422407397530 = 11218500419738 := by decide
theorem cert_e2422407397530 : check e2422407397530 [[],[]] .chain = true := by decide
def e2422407397622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e2422407397622 : Closed e2422407397622 ∧ code e2422407397622 = 11218500419830 := by decide
theorem cert_e2422407397622 : check e2422407397622 [[],[]] .chain = true := by decide
def e2422407397626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407397626 : Closed e2422407397626 ∧ code e2422407397626 = 11218500419834 := by decide
theorem cert_e2422407397626 : check e2422407397626 [[],[]] .chain = true := by decide
def e2422407397818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2422407397818 : Closed e2422407397818 ∧ code e2422407397818 = 11218500420026 := by decide
theorem cert_e2422407397818 : check e2422407397818 [[],[]] .chain = true := by decide
def e2422407397850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e2422407397850 : Closed e2422407397850 ∧ code e2422407397850 = 11218500420058 := by decide
theorem cert_e2422407397850 : check e2422407397850 [[],[]] .sourceHead = true := by decide
def e2422407397866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2422407397866 : Closed e2422407397866 ∧ code e2422407397866 = 11218500420074 := by decide
theorem cert_e2422407397866 : check e2422407397866 [[],[]] .chain = true := by decide
def e2422407397998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407397998 : Closed e2422407397998 ∧ code e2422407397998 = 11218500420206 := by decide
theorem cert_e2422407397998 : check e2422407397998 [[],[]] .sourceHead = true := by decide
def e2422407398010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407398010 : Closed e2422407398010 ∧ code e2422407398010 = 11218500420218 := by decide
theorem cert_e2422407398010 : check e2422407398010 [[],[]] .sourceHead = true := by decide
def e2422407398198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407398198 : Closed e2422407398198 ∧ code e2422407398198 = 11218500420406 := by decide
theorem cert_e2422407398198 : check e2422407398198 [[],[]] .chain = true := by decide
def e2422407398202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407398202 : Closed e2422407398202 ∧ code e2422407398202 = 11218500420410 := by decide
theorem cert_e2422407398202 : check e2422407398202 [[],[]] .chain = true := by decide
def e2422407398286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2422407398286 : Closed e2422407398286 ∧ code e2422407398286 = 11218500420494 := by decide
theorem cert_e2422407398286 : check e2422407398286 [[],[]] .chain = true := by decide
def e2422407398298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407398298 : Closed e2422407398298 ∧ code e2422407398298 = 11218500420506 := by decide
theorem cert_e2422407398298 : check e2422407398298 [[],[]] .chain = true := by decide
def e2422407398342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407398342 : Closed e2422407398342 ∧ code e2422407398342 = 11218500420550 := by decide
theorem cert_e2422407398342 : check e2422407398342 [[],[]] .chain = true := by decide
def e2422407398826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e2422407398826 : Closed e2422407398826 ∧ code e2422407398826 = 11218500421034 := by decide
theorem cert_e2422407398826 : check e2422407398826 [[],[]] .sourceHead = true := by decide
def e2422407398970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407398970 : Closed e2422407398970 ∧ code e2422407398970 = 11218500421178 := by decide
theorem cert_e2422407398970 : check e2422407398970 [[],[]] .chain = true := by decide
def e2422407399018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407399018 : Closed e2422407399018 ∧ code e2422407399018 = 11218500421226 := by decide
theorem cert_e2422407399018 : check e2422407399018 [[],[]] .sourceHead = true := by decide
def e2422407399066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407399066 : Closed e2422407399066 ∧ code e2422407399066 = 11218500421274 := by decide
theorem cert_e2422407399066 : check e2422407399066 [[],[]] .sourceHead = true := by decide
def e2422407399110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407399110 : Closed e2422407399110 ∧ code e2422407399110 = 11218500421318 := by decide
theorem cert_e2422407399110 : check e2422407399110 [[],[]] .chain = true := by decide
def e2422407399190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407399190 : Closed e2422407399190 ∧ code e2422407399190 = 11218500421398 := by decide
theorem cert_e2422407399190 : check e2422407399190 [[],[]] .chain = true := by decide
def e2422407399194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407399194 : Closed e2422407399194 ∧ code e2422407399194 = 11218500421402 := by decide
theorem cert_e2422407399194 : check e2422407399194 [[],[]] .chain = true := by decide
def e2422407399238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407399238 : Closed e2422407399238 ∧ code e2422407399238 = 11218500421446 := by decide
theorem cert_e2422407399238 : check e2422407399238 [[],[]] .chain = true := by decide
def e2422407399266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407399266 : Closed e2422407399266 ∧ code e2422407399266 = 11218500421474 := by decide
theorem cert_e2422407399266 : check e2422407399266 [[],[]] .chain = true := by decide
def e2422407399278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422407399278 : Closed e2422407399278 ∧ code e2422407399278 = 11218500421486 := by decide
theorem cert_e2422407399278 : check e2422407399278 [[],[]] .sourceHead = true := by decide
def e2422407399286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2422407399286 : Closed e2422407399286 ∧ code e2422407399286 = 11218500421494 := by decide
theorem cert_e2422407399286 : check e2422407399286 [[],[]] .chain = true := by decide
def e2422407399290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e2422407399290 : Closed e2422407399290 ∧ code e2422407399290 = 11218500421498 := by decide
theorem cert_e2422407399290 : check e2422407399290 [[],[]] .sourceHead = true := by decide
def e2422407399306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407399306 : Closed e2422407399306 ∧ code e2422407399306 = 11218500421514 := by decide
theorem cert_e2422407399306 : check e2422407399306 [[],[]] .chain = true := by decide
def e2422407399350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2422407399350 : Closed e2422407399350 ∧ code e2422407399350 = 11218500421558 := by decide
theorem cert_e2422407399350 : check e2422407399350 [[],[]] .chain = true := by decide
def e2422407399354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2422407399354 : Closed e2422407399354 ∧ code e2422407399354 = 11218500421562 := by decide
theorem cert_e2422407399354 : check e2422407399354 [[],[]] .chain = true := by decide
def e2422407399386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e2422407399386 : Closed e2422407399386 ∧ code e2422407399386 = 11218500421594 := by decide
theorem cert_e2422407399386 : check e2422407399386 [[],[]] .sourceHead = true := by decide
def e2422407399542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2422407399542 : Closed e2422407399542 ∧ code e2422407399542 = 11218500421750 := by decide
theorem cert_e2422407399542 : check e2422407399542 [[],[]] .chain = true := by decide
def e2422407399786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2422407399786 : Closed e2422407399786 ∧ code e2422407399786 = 11218500421994 := by decide
theorem cert_e2422407399786 : check e2422407399786 [[],[]] .chain = true := by decide
def e2422407399822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407399822 : Closed e2422407399822 ∧ code e2422407399822 = 11218500422030 := by decide
theorem cert_e2422407399822 : check e2422407399822 [[],[]] .chain = true := by decide
def e2422407399834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407399834 : Closed e2422407399834 ∧ code e2422407399834 = 11218500422042 := by decide
theorem cert_e2422407399834 : check e2422407399834 [[],[]] .chain = true := by decide
def e2422407399878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407399878 : Closed e2422407399878 ∧ code e2422407399878 = 11218500422086 := by decide
theorem cert_e2422407399878 : check e2422407399878 [[],[]] .chain = true := by decide
def e2422407400478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407400478 : Closed e2422407400478 ∧ code e2422407400478 = 11218500422686 := by decide
theorem cert_e2422407400478 : check e2422407400478 [[],[]] .chain = true := by decide
def e2422407400502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407400502 : Closed e2422407400502 ∧ code e2422407400502 = 11218500422710 := by decide
theorem cert_e2422407400502 : check e2422407400502 [[],[]] .chain = true := by decide
def e2422407400506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407400506 : Closed e2422407400506 ∧ code e2422407400506 = 11218500422714 := by decide
theorem cert_e2422407400506 : check e2422407400506 [[],[]] .chain = true := by decide
def e2422407400646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407400646 : Closed e2422407400646 ∧ code e2422407400646 = 11218500422854 := by decide
theorem cert_e2422407400646 : check e2422407400646 [[],[]] .chain = true := by decide
def e2422407400674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407400674 : Closed e2422407400674 ∧ code e2422407400674 = 11218500422882 := by decide
theorem cert_e2422407400674 : check e2422407400674 [[],[]] .chain = true := by decide
def e2422407400686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407400686 : Closed e2422407400686 ∧ code e2422407400686 = 11218500422894 := by decide
theorem cert_e2422407400686 : check e2422407400686 [[],[]] .sourceHead = true := by decide
def e2422407400694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407400694 : Closed e2422407400694 ∧ code e2422407400694 = 11218500422902 := by decide
theorem cert_e2422407400694 : check e2422407400694 [[],[]] .sourceHead = true := by decide
def e2422407400974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407400974 : Closed e2422407400974 ∧ code e2422407400974 = 11218500423182 := by decide
theorem cert_e2422407400974 : check e2422407400974 [[],[]] .chain = true := by decide
def e2422407401058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407401058 : Closed e2422407401058 ∧ code e2422407401058 = 11218500423266 := by decide
theorem cert_e2422407401058 : check e2422407401058 [[],[]] .chain = true := by decide
def e2422407401070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407401070 : Closed e2422407401070 ∧ code e2422407401070 = 11218500423278 := by decide
theorem cert_e2422407401070 : check e2422407401070 [[],[]] .sourceHead = true := by decide
def e2422407401082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407401082 : Closed e2422407401082 ∧ code e2422407401082 = 11218500423290 := by decide
theorem cert_e2422407401082 : check e2422407401082 [[],[]] .sourceHead = true := by decide
def e2422407401270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407401270 : Closed e2422407401270 ∧ code e2422407401270 = 11218500423478 := by decide
theorem cert_e2422407401270 : check e2422407401270 [[],[]] .sourceHead = true := by decide
def e2422407401274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407401274 : Closed e2422407401274 ∧ code e2422407401274 = 11218500423482 := by decide
theorem cert_e2422407401274 : check e2422407401274 [[],[]] .sourceHead = true := by decide
def e2422407403050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422407403050 : Closed e2422407403050 ∧ code e2422407403050 = 11218500425258 := by decide
theorem cert_e2422407403050 : check e2422407403050 [[],[]] .chain = true := by decide
def e2422407403146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407403146 : Closed e2422407403146 ∧ code e2422407403146 = 11218500425354 := by decide
theorem cert_e2422407403146 : check e2422407403146 [[],[]] .chain = true := by decide
def e2422407403170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407403170 : Closed e2422407403170 ∧ code e2422407403170 = 11218500425378 := by decide
theorem cert_e2422407403170 : check e2422407403170 [[],[]] .chain = true := by decide
def e2422407403182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407403182 : Closed e2422407403182 ∧ code e2422407403182 = 11218500425390 := by decide
theorem cert_e2422407403182 : check e2422407403182 [[],[]] .sourceHead = true := by decide
def e2422407403190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422407403190 : Closed e2422407403190 ∧ code e2422407403190 = 11218500425398 := by decide
theorem cert_e2422407403190 : check e2422407403190 [[],[]] .chain = true := by decide
def e2422407403194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407403194 : Closed e2422407403194 ∧ code e2422407403194 = 11218500425402 := by decide
theorem cert_e2422407403194 : check e2422407403194 [[],[]] .sourceHead = true := by decide
def e2422407403222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422407403222 : Closed e2422407403222 ∧ code e2422407403222 = 11218500425430 := by decide
theorem cert_e2422407403222 : check e2422407403222 [[],[]] .chain = true := by decide
def e2422407403226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422407403226 : Closed e2422407403226 ∧ code e2422407403226 = 11218500425434 := by decide
theorem cert_e2422407403226 : check e2422407403226 [[],[]] .chain = true := by decide
def e2422407403242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407403242 : Closed e2422407403242 ∧ code e2422407403242 = 11218500425450 := by decide
theorem cert_e2422407403242 : check e2422407403242 [[],[]] .sourceHead = true := by decide
def e2422407403350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422407403350 : Closed e2422407403350 ∧ code e2422407403350 = 11218500425558 := by decide
theorem cert_e2422407403350 : check e2422407403350 [[],[]] .chain = true := by decide
def e2422407403354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422407403354 : Closed e2422407403354 ∧ code e2422407403354 = 11218500425562 := by decide
theorem cert_e2422407403354 : check e2422407403354 [[],[]] .chain = true := by decide
def e2422407403370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422407403370 : Closed e2422407403370 ∧ code e2422407403370 = 11218500425578 := by decide
theorem cert_e2422407403370 : check e2422407403370 [[],[]] .chain = true := by decide
def e2422407403434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2422407403434 : Closed e2422407403434 ∧ code e2422407403434 = 11218500425642 := by decide
theorem cert_e2422407403434 : check e2422407403434 [[],[]] .sourceHead = true := by decide
def e2422407403530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407403530 : Closed e2422407403530 ∧ code e2422407403530 = 11218500425738 := by decide
theorem cert_e2422407403530 : check e2422407403530 [[],[]] .chain = true := by decide
def e2422407403566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407403566 : Closed e2422407403566 ∧ code e2422407403566 = 11218500425774 := by decide
theorem cert_e2422407403566 : check e2422407403566 [[],[]] .sourceHead = true := by decide
def e2422407403574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407403574 : Closed e2422407403574 ∧ code e2422407403574 = 11218500425782 := by decide
theorem cert_e2422407403574 : check e2422407403574 [[],[]] .chain = true := by decide
def e2422407403578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407403578 : Closed e2422407403578 ∧ code e2422407403578 = 11218500425786 := by decide
theorem cert_e2422407403578 : check e2422407403578 [[],[]] .chain = true := by decide
def e2422407403626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407403626 : Closed e2422407403626 ∧ code e2422407403626 = 11218500425834 := by decide
theorem cert_e2422407403626 : check e2422407403626 [[],[]] .sourceHead = true := by decide
def e2422407403662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407403662 : Closed e2422407403662 ∧ code e2422407403662 = 11218500425870 := by decide
theorem cert_e2422407403662 : check e2422407403662 [[],[]] .chain = true := by decide
def e2422407403674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407403674 : Closed e2422407403674 ∧ code e2422407403674 = 11218500425882 := by decide
theorem cert_e2422407403674 : check e2422407403674 [[],[]] .chain = true := by decide
def e2422407403718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407403718 : Closed e2422407403718 ∧ code e2422407403718 = 11218500425926 := by decide
theorem cert_e2422407403718 : check e2422407403718 [[],[]] .chain = true := by decide
def e2422407403746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407403746 : Closed e2422407403746 ∧ code e2422407403746 = 11218500425954 := by decide
theorem cert_e2422407403746 : check e2422407403746 [[],[]] .chain = true := by decide
def e2422407403758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407403758 : Closed e2422407403758 ∧ code e2422407403758 = 11218500425966 := by decide
theorem cert_e2422407403758 : check e2422407403758 [[],[]] .sourceHead = true := by decide
def e2422407403766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407403766 : Closed e2422407403766 ∧ code e2422407403766 = 11218500425974 := by decide
theorem cert_e2422407403766 : check e2422407403766 [[],[]] .sourceHead = true := by decide
def e2422407403914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407403914 : Closed e2422407403914 ∧ code e2422407403914 = 11218500426122 := by decide
theorem cert_e2422407403914 : check e2422407403914 [[],[]] .chain = true := by decide
def e2422407403938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407403938 : Closed e2422407403938 ∧ code e2422407403938 = 11218500426146 := by decide
theorem cert_e2422407403938 : check e2422407403938 [[],[]] .chain = true := by decide
def e2422407403950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407403950 : Closed e2422407403950 ∧ code e2422407403950 = 11218500426158 := by decide
theorem cert_e2422407403950 : check e2422407403950 [[],[]] .sourceHead = true := by decide
def e2422407403958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422407403958 : Closed e2422407403958 ∧ code e2422407403958 = 11218500426166 := by decide
theorem cert_e2422407403958 : check e2422407403958 [[],[]] .chain = true := by decide
def e2422407403962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407403962 : Closed e2422407403962 ∧ code e2422407403962 = 11218500426170 := by decide
theorem cert_e2422407403962 : check e2422407403962 [[],[]] .sourceHead = true := by decide
def e2422407403990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422407403990 : Closed e2422407403990 ∧ code e2422407403990 = 11218500426198 := by decide
theorem cert_e2422407403990 : check e2422407403990 [[],[]] .chain = true := by decide
def e2422407403994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422407403994 : Closed e2422407403994 ∧ code e2422407403994 = 11218500426202 := by decide
theorem cert_e2422407403994 : check e2422407403994 [[],[]] .chain = true := by decide
def e2422407404010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407404010 : Closed e2422407404010 ∧ code e2422407404010 = 11218500426218 := by decide
theorem cert_e2422407404010 : check e2422407404010 [[],[]] .sourceHead = true := by decide
def e2422407404034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407404034 : Closed e2422407404034 ∧ code e2422407404034 = 11218500426242 := by decide
theorem cert_e2422407404034 : check e2422407404034 [[],[]] .chain = true := by decide
def e2422407404046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407404046 : Closed e2422407404046 ∧ code e2422407404046 = 11218500426254 := by decide
theorem cert_e2422407404046 : check e2422407404046 [[],[]] .chain = true := by decide
def e2422407404058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407404058 : Closed e2422407404058 ∧ code e2422407404058 = 11218500426266 := by decide
theorem cert_e2422407404058 : check e2422407404058 [[],[]] .sourceHead = true := by decide
def e2422407404130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407404130 : Closed e2422407404130 ∧ code e2422407404130 = 11218500426338 := by decide
theorem cert_e2422407404130 : check e2422407404130 [[],[]] .chain = true := by decide
def e2422407404142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407404142 : Closed e2422407404142 ∧ code e2422407404142 = 11218500426350 := by decide
theorem cert_e2422407404142 : check e2422407404142 [[],[]] .sourceHead = true := by decide
def e2422407404150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407404150 : Closed e2422407404150 ∧ code e2422407404150 = 11218500426358 := by decide
theorem cert_e2422407404150 : check e2422407404150 [[],[]] .chain = true := by decide
def e2422407404154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407404154 : Closed e2422407404154 ∧ code e2422407404154 = 11218500426362 := by decide
theorem cert_e2422407404154 : check e2422407404154 [[],[]] .sourceHead = true := by decide
def e2422407404294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407404294 : Closed e2422407404294 ∧ code e2422407404294 = 11218500426502 := by decide
theorem cert_e2422407404294 : check e2422407404294 [[],[]] .chain = true := by decide
def e2422407404318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407404318 : Closed e2422407404318 ∧ code e2422407404318 = 11218500426526 := by decide
theorem cert_e2422407404318 : check e2422407404318 [[],[]] .sourceHead = true := by decide
def e2422407404342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407404342 : Closed e2422407404342 ∧ code e2422407404342 = 11218500426550 := by decide
theorem cert_e2422407404342 : check e2422407404342 [[],[]] .chain = true := by decide
def e2422407404346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407404346 : Closed e2422407404346 ∧ code e2422407404346 = 11218500426554 := by decide
theorem cert_e2422407404346 : check e2422407404346 [[],[]] .chain = true := by decide
def e2422407404418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407404418 : Closed e2422407404418 ∧ code e2422407404418 = 11218500426626 := by decide
theorem cert_e2422407404418 : check e2422407404418 [[],[]] .sourceHead = true := by decide
def e2422407404430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407404430 : Closed e2422407404430 ∧ code e2422407404430 = 11218500426638 := by decide
theorem cert_e2422407404430 : check e2422407404430 [[],[]] .sourceHead = true := by decide
def e2422407404442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407404442 : Closed e2422407404442 ∧ code e2422407404442 = 11218500426650 := by decide
theorem cert_e2422407404442 : check e2422407404442 [[],[]] .sourceHead = true := by decide
def e2422407404570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407404570 : Closed e2422407404570 ∧ code e2422407404570 = 11218500426778 := by decide
theorem cert_e2422407404570 : check e2422407404570 [[],[]] .chain = true := by decide
def e2422407404614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407404614 : Closed e2422407404614 ∧ code e2422407404614 = 11218500426822 := by decide
theorem cert_e2422407404614 : check e2422407404614 [[],[]] .chain = true := by decide
def e2422407404642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407404642 : Closed e2422407404642 ∧ code e2422407404642 = 11218500426850 := by decide
theorem cert_e2422407404642 : check e2422407404642 [[],[]] .chain = true := by decide
def e2422407404654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422407404654 : Closed e2422407404654 ∧ code e2422407404654 = 11218500426862 := by decide
theorem cert_e2422407404654 : check e2422407404654 [[],[]] .sourceHead = true := by decide
def e2422407404666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407404666 : Closed e2422407404666 ∧ code e2422407404666 = 11218500426874 := by decide
theorem cert_e2422407404666 : check e2422407404666 [[],[]] .sourceHead = true := by decide
def e2422407404758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407404758 : Closed e2422407404758 ∧ code e2422407404758 = 11218500426966 := by decide
theorem cert_e2422407404758 : check e2422407404758 [[],[]] .chain = true := by decide
def e2422407404762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407404762 : Closed e2422407404762 ∧ code e2422407404762 = 11218500426970 := by decide
theorem cert_e2422407404762 : check e2422407404762 [[],[]] .chain = true := by decide
def e2422407404778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407404778 : Closed e2422407404778 ∧ code e2422407404778 = 11218500426986 := by decide
theorem cert_e2422407404778 : check e2422407404778 [[],[]] .chain = true := by decide
def e2422407404806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407404806 : Closed e2422407404806 ∧ code e2422407404806 = 11218500427014 := by decide
theorem cert_e2422407404806 : check e2422407404806 [[],[]] .chain = true := by decide
def e2422407404830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422407404830 : Closed e2422407404830 ∧ code e2422407404830 = 11218500427038 := by decide
theorem cert_e2422407404830 : check e2422407404830 [[],[]] .sourceHead = true := by decide
def e2422407404854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407404854 : Closed e2422407404854 ∧ code e2422407404854 = 11218500427062 := by decide
theorem cert_e2422407404854 : check e2422407404854 [[],[]] .chain = true := by decide
def e2422407404858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407404858 : Closed e2422407404858 ∧ code e2422407404858 = 11218500427066 := by decide
theorem cert_e2422407404858 : check e2422407404858 [[],[]] .chain = true := by decide
def e2422407404954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407404954 : Closed e2422407404954 ∧ code e2422407404954 = 11218500427162 := by decide
theorem cert_e2422407404954 : check e2422407404954 [[],[]] .chain = true := by decide
def e2422407404998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407404998 : Closed e2422407404998 ∧ code e2422407404998 = 11218500427206 := by decide
theorem cert_e2422407404998 : check e2422407404998 [[],[]] .sourceHead = true := by decide
def e2422407405066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407405066 : Closed e2422407405066 ∧ code e2422407405066 = 11218500427274 := by decide
theorem cert_e2422407405066 : check e2422407405066 [[],[]] .sourceHead = true := by decide
def e2422407405110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407405110 : Closed e2422407405110 ∧ code e2422407405110 = 11218500427318 := by decide
theorem cert_e2422407405110 : check e2422407405110 [[],[]] .sourceHead = true := by decide
def e2422407405114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407405114 : Closed e2422407405114 ∧ code e2422407405114 = 11218500427322 := by decide
theorem cert_e2422407405114 : check e2422407405114 [[],[]] .sourceHead = true := by decide
def e2422407405162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407405162 : Closed e2422407405162 ∧ code e2422407405162 = 11218500427370 := by decide
theorem cert_e2422407405162 : check e2422407405162 [[],[]] .sourceHead = true := by decide
def e2422407405186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407405186 : Closed e2422407405186 ∧ code e2422407405186 = 11218500427394 := by decide
theorem cert_e2422407405186 : check e2422407405186 [[],[]] .sourceHead = true := by decide
def e2422407405198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407405198 : Closed e2422407405198 ∧ code e2422407405198 = 11218500427406 := by decide
theorem cert_e2422407405198 : check e2422407405198 [[],[]] .sourceHead = true := by decide
def e2422407405210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407405210 : Closed e2422407405210 ∧ code e2422407405210 = 11218500427418 := by decide
theorem cert_e2422407405210 : check e2422407405210 [[],[]] .sourceHead = true := by decide
def e2422407405254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407405254 : Closed e2422407405254 ∧ code e2422407405254 = 11218500427462 := by decide
theorem cert_e2422407405254 : check e2422407405254 [[],[]] .sourceHead = true := by decide
def e2422407405594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422407405594 : Closed e2422407405594 ∧ code e2422407405594 = 11218500427802 := by decide
theorem cert_e2422407405594 : check e2422407405594 [[],[]] .sourceHead = true := by decide
def e2422407405630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422407405630 : Closed e2422407405630 ∧ code e2422407405630 = 11218500427838 := by decide
theorem cert_e2422407405630 : check e2422407405630 [[],[]] .chain = true := by decide
def e2422407405678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422407405678 : Closed e2422407405678 ∧ code e2422407405678 = 11218500427886 := by decide
theorem cert_e2422407405678 : check e2422407405678 [[],[]] .chain = true := by decide
def e2422407405686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422407405686 : Closed e2422407405686 ∧ code e2422407405686 = 11218500427894 := by decide
theorem cert_e2422407405686 : check e2422407405686 [[],[]] .sourceHead = true := by decide
def e2422407405690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422407405690 : Closed e2422407405690 ∧ code e2422407405690 = 11218500427898 := by decide
theorem cert_e2422407405690 : check e2422407405690 [[],[]] .chain = true := by decide
def e2422407405930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422407405930 : Closed e2422407405930 ∧ code e2422407405930 = 11218500428138 := by decide
theorem cert_e2422407405930 : check e2422407405930 [[],[]] .sourceHead = true := by decide
def e2422407405966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422407405966 : Closed e2422407405966 ∧ code e2422407405966 = 11218500428174 := by decide
theorem cert_e2422407405966 : check e2422407405966 [[],[]] .chain = true := by decide
def e2422407405978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407405978 : Closed e2422407405978 ∧ code e2422407405978 = 11218500428186 := by decide
theorem cert_e2422407405978 : check e2422407405978 [[],[]] .sourceHead = true := by decide
def e2422407406022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422407406022 : Closed e2422407406022 ∧ code e2422407406022 = 11218500428230 := by decide
theorem cert_e2422407406022 : check e2422407406022 [[],[]] .chain = true := by decide
def e2422407406046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407406046 : Closed e2422407406046 ∧ code e2422407406046 = 11218500428254 := by decide
theorem cert_e2422407406046 : check e2422407406046 [[],[]] .sourceHead = true := by decide
def e2422407406050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407406050 : Closed e2422407406050 ∧ code e2422407406050 = 11218500428258 := by decide
theorem cert_e2422407406050 : check e2422407406050 [[],[]] .chain = true := by decide
def e2422407406062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422407406062 : Closed e2422407406062 ∧ code e2422407406062 = 11218500428270 := by decide
theorem cert_e2422407406062 : check e2422407406062 [[],[]] .chain = true := by decide
def e2422407406070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407406070 : Closed e2422407406070 ∧ code e2422407406070 = 11218500428278 := by decide
theorem cert_e2422407406070 : check e2422407406070 [[],[]] .sourceHead = true := by decide
def e2422407406986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407406986 : Closed e2422407406986 ∧ code e2422407406986 = 11218500429194 := by decide
theorem cert_e2422407406986 : check e2422407406986 [[],[]] .chain = true := by decide
def e2422407407010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407407010 : Closed e2422407407010 ∧ code e2422407407010 = 11218500429218 := by decide
theorem cert_e2422407407010 : check e2422407407010 [[],[]] .chain = true := by decide
def e2422407407022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407407022 : Closed e2422407407022 ∧ code e2422407407022 = 11218500429230 := by decide
theorem cert_e2422407407022 : check e2422407407022 [[],[]] .sourceHead = true := by decide
def e2422407407030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422407407030 : Closed e2422407407030 ∧ code e2422407407030 = 11218500429238 := by decide
theorem cert_e2422407407030 : check e2422407407030 [[],[]] .chain = true := by decide
def e2422407407034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407407034 : Closed e2422407407034 ∧ code e2422407407034 = 11218500429242 := by decide
theorem cert_e2422407407034 : check e2422407407034 [[],[]] .sourceHead = true := by decide
end Blc.Floor43
