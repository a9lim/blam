import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262374784454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2262374784454 : Closed e2262374784454 ∧ code e2262374784454 = 11058467806662 := by decide
theorem cert_e2262374784454 : check e2262374784454 [[],[.under]] .smaller = true := by decide
def e2262374784478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e2262374784478 : Closed e2262374784478 ∧ code e2262374784478 = 11058467806686 := by decide
theorem cert_e2262374784478 : check e2262374784478 [[],[.under]] .three = true := by decide
def e2262374784494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e2262374784494 : Closed e2262374784494 ∧ code e2262374784494 = 11058467806702 := by decide
theorem cert_e2262374784494 : check e2262374784494 [[],[.under]] .three = true := by decide
def e2262374784566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2262374784566 : Closed e2262374784566 ∧ code e2262374784566 = 11058467806774 := by decide
theorem cert_e2262374784566 : check e2262374784566 [[],[.under]] .smaller = true := by decide
def e2262374784570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2262374784570 : Closed e2262374784570 ∧ code e2262374784570 = 11058467806778 := by decide
theorem cert_e2262374784570 : check e2262374784570 [[],[.under]] .smaller = true := by decide
def e2262374784618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2262374784618 : Closed e2262374784618 ∧ code e2262374784618 = 11058467806826 := by decide
theorem cert_e2262374784618 : check e2262374784618 [[],[.under]] .smaller = true := by decide
def e2262374784654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2262374784654 : Closed e2262374784654 ∧ code e2262374784654 = 11058467806862 := by decide
theorem cert_e2262374784654 : check e2262374784654 [[],[.under]] .smaller = true := by decide
def e2262374784666 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374784666 : Closed e2262374784666 ∧ code e2262374784666 = 11058467806874 := by decide
theorem cert_e2262374784666 : check e2262374784666 [[],[.under]] .smaller = true := by decide
def e2262374784710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2262374784710 : Closed e2262374784710 ∧ code e2262374784710 = 11058467806918 := by decide
theorem cert_e2262374784710 : check e2262374784710 [[],[.under]] .smaller = true := by decide
def e2262374784734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e2262374784734 : Closed e2262374784734 ∧ code e2262374784734 = 11058467806942 := by decide
theorem cert_e2262374784734 : check e2262374784734 [[],[.under]] .three = true := by decide
def e2262374784758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e2262374784758 : Closed e2262374784758 ∧ code e2262374784758 = 11058467806966 := by decide
theorem cert_e2262374784758 : check e2262374784758 [[],[.under]] .three = true := by decide
def e2262374784794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2262374784794 : Closed e2262374784794 ∧ code e2262374784794 = 11058467807002 := by decide
theorem cert_e2262374784794 : check e2262374784794 [[],[.under]] .three = true := by decide
def e2262374784838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2262374784838 : Closed e2262374784838 ∧ code e2262374784838 = 11058467807046 := by decide
theorem cert_e2262374784838 : check e2262374784838 [[],[.under]] .three = true := by decide
def e2262374784862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e2262374784862 : Closed e2262374784862 ∧ code e2262374784862 = 11058467807070 := by decide
theorem cert_e2262374784862 : check e2262374784862 [[],[.under]] .three = true := by decide
def e2262374784878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e2262374784878 : Closed e2262374784878 ∧ code e2262374784878 = 11058467807086 := by decide
theorem cert_e2262374784878 : check e2262374784878 [[],[.under]] .three = true := by decide
def e2262374784886 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e2262374784886 : Closed e2262374784886 ∧ code e2262374784886 = 11058467807094 := by decide
theorem cert_e2262374784886 : check e2262374784886 [[],[.under]] .three = true := by decide
def e2262374784890 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e2262374784890 : Closed e2262374784890 ∧ code e2262374784890 = 11058467807098 := by decide
theorem cert_e2262374784890 : check e2262374784890 [[],[.under]] .three = true := by decide
def e2262374785502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2262374785502 : Closed e2262374785502 ∧ code e2262374785502 = 11058467807710 := by decide
theorem cert_e2262374785502 : check e2262374785502 [[],[.under]] .smaller = true := by decide
def e2262374785526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2262374785526 : Closed e2262374785526 ∧ code e2262374785526 = 11058467807734 := by decide
theorem cert_e2262374785526 : check e2262374785526 [[],[.under]] .smaller = true := by decide
def e2262374786478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2262374786478 : Closed e2262374786478 ∧ code e2262374786478 = 11058467808686 := by decide
theorem cert_e2262374786478 : check e2262374786478 [[],[.under]] .smaller = true := by decide
def e2262374786490 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2262374786490 : Closed e2262374786490 ∧ code e2262374786490 = 11058467808698 := by decide
theorem cert_e2262374786490 : check e2262374786490 [[],[.under]] .smaller = true := by decide
def e2262374786538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2262374786538 : Closed e2262374786538 ∧ code e2262374786538 = 11058467808746 := by decide
theorem cert_e2262374786538 : check e2262374786538 [[],[.under]] .smaller = true := by decide
def e2262374786622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2262374786622 : Closed e2262374786622 ∧ code e2262374786622 = 11058467808830 := by decide
theorem cert_e2262374786622 : check e2262374786622 [[],[.under]] .three = true := by decide
def e2262374786670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262374786670 : Closed e2262374786670 ∧ code e2262374786670 = 11058467808878 := by decide
theorem cert_e2262374786670 : check e2262374786670 [[],[.under]] .smaller = true := by decide
def e2262374786682 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262374786682 : Closed e2262374786682 ∧ code e2262374786682 = 11058467808890 := by decide
theorem cert_e2262374786682 : check e2262374786682 [[],[.under]] .smaller = true := by decide
def e2262374786846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2262374786846 : Closed e2262374786846 ∧ code e2262374786846 = 11058467809054 := by decide
theorem cert_e2262374786846 : check e2262374786846 [[],[.under]] .smaller = true := by decide
def e2262374786958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2262374786958 : Closed e2262374786958 ∧ code e2262374786958 = 11058467809166 := by decide
theorem cert_e2262374786958 : check e2262374786958 [[],[.under]] .smaller = true := by decide
def e2262374786970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374786970 : Closed e2262374786970 ∧ code e2262374786970 = 11058467809178 := by decide
theorem cert_e2262374786970 : check e2262374786970 [[],[.under]] .smaller = true := by decide
def e2262374787014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2262374787014 : Closed e2262374787014 ∧ code e2262374787014 = 11058467809222 := by decide
theorem cert_e2262374787014 : check e2262374787014 [[],[.under]] .three = true := by decide
def e2262374787038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e2262374787038 : Closed e2262374787038 ∧ code e2262374787038 = 11058467809246 := by decide
theorem cert_e2262374787038 : check e2262374787038 [[],[.under]] .three = true := by decide
def e2262374789918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2262374789918 : Closed e2262374789918 ∧ code e2262374789918 = 11058467812126 := by decide
theorem cert_e2262374789918 : check e2262374789918 [[],[.under]] .smaller = true := by decide
def e2262374790086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2262374790086 : Closed e2262374790086 ∧ code e2262374790086 = 11058467812294 := by decide
theorem cert_e2262374790086 : check e2262374790086 [[],[.under]] .smaller = true := by decide
def e2262374790110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e2262374790110 : Closed e2262374790110 ∧ code e2262374790110 = 11058467812318 := by decide
theorem cert_e2262374790110 : check e2262374790110 [[],[.under]] .three = true := by decide
def e2262374790126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e2262374790126 : Closed e2262374790126 ∧ code e2262374790126 = 11058467812334 := by decide
theorem cert_e2262374790126 : check e2262374790126 [[],[.under]] .three = true := by decide
def e2262374791286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2262374791286 : Closed e2262374791286 ∧ code e2262374791286 = 11058467813494 := by decide
theorem cert_e2262374791286 : check e2262374791286 [[],[.under]] .smaller = true := by decide
def e2262374791530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2262374791530 : Closed e2262374791530 ∧ code e2262374791530 = 11058467813738 := by decide
theorem cert_e2262374791530 : check e2262374791530 [[],[.under]] .smaller = true := by decide
def e2262374791566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2262374791566 : Closed e2262374791566 ∧ code e2262374791566 = 11058467813774 := by decide
theorem cert_e2262374791566 : check e2262374791566 [[],[.under]] .smaller = true := by decide
def e2262374791578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374791578 : Closed e2262374791578 ∧ code e2262374791578 = 11058467813786 := by decide
theorem cert_e2262374791578 : check e2262374791578 [[],[.under]] .smaller = true := by decide
def e2262374791622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2262374791622 : Closed e2262374791622 ∧ code e2262374791622 = 11058467813830 := by decide
theorem cert_e2262374791622 : check e2262374791622 [[],[.under]] .smaller = true := by decide
def e2262374791646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e2262374791646 : Closed e2262374791646 ∧ code e2262374791646 = 11058467813854 := by decide
theorem cert_e2262374791646 : check e2262374791646 [[],[.under]] .three = true := by decide
def e2262374791670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e2262374791670 : Closed e2262374791670 ∧ code e2262374791670 = 11058467813878 := by decide
theorem cert_e2262374791670 : check e2262374791670 [[],[.under]] .three = true := by decide
def e2262374792390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2262374792390 : Closed e2262374792390 ∧ code e2262374792390 = 11058467814598 := by decide
theorem cert_e2262374792390 : check e2262374792390 [[],[.under]] .three = true := by decide
def e2262374792414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e2262374792414 : Closed e2262374792414 ∧ code e2262374792414 = 11058467814622 := by decide
theorem cert_e2262374792414 : check e2262374792414 [[],[.under]] .three = true := by decide
def e2262374792430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262374792430 : Closed e2262374792430 ∧ code e2262374792430 = 11058467814638 := by decide
theorem cert_e2262374792430 : check e2262374792430 [[],[.under]] .three = true := by decide
def e2262374792438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262374792438 : Closed e2262374792438 ∧ code e2262374792438 = 11058467814646 := by decide
theorem cert_e2262374792438 : check e2262374792438 [[],[.under]] .three = true := by decide
def e2262374792442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e2262374792442 : Closed e2262374792442 ∧ code e2262374792442 = 11058467814650 := by decide
theorem cert_e2262374792442 : check e2262374792442 [[],[.under]] .three = true := by decide
def e2262374794166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e2262374794166 : Closed e2262374794166 ∧ code e2262374794166 = 11058467816374 := by decide
theorem cert_e2262374794166 : check e2262374794166 [[],[.under]] .smaller = true := by decide
def e2262374794170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2262374794170 : Closed e2262374794170 ∧ code e2262374794170 = 11058467816378 := by decide
theorem cert_e2262374794170 : check e2262374794170 [[],[.under]] .smaller = true := by decide
def e2262374794202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2262374794202 : Closed e2262374794202 ∧ code e2262374794202 = 11058467816410 := by decide
theorem cert_e2262374794202 : check e2262374794202 [[],[.under]] .smaller = true := by decide
def e2262374794870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e2262374794870 : Closed e2262374794870 ∧ code e2262374794870 = 11058467817078 := by decide
theorem cert_e2262374794870 : check e2262374794870 [[],[.under]] .smaller = true := by decide
def e2262374795062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374795062 : Closed e2262374795062 ∧ code e2262374795062 = 11058467817270 := by decide
theorem cert_e2262374795062 : check e2262374795062 [[],[.under]] .smaller = true := by decide
def e2262374795066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374795066 : Closed e2262374795066 ∧ code e2262374795066 = 11058467817274 := by decide
theorem cert_e2262374795066 : check e2262374795066 [[],[.under]] .smaller = true := by decide
def e2262374796118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2262374796118 : Closed e2262374796118 ∧ code e2262374796118 = 11058467818326 := by decide
theorem cert_e2262374796118 : check e2262374796118 [[],[.under]] .smaller = true := by decide
def e2262374796122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2262374796122 : Closed e2262374796122 ∧ code e2262374796122 = 11058467818330 := by decide
theorem cert_e2262374796122 : check e2262374796122 [[],[.under]] .smaller = true := by decide
def e2262374796138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2262374796138 : Closed e2262374796138 ∧ code e2262374796138 = 11058467818346 := by decide
theorem cert_e2262374796138 : check e2262374796138 [[],[.under]] .smaller = true := by decide
def e2262374796202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2262374796202 : Closed e2262374796202 ∧ code e2262374796202 = 11058467818410 := by decide
theorem cert_e2262374796202 : check e2262374796202 [[],[.under]] .smaller = true := by decide
def e2262374796406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2262374796406 : Closed e2262374796406 ∧ code e2262374796406 = 11058467818614 := by decide
theorem cert_e2262374796406 : check e2262374796406 [[],[.under]] .smaller = true := by decide
def e2262374796502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2262374796502 : Closed e2262374796502 ∧ code e2262374796502 = 11058467818710 := by decide
theorem cert_e2262374796502 : check e2262374796502 [[],[.under]] .smaller = true := by decide
def e2262374796506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2262374796506 : Closed e2262374796506 ∧ code e2262374796506 = 11058467818714 := by decide
theorem cert_e2262374796506 : check e2262374796506 [[],[.under]] .smaller = true := by decide
def e2262374796522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2262374796522 : Closed e2262374796522 ∧ code e2262374796522 = 11058467818730 := by decide
theorem cert_e2262374796522 : check e2262374796522 [[],[.under]] .smaller = true := by decide
def e2262374796598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374796598 : Closed e2262374796598 ∧ code e2262374796598 = 11058467818806 := by decide
theorem cert_e2262374796598 : check e2262374796598 [[],[.under]] .smaller = true := by decide
def e2262374796602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374796602 : Closed e2262374796602 ∧ code e2262374796602 = 11058467818810 := by decide
theorem cert_e2262374796602 : check e2262374796602 [[],[.under]] .smaller = true := by decide
def e2262374796686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2262374796686 : Closed e2262374796686 ∧ code e2262374796686 = 11058467818894 := by decide
theorem cert_e2262374796686 : check e2262374796686 [[],[.under]] .smaller = true := by decide
def e2262374796698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374796698 : Closed e2262374796698 ∧ code e2262374796698 = 11058467818906 := by decide
theorem cert_e2262374796698 : check e2262374796698 [[],[.under]] .smaller = true := by decide
def e2262374796766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2262374796766 : Closed e2262374796766 ∧ code e2262374796766 = 11058467818974 := by decide
theorem cert_e2262374796766 : check e2262374796766 [[],[.under]] .three = true := by decide
def e2262374796782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2262374796782 : Closed e2262374796782 ∧ code e2262374796782 = 11058467818990 := by decide
theorem cert_e2262374796782 : check e2262374796782 [[],[.under]] .three = true := by decide
def e2262374796854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2262374796854 : Closed e2262374796854 ∧ code e2262374796854 = 11058467819062 := by decide
theorem cert_e2262374796854 : check e2262374796854 [[],[.under]] .smaller = true := by decide
def e2262374796858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2262374796858 : Closed e2262374796858 ∧ code e2262374796858 = 11058467819066 := by decide
theorem cert_e2262374796858 : check e2262374796858 [[],[.under]] .smaller = true := by decide
def e2262374796906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2262374796906 : Closed e2262374796906 ∧ code e2262374796906 = 11058467819114 := by decide
theorem cert_e2262374796906 : check e2262374796906 [[],[.under]] .smaller = true := by decide
def e2262374796942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2262374796942 : Closed e2262374796942 ∧ code e2262374796942 = 11058467819150 := by decide
theorem cert_e2262374796942 : check e2262374796942 [[],[.under]] .smaller = true := by decide
def e2262374796954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374796954 : Closed e2262374796954 ∧ code e2262374796954 = 11058467819162 := by decide
theorem cert_e2262374796954 : check e2262374796954 [[],[.under]] .smaller = true := by decide
def e2262374796998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2262374796998 : Closed e2262374796998 ∧ code e2262374796998 = 11058467819206 := by decide
theorem cert_e2262374796998 : check e2262374796998 [[],[.under]] .smaller = true := by decide
def e2262374797022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2262374797022 : Closed e2262374797022 ∧ code e2262374797022 = 11058467819230 := by decide
theorem cert_e2262374797022 : check e2262374797022 [[],[.under]] .three = true := by decide
def e2262374797046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2262374797046 : Closed e2262374797046 ∧ code e2262374797046 = 11058467819254 := by decide
theorem cert_e2262374797046 : check e2262374797046 [[],[.under]] .three = true := by decide
def e2262374797150 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2262374797150 : Closed e2262374797150 ∧ code e2262374797150 = 11058467819358 := by decide
theorem cert_e2262374797150 : check e2262374797150 [[],[.under]] .three = true := by decide
def e2262374797178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2262374797178 : Closed e2262374797178 ∧ code e2262374797178 = 11058467819386 := by decide
theorem cert_e2262374797178 : check e2262374797178 [[],[.under]] .three = true := by decide
def e2262374797230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2262374797230 : Closed e2262374797230 ∧ code e2262374797230 = 11058467819438 := by decide
theorem cert_e2262374797230 : check e2262374797230 [[],[.under]] .three = true := by decide
def e2262374797238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2262374797238 : Closed e2262374797238 ∧ code e2262374797238 = 11058467819446 := by decide
theorem cert_e2262374797238 : check e2262374797238 [[],[.under]] .three = true := by decide
def e2262374797242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2262374797242 : Closed e2262374797242 ∧ code e2262374797242 = 11058467819450 := by decide
theorem cert_e2262374797242 : check e2262374797242 [[],[.under]] .three = true := by decide
def e2262374797550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2262374797550 : Closed e2262374797550 ∧ code e2262374797550 = 11058467819758 := by decide
theorem cert_e2262374797550 : check e2262374797550 [[],[.under]] .smaller = true := by decide
def e2262374797558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2262374797558 : Closed e2262374797558 ∧ code e2262374797558 = 11058467819766 := by decide
theorem cert_e2262374797558 : check e2262374797558 [[],[.under]] .smaller = true := by decide
def e2262374798038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2262374798038 : Closed e2262374798038 ∧ code e2262374798038 = 11058467820246 := by decide
theorem cert_e2262374798038 : check e2262374798038 [[],[.under]] .smaller = true := by decide
def e2262374798042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2262374798042 : Closed e2262374798042 ∧ code e2262374798042 = 11058467820250 := by decide
theorem cert_e2262374798042 : check e2262374798042 [[],[.under]] .smaller = true := by decide
def e2262374798058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2262374798058 : Closed e2262374798058 ∧ code e2262374798058 = 11058467820266 := by decide
theorem cert_e2262374798058 : check e2262374798058 [[],[.under]] .smaller = true := by decide
def e2262374798134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262374798134 : Closed e2262374798134 ∧ code e2262374798134 = 11058467820342 := by decide
theorem cert_e2262374798134 : check e2262374798134 [[],[.under]] .smaller = true := by decide
def e2262374798138 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262374798138 : Closed e2262374798138 ∧ code e2262374798138 = 11058467820346 := by decide
theorem cert_e2262374798138 : check e2262374798138 [[],[.under]] .smaller = true := by decide
def e2262374798222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2262374798222 : Closed e2262374798222 ∧ code e2262374798222 = 11058467820430 := by decide
theorem cert_e2262374798222 : check e2262374798222 [[],[.under]] .smaller = true := by decide
def e2262374798234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374798234 : Closed e2262374798234 ∧ code e2262374798234 = 11058467820442 := by decide
theorem cert_e2262374798234 : check e2262374798234 [[],[.under]] .smaller = true := by decide
def e2262374798302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2262374798302 : Closed e2262374798302 ∧ code e2262374798302 = 11058467820510 := by decide
theorem cert_e2262374798302 : check e2262374798302 [[],[.under]] .three = true := by decide
def e2262374798318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2262374798318 : Closed e2262374798318 ∧ code e2262374798318 = 11058467820526 := by decide
theorem cert_e2262374798318 : check e2262374798318 [[],[.under]] .three = true := by decide
def e2262374799478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2262374799478 : Closed e2262374799478 ∧ code e2262374799478 = 11058467821686 := by decide
theorem cert_e2262374799478 : check e2262374799478 [[],[.under]] .smaller = true := by decide
def e2262374799722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2262374799722 : Closed e2262374799722 ∧ code e2262374799722 = 11058467821930 := by decide
theorem cert_e2262374799722 : check e2262374799722 [[],[.under]] .smaller = true := by decide
def e2262374799758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2262374799758 : Closed e2262374799758 ∧ code e2262374799758 = 11058467821966 := by decide
theorem cert_e2262374799758 : check e2262374799758 [[],[.under]] .smaller = true := by decide
def e2262374799770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262374799770 : Closed e2262374799770 ∧ code e2262374799770 = 11058467821978 := by decide
theorem cert_e2262374799770 : check e2262374799770 [[],[.under]] .smaller = true := by decide
def e2262374799814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2262374799814 : Closed e2262374799814 ∧ code e2262374799814 = 11058467822022 := by decide
theorem cert_e2262374799814 : check e2262374799814 [[],[.under]] .smaller = true := by decide
def e2262374799838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2262374799838 : Closed e2262374799838 ∧ code e2262374799838 = 11058467822046 := by decide
theorem cert_e2262374799838 : check e2262374799838 [[],[.under]] .three = true := by decide
def e2262374799862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2262374799862 : Closed e2262374799862 ∧ code e2262374799862 = 11058467822070 := by decide
theorem cert_e2262374799862 : check e2262374799862 [[],[.under]] .three = true := by decide
def e2262374800606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2262374800606 : Closed e2262374800606 ∧ code e2262374800606 = 11058467822814 := by decide
theorem cert_e2262374800606 : check e2262374800606 [[],[.under]] .three = true := by decide
def e2262374800634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2262374800634 : Closed e2262374800634 ∧ code e2262374800634 = 11058467822842 := by decide
theorem cert_e2262374800634 : check e2262374800634 [[],[.under]] .three = true := by decide
def e2262374801006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374801006 : Closed e2262374801006 ∧ code e2262374801006 = 11058467823214 := by decide
theorem cert_e2262374801006 : check e2262374801006 [[],[.under]] .three = true := by decide
def e2262374801014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262374801014 : Closed e2262374801014 ∧ code e2262374801014 = 11058467823222 := by decide
theorem cert_e2262374801014 : check e2262374801014 [[],[.under]] .three = true := by decide
def e2262374801018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374801018 : Closed e2262374801018 ∧ code e2262374801018 = 11058467823226 := by decide
theorem cert_e2262374801018 : check e2262374801018 [[],[.under]] .three = true := by decide
def e2262374802230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374802230 : Closed e2262374802230 ∧ code e2262374802230 = 11058467824438 := by decide
theorem cert_e2262374802230 : check e2262374802230 [[],[.under]] .three = true := by decide
def e2262374802234 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374802234 : Closed e2262374802234 ∧ code e2262374802234 = 11058467824442 := by decide
theorem cert_e2262374802234 : check e2262374802234 [[],[.under]] .three = true := by decide
def e2262374802330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262374802330 : Closed e2262374802330 ∧ code e2262374802330 = 11058467824538 := by decide
theorem cert_e2262374802330 : check e2262374802330 [[],[.under]] .three = true := by decide
def e2262374802998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2262374802998 : Closed e2262374802998 ∧ code e2262374802998 = 11058467825206 := by decide
theorem cert_e2262374802998 : check e2262374802998 [[],[.under]] .three = true := by decide
def e2262374803002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2262374803002 : Closed e2262374803002 ∧ code e2262374803002 = 11058467825210 := by decide
theorem cert_e2262374803002 : check e2262374803002 [[],[.under]] .three = true := by decide
def e2262374803086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2262374803086 : Closed e2262374803086 ∧ code e2262374803086 = 11058467825294 := by decide
theorem cert_e2262374803086 : check e2262374803086 [[],[.under]] .three = true := by decide
def e2262374803142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2262374803142 : Closed e2262374803142 ∧ code e2262374803142 = 11058467825350 := by decide
theorem cert_e2262374803142 : check e2262374803142 [[],[.under]] .three = true := by decide
def e2262374803166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2262374803166 : Closed e2262374803166 ∧ code e2262374803166 = 11058467825374 := by decide
theorem cert_e2262374803166 : check e2262374803166 [[],[.under]] .three = true := by decide
def e2262374803182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2262374803182 : Closed e2262374803182 ∧ code e2262374803182 = 11058467825390 := by decide
theorem cert_e2262374803182 : check e2262374803182 [[],[.under]] .three = true := by decide
def e2262374803190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2262374803190 : Closed e2262374803190 ∧ code e2262374803190 = 11058467825398 := by decide
theorem cert_e2262374803190 : check e2262374803190 [[],[.under]] .three = true := by decide
def e2262374803226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2262374803226 : Closed e2262374803226 ∧ code e2262374803226 = 11058467825434 := by decide
theorem cert_e2262374803226 : check e2262374803226 [[],[.under]] .three = true := by decide
def e2262374803270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2262374803270 : Closed e2262374803270 ∧ code e2262374803270 = 11058467825478 := by decide
theorem cert_e2262374803270 : check e2262374803270 [[],[.under]] .three = true := by decide
def e2262374803294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2262374803294 : Closed e2262374803294 ∧ code e2262374803294 = 11058467825502 := by decide
theorem cert_e2262374803294 : check e2262374803294 [[],[.under]] .three = true := by decide
def e2262374803310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2262374803310 : Closed e2262374803310 ∧ code e2262374803310 = 11058467825518 := by decide
theorem cert_e2262374803310 : check e2262374803310 [[],[.under]] .three = true := by decide
def e2262374803318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2262374803318 : Closed e2262374803318 ∧ code e2262374803318 = 11058467825526 := by decide
theorem cert_e2262374803318 : check e2262374803318 [[],[.under]] .three = true := by decide
def e2262374803322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2262374803322 : Closed e2262374803322 ∧ code e2262374803322 = 11058467825530 := by decide
theorem cert_e2262374803322 : check e2262374803322 [[],[.under]] .three = true := by decide
def e2262374803374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2262374803374 : Closed e2262374803374 ∧ code e2262374803374 = 11058467825582 := by decide
theorem cert_e2262374803374 : check e2262374803374 [[],[.under]] .three = true := by decide
def e2262374803382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2262374803382 : Closed e2262374803382 ∧ code e2262374803382 = 11058467825590 := by decide
theorem cert_e2262374803382 : check e2262374803382 [[],[.under]] .three = true := by decide
def e2262374803386 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2262374803386 : Closed e2262374803386 ∧ code e2262374803386 = 11058467825594 := by decide
theorem cert_e2262374803386 : check e2262374803386 [[],[.under]] .three = true := by decide
def e2262374803414 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2262374803414 : Closed e2262374803414 ∧ code e2262374803414 = 11058467825622 := by decide
theorem cert_e2262374803414 : check e2262374803414 [[],[.under]] .three = true := by decide
def e2262374803418 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2262374803418 : Closed e2262374803418 ∧ code e2262374803418 = 11058467825626 := by decide
theorem cert_e2262374803418 : check e2262374803418 [[],[.under]] .three = true := by decide
def e2262374803854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2262374803854 : Closed e2262374803854 ∧ code e2262374803854 = 11058467826062 := by decide
theorem cert_e2262374803854 : check e2262374803854 [[],[.under]] .three = true := by decide
def e2262374803910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2262374803910 : Closed e2262374803910 ∧ code e2262374803910 = 11058467826118 := by decide
theorem cert_e2262374803910 : check e2262374803910 [[],[.under]] .three = true := by decide
def e2262374803934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2262374803934 : Closed e2262374803934 ∧ code e2262374803934 = 11058467826142 := by decide
theorem cert_e2262374803934 : check e2262374803934 [[],[.under]] .three = true := by decide
def e2262374803950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262374803950 : Closed e2262374803950 ∧ code e2262374803950 = 11058467826158 := by decide
theorem cert_e2262374803950 : check e2262374803950 [[],[.under]] .three = true := by decide
def e2262374803958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2262374803958 : Closed e2262374803958 ∧ code e2262374803958 = 11058467826166 := by decide
theorem cert_e2262374803958 : check e2262374803958 [[],[.under]] .three = true := by decide
def e2262374804678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2262374804678 : Closed e2262374804678 ∧ code e2262374804678 = 11058467826886 := by decide
theorem cert_e2262374804678 : check e2262374804678 [[],[.under]] .three = true := by decide
def e2262374804702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2262374804702 : Closed e2262374804702 ∧ code e2262374804702 = 11058467826910 := by decide
theorem cert_e2262374804702 : check e2262374804702 [[],[.under]] .three = true := by decide
def e2262374804718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262374804718 : Closed e2262374804718 ∧ code e2262374804718 = 11058467826926 := by decide
theorem cert_e2262374804718 : check e2262374804718 [[],[.under]] .three = true := by decide
def e2262374804726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262374804726 : Closed e2262374804726 ∧ code e2262374804726 = 11058467826934 := by decide
theorem cert_e2262374804726 : check e2262374804726 [[],[.under]] .three = true := by decide
def e2262374804730 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2262374804730 : Closed e2262374804730 ∧ code e2262374804730 = 11058467826938 := by decide
theorem cert_e2262374804730 : check e2262374804730 [[],[.under]] .three = true := by decide
def e2262374805102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262374805102 : Closed e2262374805102 ∧ code e2262374805102 = 11058467827310 := by decide
theorem cert_e2262374805102 : check e2262374805102 [[],[.under]] .three = true := by decide
def e2262374805110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262374805110 : Closed e2262374805110 ∧ code e2262374805110 = 11058467827318 := by decide
theorem cert_e2262374805110 : check e2262374805110 [[],[.under]] .three = true := by decide
def e2262374805114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262374805114 : Closed e2262374805114 ∧ code e2262374805114 = 11058467827322 := by decide
theorem cert_e2262374805114 : check e2262374805114 [[],[.under]] .three = true := by decide
def e2262374805302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262374805302 : Closed e2262374805302 ∧ code e2262374805302 = 11058467827510 := by decide
private def t_e2262374805302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem cert_e2262374805302 : ¬ IsSelfInterpreter e2262374805302 :=
  wSource (t := t_e2262374805302) (replay_sound (ps := []) (t := e2262374805302) (by decide)) (by decide)
def e2262374805306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262374805306 : Closed e2262374805306 ∧ code e2262374805306 = 11058467827514 := by decide
private def t_e2262374805306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem cert_e2262374805306 : ¬ IsSelfInterpreter e2262374805306 :=
  wSource (t := t_e2262374805306) (replay_sound (ps := []) (t := e2262374805306) (by decide)) (by decide)
def e2262374812526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2262374812526 : Closed e2262374812526 ∧ code e2262374812526 = 11058467834734 := by decide
theorem cert_e2262374812526 : check e2262374812526 [[],[.under]] .smaller = true := by decide
def e2262374812534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2262374812534 : Closed e2262374812534 ∧ code e2262374812534 = 11058467834742 := by decide
theorem cert_e2262374812534 : check e2262374812534 [[],[.under]] .smaller = true := by decide
def e2262374812590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2262374812590 : Closed e2262374812590 ∧ code e2262374812590 = 11058467834798 := by decide
theorem cert_e2262374812590 : check e2262374812590 [[],[.under]] .smaller = true := by decide
def e2262374812602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2262374812602 : Closed e2262374812602 ∧ code e2262374812602 = 11058467834810 := by decide
theorem cert_e2262374812602 : check e2262374812602 [[],[.under]] .smaller = true := by decide
def e2262374812630 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2262374812630 : Closed e2262374812630 ∧ code e2262374812630 = 11058467834838 := by decide
theorem cert_e2262374812630 : check e2262374812630 [[],[.under]] .smaller = true := by decide
def e2262374812634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2262374812634 : Closed e2262374812634 ∧ code e2262374812634 = 11058467834842 := by decide
theorem cert_e2262374812634 : check e2262374812634 [[],[.under]] .smaller = true := by decide
def e2262374812910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2262374812910 : Closed e2262374812910 ∧ code e2262374812910 = 11058467835118 := by decide
theorem cert_e2262374812910 : check e2262374812910 [[],[.under]] .smaller = true := by decide
def e2262374812918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2262374812918 : Closed e2262374812918 ∧ code e2262374812918 = 11058467835126 := by decide
theorem cert_e2262374812918 : check e2262374812918 [[],[.under]] .smaller = true := by decide
def e2262374813294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2262374813294 : Closed e2262374813294 ∧ code e2262374813294 = 11058467835502 := by decide
theorem cert_e2262374813294 : check e2262374813294 [[],[.under]] .smaller = true := by decide
def e2262374813306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2262374813306 : Closed e2262374813306 ∧ code e2262374813306 = 11058467835514 := by decide
theorem cert_e2262374813306 : check e2262374813306 [[],[.under]] .smaller = true := by decide
def e2262374813494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2262374813494 : Closed e2262374813494 ∧ code e2262374813494 = 11058467835702 := by decide
theorem cert_e2262374813494 : check e2262374813494 [[],[.under]] .smaller = true := by decide
def e2262374813498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2262374813498 : Closed e2262374813498 ∧ code e2262374813498 = 11058467835706 := by decide
theorem cert_e2262374813498 : check e2262374813498 [[],[.under]] .smaller = true := by decide
def e2262374821310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2262374821310 : Closed e2262374821310 ∧ code e2262374821310 = 11058467843518 := by decide
theorem cert_e2262374821310 : check e2262374821310 [[],[.under]] .three = true := by decide
def e2262374821366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2262374821366 : Closed e2262374821366 ∧ code e2262374821366 = 11058467843574 := by decide
theorem cert_e2262374821366 : check e2262374821366 [[],[.under]] .three = true := by decide
def e2262374821566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2262374821566 : Closed e2262374821566 ∧ code e2262374821566 = 11058467843774 := by decide
theorem cert_e2262374821566 : check e2262374821566 [[],[.under]] .three = true := by decide
def e2262374821626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2262374821626 : Closed e2262374821626 ∧ code e2262374821626 = 11058467843834 := by decide
theorem cert_e2262374821626 : check e2262374821626 [[],[.under]] .three = true := by decide
def e2262374821846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2262374821846 : Closed e2262374821846 ∧ code e2262374821846 = 11058467844054 := by decide
theorem cert_e2262374821846 : check e2262374821846 [[],[.under]] .three = true := by decide
def e2262374821850 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2262374821850 : Closed e2262374821850 ∧ code e2262374821850 = 11058467844058 := by decide
theorem cert_e2262374821850 : check e2262374821850 [[],[.under]] .three = true := by decide
def e2262374822846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2262374822846 : Closed e2262374822846 ∧ code e2262374822846 = 11058467845054 := by decide
theorem cert_e2262374822846 : check e2262374822846 [[],[.under]] .three = true := by decide
def e2262374822902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2262374822902 : Closed e2262374822902 ∧ code e2262374822902 = 11058467845110 := by decide
theorem cert_e2262374822902 : check e2262374822902 [[],[.under]] .three = true := by decide
def e2262374824382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2262374824382 : Closed e2262374824382 ∧ code e2262374824382 = 11058467846590 := by decide
theorem cert_e2262374824382 : check e2262374824382 [[],[.under]] .three = true := by decide
def e2262374824442 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2262374824442 : Closed e2262374824442 ∧ code e2262374824442 = 11058467846650 := by decide
theorem cert_e2262374824442 : check e2262374824442 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262374805302
#print axioms Blc.Floor43.cert_e2262374805306
