import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606398893678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606398893678 : Closed e606398893678 ∧ code e606398893678 = 9402491915886 := by decide
theorem cert_e606398893678 : check e606398893678 [[.under]] .sourceHead = true := by decide
def e606398893690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606398893690 : Closed e606398893690 ∧ code e606398893690 = 9402491915898 := by decide
theorem cert_e606398893690 : check e606398893690 [[.under]] .sourceHead = true := by decide
def e606398893878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606398893878 : Closed e606398893878 ∧ code e606398893878 = 9402491916086 := by decide
theorem cert_e606398893878 : check e606398893878 [[.under]] .sourceHead = true := by decide
def e606398893882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606398893882 : Closed e606398893882 ∧ code e606398893882 = 9402491916090 := by decide
theorem cert_e606398893882 : check e606398893882 [[.under]] .sourceHead = true := by decide
def e606398898654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e606398898654 : Closed e606398898654 ∧ code e606398898654 = 9402491920862 := by decide
theorem cert_e606398898654 : check e606398898654 [[.under]] .sourceHead = true := by decide
def e606398898678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e606398898678 : Closed e606398898678 ∧ code e606398898678 = 9402491920886 := by decide
theorem cert_e606398898678 : check e606398898678 [[.under]] .sourceHead = true := by decide
def e606398899630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e606398899630 : Closed e606398899630 ∧ code e606398899630 = 9402491921838 := by decide
theorem cert_e606398899630 : check e606398899630 [[.under]] .sourceHead = true := by decide
def e606398899642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e606398899642 : Closed e606398899642 ∧ code e606398899642 = 9402491921850 := by decide
theorem cert_e606398899642 : check e606398899642 [[.under]] .sourceHead = true := by decide
def e606398899690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e606398899690 : Closed e606398899690 ∧ code e606398899690 = 9402491921898 := by decide
theorem cert_e606398899690 : check e606398899690 [[.under]] .sourceHead = true := by decide
def e606398899822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606398899822 : Closed e606398899822 ∧ code e606398899822 = 9402491922030 := by decide
theorem cert_e606398899822 : check e606398899822 [[.under]] .sourceHead = true := by decide
def e606398899834 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606398899834 : Closed e606398899834 ∧ code e606398899834 = 9402491922042 := by decide
theorem cert_e606398899834 : check e606398899834 [[.under]] .sourceHead = true := by decide
def e606398900122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606398900122 : Closed e606398900122 ∧ code e606398900122 = 9402491922330 := by decide
theorem cert_e606398900122 : check e606398900122 [[.under]] .sourceHead = true := by decide
def e606398902510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e606398902510 : Closed e606398902510 ∧ code e606398902510 = 9402491924718 := by decide
theorem cert_e606398902510 : check e606398902510 [[.under]] .sourceHead = true := by decide
def e606398902518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e606398902518 : Closed e606398902518 ∧ code e606398902518 = 9402491924726 := by decide
theorem cert_e606398902518 : check e606398902518 [[.under]] .sourceHead = true := by decide
def e606398902998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e606398902998 : Closed e606398902998 ∧ code e606398902998 = 9402491925206 := by decide
theorem cert_e606398902998 : check e606398902998 [[.under]] .sourceHead = true := by decide
def e606398903002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e606398903002 : Closed e606398903002 ∧ code e606398903002 = 9402491925210 := by decide
theorem cert_e606398903002 : check e606398903002 [[.under]] .sourceHead = true := by decide
def e606398903018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e606398903018 : Closed e606398903018 ∧ code e606398903018 = 9402491925226 := by decide
theorem cert_e606398903018 : check e606398903018 [[.under]] .sourceHead = true := by decide
def e606398903094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606398903094 : Closed e606398903094 ∧ code e606398903094 = 9402491925302 := by decide
theorem cert_e606398903094 : check e606398903094 [[.under]] .sourceHead = true := by decide
def e606398903098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606398903098 : Closed e606398903098 ∧ code e606398903098 = 9402491925306 := by decide
theorem cert_e606398903098 : check e606398903098 [[.under]] .sourceHead = true := by decide
def e606398903194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606398903194 : Closed e606398903194 ∧ code e606398903194 = 9402491925402 := by decide
theorem cert_e606398903194 : check e606398903194 [[.under]] .sourceHead = true := by decide
def e606399040366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606399040366 : Closed e606399040366 ∧ code e606399040366 = 9402492062574 := by decide
theorem cert_e606399040366 : check e606399040366 [[.under]] .sourceHead = true := by decide
def e606399040374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606399040374 : Closed e606399040374 ∧ code e606399040374 = 9402492062582 := by decide
theorem cert_e606399040374 : check e606399040374 [[.under]] .sourceHead = true := by decide
def e606399040430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606399040430 : Closed e606399040430 ∧ code e606399040430 = 9402492062638 := by decide
theorem cert_e606399040430 : check e606399040430 [[.under]] .sourceHead = true := by decide
def e606399040442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606399040442 : Closed e606399040442 ∧ code e606399040442 = 9402492062650 := by decide
theorem cert_e606399040442 : check e606399040442 [[.under]] .sourceHead = true := by decide
def e606399040470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606399040470 : Closed e606399040470 ∧ code e606399040470 = 9402492062678 := by decide
theorem cert_e606399040470 : check e606399040470 [[.under]] .sourceHead = true := by decide
def e606399040474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606399040474 : Closed e606399040474 ∧ code e606399040474 = 9402492062682 := by decide
theorem cert_e606399040474 : check e606399040474 [[.under]] .sourceHead = true := by decide
def e606399040750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606399040750 : Closed e606399040750 ∧ code e606399040750 = 9402492062958 := by decide
theorem cert_e606399040750 : check e606399040750 [[.under]] .sourceHead = true := by decide
def e606399040758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606399040758 : Closed e606399040758 ∧ code e606399040758 = 9402492062966 := by decide
theorem cert_e606399040758 : check e606399040758 [[.under]] .sourceHead = true := by decide
def e606399041134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606399041134 : Closed e606399041134 ∧ code e606399041134 = 9402492063342 := by decide
theorem cert_e606399041134 : check e606399041134 [[.under]] .sourceHead = true := by decide
def e606399041146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606399041146 : Closed e606399041146 ∧ code e606399041146 = 9402492063354 := by decide
theorem cert_e606399041146 : check e606399041146 [[.under]] .sourceHead = true := by decide
def e606399041334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606399041334 : Closed e606399041334 ∧ code e606399041334 = 9402492063542 := by decide
theorem cert_e606399041334 : check e606399041334 [[.under]] .sourceHead = true := by decide
def e606399041338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606399041338 : Closed e606399041338 ∧ code e606399041338 = 9402492063546 := by decide
theorem cert_e606399041338 : check e606399041338 [[.under]] .sourceHead = true := by decide
def e606399370974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e606399370974 : Closed e606399370974 ∧ code e606399370974 = 9402492393182 := by decide
theorem cert_e606399370974 : check e606399370974 [[.under]] .sourceHead = true := by decide
def e606399370998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e606399370998 : Closed e606399370998 ∧ code e606399370998 = 9402492393206 := by decide
theorem cert_e606399370998 : check e606399370998 [[.under]] .sourceHead = true := by decide
def e606399371102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e606399371102 : Closed e606399371102 ∧ code e606399371102 = 9402492393310 := by decide
theorem cert_e606399371102 : check e606399371102 [[.under]] .sourceHead = true := by decide
def e606399371130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e606399371130 : Closed e606399371130 ∧ code e606399371130 = 9402492393338 := by decide
theorem cert_e606399371130 : check e606399371130 [[.under]] .sourceHead = true := by decide
def e606399371222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e606399371222 : Closed e606399371222 ∧ code e606399371222 = 9402492393430 := by decide
theorem cert_e606399371222 : check e606399371222 [[.under]] .sourceHead = true := by decide
def e606399371226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e606399371226 : Closed e606399371226 ∧ code e606399371226 = 9402492393434 := by decide
theorem cert_e606399371226 : check e606399371226 [[.under]] .sourceHead = true := by decide
def e606399371742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e606399371742 : Closed e606399371742 ∧ code e606399371742 = 9402492393950 := by decide
theorem cert_e606399371742 : check e606399371742 [[.under]] .sourceHead = true := by decide
def e606399371766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e606399371766 : Closed e606399371766 ∧ code e606399371766 = 9402492393974 := by decide
theorem cert_e606399371766 : check e606399371766 [[.under]] .sourceHead = true := by decide
def e606399372510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e606399372510 : Closed e606399372510 ∧ code e606399372510 = 9402492394718 := by decide
theorem cert_e606399372510 : check e606399372510 [[.under]] .sourceHead = true := by decide
def e606399372538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e606399372538 : Closed e606399372538 ∧ code e606399372538 = 9402492394746 := by decide
theorem cert_e606399372538 : check e606399372538 [[.under]] .sourceHead = true := by decide
def e606399373110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606399373110 : Closed e606399373110 ∧ code e606399373110 = 9402492395318 := by decide
theorem cert_e606399373110 : check e606399373110 [[.under]] .sourceHead = true := by decide
def e606399373114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606399373114 : Closed e606399373114 ∧ code e606399373114 = 9402492395322 := by decide
theorem cert_e606399373114 : check e606399373114 [[.under]] .sourceHead = true := by decide
def e606399387886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e606399387886 : Closed e606399387886 ∧ code e606399387886 = 9402492410094 := by decide
theorem cert_e606399387886 : check e606399387886 [[.under]] .sourceHead = true := by decide
def e606399387894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e606399387894 : Closed e606399387894 ∧ code e606399387894 = 9402492410102 := by decide
theorem cert_e606399387894 : check e606399387894 [[.under]] .sourceHead = true := by decide
def e606399388446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e606399388446 : Closed e606399388446 ∧ code e606399388446 = 9402492410654 := by decide
theorem cert_e606399388446 : check e606399388446 [[.under]] .sourceHead = true := by decide
def e606399388558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e606399388558 : Closed e606399388558 ∧ code e606399388558 = 9402492410766 := by decide
theorem cert_e606399388558 : check e606399388558 [[.under]] .sourceHead = true := by decide
def e606399388782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e606399388782 : Closed e606399388782 ∧ code e606399388782 = 9402492410990 := by decide
theorem cert_e606399388782 : check e606399388782 [[.under]] .sourceHead = true := by decide
def e606399388794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e606399388794 : Closed e606399388794 ∧ code e606399388794 = 9402492411002 := by decide
theorem cert_e606399388794 : check e606399388794 [[.under]] .sourceHead = true := by decide
def e606399388958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e606399388958 : Closed e606399388958 ∧ code e606399388958 = 9402492411166 := by decide
theorem cert_e606399388958 : check e606399388958 [[.under]] .sourceHead = true := by decide
def e606399389126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e606399389126 : Closed e606399389126 ∧ code e606399389126 = 9402492411334 := by decide
theorem cert_e606399389126 : check e606399389126 [[.under]] .sourceHead = true := by decide
def e606399389238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e606399389238 : Closed e606399389238 ∧ code e606399389238 = 9402492411446 := by decide
theorem cert_e606399389238 : check e606399389238 [[.under]] .sourceHead = true := by decide
def e606399389242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e606399389242 : Closed e606399389242 ∧ code e606399389242 = 9402492411450 := by decide
theorem cert_e606399389242 : check e606399389242 [[.under]] .sourceHead = true := by decide
def e606399389326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e606399389326 : Closed e606399389326 ∧ code e606399389326 = 9402492411534 := by decide
theorem cert_e606399389326 : check e606399389326 [[.under]] .sourceHead = true := by decide
def e606399389382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e606399389382 : Closed e606399389382 ∧ code e606399389382 = 9402492411590 := by decide
theorem cert_e606399389382 : check e606399389382 [[.under]] .sourceHead = true := by decide
def e606399391518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e606399391518 : Closed e606399391518 ∧ code e606399391518 = 9402492413726 := by decide
theorem cert_e606399391518 : check e606399391518 [[.under]] .sourceHead = true := by decide
def e606399391630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e606399391630 : Closed e606399391630 ∧ code e606399391630 = 9402492413838 := by decide
theorem cert_e606399391630 : check e606399391630 [[.under]] .sourceHead = true := by decide
def e606399394590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e606399394590 : Closed e606399394590 ∧ code e606399394590 = 9402492416798 := by decide
theorem cert_e606399394590 : check e606399394590 [[.under]] .sourceHead = true := by decide
def e606399394758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e606399394758 : Closed e606399394758 ∧ code e606399394758 = 9402492416966 := by decide
theorem cert_e606399394758 : check e606399394758 [[.under]] .sourceHead = true := by decide
def e606399396238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e606399396238 : Closed e606399396238 ∧ code e606399396238 = 9402492418446 := by decide
theorem cert_e606399396238 : check e606399396238 [[.under]] .sourceHead = true := by decide
def e606399396294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e606399396294 : Closed e606399396294 ∧ code e606399396294 = 9402492418502 := by decide
theorem cert_e606399396294 : check e606399396294 [[.under]] .sourceHead = true := by decide
def e606407241146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))))
theorem wire_e606407241146 : Closed e606407241146 ∧ code e606407241146 = 9402500263354 := by decide
theorem cert_e606407241146 : check e606407241146 [[.under]] .sourceHead = true := by decide
def e606407241178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))))
theorem wire_e606407241178 : Closed e606407241178 ∧ code e606407241178 = 9402500263386 := by decide
theorem cert_e606407241178 : check e606407241178 [[.under]] .sourceHead = true := by decide
def e606407241402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))))
theorem wire_e606407241402 : Closed e606407241402 ∧ code e606407241402 = 9402500263610 := by decide
theorem cert_e606407241402 : check e606407241402 [[.under]] .sourceHead = true := by decide
def e606407241450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))))
theorem wire_e606407241450 : Closed e606407241450 ∧ code e606407241450 = 9402500263658 := by decide
theorem cert_e606407241450 : check e606407241450 [[.under]] .sourceHead = true := by decide
def e606407241562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))))
theorem wire_e606407241562 : Closed e606407241562 ∧ code e606407241562 = 9402500263770 := by decide
theorem cert_e606407241562 : check e606407241562 [[.under]] .sourceHead = true := by decide
def e606407241578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))))
theorem wire_e606407241578 : Closed e606407241578 ∧ code e606407241578 = 9402500263786 := by decide
theorem cert_e606407241578 : check e606407241578 [[.under]] .sourceHead = true := by decide
def e606407242682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e606407242682 : Closed e606407242682 ∧ code e606407242682 = 9402500264890 := by decide
theorem cert_e606407242682 : check e606407242682 [[.under]] .sourceHead = true := by decide
def e606407242714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e606407242714 : Closed e606407242714 ∧ code e606407242714 = 9402500264922 := by decide
theorem cert_e606407242714 : check e606407242714 [[.under]] .sourceHead = true := by decide
def e606407244218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e606407244218 : Closed e606407244218 ∧ code e606407244218 = 9402500266426 := by decide
theorem cert_e606407244218 : check e606407244218 [[.under]] .sourceHead = true := by decide
def e606407244266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e606407244266 : Closed e606407244266 ∧ code e606407244266 = 9402500266474 := by decide
theorem cert_e606407244266 : check e606407244266 [[.under]] .sourceHead = true := by decide
def e606407245018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e606407245018 : Closed e606407245018 ∧ code e606407245018 = 9402500267226 := by decide
theorem cert_e606407245018 : check e606407245018 [[.under]] .sourceHead = true := by decide
def e606407245034 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e606407245034 : Closed e606407245034 ∧ code e606407245034 = 9402500267242 := by decide
theorem cert_e606407245034 : check e606407245034 [[.under]] .sourceHead = true := by decide
def e606407494510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e606407494510 : Closed e606407494510 ∧ code e606407494510 = 9402500516718 := by decide
theorem cert_e606407494510 : check e606407494510 [[.under]] .sourceHead = true := by decide
def e606407494518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e606407494518 : Closed e606407494518 ∧ code e606407494518 = 9402500516726 := by decide
theorem cert_e606407494518 : check e606407494518 [[.under]] .sourceHead = true := by decide
def e606407494574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e606407494574 : Closed e606407494574 ∧ code e606407494574 = 9402500516782 := by decide
theorem cert_e606407494574 : check e606407494574 [[.under]] .sourceHead = true := by decide
def e606407494586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e606407494586 : Closed e606407494586 ∧ code e606407494586 = 9402500516794 := by decide
theorem cert_e606407494586 : check e606407494586 [[.under]] .sourceHead = true := by decide
def e606407494614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e606407494614 : Closed e606407494614 ∧ code e606407494614 = 9402500516822 := by decide
theorem cert_e606407494614 : check e606407494614 [[.under]] .sourceHead = true := by decide
def e606407494618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e606407494618 : Closed e606407494618 ∧ code e606407494618 = 9402500516826 := by decide
theorem cert_e606407494618 : check e606407494618 [[.under]] .sourceHead = true := by decide
def e606407494894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e606407494894 : Closed e606407494894 ∧ code e606407494894 = 9402500517102 := by decide
theorem cert_e606407494894 : check e606407494894 [[.under]] .sourceHead = true := by decide
def e606407494902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e606407494902 : Closed e606407494902 ∧ code e606407494902 = 9402500517110 := by decide
theorem cert_e606407494902 : check e606407494902 [[.under]] .sourceHead = true := by decide
def e606407495278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e606407495278 : Closed e606407495278 ∧ code e606407495278 = 9402500517486 := by decide
theorem cert_e606407495278 : check e606407495278 [[.under]] .sourceHead = true := by decide
def e606407495290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e606407495290 : Closed e606407495290 ∧ code e606407495290 = 9402500517498 := by decide
theorem cert_e606407495290 : check e606407495290 [[.under]] .sourceHead = true := by decide
def e606407495478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e606407495478 : Closed e606407495478 ∧ code e606407495478 = 9402500517686 := by decide
theorem cert_e606407495478 : check e606407495478 [[.under]] .sourceHead = true := by decide
def e606407495482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e606407495482 : Closed e606407495482 ∧ code e606407495482 = 9402500517690 := by decide
theorem cert_e606407495482 : check e606407495482 [[.under]] .sourceHead = true := by decide
def e606408289758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e606408289758 : Closed e606408289758 ∧ code e606408289758 = 9402501311966 := by decide
theorem cert_e606408289758 : check e606408289758 [[.under]] .sourceHead = true := by decide
def e606408289774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e606408289774 : Closed e606408289774 ∧ code e606408289774 = 9402501311982 := by decide
theorem cert_e606408289774 : check e606408289774 [[.under]] .sourceHead = true := by decide
def e606408290142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e606408290142 : Closed e606408290142 ∧ code e606408290142 = 9402501312350 := by decide
theorem cert_e606408290142 : check e606408290142 [[.under]] .sourceHead = true := by decide
def e606408290170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e606408290170 : Closed e606408290170 ∧ code e606408290170 = 9402501312378 := by decide
theorem cert_e606408290170 : check e606408290170 [[.under]] .sourceHead = true := by decide
def e606408290222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e606408290222 : Closed e606408290222 ∧ code e606408290222 = 9402501312430 := by decide
theorem cert_e606408290222 : check e606408290222 [[.under]] .sourceHead = true := by decide
def e606408290234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e606408290234 : Closed e606408290234 ∧ code e606408290234 = 9402501312442 := by decide
theorem cert_e606408290234 : check e606408290234 [[.under]] .sourceHead = true := by decide
def e606408291294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e606408291294 : Closed e606408291294 ∧ code e606408291294 = 9402501313502 := by decide
theorem cert_e606408291294 : check e606408291294 [[.under]] .sourceHead = true := by decide
def e606408291310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e606408291310 : Closed e606408291310 ∧ code e606408291310 = 9402501313518 := by decide
theorem cert_e606408291310 : check e606408291310 [[.under]] .sourceHead = true := by decide
def e606408293598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e606408293598 : Closed e606408293598 ∧ code e606408293598 = 9402501315806 := by decide
theorem cert_e606408293598 : check e606408293598 [[.under]] .sourceHead = true := by decide
def e606408293626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e606408293626 : Closed e606408293626 ∧ code e606408293626 = 9402501315834 := by decide
theorem cert_e606408293626 : check e606408293626 [[.under]] .sourceHead = true := by decide
def e606408293998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606408293998 : Closed e606408293998 ∧ code e606408293998 = 9402501316206 := by decide
theorem cert_e606408293998 : check e606408293998 [[.under]] .sourceHead = true := by decide
def e606408294010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606408294010 : Closed e606408294010 ∧ code e606408294010 = 9402501316218 := by decide
theorem cert_e606408294010 : check e606408294010 [[.under]] .sourceHead = true := by decide
def e606408322414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e606408322414 : Closed e606408322414 ∧ code e606408322414 = 9402501344622 := by decide
theorem cert_e606408322414 : check e606408322414 [[.under]] .sourceHead = true := by decide
def e606408322422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e606408322422 : Closed e606408322422 ∧ code e606408322422 = 9402501344630 := by decide
theorem cert_e606408322422 : check e606408322422 [[.under]] .sourceHead = true := by decide
def e606408322478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e606408322478 : Closed e606408322478 ∧ code e606408322478 = 9402501344686 := by decide
theorem cert_e606408322478 : check e606408322478 [[.under]] .sourceHead = true := by decide
def e606408322490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e606408322490 : Closed e606408322490 ∧ code e606408322490 = 9402501344698 := by decide
theorem cert_e606408322490 : check e606408322490 [[.under]] .sourceHead = true := by decide
def e606408322518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e606408322518 : Closed e606408322518 ∧ code e606408322518 = 9402501344726 := by decide
theorem cert_e606408322518 : check e606408322518 [[.under]] .sourceHead = true := by decide
def e606408322522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e606408322522 : Closed e606408322522 ∧ code e606408322522 = 9402501344730 := by decide
theorem cert_e606408322522 : check e606408322522 [[.under]] .sourceHead = true := by decide
def e606408322734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e606408322734 : Closed e606408322734 ∧ code e606408322734 = 9402501344942 := by decide
theorem cert_e606408322734 : check e606408322734 [[.under]] .sourceHead = true := by decide
def e606408322746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e606408322746 : Closed e606408322746 ∧ code e606408322746 = 9402501344954 := by decide
theorem cert_e606408322746 : check e606408322746 [[.under]] .sourceHead = true := by decide
def e606408322794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e606408322794 : Closed e606408322794 ∧ code e606408322794 = 9402501345002 := by decide
theorem cert_e606408322794 : check e606408322794 [[.under]] .sourceHead = true := by decide
def e606408322902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e606408322902 : Closed e606408322902 ∧ code e606408322902 = 9402501345110 := by decide
theorem cert_e606408322902 : check e606408322902 [[.under]] .sourceHead = true := by decide
def e606408322906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e606408322906 : Closed e606408322906 ∧ code e606408322906 = 9402501345114 := by decide
theorem cert_e606408322906 : check e606408322906 [[.under]] .sourceHead = true := by decide
def e606408322922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e606408322922 : Closed e606408322922 ∧ code e606408322922 = 9402501345130 := by decide
theorem cert_e606408322922 : check e606408322922 [[.under]] .sourceHead = true := by decide
def e606408323950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e606408323950 : Closed e606408323950 ∧ code e606408323950 = 9402501346158 := by decide
theorem cert_e606408323950 : check e606408323950 [[.under]] .sourceHead = true := by decide
def e606408323958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e606408323958 : Closed e606408323958 ∧ code e606408323958 = 9402501346166 := by decide
theorem cert_e606408323958 : check e606408323958 [[.under]] .sourceHead = true := by decide
def e606408324014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e606408324014 : Closed e606408324014 ∧ code e606408324014 = 9402501346222 := by decide
theorem cert_e606408324014 : check e606408324014 [[.under]] .sourceHead = true := by decide
def e606408324026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e606408324026 : Closed e606408324026 ∧ code e606408324026 = 9402501346234 := by decide
theorem cert_e606408324026 : check e606408324026 [[.under]] .sourceHead = true := by decide
def e606408324054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e606408324054 : Closed e606408324054 ∧ code e606408324054 = 9402501346262 := by decide
theorem cert_e606408324054 : check e606408324054 [[.under]] .sourceHead = true := by decide
def e606408324058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e606408324058 : Closed e606408324058 ∧ code e606408324058 = 9402501346266 := by decide
theorem cert_e606408324058 : check e606408324058 [[.under]] .sourceHead = true := by decide
def e606408324334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e606408324334 : Closed e606408324334 ∧ code e606408324334 = 9402501346542 := by decide
theorem cert_e606408324334 : check e606408324334 [[.under]] .sourceHead = true := by decide
def e606408324342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e606408324342 : Closed e606408324342 ∧ code e606408324342 = 9402501346550 := by decide
theorem cert_e606408324342 : check e606408324342 [[.under]] .sourceHead = true := by decide
def e606408324718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606408324718 : Closed e606408324718 ∧ code e606408324718 = 9402501346926 := by decide
theorem cert_e606408324718 : check e606408324718 [[.under]] .sourceHead = true := by decide
def e606408324730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606408324730 : Closed e606408324730 ∧ code e606408324730 = 9402501346938 := by decide
theorem cert_e606408324730 : check e606408324730 [[.under]] .sourceHead = true := by decide
def e606408324918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606408324918 : Closed e606408324918 ∧ code e606408324918 = 9402501347126 := by decide
theorem cert_e606408324918 : check e606408324918 [[.under]] .sourceHead = true := by decide
def e606408324922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606408324922 : Closed e606408324922 ∧ code e606408324922 = 9402501347130 := by decide
theorem cert_e606408324922 : check e606408324922 [[.under]] .sourceHead = true := by decide
def e606408325550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e606408325550 : Closed e606408325550 ∧ code e606408325550 = 9402501347758 := by decide
theorem cert_e606408325550 : check e606408325550 [[.under]] .sourceHead = true := by decide
def e606408325562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e606408325562 : Closed e606408325562 ∧ code e606408325562 = 9402501347770 := by decide
theorem cert_e606408325562 : check e606408325562 [[.under]] .sourceHead = true := by decide
def e606408325610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e606408325610 : Closed e606408325610 ∧ code e606408325610 = 9402501347818 := by decide
theorem cert_e606408325610 : check e606408325610 [[.under]] .sourceHead = true := by decide
def e606408325742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606408325742 : Closed e606408325742 ∧ code e606408325742 = 9402501347950 := by decide
theorem cert_e606408325742 : check e606408325742 [[.under]] .sourceHead = true := by decide
def e606408325754 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606408325754 : Closed e606408325754 ∧ code e606408325754 = 9402501347962 := by decide
theorem cert_e606408325754 : check e606408325754 [[.under]] .sourceHead = true := by decide
def e606408326042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606408326042 : Closed e606408326042 ∧ code e606408326042 = 9402501348250 := by decide
theorem cert_e606408326042 : check e606408326042 [[.under]] .sourceHead = true := by decide
def e606408326358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e606408326358 : Closed e606408326358 ∧ code e606408326358 = 9402501348566 := by decide
theorem cert_e606408326358 : check e606408326358 [[.under]] .sourceHead = true := by decide
def e606408326362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e606408326362 : Closed e606408326362 ∧ code e606408326362 = 9402501348570 := by decide
theorem cert_e606408326362 : check e606408326362 [[.under]] .sourceHead = true := by decide
def e606408326378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e606408326378 : Closed e606408326378 ∧ code e606408326378 = 9402501348586 := by decide
theorem cert_e606408326378 : check e606408326378 [[.under]] .sourceHead = true := by decide
def e606408326454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606408326454 : Closed e606408326454 ∧ code e606408326454 = 9402501348662 := by decide
theorem cert_e606408326454 : check e606408326454 [[.under]] .sourceHead = true := by decide
def e606408326458 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606408326458 : Closed e606408326458 ∧ code e606408326458 = 9402501348666 := by decide
theorem cert_e606408326458 : check e606408326458 [[.under]] .sourceHead = true := by decide
def e606408326554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606408326554 : Closed e606408326554 ∧ code e606408326554 = 9402501348762 := by decide
theorem cert_e606408326554 : check e606408326554 [[.under]] .sourceHead = true := by decide
def e606408328158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e606408328158 : Closed e606408328158 ∧ code e606408328158 = 9402501350366 := by decide
theorem cert_e606408328158 : check e606408328158 [[.under]] .sourceHead = true := by decide
def e606408328174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e606408328174 : Closed e606408328174 ∧ code e606408328174 = 9402501350382 := by decide
theorem cert_e606408328174 : check e606408328174 [[.under]] .sourceHead = true := by decide
def e606408330094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606408330094 : Closed e606408330094 ∧ code e606408330094 = 9402501352302 := by decide
theorem cert_e606408330094 : check e606408330094 [[.under]] .sourceHead = true := by decide
def e606408330102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606408330102 : Closed e606408330102 ∧ code e606408330102 = 9402501352310 := by decide
theorem cert_e606408330102 : check e606408330102 [[.under]] .sourceHead = true := by decide
def e606408330158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606408330158 : Closed e606408330158 ∧ code e606408330158 = 9402501352366 := by decide
theorem cert_e606408330158 : check e606408330158 [[.under]] .sourceHead = true := by decide
def e606408330170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606408330170 : Closed e606408330170 ∧ code e606408330170 = 9402501352378 := by decide
theorem cert_e606408330170 : check e606408330170 [[.under]] .sourceHead = true := by decide
def e606408330198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606408330198 : Closed e606408330198 ∧ code e606408330198 = 9402501352406 := by decide
theorem cert_e606408330198 : check e606408330198 [[.under]] .sourceHead = true := by decide
def e606408330202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606408330202 : Closed e606408330202 ∧ code e606408330202 = 9402501352410 := by decide
theorem cert_e606408330202 : check e606408330202 [[.under]] .sourceHead = true := by decide
def e606408330478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606408330478 : Closed e606408330478 ∧ code e606408330478 = 9402501352686 := by decide
theorem cert_e606408330478 : check e606408330478 [[.under]] .sourceHead = true := by decide
def e606408330486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606408330486 : Closed e606408330486 ∧ code e606408330486 = 9402501352694 := by decide
theorem cert_e606408330486 : check e606408330486 [[.under]] .sourceHead = true := by decide
def e606408330862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606408330862 : Closed e606408330862 ∧ code e606408330862 = 9402501353070 := by decide
theorem cert_e606408330862 : check e606408330862 [[.under]] .sourceHead = true := by decide
def e606408330874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606408330874 : Closed e606408330874 ∧ code e606408330874 = 9402501353082 := by decide
theorem cert_e606408330874 : check e606408330874 [[.under]] .sourceHead = true := by decide
def e606408331062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606408331062 : Closed e606408331062 ∧ code e606408331062 = 9402501353270 := by decide
theorem cert_e606408331062 : check e606408331062 [[.under]] .sourceHead = true := by decide
def e606408331066 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606408331066 : Closed e606408331066 ∧ code e606408331066 = 9402501353274 := by decide
theorem cert_e606408331066 : check e606408331066 [[.under]] .sourceHead = true := by decide
def e606408335838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e606408335838 : Closed e606408335838 ∧ code e606408335838 = 9402501358046 := by decide
theorem cert_e606408335838 : check e606408335838 [[.under]] .sourceHead = true := by decide
def e606408335862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e606408335862 : Closed e606408335862 ∧ code e606408335862 = 9402501358070 := by decide
theorem cert_e606408335862 : check e606408335862 [[.under]] .sourceHead = true := by decide
def e606408336814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e606408336814 : Closed e606408336814 ∧ code e606408336814 = 9402501359022 := by decide
theorem cert_e606408336814 : check e606408336814 [[.under]] .sourceHead = true := by decide
def e606408336826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e606408336826 : Closed e606408336826 ∧ code e606408336826 = 9402501359034 := by decide
theorem cert_e606408336826 : check e606408336826 [[.under]] .sourceHead = true := by decide
def e606408336874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e606408336874 : Closed e606408336874 ∧ code e606408336874 = 9402501359082 := by decide
theorem cert_e606408336874 : check e606408336874 [[.under]] .sourceHead = true := by decide
def e606408337006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606408337006 : Closed e606408337006 ∧ code e606408337006 = 9402501359214 := by decide
theorem cert_e606408337006 : check e606408337006 [[.under]] .sourceHead = true := by decide
def e606408337018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606408337018 : Closed e606408337018 ∧ code e606408337018 = 9402501359226 := by decide
theorem cert_e606408337018 : check e606408337018 [[.under]] .sourceHead = true := by decide
def e606408337306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606408337306 : Closed e606408337306 ∧ code e606408337306 = 9402501359514 := by decide
theorem cert_e606408337306 : check e606408337306 [[.under]] .sourceHead = true := by decide
def e606408339694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e606408339694 : Closed e606408339694 ∧ code e606408339694 = 9402501361902 := by decide
theorem cert_e606408339694 : check e606408339694 [[.under]] .sourceHead = true := by decide
def e606408339702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e606408339702 : Closed e606408339702 ∧ code e606408339702 = 9402501361910 := by decide
theorem cert_e606408339702 : check e606408339702 [[.under]] .sourceHead = true := by decide
def e606408340182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e606408340182 : Closed e606408340182 ∧ code e606408340182 = 9402501362390 := by decide
theorem cert_e606408340182 : check e606408340182 [[.under]] .sourceHead = true := by decide
def e606408340186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e606408340186 : Closed e606408340186 ∧ code e606408340186 = 9402501362394 := by decide
theorem cert_e606408340186 : check e606408340186 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
