import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373646022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373646022 : Closed e2422373646022 ∧ code e2422373646022 = 11218466668230 := by decide
theorem cert_e2422373646022 : check e2422373646022 [[],[]] .three = true := by decide
def e2422373646046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 1)))) (.var 3)))))))
theorem wire_e2422373646046 : Closed e2422373646046 ∧ code e2422373646046 = 11218466668254 := by decide
theorem cert_e2422373646046 : check e2422373646046 [[],[]] .three = true := by decide
def e2422373646062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 2)))) (.var 2)))))))
theorem wire_e2422373646062 : Closed e2422373646062 ∧ code e2422373646062 = 11218466668270 := by decide
theorem cert_e2422373646062 : check e2422373646062 [[],[]] .three = true := by decide
def e2422373646070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 3)))) (.var 1)))))))
theorem wire_e2422373646070 : Closed e2422373646070 ∧ code e2422373646070 = 11218466668278 := by decide
theorem cert_e2422373646070 : check e2422373646070 [[],[]] .three = true := by decide
def e2422373646074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 4) (.var 4)))) (.var 0)))))))
theorem wire_e2422373646074 : Closed e2422373646074 ∧ code e2422373646074 = 11218466668282 := by decide
theorem cert_e2422373646074 : check e2422373646074 [[],[]] .three = true := by decide
def e2422373652190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2422373652190 : Closed e2422373652190 ∧ code e2422373652190 = 11218466674398 := by decide
theorem cert_e2422373652190 : check e2422373652190 [[],[]] .three = true := by decide
def e2422373652206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2422373652206 : Closed e2422373652206 ∧ code e2422373652206 = 11218466674414 := by decide
theorem cert_e2422373652206 : check e2422373652206 [[],[]] .smaller = true := by decide
def e2422373652214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2422373652214 : Closed e2422373652214 ∧ code e2422373652214 = 11218466674422 := by decide
theorem cert_e2422373652214 : check e2422373652214 [[],[]] .three = true := by decide
def e2422373652318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2422373652318 : Closed e2422373652318 ∧ code e2422373652318 = 11218466674526 := by decide
theorem cert_e2422373652318 : check e2422373652318 [[],[]] .three = true := by decide
def e2422373652346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2422373652346 : Closed e2422373652346 ∧ code e2422373652346 = 11218466674554 := by decide
theorem cert_e2422373652346 : check e2422373652346 [[],[]] .three = true := by decide
def e2422373652398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2422373652398 : Closed e2422373652398 ∧ code e2422373652398 = 11218466674606 := by decide
theorem cert_e2422373652398 : check e2422373652398 [[],[]] .smaller = true := by decide
def e2422373652410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2422373652410 : Closed e2422373652410 ∧ code e2422373652410 = 11218466674618 := by decide
theorem cert_e2422373652410 : check e2422373652410 [[],[]] .smaller = true := by decide
def e2422373652438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2422373652438 : Closed e2422373652438 ∧ code e2422373652438 = 11218466674646 := by decide
theorem cert_e2422373652438 : check e2422373652438 [[],[]] .three = true := by decide
def e2422373652442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2422373652442 : Closed e2422373652442 ∧ code e2422373652442 = 11218466674650 := by decide
theorem cert_e2422373652442 : check e2422373652442 [[],[]] .three = true := by decide
def e2422373652958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373652958 : Closed e2422373652958 ∧ code e2422373652958 = 11218466675166 := by decide
theorem cert_e2422373652958 : check e2422373652958 [[],[]] .three = true := by decide
def e2422373652974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373652974 : Closed e2422373652974 ∧ code e2422373652974 = 11218466675182 := by decide
theorem cert_e2422373652974 : check e2422373652974 [[],[]] .smaller = true := by decide
def e2422373652982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373652982 : Closed e2422373652982 ∧ code e2422373652982 = 11218466675190 := by decide
theorem cert_e2422373652982 : check e2422373652982 [[],[]] .three = true := by decide
def e2422373653726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373653726 : Closed e2422373653726 ∧ code e2422373653726 = 11218466675934 := by decide
theorem cert_e2422373653726 : check e2422373653726 [[],[]] .three = true := by decide
def e2422373653754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373653754 : Closed e2422373653754 ∧ code e2422373653754 = 11218466675962 := by decide
theorem cert_e2422373653754 : check e2422373653754 [[],[]] .three = true := by decide
def e2422373654126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373654126 : Closed e2422373654126 ∧ code e2422373654126 = 11218466676334 := by decide
theorem cert_e2422373654126 : check e2422373654126 [[],[]] .smaller = true := by decide
def e2422373654138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373654138 : Closed e2422373654138 ∧ code e2422373654138 = 11218466676346 := by decide
theorem cert_e2422373654138 : check e2422373654138 [[],[]] .smaller = true := by decide
def e2422373654326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373654326 : Closed e2422373654326 ∧ code e2422373654326 = 11218466676534 := by decide
theorem cert_e2422373654326 : check e2422373654326 [[],[]] .three = true := by decide
def e2422373654330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373654330 : Closed e2422373654330 ∧ code e2422373654330 = 11218466676538 := by decide
theorem cert_e2422373654330 : check e2422373654330 [[],[]] .three = true := by decide
def e2422373663678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e2422373663678 : Closed e2422373663678 ∧ code e2422373663678 = 11218466685886 := by decide
theorem cert_e2422373663678 : check e2422373663678 [[],[]] .three = true := by decide
def e2422373663710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373663710 : Closed e2422373663710 ∧ code e2422373663710 = 11218466685918 := by decide
theorem cert_e2422373663710 : check e2422373663710 [[],[]] .smaller = true := by decide
def e2422373663726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373663726 : Closed e2422373663726 ∧ code e2422373663726 = 11218466685934 := by decide
theorem cert_e2422373663726 : check e2422373663726 [[],[]] .smaller = true := by decide
def e2422373663734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e2422373663734 : Closed e2422373663734 ∧ code e2422373663734 = 11218466685942 := by decide
theorem cert_e2422373663734 : check e2422373663734 [[],[]] .three = true := by decide
def e2422373665630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2422373665630 : Closed e2422373665630 ∧ code e2422373665630 = 11218466687838 := by decide
theorem cert_e2422373665630 : check e2422373665630 [[],[]] .three = true := by decide
def e2422373665646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422373665646 : Closed e2422373665646 ∧ code e2422373665646 = 11218466687854 := by decide
theorem cert_e2422373665646 : check e2422373665646 [[],[]] .smaller = true := by decide
def e2422373665654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422373665654 : Closed e2422373665654 ∧ code e2422373665654 = 11218466687862 := by decide
theorem cert_e2422373665654 : check e2422373665654 [[],[]] .smaller = true := by decide
def e2422373665658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2422373665658 : Closed e2422373665658 ∧ code e2422373665658 = 11218466687866 := by decide
theorem cert_e2422373665658 : check e2422373665658 [[],[]] .three = true := by decide
def e2422373665710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422373665710 : Closed e2422373665710 ∧ code e2422373665710 = 11218466687918 := by decide
theorem cert_e2422373665710 : check e2422373665710 [[],[]] .smaller = true := by decide
def e2422373665722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422373665722 : Closed e2422373665722 ∧ code e2422373665722 = 11218466687930 := by decide
theorem cert_e2422373665722 : check e2422373665722 [[],[]] .smaller = true := by decide
def e2422373665750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422373665750 : Closed e2422373665750 ∧ code e2422373665750 = 11218466687958 := by decide
theorem cert_e2422373665750 : check e2422373665750 [[],[]] .smaller = true := by decide
def e2422373665754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422373665754 : Closed e2422373665754 ∧ code e2422373665754 = 11218466687962 := by decide
theorem cert_e2422373665754 : check e2422373665754 [[],[]] .smaller = true := by decide
def e2422373665770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2422373665770 : Closed e2422373665770 ∧ code e2422373665770 = 11218466687978 := by decide
theorem cert_e2422373665770 : check e2422373665770 [[],[]] .three = true := by decide
def e2422373666014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373666014 : Closed e2422373666014 ∧ code e2422373666014 = 11218466688222 := by decide
theorem cert_e2422373666014 : check e2422373666014 [[],[]] .three = true := by decide
def e2422373666030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373666030 : Closed e2422373666030 ∧ code e2422373666030 = 11218466688238 := by decide
theorem cert_e2422373666030 : check e2422373666030 [[],[]] .smaller = true := by decide
def e2422373666038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373666038 : Closed e2422373666038 ∧ code e2422373666038 = 11218466688246 := by decide
theorem cert_e2422373666038 : check e2422373666038 [[],[]] .smaller = true := by decide
def e2422373666042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373666042 : Closed e2422373666042 ∧ code e2422373666042 = 11218466688250 := by decide
theorem cert_e2422373666042 : check e2422373666042 [[],[]] .three = true := by decide
def e2422373666366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2422373666366 : Closed e2422373666366 ∧ code e2422373666366 = 11218466688574 := by decide
theorem cert_e2422373666366 : check e2422373666366 [[],[]] .three = true := by decide
def e2422373666414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373666414 : Closed e2422373666414 ∧ code e2422373666414 = 11218466688622 := by decide
theorem cert_e2422373666414 : check e2422373666414 [[],[]] .smaller = true := by decide
def e2422373666426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373666426 : Closed e2422373666426 ∧ code e2422373666426 = 11218466688634 := by decide
theorem cert_e2422373666426 : check e2422373666426 [[],[]] .smaller = true := by decide
def e2422373666590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e2422373666590 : Closed e2422373666590 ∧ code e2422373666590 = 11218466688798 := by decide
theorem cert_e2422373666590 : check e2422373666590 [[],[]] .smaller = true := by decide
def e2422373666614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373666614 : Closed e2422373666614 ∧ code e2422373666614 = 11218466688822 := by decide
theorem cert_e2422373666614 : check e2422373666614 [[],[]] .smaller = true := by decide
def e2422373666618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373666618 : Closed e2422373666618 ∧ code e2422373666618 = 11218466688826 := by decide
theorem cert_e2422373666618 : check e2422373666618 [[],[]] .smaller = true := by decide
def e2422373666702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2422373666702 : Closed e2422373666702 ∧ code e2422373666702 = 11218466688910 := by decide
theorem cert_e2422373666702 : check e2422373666702 [[],[]] .three = true := by decide
def e2422373666714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373666714 : Closed e2422373666714 ∧ code e2422373666714 = 11218466688922 := by decide
theorem cert_e2422373666714 : check e2422373666714 [[],[]] .three = true := by decide
def e2422373671390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373671390 : Closed e2422373671390 ∧ code e2422373671390 = 11218466693598 := by decide
theorem cert_e2422373671390 : check e2422373671390 [[],[]] .smaller = true := by decide
def e2422373671414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373671414 : Closed e2422373671414 ∧ code e2422373671414 = 11218466693622 := by decide
theorem cert_e2422373671414 : check e2422373671414 [[],[]] .smaller = true := by decide
def e2422373672366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422373672366 : Closed e2422373672366 ∧ code e2422373672366 = 11218466694574 := by decide
theorem cert_e2422373672366 : check e2422373672366 [[],[]] .smaller = true := by decide
def e2422373672378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422373672378 : Closed e2422373672378 ∧ code e2422373672378 = 11218466694586 := by decide
theorem cert_e2422373672378 : check e2422373672378 [[],[]] .smaller = true := by decide
def e2422373672426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422373672426 : Closed e2422373672426 ∧ code e2422373672426 = 11218466694634 := by decide
theorem cert_e2422373672426 : check e2422373672426 [[],[]] .smaller = true := by decide
def e2422373672510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422373672510 : Closed e2422373672510 ∧ code e2422373672510 = 11218466694718 := by decide
theorem cert_e2422373672510 : check e2422373672510 [[],[]] .three = true := by decide
def e2422373672558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373672558 : Closed e2422373672558 ∧ code e2422373672558 = 11218466694766 := by decide
theorem cert_e2422373672558 : check e2422373672558 [[],[]] .smaller = true := by decide
def e2422373672570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373672570 : Closed e2422373672570 ∧ code e2422373672570 = 11218466694778 := by decide
theorem cert_e2422373672570 : check e2422373672570 [[],[]] .smaller = true := by decide
def e2422373672858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373672858 : Closed e2422373672858 ∧ code e2422373672858 = 11218466695066 := by decide
theorem cert_e2422373672858 : check e2422373672858 [[],[]] .smaller = true := by decide
def e2422373672902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422373672902 : Closed e2422373672902 ∧ code e2422373672902 = 11218466695110 := by decide
theorem cert_e2422373672902 : check e2422373672902 [[],[]] .three = true := by decide
def e2422373675246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373675246 : Closed e2422373675246 ∧ code e2422373675246 = 11218466697454 := by decide
theorem cert_e2422373675246 : check e2422373675246 [[],[]] .smaller = true := by decide
def e2422373675254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373675254 : Closed e2422373675254 ∧ code e2422373675254 = 11218466697462 := by decide
theorem cert_e2422373675254 : check e2422373675254 [[],[]] .smaller = true := by decide
def e2422373675734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373675734 : Closed e2422373675734 ∧ code e2422373675734 = 11218466697942 := by decide
theorem cert_e2422373675734 : check e2422373675734 [[],[]] .smaller = true := by decide
def e2422373675738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373675738 : Closed e2422373675738 ∧ code e2422373675738 = 11218466697946 := by decide
theorem cert_e2422373675738 : check e2422373675738 [[],[]] .smaller = true := by decide
def e2422373675754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373675754 : Closed e2422373675754 ∧ code e2422373675754 = 11218466697962 := by decide
theorem cert_e2422373675754 : check e2422373675754 [[],[]] .smaller = true := by decide
def e2422373675806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373675806 : Closed e2422373675806 ∧ code e2422373675806 = 11218466698014 := by decide
theorem cert_e2422373675806 : check e2422373675806 [[],[]] .smaller = true := by decide
def e2422373675830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373675830 : Closed e2422373675830 ∧ code e2422373675830 = 11218466698038 := by decide
theorem cert_e2422373675830 : check e2422373675830 [[],[]] .smaller = true := by decide
def e2422373675834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373675834 : Closed e2422373675834 ∧ code e2422373675834 = 11218466698042 := by decide
theorem cert_e2422373675834 : check e2422373675834 [[],[]] .smaller = true := by decide
def e2422373675930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373675930 : Closed e2422373675930 ∧ code e2422373675930 = 11218466698138 := by decide
theorem cert_e2422373675930 : check e2422373675930 [[],[]] .smaller = true := by decide
def e2422373675974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373675974 : Closed e2422373675974 ∧ code e2422373675974 = 11218466698182 := by decide
theorem cert_e2422373675974 : check e2422373675974 [[],[]] .smaller = true := by decide
def e2422373675998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373675998 : Closed e2422373675998 ∧ code e2422373675998 = 11218466698206 := by decide
theorem cert_e2422373675998 : check e2422373675998 [[],[]] .three = true := by decide
def e2422373676014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373676014 : Closed e2422373676014 ∧ code e2422373676014 = 11218466698222 := by decide
theorem cert_e2422373676014 : check e2422373676014 [[],[]] .three = true := by decide
def e2422373677174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373677174 : Closed e2422373677174 ∧ code e2422373677174 = 11218466699382 := by decide
theorem cert_e2422373677174 : check e2422373677174 [[],[]] .three = true := by decide
def e2422373677418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373677418 : Closed e2422373677418 ∧ code e2422373677418 = 11218466699626 := by decide
theorem cert_e2422373677418 : check e2422373677418 [[],[]] .three = true := by decide
def e2422373677454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373677454 : Closed e2422373677454 ∧ code e2422373677454 = 11218466699662 := by decide
theorem cert_e2422373677454 : check e2422373677454 [[],[]] .three = true := by decide
def e2422373677466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373677466 : Closed e2422373677466 ∧ code e2422373677466 = 11218466699674 := by decide
theorem cert_e2422373677466 : check e2422373677466 [[],[]] .three = true := by decide
def e2422373677510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373677510 : Closed e2422373677510 ∧ code e2422373677510 = 11218466699718 := by decide
theorem cert_e2422373677510 : check e2422373677510 [[],[]] .three = true := by decide
def e2422373677550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373677550 : Closed e2422373677550 ∧ code e2422373677550 = 11218466699758 := by decide
theorem cert_e2422373677550 : check e2422373677550 [[],[]] .three = true := by decide
def e2422373702318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422373702318 : Closed e2422373702318 ∧ code e2422373702318 = 11218466724526 := by decide
theorem cert_e2422373702318 : check e2422373702318 [[],[]] .smaller = true := by decide
def e2422373702330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422373702330 : Closed e2422373702330 ∧ code e2422373702330 = 11218466724538 := by decide
theorem cert_e2422373702330 : check e2422373702330 [[],[]] .smaller = true := by decide
def e2422373702378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422373702378 : Closed e2422373702378 ∧ code e2422373702378 = 11218466724586 := by decide
theorem cert_e2422373702378 : check e2422373702378 [[],[]] .smaller = true := by decide
def e2422373702570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373702570 : Closed e2422373702570 ∧ code e2422373702570 = 11218466724778 := by decide
theorem cert_e2422373702570 : check e2422373702570 [[],[]] .smaller = true := by decide
def e2422373703338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373703338 : Closed e2422373703338 ∧ code e2422373703338 = 11218466725546 := by decide
theorem cert_e2422373703338 : check e2422373703338 [[],[]] .smaller = true := by decide
def e2422373703854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))) (.var 2)))))))
theorem wire_e2422373703854 : Closed e2422373703854 ∧ code e2422373703854 = 11218466726062 := by decide
theorem cert_e2422373703854 : check e2422373703854 [[],[]] .smaller = true := by decide
def e2422373703866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))) (.var 0)))))))
theorem wire_e2422373703866 : Closed e2422373703866 ∧ code e2422373703866 = 11218466726074 := by decide
theorem cert_e2422373703866 : check e2422373703866 [[],[]] .smaller = true := by decide
def e2422373704414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 3)))))))
theorem wire_e2422373704414 : Closed e2422373704414 ∧ code e2422373704414 = 11218466726622 := by decide
theorem cert_e2422373704414 : check e2422373704414 [[],[]] .three = true := by decide
def e2422373704430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 2)))))))
theorem wire_e2422373704430 : Closed e2422373704430 ∧ code e2422373704430 = 11218466726638 := by decide
theorem cert_e2422373704430 : check e2422373704430 [[],[]] .smaller = true := by decide
def e2422373704438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))) (.var 1)))))))
theorem wire_e2422373704438 : Closed e2422373704438 ∧ code e2422373704438 = 11218466726646 := by decide
theorem cert_e2422373704438 : check e2422373704438 [[],[]] .three = true := by decide
def e2422373704542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 3)))))))
theorem wire_e2422373704542 : Closed e2422373704542 ∧ code e2422373704542 = 11218466726750 := by decide
theorem cert_e2422373704542 : check e2422373704542 [[],[]] .three = true := by decide
def e2422373704558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 2)))))))
theorem wire_e2422373704558 : Closed e2422373704558 ∧ code e2422373704558 = 11218466726766 := by decide
theorem cert_e2422373704558 : check e2422373704558 [[],[]] .smaller = true := by decide
def e2422373704566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))) (.var 1)))))))
theorem wire_e2422373704566 : Closed e2422373704566 ∧ code e2422373704566 = 11218466726774 := by decide
theorem cert_e2422373704566 : check e2422373704566 [[],[]] .smaller = true := by decide
def e2422373704570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 3))) (.var 0)))))))
theorem wire_e2422373704570 : Closed e2422373704570 ∧ code e2422373704570 = 11218466726778 := by decide
theorem cert_e2422373704570 : check e2422373704570 [[],[]] .three = true := by decide
def e2422373704622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 2)))))))
theorem wire_e2422373704622 : Closed e2422373704622 ∧ code e2422373704622 = 11218466726830 := by decide
theorem cert_e2422373704622 : check e2422373704622 [[],[]] .smaller = true := by decide
def e2422373704634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))) (.var 0)))))))
theorem wire_e2422373704634 : Closed e2422373704634 ∧ code e2422373704634 = 11218466726842 := by decide
theorem cert_e2422373704634 : check e2422373704634 [[],[]] .smaller = true := by decide
def e2422373704662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))) (.var 1)))))))
theorem wire_e2422373704662 : Closed e2422373704662 ∧ code e2422373704662 = 11218466726870 := by decide
theorem cert_e2422373704662 : check e2422373704662 [[],[]] .smaller = true := by decide
def e2422373704666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))) (.var 0)))))))
theorem wire_e2422373704666 : Closed e2422373704666 ∧ code e2422373704666 = 11218466726874 := by decide
theorem cert_e2422373704666 : check e2422373704666 [[],[]] .smaller = true := by decide
def e2422373704682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 4))) (.var 0))) (.var 0)))))))
theorem wire_e2422373704682 : Closed e2422373704682 ∧ code e2422373704682 = 11218466726890 := by decide
theorem cert_e2422373704682 : check e2422373704682 [[],[]] .three = true := by decide
def e2422373705390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e2422373705390 : Closed e2422373705390 ∧ code e2422373705390 = 11218466727598 := by decide
theorem cert_e2422373705390 : check e2422373705390 [[],[]] .smaller = true := by decide
def e2422373705402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e2422373705402 : Closed e2422373705402 ∧ code e2422373705402 = 11218466727610 := by decide
theorem cert_e2422373705402 : check e2422373705402 [[],[]] .smaller = true := by decide
def e2422373705450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e2422373705450 : Closed e2422373705450 ∧ code e2422373705450 = 11218466727658 := by decide
theorem cert_e2422373705450 : check e2422373705450 [[],[]] .smaller = true := by decide
def e2422373705642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422373705642 : Closed e2422373705642 ∧ code e2422373705642 = 11218466727850 := by decide
theorem cert_e2422373705642 : check e2422373705642 [[],[]] .smaller = true := by decide
def e2422373705774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373705774 : Closed e2422373705774 ∧ code e2422373705774 = 11218466727982 := by decide
theorem cert_e2422373705774 : check e2422373705774 [[],[]] .smaller = true := by decide
def e2422373705950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422373705950 : Closed e2422373705950 ∧ code e2422373705950 = 11218466728158 := by decide
theorem cert_e2422373705950 : check e2422373705950 [[],[]] .three = true := by decide
def e2422373705966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422373705966 : Closed e2422373705966 ∧ code e2422373705966 = 11218466728174 := by decide
theorem cert_e2422373705966 : check e2422373705966 [[],[]] .smaller = true := by decide
def e2422373705974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422373705974 : Closed e2422373705974 ∧ code e2422373705974 = 11218466728182 := by decide
theorem cert_e2422373705974 : check e2422373705974 [[],[]] .smaller = true := by decide
def e2422373705978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422373705978 : Closed e2422373705978 ∧ code e2422373705978 = 11218466728186 := by decide
theorem cert_e2422373705978 : check e2422373705978 [[],[]] .three = true := by decide
def e2422373706158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422373706158 : Closed e2422373706158 ∧ code e2422373706158 = 11218466728366 := by decide
theorem cert_e2422373706158 : check e2422373706158 [[],[]] .smaller = true := by decide
def e2422373706170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422373706170 : Closed e2422373706170 ∧ code e2422373706170 = 11218466728378 := by decide
theorem cert_e2422373706170 : check e2422373706170 [[],[]] .smaller = true := by decide
def e2422373706218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422373706218 : Closed e2422373706218 ∧ code e2422373706218 = 11218466728426 := by decide
theorem cert_e2422373706218 : check e2422373706218 [[],[]] .smaller = true := by decide
def e2422373706302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422373706302 : Closed e2422373706302 ∧ code e2422373706302 = 11218466728510 := by decide
theorem cert_e2422373706302 : check e2422373706302 [[],[]] .three = true := by decide
def e2422373706350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373706350 : Closed e2422373706350 ∧ code e2422373706350 = 11218466728558 := by decide
theorem cert_e2422373706350 : check e2422373706350 [[],[]] .smaller = true := by decide
def e2422373706362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373706362 : Closed e2422373706362 ∧ code e2422373706362 = 11218466728570 := by decide
theorem cert_e2422373706362 : check e2422373706362 [[],[]] .smaller = true := by decide
def e2422373706526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422373706526 : Closed e2422373706526 ∧ code e2422373706526 = 11218466728734 := by decide
theorem cert_e2422373706526 : check e2422373706526 [[],[]] .smaller = true := by decide
def e2422373706626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373706626 : Closed e2422373706626 ∧ code e2422373706626 = 11218466728834 := by decide
theorem cert_e2422373706626 : check e2422373706626 [[],[]] .smaller = true := by decide
def e2422373706638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422373706638 : Closed e2422373706638 ∧ code e2422373706638 = 11218466728846 := by decide
theorem cert_e2422373706638 : check e2422373706638 [[],[]] .smaller = true := by decide
def e2422373706650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373706650 : Closed e2422373706650 ∧ code e2422373706650 = 11218466728858 := by decide
theorem cert_e2422373706650 : check e2422373706650 [[],[]] .smaller = true := by decide
def e2422373706694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422373706694 : Closed e2422373706694 ∧ code e2422373706694 = 11218466728902 := by decide
theorem cert_e2422373706694 : check e2422373706694 [[],[]] .three = true := by decide
def e2422373706718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 3)))))))
theorem wire_e2422373706718 : Closed e2422373706718 ∧ code e2422373706718 = 11218466728926 := by decide
theorem cert_e2422373706718 : check e2422373706718 [[],[]] .three = true := by decide
def e2422373706846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373706846 : Closed e2422373706846 ∧ code e2422373706846 = 11218466729054 := by decide
theorem cert_e2422373706846 : check e2422373706846 [[],[]] .three = true := by decide
def e2422373706862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2422373706862 : Closed e2422373706862 ∧ code e2422373706862 = 11218466729070 := by decide
theorem cert_e2422373706862 : check e2422373706862 [[],[]] .smaller = true := by decide
def e2422373706874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422373706874 : Closed e2422373706874 ∧ code e2422373706874 = 11218466729082 := by decide
theorem cert_e2422373706874 : check e2422373706874 [[],[]] .smaller = true := by decide
def e2422373707038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2422373707038 : Closed e2422373707038 ∧ code e2422373707038 = 11218466729246 := by decide
theorem cert_e2422373707038 : check e2422373707038 [[],[]] .smaller = true := by decide
def e2422373707206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422373707206 : Closed e2422373707206 ∧ code e2422373707206 = 11218466729414 := by decide
theorem cert_e2422373707206 : check e2422373707206 [[],[]] .smaller = true := by decide
def e2422373707230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 3)))))))
theorem wire_e2422373707230 : Closed e2422373707230 ∧ code e2422373707230 = 11218466729438 := by decide
theorem cert_e2422373707230 : check e2422373707230 [[],[]] .three = true := by decide
def e2422373707234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373707234 : Closed e2422373707234 ∧ code e2422373707234 = 11218466729442 := by decide
theorem cert_e2422373707234 : check e2422373707234 [[],[]] .three = true := by decide
def e2422373707246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 2)))))))
theorem wire_e2422373707246 : Closed e2422373707246 ∧ code e2422373707246 = 11218466729454 := by decide
theorem cert_e2422373707246 : check e2422373707246 [[],[]] .three = true := by decide
def e2422373707274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373707274 : Closed e2422373707274 ∧ code e2422373707274 = 11218466729482 := by decide
theorem cert_e2422373707274 : check e2422373707274 [[],[]] .smaller = true := by decide
def e2422373707310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373707310 : Closed e2422373707310 ∧ code e2422373707310 = 11218466729518 := by decide
theorem cert_e2422373707310 : check e2422373707310 [[],[]] .smaller = true := by decide
def e2422373707318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373707318 : Closed e2422373707318 ∧ code e2422373707318 = 11218466729526 := by decide
theorem cert_e2422373707318 : check e2422373707318 [[],[]] .smaller = true := by decide
def e2422373707322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373707322 : Closed e2422373707322 ∧ code e2422373707322 = 11218466729530 := by decide
theorem cert_e2422373707322 : check e2422373707322 [[],[]] .smaller = true := by decide
def e2422373707370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373707370 : Closed e2422373707370 ∧ code e2422373707370 = 11218466729578 := by decide
theorem cert_e2422373707370 : check e2422373707370 [[],[]] .smaller = true := by decide
def e2422373707394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373707394 : Closed e2422373707394 ∧ code e2422373707394 = 11218466729602 := by decide
theorem cert_e2422373707394 : check e2422373707394 [[],[]] .smaller = true := by decide
def e2422373707406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373707406 : Closed e2422373707406 ∧ code e2422373707406 = 11218466729614 := by decide
theorem cert_e2422373707406 : check e2422373707406 [[],[]] .smaller = true := by decide
def e2422373707418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373707418 : Closed e2422373707418 ∧ code e2422373707418 = 11218466729626 := by decide
theorem cert_e2422373707418 : check e2422373707418 [[],[]] .smaller = true := by decide
def e2422373707462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373707462 : Closed e2422373707462 ∧ code e2422373707462 = 11218466729670 := by decide
theorem cert_e2422373707462 : check e2422373707462 [[],[]] .smaller = true := by decide
def e2422373707486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 3)))))))
theorem wire_e2422373707486 : Closed e2422373707486 ∧ code e2422373707486 = 11218466729694 := by decide
theorem cert_e2422373707486 : check e2422373707486 [[],[]] .three = true := by decide
def e2422373707490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373707490 : Closed e2422373707490 ∧ code e2422373707490 = 11218466729698 := by decide
theorem cert_e2422373707490 : check e2422373707490 [[],[]] .smaller = true := by decide
def e2422373707502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 2)))))))
theorem wire_e2422373707502 : Closed e2422373707502 ∧ code e2422373707502 = 11218466729710 := by decide
theorem cert_e2422373707502 : check e2422373707502 [[],[]] .smaller = true := by decide
def e2422373707510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 1)))))))
theorem wire_e2422373707510 : Closed e2422373707510 ∧ code e2422373707510 = 11218466729718 := by decide
theorem cert_e2422373707510 : check e2422373707510 [[],[]] .three = true := by decide
def e2422373707542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373707542 : Closed e2422373707542 ∧ code e2422373707542 = 11218466729750 := by decide
theorem cert_e2422373707542 : check e2422373707542 [[],[]] .three = true := by decide
def e2422373707546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373707546 : Closed e2422373707546 ∧ code e2422373707546 = 11218466729754 := by decide
theorem cert_e2422373707546 : check e2422373707546 [[],[]] .three = true := by decide
def e2422373707590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373707590 : Closed e2422373707590 ∧ code e2422373707590 = 11218466729798 := by decide
theorem cert_e2422373707590 : check e2422373707590 [[],[]] .three = true := by decide
def e2422373707614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 3)))))))
theorem wire_e2422373707614 : Closed e2422373707614 ∧ code e2422373707614 = 11218466729822 := by decide
theorem cert_e2422373707614 : check e2422373707614 [[],[]] .three = true := by decide
def e2422373707618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373707618 : Closed e2422373707618 ∧ code e2422373707618 = 11218466729826 := by decide
theorem cert_e2422373707618 : check e2422373707618 [[],[]] .three = true := by decide
def e2422373707630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 2)))))))
theorem wire_e2422373707630 : Closed e2422373707630 ∧ code e2422373707630 = 11218466729838 := by decide
theorem cert_e2422373707630 : check e2422373707630 [[],[]] .three = true := by decide
def e2422373707638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 1)))))))
theorem wire_e2422373707638 : Closed e2422373707638 ∧ code e2422373707638 = 11218466729846 := by decide
theorem cert_e2422373707638 : check e2422373707638 [[],[]] .three = true := by decide
def e2422373707642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3))) (.var 0)))))))
theorem wire_e2422373707642 : Closed e2422373707642 ∧ code e2422373707642 = 11218466729850 := by decide
theorem cert_e2422373707642 : check e2422373707642 [[],[]] .three = true := by decide
def e2422373708126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 3)))))))
theorem wire_e2422373708126 : Closed e2422373708126 ∧ code e2422373708126 = 11218466730334 := by decide
theorem cert_e2422373708126 : check e2422373708126 [[],[]] .three = true := by decide
def e2422373708154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 3))) (.var 0)))))))
theorem wire_e2422373708154 : Closed e2422373708154 ∧ code e2422373708154 = 11218466730362 := by decide
theorem cert_e2422373708154 : check e2422373708154 [[],[]] .three = true := by decide
def e2422373708206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 2)))))))
theorem wire_e2422373708206 : Closed e2422373708206 ∧ code e2422373708206 = 11218466730414 := by decide
theorem cert_e2422373708206 : check e2422373708206 [[],[]] .smaller = true := by decide
def e2422373708218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))) (.var 0)))))))
theorem wire_e2422373708218 : Closed e2422373708218 ∧ code e2422373708218 = 11218466730426 := by decide
theorem cert_e2422373708218 : check e2422373708218 [[],[]] .smaller = true := by decide
def e2422373708266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))) (.var 0)))))))
theorem wire_e2422373708266 : Closed e2422373708266 ∧ code e2422373708266 = 11218466730474 := by decide
theorem cert_e2422373708266 : check e2422373708266 [[],[]] .smaller = true := by decide
def e2422373708894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373708894 : Closed e2422373708894 ∧ code e2422373708894 = 11218466731102 := by decide
theorem cert_e2422373708894 : check e2422373708894 [[],[]] .three = true := by decide
def e2422373708910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2422373708910 : Closed e2422373708910 ∧ code e2422373708910 = 11218466731118 := by decide
theorem cert_e2422373708910 : check e2422373708910 [[],[]] .smaller = true := by decide
def e2422373708922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422373708922 : Closed e2422373708922 ∧ code e2422373708922 = 11218466731130 := by decide
theorem cert_e2422373708922 : check e2422373708922 [[],[]] .smaller = true := by decide
def e2422373709086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2422373709086 : Closed e2422373709086 ∧ code e2422373709086 = 11218466731294 := by decide
theorem cert_e2422373709086 : check e2422373709086 [[],[]] .smaller = true := by decide
def e2422373709254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422373709254 : Closed e2422373709254 ∧ code e2422373709254 = 11218466731462 := by decide
theorem cert_e2422373709254 : check e2422373709254 [[],[]] .smaller = true := by decide
def e2422373709278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e2422373709278 : Closed e2422373709278 ∧ code e2422373709278 = 11218466731486 := by decide
theorem cert_e2422373709278 : check e2422373709278 [[],[]] .three = true := by decide
def e2422373709282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373709282 : Closed e2422373709282 ∧ code e2422373709282 = 11218466731490 := by decide
theorem cert_e2422373709282 : check e2422373709282 [[],[]] .three = true := by decide
def e2422373709294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e2422373709294 : Closed e2422373709294 ∧ code e2422373709294 = 11218466731502 := by decide
theorem cert_e2422373709294 : check e2422373709294 [[],[]] .three = true := by decide
def e2422373709594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373709594 : Closed e2422373709594 ∧ code e2422373709594 = 11218466731802 := by decide
theorem cert_e2422373709594 : check e2422373709594 [[],[]] .smaller = true := by decide
def e2422373709638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373709638 : Closed e2422373709638 ∧ code e2422373709638 = 11218466731846 := by decide
theorem cert_e2422373709638 : check e2422373709638 [[],[]] .smaller = true := by decide
end Blc.Floor43
