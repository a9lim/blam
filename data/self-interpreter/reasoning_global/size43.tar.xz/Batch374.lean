import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364416494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364416494 : Closed e2422364416494 ∧ code e2422364416494 = 11218457438702 := by decide
theorem cert_e2422364416494 : check e2422364416494 [[],[]] .smaller = true := by decide
def e2422364416502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364416502 : Closed e2422364416502 ∧ code e2422364416502 = 11218457438710 := by decide
theorem cert_e2422364416502 : check e2422364416502 [[],[]] .smaller = true := by decide
def e2422364416506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364416506 : Closed e2422364416506 ∧ code e2422364416506 = 11218457438714 := by decide
theorem cert_e2422364416506 : check e2422364416506 [[],[]] .three = true := by decide
def e2422364417150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 5)))))))))
theorem wire_e2422364417150 : Closed e2422364417150 ∧ code e2422364417150 = 11218457439358 := by decide
theorem cert_e2422364417150 : check e2422364417150 [[],[]] .three = true := by decide
def e2422364417246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364417246 : Closed e2422364417246 ∧ code e2422364417246 = 11218457439454 := by decide
theorem cert_e2422364417246 : check e2422364417246 [[],[]] .smaller = true := by decide
def e2422364417262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364417262 : Closed e2422364417262 ∧ code e2422364417262 = 11218457439470 := by decide
theorem cert_e2422364417262 : check e2422364417262 [[],[]] .smaller = true := by decide
def e2422364417270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364417270 : Closed e2422364417270 ∧ code e2422364417270 = 11218457439478 := by decide
theorem cert_e2422364417270 : check e2422364417270 [[],[]] .smaller = true := by decide
def e2422364417274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364417274 : Closed e2422364417274 ∧ code e2422364417274 = 11218457439482 := by decide
theorem cert_e2422364417274 : check e2422364417274 [[],[]] .smaller = true := by decide
def e2422364417550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364417550 : Closed e2422364417550 ∧ code e2422364417550 = 11218457439758 := by decide
theorem cert_e2422364417550 : check e2422364417550 [[],[]] .smaller = true := by decide
def e2422364417562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364417562 : Closed e2422364417562 ∧ code e2422364417562 = 11218457439770 := by decide
theorem cert_e2422364417562 : check e2422364417562 [[],[]] .smaller = true := by decide
def e2422364417634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364417634 : Closed e2422364417634 ∧ code e2422364417634 = 11218457439842 := by decide
theorem cert_e2422364417634 : check e2422364417634 [[],[]] .smaller = true := by decide
def e2422364417646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364417646 : Closed e2422364417646 ∧ code e2422364417646 = 11218457439854 := by decide
theorem cert_e2422364417646 : check e2422364417646 [[],[]] .smaller = true := by decide
def e2422364417654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364417654 : Closed e2422364417654 ∧ code e2422364417654 = 11218457439862 := by decide
theorem cert_e2422364417654 : check e2422364417654 [[],[]] .smaller = true := by decide
def e2422364417658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364417658 : Closed e2422364417658 ∧ code e2422364417658 = 11218457439866 := by decide
theorem cert_e2422364417658 : check e2422364417658 [[],[]] .smaller = true := by decide
def e2422364417846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364417846 : Closed e2422364417846 ∧ code e2422364417846 = 11218457440054 := by decide
theorem cert_e2422364417846 : check e2422364417846 [[],[]] .smaller = true := by decide
def e2422364417850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364417850 : Closed e2422364417850 ∧ code e2422364417850 = 11218457440058 := by decide
theorem cert_e2422364417850 : check e2422364417850 [[],[]] .smaller = true := by decide
def e2422364417934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.lam (.var 2)))))))))
theorem wire_e2422364417934 : Closed e2422364417934 ∧ code e2422364417934 = 11218457440142 := by decide
theorem cert_e2422364417934 : check e2422364417934 [[],[]] .three = true := by decide
def e2422364417946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364417946 : Closed e2422364417946 ∧ code e2422364417946 = 11218457440154 := by decide
theorem cert_e2422364417946 : check e2422364417946 [[],[]] .three = true := by decide
def e2422364417982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 4))))))))
theorem wire_e2422364417982 : Closed e2422364417982 ∧ code e2422364417982 = 11218457440190 := by decide
theorem cert_e2422364417982 : check e2422364417982 [[],[]] .three = true := by decide
def e2422364418494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 4))))))))
theorem wire_e2422364418494 : Closed e2422364418494 ∧ code e2422364418494 = 11218457440702 := by decide
theorem cert_e2422364418494 : check e2422364418494 [[],[]] .three = true := by decide
def e2422364418554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 5))) (.var 0))))))))
theorem wire_e2422364418554 : Closed e2422364418554 ∧ code e2422364418554 = 11218457440762 := by decide
theorem cert_e2422364418554 : check e2422364418554 [[],[]] .three = true := by decide
def e2422364418910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2422364418910 : Closed e2422364418910 ∧ code e2422364418910 = 11218457441118 := by decide
theorem cert_e2422364418910 : check e2422364418910 [[],[]] .smaller = true := by decide
def e2422364418926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422364418926 : Closed e2422364418926 ∧ code e2422364418926 = 11218457441134 := by decide
theorem cert_e2422364418926 : check e2422364418926 [[],[]] .smaller = true := by decide
def e2422364418934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422364418934 : Closed e2422364418934 ∧ code e2422364418934 = 11218457441142 := by decide
theorem cert_e2422364418934 : check e2422364418934 [[],[]] .smaller = true := by decide
def e2422364418938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2422364418938 : Closed e2422364418938 ∧ code e2422364418938 = 11218457441146 := by decide
theorem cert_e2422364418938 : check e2422364418938 [[],[]] .smaller = true := by decide
def e2422364418990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422364418990 : Closed e2422364418990 ∧ code e2422364418990 = 11218457441198 := by decide
theorem cert_e2422364418990 : check e2422364418990 [[],[]] .smaller = true := by decide
def e2422364419002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422364419002 : Closed e2422364419002 ∧ code e2422364419002 = 11218457441210 := by decide
theorem cert_e2422364419002 : check e2422364419002 [[],[]] .smaller = true := by decide
def e2422364419030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422364419030 : Closed e2422364419030 ∧ code e2422364419030 = 11218457441238 := by decide
theorem cert_e2422364419030 : check e2422364419030 [[],[]] .smaller = true := by decide
def e2422364419034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422364419034 : Closed e2422364419034 ∧ code e2422364419034 = 11218457441242 := by decide
theorem cert_e2422364419034 : check e2422364419034 [[],[]] .smaller = true := by decide
def e2422364419050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2422364419050 : Closed e2422364419050 ∧ code e2422364419050 = 11218457441258 := by decide
theorem cert_e2422364419050 : check e2422364419050 [[],[]] .smaller = true := by decide
def e2422364419198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 5)))))))))
theorem wire_e2422364419198 : Closed e2422364419198 ∧ code e2422364419198 = 11218457441406 := by decide
theorem cert_e2422364419198 : check e2422364419198 [[],[]] .three = true := by decide
def e2422364419294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364419294 : Closed e2422364419294 ∧ code e2422364419294 = 11218457441502 := by decide
theorem cert_e2422364419294 : check e2422364419294 [[],[]] .smaller = true := by decide
def e2422364419310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364419310 : Closed e2422364419310 ∧ code e2422364419310 = 11218457441518 := by decide
theorem cert_e2422364419310 : check e2422364419310 [[],[]] .smaller = true := by decide
def e2422364419318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364419318 : Closed e2422364419318 ∧ code e2422364419318 = 11218457441526 := by decide
theorem cert_e2422364419318 : check e2422364419318 [[],[]] .smaller = true := by decide
def e2422364419322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364419322 : Closed e2422364419322 ∧ code e2422364419322 = 11218457441530 := by decide
theorem cert_e2422364419322 : check e2422364419322 [[],[]] .smaller = true := by decide
def e2422364419694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364419694 : Closed e2422364419694 ∧ code e2422364419694 = 11218457441902 := by decide
theorem cert_e2422364419694 : check e2422364419694 [[],[]] .smaller = true := by decide
def e2422364419706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364419706 : Closed e2422364419706 ∧ code e2422364419706 = 11218457441914 := by decide
theorem cert_e2422364419706 : check e2422364419706 [[],[]] .smaller = true := by decide
def e2422364419894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364419894 : Closed e2422364419894 ∧ code e2422364419894 = 11218457442102 := by decide
theorem cert_e2422364419894 : check e2422364419894 [[],[]] .smaller = true := by decide
def e2422364419898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364419898 : Closed e2422364419898 ∧ code e2422364419898 = 11218457442106 := by decide
theorem cert_e2422364419898 : check e2422364419898 [[],[]] .smaller = true := by decide
def e2422364419994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364419994 : Closed e2422364419994 ∧ code e2422364419994 = 11218457442202 := by decide
theorem cert_e2422364419994 : check e2422364419994 [[],[]] .smaller = true := by decide
def e2422364420030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 4))))))))
theorem wire_e2422364420030 : Closed e2422364420030 ∧ code e2422364420030 = 11218457442238 := by decide
theorem cert_e2422364420030 : check e2422364420030 [[],[]] .three = true := by decide
def e2422364420038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 4)) (.lam (.var 1)))))))))
theorem wire_e2422364420038 : Closed e2422364420038 ∧ code e2422364420038 = 11218457442246 := by decide
theorem cert_e2422364420038 : check e2422364420038 [[],[]] .three = true := by decide
def e2422364420062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 4)) (.var 3))))))))
theorem wire_e2422364420062 : Closed e2422364420062 ∧ code e2422364420062 = 11218457442270 := by decide
theorem cert_e2422364420062 : check e2422364420062 [[],[]] .three = true := by decide
def e2422364420154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422364420154 : Closed e2422364420154 ∧ code e2422364420154 = 11218457442362 := by decide
theorem cert_e2422364420154 : check e2422364420154 [[],[]] .smaller = true := by decide
def e2422364420202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422364420202 : Closed e2422364420202 ∧ code e2422364420202 = 11218457442410 := by decide
theorem cert_e2422364420202 : check e2422364420202 [[],[]] .smaller = true := by decide
def e2422364420250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364420250 : Closed e2422364420250 ∧ code e2422364420250 = 11218457442458 := by decide
theorem cert_e2422364420250 : check e2422364420250 [[],[]] .smaller = true := by decide
def e2422364420294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422364420294 : Closed e2422364420294 ∧ code e2422364420294 = 11218457442502 := by decide
theorem cert_e2422364420294 : check e2422364420294 [[],[]] .smaller = true := by decide
def e2422364420490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364420490 : Closed e2422364420490 ∧ code e2422364420490 = 11218457442698 := by decide
theorem cert_e2422364420490 : check e2422364420490 [[],[]] .smaller = true := by decide
def e2422364420514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364420514 : Closed e2422364420514 ∧ code e2422364420514 = 11218457442722 := by decide
theorem cert_e2422364420514 : check e2422364420514 [[],[]] .smaller = true := by decide
def e2422364420526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422364420526 : Closed e2422364420526 ∧ code e2422364420526 = 11218457442734 := by decide
theorem cert_e2422364420526 : check e2422364420526 [[],[]] .smaller = true := by decide
def e2422364420534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e2422364420534 : Closed e2422364420534 ∧ code e2422364420534 = 11218457442742 := by decide
theorem cert_e2422364420534 : check e2422364420534 [[],[]] .smaller = true := by decide
def e2422364420538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422364420538 : Closed e2422364420538 ∧ code e2422364420538 = 11218457442746 := by decide
theorem cert_e2422364420538 : check e2422364420538 [[],[]] .smaller = true := by decide
def e2422364420566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e2422364420566 : Closed e2422364420566 ∧ code e2422364420566 = 11218457442774 := by decide
theorem cert_e2422364420566 : check e2422364420566 [[],[]] .smaller = true := by decide
def e2422364420570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e2422364420570 : Closed e2422364420570 ∧ code e2422364420570 = 11218457442778 := by decide
theorem cert_e2422364420570 : check e2422364420570 [[],[]] .smaller = true := by decide
def e2422364420586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422364420586 : Closed e2422364420586 ∧ code e2422364420586 = 11218457442794 := by decide
theorem cert_e2422364420586 : check e2422364420586 [[],[]] .smaller = true := by decide
def e2422364420622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364420622 : Closed e2422364420622 ∧ code e2422364420622 = 11218457442830 := by decide
theorem cert_e2422364420622 : check e2422364420622 [[],[]] .smaller = true := by decide
def e2422364420634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364420634 : Closed e2422364420634 ∧ code e2422364420634 = 11218457442842 := by decide
theorem cert_e2422364420634 : check e2422364420634 [[],[]] .smaller = true := by decide
def e2422364420706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364420706 : Closed e2422364420706 ∧ code e2422364420706 = 11218457442914 := by decide
theorem cert_e2422364420706 : check e2422364420706 [[],[]] .smaller = true := by decide
def e2422364420718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364420718 : Closed e2422364420718 ∧ code e2422364420718 = 11218457442926 := by decide
theorem cert_e2422364420718 : check e2422364420718 [[],[]] .smaller = true := by decide
def e2422364420726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364420726 : Closed e2422364420726 ∧ code e2422364420726 = 11218457442934 := by decide
theorem cert_e2422364420726 : check e2422364420726 [[],[]] .smaller = true := by decide
def e2422364420730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364420730 : Closed e2422364420730 ∧ code e2422364420730 = 11218457442938 := by decide
theorem cert_e2422364420730 : check e2422364420730 [[],[]] .smaller = true := by decide
def e2422364420918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364420918 : Closed e2422364420918 ∧ code e2422364420918 = 11218457443126 := by decide
theorem cert_e2422364420918 : check e2422364420918 [[],[]] .smaller = true := by decide
def e2422364420922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364420922 : Closed e2422364420922 ∧ code e2422364420922 = 11218457443130 := by decide
theorem cert_e2422364420922 : check e2422364420922 [[],[]] .smaller = true := by decide
def e2422364421018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364421018 : Closed e2422364421018 ∧ code e2422364421018 = 11218457443226 := by decide
theorem cert_e2422364421018 : check e2422364421018 [[],[]] .smaller = true := by decide
def e2422364421054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 4))))))))
theorem wire_e2422364421054 : Closed e2422364421054 ∧ code e2422364421054 = 11218457443262 := by decide
theorem cert_e2422364421054 : check e2422364421054 [[],[]] .three = true := by decide
def e2422364421086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 3))))))))
theorem wire_e2422364421086 : Closed e2422364421086 ∧ code e2422364421086 = 11218457443294 := by decide
theorem cert_e2422364421086 : check e2422364421086 [[],[]] .smaller = true := by decide
def e2422364421102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 4)) (.var 2))))))))
theorem wire_e2422364421102 : Closed e2422364421102 ∧ code e2422364421102 = 11218457443310 := by decide
theorem cert_e2422364421102 : check e2422364421102 [[],[]] .three = true := by decide
def e2422364421334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422364421334 : Closed e2422364421334 ∧ code e2422364421334 = 11218457443542 := by decide
theorem cert_e2422364421334 : check e2422364421334 [[],[]] .smaller = true := by decide
def e2422364421338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422364421338 : Closed e2422364421338 ∧ code e2422364421338 = 11218457443546 := by decide
theorem cert_e2422364421338 : check e2422364421338 [[],[]] .smaller = true := by decide
def e2422364421354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422364421354 : Closed e2422364421354 ∧ code e2422364421354 = 11218457443562 := by decide
theorem cert_e2422364421354 : check e2422364421354 [[],[]] .smaller = true := by decide
def e2422364421430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364421430 : Closed e2422364421430 ∧ code e2422364421430 = 11218457443638 := by decide
theorem cert_e2422364421430 : check e2422364421430 [[],[]] .smaller = true := by decide
def e2422364421434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364421434 : Closed e2422364421434 ∧ code e2422364421434 = 11218457443642 := by decide
theorem cert_e2422364421434 : check e2422364421434 [[],[]] .smaller = true := by decide
def e2422364421530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364421530 : Closed e2422364421530 ∧ code e2422364421530 = 11218457443738 := by decide
theorem cert_e2422364421530 : check e2422364421530 [[],[]] .smaller = true := by decide
def e2422364421566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 4))))))))
theorem wire_e2422364421566 : Closed e2422364421566 ∧ code e2422364421566 = 11218457443774 := by decide
theorem cert_e2422364421566 : check e2422364421566 [[],[]] .three = true := by decide
def e2422364421598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 3))))))))
theorem wire_e2422364421598 : Closed e2422364421598 ∧ code e2422364421598 = 11218457443806 := by decide
theorem cert_e2422364421598 : check e2422364421598 [[],[]] .smaller = true := by decide
def e2422364421614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 2))))))))
theorem wire_e2422364421614 : Closed e2422364421614 ∧ code e2422364421614 = 11218457443822 := by decide
theorem cert_e2422364421614 : check e2422364421614 [[],[]] .smaller = true := by decide
def e2422364421622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 4)) (.var 1))))))))
theorem wire_e2422364421622 : Closed e2422364421622 ∧ code e2422364421622 = 11218457443830 := by decide
theorem cert_e2422364421622 : check e2422364421622 [[],[]] .three = true := by decide
def e2422364421686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422364421686 : Closed e2422364421686 ∧ code e2422364421686 = 11218457443894 := by decide
theorem cert_e2422364421686 : check e2422364421686 [[],[]] .three = true := by decide
def e2422364421690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422364421690 : Closed e2422364421690 ∧ code e2422364421690 = 11218457443898 := by decide
theorem cert_e2422364421690 : check e2422364421690 [[],[]] .three = true := by decide
def e2422364421738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422364421738 : Closed e2422364421738 ∧ code e2422364421738 = 11218457443946 := by decide
theorem cert_e2422364421738 : check e2422364421738 [[],[]] .three = true := by decide
def e2422364421774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422364421774 : Closed e2422364421774 ∧ code e2422364421774 = 11218457443982 := by decide
theorem cert_e2422364421774 : check e2422364421774 [[],[]] .three = true := by decide
def e2422364421786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364421786 : Closed e2422364421786 ∧ code e2422364421786 = 11218457443994 := by decide
theorem cert_e2422364421786 : check e2422364421786 [[],[]] .three = true := by decide
def e2422364421822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 4))))))))
theorem wire_e2422364421822 : Closed e2422364421822 ∧ code e2422364421822 = 11218457444030 := by decide
theorem cert_e2422364421822 : check e2422364421822 [[],[]] .three = true := by decide
def e2422364421830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422364421830 : Closed e2422364421830 ∧ code e2422364421830 = 11218457444038 := by decide
theorem cert_e2422364421830 : check e2422364421830 [[],[]] .three = true := by decide
def e2422364421854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 1)) (.var 3))))))))
theorem wire_e2422364421854 : Closed e2422364421854 ∧ code e2422364421854 = 11218457444062 := by decide
theorem cert_e2422364421854 : check e2422364421854 [[],[]] .three = true := by decide
def e2422364421870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 2)) (.var 2))))))))
theorem wire_e2422364421870 : Closed e2422364421870 ∧ code e2422364421870 = 11218457444078 := by decide
theorem cert_e2422364421870 : check e2422364421870 [[],[]] .three = true := by decide
def e2422364421878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 3)) (.var 1))))))))
theorem wire_e2422364421878 : Closed e2422364421878 ∧ code e2422364421878 = 11218457444086 := by decide
theorem cert_e2422364421878 : check e2422364421878 [[],[]] .three = true := by decide
def e2422364421882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 4)) (.var 0))))))))
theorem wire_e2422364421882 : Closed e2422364421882 ∧ code e2422364421882 = 11218457444090 := by decide
theorem cert_e2422364421882 : check e2422364421882 [[],[]] .three = true := by decide
def e2422364422614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))))
theorem wire_e2422364422614 : Closed e2422364422614 ∧ code e2422364422614 = 11218457444822 := by decide
theorem cert_e2422364422614 : check e2422364422614 [[],[]] .smaller = true := by decide
def e2422364422618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))))))))
theorem wire_e2422364422618 : Closed e2422364422618 ∧ code e2422364422618 = 11218457444826 := by decide
theorem cert_e2422364422618 : check e2422364422618 [[],[]] .smaller = true := by decide
def e2422364422634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))))))
theorem wire_e2422364422634 : Closed e2422364422634 ∧ code e2422364422634 = 11218457444842 := by decide
theorem cert_e2422364422634 : check e2422364422634 [[],[]] .smaller = true := by decide
def e2422364422998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))))
theorem wire_e2422364422998 : Closed e2422364422998 ∧ code e2422364422998 = 11218457445206 := by decide
theorem cert_e2422364422998 : check e2422364422998 [[],[]] .smaller = true := by decide
def e2422364423002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))))
theorem wire_e2422364423002 : Closed e2422364423002 ∧ code e2422364423002 = 11218457445210 := by decide
theorem cert_e2422364423002 : check e2422364423002 [[],[]] .smaller = true := by decide
def e2422364423382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422364423382 : Closed e2422364423382 ∧ code e2422364423382 = 11218457445590 := by decide
theorem cert_e2422364423382 : check e2422364423382 [[],[]] .smaller = true := by decide
def e2422364423386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422364423386 : Closed e2422364423386 ∧ code e2422364423386 = 11218457445594 := by decide
theorem cert_e2422364423386 : check e2422364423386 [[],[]] .smaller = true := by decide
def e2422364423402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422364423402 : Closed e2422364423402 ∧ code e2422364423402 = 11218457445610 := by decide
theorem cert_e2422364423402 : check e2422364423402 [[],[]] .smaller = true := by decide
def e2422364423478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364423478 : Closed e2422364423478 ∧ code e2422364423478 = 11218457445686 := by decide
theorem cert_e2422364423478 : check e2422364423478 [[],[]] .smaller = true := by decide
def e2422364423482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364423482 : Closed e2422364423482 ∧ code e2422364423482 = 11218457445690 := by decide
theorem cert_e2422364423482 : check e2422364423482 [[],[]] .smaller = true := by decide
def e2422364423578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364423578 : Closed e2422364423578 ∧ code e2422364423578 = 11218457445786 := by decide
theorem cert_e2422364423578 : check e2422364423578 [[],[]] .smaller = true := by decide
def e2422364423734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422364423734 : Closed e2422364423734 ∧ code e2422364423734 = 11218457445942 := by decide
theorem cert_e2422364423734 : check e2422364423734 [[],[]] .smaller = true := by decide
def e2422364423738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422364423738 : Closed e2422364423738 ∧ code e2422364423738 = 11218457445946 := by decide
theorem cert_e2422364423738 : check e2422364423738 [[],[]] .smaller = true := by decide
def e2422364423822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422364423822 : Closed e2422364423822 ∧ code e2422364423822 = 11218457446030 := by decide
theorem cert_e2422364423822 : check e2422364423822 [[],[]] .smaller = true := by decide
def e2422364423870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 4))))))))
theorem wire_e2422364423870 : Closed e2422364423870 ∧ code e2422364423870 = 11218457446078 := by decide
theorem cert_e2422364423870 : check e2422364423870 [[],[]] .three = true := by decide
def e2422364423878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422364423878 : Closed e2422364423878 ∧ code e2422364423878 = 11218457446086 := by decide
theorem cert_e2422364423878 : check e2422364423878 [[],[]] .smaller = true := by decide
def e2422364423930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 4)) (.var 0))))))))
theorem wire_e2422364423930 : Closed e2422364423930 ∧ code e2422364423930 = 11218457446138 := by decide
theorem cert_e2422364423930 : check e2422364423930 [[],[]] .three = true := by decide
def e2422364423962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422364423962 : Closed e2422364423962 ∧ code e2422364423962 = 11218457446170 := by decide
theorem cert_e2422364423962 : check e2422364423962 [[],[]] .smaller = true := by decide
def e2422364424006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422364424006 : Closed e2422364424006 ∧ code e2422364424006 = 11218457446214 := by decide
theorem cert_e2422364424006 : check e2422364424006 [[],[]] .smaller = true := by decide
def e2422364424170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 5))) (.var 0)) (.var 0))))))))
theorem wire_e2422364424170 : Closed e2422364424170 ∧ code e2422364424170 = 11218457446378 := by decide
theorem cert_e2422364424170 : check e2422364424170 [[],[]] .three = true := by decide
def e2422364425302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1))))))))
theorem wire_e2422364425302 : Closed e2422364425302 ∧ code e2422364425302 = 11218457447510 := by decide
theorem cert_e2422364425302 : check e2422364425302 [[],[]] .smaller = true := by decide
def e2422364425306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0))))))))
theorem wire_e2422364425306 : Closed e2422364425306 ∧ code e2422364425306 = 11218457447514 := by decide
theorem cert_e2422364425306 : check e2422364425306 [[],[]] .smaller = true := by decide
def e2422364425494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422364425494 : Closed e2422364425494 ∧ code e2422364425494 = 11218457447702 := by decide
theorem cert_e2422364425494 : check e2422364425494 [[],[]] .smaller = true := by decide
def e2422364425566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e2422364425566 : Closed e2422364425566 ∧ code e2422364425566 = 11218457447774 := by decide
theorem cert_e2422364425566 : check e2422364425566 [[],[]] .smaller = true := by decide
def e2422364425570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422364425570 : Closed e2422364425570 ∧ code e2422364425570 = 11218457447778 := by decide
theorem cert_e2422364425570 : check e2422364425570 [[],[]] .smaller = true := by decide
def e2422364425582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e2422364425582 : Closed e2422364425582 ∧ code e2422364425582 = 11218457447790 := by decide
theorem cert_e2422364425582 : check e2422364425582 [[],[]] .smaller = true := by decide
def e2422364425590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e2422364425590 : Closed e2422364425590 ∧ code e2422364425590 = 11218457447798 := by decide
theorem cert_e2422364425590 : check e2422364425590 [[],[]] .smaller = true := by decide
def e2422364425594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e2422364425594 : Closed e2422364425594 ∧ code e2422364425594 = 11218457447802 := by decide
theorem cert_e2422364425594 : check e2422364425594 [[],[]] .smaller = true := by decide
def e2422364425610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364425610 : Closed e2422364425610 ∧ code e2422364425610 = 11218457447818 := by decide
theorem cert_e2422364425610 : check e2422364425610 [[],[]] .smaller = true := by decide
def e2422364425634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364425634 : Closed e2422364425634 ∧ code e2422364425634 = 11218457447842 := by decide
theorem cert_e2422364425634 : check e2422364425634 [[],[]] .smaller = true := by decide
def e2422364425646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e2422364425646 : Closed e2422364425646 ∧ code e2422364425646 = 11218457447854 := by decide
theorem cert_e2422364425646 : check e2422364425646 [[],[]] .smaller = true := by decide
def e2422364425654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e2422364425654 : Closed e2422364425654 ∧ code e2422364425654 = 11218457447862 := by decide
theorem cert_e2422364425654 : check e2422364425654 [[],[]] .smaller = true := by decide
def e2422364425658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e2422364425658 : Closed e2422364425658 ∧ code e2422364425658 = 11218457447866 := by decide
theorem cert_e2422364425658 : check e2422364425658 [[],[]] .smaller = true := by decide
def e2422364425686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e2422364425686 : Closed e2422364425686 ∧ code e2422364425686 = 11218457447894 := by decide
theorem cert_e2422364425686 : check e2422364425686 [[],[]] .smaller = true := by decide
def e2422364425690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e2422364425690 : Closed e2422364425690 ∧ code e2422364425690 = 11218457447898 := by decide
theorem cert_e2422364425690 : check e2422364425690 [[],[]] .smaller = true := by decide
def e2422364425706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e2422364425706 : Closed e2422364425706 ∧ code e2422364425706 = 11218457447914 := by decide
theorem cert_e2422364425706 : check e2422364425706 [[],[]] .smaller = true := by decide
def e2422364425770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0))))))))
theorem wire_e2422364425770 : Closed e2422364425770 ∧ code e2422364425770 = 11218457447978 := by decide
theorem cert_e2422364425770 : check e2422364425770 [[],[]] .smaller = true := by decide
def e2422364425866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422364425866 : Closed e2422364425866 ∧ code e2422364425866 = 11218457448074 := by decide
theorem cert_e2422364425866 : check e2422364425866 [[],[]] .smaller = true := by decide
def e2422364425890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422364425890 : Closed e2422364425890 ∧ code e2422364425890 = 11218457448098 := by decide
theorem cert_e2422364425890 : check e2422364425890 [[],[]] .smaller = true := by decide
def e2422364425902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422364425902 : Closed e2422364425902 ∧ code e2422364425902 = 11218457448110 := by decide
theorem cert_e2422364425902 : check e2422364425902 [[],[]] .smaller = true := by decide
def e2422364425910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e2422364425910 : Closed e2422364425910 ∧ code e2422364425910 = 11218457448118 := by decide
theorem cert_e2422364425910 : check e2422364425910 [[],[]] .smaller = true := by decide
def e2422364425914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422364425914 : Closed e2422364425914 ∧ code e2422364425914 = 11218457448122 := by decide
theorem cert_e2422364425914 : check e2422364425914 [[],[]] .smaller = true := by decide
def e2422364425942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422364425942 : Closed e2422364425942 ∧ code e2422364425942 = 11218457448150 := by decide
theorem cert_e2422364425942 : check e2422364425942 [[],[]] .smaller = true := by decide
def e2422364425946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422364425946 : Closed e2422364425946 ∧ code e2422364425946 = 11218457448154 := by decide
theorem cert_e2422364425946 : check e2422364425946 [[],[]] .smaller = true := by decide
def e2422364425962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422364425962 : Closed e2422364425962 ∧ code e2422364425962 = 11218457448170 := by decide
theorem cert_e2422364425962 : check e2422364425962 [[],[]] .smaller = true := by decide
def e2422364426070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422364426070 : Closed e2422364426070 ∧ code e2422364426070 = 11218457448278 := by decide
theorem cert_e2422364426070 : check e2422364426070 [[],[]] .smaller = true := by decide
def e2422364426074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422364426074 : Closed e2422364426074 ∧ code e2422364426074 = 11218457448282 := by decide
theorem cert_e2422364426074 : check e2422364426074 [[],[]] .smaller = true := by decide
def e2422364426090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422364426090 : Closed e2422364426090 ∧ code e2422364426090 = 11218457448298 := by decide
theorem cert_e2422364426090 : check e2422364426090 [[],[]] .smaller = true := by decide
def e2422364426154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422364426154 : Closed e2422364426154 ∧ code e2422364426154 = 11218457448362 := by decide
theorem cert_e2422364426154 : check e2422364426154 [[],[]] .smaller = true := by decide
def e2422364426358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422364426358 : Closed e2422364426358 ∧ code e2422364426358 = 11218457448566 := by decide
theorem cert_e2422364426358 : check e2422364426358 [[],[]] .smaller = true := by decide
def e2422364426362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422364426362 : Closed e2422364426362 ∧ code e2422364426362 = 11218457448570 := by decide
theorem cert_e2422364426362 : check e2422364426362 [[],[]] .smaller = true := by decide
def e2422364426454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422364426454 : Closed e2422364426454 ∧ code e2422364426454 = 11218457448662 := by decide
theorem cert_e2422364426454 : check e2422364426454 [[],[]] .smaller = true := by decide
def e2422364426550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364426550 : Closed e2422364426550 ∧ code e2422364426550 = 11218457448758 := by decide
theorem cert_e2422364426550 : check e2422364426550 [[],[]] .smaller = true := by decide
def e2422364426554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364426554 : Closed e2422364426554 ∧ code e2422364426554 = 11218457448762 := by decide
theorem cert_e2422364426554 : check e2422364426554 [[],[]] .smaller = true := by decide
def e2422364426638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422364426638 : Closed e2422364426638 ∧ code e2422364426638 = 11218457448846 := by decide
theorem cert_e2422364426638 : check e2422364426638 [[],[]] .smaller = true := by decide
def e2422364426686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 4))))))))
theorem wire_e2422364426686 : Closed e2422364426686 ∧ code e2422364426686 = 11218457448894 := by decide
theorem cert_e2422364426686 : check e2422364426686 [[],[]] .three = true := by decide
def e2422364426694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422364426694 : Closed e2422364426694 ∧ code e2422364426694 = 11218457448902 := by decide
theorem cert_e2422364426694 : check e2422364426694 [[],[]] .smaller = true := by decide
def e2422364426746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 5))) (.var 0))))))))
theorem wire_e2422364426746 : Closed e2422364426746 ∧ code e2422364426746 = 11218457448954 := by decide
theorem cert_e2422364426746 : check e2422364426746 [[],[]] .three = true := by decide
def e2422364427030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422364427030 : Closed e2422364427030 ∧ code e2422364427030 = 11218457449238 := by decide
theorem cert_e2422364427030 : check e2422364427030 [[],[]] .smaller = true := by decide
def e2422364427102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e2422364427102 : Closed e2422364427102 ∧ code e2422364427102 = 11218457449310 := by decide
theorem cert_e2422364427102 : check e2422364427102 [[],[]] .smaller = true := by decide
def e2422364427106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422364427106 : Closed e2422364427106 ∧ code e2422364427106 = 11218457449314 := by decide
theorem cert_e2422364427106 : check e2422364427106 [[],[]] .smaller = true := by decide
def e2422364427118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422364427118 : Closed e2422364427118 ∧ code e2422364427118 = 11218457449326 := by decide
theorem cert_e2422364427118 : check e2422364427118 [[],[]] .smaller = true := by decide
def e2422364427126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422364427126 : Closed e2422364427126 ∧ code e2422364427126 = 11218457449334 := by decide
theorem cert_e2422364427126 : check e2422364427126 [[],[]] .smaller = true := by decide
def e2422364427130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e2422364427130 : Closed e2422364427130 ∧ code e2422364427130 = 11218457449338 := by decide
theorem cert_e2422364427130 : check e2422364427130 [[],[]] .smaller = true := by decide
def e2422364427146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364427146 : Closed e2422364427146 ∧ code e2422364427146 = 11218457449354 := by decide
theorem cert_e2422364427146 : check e2422364427146 [[],[]] .smaller = true := by decide
def e2422364427170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364427170 : Closed e2422364427170 ∧ code e2422364427170 = 11218457449378 := by decide
theorem cert_e2422364427170 : check e2422364427170 [[],[]] .smaller = true := by decide
def e2422364427182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422364427182 : Closed e2422364427182 ∧ code e2422364427182 = 11218457449390 := by decide
theorem cert_e2422364427182 : check e2422364427182 [[],[]] .smaller = true := by decide
def e2422364427190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 1))))))))
theorem wire_e2422364427190 : Closed e2422364427190 ∧ code e2422364427190 = 11218457449398 := by decide
theorem cert_e2422364427190 : check e2422364427190 [[],[]] .smaller = true := by decide
def e2422364427194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422364427194 : Closed e2422364427194 ∧ code e2422364427194 = 11218457449402 := by decide
theorem cert_e2422364427194 : check e2422364427194 [[],[]] .smaller = true := by decide
def e2422364427222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422364427222 : Closed e2422364427222 ∧ code e2422364427222 = 11218457449430 := by decide
theorem cert_e2422364427222 : check e2422364427222 [[],[]] .smaller = true := by decide
def e2422364427226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422364427226 : Closed e2422364427226 ∧ code e2422364427226 = 11218457449434 := by decide
theorem cert_e2422364427226 : check e2422364427226 [[],[]] .smaller = true := by decide
def e2422364427242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e2422364427242 : Closed e2422364427242 ∧ code e2422364427242 = 11218457449450 := by decide
theorem cert_e2422364427242 : check e2422364427242 [[],[]] .smaller = true := by decide
end Blc.Floor43
