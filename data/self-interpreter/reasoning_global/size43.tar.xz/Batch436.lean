import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374907118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374907118 : Closed e2422374907118 ∧ code e2422374907118 = 11218467929326 := by decide
theorem cert_e2422374907118 : check e2422374907118 [[],[]] .three = true := by decide
def e2422374907126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374907126 : Closed e2422374907126 ∧ code e2422374907126 = 11218467929334 := by decide
theorem cert_e2422374907126 : check e2422374907126 [[],[]] .three = true := by decide
def e2422374907130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374907130 : Closed e2422374907130 ∧ code e2422374907130 = 11218467929338 := by decide
theorem cert_e2422374907130 : check e2422374907130 [[],[]] .three = true := by decide
def e2422374908118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1))))))))
theorem wire_e2422374908118 : Closed e2422374908118 ∧ code e2422374908118 = 11218467930326 := by decide
theorem cert_e2422374908118 : check e2422374908118 [[],[]] .smaller = true := by decide
def e2422374908214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374908214 : Closed e2422374908214 ∧ code e2422374908214 = 11218467930422 := by decide
theorem cert_e2422374908214 : check e2422374908214 [[],[]] .smaller = true := by decide
def e2422374908218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374908218 : Closed e2422374908218 ∧ code e2422374908218 = 11218467930426 := by decide
theorem cert_e2422374908218 : check e2422374908218 [[],[]] .smaller = true := by decide
def e2422374908382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 3))))))))
theorem wire_e2422374908382 : Closed e2422374908382 ∧ code e2422374908382 = 11218467930590 := by decide
theorem cert_e2422374908382 : check e2422374908382 [[],[]] .three = true := by decide
def e2422374908398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e2422374908398 : Closed e2422374908398 ∧ code e2422374908398 = 11218467930606 := by decide
theorem cert_e2422374908398 : check e2422374908398 [[],[]] .smaller = true := by decide
def e2422374908406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e2422374908406 : Closed e2422374908406 ∧ code e2422374908406 = 11218467930614 := by decide
theorem cert_e2422374908406 : check e2422374908406 [[],[]] .smaller = true := by decide
def e2422374908410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 5)))) (.var 0))))))))
theorem wire_e2422374908410 : Closed e2422374908410 ∧ code e2422374908410 = 11218467930618 := by decide
theorem cert_e2422374908410 : check e2422374908410 [[],[]] .three = true := by decide
def e2422374908766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e2422374908766 : Closed e2422374908766 ∧ code e2422374908766 = 11218467930974 := by decide
theorem cert_e2422374908766 : check e2422374908766 [[],[]] .three = true := by decide
def e2422374908790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e2422374908790 : Closed e2422374908790 ∧ code e2422374908790 = 11218467930998 := by decide
theorem cert_e2422374908790 : check e2422374908790 [[],[]] .smaller = true := by decide
def e2422374908854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e2422374908854 : Closed e2422374908854 ∧ code e2422374908854 = 11218467931062 := by decide
theorem cert_e2422374908854 : check e2422374908854 [[],[]] .smaller = true := by decide
def e2422374908858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e2422374908858 : Closed e2422374908858 ∧ code e2422374908858 = 11218467931066 := by decide
theorem cert_e2422374908858 : check e2422374908858 [[],[]] .smaller = true := by decide
def e2422374908886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e2422374908886 : Closed e2422374908886 ∧ code e2422374908886 = 11218467931094 := by decide
theorem cert_e2422374908886 : check e2422374908886 [[],[]] .smaller = true := by decide
def e2422374908890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e2422374908890 : Closed e2422374908890 ∧ code e2422374908890 = 11218467931098 := by decide
theorem cert_e2422374908890 : check e2422374908890 [[],[]] .smaller = true := by decide
def e2422374909150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374909150 : Closed e2422374909150 ∧ code e2422374909150 = 11218467931358 := by decide
theorem cert_e2422374909150 : check e2422374909150 [[],[]] .three = true := by decide
def e2422374909166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374909166 : Closed e2422374909166 ∧ code e2422374909166 = 11218467931374 := by decide
theorem cert_e2422374909166 : check e2422374909166 [[],[]] .smaller = true := by decide
def e2422374909174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374909174 : Closed e2422374909174 ∧ code e2422374909174 = 11218467931382 := by decide
theorem cert_e2422374909174 : check e2422374909174 [[],[]] .smaller = true := by decide
def e2422374909178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374909178 : Closed e2422374909178 ∧ code e2422374909178 = 11218467931386 := by decide
theorem cert_e2422374909178 : check e2422374909178 [[],[]] .three = true := by decide
def e2422374909502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 4)))))))))
theorem wire_e2422374909502 : Closed e2422374909502 ∧ code e2422374909502 = 11218467931710 := by decide
theorem cert_e2422374909502 : check e2422374909502 [[],[]] .three = true := by decide
def e2422374909558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374909558 : Closed e2422374909558 ∧ code e2422374909558 = 11218467931766 := by decide
theorem cert_e2422374909558 : check e2422374909558 [[],[]] .smaller = true := by decide
def e2422374909726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e2422374909726 : Closed e2422374909726 ∧ code e2422374909726 = 11218467931934 := by decide
theorem cert_e2422374909726 : check e2422374909726 [[],[]] .smaller = true := by decide
def e2422374909750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374909750 : Closed e2422374909750 ∧ code e2422374909750 = 11218467931958 := by decide
theorem cert_e2422374909750 : check e2422374909750 [[],[]] .smaller = true := by decide
def e2422374909754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374909754 : Closed e2422374909754 ∧ code e2422374909754 = 11218467931962 := by decide
theorem cert_e2422374909754 : check e2422374909754 [[],[]] .smaller = true := by decide
def e2422374909838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e2422374909838 : Closed e2422374909838 ∧ code e2422374909838 = 11218467932046 := by decide
theorem cert_e2422374909838 : check e2422374909838 [[],[]] .smaller = true := by decide
def e2422374909894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 4))) (.lam (.var 1)))))))))
theorem wire_e2422374909894 : Closed e2422374909894 ∧ code e2422374909894 = 11218467932102 := by decide
theorem cert_e2422374909894 : check e2422374909894 [[],[]] .three = true := by decide
def e2422374909918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 4))) (.var 3))))))))
theorem wire_e2422374909918 : Closed e2422374909918 ∧ code e2422374909918 = 11218467932126 := by decide
theorem cert_e2422374909918 : check e2422374909918 [[],[]] .three = true := by decide
def e2422374910806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422374910806 : Closed e2422374910806 ∧ code e2422374910806 = 11218467933014 := by decide
theorem cert_e2422374910806 : check e2422374910806 [[],[]] .smaller = true := by decide
def e2422374910810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422374910810 : Closed e2422374910810 ∧ code e2422374910810 = 11218467933018 := by decide
theorem cert_e2422374910810 : check e2422374910810 [[],[]] .smaller = true := by decide
def e2422374910826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422374910826 : Closed e2422374910826 ∧ code e2422374910826 = 11218467933034 := by decide
theorem cert_e2422374910826 : check e2422374910826 [[],[]] .smaller = true := by decide
def e2422374910890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422374910890 : Closed e2422374910890 ∧ code e2422374910890 = 11218467933098 := by decide
theorem cert_e2422374910890 : check e2422374910890 [[],[]] .smaller = true := by decide
def e2422374910998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))))
theorem wire_e2422374910998 : Closed e2422374910998 ∧ code e2422374910998 = 11218467933206 := by decide
theorem cert_e2422374910998 : check e2422374910998 [[],[]] .smaller = true := by decide
def e2422374911070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e2422374911070 : Closed e2422374911070 ∧ code e2422374911070 = 11218467933278 := by decide
theorem cert_e2422374911070 : check e2422374911070 [[],[]] .three = true := by decide
def e2422374911094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422374911094 : Closed e2422374911094 ∧ code e2422374911094 = 11218467933302 := by decide
theorem cert_e2422374911094 : check e2422374911094 [[],[]] .smaller = true := by decide
def e2422374911190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422374911190 : Closed e2422374911190 ∧ code e2422374911190 = 11218467933398 := by decide
theorem cert_e2422374911190 : check e2422374911190 [[],[]] .smaller = true := by decide
def e2422374911194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422374911194 : Closed e2422374911194 ∧ code e2422374911194 = 11218467933402 := by decide
theorem cert_e2422374911194 : check e2422374911194 [[],[]] .smaller = true := by decide
def e2422374911210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422374911210 : Closed e2422374911210 ∧ code e2422374911210 = 11218467933418 := by decide
theorem cert_e2422374911210 : check e2422374911210 [[],[]] .smaller = true := by decide
def e2422374911286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374911286 : Closed e2422374911286 ∧ code e2422374911286 = 11218467933494 := by decide
theorem cert_e2422374911286 : check e2422374911286 [[],[]] .smaller = true := by decide
def e2422374911290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374911290 : Closed e2422374911290 ∧ code e2422374911290 = 11218467933498 := by decide
theorem cert_e2422374911290 : check e2422374911290 [[],[]] .smaller = true := by decide
def e2422374911362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374911362 : Closed e2422374911362 ∧ code e2422374911362 = 11218467933570 := by decide
theorem cert_e2422374911362 : check e2422374911362 [[],[]] .smaller = true := by decide
def e2422374911374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422374911374 : Closed e2422374911374 ∧ code e2422374911374 = 11218467933582 := by decide
theorem cert_e2422374911374 : check e2422374911374 [[],[]] .smaller = true := by decide
def e2422374911386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374911386 : Closed e2422374911386 ∧ code e2422374911386 = 11218467933594 := by decide
theorem cert_e2422374911386 : check e2422374911386 [[],[]] .smaller = true := by decide
def e2422374911454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e2422374911454 : Closed e2422374911454 ∧ code e2422374911454 = 11218467933662 := by decide
theorem cert_e2422374911454 : check e2422374911454 [[],[]] .three = true := by decide
def e2422374911458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e2422374911458 : Closed e2422374911458 ∧ code e2422374911458 = 11218467933666 := by decide
theorem cert_e2422374911458 : check e2422374911458 [[],[]] .three = true := by decide
def e2422374911470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e2422374911470 : Closed e2422374911470 ∧ code e2422374911470 = 11218467933678 := by decide
theorem cert_e2422374911470 : check e2422374911470 [[],[]] .three = true := by decide
def e2422374911498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422374911498 : Closed e2422374911498 ∧ code e2422374911498 = 11218467933706 := by decide
theorem cert_e2422374911498 : check e2422374911498 [[],[]] .smaller = true := by decide
def e2422374911534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422374911534 : Closed e2422374911534 ∧ code e2422374911534 = 11218467933742 := by decide
theorem cert_e2422374911534 : check e2422374911534 [[],[]] .smaller = true := by decide
def e2422374911542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422374911542 : Closed e2422374911542 ∧ code e2422374911542 = 11218467933750 := by decide
theorem cert_e2422374911542 : check e2422374911542 [[],[]] .smaller = true := by decide
def e2422374911546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422374911546 : Closed e2422374911546 ∧ code e2422374911546 = 11218467933754 := by decide
theorem cert_e2422374911546 : check e2422374911546 [[],[]] .smaller = true := by decide
def e2422374911594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422374911594 : Closed e2422374911594 ∧ code e2422374911594 = 11218467933802 := by decide
theorem cert_e2422374911594 : check e2422374911594 [[],[]] .smaller = true := by decide
def e2422374911618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374911618 : Closed e2422374911618 ∧ code e2422374911618 = 11218467933826 := by decide
theorem cert_e2422374911618 : check e2422374911618 [[],[]] .smaller = true := by decide
def e2422374911630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422374911630 : Closed e2422374911630 ∧ code e2422374911630 = 11218467933838 := by decide
theorem cert_e2422374911630 : check e2422374911630 [[],[]] .smaller = true := by decide
def e2422374911642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374911642 : Closed e2422374911642 ∧ code e2422374911642 = 11218467933850 := by decide
theorem cert_e2422374911642 : check e2422374911642 [[],[]] .smaller = true := by decide
def e2422374911686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422374911686 : Closed e2422374911686 ∧ code e2422374911686 = 11218467933894 := by decide
theorem cert_e2422374911686 : check e2422374911686 [[],[]] .smaller = true := by decide
def e2422374911710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e2422374911710 : Closed e2422374911710 ∧ code e2422374911710 = 11218467933918 := by decide
theorem cert_e2422374911710 : check e2422374911710 [[],[]] .three = true := by decide
def e2422374911714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422374911714 : Closed e2422374911714 ∧ code e2422374911714 = 11218467933922 := by decide
theorem cert_e2422374911714 : check e2422374911714 [[],[]] .smaller = true := by decide
def e2422374911726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e2422374911726 : Closed e2422374911726 ∧ code e2422374911726 = 11218467933934 := by decide
theorem cert_e2422374911726 : check e2422374911726 [[],[]] .smaller = true := by decide
def e2422374911734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e2422374911734 : Closed e2422374911734 ∧ code e2422374911734 = 11218467933942 := by decide
theorem cert_e2422374911734 : check e2422374911734 [[],[]] .three = true := by decide
def e2422374911766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422374911766 : Closed e2422374911766 ∧ code e2422374911766 = 11218467933974 := by decide
theorem cert_e2422374911766 : check e2422374911766 [[],[]] .smaller = true := by decide
def e2422374911838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e2422374911838 : Closed e2422374911838 ∧ code e2422374911838 = 11218467934046 := by decide
theorem cert_e2422374911838 : check e2422374911838 [[],[]] .three = true := by decide
def e2422374911842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422374911842 : Closed e2422374911842 ∧ code e2422374911842 = 11218467934050 := by decide
theorem cert_e2422374911842 : check e2422374911842 [[],[]] .smaller = true := by decide
def e2422374911854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e2422374911854 : Closed e2422374911854 ∧ code e2422374911854 = 11218467934062 := by decide
theorem cert_e2422374911854 : check e2422374911854 [[],[]] .smaller = true := by decide
def e2422374911862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e2422374911862 : Closed e2422374911862 ∧ code e2422374911862 = 11218467934070 := by decide
theorem cert_e2422374911862 : check e2422374911862 [[],[]] .smaller = true := by decide
def e2422374911866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e2422374911866 : Closed e2422374911866 ∧ code e2422374911866 = 11218467934074 := by decide
theorem cert_e2422374911866 : check e2422374911866 [[],[]] .three = true := by decide
def e2422374911882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422374911882 : Closed e2422374911882 ∧ code e2422374911882 = 11218467934090 := by decide
theorem cert_e2422374911882 : check e2422374911882 [[],[]] .three = true := by decide
def e2422374911906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422374911906 : Closed e2422374911906 ∧ code e2422374911906 = 11218467934114 := by decide
theorem cert_e2422374911906 : check e2422374911906 [[],[]] .three = true := by decide
def e2422374911918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e2422374911918 : Closed e2422374911918 ∧ code e2422374911918 = 11218467934126 := by decide
theorem cert_e2422374911918 : check e2422374911918 [[],[]] .three = true := by decide
def e2422374911926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e2422374911926 : Closed e2422374911926 ∧ code e2422374911926 = 11218467934134 := by decide
theorem cert_e2422374911926 : check e2422374911926 [[],[]] .three = true := by decide
def e2422374911930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e2422374911930 : Closed e2422374911930 ∧ code e2422374911930 = 11218467934138 := by decide
theorem cert_e2422374911930 : check e2422374911930 [[],[]] .three = true := by decide
def e2422374912126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 5))))))))))
theorem wire_e2422374912126 : Closed e2422374912126 ∧ code e2422374912126 = 11218467934334 := by decide
theorem cert_e2422374912126 : check e2422374912126 [[],[]] .three = true := by decide
def e2422374912238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2422374912238 : Closed e2422374912238 ∧ code e2422374912238 = 11218467934446 := by decide
theorem cert_e2422374912238 : check e2422374912238 [[],[]] .smaller = true := by decide
def e2422374912246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2422374912246 : Closed e2422374912246 ∧ code e2422374912246 = 11218467934454 := by decide
theorem cert_e2422374912246 : check e2422374912246 [[],[]] .smaller = true := by decide
def e2422374912726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422374912726 : Closed e2422374912726 ∧ code e2422374912726 = 11218467934934 := by decide
theorem cert_e2422374912726 : check e2422374912726 [[],[]] .smaller = true := by decide
def e2422374912730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422374912730 : Closed e2422374912730 ∧ code e2422374912730 = 11218467934938 := by decide
theorem cert_e2422374912730 : check e2422374912730 [[],[]] .smaller = true := by decide
def e2422374912746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422374912746 : Closed e2422374912746 ∧ code e2422374912746 = 11218467934954 := by decide
theorem cert_e2422374912746 : check e2422374912746 [[],[]] .smaller = true := by decide
def e2422374912822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374912822 : Closed e2422374912822 ∧ code e2422374912822 = 11218467935030 := by decide
theorem cert_e2422374912822 : check e2422374912822 [[],[]] .smaller = true := by decide
def e2422374912826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374912826 : Closed e2422374912826 ∧ code e2422374912826 = 11218467935034 := by decide
theorem cert_e2422374912826 : check e2422374912826 [[],[]] .smaller = true := by decide
def e2422374912898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374912898 : Closed e2422374912898 ∧ code e2422374912898 = 11218467935106 := by decide
theorem cert_e2422374912898 : check e2422374912898 [[],[]] .smaller = true := by decide
def e2422374912910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422374912910 : Closed e2422374912910 ∧ code e2422374912910 = 11218467935118 := by decide
theorem cert_e2422374912910 : check e2422374912910 [[],[]] .smaller = true := by decide
def e2422374912922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374912922 : Closed e2422374912922 ∧ code e2422374912922 = 11218467935130 := by decide
theorem cert_e2422374912922 : check e2422374912922 [[],[]] .smaller = true := by decide
def e2422374912990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422374912990 : Closed e2422374912990 ∧ code e2422374912990 = 11218467935198 := by decide
theorem cert_e2422374912990 : check e2422374912990 [[],[]] .three = true := by decide
def e2422374912994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422374912994 : Closed e2422374912994 ∧ code e2422374912994 = 11218467935202 := by decide
theorem cert_e2422374912994 : check e2422374912994 [[],[]] .three = true := by decide
def e2422374913006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422374913006 : Closed e2422374913006 ∧ code e2422374913006 = 11218467935214 := by decide
theorem cert_e2422374913006 : check e2422374913006 [[],[]] .three = true := by decide
def e2422374914074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374914074 : Closed e2422374914074 ∧ code e2422374914074 = 11218467936282 := by decide
theorem cert_e2422374914074 : check e2422374914074 [[],[]] .smaller = true := by decide
def e2422374914110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422374914110 : Closed e2422374914110 ∧ code e2422374914110 = 11218467936318 := by decide
theorem cert_e2422374914110 : check e2422374914110 [[],[]] .smaller = true := by decide
def e2422374914158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374914158 : Closed e2422374914158 ∧ code e2422374914158 = 11218467936366 := by decide
theorem cert_e2422374914158 : check e2422374914158 [[],[]] .smaller = true := by decide
def e2422374914166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422374914166 : Closed e2422374914166 ∧ code e2422374914166 = 11218467936374 := by decide
theorem cert_e2422374914166 : check e2422374914166 [[],[]] .smaller = true := by decide
def e2422374914170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374914170 : Closed e2422374914170 ∧ code e2422374914170 = 11218467936378 := by decide
theorem cert_e2422374914170 : check e2422374914170 [[],[]] .smaller = true := by decide
def e2422374914410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422374914410 : Closed e2422374914410 ∧ code e2422374914410 = 11218467936618 := by decide
theorem cert_e2422374914410 : check e2422374914410 [[],[]] .smaller = true := by decide
def e2422374914434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422374914434 : Closed e2422374914434 ∧ code e2422374914434 = 11218467936642 := by decide
theorem cert_e2422374914434 : check e2422374914434 [[],[]] .smaller = true := by decide
def e2422374914446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422374914446 : Closed e2422374914446 ∧ code e2422374914446 = 11218467936654 := by decide
theorem cert_e2422374914446 : check e2422374914446 [[],[]] .smaller = true := by decide
def e2422374914458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374914458 : Closed e2422374914458 ∧ code e2422374914458 = 11218467936666 := by decide
theorem cert_e2422374914458 : check e2422374914458 [[],[]] .smaller = true := by decide
def e2422374914502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422374914502 : Closed e2422374914502 ∧ code e2422374914502 = 11218467936710 := by decide
theorem cert_e2422374914502 : check e2422374914502 [[],[]] .smaller = true := by decide
def e2422374914526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374914526 : Closed e2422374914526 ∧ code e2422374914526 = 11218467936734 := by decide
theorem cert_e2422374914526 : check e2422374914526 [[],[]] .three = true := by decide
def e2422374914530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422374914530 : Closed e2422374914530 ∧ code e2422374914530 = 11218467936738 := by decide
theorem cert_e2422374914530 : check e2422374914530 [[],[]] .smaller = true := by decide
def e2422374914542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422374914542 : Closed e2422374914542 ∧ code e2422374914542 = 11218467936750 := by decide
theorem cert_e2422374914542 : check e2422374914542 [[],[]] .smaller = true := by decide
def e2422374914550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374914550 : Closed e2422374914550 ∧ code e2422374914550 = 11218467936758 := by decide
theorem cert_e2422374914550 : check e2422374914550 [[],[]] .three = true := by decide
def e2422374915102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422374915102 : Closed e2422374915102 ∧ code e2422374915102 = 11218467937310 := by decide
theorem cert_e2422374915102 : check e2422374915102 [[],[]] .smaller = true := by decide
def e2422374915294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374915294 : Closed e2422374915294 ∧ code e2422374915294 = 11218467937502 := by decide
theorem cert_e2422374915294 : check e2422374915294 [[],[]] .three = true := by decide
def e2422374915298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422374915298 : Closed e2422374915298 ∧ code e2422374915298 = 11218467937506 := by decide
theorem cert_e2422374915298 : check e2422374915298 [[],[]] .smaller = true := by decide
def e2422374915310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374915310 : Closed e2422374915310 ∧ code e2422374915310 = 11218467937518 := by decide
theorem cert_e2422374915310 : check e2422374915310 [[],[]] .smaller = true := by decide
def e2422374915318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374915318 : Closed e2422374915318 ∧ code e2422374915318 = 11218467937526 := by decide
theorem cert_e2422374915318 : check e2422374915318 [[],[]] .smaller = true := by decide
def e2422374915322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374915322 : Closed e2422374915322 ∧ code e2422374915322 = 11218467937530 := by decide
theorem cert_e2422374915322 : check e2422374915322 [[],[]] .three = true := by decide
def e2422374915598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422374915598 : Closed e2422374915598 ∧ code e2422374915598 = 11218467937806 := by decide
theorem cert_e2422374915598 : check e2422374915598 [[],[]] .three = true := by decide
def e2422374915610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374915610 : Closed e2422374915610 ∧ code e2422374915610 = 11218467937818 := by decide
theorem cert_e2422374915610 : check e2422374915610 [[],[]] .three = true := by decide
def e2422374915646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.lam (.var 4)))))))))
theorem wire_e2422374915646 : Closed e2422374915646 ∧ code e2422374915646 = 11218467937854 := by decide
theorem cert_e2422374915646 : check e2422374915646 [[],[]] .three = true := by decide
def e2422374915682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422374915682 : Closed e2422374915682 ∧ code e2422374915682 = 11218467937890 := by decide
theorem cert_e2422374915682 : check e2422374915682 [[],[]] .three = true := by decide
def e2422374915694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374915694 : Closed e2422374915694 ∧ code e2422374915694 = 11218467937902 := by decide
theorem cert_e2422374915694 : check e2422374915694 [[],[]] .three = true := by decide
def e2422374915702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374915702 : Closed e2422374915702 ∧ code e2422374915702 = 11218467937910 := by decide
theorem cert_e2422374915702 : check e2422374915702 [[],[]] .three = true := by decide
def e2422374915706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374915706 : Closed e2422374915706 ∧ code e2422374915706 = 11218467937914 := by decide
theorem cert_e2422374915706 : check e2422374915706 [[],[]] .three = true := by decide
def e2422374916334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422374916334 : Closed e2422374916334 ∧ code e2422374916334 = 11218467938542 := by decide
theorem cert_e2422374916334 : check e2422374916334 [[],[]] .three = true := by decide
def e2422374916342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.var 1))))))))
theorem wire_e2422374916342 : Closed e2422374916342 ∧ code e2422374916342 = 11218467938550 := by decide
theorem cert_e2422374916342 : check e2422374916342 [[],[]] .three = true := by decide
def e2422374916346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422374916346 : Closed e2422374916346 ∧ code e2422374916346 = 11218467938554 := by decide
theorem cert_e2422374916346 : check e2422374916346 [[],[]] .three = true := by decide
def e2422374916526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422374916526 : Closed e2422374916526 ∧ code e2422374916526 = 11218467938734 := by decide
theorem cert_e2422374916526 : check e2422374916526 [[],[]] .three = true := by decide
def e2422374916534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422374916534 : Closed e2422374916534 ∧ code e2422374916534 = 11218467938742 := by decide
theorem cert_e2422374916534 : check e2422374916534 [[],[]] .three = true := by decide
def e2422374916538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422374916538 : Closed e2422374916538 ∧ code e2422374916538 = 11218467938746 := by decide
theorem cert_e2422374916538 : check e2422374916538 [[],[]] .three = true := by decide
def e2422374916566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422374916566 : Closed e2422374916566 ∧ code e2422374916566 = 11218467938774 := by decide
theorem cert_e2422374916566 : check e2422374916566 [[],[]] .three = true := by decide
def e2422374916586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422374916586 : Closed e2422374916586 ∧ code e2422374916586 = 11218467938794 := by decide
theorem cert_e2422374916586 : check e2422374916586 [[],[]] .three = true := by decide
def e2422374916718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374916718 : Closed e2422374916718 ∧ code e2422374916718 = 11218467938926 := by decide
theorem cert_e2422374916718 : check e2422374916718 [[],[]] .three = true := by decide
def e2422374916726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374916726 : Closed e2422374916726 ∧ code e2422374916726 = 11218467938934 := by decide
theorem cert_e2422374916726 : check e2422374916726 [[],[]] .three = true := by decide
def e2422374916730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374916730 : Closed e2422374916730 ∧ code e2422374916730 = 11218467938938 := by decide
theorem cert_e2422374916730 : check e2422374916730 [[],[]] .three = true := by decide
def e2422374916894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422374916894 : Closed e2422374916894 ∧ code e2422374916894 = 11218467939102 := by decide
theorem cert_e2422374916894 : check e2422374916894 [[],[]] .three = true := by decide
def e2422374916918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374916918 : Closed e2422374916918 ∧ code e2422374916918 = 11218467939126 := by decide
theorem cert_e2422374916918 : check e2422374916918 [[],[]] .three = true := by decide
def e2422374916922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374916922 : Closed e2422374916922 ∧ code e2422374916922 = 11218467939130 := by decide
theorem cert_e2422374916922 : check e2422374916922 [[],[]] .three = true := by decide
def e2422374917006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.lam (.var 2)))))))))
theorem wire_e2422374917006 : Closed e2422374917006 ∧ code e2422374917006 = 11218467939214 := by decide
theorem cert_e2422374917006 : check e2422374917006 [[],[]] .three = true := by decide
def e2422374917018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374917018 : Closed e2422374917018 ∧ code e2422374917018 = 11218467939226 := by decide
theorem cert_e2422374917018 : check e2422374917018 [[],[]] .three = true := by decide
def e2422374917062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422374917062 : Closed e2422374917062 ∧ code e2422374917062 = 11218467939270 := by decide
theorem cert_e2422374917062 : check e2422374917062 [[],[]] .three = true := by decide
def e2422374917086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 3))) (.var 3))))))))
theorem wire_e2422374917086 : Closed e2422374917086 ∧ code e2422374917086 = 11218467939294 := by decide
theorem cert_e2422374917086 : check e2422374917086 [[],[]] .three = true := by decide
def e2422374917102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.lam (.var 4))) (.var 2))))))))
theorem wire_e2422374917102 : Closed e2422374917102 ∧ code e2422374917102 = 11218467939310 := by decide
theorem cert_e2422374917102 : check e2422374917102 [[],[]] .three = true := by decide
def e2422374917678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422374917678 : Closed e2422374917678 ∧ code e2422374917678 = 11218467939886 := by decide
theorem cert_e2422374917678 : check e2422374917678 [[],[]] .three = true := by decide
def e2422374917686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422374917686 : Closed e2422374917686 ∧ code e2422374917686 = 11218467939894 := by decide
theorem cert_e2422374917686 : check e2422374917686 [[],[]] .three = true := by decide
def e2422374917690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422374917690 : Closed e2422374917690 ∧ code e2422374917690 = 11218467939898 := by decide
theorem cert_e2422374917690 : check e2422374917690 [[],[]] .three = true := by decide
def e2422374917774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422374917774 : Closed e2422374917774 ∧ code e2422374917774 = 11218467939982 := by decide
theorem cert_e2422374917774 : check e2422374917774 [[],[]] .three = true := by decide
def e2422374917830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422374917830 : Closed e2422374917830 ∧ code e2422374917830 = 11218467940038 := by decide
theorem cert_e2422374917830 : check e2422374917830 [[],[]] .three = true := by decide
def e2422374917854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2422374917854 : Closed e2422374917854 ∧ code e2422374917854 = 11218467940062 := by decide
theorem cert_e2422374917854 : check e2422374917854 [[],[]] .three = true := by decide
def e2422374917858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422374917858 : Closed e2422374917858 ∧ code e2422374917858 = 11218467940066 := by decide
theorem cert_e2422374917858 : check e2422374917858 [[],[]] .three = true := by decide
def e2422374917870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2422374917870 : Closed e2422374917870 ∧ code e2422374917870 = 11218467940078 := by decide
theorem cert_e2422374917870 : check e2422374917870 [[],[]] .three = true := by decide
def e2422374917878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2422374917878 : Closed e2422374917878 ∧ code e2422374917878 = 11218467940086 := by decide
theorem cert_e2422374917878 : check e2422374917878 [[],[]] .three = true := by decide
def e2422374917910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422374917910 : Closed e2422374917910 ∧ code e2422374917910 = 11218467940118 := by decide
theorem cert_e2422374917910 : check e2422374917910 [[],[]] .three = true := by decide
def e2422374917914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422374917914 : Closed e2422374917914 ∧ code e2422374917914 = 11218467940122 := by decide
theorem cert_e2422374917914 : check e2422374917914 [[],[]] .three = true := by decide
def e2422374917958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422374917958 : Closed e2422374917958 ∧ code e2422374917958 = 11218467940166 := by decide
theorem cert_e2422374917958 : check e2422374917958 [[],[]] .three = true := by decide
def e2422374917982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2422374917982 : Closed e2422374917982 ∧ code e2422374917982 = 11218467940190 := by decide
theorem cert_e2422374917982 : check e2422374917982 [[],[]] .three = true := by decide
def e2422374917986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422374917986 : Closed e2422374917986 ∧ code e2422374917986 = 11218467940194 := by decide
theorem cert_e2422374917986 : check e2422374917986 [[],[]] .three = true := by decide
def e2422374917998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e2422374917998 : Closed e2422374917998 ∧ code e2422374917998 = 11218467940206 := by decide
theorem cert_e2422374917998 : check e2422374917998 [[],[]] .three = true := by decide
def e2422374918006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e2422374918006 : Closed e2422374918006 ∧ code e2422374918006 = 11218467940214 := by decide
theorem cert_e2422374918006 : check e2422374918006 [[],[]] .three = true := by decide
def e2422374918010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e2422374918010 : Closed e2422374918010 ∧ code e2422374918010 = 11218467940218 := by decide
theorem cert_e2422374918010 : check e2422374918010 [[],[]] .three = true := by decide
def e2422374918026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422374918026 : Closed e2422374918026 ∧ code e2422374918026 = 11218467940234 := by decide
theorem cert_e2422374918026 : check e2422374918026 [[],[]] .three = true := by decide
def e2422374918050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422374918050 : Closed e2422374918050 ∧ code e2422374918050 = 11218467940258 := by decide
theorem cert_e2422374918050 : check e2422374918050 [[],[]] .three = true := by decide
def e2422374918062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e2422374918062 : Closed e2422374918062 ∧ code e2422374918062 = 11218467940270 := by decide
theorem cert_e2422374918062 : check e2422374918062 [[],[]] .three = true := by decide
def e2422374918070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e2422374918070 : Closed e2422374918070 ∧ code e2422374918070 = 11218467940278 := by decide
theorem cert_e2422374918070 : check e2422374918070 [[],[]] .three = true := by decide
def e2422374918074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e2422374918074 : Closed e2422374918074 ∧ code e2422374918074 = 11218467940282 := by decide
theorem cert_e2422374918074 : check e2422374918074 [[],[]] .three = true := by decide
def e2422374918102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e2422374918102 : Closed e2422374918102 ∧ code e2422374918102 = 11218467940310 := by decide
theorem cert_e2422374918102 : check e2422374918102 [[],[]] .three = true := by decide
def e2422374918106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e2422374918106 : Closed e2422374918106 ∧ code e2422374918106 = 11218467940314 := by decide
theorem cert_e2422374918106 : check e2422374918106 [[],[]] .three = true := by decide
def e2422374918206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422374918206 : Closed e2422374918206 ∧ code e2422374918206 = 11218467940414 := by decide
theorem cert_e2422374918206 : check e2422374918206 [[],[]] .three = true := by decide
def e2422374918254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374918254 : Closed e2422374918254 ∧ code e2422374918254 = 11218467940462 := by decide
theorem cert_e2422374918254 : check e2422374918254 [[],[]] .three = true := by decide
def e2422374918266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374918266 : Closed e2422374918266 ∧ code e2422374918266 = 11218467940474 := by decide
theorem cert_e2422374918266 : check e2422374918266 [[],[]] .three = true := by decide
def e2422374918542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422374918542 : Closed e2422374918542 ∧ code e2422374918542 = 11218467940750 := by decide
theorem cert_e2422374918542 : check e2422374918542 [[],[]] .three = true := by decide
def e2422374918598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422374918598 : Closed e2422374918598 ∧ code e2422374918598 = 11218467940806 := by decide
theorem cert_e2422374918598 : check e2422374918598 [[],[]] .three = true := by decide
def e2422374918622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374918622 : Closed e2422374918622 ∧ code e2422374918622 = 11218467940830 := by decide
theorem cert_e2422374918622 : check e2422374918622 [[],[]] .three = true := by decide
end Blc.Floor43
