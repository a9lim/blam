import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601905114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e605601905114 : Closed e605601905114 ∧ code e605601905114 = 9401694927322 := by decide
theorem cert_e605601905114 : check e605601905114 [[.under],[.under]] .three = true := by decide
def e605601905270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e605601905270 : Closed e605601905270 ∧ code e605601905270 = 9401694927478 := by decide
theorem cert_e605601905270 : check e605601905270 [[.under],[.under]] .three = true := by decide
def e605601905462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e605601905462 : Closed e605601905462 ∧ code e605601905462 = 9401694927670 := by decide
theorem cert_e605601905462 : check e605601905462 [[.under],[.under]] .three = true := by decide
def e605601905466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e605601905466 : Closed e605601905466 ∧ code e605601905466 = 9401694927674 := by decide
theorem cert_e605601905466 : check e605601905466 [[.under],[.under]] .three = true := by decide
def e605602115038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 3)))))))
theorem wire_e605602115038 : Closed e605602115038 ∧ code e605602115038 = 9401695137246 := by decide
theorem cert_e605602115038 : check e605602115038 [[.under],[.under]] .three = true := by decide
def e605602115054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))) (.var 2)))))))
theorem wire_e605602115054 : Closed e605602115054 ∧ code e605602115054 = 9401695137262 := by decide
theorem cert_e605602115054 : check e605602115054 [[.under],[.under]] .three = true := by decide
def e605602115294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 3)))))))
theorem wire_e605602115294 : Closed e605602115294 ∧ code e605602115294 = 9401695137502 := by decide
theorem cert_e605602115294 : check e605602115294 [[.under],[.under]] .three = true := by decide
def e605602115318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 3))) (.var 1)))))))
theorem wire_e605602115318 : Closed e605602115318 ∧ code e605602115318 = 9401695137526 := by decide
theorem cert_e605602115318 : check e605602115318 [[.under],[.under]] .three = true := by decide
def e605602115438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))) (.var 2)))))))
theorem wire_e605602115438 : Closed e605602115438 ∧ code e605602115438 = 9401695137646 := by decide
theorem cert_e605602115438 : check e605602115438 [[.under],[.under]] .three = true := by decide
def e605602115446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 2))) (.var 1)))))))
theorem wire_e605602115446 : Closed e605602115446 ∧ code e605602115446 = 9401695137654 := by decide
theorem cert_e605602115446 : check e605602115446 [[.under],[.under]] .three = true := by decide
def e605602117342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 3)))))))
theorem wire_e605602117342 : Closed e605602117342 ∧ code e605602117342 = 9401695139550 := by decide
theorem cert_e605602117342 : check e605602117342 [[.under],[.under]] .three = true := by decide
def e605602117366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 3))) (.var 1)))))))
theorem wire_e605602117366 : Closed e605602117366 ∧ code e605602117366 = 9401695139574 := by decide
theorem cert_e605602117366 : check e605602117366 [[.under],[.under]] .three = true := by decide
def e605602117558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 1))) (.var 1)))))))
theorem wire_e605602117558 : Closed e605602117558 ∧ code e605602117558 = 9401695139766 := by decide
theorem cert_e605602117558 : check e605602117558 [[.under],[.under]] .three = true := by decide
def e605602118510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e605602118510 : Closed e605602118510 ∧ code e605602118510 = 9401695140718 := by decide
theorem cert_e605602118510 : check e605602118510 [[.under],[.under]] .three = true := by decide
def e605602118518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e605602118518 : Closed e605602118518 ∧ code e605602118518 = 9401695140726 := by decide
theorem cert_e605602118518 : check e605602118518 [[.under],[.under]] .three = true := by decide
def e605602118582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e605602118582 : Closed e605602118582 ∧ code e605602118582 = 9401695140790 := by decide
theorem cert_e605602118582 : check e605602118582 [[.under],[.under]] .three = true := by decide
def e605602160094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e605602160094 : Closed e605602160094 ∧ code e605602160094 = 9401695182302 := by decide
theorem cert_e605602160094 : check e605602160094 [[.under],[.under]] .three = true := by decide
def e605602160110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e605602160110 : Closed e605602160110 ∧ code e605602160110 = 9401695182318 := by decide
theorem cert_e605602160110 : check e605602160110 [[.under],[.under]] .three = true := by decide
def e605602160350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e605602160350 : Closed e605602160350 ∧ code e605602160350 = 9401695182558 := by decide
theorem cert_e605602160350 : check e605602160350 [[.under],[.under]] .three = true := by decide
def e605602160374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e605602160374 : Closed e605602160374 ∧ code e605602160374 = 9401695182582 := by decide
theorem cert_e605602160374 : check e605602160374 [[.under],[.under]] .three = true := by decide
def e605602160494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e605602160494 : Closed e605602160494 ∧ code e605602160494 = 9401695182702 := by decide
theorem cert_e605602160494 : check e605602160494 [[.under],[.under]] .three = true := by decide
def e605602160502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e605602160502 : Closed e605602160502 ∧ code e605602160502 = 9401695182710 := by decide
theorem cert_e605602160502 : check e605602160502 [[.under],[.under]] .three = true := by decide
def e605602165726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e605602165726 : Closed e605602165726 ∧ code e605602165726 = 9401695187934 := by decide
theorem cert_e605602165726 : check e605602165726 [[.under],[.under]] .three = true := by decide
def e605602165742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e605602165742 : Closed e605602165742 ∧ code e605602165742 = 9401695187950 := by decide
theorem cert_e605602165742 : check e605602165742 [[.under],[.under]] .three = true := by decide
def e605602167262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e605602167262 : Closed e605602167262 ∧ code e605602167262 = 9401695189470 := by decide
theorem cert_e605602167262 : check e605602167262 [[.under],[.under]] .three = true := by decide
def e605602167286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e605602167286 : Closed e605602167286 ∧ code e605602167286 = 9401695189494 := by decide
theorem cert_e605602167286 : check e605602167286 [[.under],[.under]] .three = true := by decide
def e605602168046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e605602168046 : Closed e605602168046 ∧ code e605602168046 = 9401695190254 := by decide
theorem cert_e605602168046 : check e605602168046 [[.under],[.under]] .three = true := by decide
def e605602168054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e605602168054 : Closed e605602168054 ∧ code e605602168054 = 9401695190262 := by decide
theorem cert_e605602168054 : check e605602168054 [[.under],[.under]] .three = true := by decide
def e605602172638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 3)))))))
theorem wire_e605602172638 : Closed e605602172638 ∧ code e605602172638 = 9401695194846 := by decide
theorem cert_e605602172638 : check e605602172638 [[.under],[.under]] .three = true := by decide
def e605602172662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e605602172662 : Closed e605602172662 ∧ code e605602172662 = 9401695194870 := by decide
theorem cert_e605602172662 : check e605602172662 [[.under],[.under]] .three = true := by decide
def e605602172854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e605602172854 : Closed e605602172854 ∧ code e605602172854 = 9401695195062 := by decide
theorem cert_e605602172854 : check e605602172854 [[.under],[.under]] .three = true := by decide
def e605602175454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 3))))))))
theorem wire_e605602175454 : Closed e605602175454 ∧ code e605602175454 = 9401695197662 := by decide
theorem cert_e605602175454 : check e605602175454 [[.under],[.under]] .three = true := by decide
def e605602175478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e605602175478 : Closed e605602175478 ∧ code e605602175478 = 9401695197686 := by decide
theorem cert_e605602175478 : check e605602175478 [[.under],[.under]] .three = true := by decide
def e605602176630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e605602176630 : Closed e605602176630 ∧ code e605602176630 = 9401695198838 := by decide
theorem cert_e605602176630 : check e605602176630 [[.under],[.under]] .three = true := by decide
def e605602178926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e605602178926 : Closed e605602178926 ∧ code e605602178926 = 9401695201134 := by decide
theorem cert_e605602178926 : check e605602178926 [[.under],[.under]] .three = true := by decide
def e605602178934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e605602178934 : Closed e605602178934 ∧ code e605602178934 = 9401695201142 := by decide
theorem cert_e605602178934 : check e605602178934 [[.under],[.under]] .three = true := by decide
def e605602178998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e605602178998 : Closed e605602178998 ∧ code e605602178998 = 9401695201206 := by decide
theorem cert_e605602178998 : check e605602178998 [[.under],[.under]] .three = true := by decide
def e605602180334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605602180334 : Closed e605602180334 ∧ code e605602180334 = 9401695202542 := by decide
theorem cert_e605602180334 : check e605602180334 [[.under],[.under]] .three = true := by decide
def e605602180342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605602180342 : Closed e605602180342 ∧ code e605602180342 = 9401695202550 := by decide
theorem cert_e605602180342 : check e605602180342 [[.under],[.under]] .three = true := by decide
def e605602180726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e605602180726 : Closed e605602180726 ∧ code e605602180726 = 9401695202934 := by decide
theorem cert_e605602180726 : check e605602180726 [[.under],[.under]] .three = true := by decide
def e605602340318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e605602340318 : Closed e605602340318 ∧ code e605602340318 = 9401695362526 := by decide
theorem cert_e605602340318 : check e605602340318 [[.under],[.under]] .three = true := by decide
def e605602340334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e605602340334 : Closed e605602340334 ∧ code e605602340334 = 9401695362542 := by decide
theorem cert_e605602340334 : check e605602340334 [[.under],[.under]] .three = true := by decide
def e605602340574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e605602340574 : Closed e605602340574 ∧ code e605602340574 = 9401695362782 := by decide
theorem cert_e605602340574 : check e605602340574 [[.under],[.under]] .three = true := by decide
def e605602340598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e605602340598 : Closed e605602340598 ∧ code e605602340598 = 9401695362806 := by decide
theorem cert_e605602340598 : check e605602340598 [[.under],[.under]] .three = true := by decide
def e605602340718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e605602340718 : Closed e605602340718 ∧ code e605602340718 = 9401695362926 := by decide
theorem cert_e605602340718 : check e605602340718 [[.under],[.under]] .three = true := by decide
def e605602340726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e605602340726 : Closed e605602340726 ∧ code e605602340726 = 9401695362934 := by decide
theorem cert_e605602340726 : check e605602340726 [[.under],[.under]] .three = true := by decide
def e605602345950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e605602345950 : Closed e605602345950 ∧ code e605602345950 = 9401695368158 := by decide
theorem cert_e605602345950 : check e605602345950 [[.under],[.under]] .three = true := by decide
def e605602345966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e605602345966 : Closed e605602345966 ∧ code e605602345966 = 9401695368174 := by decide
theorem cert_e605602345966 : check e605602345966 [[.under],[.under]] .three = true := by decide
def e605602347486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602347486 : Closed e605602347486 ∧ code e605602347486 = 9401695369694 := by decide
theorem cert_e605602347486 : check e605602347486 [[.under],[.under]] .three = true := by decide
def e605602347510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602347510 : Closed e605602347510 ∧ code e605602347510 = 9401695369718 := by decide
theorem cert_e605602347510 : check e605602347510 [[.under],[.under]] .three = true := by decide
def e605602348270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602348270 : Closed e605602348270 ∧ code e605602348270 = 9401695370478 := by decide
theorem cert_e605602348270 : check e605602348270 [[.under],[.under]] .three = true := by decide
def e605602348278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602348278 : Closed e605602348278 ∧ code e605602348278 = 9401695370486 := by decide
theorem cert_e605602348278 : check e605602348278 [[.under],[.under]] .three = true := by decide
def e605602393822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e605602393822 : Closed e605602393822 ∧ code e605602393822 = 9401695416030 := by decide
theorem cert_e605602393822 : check e605602393822 [[.under],[.under]] .three = true := by decide
def e605602393846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e605602393846 : Closed e605602393846 ∧ code e605602393846 = 9401695416054 := by decide
theorem cert_e605602393846 : check e605602393846 [[.under],[.under]] .three = true := by decide
def e605602394038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e605602394038 : Closed e605602394038 ∧ code e605602394038 = 9401695416246 := by decide
theorem cert_e605602394038 : check e605602394038 [[.under],[.under]] .three = true := by decide
def e605602396638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602396638 : Closed e605602396638 ∧ code e605602396638 = 9401695418846 := by decide
theorem cert_e605602396638 : check e605602396638 [[.under],[.under]] .three = true := by decide
def e605602396662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602396662 : Closed e605602396662 ∧ code e605602396662 = 9401695418870 := by decide
theorem cert_e605602396662 : check e605602396662 [[.under],[.under]] .three = true := by decide
def e605602397814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602397814 : Closed e605602397814 ∧ code e605602397814 = 9401695420022 := by decide
theorem cert_e605602397814 : check e605602397814 [[.under],[.under]] .three = true := by decide
def e605602420590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e605602420590 : Closed e605602420590 ∧ code e605602420590 = 9401695442798 := by decide
theorem cert_e605602420590 : check e605602420590 [[.under],[.under]] .three = true := by decide
def e605602420598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e605602420598 : Closed e605602420598 ∧ code e605602420598 = 9401695442806 := by decide
theorem cert_e605602420598 : check e605602420598 [[.under],[.under]] .three = true := by decide
def e605602420662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e605602420662 : Closed e605602420662 ∧ code e605602420662 = 9401695442870 := by decide
theorem cert_e605602420662 : check e605602420662 [[.under],[.under]] .three = true := by decide
def e605602421998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602421998 : Closed e605602421998 ∧ code e605602421998 = 9401695444206 := by decide
theorem cert_e605602421998 : check e605602421998 [[.under],[.under]] .three = true := by decide
def e605602422006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602422006 : Closed e605602422006 ∧ code e605602422006 = 9401695444214 := by decide
theorem cert_e605602422006 : check e605602422006 [[.under],[.under]] .three = true := by decide
def e605602422390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e605602422390 : Closed e605602422390 ∧ code e605602422390 = 9401695444598 := by decide
theorem cert_e605602422390 : check e605602422390 [[.under],[.under]] .three = true := by decide
def e605602541022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 3)))))))
theorem wire_e605602541022 : Closed e605602541022 ∧ code e605602541022 = 9401695563230 := by decide
theorem cert_e605602541022 : check e605602541022 [[.under],[.under]] .three = true := by decide
def e605602541038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 2)))))))
theorem wire_e605602541038 : Closed e605602541038 ∧ code e605602541038 = 9401695563246 := by decide
theorem cert_e605602541038 : check e605602541038 [[.under],[.under]] .three = true := by decide
def e605602541278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 3)))))))
theorem wire_e605602541278 : Closed e605602541278 ∧ code e605602541278 = 9401695563486 := by decide
theorem cert_e605602541278 : check e605602541278 [[.under],[.under]] .three = true := by decide
def e605602541302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 3))) (.var 1)))))))
theorem wire_e605602541302 : Closed e605602541302 ∧ code e605602541302 = 9401695563510 := by decide
theorem cert_e605602541302 : check e605602541302 [[.under],[.under]] .three = true := by decide
def e605602541422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 2)))))))
theorem wire_e605602541422 : Closed e605602541422 ∧ code e605602541422 = 9401695563630 := by decide
theorem cert_e605602541422 : check e605602541422 [[.under],[.under]] .three = true := by decide
def e605602541430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 2))) (.var 1)))))))
theorem wire_e605602541430 : Closed e605602541430 ∧ code e605602541430 = 9401695563638 := by decide
theorem cert_e605602541430 : check e605602541430 [[.under],[.under]] .three = true := by decide
def e605602543070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 3)))))))
theorem wire_e605602543070 : Closed e605602543070 ∧ code e605602543070 = 9401695565278 := by decide
theorem cert_e605602543070 : check e605602543070 [[.under],[.under]] .three = true := by decide
def e605602543086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 2)))))))
theorem wire_e605602543086 : Closed e605602543086 ∧ code e605602543086 = 9401695565294 := by decide
theorem cert_e605602543086 : check e605602543086 [[.under],[.under]] .three = true := by decide
def e605602543454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 3)))))))
theorem wire_e605602543454 : Closed e605602543454 ∧ code e605602543454 = 9401695565662 := by decide
theorem cert_e605602543454 : check e605602543454 [[.under],[.under]] .three = true := by decide
def e605602543482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 3))) (.var 0)))))))
theorem wire_e605602543482 : Closed e605602543482 ∧ code e605602543482 = 9401695565690 := by decide
theorem cert_e605602543482 : check e605602543482 [[.under],[.under]] .three = true := by decide
def e605602543534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 2)))))))
theorem wire_e605602543534 : Closed e605602543534 ∧ code e605602543534 = 9401695565742 := by decide
theorem cert_e605602543534 : check e605602543534 [[.under],[.under]] .three = true := by decide
def e605602543546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 2))) (.var 0)))))))
theorem wire_e605602543546 : Closed e605602543546 ∧ code e605602543546 = 9401695565754 := by decide
theorem cert_e605602543546 : check e605602543546 [[.under],[.under]] .three = true := by decide
def e605602544350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e605602544350 : Closed e605602544350 ∧ code e605602544350 = 9401695566558 := by decide
theorem cert_e605602544350 : check e605602544350 [[.under],[.under]] .three = true := by decide
def e605602544374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e605602544374 : Closed e605602544374 ∧ code e605602544374 = 9401695566582 := by decide
theorem cert_e605602544374 : check e605602544374 [[.under],[.under]] .three = true := by decide
def e605602544478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e605602544478 : Closed e605602544478 ∧ code e605602544478 = 9401695566686 := by decide
theorem cert_e605602544478 : check e605602544478 [[.under],[.under]] .three = true := by decide
def e605602544506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e605602544506 : Closed e605602544506 ∧ code e605602544506 = 9401695566714 := by decide
theorem cert_e605602544506 : check e605602544506 [[.under],[.under]] .three = true := by decide
def e605602544598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e605602544598 : Closed e605602544598 ∧ code e605602544598 = 9401695566806 := by decide
theorem cert_e605602544598 : check e605602544598 [[.under],[.under]] .three = true := by decide
def e605602544602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e605602544602 : Closed e605602544602 ∧ code e605602544602 = 9401695566810 := by decide
theorem cert_e605602544602 : check e605602544602 [[.under],[.under]] .three = true := by decide
def e605602545006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e605602545006 : Closed e605602545006 ∧ code e605602545006 = 9401695567214 := by decide
theorem cert_e605602545006 : check e605602545006 [[.under],[.under]] .three = true := by decide
def e605602545014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e605602545014 : Closed e605602545014 ∧ code e605602545014 = 9401695567222 := by decide
theorem cert_e605602545014 : check e605602545014 [[.under],[.under]] .three = true := by decide
def e605602545070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e605602545070 : Closed e605602545070 ∧ code e605602545070 = 9401695567278 := by decide
theorem cert_e605602545070 : check e605602545070 [[.under],[.under]] .three = true := by decide
def e605602545082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e605602545082 : Closed e605602545082 ∧ code e605602545082 = 9401695567290 := by decide
theorem cert_e605602545082 : check e605602545082 [[.under],[.under]] .three = true := by decide
def e605602545110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e605602545110 : Closed e605602545110 ∧ code e605602545110 = 9401695567318 := by decide
theorem cert_e605602545110 : check e605602545110 [[.under],[.under]] .three = true := by decide
def e605602545114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e605602545114 : Closed e605602545114 ∧ code e605602545114 = 9401695567322 := by decide
theorem cert_e605602545114 : check e605602545114 [[.under],[.under]] .three = true := by decide
def e605602553310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e605602553310 : Closed e605602553310 ∧ code e605602553310 = 9401695575518 := by decide
theorem cert_e605602553310 : check e605602553310 [[.under],[.under]] .three = true := by decide
def e605602553326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e605602553326 : Closed e605602553326 ∧ code e605602553326 = 9401695575534 := by decide
theorem cert_e605602553326 : check e605602553326 [[.under],[.under]] .three = true := by decide
def e605602553566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e605602553566 : Closed e605602553566 ∧ code e605602553566 = 9401695575774 := by decide
theorem cert_e605602553566 : check e605602553566 [[.under],[.under]] .three = true := by decide
def e605602553590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e605602553590 : Closed e605602553590 ∧ code e605602553590 = 9401695575798 := by decide
theorem cert_e605602553590 : check e605602553590 [[.under],[.under]] .three = true := by decide
def e605602553710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e605602553710 : Closed e605602553710 ∧ code e605602553710 = 9401695575918 := by decide
theorem cert_e605602553710 : check e605602553710 [[.under],[.under]] .three = true := by decide
def e605602553718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e605602553718 : Closed e605602553718 ∧ code e605602553718 = 9401695575926 := by decide
theorem cert_e605602553718 : check e605602553718 [[.under],[.under]] .three = true := by decide
def e605602558942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e605602558942 : Closed e605602558942 ∧ code e605602558942 = 9401695581150 := by decide
theorem cert_e605602558942 : check e605602558942 [[.under],[.under]] .three = true := by decide
def e605602558958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e605602558958 : Closed e605602558958 ∧ code e605602558958 = 9401695581166 := by decide
theorem cert_e605602558958 : check e605602558958 [[.under],[.under]] .three = true := by decide
def e605602560478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e605602560478 : Closed e605602560478 ∧ code e605602560478 = 9401695582686 := by decide
theorem cert_e605602560478 : check e605602560478 [[.under],[.under]] .three = true := by decide
def e605602560502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e605602560502 : Closed e605602560502 ∧ code e605602560502 = 9401695582710 := by decide
theorem cert_e605602560502 : check e605602560502 [[.under],[.under]] .three = true := by decide
def e605602561262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e605602561262 : Closed e605602561262 ∧ code e605602561262 = 9401695583470 := by decide
theorem cert_e605602561262 : check e605602561262 [[.under],[.under]] .three = true := by decide
def e605602561270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e605602561270 : Closed e605602561270 ∧ code e605602561270 = 9401695583478 := by decide
theorem cert_e605602561270 : check e605602561270 [[.under],[.under]] .three = true := by decide
def e605602565598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e605602565598 : Closed e605602565598 ∧ code e605602565598 = 9401695587806 := by decide
theorem cert_e605602565598 : check e605602565598 [[.under],[.under]] .three = true := by decide
def e605602565614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e605602565614 : Closed e605602565614 ∧ code e605602565614 = 9401695587822 := by decide
theorem cert_e605602565614 : check e605602565614 [[.under],[.under]] .three = true := by decide
def e605602565982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e605602565982 : Closed e605602565982 ∧ code e605602565982 = 9401695588190 := by decide
theorem cert_e605602565982 : check e605602565982 [[.under],[.under]] .three = true := by decide
def e605602566010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e605602566010 : Closed e605602566010 ∧ code e605602566010 = 9401695588218 := by decide
theorem cert_e605602566010 : check e605602566010 [[.under],[.under]] .three = true := by decide
def e605602566062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e605602566062 : Closed e605602566062 ∧ code e605602566062 = 9401695588270 := by decide
theorem cert_e605602566062 : check e605602566062 [[.under],[.under]] .three = true := by decide
def e605602566074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e605602566074 : Closed e605602566074 ∧ code e605602566074 = 9401695588282 := by decide
theorem cert_e605602566074 : check e605602566074 [[.under],[.under]] .three = true := by decide
def e605602567134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e605602567134 : Closed e605602567134 ∧ code e605602567134 = 9401695589342 := by decide
theorem cert_e605602567134 : check e605602567134 [[.under],[.under]] .three = true := by decide
def e605602567150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e605602567150 : Closed e605602567150 ∧ code e605602567150 = 9401695589358 := by decide
theorem cert_e605602567150 : check e605602567150 [[.under],[.under]] .three = true := by decide
def e605602569438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e605602569438 : Closed e605602569438 ∧ code e605602569438 = 9401695591646 := by decide
theorem cert_e605602569438 : check e605602569438 [[.under],[.under]] .three = true := by decide
def e605602569466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e605602569466 : Closed e605602569466 ∧ code e605602569466 = 9401695591674 := by decide
theorem cert_e605602569466 : check e605602569466 [[.under],[.under]] .three = true := by decide
def e605602569838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e605602569838 : Closed e605602569838 ∧ code e605602569838 = 9401695592046 := by decide
theorem cert_e605602569838 : check e605602569838 [[.under],[.under]] .three = true := by decide
def e605602569850 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e605602569850 : Closed e605602569850 ∧ code e605602569850 = 9401695592058 := by decide
theorem cert_e605602569850 : check e605602569850 [[.under],[.under]] .three = true := by decide
def e605602571998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e605602571998 : Closed e605602571998 ∧ code e605602571998 = 9401695594206 := by decide
theorem cert_e605602571998 : check e605602571998 [[.under],[.under]] .three = true := by decide
def e605602572022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e605602572022 : Closed e605602572022 ∧ code e605602572022 = 9401695594230 := by decide
theorem cert_e605602572022 : check e605602572022 [[.under],[.under]] .three = true := by decide
def e605602572126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e605602572126 : Closed e605602572126 ∧ code e605602572126 = 9401695594334 := by decide
theorem cert_e605602572126 : check e605602572126 [[.under],[.under]] .three = true := by decide
def e605602572154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e605602572154 : Closed e605602572154 ∧ code e605602572154 = 9401695594362 := by decide
theorem cert_e605602572154 : check e605602572154 [[.under],[.under]] .three = true := by decide
def e605602572246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e605602572246 : Closed e605602572246 ∧ code e605602572246 = 9401695594454 := by decide
theorem cert_e605602572246 : check e605602572246 [[.under],[.under]] .three = true := by decide
def e605602572250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e605602572250 : Closed e605602572250 ∧ code e605602572250 = 9401695594458 := by decide
theorem cert_e605602572250 : check e605602572250 [[.under],[.under]] .three = true := by decide
def e605602572766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e605602572766 : Closed e605602572766 ∧ code e605602572766 = 9401695594974 := by decide
theorem cert_e605602572766 : check e605602572766 [[.under],[.under]] .three = true := by decide
def e605602572790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e605602572790 : Closed e605602572790 ∧ code e605602572790 = 9401695594998 := by decide
theorem cert_e605602572790 : check e605602572790 [[.under],[.under]] .three = true := by decide
def e605602573534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e605602573534 : Closed e605602573534 ∧ code e605602573534 = 9401695595742 := by decide
theorem cert_e605602573534 : check e605602573534 [[.under],[.under]] .three = true := by decide
def e605602573562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e605602573562 : Closed e605602573562 ∧ code e605602573562 = 9401695595770 := by decide
theorem cert_e605602573562 : check e605602573562 [[.under],[.under]] .three = true := by decide
def e605602574134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605602574134 : Closed e605602574134 ∧ code e605602574134 = 9401695596342 := by decide
theorem cert_e605602574134 : check e605602574134 [[.under],[.under]] .three = true := by decide
def e605602574138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605602574138 : Closed e605602574138 ∧ code e605602574138 = 9401695596346 := by decide
theorem cert_e605602574138 : check e605602574138 [[.under],[.under]] .three = true := by decide
def e605602575214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e605602575214 : Closed e605602575214 ∧ code e605602575214 = 9401695597422 := by decide
theorem cert_e605602575214 : check e605602575214 [[.under],[.under]] .three = true := by decide
def e605602575222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e605602575222 : Closed e605602575222 ∧ code e605602575222 = 9401695597430 := by decide
theorem cert_e605602575222 : check e605602575222 [[.under],[.under]] .three = true := by decide
def e605602575278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e605602575278 : Closed e605602575278 ∧ code e605602575278 = 9401695597486 := by decide
theorem cert_e605602575278 : check e605602575278 [[.under],[.under]] .three = true := by decide
def e605602575290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e605602575290 : Closed e605602575290 ∧ code e605602575290 = 9401695597498 := by decide
theorem cert_e605602575290 : check e605602575290 [[.under],[.under]] .three = true := by decide
def e605602575318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e605602575318 : Closed e605602575318 ∧ code e605602575318 = 9401695597526 := by decide
theorem cert_e605602575318 : check e605602575318 [[.under],[.under]] .three = true := by decide
def e605602575322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e605602575322 : Closed e605602575322 ∧ code e605602575322 = 9401695597530 := by decide
theorem cert_e605602575322 : check e605602575322 [[.under],[.under]] .three = true := by decide
def e605602575598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e605602575598 : Closed e605602575598 ∧ code e605602575598 = 9401695597806 := by decide
theorem cert_e605602575598 : check e605602575598 [[.under],[.under]] .three = true := by decide
def e605602575606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e605602575606 : Closed e605602575606 ∧ code e605602575606 = 9401695597814 := by decide
theorem cert_e605602575606 : check e605602575606 [[.under],[.under]] .three = true := by decide
def e605602575982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605602575982 : Closed e605602575982 ∧ code e605602575982 = 9401695598190 := by decide
theorem cert_e605602575982 : check e605602575982 [[.under],[.under]] .three = true := by decide
def e605602575994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605602575994 : Closed e605602575994 ∧ code e605602575994 = 9401695598202 := by decide
theorem cert_e605602575994 : check e605602575994 [[.under],[.under]] .three = true := by decide
def e605602576182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e605602576182 : Closed e605602576182 ∧ code e605602576182 = 9401695598390 := by decide
theorem cert_e605602576182 : check e605602576182 [[.under],[.under]] .three = true := by decide
def e605602576186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e605602576186 : Closed e605602576186 ∧ code e605602576186 = 9401695598394 := by decide
theorem cert_e605602576186 : check e605602576186 [[.under],[.under]] .three = true := by decide
def e605602602462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e605602602462 : Closed e605602602462 ∧ code e605602602462 = 9401695624670 := by decide
theorem cert_e605602602462 : check e605602602462 [[.under],[.under]] .three = true := by decide
def e605602602478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e605602602478 : Closed e605602602478 ∧ code e605602602478 = 9401695624686 := by decide
theorem cert_e605602602478 : check e605602602478 [[.under],[.under]] .three = true := by decide
def e605602602718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e605602602718 : Closed e605602602718 ∧ code e605602602718 = 9401695624926 := by decide
theorem cert_e605602602718 : check e605602602718 [[.under],[.under]] .three = true := by decide
def e605602602742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e605602602742 : Closed e605602602742 ∧ code e605602602742 = 9401695624950 := by decide
theorem cert_e605602602742 : check e605602602742 [[.under],[.under]] .three = true := by decide
def e605602602862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e605602602862 : Closed e605602602862 ∧ code e605602602862 = 9401695625070 := by decide
theorem cert_e605602602862 : check e605602602862 [[.under],[.under]] .three = true := by decide
def e605602602870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e605602602870 : Closed e605602602870 ∧ code e605602602870 = 9401695625078 := by decide
theorem cert_e605602602870 : check e605602602870 [[.under],[.under]] .three = true := by decide
def e605602608094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e605602608094 : Closed e605602608094 ∧ code e605602608094 = 9401695630302 := by decide
theorem cert_e605602608094 : check e605602608094 [[.under],[.under]] .three = true := by decide
def e605602608110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e605602608110 : Closed e605602608110 ∧ code e605602608110 = 9401695630318 := by decide
theorem cert_e605602608110 : check e605602608110 [[.under],[.under]] .three = true := by decide
def e605602609630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e605602609630 : Closed e605602609630 ∧ code e605602609630 = 9401695631838 := by decide
theorem cert_e605602609630 : check e605602609630 [[.under],[.under]] .three = true := by decide
def e605602609654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e605602609654 : Closed e605602609654 ∧ code e605602609654 = 9401695631862 := by decide
theorem cert_e605602609654 : check e605602609654 [[.under],[.under]] .three = true := by decide
def e605602610414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e605602610414 : Closed e605602610414 ∧ code e605602610414 = 9401695632622 := by decide
theorem cert_e605602610414 : check e605602610414 [[.under],[.under]] .three = true := by decide
def e605602610422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e605602610422 : Closed e605602610422 ∧ code e605602610422 = 9401695632630 := by decide
theorem cert_e605602610422 : check e605602610422 [[.under],[.under]] .three = true := by decide
def e605602655710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e605602655710 : Closed e605602655710 ∧ code e605602655710 = 9401695677918 := by decide
theorem cert_e605602655710 : check e605602655710 [[.under],[.under]] .three = true := by decide
def e605602655726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e605602655726 : Closed e605602655726 ∧ code e605602655726 = 9401695677934 := by decide
theorem cert_e605602655726 : check e605602655726 [[.under],[.under]] .three = true := by decide
def e605602656094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e605602656094 : Closed e605602656094 ∧ code e605602656094 = 9401695678302 := by decide
theorem cert_e605602656094 : check e605602656094 [[.under],[.under]] .three = true := by decide
def e605602656122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e605602656122 : Closed e605602656122 ∧ code e605602656122 = 9401695678330 := by decide
theorem cert_e605602656122 : check e605602656122 [[.under],[.under]] .three = true := by decide
def e605602656174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e605602656174 : Closed e605602656174 ∧ code e605602656174 = 9401695678382 := by decide
theorem cert_e605602656174 : check e605602656174 [[.under],[.under]] .three = true := by decide
def e605602656186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e605602656186 : Closed e605602656186 ∧ code e605602656186 = 9401695678394 := by decide
theorem cert_e605602656186 : check e605602656186 [[.under],[.under]] .three = true := by decide
def e605602657246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e605602657246 : Closed e605602657246 ∧ code e605602657246 = 9401695679454 := by decide
theorem cert_e605602657246 : check e605602657246 [[.under],[.under]] .three = true := by decide
def e605602657262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e605602657262 : Closed e605602657262 ∧ code e605602657262 = 9401695679470 := by decide
theorem cert_e605602657262 : check e605602657262 [[.under],[.under]] .three = true := by decide
def e605602659550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e605602659550 : Closed e605602659550 ∧ code e605602659550 = 9401695681758 := by decide
theorem cert_e605602659550 : check e605602659550 [[.under],[.under]] .three = true := by decide
def e605602659578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e605602659578 : Closed e605602659578 ∧ code e605602659578 = 9401695681786 := by decide
theorem cert_e605602659578 : check e605602659578 [[.under],[.under]] .three = true := by decide
def e605602659950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e605602659950 : Closed e605602659950 ∧ code e605602659950 = 9401695682158 := by decide
theorem cert_e605602659950 : check e605602659950 [[.under],[.under]] .three = true := by decide
def e605602659962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e605602659962 : Closed e605602659962 ∧ code e605602659962 = 9401695682170 := by decide
theorem cert_e605602659962 : check e605602659962 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
