import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389613991450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389613991450 : Closed e2389613991450 ∧ code e2389613991450 = 11185707013658 := by decide
theorem cert_e2389613991450 : check e2389613991450 [[]] .width = true := by decide
def e2389613992474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389613992474 : Closed e2389613992474 ∧ code e2389613992474 = 11185707014682 := by decide
theorem cert_e2389613992474 : check e2389613992474 [[]] .width = true := by decide
def e2389614124570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389614124570 : Closed e2389614124570 ∧ code e2389614124570 = 11185707146778 := by decide
theorem cert_e2389614124570 : check e2389614124570 [[]] .width = true := by decide
def e2389614130714 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389614130714 : Closed e2389614130714 ∧ code e2389614130714 = 11185707152922 := by decide
theorem cert_e2389614130714 : check e2389614130714 [[]] .width = true := by decide
def e2389614321178 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389614321178 : Closed e2389614321178 ∧ code e2389614321178 = 11185707343386 := by decide
theorem cert_e2389614321178 : check e2389614321178 [[]] .width = true := by decide
def e2389614328346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389614328346 : Closed e2389614328346 ∧ code e2389614328346 = 11185707350554 := by decide
theorem cert_e2389614328346 : check e2389614328346 [[]] .width = true := by decide
def e2389614474778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389614474778 : Closed e2389614474778 ∧ code e2389614474778 = 11185707496986 := by decide
theorem cert_e2389614474778 : check e2389614474778 [[]] .width = true := by decide
def e2389614475802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389614475802 : Closed e2389614475802 ∧ code e2389614475802 = 11185707498010 := by decide
theorem cert_e2389614475802 : check e2389614475802 [[]] .width = true := by decide
def e2389618257434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618257434 : Closed e2389618257434 ∧ code e2389618257434 = 11185711279642 := by decide
theorem cert_e2389618257434 : check e2389618257434 [[]] .width = true := by decide
def e2389618259482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618259482 : Closed e2389618259482 ∧ code e2389618259482 = 11185711281690 := by decide
theorem cert_e2389618259482 : check e2389618259482 [[]] .width = true := by decide
def e2389618400794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618400794 : Closed e2389618400794 ∧ code e2389618400794 = 11185711423002 := by decide
theorem cert_e2389618400794 : check e2389618400794 [[]] .width = true := by decide
def e2389618421958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389618421958 : Closed e2389618421958 ∧ code e2389618421958 = 11185711444166 := by decide
theorem cert_e2389618421958 : check e2389618421958 [[]] .width = true := by decide
def e2389618429466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618429466 : Closed e2389618429466 ∧ code e2389618429466 = 11185711451674 := by decide
theorem cert_e2389618429466 : check e2389618429466 [[]] .width = true := by decide
def e2389618438342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389618438342 : Closed e2389618438342 ∧ code e2389618438342 = 11185711460550 := by decide
theorem cert_e2389618438342 : check e2389618438342 [[]] .width = true := by decide
def e2389618486810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618486810 : Closed e2389618486810 ∧ code e2389618486810 = 11185711509018 := by decide
theorem cert_e2389618486810 : check e2389618486810 [[]] .width = true := by decide
def e2389618489882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618489882 : Closed e2389618489882 ∧ code e2389618489882 = 11185711512090 := by decide
theorem cert_e2389618489882 : check e2389618489882 [[]] .width = true := by decide
def e2389618531866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618531866 : Closed e2389618531866 ∧ code e2389618531866 = 11185711554074 := by decide
theorem cert_e2389618531866 : check e2389618531866 [[]] .width = true := by decide
def e2389618553030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389618553030 : Closed e2389618553030 ∧ code e2389618553030 = 11185711575238 := by decide
theorem cert_e2389618553030 : check e2389618553030 [[]] .width = true := by decide
def e2389618574874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618574874 : Closed e2389618574874 ∧ code e2389618574874 = 11185711597082 := by decide
theorem cert_e2389618574874 : check e2389618574874 [[]] .width = true := by decide
def e2389618577606 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389618577606 : Closed e2389618577606 ∧ code e2389618577606 = 11185711599814 := by decide
theorem cert_e2389618577606 : check e2389618577606 [[]] .width = true := by decide
def e2389618603546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618603546 : Closed e2389618603546 ∧ code e2389618603546 = 11185711625754 := by decide
theorem cert_e2389618603546 : check e2389618603546 [[]] .width = true := by decide
def e2389618604570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618604570 : Closed e2389618604570 ∧ code e2389618604570 = 11185711626778 := by decide
theorem cert_e2389618604570 : check e2389618604570 [[]] .width = true := by decide
def e2389618626074 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618626074 : Closed e2389618626074 ∧ code e2389618626074 = 11185711648282 := by decide
theorem cert_e2389618626074 : check e2389618626074 [[]] .width = true := by decide
def e2389618634950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389618634950 : Closed e2389618634950 ∧ code e2389618634950 = 11185711657158 := by decide
theorem cert_e2389618634950 : check e2389618634950 [[]] .width = true := by decide
def e2389618640410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389618640410 : Closed e2389618640410 ∧ code e2389618640410 = 11185711662618 := by decide
theorem cert_e2389618640410 : check e2389618640410 [[]] .width = true := by decide
def e2389618643142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389618643142 : Closed e2389618643142 ∧ code e2389618643142 = 11185711665350 := by decide
theorem cert_e2389618643142 : check e2389618643142 [[]] .width = true := by decide
def e2389619187226 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389619187226 : Closed e2389619187226 ∧ code e2389619187226 = 11185712209434 := by decide
theorem cert_e2389619187226 : check e2389619187226 [[]] .width = true := by decide
def e2389619208390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389619208390 : Closed e2389619208390 ∧ code e2389619208390 = 11185712230598 := by decide
theorem cert_e2389619208390 : check e2389619208390 [[]] .width = true := by decide
def e2389619215898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389619215898 : Closed e2389619215898 ∧ code e2389619215898 = 11185712238106 := by decide
theorem cert_e2389619215898 : check e2389619215898 [[]] .width = true := by decide
def e2389619224774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389619224774 : Closed e2389619224774 ∧ code e2389619224774 = 11185712246982 := by decide
theorem cert_e2389619224774 : check e2389619224774 [[]] .width = true := by decide
def e2389619973658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389619973658 : Closed e2389619973658 ∧ code e2389619973658 = 11185712995866 := by decide
theorem cert_e2389619973658 : check e2389619973658 [[]] .width = true := by decide
def e2389619994822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389619994822 : Closed e2389619994822 ∧ code e2389619994822 = 11185713017030 := by decide
theorem cert_e2389619994822 : check e2389619994822 [[]] .width = true := by decide
def e2389620016666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389620016666 : Closed e2389620016666 ∧ code e2389620016666 = 11185713038874 := by decide
theorem cert_e2389620016666 : check e2389620016666 [[]] .width = true := by decide
def e2389620019398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389620019398 : Closed e2389620019398 ∧ code e2389620019398 = 11185713041606 := by decide
theorem cert_e2389620019398 : check e2389620019398 [[]] .width = true := by decide
def e2389620395546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389620395546 : Closed e2389620395546 ∧ code e2389620395546 = 11185713417754 := by decide
theorem cert_e2389620395546 : check e2389620395546 [[]] .width = true := by decide
def e2389620404422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389620404422 : Closed e2389620404422 ∧ code e2389620404422 = 11185713426630 := by decide
theorem cert_e2389620404422 : check e2389620404422 [[]] .width = true := by decide
def e2389620409882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389620409882 : Closed e2389620409882 ∧ code e2389620409882 = 11185713432090 := by decide
theorem cert_e2389620409882 : check e2389620409882 [[]] .width = true := by decide
def e2389620412614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2389620412614 : Closed e2389620412614 ∧ code e2389620412614 = 11185713434822 := by decide
theorem cert_e2389620412614 : check e2389620412614 [[]] .width = true := by decide
def e2389646072686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2389646072686 : Closed e2389646072686 ∧ code e2389646072686 = 11185739094894 := by decide
theorem cert_e2389646072686 : check e2389646072686 [[],[.left]] .chain = true := by decide
def e2389646072694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2389646072694 : Closed e2389646072694 ∧ code e2389646072694 = 11185739094902 := by decide
theorem cert_e2389646072694 : check e2389646072694 [[],[.left]] .chain = true := by decide
def e2389646072758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2389646072758 : Closed e2389646072758 ∧ code e2389646072758 = 11185739094966 := by decide
theorem cert_e2389646072758 : check e2389646072758 [[],[.left]] .chain = true := by decide
def e2389646073198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2389646073198 : Closed e2389646073198 ∧ code e2389646073198 = 11185739095406 := by decide
theorem cert_e2389646073198 : check e2389646073198 [[],[.left]] .chain = true := by decide
def e2389646073206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2389646073206 : Closed e2389646073206 ∧ code e2389646073206 = 11185739095414 := by decide
theorem cert_e2389646073206 : check e2389646073206 [[],[.left]] .chain = true := by decide
def e2389646073262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2389646073262 : Closed e2389646073262 ∧ code e2389646073262 = 11185739095470 := by decide
theorem cert_e2389646073262 : check e2389646073262 [[],[.left]] .chain = true := by decide
def e2389646073274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2389646073274 : Closed e2389646073274 ∧ code e2389646073274 = 11185739095482 := by decide
theorem cert_e2389646073274 : check e2389646073274 [[],[.left]] .chain = true := by decide
def e2389646073302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2389646073302 : Closed e2389646073302 ∧ code e2389646073302 = 11185739095510 := by decide
theorem cert_e2389646073302 : check e2389646073302 [[],[.left]] .chain = true := by decide
def e2389646073306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2389646073306 : Closed e2389646073306 ∧ code e2389646073306 = 11185739095514 := by decide
theorem cert_e2389646073306 : check e2389646073306 [[],[.left]] .chain = true := by decide
def e2389646073526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2389646073526 : Closed e2389646073526 ∧ code e2389646073526 = 11185739095734 := by decide
theorem cert_e2389646073526 : check e2389646073526 [[],[.left]] .chain = true := by decide
def e2389646073558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2389646073558 : Closed e2389646073558 ∧ code e2389646073558 = 11185739095766 := by decide
theorem cert_e2389646073558 : check e2389646073558 [[],[.left]] .chain = true := by decide
def e2389646073562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2389646073562 : Closed e2389646073562 ∧ code e2389646073562 = 11185739095770 := by decide
theorem cert_e2389646073562 : check e2389646073562 [[],[.left]] .chain = true := by decide
def e2389646075758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2389646075758 : Closed e2389646075758 ∧ code e2389646075758 = 11185739097966 := by decide
theorem cert_e2389646075758 : check e2389646075758 [[],[.left]] .chain = true := by decide
def e2389646075766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2389646075766 : Closed e2389646075766 ∧ code e2389646075766 = 11185739097974 := by decide
theorem cert_e2389646075766 : check e2389646075766 [[],[.left]] .chain = true := by decide
def e2389646075830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2389646075830 : Closed e2389646075830 ∧ code e2389646075830 = 11185739098038 := by decide
theorem cert_e2389646075830 : check e2389646075830 [[],[.left]] .chain = true := by decide
def e2389646077166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2389646077166 : Closed e2389646077166 ∧ code e2389646077166 = 11185739099374 := by decide
theorem cert_e2389646077166 : check e2389646077166 [[],[.left]] .chain = true := by decide
def e2389646077174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2389646077174 : Closed e2389646077174 ∧ code e2389646077174 = 11185739099382 := by decide
theorem cert_e2389646077174 : check e2389646077174 [[],[.left]] .chain = true := by decide
def e2389646077558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2389646077558 : Closed e2389646077558 ∧ code e2389646077558 = 11185739099766 := by decide
theorem cert_e2389646077558 : check e2389646077558 [[],[.left]] .chain = true := by decide
def e2389646078830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2389646078830 : Closed e2389646078830 ∧ code e2389646078830 = 11185739101038 := by decide
theorem cert_e2389646078830 : check e2389646078830 [[],[.left]] .chain = true := by decide
def e2389646078838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2389646078838 : Closed e2389646078838 ∧ code e2389646078838 = 11185739101046 := by decide
theorem cert_e2389646078838 : check e2389646078838 [[],[.left]] .chain = true := by decide
def e2389646078894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2389646078894 : Closed e2389646078894 ∧ code e2389646078894 = 11185739101102 := by decide
theorem cert_e2389646078894 : check e2389646078894 [[],[.left]] .chain = true := by decide
def e2389646078906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2389646078906 : Closed e2389646078906 ∧ code e2389646078906 = 11185739101114 := by decide
theorem cert_e2389646078906 : check e2389646078906 [[],[.left]] .chain = true := by decide
def e2389646078934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2389646078934 : Closed e2389646078934 ∧ code e2389646078934 = 11185739101142 := by decide
theorem cert_e2389646078934 : check e2389646078934 [[],[.left]] .chain = true := by decide
def e2389646078938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2389646078938 : Closed e2389646078938 ∧ code e2389646078938 = 11185739101146 := by decide
theorem cert_e2389646078938 : check e2389646078938 [[],[.left]] .chain = true := by decide
def e2389646079214 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2389646079214 : Closed e2389646079214 ∧ code e2389646079214 = 11185739101422 := by decide
theorem cert_e2389646079214 : check e2389646079214 [[],[.left]] .chain = true := by decide
def e2389646079222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2389646079222 : Closed e2389646079222 ∧ code e2389646079222 = 11185739101430 := by decide
theorem cert_e2389646079222 : check e2389646079222 [[],[.left]] .chain = true := by decide
def e2389646079598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389646079598 : Closed e2389646079598 ∧ code e2389646079598 = 11185739101806 := by decide
theorem cert_e2389646079598 : check e2389646079598 [[],[.left]] .chain = true := by decide
def e2389646079610 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389646079610 : Closed e2389646079610 ∧ code e2389646079610 = 11185739101818 := by decide
theorem cert_e2389646079610 : check e2389646079610 [[],[.left]] .chain = true := by decide
def e2389646079798 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389646079798 : Closed e2389646079798 ∧ code e2389646079798 = 11185739102006 := by decide
theorem cert_e2389646079798 : check e2389646079798 [[],[.left]] .chain = true := by decide
def e2389646079802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389646079802 : Closed e2389646079802 ∧ code e2389646079802 = 11185739102010 := by decide
theorem cert_e2389646079802 : check e2389646079802 [[],[.left]] .chain = true := by decide
def e2389646080438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2389646080438 : Closed e2389646080438 ∧ code e2389646080438 = 11185739102646 := by decide
theorem cert_e2389646080438 : check e2389646080438 [[],[.left]] .chain = true := by decide
def e2389646080470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2389646080470 : Closed e2389646080470 ∧ code e2389646080470 = 11185739102678 := by decide
theorem cert_e2389646080470 : check e2389646080470 [[],[.left]] .chain = true := by decide
def e2389646080474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2389646080474 : Closed e2389646080474 ∧ code e2389646080474 = 11185739102682 := by decide
theorem cert_e2389646080474 : check e2389646080474 [[],[.left]] .chain = true := by decide
def e2389646080630 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2389646080630 : Closed e2389646080630 ∧ code e2389646080630 = 11185739102838 := by decide
theorem cert_e2389646080630 : check e2389646080630 [[],[.left]] .chain = true := by decide
def e2389646080822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389646080822 : Closed e2389646080822 ∧ code e2389646080822 = 11185739103030 := by decide
theorem cert_e2389646080822 : check e2389646080822 [[],[.left]] .chain = true := by decide
def e2389646080826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389646080826 : Closed e2389646080826 ∧ code e2389646080826 = 11185739103034 := by decide
theorem cert_e2389646080826 : check e2389646080826 [[],[.left]] .chain = true := by decide
def e2389646088046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2389646088046 : Closed e2389646088046 ∧ code e2389646088046 = 11185739110254 := by decide
theorem cert_e2389646088046 : check e2389646088046 [[],[.left]] .chain = true := by decide
def e2389646088054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2389646088054 : Closed e2389646088054 ∧ code e2389646088054 = 11185739110262 := by decide
theorem cert_e2389646088054 : check e2389646088054 [[],[.left]] .chain = true := by decide
def e2389646088118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2389646088118 : Closed e2389646088118 ∧ code e2389646088118 = 11185739110326 := by decide
theorem cert_e2389646088118 : check e2389646088118 [[],[.left]] .chain = true := by decide
def e2389646089454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2389646089454 : Closed e2389646089454 ∧ code e2389646089454 = 11185739111662 := by decide
theorem cert_e2389646089454 : check e2389646089454 [[],[.left]] .chain = true := by decide
def e2389646089462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2389646089462 : Closed e2389646089462 ∧ code e2389646089462 = 11185739111670 := by decide
theorem cert_e2389646089462 : check e2389646089462 [[],[.left]] .chain = true := by decide
def e2389646089846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2389646089846 : Closed e2389646089846 ∧ code e2389646089846 = 11185739112054 := by decide
theorem cert_e2389646089846 : check e2389646089846 [[],[.left]] .chain = true := by decide
def e2389646101358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389646101358 : Closed e2389646101358 ∧ code e2389646101358 = 11185739123566 := by decide
theorem cert_e2389646101358 : check e2389646101358 [[],[.left]] .chain = true := by decide
def e2389646101366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389646101366 : Closed e2389646101366 ∧ code e2389646101366 = 11185739123574 := by decide
theorem cert_e2389646101366 : check e2389646101366 [[],[.left]] .chain = true := by decide
def e2389646101422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389646101422 : Closed e2389646101422 ∧ code e2389646101422 = 11185739123630 := by decide
theorem cert_e2389646101422 : check e2389646101422 [[],[.left]] .chain = true := by decide
def e2389646101434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389646101434 : Closed e2389646101434 ∧ code e2389646101434 = 11185739123642 := by decide
theorem cert_e2389646101434 : check e2389646101434 [[],[.left]] .chain = true := by decide
def e2389646101462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389646101462 : Closed e2389646101462 ∧ code e2389646101462 = 11185739123670 := by decide
theorem cert_e2389646101462 : check e2389646101462 [[],[.left]] .chain = true := by decide
def e2389646101466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389646101466 : Closed e2389646101466 ∧ code e2389646101466 = 11185739123674 := by decide
theorem cert_e2389646101466 : check e2389646101466 [[],[.left]] .chain = true := by decide
def e2389646101742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389646101742 : Closed e2389646101742 ∧ code e2389646101742 = 11185739123950 := by decide
theorem cert_e2389646101742 : check e2389646101742 [[],[.left]] .chain = true := by decide
def e2389646101750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389646101750 : Closed e2389646101750 ∧ code e2389646101750 = 11185739123958 := by decide
theorem cert_e2389646101750 : check e2389646101750 [[],[.left]] .chain = true := by decide
def e2389646102126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389646102126 : Closed e2389646102126 ∧ code e2389646102126 = 11185739124334 := by decide
theorem cert_e2389646102126 : check e2389646102126 [[],[.left]] .chain = true := by decide
def e2389646102138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389646102138 : Closed e2389646102138 ∧ code e2389646102138 = 11185739124346 := by decide
theorem cert_e2389646102138 : check e2389646102138 [[],[.left]] .chain = true := by decide
def e2389646102326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389646102326 : Closed e2389646102326 ∧ code e2389646102326 = 11185739124534 := by decide
theorem cert_e2389646102326 : check e2389646102326 [[],[.left]] .chain = true := by decide
def e2389646102330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389646102330 : Closed e2389646102330 ∧ code e2389646102330 = 11185739124538 := by decide
theorem cert_e2389646102330 : check e2389646102330 [[],[.left]] .chain = true := by decide
def e2389646108086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2389646108086 : Closed e2389646108086 ∧ code e2389646108086 = 11185739130294 := by decide
theorem cert_e2389646108086 : check e2389646108086 [[],[.left]] .chain = true := by decide
def e2389646108118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2389646108118 : Closed e2389646108118 ∧ code e2389646108118 = 11185739130326 := by decide
theorem cert_e2389646108118 : check e2389646108118 [[],[.left]] .chain = true := by decide
def e2389646108122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2389646108122 : Closed e2389646108122 ∧ code e2389646108122 = 11185739130330 := by decide
theorem cert_e2389646108122 : check e2389646108122 [[],[.left]] .chain = true := by decide
def e2389646108278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2389646108278 : Closed e2389646108278 ∧ code e2389646108278 = 11185739130486 := by decide
theorem cert_e2389646108278 : check e2389646108278 [[],[.left]] .chain = true := by decide
def e2389646108470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2389646108470 : Closed e2389646108470 ∧ code e2389646108470 = 11185739130678 := by decide
theorem cert_e2389646108470 : check e2389646108470 [[],[.left]] .chain = true := by decide
def e2389646108474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2389646108474 : Closed e2389646108474 ∧ code e2389646108474 = 11185739130682 := by decide
theorem cert_e2389646108474 : check e2389646108474 [[],[.left]] .chain = true := by decide
def e2389646445422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389646445422 : Closed e2389646445422 ∧ code e2389646445422 = 11185739467630 := by decide
theorem cert_e2389646445422 : check e2389646445422 [[],[.left],[],[]] .smaller = true := by decide
def e2389646445430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389646445430 : Closed e2389646445430 ∧ code e2389646445430 = 11185739467638 := by decide
theorem cert_e2389646445430 : check e2389646445430 [[],[.left],[],[]] .smaller = true := by decide
def e2389646445486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389646445486 : Closed e2389646445486 ∧ code e2389646445486 = 11185739467694 := by decide
theorem cert_e2389646445486 : check e2389646445486 [[],[.left],[],[]] .smaller = true := by decide
def e2389646445498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389646445498 : Closed e2389646445498 ∧ code e2389646445498 = 11185739467706 := by decide
theorem cert_e2389646445498 : check e2389646445498 [[],[.left],[],[]] .smaller = true := by decide
def e2389646445526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389646445526 : Closed e2389646445526 ∧ code e2389646445526 = 11185739467734 := by decide
theorem cert_e2389646445526 : check e2389646445526 [[],[.left],[],[]] .smaller = true := by decide
def e2389646445530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389646445530 : Closed e2389646445530 ∧ code e2389646445530 = 11185739467738 := by decide
theorem cert_e2389646445530 : check e2389646445530 [[],[.left],[],[]] .smaller = true := by decide
def e2389646445806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389646445806 : Closed e2389646445806 ∧ code e2389646445806 = 11185739468014 := by decide
theorem cert_e2389646445806 : check e2389646445806 [[],[.left],[],[]] .smaller = true := by decide
def e2389646445814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389646445814 : Closed e2389646445814 ∧ code e2389646445814 = 11185739468022 := by decide
theorem cert_e2389646445814 : check e2389646445814 [[],[.left],[],[]] .smaller = true := by decide
def e2389646446190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389646446190 : Closed e2389646446190 ∧ code e2389646446190 = 11185739468398 := by decide
theorem cert_e2389646446190 : check e2389646446190 [[],[.left],[],[]] .smaller = true := by decide
def e2389646446202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389646446202 : Closed e2389646446202 ∧ code e2389646446202 = 11185739468410 := by decide
theorem cert_e2389646446202 : check e2389646446202 [[],[.left],[],[]] .smaller = true := by decide
def e2389646446390 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389646446390 : Closed e2389646446390 ∧ code e2389646446390 = 11185739468598 := by decide
theorem cert_e2389646446390 : check e2389646446390 [[],[.left],[],[]] .smaller = true := by decide
def e2389646446394 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389646446394 : Closed e2389646446394 ∧ code e2389646446394 = 11185739468602 := by decide
theorem cert_e2389646446394 : check e2389646446394 [[],[.left],[],[]] .smaller = true := by decide
def e2389662805358 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2389662805358 : Closed e2389662805358 ∧ code e2389662805358 = 11185755827566 := by decide
theorem cert_e2389662805358 : check e2389662805358 [[],[.left],[]] .sourceHead = true := by decide
def e2389662805366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2389662805366 : Closed e2389662805366 ∧ code e2389662805366 = 11185755827574 := by decide
theorem cert_e2389662805366 : check e2389662805366 [[],[.left],[]] .sourceHead = true := by decide
def e2389662805422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2389662805422 : Closed e2389662805422 ∧ code e2389662805422 = 11185755827630 := by decide
theorem cert_e2389662805422 : check e2389662805422 [[],[.left],[]] .sourceHead = true := by decide
def e2389662805434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2389662805434 : Closed e2389662805434 ∧ code e2389662805434 = 11185755827642 := by decide
theorem cert_e2389662805434 : check e2389662805434 [[],[.left],[]] .sourceHead = true := by decide
def e2389662805462 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2389662805462 : Closed e2389662805462 ∧ code e2389662805462 = 11185755827670 := by decide
theorem cert_e2389662805462 : check e2389662805462 [[],[.left],[]] .sourceHead = true := by decide
def e2389662805466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2389662805466 : Closed e2389662805466 ∧ code e2389662805466 = 11185755827674 := by decide
theorem cert_e2389662805466 : check e2389662805466 [[],[.left],[]] .sourceHead = true := by decide
def e2389662805678 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2389662805678 : Closed e2389662805678 ∧ code e2389662805678 = 11185755827886 := by decide
theorem cert_e2389662805678 : check e2389662805678 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2389662805690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2389662805690 : Closed e2389662805690 ∧ code e2389662805690 = 11185755827898 := by decide
theorem cert_e2389662805690 : check e2389662805690 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389662805738 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2389662805738 : Closed e2389662805738 ∧ code e2389662805738 = 11185755827946 := by decide
theorem cert_e2389662805738 : check e2389662805738 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2389662805846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2389662805846 : Closed e2389662805846 ∧ code e2389662805846 = 11185755828054 := by decide
theorem cert_e2389662805846 : check e2389662805846 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2389662805850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2389662805850 : Closed e2389662805850 ∧ code e2389662805850 = 11185755828058 := by decide
theorem cert_e2389662805850 : check e2389662805850 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2389662805866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2389662805866 : Closed e2389662805866 ∧ code e2389662805866 = 11185755828074 := by decide
theorem cert_e2389662805866 : check e2389662805866 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2389662806894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2389662806894 : Closed e2389662806894 ∧ code e2389662806894 = 11185755829102 := by decide
theorem cert_e2389662806894 : check e2389662806894 [[],[.left],[]] .sourceHead = true := by decide
def e2389662806902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2389662806902 : Closed e2389662806902 ∧ code e2389662806902 = 11185755829110 := by decide
theorem cert_e2389662806902 : check e2389662806902 [[],[.left],[]] .sourceHead = true := by decide
def e2389662806958 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2389662806958 : Closed e2389662806958 ∧ code e2389662806958 = 11185755829166 := by decide
theorem cert_e2389662806958 : check e2389662806958 [[],[.left],[]] .sourceHead = true := by decide
def e2389662806970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2389662806970 : Closed e2389662806970 ∧ code e2389662806970 = 11185755829178 := by decide
theorem cert_e2389662806970 : check e2389662806970 [[],[.left],[]] .sourceHead = true := by decide
def e2389662806998 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2389662806998 : Closed e2389662806998 ∧ code e2389662806998 = 11185755829206 := by decide
theorem cert_e2389662806998 : check e2389662806998 [[],[.left],[]] .sourceHead = true := by decide
def e2389662807002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2389662807002 : Closed e2389662807002 ∧ code e2389662807002 = 11185755829210 := by decide
theorem cert_e2389662807002 : check e2389662807002 [[],[.left],[]] .sourceHead = true := by decide
def e2389662807278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2389662807278 : Closed e2389662807278 ∧ code e2389662807278 = 11185755829486 := by decide
theorem cert_e2389662807278 : check e2389662807278 [[],[.left],[]] .sourceHead = true := by decide
def e2389662807286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2389662807286 : Closed e2389662807286 ∧ code e2389662807286 = 11185755829494 := by decide
theorem cert_e2389662807286 : check e2389662807286 [[],[.left],[]] .sourceHead = true := by decide
def e2389662807662 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389662807662 : Closed e2389662807662 ∧ code e2389662807662 = 11185755829870 := by decide
theorem cert_e2389662807662 : check e2389662807662 [[],[.left],[]] .sourceHead = true := by decide
def e2389662807674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389662807674 : Closed e2389662807674 ∧ code e2389662807674 = 11185755829882 := by decide
theorem cert_e2389662807674 : check e2389662807674 [[],[.left],[]] .sourceHead = true := by decide
def e2389662807862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389662807862 : Closed e2389662807862 ∧ code e2389662807862 = 11185755830070 := by decide
theorem cert_e2389662807862 : check e2389662807862 [[],[.left],[]] .sourceHead = true := by decide
def e2389662807866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389662807866 : Closed e2389662807866 ∧ code e2389662807866 = 11185755830074 := by decide
theorem cert_e2389662807866 : check e2389662807866 [[],[.left],[]] .sourceHead = true := by decide
def e2389662808494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2389662808494 : Closed e2389662808494 ∧ code e2389662808494 = 11185755830702 := by decide
theorem cert_e2389662808494 : check e2389662808494 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389662808506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2389662808506 : Closed e2389662808506 ∧ code e2389662808506 = 11185755830714 := by decide
theorem cert_e2389662808506 : check e2389662808506 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389662808554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2389662808554 : Closed e2389662808554 ∧ code e2389662808554 = 11185755830762 := by decide
theorem cert_e2389662808554 : check e2389662808554 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389662808686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2389662808686 : Closed e2389662808686 ∧ code e2389662808686 = 11185755830894 := by decide
theorem cert_e2389662808686 : check e2389662808686 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389662808698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2389662808698 : Closed e2389662808698 ∧ code e2389662808698 = 11185755830906 := by decide
theorem cert_e2389662808698 : check e2389662808698 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389662808986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389662808986 : Closed e2389662808986 ∧ code e2389662808986 = 11185755831194 := by decide
theorem cert_e2389662808986 : check e2389662808986 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389662809302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2389662809302 : Closed e2389662809302 ∧ code e2389662809302 = 11185755831510 := by decide
theorem cert_e2389662809302 : check e2389662809302 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389662809306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2389662809306 : Closed e2389662809306 ∧ code e2389662809306 = 11185755831514 := by decide
theorem cert_e2389662809306 : check e2389662809306 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389662809322 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2389662809322 : Closed e2389662809322 ∧ code e2389662809322 = 11185755831530 := by decide
theorem cert_e2389662809322 : check e2389662809322 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389662809398 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2389662809398 : Closed e2389662809398 ∧ code e2389662809398 = 11185755831606 := by decide
theorem cert_e2389662809398 : check e2389662809398 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389662809402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2389662809402 : Closed e2389662809402 ∧ code e2389662809402 = 11185755831610 := by decide
theorem cert_e2389662809402 : check e2389662809402 [[],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2389662809498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2389662809498 : Closed e2389662809498 ∧ code e2389662809498 = 11185755831706 := by decide
theorem cert_e2389662809498 : check e2389662809498 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2389662813038 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389662813038 : Closed e2389662813038 ∧ code e2389662813038 = 11185755835246 := by decide
theorem cert_e2389662813038 : check e2389662813038 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389662813046 : Closed e2389662813046 ∧ code e2389662813046 = 11185755835254 := by decide
theorem cert_e2389662813046 : check e2389662813046 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389662813102 : Closed e2389662813102 ∧ code e2389662813102 = 11185755835310 := by decide
theorem cert_e2389662813102 : check e2389662813102 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389662813114 : Closed e2389662813114 ∧ code e2389662813114 = 11185755835322 := by decide
theorem cert_e2389662813114 : check e2389662813114 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389662813142 : Closed e2389662813142 ∧ code e2389662813142 = 11185755835350 := by decide
theorem cert_e2389662813142 : check e2389662813142 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389662813146 : Closed e2389662813146 ∧ code e2389662813146 = 11185755835354 := by decide
theorem cert_e2389662813146 : check e2389662813146 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389662813422 : Closed e2389662813422 ∧ code e2389662813422 = 11185755835630 := by decide
theorem cert_e2389662813422 : check e2389662813422 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813430 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389662813430 : Closed e2389662813430 ∧ code e2389662813430 = 11185755835638 := by decide
theorem cert_e2389662813430 : check e2389662813430 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389662813806 : Closed e2389662813806 ∧ code e2389662813806 = 11185755836014 := by decide
theorem cert_e2389662813806 : check e2389662813806 [[],[.left],[]] .sourceHead = true := by decide
def e2389662813818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389662813818 : Closed e2389662813818 ∧ code e2389662813818 = 11185755836026 := by decide
theorem cert_e2389662813818 : check e2389662813818 [[],[.left],[]] .sourceHead = true := by decide
def e2389662814006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389662814006 : Closed e2389662814006 ∧ code e2389662814006 = 11185755836214 := by decide
theorem cert_e2389662814006 : check e2389662814006 [[],[.left],[]] .sourceHead = true := by decide
def e2389662814010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389662814010 : Closed e2389662814010 ∧ code e2389662814010 = 11185755836218 := by decide
theorem cert_e2389662814010 : check e2389662814010 [[],[.left],[]] .sourceHead = true := by decide
def e2389662819758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2389662819758 : Closed e2389662819758 ∧ code e2389662819758 = 11185755841966 := by decide
theorem cert_e2389662819758 : check e2389662819758 [[],[.left],[],[.under]] .smaller = true := by decide
def e2389662819770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2389662819770 : Closed e2389662819770 ∧ code e2389662819770 = 11185755841978 := by decide
theorem cert_e2389662819770 : check e2389662819770 [[],[.left],[],[.under]] .smaller = true := by decide
end Blc.Floor43
