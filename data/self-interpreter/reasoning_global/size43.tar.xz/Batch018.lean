import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604919663854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e604919663854 : Closed e604919663854 ∧ code e604919663854 = 9401012686062 := by decide
theorem cert_e604919663854 : check e604919663854 [[.under],[.under]] .three = true := by decide
def e604919663862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e604919663862 : Closed e604919663862 ∧ code e604919663862 = 9401012686070 := by decide
theorem cert_e604919663862 : check e604919663862 [[.under],[.under]] .three = true := by decide
def e604919664238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e604919664238 : Closed e604919664238 ∧ code e604919664238 = 9401012686446 := by decide
theorem cert_e604919664238 : check e604919664238 [[.under],[.under]] .three = true := by decide
def e604919664250 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e604919664250 : Closed e604919664250 ∧ code e604919664250 = 9401012686458 := by decide
theorem cert_e604919664250 : check e604919664250 [[.under],[.under]] .three = true := by decide
def e604919664438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e604919664438 : Closed e604919664438 ∧ code e604919664438 = 9401012686646 := by decide
theorem cert_e604919664438 : check e604919664438 [[.under],[.under]] .three = true := by decide
def e604919664442 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e604919664442 : Closed e604919664442 ∧ code e604919664442 = 9401012686650 := by decide
theorem cert_e604919664442 : check e604919664442 [[.under],[.under]] .three = true := by decide
def e604919666926 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e604919666926 : Closed e604919666926 ∧ code e604919666926 = 9401012689134 := by decide
theorem cert_e604919666926 : check e604919666926 [[.under],[.under]] .three = true := by decide
def e604919666934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e604919666934 : Closed e604919666934 ∧ code e604919666934 = 9401012689142 := by decide
theorem cert_e604919666934 : check e604919666934 [[.under],[.under]] .three = true := by decide
def e604919667486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e604919667486 : Closed e604919667486 ∧ code e604919667486 = 9401012689694 := by decide
theorem cert_e604919667486 : check e604919667486 [[.under],[.under]] .three = true := by decide
def e604919667598 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e604919667598 : Closed e604919667598 ∧ code e604919667598 = 9401012689806 := by decide
theorem cert_e604919667598 : check e604919667598 [[.under],[.under]] .three = true := by decide
def e604919667822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e604919667822 : Closed e604919667822 ∧ code e604919667822 = 9401012690030 := by decide
theorem cert_e604919667822 : check e604919667822 [[.under],[.under]] .three = true := by decide
def e604919667834 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e604919667834 : Closed e604919667834 ∧ code e604919667834 = 9401012690042 := by decide
theorem cert_e604919667834 : check e604919667834 [[.under],[.under]] .three = true := by decide
def e604919667998 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e604919667998 : Closed e604919667998 ∧ code e604919667998 = 9401012690206 := by decide
theorem cert_e604919667998 : check e604919667998 [[.under],[.under]] .three = true := by decide
def e604919668166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e604919668166 : Closed e604919668166 ∧ code e604919668166 = 9401012690374 := by decide
theorem cert_e604919668166 : check e604919668166 [[.under],[.under]] .three = true := by decide
def e604919668278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e604919668278 : Closed e604919668278 ∧ code e604919668278 = 9401012690486 := by decide
theorem cert_e604919668278 : check e604919668278 [[.under],[.under]] .three = true := by decide
def e604919668282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e604919668282 : Closed e604919668282 ∧ code e604919668282 = 9401012690490 := by decide
theorem cert_e604919668282 : check e604919668282 [[.under],[.under]] .three = true := by decide
def e604919668366 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e604919668366 : Closed e604919668366 ∧ code e604919668366 = 9401012690574 := by decide
theorem cert_e604919668366 : check e604919668366 [[.under],[.under]] .three = true := by decide
def e604919668422 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e604919668422 : Closed e604919668422 ∧ code e604919668422 = 9401012690630 := by decide
theorem cert_e604919668422 : check e604919668422 [[.under],[.under]] .three = true := by decide
def e604919670558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e604919670558 : Closed e604919670558 ∧ code e604919670558 = 9401012692766 := by decide
theorem cert_e604919670558 : check e604919670558 [[.under],[.under]] .three = true := by decide
def e604919670670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e604919670670 : Closed e604919670670 ∧ code e604919670670 = 9401012692878 := by decide
theorem cert_e604919670670 : check e604919670670 [[.under],[.under]] .three = true := by decide
def e604919673630 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e604919673630 : Closed e604919673630 ∧ code e604919673630 = 9401012695838 := by decide
theorem cert_e604919673630 : check e604919673630 [[.under],[.under]] .three = true := by decide
def e604919673798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e604919673798 : Closed e604919673798 ∧ code e604919673798 = 9401012696006 := by decide
theorem cert_e604919673798 : check e604919673798 [[.under],[.under]] .three = true := by decide
def e604919675278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e604919675278 : Closed e604919675278 ∧ code e604919675278 = 9401012697486 := by decide
theorem cert_e604919675278 : check e604919675278 [[.under],[.under]] .three = true := by decide
def e604919675334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e604919675334 : Closed e604919675334 ∧ code e604919675334 = 9401012697542 := by decide
theorem cert_e604919675334 : check e604919675334 [[.under],[.under]] .three = true := by decide
def e604919678574 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e604919678574 : Closed e604919678574 ∧ code e604919678574 = 9401012700782 := by decide
theorem cert_e604919678574 : check e604919678574 [[.under],[.under]] .three = true := by decide
def e604919678586 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e604919678586 : Closed e604919678586 ∧ code e604919678586 = 9401012700794 := by decide
theorem cert_e604919678586 : check e604919678586 [[.under],[.under]] .three = true := by decide
def e604919678874 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e604919678874 : Closed e604919678874 ∧ code e604919678874 = 9401012701082 := by decide
theorem cert_e604919678874 : check e604919678874 [[.under],[.under]] .three = true := by decide
def e604919680110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e604919680110 : Closed e604919680110 ∧ code e604919680110 = 9401012702318 := by decide
theorem cert_e604919680110 : check e604919680110 [[.under],[.under]] .three = true := by decide
def e604919680122 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e604919680122 : Closed e604919680122 ∧ code e604919680122 = 9401012702330 := by decide
theorem cert_e604919680122 : check e604919680122 [[.under],[.under]] .three = true := by decide
def e604919680286 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e604919680286 : Closed e604919680286 ∧ code e604919680286 = 9401012702494 := by decide
theorem cert_e604919680286 : check e604919680286 [[.under],[.under]] .three = true := by decide
def e604919680454 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e604919680454 : Closed e604919680454 ∧ code e604919680454 = 9401012702662 := by decide
theorem cert_e604919680454 : check e604919680454 [[.under],[.under]] .three = true := by decide
def e604919680794 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e604919680794 : Closed e604919680794 ∧ code e604919680794 = 9401012703002 := by decide
theorem cert_e604919680794 : check e604919680794 [[.under],[.under]] .three = true := by decide
def e604919680838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e604919680838 : Closed e604919680838 ∧ code e604919680838 = 9401012703046 := by decide
theorem cert_e604919680838 : check e604919680838 [[.under],[.under]] .three = true := by decide
def e604919681822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e604919681822 : Closed e604919681822 ∧ code e604919681822 = 9401012704030 := by decide
theorem cert_e604919681822 : check e604919681822 [[.under],[.under]] .three = true := by decide
def e604919681990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e604919681990 : Closed e604919681990 ∧ code e604919681990 = 9401012704198 := by decide
theorem cert_e604919681990 : check e604919681990 [[.under],[.under]] .three = true := by decide
def e604919684294 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e604919684294 : Closed e604919684294 ∧ code e604919684294 = 9401012706502 := by decide
theorem cert_e604919684294 : check e604919684294 [[.under],[.under]] .three = true := by decide
def e604919685942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e604919685942 : Closed e604919685942 ∧ code e604919685942 = 9401012708150 := by decide
theorem cert_e604919685942 : check e604919685942 [[.under],[.under]] .three = true := by decide
def e604919685946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e604919685946 : Closed e604919685946 ∧ code e604919685946 = 9401012708154 := by decide
theorem cert_e604919685946 : check e604919685946 [[.under],[.under]] .three = true := by decide
def e604919686042 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e604919686042 : Closed e604919686042 ∧ code e604919686042 = 9401012708250 := by decide
theorem cert_e604919686042 : check e604919686042 [[.under],[.under]] .three = true := by decide
def e604919686710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e604919686710 : Closed e604919686710 ∧ code e604919686710 = 9401012708918 := by decide
theorem cert_e604919686710 : check e604919686710 [[.under],[.under]] .three = true := by decide
def e604919686714 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e604919686714 : Closed e604919686714 ∧ code e604919686714 = 9401012708922 := by decide
theorem cert_e604919686714 : check e604919686714 [[.under],[.under]] .three = true := by decide
def e604919686798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e604919686798 : Closed e604919686798 ∧ code e604919686798 = 9401012709006 := by decide
theorem cert_e604919686798 : check e604919686798 [[.under],[.under]] .three = true := by decide
def e604919686854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e604919686854 : Closed e604919686854 ∧ code e604919686854 = 9401012709062 := by decide
theorem cert_e604919686854 : check e604919686854 [[.under],[.under]] .three = true := by decide
def e604919686938 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e604919686938 : Closed e604919686938 ∧ code e604919686938 = 9401012709146 := by decide
theorem cert_e604919686938 : check e604919686938 [[.under],[.under]] .three = true := by decide
def e604919686982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e604919686982 : Closed e604919686982 ∧ code e604919686982 = 9401012709190 := by decide
theorem cert_e604919686982 : check e604919686982 [[.under],[.under]] .three = true := by decide
def e604919687566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e604919687566 : Closed e604919687566 ∧ code e604919687566 = 9401012709774 := by decide
theorem cert_e604919687566 : check e604919687566 [[.under],[.under]] .three = true := by decide
def e604919687622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e604919687622 : Closed e604919687622 ∧ code e604919687622 = 9401012709830 := by decide
theorem cert_e604919687622 : check e604919687622 [[.under],[.under]] .three = true := by decide
def e604919688390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e604919688390 : Closed e604919688390 ∧ code e604919688390 = 9401012710598 := by decide
theorem cert_e604919688390 : check e604919688390 [[.under],[.under]] .three = true := by decide
def e604919699166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e604919699166 : Closed e604919699166 ∧ code e604919699166 = 9401012721374 := by decide
theorem cert_e604919699166 : check e604919699166 [[.under],[.under]] .three = true := by decide
def e604919699190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e604919699190 : Closed e604919699190 ∧ code e604919699190 = 9401012721398 := by decide
theorem cert_e604919699190 : check e604919699190 [[.under],[.under]] .three = true := by decide
def e604919699294 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e604919699294 : Closed e604919699294 ∧ code e604919699294 = 9401012721502 := by decide
theorem cert_e604919699294 : check e604919699294 [[.under],[.under]] .three = true := by decide
def e604919699322 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e604919699322 : Closed e604919699322 ∧ code e604919699322 = 9401012721530 := by decide
theorem cert_e604919699322 : check e604919699322 [[.under],[.under]] .three = true := by decide
def e604919699414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e604919699414 : Closed e604919699414 ∧ code e604919699414 = 9401012721622 := by decide
theorem cert_e604919699414 : check e604919699414 [[.under],[.under]] .three = true := by decide
def e604919699418 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e604919699418 : Closed e604919699418 ∧ code e604919699418 = 9401012721626 := by decide
theorem cert_e604919699418 : check e604919699418 [[.under],[.under]] .three = true := by decide
def e604919699934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e604919699934 : Closed e604919699934 ∧ code e604919699934 = 9401012722142 := by decide
theorem cert_e604919699934 : check e604919699934 [[.under],[.under]] .three = true := by decide
def e604919699958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e604919699958 : Closed e604919699958 ∧ code e604919699958 = 9401012722166 := by decide
theorem cert_e604919699958 : check e604919699958 [[.under],[.under]] .three = true := by decide
def e604919700702 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e604919700702 : Closed e604919700702 ∧ code e604919700702 = 9401012722910 := by decide
theorem cert_e604919700702 : check e604919700702 [[.under],[.under]] .three = true := by decide
def e604919700730 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e604919700730 : Closed e604919700730 ∧ code e604919700730 = 9401012722938 := by decide
theorem cert_e604919700730 : check e604919700730 [[.under],[.under]] .three = true := by decide
def e604919701302 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e604919701302 : Closed e604919701302 ∧ code e604919701302 = 9401012723510 := by decide
theorem cert_e604919701302 : check e604919701302 [[.under],[.under]] .three = true := by decide
def e604919701306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e604919701306 : Closed e604919701306 ∧ code e604919701306 = 9401012723514 := by decide
theorem cert_e604919701306 : check e604919701306 [[.under],[.under]] .three = true := by decide
def e604919716078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e604919716078 : Closed e604919716078 ∧ code e604919716078 = 9401012738286 := by decide
theorem cert_e604919716078 : check e604919716078 [[.under],[.under]] .three = true := by decide
def e604919716086 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e604919716086 : Closed e604919716086 ∧ code e604919716086 = 9401012738294 := by decide
theorem cert_e604919716086 : check e604919716086 [[.under],[.under]] .three = true := by decide
def e604919716638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e604919716638 : Closed e604919716638 ∧ code e604919716638 = 9401012738846 := by decide
theorem cert_e604919716638 : check e604919716638 [[.under],[.under]] .three = true := by decide
def e604919716750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e604919716750 : Closed e604919716750 ∧ code e604919716750 = 9401012738958 := by decide
theorem cert_e604919716750 : check e604919716750 [[.under],[.under]] .three = true := by decide
def e604919716974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e604919716974 : Closed e604919716974 ∧ code e604919716974 = 9401012739182 := by decide
theorem cert_e604919716974 : check e604919716974 [[.under],[.under]] .three = true := by decide
def e604919716986 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e604919716986 : Closed e604919716986 ∧ code e604919716986 = 9401012739194 := by decide
theorem cert_e604919716986 : check e604919716986 [[.under],[.under]] .three = true := by decide
def e604919717150 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e604919717150 : Closed e604919717150 ∧ code e604919717150 = 9401012739358 := by decide
theorem cert_e604919717150 : check e604919717150 [[.under],[.under]] .three = true := by decide
def e604919717318 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e604919717318 : Closed e604919717318 ∧ code e604919717318 = 9401012739526 := by decide
theorem cert_e604919717318 : check e604919717318 [[.under],[.under]] .three = true := by decide
def e604919717430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e604919717430 : Closed e604919717430 ∧ code e604919717430 = 9401012739638 := by decide
theorem cert_e604919717430 : check e604919717430 [[.under],[.under]] .three = true := by decide
def e604919717434 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e604919717434 : Closed e604919717434 ∧ code e604919717434 = 9401012739642 := by decide
theorem cert_e604919717434 : check e604919717434 [[.under],[.under]] .three = true := by decide
def e604919717518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e604919717518 : Closed e604919717518 ∧ code e604919717518 = 9401012739726 := by decide
theorem cert_e604919717518 : check e604919717518 [[.under],[.under]] .three = true := by decide
def e604919717574 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e604919717574 : Closed e604919717574 ∧ code e604919717574 = 9401012739782 := by decide
theorem cert_e604919717574 : check e604919717574 [[.under],[.under]] .three = true := by decide
def e604919719710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e604919719710 : Closed e604919719710 ∧ code e604919719710 = 9401012741918 := by decide
theorem cert_e604919719710 : check e604919719710 [[.under],[.under]] .three = true := by decide
def e604919719822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e604919719822 : Closed e604919719822 ∧ code e604919719822 = 9401012742030 := by decide
theorem cert_e604919719822 : check e604919719822 [[.under],[.under]] .three = true := by decide
def e604919722782 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e604919722782 : Closed e604919722782 ∧ code e604919722782 = 9401012744990 := by decide
theorem cert_e604919722782 : check e604919722782 [[.under],[.under]] .three = true := by decide
def e604919722950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e604919722950 : Closed e604919722950 ∧ code e604919722950 = 9401012745158 := by decide
theorem cert_e604919722950 : check e604919722950 [[.under],[.under]] .three = true := by decide
def e604919724430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e604919724430 : Closed e604919724430 ∧ code e604919724430 = 9401012746638 := by decide
theorem cert_e604919724430 : check e604919724430 [[.under],[.under]] .three = true := by decide
def e604919724486 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e604919724486 : Closed e604919724486 ∧ code e604919724486 = 9401012746694 := by decide
theorem cert_e604919724486 : check e604919724486 [[.under],[.under]] .three = true := by decide
def e604919761774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604919761774 : Closed e604919761774 ∧ code e604919761774 = 9401012783982 := by decide
theorem cert_e604919761774 : check e604919761774 [[.under],[.under]] .smaller = true := by decide
def e604919761782 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604919761782 : Closed e604919761782 ∧ code e604919761782 = 9401012783990 := by decide
theorem cert_e604919761782 : check e604919761782 [[.under],[.under]] .smaller = true := by decide
def e604919761838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604919761838 : Closed e604919761838 ∧ code e604919761838 = 9401012784046 := by decide
theorem cert_e604919761838 : check e604919761838 [[.under],[.under]] .smaller = true := by decide
def e604919761850 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604919761850 : Closed e604919761850 ∧ code e604919761850 = 9401012784058 := by decide
theorem cert_e604919761850 : check e604919761850 [[.under],[.under]] .smaller = true := by decide
def e604919761878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604919761878 : Closed e604919761878 ∧ code e604919761878 = 9401012784086 := by decide
theorem cert_e604919761878 : check e604919761878 [[.under],[.under]] .smaller = true := by decide
def e604919761882 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604919761882 : Closed e604919761882 ∧ code e604919761882 = 9401012784090 := by decide
theorem cert_e604919761882 : check e604919761882 [[.under],[.under]] .smaller = true := by decide
def e604919762158 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604919762158 : Closed e604919762158 ∧ code e604919762158 = 9401012784366 := by decide
theorem cert_e604919762158 : check e604919762158 [[.under],[.under]] .smaller = true := by decide
def e604919762166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604919762166 : Closed e604919762166 ∧ code e604919762166 = 9401012784374 := by decide
theorem cert_e604919762166 : check e604919762166 [[.under],[.under]] .smaller = true := by decide
def e604919762542 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604919762542 : Closed e604919762542 ∧ code e604919762542 = 9401012784750 := by decide
theorem cert_e604919762542 : check e604919762542 [[.under],[.under]] .smaller = true := by decide
def e604919762554 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604919762554 : Closed e604919762554 ∧ code e604919762554 = 9401012784762 := by decide
theorem cert_e604919762554 : check e604919762554 [[.under],[.under]] .smaller = true := by decide
def e604919762742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604919762742 : Closed e604919762742 ∧ code e604919762742 = 9401012784950 := by decide
theorem cert_e604919762742 : check e604919762742 [[.under],[.under]] .smaller = true := by decide
def e604919762746 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604919762746 : Closed e604919762746 ∧ code e604919762746 = 9401012784954 := by decide
theorem cert_e604919762746 : check e604919762746 [[.under],[.under]] .smaller = true := by decide
def e604919770222 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e604919770222 : Closed e604919770222 ∧ code e604919770222 = 9401012792430 := by decide
theorem cert_e604919770222 : check e604919770222 [[.under],[.under]] .three = true := by decide
def e604919770234 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e604919770234 : Closed e604919770234 ∧ code e604919770234 = 9401012792442 := by decide
theorem cert_e604919770234 : check e604919770234 [[.under],[.under]] .three = true := by decide
def e604919770398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e604919770398 : Closed e604919770398 ∧ code e604919770398 = 9401012792606 := by decide
theorem cert_e604919770398 : check e604919770398 [[.under],[.under]] .three = true := by decide
def e604919770566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e604919770566 : Closed e604919770566 ∧ code e604919770566 = 9401012792774 := by decide
theorem cert_e604919770566 : check e604919770566 [[.under],[.under]] .three = true := by decide
def e604919770906 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e604919770906 : Closed e604919770906 ∧ code e604919770906 = 9401012793114 := by decide
theorem cert_e604919770906 : check e604919770906 [[.under],[.under]] .three = true := by decide
def e604919770950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e604919770950 : Closed e604919770950 ∧ code e604919770950 = 9401012793158 := by decide
theorem cert_e604919770950 : check e604919770950 [[.under],[.under]] .three = true := by decide
def e604919771934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e604919771934 : Closed e604919771934 ∧ code e604919771934 = 9401012794142 := by decide
theorem cert_e604919771934 : check e604919771934 [[.under],[.under]] .three = true := by decide
def e604919772102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e604919772102 : Closed e604919772102 ∧ code e604919772102 = 9401012794310 := by decide
theorem cert_e604919772102 : check e604919772102 [[.under],[.under]] .three = true := by decide
def e604919774406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e604919774406 : Closed e604919774406 ∧ code e604919774406 = 9401012796614 := by decide
theorem cert_e604919774406 : check e604919774406 [[.under],[.under]] .three = true := by decide
def e604919797302 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e604919797302 : Closed e604919797302 ∧ code e604919797302 = 9401012819510 := by decide
theorem cert_e604919797302 : check e604919797302 [[.under],[.under]] .three = true := by decide
def e604919797306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e604919797306 : Closed e604919797306 ∧ code e604919797306 = 9401012819514 := by decide
theorem cert_e604919797306 : check e604919797306 [[.under],[.under]] .three = true := by decide
def e604919797390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e604919797390 : Closed e604919797390 ∧ code e604919797390 = 9401012819598 := by decide
theorem cert_e604919797390 : check e604919797390 [[.under],[.under]] .three = true := by decide
def e604919797446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e604919797446 : Closed e604919797446 ∧ code e604919797446 = 9401012819654 := by decide
theorem cert_e604919797446 : check e604919797446 [[.under],[.under]] .three = true := by decide
def e604919797530 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e604919797530 : Closed e604919797530 ∧ code e604919797530 = 9401012819738 := by decide
theorem cert_e604919797530 : check e604919797530 [[.under],[.under]] .three = true := by decide
def e604919797574 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e604919797574 : Closed e604919797574 ∧ code e604919797574 = 9401012819782 := by decide
theorem cert_e604919797574 : check e604919797574 [[.under],[.under]] .three = true := by decide
def e604919798158 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e604919798158 : Closed e604919798158 ∧ code e604919798158 = 9401012820366 := by decide
theorem cert_e604919798158 : check e604919798158 [[.under],[.under]] .three = true := by decide
def e604919798214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e604919798214 : Closed e604919798214 ∧ code e604919798214 = 9401012820422 := by decide
theorem cert_e604919798214 : check e604919798214 [[.under],[.under]] .three = true := by decide
def e604919798982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e604919798982 : Closed e604919798982 ∧ code e604919798982 = 9401012821190 := by decide
theorem cert_e604919798982 : check e604919798982 [[.under],[.under]] .three = true := by decide
def e604920895726 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e604920895726 : Closed e604920895726 ∧ code e604920895726 = 9401013917934 := by decide
theorem cert_e604920895726 : check e604920895726 [[.under],[.under]] .chain = true := by decide
def e604920895734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e604920895734 : Closed e604920895734 ∧ code e604920895734 = 9401013917942 := by decide
theorem cert_e604920895734 : check e604920895734 [[.under],[.under]] .chain = true := by decide
def e604920896286 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e604920896286 : Closed e604920896286 ∧ code e604920896286 = 9401013918494 := by decide
theorem cert_e604920896286 : check e604920896286 [[.under],[.under]] .chain = true := by decide
def e604920896398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e604920896398 : Closed e604920896398 ∧ code e604920896398 = 9401013918606 := by decide
theorem cert_e604920896398 : check e604920896398 [[.under],[.under]] .chain = true := by decide
def e604920896622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e604920896622 : Closed e604920896622 ∧ code e604920896622 = 9401013918830 := by decide
theorem cert_e604920896622 : check e604920896622 [[.under],[.under]] .chain = true := by decide
def e604920896634 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e604920896634 : Closed e604920896634 ∧ code e604920896634 = 9401013918842 := by decide
theorem cert_e604920896634 : check e604920896634 [[.under],[.under]] .chain = true := by decide
def e604920896798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e604920896798 : Closed e604920896798 ∧ code e604920896798 = 9401013919006 := by decide
theorem cert_e604920896798 : check e604920896798 [[.under],[.under]] .chain = true := by decide
def e604920896966 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e604920896966 : Closed e604920896966 ∧ code e604920896966 = 9401013919174 := by decide
theorem cert_e604920896966 : check e604920896966 [[.under],[.under]] .chain = true := by decide
def e604920897078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e604920897078 : Closed e604920897078 ∧ code e604920897078 = 9401013919286 := by decide
theorem cert_e604920897078 : check e604920897078 [[.under],[.under]] .chain = true := by decide
def e604920897082 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e604920897082 : Closed e604920897082 ∧ code e604920897082 = 9401013919290 := by decide
theorem cert_e604920897082 : check e604920897082 [[.under],[.under]] .chain = true := by decide
def e604920897166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e604920897166 : Closed e604920897166 ∧ code e604920897166 = 9401013919374 := by decide
theorem cert_e604920897166 : check e604920897166 [[.under],[.under]] .chain = true := by decide
def e604920897222 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e604920897222 : Closed e604920897222 ∧ code e604920897222 = 9401013919430 := by decide
theorem cert_e604920897222 : check e604920897222 [[.under],[.under]] .chain = true := by decide
def e604920899358 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e604920899358 : Closed e604920899358 ∧ code e604920899358 = 9401013921566 := by decide
theorem cert_e604920899358 : check e604920899358 [[.under],[.under]] .chain = true := by decide
def e604920899470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e604920899470 : Closed e604920899470 ∧ code e604920899470 = 9401013921678 := by decide
theorem cert_e604920899470 : check e604920899470 [[.under],[.under]] .chain = true := by decide
def e604920902430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e604920902430 : Closed e604920902430 ∧ code e604920902430 = 9401013924638 := by decide
theorem cert_e604920902430 : check e604920902430 [[.under],[.under]] .chain = true := by decide
def e604920902598 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e604920902598 : Closed e604920902598 ∧ code e604920902598 = 9401013924806 := by decide
theorem cert_e604920902598 : check e604920902598 [[.under],[.under]] .chain = true := by decide
def e604920904078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e604920904078 : Closed e604920904078 ∧ code e604920904078 = 9401013926286 := by decide
theorem cert_e604920904078 : check e604920904078 [[.under],[.under]] .chain = true := by decide
def e604920904134 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e604920904134 : Closed e604920904134 ∧ code e604920904134 = 9401013926342 := by decide
theorem cert_e604920904134 : check e604920904134 [[.under],[.under]] .chain = true := by decide
def e604925597406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e604925597406 : Closed e604925597406 ∧ code e604925597406 = 9401018619614 := by decide
theorem cert_e604925597406 : check e604925597406 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925597430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e604925597430 : Closed e604925597430 ∧ code e604925597430 = 9401018619638 := by decide
theorem cert_e604925597430 : check e604925597430 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925597534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e604925597534 : Closed e604925597534 ∧ code e604925597534 = 9401018619742 := by decide
theorem cert_e604925597534 : check e604925597534 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925597562 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e604925597562 : Closed e604925597562 ∧ code e604925597562 = 9401018619770 := by decide
theorem cert_e604925597562 : check e604925597562 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925597654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e604925597654 : Closed e604925597654 ∧ code e604925597654 = 9401018619862 := by decide
theorem cert_e604925597654 : check e604925597654 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925597658 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e604925597658 : Closed e604925597658 ∧ code e604925597658 = 9401018619866 := by decide
theorem cert_e604925597658 : check e604925597658 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925598174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e604925598174 : Closed e604925598174 ∧ code e604925598174 = 9401018620382 := by decide
theorem cert_e604925598174 : check e604925598174 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925598198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e604925598198 : Closed e604925598198 ∧ code e604925598198 = 9401018620406 := by decide
theorem cert_e604925598198 : check e604925598198 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925598942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e604925598942 : Closed e604925598942 ∧ code e604925598942 = 9401018621150 := by decide
theorem cert_e604925598942 : check e604925598942 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925598970 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e604925598970 : Closed e604925598970 ∧ code e604925598970 = 9401018621178 := by decide
theorem cert_e604925598970 : check e604925598970 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925599542 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e604925599542 : Closed e604925599542 ∧ code e604925599542 = 9401018621750 := by decide
theorem cert_e604925599542 : check e604925599542 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925599546 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e604925599546 : Closed e604925599546 ∧ code e604925599546 = 9401018621754 := by decide
theorem cert_e604925599546 : check e604925599546 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925614318 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e604925614318 : Closed e604925614318 ∧ code e604925614318 = 9401018636526 := by decide
theorem cert_e604925614318 : check e604925614318 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925614326 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e604925614326 : Closed e604925614326 ∧ code e604925614326 = 9401018636534 := by decide
theorem cert_e604925614326 : check e604925614326 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925614878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e604925614878 : Closed e604925614878 ∧ code e604925614878 = 9401018637086 := by decide
theorem cert_e604925614878 : check e604925614878 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925614990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e604925614990 : Closed e604925614990 ∧ code e604925614990 = 9401018637198 := by decide
theorem cert_e604925614990 : check e604925614990 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e604925615214 : Closed e604925615214 ∧ code e604925615214 = 9401018637422 := by decide
theorem cert_e604925615214 : check e604925615214 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615226 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e604925615226 : Closed e604925615226 ∧ code e604925615226 = 9401018637434 := by decide
theorem cert_e604925615226 : check e604925615226 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e604925615390 : Closed e604925615390 ∧ code e604925615390 = 9401018637598 := by decide
theorem cert_e604925615390 : check e604925615390 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e604925615558 : Closed e604925615558 ∧ code e604925615558 = 9401018637766 := by decide
theorem cert_e604925615558 : check e604925615558 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e604925615670 : Closed e604925615670 ∧ code e604925615670 = 9401018637878 := by decide
theorem cert_e604925615670 : check e604925615670 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615674 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e604925615674 : Closed e604925615674 ∧ code e604925615674 = 9401018637882 := by decide
theorem cert_e604925615674 : check e604925615674 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615758 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e604925615758 : Closed e604925615758 ∧ code e604925615758 = 9401018637966 := by decide
theorem cert_e604925615758 : check e604925615758 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925615814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e604925615814 : Closed e604925615814 ∧ code e604925615814 = 9401018638022 := by decide
theorem cert_e604925615814 : check e604925615814 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925617950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e604925617950 : Closed e604925617950 ∧ code e604925617950 = 9401018640158 := by decide
theorem cert_e604925617950 : check e604925617950 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925618062 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e604925618062 : Closed e604925618062 ∧ code e604925618062 = 9401018640270 := by decide
theorem cert_e604925618062 : check e604925618062 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925621022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e604925621022 : Closed e604925621022 ∧ code e604925621022 = 9401018643230 := by decide
theorem cert_e604925621022 : check e604925621022 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925621190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e604925621190 : Closed e604925621190 ∧ code e604925621190 = 9401018643398 := by decide
theorem cert_e604925621190 : check e604925621190 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925622670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e604925622670 : Closed e604925622670 ∧ code e604925622670 = 9401018644878 := by decide
theorem cert_e604925622670 : check e604925622670 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e604925622726 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e604925622726 : Closed e604925622726 ∧ code e604925622726 = 9401018644934 := by decide
theorem cert_e604925622726 : check e604925622726 [[.under],[.under],[.under,.left]] .chain = true := by decide
def e605059510470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605059510470 : Closed e605059510470 ∧ code e605059510470 = 9401152532678 := by decide
theorem cert_e605059510470 : check e605059510470 [[.under]] .width = true := by decide
def e605059526854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605059526854 : Closed e605059526854 ∧ code e605059526854 = 9401152549062 := by decide
theorem cert_e605059526854 : check e605059526854 [[.under]] .width = true := by decide
def e605059641542 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605059641542 : Closed e605059641542 ∧ code e605059641542 = 9401152663750 := by decide
theorem cert_e605059641542 : check e605059641542 [[.under]] .width = true := by decide
def e605059666118 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e605059666118 : Closed e605059666118 ∧ code e605059666118 = 9401152688326 := by decide
theorem cert_e605059666118 : check e605059666118 [[.under]] .width = true := by decide
end Blc.Floor43
