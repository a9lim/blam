import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406585738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406585738 : Closed e2422406585738 ∧ code e2422406585738 = 11218499607946 := by decide
theorem cert_e2422406585738 : check e2422406585738 [[],[]] .chain = true := by decide
def e2422406585762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406585762 : Closed e2422406585762 ∧ code e2422406585762 = 11218499607970 := by decide
theorem cert_e2422406585762 : check e2422406585762 [[],[]] .chain = true := by decide
def e2422406585774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406585774 : Closed e2422406585774 ∧ code e2422406585774 = 11218499607982 := by decide
theorem cert_e2422406585774 : check e2422406585774 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406585786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406585786 : Closed e2422406585786 ∧ code e2422406585786 = 11218499607994 := by decide
theorem cert_e2422406585786 : check e2422406585786 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406585814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406585814 : Closed e2422406585814 ∧ code e2422406585814 = 11218499608022 := by decide
theorem cert_e2422406585814 : check e2422406585814 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406585818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406585818 : Closed e2422406585818 ∧ code e2422406585818 = 11218499608026 := by decide
theorem cert_e2422406585818 : check e2422406585818 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406586038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406586038 : Closed e2422406586038 ∧ code e2422406586038 = 11218499608246 := by decide
theorem cert_e2422406586038 : check e2422406586038 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406586070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406586070 : Closed e2422406586070 ∧ code e2422406586070 = 11218499608278 := by decide
theorem cert_e2422406586070 : check e2422406586070 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406586074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406586074 : Closed e2422406586074 ∧ code e2422406586074 = 11218499608282 := by decide
theorem cert_e2422406586074 : check e2422406586074 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406590806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406590806 : Closed e2422406590806 ∧ code e2422406590806 = 11218499613014 := by decide
theorem cert_e2422406590806 : check e2422406590806 [[],[]] .chain = true := by decide
def e2422406590810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406590810 : Closed e2422406590810 ∧ code e2422406590810 = 11218499613018 := by decide
theorem cert_e2422406590810 : check e2422406590810 [[],[]] .chain = true := by decide
def e2422406590826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406590826 : Closed e2422406590826 ∧ code e2422406590826 = 11218499613034 := by decide
theorem cert_e2422406590826 : check e2422406590826 [[],[]] .chain = true := by decide
def e2422406591574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406591574 : Closed e2422406591574 ∧ code e2422406591574 = 11218499613782 := by decide
theorem cert_e2422406591574 : check e2422406591574 [[],[]] .chain = true := by decide
def e2422406591578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406591578 : Closed e2422406591578 ∧ code e2422406591578 = 11218499613786 := by decide
theorem cert_e2422406591578 : check e2422406591578 [[],[]] .chain = true := by decide
def e2422406591766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406591766 : Closed e2422406591766 ∧ code e2422406591766 = 11218499613974 := by decide
theorem cert_e2422406591766 : check e2422406591766 [[],[]] .chain = true := by decide
def e2422406591842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406591842 : Closed e2422406591842 ∧ code e2422406591842 = 11218499614050 := by decide
theorem cert_e2422406591842 : check e2422406591842 [[],[]] .chain = true := by decide
def e2422406591854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406591854 : Closed e2422406591854 ∧ code e2422406591854 = 11218499614062 := by decide
theorem cert_e2422406591854 : check e2422406591854 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406591862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406591862 : Closed e2422406591862 ∧ code e2422406591862 = 11218499614070 := by decide
theorem cert_e2422406591862 : checkPay e2422406591862 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422406591882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406591882 : Closed e2422406591882 ∧ code e2422406591882 = 11218499614090 := by decide
theorem cert_e2422406591882 : check e2422406591882 [[],[]] .chain = true := by decide
def e2422406591906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406591906 : Closed e2422406591906 ∧ code e2422406591906 = 11218499614114 := by decide
theorem cert_e2422406591906 : check e2422406591906 [[],[]] .chain = true := by decide
def e2422406591918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406591918 : Closed e2422406591918 ∧ code e2422406591918 = 11218499614126 := by decide
theorem cert_e2422406591918 : check e2422406591918 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406591926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2422406591926 : Closed e2422406591926 ∧ code e2422406591926 = 11218499614134 := by decide
theorem cert_e2422406591926 : check e2422406591926 [[],[]] .chain = true := by decide
def e2422406591930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406591930 : Closed e2422406591930 ∧ code e2422406591930 = 11218499614138 := by decide
theorem cert_e2422406591930 : check e2422406591930 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406591958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406591958 : Closed e2422406591958 ∧ code e2422406591958 = 11218499614166 := by decide
theorem cert_e2422406591958 : check e2422406591958 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406591962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406591962 : Closed e2422406591962 ∧ code e2422406591962 = 11218499614170 := by decide
theorem cert_e2422406591962 : check e2422406591962 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406592042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406592042 : Closed e2422406592042 ∧ code e2422406592042 = 11218499614250 := by decide
theorem cert_e2422406592042 : check e2422406592042 [[],[]] .chain = true := by decide
def e2422406592138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406592138 : Closed e2422406592138 ∧ code e2422406592138 = 11218499614346 := by decide
theorem cert_e2422406592138 : check e2422406592138 [[],[]] .chain = true := by decide
def e2422406592162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406592162 : Closed e2422406592162 ∧ code e2422406592162 = 11218499614370 := by decide
theorem cert_e2422406592162 : check e2422406592162 [[],[]] .chain = true := by decide
def e2422406592174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406592174 : Closed e2422406592174 ∧ code e2422406592174 = 11218499614382 := by decide
theorem cert_e2422406592174 : check e2422406592174 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406592182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406592182 : Closed e2422406592182 ∧ code e2422406592182 = 11218499614390 := by decide
theorem cert_e2422406592182 : check e2422406592182 [[],[]] .chain = true := by decide
def e2422406592186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406592186 : Closed e2422406592186 ∧ code e2422406592186 = 11218499614394 := by decide
theorem cert_e2422406592186 : check e2422406592186 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406592214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406592214 : Closed e2422406592214 ∧ code e2422406592214 = 11218499614422 := by decide
theorem cert_e2422406592214 : check e2422406592214 [[],[]] .chain = true := by decide
def e2422406592218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406592218 : Closed e2422406592218 ∧ code e2422406592218 = 11218499614426 := by decide
theorem cert_e2422406592218 : check e2422406592218 [[],[]] .chain = true := by decide
def e2422406592234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406592234 : Closed e2422406592234 ∧ code e2422406592234 = 11218499614442 := by decide
theorem cert_e2422406592234 : check e2422406592234 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406592342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406592342 : Closed e2422406592342 ∧ code e2422406592342 = 11218499614550 := by decide
def e2422406592346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406592346 : Closed e2422406592346 ∧ code e2422406592346 = 11218499614554 := by decide
theorem cert_e2422406592346 : check e2422406592346 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406592362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406592362 : Closed e2422406592362 ∧ code e2422406592362 = 11218499614570 := by decide
def e2422406592682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406592682 : Closed e2422406592682 ∧ code e2422406592682 = 11218499614890 := by decide
theorem cert_e2422406592682 : check e2422406592682 [[],[]] .chain = true := by decide
def e2422406593066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406593066 : Closed e2422406593066 ∧ code e2422406593066 = 11218499615274 := by decide
theorem cert_e2422406593066 : check e2422406593066 [[],[]] .chain = true := by decide
def e2422406593162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406593162 : Closed e2422406593162 ∧ code e2422406593162 = 11218499615370 := by decide
theorem cert_e2422406593162 : check e2422406593162 [[],[]] .chain = true := by decide
def e2422406593186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406593186 : Closed e2422406593186 ∧ code e2422406593186 = 11218499615394 := by decide
theorem cert_e2422406593186 : check e2422406593186 [[],[]] .chain = true := by decide
def e2422406593198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406593198 : Closed e2422406593198 ∧ code e2422406593198 = 11218499615406 := by decide
theorem cert_e2422406593198 : check e2422406593198 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406593206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406593206 : Closed e2422406593206 ∧ code e2422406593206 = 11218499615414 := by decide
theorem cert_e2422406593206 : check e2422406593206 [[],[]] .chain = true := by decide
def e2422406593210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406593210 : Closed e2422406593210 ∧ code e2422406593210 = 11218499615418 := by decide
theorem cert_e2422406593210 : check e2422406593210 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406593238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406593238 : Closed e2422406593238 ∧ code e2422406593238 = 11218499615446 := by decide
theorem cert_e2422406593238 : check e2422406593238 [[],[]] .chain = true := by decide
def e2422406593242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406593242 : Closed e2422406593242 ∧ code e2422406593242 = 11218499615450 := by decide
theorem cert_e2422406593242 : check e2422406593242 [[],[]] .chain = true := by decide
def e2422406593258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406593258 : Closed e2422406593258 ∧ code e2422406593258 = 11218499615466 := by decide
theorem cert_e2422406593258 : check e2422406593258 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406593366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406593366 : Closed e2422406593366 ∧ code e2422406593366 = 11218499615574 := by decide
theorem cert_e2422406593366 : check e2422406593366 [[],[]] .chain = true := by decide
def e2422406593370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406593370 : Closed e2422406593370 ∧ code e2422406593370 = 11218499615578 := by decide
theorem cert_e2422406593370 : check e2422406593370 [[],[]] .chain = true := by decide
def e2422406593386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406593386 : Closed e2422406593386 ∧ code e2422406593386 = 11218499615594 := by decide
theorem cert_e2422406593386 : check e2422406593386 [[],[]] .chain = true := by decide
def e2422406593450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406593450 : Closed e2422406593450 ∧ code e2422406593450 = 11218499615658 := by decide
theorem cert_e2422406593450 : check e2422406593450 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406593878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406593878 : Closed e2422406593878 ∧ code e2422406593878 = 11218499616086 := by decide
theorem cert_e2422406593878 : check e2422406593878 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406593882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406593882 : Closed e2422406593882 ∧ code e2422406593882 = 11218499616090 := by decide
theorem cert_e2422406593882 : check e2422406593882 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406593898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406593898 : Closed e2422406593898 ∧ code e2422406593898 = 11218499616106 := by decide
theorem cert_e2422406593898 : check e2422406593898 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406593962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406593962 : Closed e2422406593962 ∧ code e2422406593962 = 11218499616170 := by decide
theorem cert_e2422406593962 : check e2422406593962 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2422406594646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422406594646 : Closed e2422406594646 ∧ code e2422406594646 = 11218499616854 := by decide
theorem cert_e2422406594646 : check e2422406594646 [[],[]] .chain = true := by decide
def e2422406594650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422406594650 : Closed e2422406594650 ∧ code e2422406594650 = 11218499616858 := by decide
theorem cert_e2422406594650 : check e2422406594650 [[],[]] .chain = true := by decide
def e2422406594926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406594926 : Closed e2422406594926 ∧ code e2422406594926 = 11218499617134 := by decide
theorem cert_e2422406594926 : check e2422406594926 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406594934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406594934 : Closed e2422406594934 ∧ code e2422406594934 = 11218499617142 := by decide
theorem cert_e2422406594934 : check e2422406594934 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406594998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422406594998 : Closed e2422406594998 ∧ code e2422406594998 = 11218499617206 := by decide
theorem cert_e2422406594998 : check e2422406594998 [[],[]] .chain = true := by decide
def e2422406595030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422406595030 : Closed e2422406595030 ∧ code e2422406595030 = 11218499617238 := by decide
theorem cert_e2422406595030 : check e2422406595030 [[],[]] .chain = true := by decide
def e2422406595034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422406595034 : Closed e2422406595034 ∧ code e2422406595034 = 11218499617242 := by decide
theorem cert_e2422406595034 : check e2422406595034 [[],[]] .chain = true := by decide
def e2422406595050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2422406595050 : Closed e2422406595050 ∧ code e2422406595050 = 11218499617258 := by decide
theorem cert_e2422406595050 : check e2422406595050 [[],[]] .chain = true := by decide
def e2422406595414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406595414 : Closed e2422406595414 ∧ code e2422406595414 = 11218499617622 := by decide
theorem cert_e2422406595414 : check e2422406595414 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406595418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406595418 : Closed e2422406595418 ∧ code e2422406595418 = 11218499617626 := by decide
theorem cert_e2422406595418 : check e2422406595418 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406595702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406595702 : Closed e2422406595702 ∧ code e2422406595702 = 11218499617910 := by decide
theorem cert_e2422406595702 : check e2422406595702 [[],[]] .chain = true := by decide
def e2422406595798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406595798 : Closed e2422406595798 ∧ code e2422406595798 = 11218499618006 := by decide
theorem cert_e2422406595798 : check e2422406595798 [[],[]] .chain = true := by decide
def e2422406595802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406595802 : Closed e2422406595802 ∧ code e2422406595802 = 11218499618010 := by decide
theorem cert_e2422406595802 : check e2422406595802 [[],[]] .chain = true := by decide
def e2422406595818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406595818 : Closed e2422406595818 ∧ code e2422406595818 = 11218499618026 := by decide
theorem cert_e2422406595818 : check e2422406595818 [[],[]] .chain = true := by decide
def e2422406595894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406595894 : Closed e2422406595894 ∧ code e2422406595894 = 11218499618102 := by decide
theorem cert_e2422406595894 : check e2422406595894 [[],[]] .chain = true := by decide
def e2422406595898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406595898 : Closed e2422406595898 ∧ code e2422406595898 = 11218499618106 := by decide
theorem cert_e2422406595898 : check e2422406595898 [[],[]] .chain = true := by decide
def e2422406595982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406595982 : Closed e2422406595982 ∧ code e2422406595982 = 11218499618190 := by decide
theorem cert_e2422406595982 : check e2422406595982 [[],[]] .chain = true := by decide
def e2422406595994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406595994 : Closed e2422406595994 ∧ code e2422406595994 = 11218499618202 := by decide
theorem cert_e2422406595994 : check e2422406595994 [[],[]] .chain = true := by decide
def e2422406596150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406596150 : Closed e2422406596150 ∧ code e2422406596150 = 11218499618358 := by decide
theorem cert_e2422406596150 : check e2422406596150 [[],[]] .chain = true := by decide
def e2422406596154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406596154 : Closed e2422406596154 ∧ code e2422406596154 = 11218499618362 := by decide
theorem cert_e2422406596154 : check e2422406596154 [[],[]] .chain = true := by decide
def e2422406596238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406596238 : Closed e2422406596238 ∧ code e2422406596238 = 11218499618446 := by decide
theorem cert_e2422406596238 : check e2422406596238 [[],[]] .chain = true := by decide
def e2422406596294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406596294 : Closed e2422406596294 ∧ code e2422406596294 = 11218499618502 := by decide
theorem cert_e2422406596294 : check e2422406596294 [[],[]] .chain = true := by decide
def e2422406596374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406596374 : Closed e2422406596374 ∧ code e2422406596374 = 11218499618582 := by decide
theorem cert_e2422406596374 : check e2422406596374 [[],[]] .chain = true := by decide
def e2422406596378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406596378 : Closed e2422406596378 ∧ code e2422406596378 = 11218499618586 := by decide
theorem cert_e2422406596378 : check e2422406596378 [[],[]] .chain = true := by decide
def e2422406596422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406596422 : Closed e2422406596422 ∧ code e2422406596422 = 11218499618630 := by decide
theorem cert_e2422406596422 : check e2422406596422 [[],[]] .chain = true := by decide
def e2422406596450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406596450 : Closed e2422406596450 ∧ code e2422406596450 = 11218499618658 := by decide
theorem cert_e2422406596450 : check e2422406596450 [[],[]] .chain = true := by decide
def e2422406596462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2422406596462 : Closed e2422406596462 ∧ code e2422406596462 = 11218499618670 := by decide
theorem cert_e2422406596462 : check e2422406596462 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406596470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2422406596470 : Closed e2422406596470 ∧ code e2422406596470 = 11218499618678 := by decide
theorem cert_e2422406596470 : check e2422406596470 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406596534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 1))))))
theorem wire_e2422406596534 : Closed e2422406596534 ∧ code e2422406596534 = 11218499618742 := by decide
theorem cert_e2422406596534 : check e2422406596534 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406597718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406597718 : Closed e2422406597718 ∧ code e2422406597718 = 11218499619926 := by decide
theorem cert_e2422406597718 : check e2422406597718 [[],[]] .chain = true := by decide
def e2422406597722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406597722 : Closed e2422406597722 ∧ code e2422406597722 = 11218499619930 := by decide
theorem cert_e2422406597722 : check e2422406597722 [[],[]] .chain = true := by decide
def e2422406597910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406597910 : Closed e2422406597910 ∧ code e2422406597910 = 11218499620118 := by decide
theorem cert_e2422406597910 : check e2422406597910 [[],[]] .chain = true := by decide
def e2422406597986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406597986 : Closed e2422406597986 ∧ code e2422406597986 = 11218499620194 := by decide
theorem cert_e2422406597986 : check e2422406597986 [[],[]] .chain = true := by decide
def e2422406597998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406597998 : Closed e2422406597998 ∧ code e2422406597998 = 11218499620206 := by decide
theorem cert_e2422406597998 : check e2422406597998 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406598006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406598006 : Closed e2422406598006 ∧ code e2422406598006 = 11218499620214 := by decide
def e2422406598026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406598026 : Closed e2422406598026 ∧ code e2422406598026 = 11218499620234 := by decide
theorem cert_e2422406598026 : check e2422406598026 [[],[]] .chain = true := by decide
def e2422406598050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406598050 : Closed e2422406598050 ∧ code e2422406598050 = 11218499620258 := by decide
theorem cert_e2422406598050 : check e2422406598050 [[],[]] .chain = true := by decide
def e2422406598062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406598062 : Closed e2422406598062 ∧ code e2422406598062 = 11218499620270 := by decide
theorem cert_e2422406598062 : check e2422406598062 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406598070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422406598070 : Closed e2422406598070 ∧ code e2422406598070 = 11218499620278 := by decide
theorem cert_e2422406598070 : check e2422406598070 [[],[]] .chain = true := by decide
def e2422406598074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406598074 : Closed e2422406598074 ∧ code e2422406598074 = 11218499620282 := by decide
def e2422406598102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406598102 : Closed e2422406598102 ∧ code e2422406598102 = 11218499620310 := by decide
theorem cert_e2422406598102 : check e2422406598102 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406598106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406598106 : Closed e2422406598106 ∧ code e2422406598106 = 11218499620314 := by decide
theorem cert_e2422406598106 : check e2422406598106 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406598186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406598186 : Closed e2422406598186 ∧ code e2422406598186 = 11218499620394 := by decide
theorem cert_e2422406598186 : check e2422406598186 [[],[]] .chain = true := by decide
def e2422406598282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406598282 : Closed e2422406598282 ∧ code e2422406598282 = 11218499620490 := by decide
theorem cert_e2422406598282 : check e2422406598282 [[],[]] .chain = true := by decide
def e2422406598306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406598306 : Closed e2422406598306 ∧ code e2422406598306 = 11218499620514 := by decide
theorem cert_e2422406598306 : check e2422406598306 [[],[]] .chain = true := by decide
def e2422406598318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406598318 : Closed e2422406598318 ∧ code e2422406598318 = 11218499620526 := by decide
theorem cert_e2422406598318 : check e2422406598318 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406598326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406598326 : Closed e2422406598326 ∧ code e2422406598326 = 11218499620534 := by decide
theorem cert_e2422406598326 : check e2422406598326 [[],[]] .chain = true := by decide
def e2422406598330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406598330 : Closed e2422406598330 ∧ code e2422406598330 = 11218499620538 := by decide
theorem cert_e2422406598330 : check e2422406598330 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406598358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406598358 : Closed e2422406598358 ∧ code e2422406598358 = 11218499620566 := by decide
theorem cert_e2422406598358 : check e2422406598358 [[],[]] .chain = true := by decide
def e2422406598362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406598362 : Closed e2422406598362 ∧ code e2422406598362 = 11218499620570 := by decide
theorem cert_e2422406598362 : check e2422406598362 [[],[]] .chain = true := by decide
def e2422406598378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406598378 : Closed e2422406598378 ∧ code e2422406598378 = 11218499620586 := by decide
theorem cert_e2422406598378 : check e2422406598378 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406598486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406598486 : Closed e2422406598486 ∧ code e2422406598486 = 11218499620694 := by decide
theorem cert_e2422406598486 : check e2422406598486 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406598490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406598490 : Closed e2422406598490 ∧ code e2422406598490 = 11218499620698 := by decide
theorem cert_e2422406598490 : check e2422406598490 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406598506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406598506 : Closed e2422406598506 ∧ code e2422406598506 = 11218499620714 := by decide
theorem cert_e2422406598506 : check e2422406598506 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406598678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422406598678 : Closed e2422406598678 ∧ code e2422406598678 = 11218499620886 := by decide
theorem cert_e2422406598678 : check e2422406598678 [[],[]] .chain = true := by decide
def e2422406598774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422406598774 : Closed e2422406598774 ∧ code e2422406598774 = 11218499620982 := by decide
theorem cert_e2422406598774 : check e2422406598774 [[],[]] .chain = true := by decide
def e2422406598778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422406598778 : Closed e2422406598778 ∧ code e2422406598778 = 11218499620986 := by decide
theorem cert_e2422406598778 : check e2422406598778 [[],[]] .chain = true := by decide
def e2422406598870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422406598870 : Closed e2422406598870 ∧ code e2422406598870 = 11218499621078 := by decide
theorem cert_e2422406598870 : check e2422406598870 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406598966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406598966 : Closed e2422406598966 ∧ code e2422406598966 = 11218499621174 := by decide
theorem cert_e2422406598966 : check e2422406598966 [[],[]] .chain = true := by decide
def e2422406598970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406598970 : Closed e2422406598970 ∧ code e2422406598970 = 11218499621178 := by decide
theorem cert_e2422406598970 : check e2422406598970 [[],[]] .chain = true := by decide
def e2422406599054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422406599054 : Closed e2422406599054 ∧ code e2422406599054 = 11218499621262 := by decide
theorem cert_e2422406599054 : check e2422406599054 [[],[]] .chain = true := by decide
def e2422406599110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422406599110 : Closed e2422406599110 ∧ code e2422406599110 = 11218499621318 := by decide
theorem cert_e2422406599110 : check e2422406599110 [[],[]] .chain = true := by decide
def e2422406599446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406599446 : Closed e2422406599446 ∧ code e2422406599446 = 11218499621654 := by decide
theorem cert_e2422406599446 : check e2422406599446 [[],[]] .chain = true := by decide
def e2422406599522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406599522 : Closed e2422406599522 ∧ code e2422406599522 = 11218499621730 := by decide
theorem cert_e2422406599522 : check e2422406599522 [[],[]] .chain = true := by decide
def e2422406599534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406599534 : Closed e2422406599534 ∧ code e2422406599534 = 11218499621742 := by decide
theorem cert_e2422406599534 : check e2422406599534 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406599542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406599542 : Closed e2422406599542 ∧ code e2422406599542 = 11218499621750 := by decide
theorem cert_e2422406599542 : check e2422406599542 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406599562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406599562 : Closed e2422406599562 ∧ code e2422406599562 = 11218499621770 := by decide
theorem cert_e2422406599562 : check e2422406599562 [[],[]] .chain = true := by decide
def e2422406599586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406599586 : Closed e2422406599586 ∧ code e2422406599586 = 11218499621794 := by decide
theorem cert_e2422406599586 : check e2422406599586 [[],[]] .chain = true := by decide
def e2422406599598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406599598 : Closed e2422406599598 ∧ code e2422406599598 = 11218499621806 := by decide
theorem cert_e2422406599598 : check e2422406599598 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406599606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2422406599606 : Closed e2422406599606 ∧ code e2422406599606 = 11218499621814 := by decide
theorem cert_e2422406599606 : check e2422406599606 [[],[]] .chain = true := by decide
def e2422406599610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406599610 : Closed e2422406599610 ∧ code e2422406599610 = 11218499621818 := by decide
theorem cert_e2422406599610 : check e2422406599610 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406599638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406599638 : Closed e2422406599638 ∧ code e2422406599638 = 11218499621846 := by decide
def e2422406599642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406599642 : Closed e2422406599642 ∧ code e2422406599642 = 11218499621850 := by decide
theorem cert_e2422406599642 : check e2422406599642 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406599710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406599710 : Closed e2422406599710 ∧ code e2422406599710 = 11218499621918 := by decide
theorem cert_e2422406599710 : check e2422406599710 [[],[]] .chain = true := by decide
def e2422406599906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406599906 : Closed e2422406599906 ∧ code e2422406599906 = 11218499622114 := by decide
theorem cert_e2422406599906 : check e2422406599906 [[],[]] .chain = true := by decide
def e2422406599918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406599918 : Closed e2422406599918 ∧ code e2422406599918 = 11218499622126 := by decide
theorem cert_e2422406599918 : check e2422406599918 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406599926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406599926 : Closed e2422406599926 ∧ code e2422406599926 = 11218499622134 := by decide
theorem cert_e2422406599926 : check e2422406599926 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406600194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406600194 : Closed e2422406600194 ∧ code e2422406600194 = 11218499622402 := by decide
theorem cert_e2422406600194 : check e2422406600194 [[],[]] .chain = true := by decide
def e2422406600206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406600206 : Closed e2422406600206 ∧ code e2422406600206 = 11218499622414 := by decide
theorem cert_e2422406600206 : check e2422406600206 [[],[]] .chain = true := by decide
def e2422406600218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406600218 : Closed e2422406600218 ∧ code e2422406600218 = 11218499622426 := by decide
theorem cert_e2422406600218 : check e2422406600218 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406600290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406600290 : Closed e2422406600290 ∧ code e2422406600290 = 11218499622498 := by decide
theorem cert_e2422406600290 : check e2422406600290 [[],[]] .chain = true := by decide
def e2422406600302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406600302 : Closed e2422406600302 ∧ code e2422406600302 = 11218499622510 := by decide
theorem cert_e2422406600302 : check e2422406600302 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406600310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406600310 : Closed e2422406600310 ∧ code e2422406600310 = 11218499622518 := by decide
theorem cert_e2422406600310 : check e2422406600310 [[],[]] .chain = true := by decide
def e2422406600314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406600314 : Closed e2422406600314 ∧ code e2422406600314 = 11218499622522 := by decide
theorem cert_e2422406600314 : check e2422406600314 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406600502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406600502 : Closed e2422406600502 ∧ code e2422406600502 = 11218499622710 := by decide
theorem cert_e2422406600502 : check e2422406600502 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406600506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406600506 : Closed e2422406600506 ∧ code e2422406600506 = 11218499622714 := by decide
theorem cert_e2422406600506 : check e2422406600506 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406600714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406600714 : Closed e2422406600714 ∧ code e2422406600714 = 11218499622922 := by decide
theorem cert_e2422406600714 : check e2422406600714 [[],[]] .chain = true := by decide
def e2422406600750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406600750 : Closed e2422406600750 ∧ code e2422406600750 = 11218499622958 := by decide
theorem cert_e2422406600750 : check e2422406600750 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406600758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406600758 : Closed e2422406600758 ∧ code e2422406600758 = 11218499622966 := by decide
theorem cert_e2422406600758 : check e2422406600758 [[],[]] .chain = true := by decide
def e2422406600762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406600762 : Closed e2422406600762 ∧ code e2422406600762 = 11218499622970 := by decide
theorem cert_e2422406600762 : check e2422406600762 [[],[]] .chain = true := by decide
def e2422406600810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406600810 : Closed e2422406600810 ∧ code e2422406600810 = 11218499623018 := by decide
theorem cert_e2422406600810 : check e2422406600810 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406600846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406600846 : Closed e2422406600846 ∧ code e2422406600846 = 11218499623054 := by decide
theorem cert_e2422406600846 : check e2422406600846 [[],[]] .chain = true := by decide
def e2422406600858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406600858 : Closed e2422406600858 ∧ code e2422406600858 = 11218499623066 := by decide
theorem cert_e2422406600858 : check e2422406600858 [[],[]] .chain = true := by decide
def e2422406600902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406600902 : Closed e2422406600902 ∧ code e2422406600902 = 11218499623110 := by decide
theorem cert_e2422406600902 : check e2422406600902 [[],[]] .chain = true := by decide
def e2422406600930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406600930 : Closed e2422406600930 ∧ code e2422406600930 = 11218499623138 := by decide
theorem cert_e2422406600930 : check e2422406600930 [[],[]] .chain = true := by decide
def e2422406600942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406600942 : Closed e2422406600942 ∧ code e2422406600942 = 11218499623150 := by decide
theorem cert_e2422406600942 : check e2422406600942 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406600950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406600950 : Closed e2422406600950 ∧ code e2422406600950 = 11218499623158 := by decide
theorem cert_e2422406600950 : check e2422406600950 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406601098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406601098 : Closed e2422406601098 ∧ code e2422406601098 = 11218499623306 := by decide
theorem cert_e2422406601098 : check e2422406601098 [[],[]] .chain = true := by decide
def e2422406601122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406601122 : Closed e2422406601122 ∧ code e2422406601122 = 11218499623330 := by decide
theorem cert_e2422406601122 : check e2422406601122 [[],[]] .chain = true := by decide
def e2422406601134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406601134 : Closed e2422406601134 ∧ code e2422406601134 = 11218499623342 := by decide
theorem cert_e2422406601134 : check e2422406601134 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406601142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406601142 : Closed e2422406601142 ∧ code e2422406601142 = 11218499623350 := by decide
theorem cert_e2422406601142 : check e2422406601142 [[],[]] .chain = true := by decide
def e2422406601146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406601146 : Closed e2422406601146 ∧ code e2422406601146 = 11218499623354 := by decide
theorem cert_e2422406601146 : checkPay e2422406601146 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] = true := by decide
def e2422406601174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406601174 : Closed e2422406601174 ∧ code e2422406601174 = 11218499623382 := by decide
theorem cert_e2422406601174 : check e2422406601174 [[],[]] .chain = true := by decide
def e2422406601178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406601178 : Closed e2422406601178 ∧ code e2422406601178 = 11218499623386 := by decide
theorem cert_e2422406601178 : check e2422406601178 [[],[]] .chain = true := by decide
def e2422406601194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406601194 : Closed e2422406601194 ∧ code e2422406601194 = 11218499623402 := by decide
end Blc.Floor43
