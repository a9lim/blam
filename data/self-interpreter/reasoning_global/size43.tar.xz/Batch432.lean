import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374346606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))))
theorem wire_e2422374346606 : Closed e2422374346606 ∧ code e2422374346606 = 11218467368814 := by decide
theorem cert_e2422374346606 : check e2422374346606 [[],[]] .smaller = true := by decide
def e2422374346614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))))
theorem wire_e2422374346614 : Closed e2422374346614 ∧ code e2422374346614 = 11218467368822 := by decide
theorem cert_e2422374346614 : check e2422374346614 [[],[]] .smaller = true := by decide
def e2422374346618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e2422374346618 : Closed e2422374346618 ∧ code e2422374346618 = 11218467368826 := by decide
theorem cert_e2422374346618 : check e2422374346618 [[],[]] .smaller = true := by decide
def e2422374346670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e2422374346670 : Closed e2422374346670 ∧ code e2422374346670 = 11218467368878 := by decide
theorem cert_e2422374346670 : check e2422374346670 [[],[]] .smaller = true := by decide
def e2422374346678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e2422374346678 : Closed e2422374346678 ∧ code e2422374346678 = 11218467368886 := by decide
theorem cert_e2422374346678 : check e2422374346678 [[],[]] .smaller = true := by decide
def e2422374346682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e2422374346682 : Closed e2422374346682 ∧ code e2422374346682 = 11218467368890 := by decide
theorem cert_e2422374346682 : check e2422374346682 [[],[]] .smaller = true := by decide
def e2422374346710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1))))))))))
theorem wire_e2422374346710 : Closed e2422374346710 ∧ code e2422374346710 = 11218467368918 := by decide
theorem cert_e2422374346710 : check e2422374346710 [[],[]] .three = true := by decide
def e2422374346714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0))))))))))
theorem wire_e2422374346714 : Closed e2422374346714 ∧ code e2422374346714 = 11218467368922 := by decide
theorem cert_e2422374346714 : check e2422374346714 [[],[]] .three = true := by decide
def e2422374347710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422374347710 : Closed e2422374347710 ∧ code e2422374347710 = 11218467369918 := by decide
theorem cert_e2422374347710 : check e2422374347710 [[],[]] .three = true := by decide
def e2422374347742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422374347742 : Closed e2422374347742 ∧ code e2422374347742 = 11218467369950 := by decide
theorem cert_e2422374347742 : check e2422374347742 [[],[]] .smaller = true := by decide
def e2422374347758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422374347758 : Closed e2422374347758 ∧ code e2422374347758 = 11218467369966 := by decide
theorem cert_e2422374347758 : check e2422374347758 [[],[]] .smaller = true := by decide
def e2422374347766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422374347766 : Closed e2422374347766 ∧ code e2422374347766 = 11218467369974 := by decide
theorem cert_e2422374347766 : check e2422374347766 [[],[]] .three = true := by decide
def e2422374348862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))))
theorem wire_e2422374348862 : Closed e2422374348862 ∧ code e2422374348862 = 11218467371070 := by decide
theorem cert_e2422374348862 : check e2422374348862 [[],[]] .smaller = true := by decide
def e2422374349246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422374349246 : Closed e2422374349246 ∧ code e2422374349246 = 11218467371454 := by decide
theorem cert_e2422374349246 : check e2422374349246 [[],[]] .three = true := by decide
def e2422374349278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422374349278 : Closed e2422374349278 ∧ code e2422374349278 = 11218467371486 := by decide
theorem cert_e2422374349278 : check e2422374349278 [[],[]] .smaller = true := by decide
def e2422374349282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))))
theorem wire_e2422374349282 : Closed e2422374349282 ∧ code e2422374349282 = 11218467371490 := by decide
theorem cert_e2422374349282 : check e2422374349282 [[],[]] .smaller = true := by decide
def e2422374349294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422374349294 : Closed e2422374349294 ∧ code e2422374349294 = 11218467371502 := by decide
theorem cert_e2422374349294 : check e2422374349294 [[],[]] .smaller = true := by decide
def e2422374349302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422374349302 : Closed e2422374349302 ∧ code e2422374349302 = 11218467371510 := by decide
theorem cert_e2422374349302 : check e2422374349302 [[],[]] .smaller = true := by decide
def e2422374349306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422374349306 : Closed e2422374349306 ∧ code e2422374349306 = 11218467371514 := by decide
theorem cert_e2422374349306 : check e2422374349306 [[],[]] .three = true := by decide
def e2422374349854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))))
theorem wire_e2422374349854 : Closed e2422374349854 ∧ code e2422374349854 = 11218467372062 := by decide
theorem cert_e2422374349854 : check e2422374349854 [[],[]] .smaller = true := by decide
def e2422374350046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422374350046 : Closed e2422374350046 ∧ code e2422374350046 = 11218467372254 := by decide
theorem cert_e2422374350046 : check e2422374350046 [[],[]] .smaller = true := by decide
def e2422374350050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))))
theorem wire_e2422374350050 : Closed e2422374350050 ∧ code e2422374350050 = 11218467372258 := by decide
theorem cert_e2422374350050 : check e2422374350050 [[],[]] .smaller = true := by decide
def e2422374350062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422374350062 : Closed e2422374350062 ∧ code e2422374350062 = 11218467372270 := by decide
theorem cert_e2422374350062 : check e2422374350062 [[],[]] .smaller = true := by decide
def e2422374350070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422374350070 : Closed e2422374350070 ∧ code e2422374350070 = 11218467372278 := by decide
theorem cert_e2422374350070 : check e2422374350070 [[],[]] .smaller = true := by decide
def e2422374350074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422374350074 : Closed e2422374350074 ∧ code e2422374350074 = 11218467372282 := by decide
theorem cert_e2422374350074 : check e2422374350074 [[],[]] .smaller = true := by decide
def e2422374350446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374350446 : Closed e2422374350446 ∧ code e2422374350446 = 11218467372654 := by decide
theorem cert_e2422374350446 : check e2422374350446 [[],[]] .smaller = true := by decide
def e2422374350454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422374350454 : Closed e2422374350454 ∧ code e2422374350454 = 11218467372662 := by decide
theorem cert_e2422374350454 : check e2422374350454 [[],[]] .smaller = true := by decide
def e2422374350458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374350458 : Closed e2422374350458 ∧ code e2422374350458 = 11218467372666 := by decide
theorem cert_e2422374350458 : check e2422374350458 [[],[]] .smaller = true := by decide
def e2422374350646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374350646 : Closed e2422374350646 ∧ code e2422374350646 = 11218467372854 := by decide
theorem cert_e2422374350646 : check e2422374350646 [[],[]] .three = true := by decide
def e2422374350650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374350650 : Closed e2422374350650 ∧ code e2422374350650 = 11218467372858 := by decide
theorem cert_e2422374350650 : check e2422374350650 [[],[]] .three = true := by decide
def e2422374369150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 5)))))))))))
theorem wire_e2422374369150 : Closed e2422374369150 ∧ code e2422374369150 = 11218467391358 := by decide
theorem cert_e2422374369150 : check e2422374369150 [[],[]] .three = true := by decide
def e2422374369270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 5) (.var 1)))))))))))
theorem wire_e2422374369270 : Closed e2422374369270 ∧ code e2422374369270 = 11218467391478 := by decide
theorem cert_e2422374369270 : check e2422374369270 [[],[]] .three = true := by decide
def e2422374372910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))))
theorem wire_e2422374372910 : Closed e2422374372910 ∧ code e2422374372910 = 11218467395118 := by decide
theorem cert_e2422374372910 : check e2422374372910 [[],[]] .smaller = true := by decide
def e2422374373054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4))))))))))
theorem wire_e2422374373054 : Closed e2422374373054 ∧ code e2422374373054 = 11218467395262 := by decide
theorem cert_e2422374373054 : check e2422374373054 [[],[]] .three = true := by decide
def e2422374373086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2422374373086 : Closed e2422374373086 ∧ code e2422374373086 = 11218467395294 := by decide
theorem cert_e2422374373086 : check e2422374373086 [[],[]] .smaller = true := by decide
def e2422374373090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))))
theorem wire_e2422374373090 : Closed e2422374373090 ∧ code e2422374373090 = 11218467395298 := by decide
theorem cert_e2422374373090 : check e2422374373090 [[],[]] .smaller = true := by decide
def e2422374373102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e2422374373102 : Closed e2422374373102 ∧ code e2422374373102 = 11218467395310 := by decide
theorem cert_e2422374373102 : check e2422374373102 [[],[]] .smaller = true := by decide
def e2422374373110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2422374373110 : Closed e2422374373110 ∧ code e2422374373110 = 11218467395318 := by decide
theorem cert_e2422374373110 : check e2422374373110 [[],[]] .smaller = true := by decide
def e2422374373114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0))))))))))
theorem wire_e2422374373114 : Closed e2422374373114 ∧ code e2422374373114 = 11218467395322 := by decide
theorem cert_e2422374373114 : check e2422374373114 [[],[]] .three = true := by decide
def e2422374373214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2422374373214 : Closed e2422374373214 ∧ code e2422374373214 = 11218467395422 := by decide
theorem cert_e2422374373214 : check e2422374373214 [[],[]] .smaller = true := by decide
def e2422374373242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2422374373242 : Closed e2422374373242 ∧ code e2422374373242 = 11218467395450 := by decide
theorem cert_e2422374373242 : check e2422374373242 [[],[]] .smaller = true := by decide
def e2422374373258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422374373258 : Closed e2422374373258 ∧ code e2422374373258 = 11218467395466 := by decide
theorem cert_e2422374373258 : check e2422374373258 [[],[]] .smaller = true := by decide
def e2422374373282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422374373282 : Closed e2422374373282 ∧ code e2422374373282 = 11218467395490 := by decide
theorem cert_e2422374373282 : check e2422374373282 [[],[]] .smaller = true := by decide
def e2422374373294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e2422374373294 : Closed e2422374373294 ∧ code e2422374373294 = 11218467395502 := by decide
theorem cert_e2422374373294 : check e2422374373294 [[],[]] .smaller = true := by decide
def e2422374373306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e2422374373306 : Closed e2422374373306 ∧ code e2422374373306 = 11218467395514 := by decide
theorem cert_e2422374373306 : check e2422374373306 [[],[]] .smaller = true := by decide
def e2422374373334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2422374373334 : Closed e2422374373334 ∧ code e2422374373334 = 11218467395542 := by decide
theorem cert_e2422374373334 : check e2422374373334 [[],[]] .smaller = true := by decide
def e2422374373338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2422374373338 : Closed e2422374373338 ∧ code e2422374373338 = 11218467395546 := by decide
theorem cert_e2422374373338 : check e2422374373338 [[],[]] .smaller = true := by decide
def e2422374373354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0))))))))))
theorem wire_e2422374373354 : Closed e2422374373354 ∧ code e2422374373354 = 11218467395562 := by decide
theorem cert_e2422374373354 : check e2422374373354 [[],[]] .three = true := by decide
def e2422374373438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))))
theorem wire_e2422374373438 : Closed e2422374373438 ∧ code e2422374373438 = 11218467395646 := by decide
theorem cert_e2422374373438 : check e2422374373438 [[],[]] .smaller = true := by decide
def e2422374373822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422374373822 : Closed e2422374373822 ∧ code e2422374373822 = 11218467396030 := by decide
theorem cert_e2422374373822 : check e2422374373822 [[],[]] .three = true := by decide
def e2422374373854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422374373854 : Closed e2422374373854 ∧ code e2422374373854 = 11218467396062 := by decide
theorem cert_e2422374373854 : check e2422374373854 [[],[]] .smaller = true := by decide
def e2422374373858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))))
theorem wire_e2422374373858 : Closed e2422374373858 ∧ code e2422374373858 = 11218467396066 := by decide
theorem cert_e2422374373858 : check e2422374373858 [[],[]] .smaller = true := by decide
def e2422374373870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422374373870 : Closed e2422374373870 ∧ code e2422374373870 = 11218467396078 := by decide
theorem cert_e2422374373870 : check e2422374373870 [[],[]] .smaller = true := by decide
def e2422374373878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422374373878 : Closed e2422374373878 ∧ code e2422374373878 = 11218467396086 := by decide
theorem cert_e2422374373878 : check e2422374373878 [[],[]] .smaller = true := by decide
def e2422374373882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422374373882 : Closed e2422374373882 ∧ code e2422374373882 = 11218467396090 := by decide
theorem cert_e2422374373882 : check e2422374373882 [[],[]] .three = true := by decide
def e2422374374622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422374374622 : Closed e2422374374622 ∧ code e2422374374622 = 11218467396830 := by decide
theorem cert_e2422374374622 : check e2422374374622 [[],[]] .smaller = true := by decide
def e2422374374650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422374374650 : Closed e2422374374650 ∧ code e2422374374650 = 11218467396858 := by decide
theorem cert_e2422374374650 : check e2422374374650 [[],[]] .smaller = true := by decide
def e2422374374926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422374374926 : Closed e2422374374926 ∧ code e2422374374926 = 11218467397134 := by decide
theorem cert_e2422374374926 : check e2422374374926 [[],[]] .smaller = true := by decide
def e2422374374974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e2422374374974 : Closed e2422374374974 ∧ code e2422374374974 = 11218467397182 := by decide
theorem cert_e2422374374974 : check e2422374374974 [[],[]] .smaller = true := by decide
def e2422374375010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422374375010 : Closed e2422374375010 ∧ code e2422374375010 = 11218467397218 := by decide
theorem cert_e2422374375010 : check e2422374375010 [[],[]] .smaller = true := by decide
def e2422374375022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374375022 : Closed e2422374375022 ∧ code e2422374375022 = 11218467397230 := by decide
theorem cert_e2422374375022 : check e2422374375022 [[],[]] .smaller = true := by decide
def e2422374375034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374375034 : Closed e2422374375034 ∧ code e2422374375034 = 11218467397242 := by decide
theorem cert_e2422374375034 : check e2422374375034 [[],[]] .smaller = true := by decide
def e2422374375198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e2422374375198 : Closed e2422374375198 ∧ code e2422374375198 = 11218467397406 := by decide
theorem cert_e2422374375198 : check e2422374375198 [[],[]] .smaller = true := by decide
def e2422374375222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374375222 : Closed e2422374375222 ∧ code e2422374375222 = 11218467397430 := by decide
theorem cert_e2422374375222 : check e2422374375222 [[],[]] .smaller = true := by decide
def e2422374375226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374375226 : Closed e2422374375226 ∧ code e2422374375226 = 11218467397434 := by decide
theorem cert_e2422374375226 : check e2422374375226 [[],[]] .smaller = true := by decide
def e2422374375322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374375322 : Closed e2422374375322 ∧ code e2422374375322 = 11218467397530 := by decide
theorem cert_e2422374375322 : check e2422374375322 [[],[]] .three = true := by decide
def e2422374386454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))))
theorem wire_e2422374386454 : Closed e2422374386454 ∧ code e2422374386454 = 11218467408662 := by decide
theorem cert_e2422374386454 : check e2422374386454 [[],[]] .smaller = true := by decide
def e2422374386526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e2422374386526 : Closed e2422374386526 ∧ code e2422374386526 = 11218467408734 := by decide
theorem cert_e2422374386526 : check e2422374386526 [[],[]] .smaller = true := by decide
def e2422374386530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))))
theorem wire_e2422374386530 : Closed e2422374386530 ∧ code e2422374386530 = 11218467408738 := by decide
theorem cert_e2422374386530 : check e2422374386530 [[],[]] .smaller = true := by decide
def e2422374386542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422374386542 : Closed e2422374386542 ∧ code e2422374386542 = 11218467408750 := by decide
theorem cert_e2422374386542 : check e2422374386542 [[],[]] .smaller = true := by decide
def e2422374386550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422374386550 : Closed e2422374386550 ∧ code e2422374386550 = 11218467408758 := by decide
theorem cert_e2422374386550 : check e2422374386550 [[],[]] .smaller = true := by decide
def e2422374386554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e2422374386554 : Closed e2422374386554 ∧ code e2422374386554 = 11218467408762 := by decide
theorem cert_e2422374386554 : check e2422374386554 [[],[]] .smaller = true := by decide
def e2422374386570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422374386570 : Closed e2422374386570 ∧ code e2422374386570 = 11218467408778 := by decide
theorem cert_e2422374386570 : check e2422374386570 [[],[]] .smaller = true := by decide
def e2422374386594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422374386594 : Closed e2422374386594 ∧ code e2422374386594 = 11218467408802 := by decide
theorem cert_e2422374386594 : check e2422374386594 [[],[]] .smaller = true := by decide
def e2422374386606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422374386606 : Closed e2422374386606 ∧ code e2422374386606 = 11218467408814 := by decide
theorem cert_e2422374386606 : check e2422374386606 [[],[]] .smaller = true := by decide
def e2422374386618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422374386618 : Closed e2422374386618 ∧ code e2422374386618 = 11218467408826 := by decide
theorem cert_e2422374386618 : check e2422374386618 [[],[]] .smaller = true := by decide
def e2422374386646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422374386646 : Closed e2422374386646 ∧ code e2422374386646 = 11218467408854 := by decide
theorem cert_e2422374386646 : check e2422374386646 [[],[]] .smaller = true := by decide
def e2422374386650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422374386650 : Closed e2422374386650 ∧ code e2422374386650 = 11218467408858 := by decide
theorem cert_e2422374386650 : check e2422374386650 [[],[]] .smaller = true := by decide
def e2422374386666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e2422374386666 : Closed e2422374386666 ∧ code e2422374386666 = 11218467408874 := by decide
theorem cert_e2422374386666 : check e2422374386666 [[],[]] .smaller = true := by decide
def e2422374386718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))))
theorem wire_e2422374386718 : Closed e2422374386718 ∧ code e2422374386718 = 11218467408926 := by decide
theorem cert_e2422374386718 : check e2422374386718 [[],[]] .smaller = true := by decide
def e2422374386910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422374386910 : Closed e2422374386910 ∧ code e2422374386910 = 11218467409118 := by decide
theorem cert_e2422374386910 : check e2422374386910 [[],[]] .smaller = true := by decide
def e2422374386914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))))
theorem wire_e2422374386914 : Closed e2422374386914 ∧ code e2422374386914 = 11218467409122 := by decide
theorem cert_e2422374386914 : check e2422374386914 [[],[]] .smaller = true := by decide
def e2422374386926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422374386926 : Closed e2422374386926 ∧ code e2422374386926 = 11218467409134 := by decide
theorem cert_e2422374386926 : check e2422374386926 [[],[]] .smaller = true := by decide
def e2422374386934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422374386934 : Closed e2422374386934 ∧ code e2422374386934 = 11218467409142 := by decide
theorem cert_e2422374386934 : check e2422374386934 [[],[]] .smaller = true := by decide
def e2422374386938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422374386938 : Closed e2422374386938 ∧ code e2422374386938 = 11218467409146 := by decide
theorem cert_e2422374386938 : check e2422374386938 [[],[]] .smaller = true := by decide
def e2422374387214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422374387214 : Closed e2422374387214 ∧ code e2422374387214 = 11218467409422 := by decide
theorem cert_e2422374387214 : check e2422374387214 [[],[]] .smaller = true := by decide
def e2422374387262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e2422374387262 : Closed e2422374387262 ∧ code e2422374387262 = 11218467409470 := by decide
theorem cert_e2422374387262 : check e2422374387262 [[],[]] .smaller = true := by decide
def e2422374387298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422374387298 : Closed e2422374387298 ∧ code e2422374387298 = 11218467409506 := by decide
theorem cert_e2422374387298 : check e2422374387298 [[],[]] .smaller = true := by decide
def e2422374387310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374387310 : Closed e2422374387310 ∧ code e2422374387310 = 11218467409518 := by decide
theorem cert_e2422374387310 : check e2422374387310 [[],[]] .smaller = true := by decide
def e2422374387322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374387322 : Closed e2422374387322 ∧ code e2422374387322 = 11218467409530 := by decide
theorem cert_e2422374387322 : check e2422374387322 [[],[]] .smaller = true := by decide
def e2422374387510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374387510 : Closed e2422374387510 ∧ code e2422374387510 = 11218467409718 := by decide
theorem cert_e2422374387510 : check e2422374387510 [[],[]] .smaller = true := by decide
def e2422374387514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374387514 : Closed e2422374387514 ∧ code e2422374387514 = 11218467409722 := by decide
theorem cert_e2422374387514 : check e2422374387514 [[],[]] .smaller = true := by decide
def e2422374387598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e2422374387598 : Closed e2422374387598 ∧ code e2422374387598 = 11218467409806 := by decide
theorem cert_e2422374387598 : check e2422374387598 [[],[]] .smaller = true := by decide
def e2422374387610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374387610 : Closed e2422374387610 ∧ code e2422374387610 = 11218467409818 := by decide
theorem cert_e2422374387610 : check e2422374387610 [[],[]] .smaller = true := by decide
def e2422374393262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422374393262 : Closed e2422374393262 ∧ code e2422374393262 = 11218467415470 := by decide
theorem cert_e2422374393262 : check e2422374393262 [[],[]] .smaller = true := by decide
def e2422374393270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422374393270 : Closed e2422374393270 ∧ code e2422374393270 = 11218467415478 := by decide
theorem cert_e2422374393270 : check e2422374393270 [[],[]] .smaller = true := by decide
def e2422374393274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422374393274 : Closed e2422374393274 ∧ code e2422374393274 = 11218467415482 := by decide
theorem cert_e2422374393274 : check e2422374393274 [[],[]] .smaller = true := by decide
def e2422374393302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422374393302 : Closed e2422374393302 ∧ code e2422374393302 = 11218467415510 := by decide
theorem cert_e2422374393302 : check e2422374393302 [[],[]] .smaller = true := by decide
def e2422374393306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422374393306 : Closed e2422374393306 ∧ code e2422374393306 = 11218467415514 := by decide
theorem cert_e2422374393306 : check e2422374393306 [[],[]] .smaller = true := by decide
def e2422374393322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422374393322 : Closed e2422374393322 ∧ code e2422374393322 = 11218467415530 := by decide
theorem cert_e2422374393322 : check e2422374393322 [[],[]] .smaller = true := by decide
def e2422374393454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422374393454 : Closed e2422374393454 ∧ code e2422374393454 = 11218467415662 := by decide
theorem cert_e2422374393454 : check e2422374393454 [[],[]] .smaller = true := by decide
def e2422374393462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422374393462 : Closed e2422374393462 ∧ code e2422374393462 = 11218467415670 := by decide
theorem cert_e2422374393462 : check e2422374393462 [[],[]] .smaller = true := by decide
def e2422374393466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422374393466 : Closed e2422374393466 ∧ code e2422374393466 = 11218467415674 := by decide
theorem cert_e2422374393466 : check e2422374393466 [[],[]] .smaller = true := by decide
def e2422374393630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422374393630 : Closed e2422374393630 ∧ code e2422374393630 = 11218467415838 := by decide
theorem cert_e2422374393630 : check e2422374393630 [[],[]] .smaller = true := by decide
def e2422374393654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374393654 : Closed e2422374393654 ∧ code e2422374393654 = 11218467415862 := by decide
theorem cert_e2422374393654 : check e2422374393654 [[],[]] .smaller = true := by decide
def e2422374393658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374393658 : Closed e2422374393658 ∧ code e2422374393658 = 11218467415866 := by decide
theorem cert_e2422374393658 : check e2422374393658 [[],[]] .smaller = true := by decide
def e2422374393742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422374393742 : Closed e2422374393742 ∧ code e2422374393742 = 11218467415950 := by decide
theorem cert_e2422374393742 : check e2422374393742 [[],[]] .smaller = true := by decide
def e2422374393754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374393754 : Closed e2422374393754 ∧ code e2422374393754 = 11218467415962 := by decide
theorem cert_e2422374393754 : check e2422374393754 [[],[]] .smaller = true := by decide
def e2422374396142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422374396142 : Closed e2422374396142 ∧ code e2422374396142 = 11218467418350 := by decide
theorem cert_e2422374396142 : check e2422374396142 [[],[]] .three = true := by decide
def e2422374396150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422374396150 : Closed e2422374396150 ∧ code e2422374396150 = 11218467418358 := by decide
theorem cert_e2422374396150 : check e2422374396150 [[],[]] .three = true := by decide
def e2422374396630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422374396630 : Closed e2422374396630 ∧ code e2422374396630 = 11218467418838 := by decide
theorem cert_e2422374396630 : check e2422374396630 [[],[]] .three = true := by decide
def e2422374396634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422374396634 : Closed e2422374396634 ∧ code e2422374396634 = 11218467418842 := by decide
theorem cert_e2422374396634 : check e2422374396634 [[],[]] .three = true := by decide
def e2422374396650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422374396650 : Closed e2422374396650 ∧ code e2422374396650 = 11218467418858 := by decide
theorem cert_e2422374396650 : check e2422374396650 [[],[]] .three = true := by decide
def e2422374396726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422374396726 : Closed e2422374396726 ∧ code e2422374396726 = 11218467418934 := by decide
theorem cert_e2422374396726 : check e2422374396726 [[],[]] .three = true := by decide
def e2422374396730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422374396730 : Closed e2422374396730 ∧ code e2422374396730 = 11218467418938 := by decide
theorem cert_e2422374396730 : check e2422374396730 [[],[]] .three = true := by decide
def e2422374396826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422374396826 : Closed e2422374396826 ∧ code e2422374396826 = 11218467419034 := by decide
theorem cert_e2422374396826 : check e2422374396826 [[],[]] .three = true := by decide
def e2422374716382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422374716382 : Closed e2422374716382 ∧ code e2422374716382 = 11218467738590 := by decide
theorem cert_e2422374716382 : check e2422374716382 [[],[]] .three = true := by decide
def e2422374716398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422374716398 : Closed e2422374716398 ∧ code e2422374716398 = 11218467738606 := by decide
theorem cert_e2422374716398 : check e2422374716398 [[],[]] .three = true := by decide
def e2422374839662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422374839662 : Closed e2422374839662 ∧ code e2422374839662 = 11218467861870 := by decide
theorem cert_e2422374839662 : check e2422374839662 [[],[]] .smaller = true := by decide
def e2422374839670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422374839670 : Closed e2422374839670 ∧ code e2422374839670 = 11218467861878 := by decide
theorem cert_e2422374839670 : check e2422374839670 [[],[]] .smaller = true := by decide
def e2422374839726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422374839726 : Closed e2422374839726 ∧ code e2422374839726 = 11218467861934 := by decide
theorem cert_e2422374839726 : check e2422374839726 [[],[]] .smaller = true := by decide
def e2422374839738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422374839738 : Closed e2422374839738 ∧ code e2422374839738 = 11218467861946 := by decide
theorem cert_e2422374839738 : check e2422374839738 [[],[]] .smaller = true := by decide
def e2422374839766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422374839766 : Closed e2422374839766 ∧ code e2422374839766 = 11218467861974 := by decide
theorem cert_e2422374839766 : check e2422374839766 [[],[]] .smaller = true := by decide
def e2422374839770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422374839770 : Closed e2422374839770 ∧ code e2422374839770 = 11218467861978 := by decide
theorem cert_e2422374839770 : check e2422374839770 [[],[]] .smaller = true := by decide
def e2422374839982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422374839982 : Closed e2422374839982 ∧ code e2422374839982 = 11218467862190 := by decide
theorem cert_e2422374839982 : check e2422374839982 [[],[]] .smaller = true := by decide
def e2422374839994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422374839994 : Closed e2422374839994 ∧ code e2422374839994 = 11218467862202 := by decide
theorem cert_e2422374839994 : check e2422374839994 [[],[]] .smaller = true := by decide
def e2422374840042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422374840042 : Closed e2422374840042 ∧ code e2422374840042 = 11218467862250 := by decide
theorem cert_e2422374840042 : check e2422374840042 [[],[]] .smaller = true := by decide
def e2422374840150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422374840150 : Closed e2422374840150 ∧ code e2422374840150 = 11218467862358 := by decide
theorem cert_e2422374840150 : check e2422374840150 [[],[]] .smaller = true := by decide
def e2422374840154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422374840154 : Closed e2422374840154 ∧ code e2422374840154 = 11218467862362 := by decide
theorem cert_e2422374840154 : check e2422374840154 [[],[]] .smaller = true := by decide
def e2422374840170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422374840170 : Closed e2422374840170 ∧ code e2422374840170 = 11218467862378 := by decide
theorem cert_e2422374840170 : check e2422374840170 [[],[]] .smaller = true := by decide
def e2422374841006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422374841006 : Closed e2422374841006 ∧ code e2422374841006 = 11218467863214 := by decide
theorem cert_e2422374841006 : check e2422374841006 [[],[]] .smaller = true := by decide
def e2422374841018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422374841018 : Closed e2422374841018 ∧ code e2422374841018 = 11218467863226 := by decide
theorem cert_e2422374841018 : check e2422374841018 [[],[]] .smaller = true := by decide
def e2422374841066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422374841066 : Closed e2422374841066 ∧ code e2422374841066 = 11218467863274 := by decide
theorem cert_e2422374841066 : check e2422374841066 [[],[]] .smaller = true := by decide
def e2422374841258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422374841258 : Closed e2422374841258 ∧ code e2422374841258 = 11218467863466 := by decide
theorem cert_e2422374841258 : check e2422374841258 [[],[]] .smaller = true := by decide
def e2422374841686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422374841686 : Closed e2422374841686 ∧ code e2422374841686 = 11218467863894 := by decide
theorem cert_e2422374841686 : check e2422374841686 [[],[]] .smaller = true := by decide
def e2422374841690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422374841690 : Closed e2422374841690 ∧ code e2422374841690 = 11218467863898 := by decide
theorem cert_e2422374841690 : check e2422374841690 [[],[]] .smaller = true := by decide
def e2422374841706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422374841706 : Closed e2422374841706 ∧ code e2422374841706 = 11218467863914 := by decide
theorem cert_e2422374841706 : check e2422374841706 [[],[]] .smaller = true := by decide
def e2422374841770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422374841770 : Closed e2422374841770 ∧ code e2422374841770 = 11218467863978 := by decide
theorem cert_e2422374841770 : check e2422374841770 [[],[]] .smaller = true := by decide
def e2422374842734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2))))))))
theorem wire_e2422374842734 : Closed e2422374842734 ∧ code e2422374842734 = 11218467864942 := by decide
theorem cert_e2422374842734 : check e2422374842734 [[],[]] .smaller = true := by decide
def e2422374842742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1))))))))
theorem wire_e2422374842742 : Closed e2422374842742 ∧ code e2422374842742 = 11218467864950 := by decide
theorem cert_e2422374842742 : check e2422374842742 [[],[]] .smaller = true := by decide
def e2422374843870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 3))))))))
theorem wire_e2422374843870 : Closed e2422374843870 ∧ code e2422374843870 = 11218467866078 := by decide
theorem cert_e2422374843870 : check e2422374843870 [[],[]] .three = true := by decide
def e2422374843886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 2))))))))
theorem wire_e2422374843886 : Closed e2422374843886 ∧ code e2422374843886 = 11218467866094 := by decide
theorem cert_e2422374843886 : check e2422374843886 [[],[]] .three = true := by decide
def e2422374844126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3))))))))
theorem wire_e2422374844126 : Closed e2422374844126 ∧ code e2422374844126 = 11218467866334 := by decide
theorem cert_e2422374844126 : check e2422374844126 [[],[]] .three = true := by decide
def e2422374844150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1))))))))
theorem wire_e2422374844150 : Closed e2422374844150 ∧ code e2422374844150 = 11218467866358 := by decide
theorem cert_e2422374844150 : check e2422374844150 [[],[]] .three = true := by decide
def e2422374844254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3))))))))
theorem wire_e2422374844254 : Closed e2422374844254 ∧ code e2422374844254 = 11218467866462 := by decide
theorem cert_e2422374844254 : check e2422374844254 [[],[]] .three = true := by decide
def e2422374844270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))))
theorem wire_e2422374844270 : Closed e2422374844270 ∧ code e2422374844270 = 11218467866478 := by decide
theorem cert_e2422374844270 : check e2422374844270 [[],[]] .smaller = true := by decide
def e2422374844278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))))
theorem wire_e2422374844278 : Closed e2422374844278 ∧ code e2422374844278 = 11218467866486 := by decide
theorem cert_e2422374844278 : check e2422374844278 [[],[]] .smaller = true := by decide
def e2422374844282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0))))))))
theorem wire_e2422374844282 : Closed e2422374844282 ∧ code e2422374844282 = 11218467866490 := by decide
theorem cert_e2422374844282 : check e2422374844282 [[],[]] .three = true := by decide
def e2422374844342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))))
theorem wire_e2422374844342 : Closed e2422374844342 ∧ code e2422374844342 = 11218467866550 := by decide
theorem cert_e2422374844342 : check e2422374844342 [[],[]] .smaller = true := by decide
def e2422374844374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1))))))))
theorem wire_e2422374844374 : Closed e2422374844374 ∧ code e2422374844374 = 11218467866582 := by decide
theorem cert_e2422374844374 : check e2422374844374 [[],[]] .three = true := by decide
def e2422374844378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0))))))))
theorem wire_e2422374844378 : Closed e2422374844378 ∧ code e2422374844378 = 11218467866586 := by decide
theorem cert_e2422374844378 : check e2422374844378 [[],[]] .three = true := by decide
def e2422374845806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e2422374845806 : Closed e2422374845806 ∧ code e2422374845806 = 11218467868014 := by decide
theorem cert_e2422374845806 : check e2422374845806 [[],[]] .smaller = true := by decide
def e2422374845814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e2422374845814 : Closed e2422374845814 ∧ code e2422374845814 = 11218467868022 := by decide
theorem cert_e2422374845814 : check e2422374845814 [[],[]] .smaller = true := by decide
def e2422374845870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e2422374845870 : Closed e2422374845870 ∧ code e2422374845870 = 11218467868078 := by decide
theorem cert_e2422374845870 : check e2422374845870 [[],[]] .smaller = true := by decide
def e2422374845882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e2422374845882 : Closed e2422374845882 ∧ code e2422374845882 = 11218467868090 := by decide
theorem cert_e2422374845882 : check e2422374845882 [[],[]] .smaller = true := by decide
def e2422374845910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e2422374845910 : Closed e2422374845910 ∧ code e2422374845910 = 11218467868118 := by decide
theorem cert_e2422374845910 : check e2422374845910 [[],[]] .smaller = true := by decide
def e2422374845914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e2422374845914 : Closed e2422374845914 ∧ code e2422374845914 = 11218467868122 := by decide
theorem cert_e2422374845914 : check e2422374845914 [[],[]] .smaller = true := by decide
def e2422374846126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422374846126 : Closed e2422374846126 ∧ code e2422374846126 = 11218467868334 := by decide
theorem cert_e2422374846126 : check e2422374846126 [[],[]] .smaller = true := by decide
def e2422374846138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422374846138 : Closed e2422374846138 ∧ code e2422374846138 = 11218467868346 := by decide
theorem cert_e2422374846138 : check e2422374846138 [[],[]] .smaller = true := by decide
def e2422374846186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422374846186 : Closed e2422374846186 ∧ code e2422374846186 = 11218467868394 := by decide
theorem cert_e2422374846186 : check e2422374846186 [[],[]] .smaller = true := by decide
end Blc.Floor43
