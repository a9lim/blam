import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e597487039406 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e597487039406 : Closed e597487039406 ∧ code e597487039406 = 9393580061614 := by decide
theorem cert_e597487039406 : check e597487039406 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487039418 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e597487039418 : Closed e597487039418 ∧ code e597487039418 = 9393580061626 := by decide
theorem cert_e597487039418 : check e597487039418 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487039446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e597487039446 : Closed e597487039446 ∧ code e597487039446 = 9393580061654 := by decide
theorem cert_e597487039446 : check e597487039446 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487039450 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e597487039450 : Closed e597487039450 ∧ code e597487039450 = 9393580061658 := by decide
theorem cert_e597487039450 : check e597487039450 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487039726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e597487039726 : Closed e597487039726 ∧ code e597487039726 = 9393580061934 := by decide
theorem cert_e597487039726 : check e597487039726 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487039734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e597487039734 : Closed e597487039734 ∧ code e597487039734 = 9393580061942 := by decide
theorem cert_e597487039734 : check e597487039734 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487040110 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e597487040110 : Closed e597487040110 ∧ code e597487040110 = 9393580062318 := by decide
theorem cert_e597487040110 : check e597487040110 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487040122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e597487040122 : Closed e597487040122 ∧ code e597487040122 = 9393580062330 := by decide
theorem cert_e597487040122 : check e597487040122 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487040310 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e597487040310 : Closed e597487040310 ∧ code e597487040310 = 9393580062518 := by decide
theorem cert_e597487040310 : check e597487040310 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487040314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e597487040314 : Closed e597487040314 ∧ code e597487040314 = 9393580062522 := by decide
theorem cert_e597487040314 : check e597487040314 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487040942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e597487040942 : Closed e597487040942 ∧ code e597487040942 = 9393580063150 := by decide
theorem cert_e597487040942 : check e597487040942 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487040954 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e597487040954 : Closed e597487040954 ∧ code e597487040954 = 9393580063162 := by decide
theorem cert_e597487040954 : check e597487040954 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e597487041002 : Closed e597487041002 ∧ code e597487041002 = 9393580063210 := by decide
theorem cert_e597487041002 : check e597487041002 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e597487041134 : Closed e597487041134 ∧ code e597487041134 = 9393580063342 := by decide
theorem cert_e597487041134 : check e597487041134 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041146 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e597487041146 : Closed e597487041146 ∧ code e597487041146 = 9393580063354 := by decide
theorem cert_e597487041146 : check e597487041146 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e597487041434 : Closed e597487041434 ∧ code e597487041434 = 9393580063642 := by decide
theorem cert_e597487041434 : check e597487041434 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041750 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e597487041750 : Closed e597487041750 ∧ code e597487041750 = 9393580063958 := by decide
theorem cert_e597487041750 : check e597487041750 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041754 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e597487041754 : Closed e597487041754 ∧ code e597487041754 = 9393580063962 := by decide
theorem cert_e597487041754 : check e597487041754 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e597487041770 : Closed e597487041770 ∧ code e597487041770 = 9393580063978 := by decide
theorem cert_e597487041770 : check e597487041770 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e597487041846 : Closed e597487041846 ∧ code e597487041846 = 9393580064054 := by decide
theorem cert_e597487041846 : check e597487041846 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041850 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e597487041850 : Closed e597487041850 ∧ code e597487041850 = 9393580064058 := by decide
theorem cert_e597487041850 : check e597487041850 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487041946 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e597487041946 : Closed e597487041946 ∧ code e597487041946 = 9393580064154 := by decide
theorem cert_e597487041946 : check e597487041946 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597487045486 : Closed e597487045486 ∧ code e597487045486 = 9393580067694 := by decide
theorem cert_e597487045486 : check e597487045486 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045494 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597487045494 : Closed e597487045494 ∧ code e597487045494 = 9393580067702 := by decide
theorem cert_e597487045494 : check e597487045494 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045550 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597487045550 : Closed e597487045550 ∧ code e597487045550 = 9393580067758 := by decide
theorem cert_e597487045550 : check e597487045550 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045562 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597487045562 : Closed e597487045562 ∧ code e597487045562 = 9393580067770 := by decide
theorem cert_e597487045562 : check e597487045562 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597487045590 : Closed e597487045590 ∧ code e597487045590 = 9393580067798 := by decide
theorem cert_e597487045590 : check e597487045590 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045594 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597487045594 : Closed e597487045594 ∧ code e597487045594 = 9393580067802 := by decide
theorem cert_e597487045594 : check e597487045594 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597487045870 : Closed e597487045870 ∧ code e597487045870 = 9393580068078 := by decide
theorem cert_e597487045870 : check e597487045870 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487045878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597487045878 : Closed e597487045878 ∧ code e597487045878 = 9393580068086 := by decide
theorem cert_e597487045878 : check e597487045878 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487046254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597487046254 : Closed e597487046254 ∧ code e597487046254 = 9393580068462 := by decide
theorem cert_e597487046254 : check e597487046254 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487046266 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597487046266 : Closed e597487046266 ∧ code e597487046266 = 9393580068474 := by decide
theorem cert_e597487046266 : check e597487046266 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487046454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597487046454 : Closed e597487046454 ∧ code e597487046454 = 9393580068662 := by decide
theorem cert_e597487046454 : check e597487046454 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487046458 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597487046458 : Closed e597487046458 ∧ code e597487046458 = 9393580068666 := by decide
theorem cert_e597487046458 : check e597487046458 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487052206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e597487052206 : Closed e597487052206 ∧ code e597487052206 = 9393580074414 := by decide
theorem cert_e597487052206 : check e597487052206 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487052218 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e597487052218 : Closed e597487052218 ∧ code e597487052218 = 9393580074426 := by decide
theorem cert_e597487052218 : check e597487052218 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487052266 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e597487052266 : Closed e597487052266 ∧ code e597487052266 = 9393580074474 := by decide
theorem cert_e597487052266 : check e597487052266 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487052398 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e597487052398 : Closed e597487052398 ∧ code e597487052398 = 9393580074606 := by decide
theorem cert_e597487052398 : check e597487052398 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487052410 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e597487052410 : Closed e597487052410 ∧ code e597487052410 = 9393580074618 := by decide
theorem cert_e597487052410 : check e597487052410 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487052698 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e597487052698 : Closed e597487052698 ∧ code e597487052698 = 9393580074906 := by decide
theorem cert_e597487052698 : check e597487052698 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487055574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e597487055574 : Closed e597487055574 ∧ code e597487055574 = 9393580077782 := by decide
theorem cert_e597487055574 : check e597487055574 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487055578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e597487055578 : Closed e597487055578 ∧ code e597487055578 = 9393580077786 := by decide
theorem cert_e597487055578 : check e597487055578 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487055594 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e597487055594 : Closed e597487055594 ∧ code e597487055594 = 9393580077802 := by decide
theorem cert_e597487055594 : check e597487055594 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487055670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e597487055670 : Closed e597487055670 ∧ code e597487055670 = 9393580077878 := by decide
theorem cert_e597487055670 : check e597487055670 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487055674 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e597487055674 : Closed e597487055674 ∧ code e597487055674 = 9393580077882 := by decide
theorem cert_e597487055674 : check e597487055674 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487055770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e597487055770 : Closed e597487055770 ∧ code e597487055770 = 9393580077978 := by decide
theorem cert_e597487055770 : check e597487055770 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487192942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597487192942 : Closed e597487192942 ∧ code e597487192942 = 9393580215150 := by decide
theorem cert_e597487192942 : check e597487192942 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487192950 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597487192950 : Closed e597487192950 ∧ code e597487192950 = 9393580215158 := by decide
theorem cert_e597487192950 : check e597487192950 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597487193006 : Closed e597487193006 ∧ code e597487193006 = 9393580215214 := by decide
theorem cert_e597487193006 : check e597487193006 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597487193018 : Closed e597487193018 ∧ code e597487193018 = 9393580215226 := by decide
theorem cert_e597487193018 : check e597487193018 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597487193046 : Closed e597487193046 ∧ code e597487193046 = 9393580215254 := by decide
theorem cert_e597487193046 : check e597487193046 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193050 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597487193050 : Closed e597487193050 ∧ code e597487193050 = 9393580215258 := by decide
theorem cert_e597487193050 : check e597487193050 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597487193326 : Closed e597487193326 ∧ code e597487193326 = 9393580215534 := by decide
theorem cert_e597487193326 : check e597487193326 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597487193334 : Closed e597487193334 ∧ code e597487193334 = 9393580215542 := by decide
theorem cert_e597487193334 : check e597487193334 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597487193710 : Closed e597487193710 ∧ code e597487193710 = 9393580215918 := by decide
theorem cert_e597487193710 : check e597487193710 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193722 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597487193722 : Closed e597487193722 ∧ code e597487193722 = 9393580215930 := by decide
theorem cert_e597487193722 : check e597487193722 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597487193910 : Closed e597487193910 ∧ code e597487193910 = 9393580216118 := by decide
theorem cert_e597487193910 : check e597487193910 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487193914 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597487193914 : Closed e597487193914 ∧ code e597487193914 = 9393580216122 := by decide
theorem cert_e597487193914 : check e597487193914 [[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e597487782766 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597487782766 : Closed e597487782766 ∧ code e597487782766 = 9393580804974 := by decide
theorem cert_e597487782766 : check e597487782766 [[.under],[.under,.left]] .chain = true := by decide
def e597487782774 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597487782774 : Closed e597487782774 ∧ code e597487782774 = 9393580804982 := by decide
theorem cert_e597487782774 : check e597487782774 [[.under],[.under,.left]] .chain = true := by decide
def e597487782830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597487782830 : Closed e597487782830 ∧ code e597487782830 = 9393580805038 := by decide
theorem cert_e597487782830 : check e597487782830 [[.under],[.under,.left]] .chain = true := by decide
def e597487782842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597487782842 : Closed e597487782842 ∧ code e597487782842 = 9393580805050 := by decide
theorem cert_e597487782842 : check e597487782842 [[.under],[.under,.left]] .chain = true := by decide
def e597487782870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597487782870 : Closed e597487782870 ∧ code e597487782870 = 9393580805078 := by decide
theorem cert_e597487782870 : check e597487782870 [[.under],[.under,.left]] .chain = true := by decide
def e597487782874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597487782874 : Closed e597487782874 ∧ code e597487782874 = 9393580805082 := by decide
theorem cert_e597487782874 : check e597487782874 [[.under],[.under,.left]] .chain = true := by decide
def e597487783150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597487783150 : Closed e597487783150 ∧ code e597487783150 = 9393580805358 := by decide
theorem cert_e597487783150 : check e597487783150 [[.under],[.under,.left]] .chain = true := by decide
def e597487783158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597487783158 : Closed e597487783158 ∧ code e597487783158 = 9393580805366 := by decide
theorem cert_e597487783158 : check e597487783158 [[.under],[.under,.left]] .chain = true := by decide
def e597487783534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597487783534 : Closed e597487783534 ∧ code e597487783534 = 9393580805742 := by decide
theorem cert_e597487783534 : check e597487783534 [[.under],[.under,.left]] .chain = true := by decide
def e597487783546 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597487783546 : Closed e597487783546 ∧ code e597487783546 = 9393580805754 := by decide
theorem cert_e597487783546 : check e597487783546 [[.under],[.under,.left]] .chain = true := by decide
def e597487783734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597487783734 : Closed e597487783734 ∧ code e597487783734 = 9393580805942 := by decide
theorem cert_e597487783734 : check e597487783734 [[.under],[.under,.left]] .chain = true := by decide
def e597487783738 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597487783738 : Closed e597487783738 ∧ code e597487783738 = 9393580805946 := by decide
theorem cert_e597487783738 : check e597487783738 [[.under],[.under,.left]] .chain = true := by decide
def e598086182426 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086182426 : Closed e598086182426 ∧ code e598086182426 = 9394179204634 := by decide
theorem cert_e598086182426 : check e598086182426 [[.under]] .width = true := by decide
def e598086215194 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086215194 : Closed e598086215194 ∧ code e598086215194 = 9394179237402 := by decide
theorem cert_e598086215194 : check e598086215194 [[.under]] .width = true := by decide
def e598086444570 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086444570 : Closed e598086444570 ∧ code e598086444570 = 9394179466778 := by decide
theorem cert_e598086444570 : check e598086444570 [[.under]] .width = true := by decide
def e598086493722 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086493722 : Closed e598086493722 ∧ code e598086493722 = 9394179515930 := by decide
theorem cert_e598086493722 : check e598086493722 [[.under]] .width = true := by decide
def e598086608410 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086608410 : Closed e598086608410 ∧ code e598086608410 = 9394179630618 := by decide
theorem cert_e598086608410 : check e598086608410 [[.under]] .width = true := by decide
def e598086624794 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598086624794 : Closed e598086624794 ∧ code e598086624794 = 9394179647002 := by decide
theorem cert_e598086624794 : check e598086624794 [[.under]] .width = true := by decide
def e598087755290 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598087755290 : Closed e598087755290 ∧ code e598087755290 = 9394180777498 := by decide
theorem cert_e598087755290 : check e598087755290 [[.under]] .width = true := by decide
def e598087788058 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598087788058 : Closed e598087788058 ∧ code e598087788058 = 9394180810266 := by decide
theorem cert_e598087788058 : check e598087788058 [[.under]] .width = true := by decide
def e598089328154 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598089328154 : Closed e598089328154 ∧ code e598089328154 = 9394182350362 := by decide
theorem cert_e598089328154 : check e598089328154 [[.under]] .width = true := by decide
def e598089377306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598089377306 : Closed e598089377306 ∧ code e598089377306 = 9394182399514 := by decide
theorem cert_e598089377306 : check e598089377306 [[.under]] .width = true := by decide
def e598090147354 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598090147354 : Closed e598090147354 ∧ code e598090147354 = 9394183169562 := by decide
theorem cert_e598090147354 : check e598090147354 [[.under]] .width = true := by decide
def e598090163738 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e598090163738 : Closed e598090163738 ∧ code e598090163738 = 9394183185946 := by decide
theorem cert_e598090163738 : check e598090163738 [[.under]] .width = true := by decide
def e598191680878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e598191680878 : Closed e598191680878 ∧ code e598191680878 = 9394284703086 := by decide
theorem cert_e598191680878 : check e598191680878 [[.under],[.under,.left]] .chain = true := by decide
def e598191680886 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e598191680886 : Closed e598191680886 ∧ code e598191680886 = 9394284703094 := by decide
theorem cert_e598191680886 : check e598191680886 [[.under],[.under,.left]] .chain = true := by decide
def e598191680942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e598191680942 : Closed e598191680942 ∧ code e598191680942 = 9394284703150 := by decide
theorem cert_e598191680942 : check e598191680942 [[.under],[.under,.left]] .chain = true := by decide
def e598191680954 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e598191680954 : Closed e598191680954 ∧ code e598191680954 = 9394284703162 := by decide
theorem cert_e598191680954 : check e598191680954 [[.under],[.under,.left]] .chain = true := by decide
def e598191680982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e598191680982 : Closed e598191680982 ∧ code e598191680982 = 9394284703190 := by decide
theorem cert_e598191680982 : check e598191680982 [[.under],[.under,.left]] .chain = true := by decide
def e598191680986 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e598191680986 : Closed e598191680986 ∧ code e598191680986 = 9394284703194 := by decide
theorem cert_e598191680986 : check e598191680986 [[.under],[.under,.left]] .chain = true := by decide
def e598191681198 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598191681198 : Closed e598191681198 ∧ code e598191681198 = 9394284703406 := by decide
theorem cert_e598191681198 : check e598191681198 [[.under],[.under,.left]] .chain = true := by decide
def e598191681210 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598191681210 : Closed e598191681210 ∧ code e598191681210 = 9394284703418 := by decide
theorem cert_e598191681210 : check e598191681210 [[.under],[.under,.left]] .chain = true := by decide
def e598191681258 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598191681258 : Closed e598191681258 ∧ code e598191681258 = 9394284703466 := by decide
theorem cert_e598191681258 : check e598191681258 [[.under],[.under,.left]] .chain = true := by decide
def e598191681366 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e598191681366 : Closed e598191681366 ∧ code e598191681366 = 9394284703574 := by decide
theorem cert_e598191681366 : check e598191681366 [[.under],[.under,.left]] .chain = true := by decide
def e598191681370 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e598191681370 : Closed e598191681370 ∧ code e598191681370 = 9394284703578 := by decide
theorem cert_e598191681370 : check e598191681370 [[.under],[.under,.left]] .chain = true := by decide
def e598191681386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e598191681386 : Closed e598191681386 ∧ code e598191681386 = 9394284703594 := by decide
theorem cert_e598191681386 : check e598191681386 [[.under],[.under,.left]] .chain = true := by decide
def e598191682414 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e598191682414 : Closed e598191682414 ∧ code e598191682414 = 9394284704622 := by decide
theorem cert_e598191682414 : check e598191682414 [[.under],[.under,.left]] .chain = true := by decide
def e598191682422 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e598191682422 : Closed e598191682422 ∧ code e598191682422 = 9394284704630 := by decide
theorem cert_e598191682422 : check e598191682422 [[.under],[.under,.left]] .chain = true := by decide
def e598191682478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e598191682478 : Closed e598191682478 ∧ code e598191682478 = 9394284704686 := by decide
theorem cert_e598191682478 : check e598191682478 [[.under],[.under,.left]] .chain = true := by decide
def e598191682490 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e598191682490 : Closed e598191682490 ∧ code e598191682490 = 9394284704698 := by decide
theorem cert_e598191682490 : check e598191682490 [[.under],[.under,.left]] .chain = true := by decide
def e598191682518 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e598191682518 : Closed e598191682518 ∧ code e598191682518 = 9394284704726 := by decide
theorem cert_e598191682518 : check e598191682518 [[.under],[.under,.left]] .chain = true := by decide
def e598191682522 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e598191682522 : Closed e598191682522 ∧ code e598191682522 = 9394284704730 := by decide
theorem cert_e598191682522 : check e598191682522 [[.under],[.under,.left]] .chain = true := by decide
def e598191682798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e598191682798 : Closed e598191682798 ∧ code e598191682798 = 9394284705006 := by decide
theorem cert_e598191682798 : check e598191682798 [[.under],[.under,.left]] .chain = true := by decide
def e598191682806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e598191682806 : Closed e598191682806 ∧ code e598191682806 = 9394284705014 := by decide
theorem cert_e598191682806 : check e598191682806 [[.under],[.under,.left]] .chain = true := by decide
def e598191683182 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e598191683182 : Closed e598191683182 ∧ code e598191683182 = 9394284705390 := by decide
theorem cert_e598191683182 : check e598191683182 [[.under],[.under,.left]] .chain = true := by decide
def e598191683194 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e598191683194 : Closed e598191683194 ∧ code e598191683194 = 9394284705402 := by decide
theorem cert_e598191683194 : check e598191683194 [[.under],[.under,.left]] .chain = true := by decide
def e598191683382 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e598191683382 : Closed e598191683382 ∧ code e598191683382 = 9394284705590 := by decide
theorem cert_e598191683382 : check e598191683382 [[.under],[.under,.left]] .chain = true := by decide
def e598191683386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e598191683386 : Closed e598191683386 ∧ code e598191683386 = 9394284705594 := by decide
theorem cert_e598191683386 : check e598191683386 [[.under],[.under,.left]] .chain = true := by decide
def e598191684014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598191684014 : Closed e598191684014 ∧ code e598191684014 = 9394284706222 := by decide
theorem cert_e598191684014 : check e598191684014 [[.under],[.under,.left]] .chain = true := by decide
def e598191684026 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598191684026 : Closed e598191684026 ∧ code e598191684026 = 9394284706234 := by decide
theorem cert_e598191684026 : check e598191684026 [[.under],[.under,.left]] .chain = true := by decide
def e598191684074 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598191684074 : Closed e598191684074 ∧ code e598191684074 = 9394284706282 := by decide
theorem cert_e598191684074 : check e598191684074 [[.under],[.under,.left]] .chain = true := by decide
def e598191684206 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598191684206 : Closed e598191684206 ∧ code e598191684206 = 9394284706414 := by decide
theorem cert_e598191684206 : check e598191684206 [[.under],[.under,.left]] .chain = true := by decide
def e598191684218 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598191684218 : Closed e598191684218 ∧ code e598191684218 = 9394284706426 := by decide
theorem cert_e598191684218 : check e598191684218 [[.under],[.under,.left]] .chain = true := by decide
def e598191684506 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598191684506 : Closed e598191684506 ∧ code e598191684506 = 9394284706714 := by decide
theorem cert_e598191684506 : check e598191684506 [[.under],[.under,.left]] .chain = true := by decide
def e598191684822 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e598191684822 : Closed e598191684822 ∧ code e598191684822 = 9394284707030 := by decide
theorem cert_e598191684822 : check e598191684822 [[.under],[.under,.left]] .chain = true := by decide
def e598191684826 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e598191684826 : Closed e598191684826 ∧ code e598191684826 = 9394284707034 := by decide
theorem cert_e598191684826 : check e598191684826 [[.under],[.under,.left]] .chain = true := by decide
def e598191684842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e598191684842 : Closed e598191684842 ∧ code e598191684842 = 9394284707050 := by decide
theorem cert_e598191684842 : check e598191684842 [[.under],[.under,.left]] .chain = true := by decide
def e598191684918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e598191684918 : Closed e598191684918 ∧ code e598191684918 = 9394284707126 := by decide
theorem cert_e598191684918 : check e598191684918 [[.under],[.under,.left]] .chain = true := by decide
def e598191684922 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e598191684922 : Closed e598191684922 ∧ code e598191684922 = 9394284707130 := by decide
theorem cert_e598191684922 : check e598191684922 [[.under],[.under,.left]] .chain = true := by decide
def e598191685018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e598191685018 : Closed e598191685018 ∧ code e598191685018 = 9394284707226 := by decide
theorem cert_e598191685018 : check e598191685018 [[.under],[.under,.left]] .chain = true := by decide
def e598191688558 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598191688558 : Closed e598191688558 ∧ code e598191688558 = 9394284710766 := by decide
theorem cert_e598191688558 : check e598191688558 [[.under],[.under,.left]] .chain = true := by decide
def e598191688566 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598191688566 : Closed e598191688566 ∧ code e598191688566 = 9394284710774 := by decide
theorem cert_e598191688566 : check e598191688566 [[.under],[.under,.left]] .chain = true := by decide
def e598191688622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598191688622 : Closed e598191688622 ∧ code e598191688622 = 9394284710830 := by decide
theorem cert_e598191688622 : check e598191688622 [[.under],[.under,.left]] .chain = true := by decide
def e598191688634 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598191688634 : Closed e598191688634 ∧ code e598191688634 = 9394284710842 := by decide
theorem cert_e598191688634 : check e598191688634 [[.under],[.under,.left]] .chain = true := by decide
def e598191688662 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598191688662 : Closed e598191688662 ∧ code e598191688662 = 9394284710870 := by decide
theorem cert_e598191688662 : check e598191688662 [[.under],[.under,.left]] .chain = true := by decide
def e598191688666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598191688666 : Closed e598191688666 ∧ code e598191688666 = 9394284710874 := by decide
theorem cert_e598191688666 : check e598191688666 [[.under],[.under,.left]] .chain = true := by decide
def e598191688942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598191688942 : Closed e598191688942 ∧ code e598191688942 = 9394284711150 := by decide
theorem cert_e598191688942 : check e598191688942 [[.under],[.under,.left]] .chain = true := by decide
def e598191688950 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598191688950 : Closed e598191688950 ∧ code e598191688950 = 9394284711158 := by decide
theorem cert_e598191688950 : check e598191688950 [[.under],[.under,.left]] .chain = true := by decide
def e598191689326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598191689326 : Closed e598191689326 ∧ code e598191689326 = 9394284711534 := by decide
theorem cert_e598191689326 : check e598191689326 [[.under],[.under,.left]] .chain = true := by decide
def e598191689338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598191689338 : Closed e598191689338 ∧ code e598191689338 = 9394284711546 := by decide
theorem cert_e598191689338 : check e598191689338 [[.under],[.under,.left]] .chain = true := by decide
def e598191689526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598191689526 : Closed e598191689526 ∧ code e598191689526 = 9394284711734 := by decide
theorem cert_e598191689526 : check e598191689526 [[.under],[.under,.left]] .chain = true := by decide
def e598191689530 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598191689530 : Closed e598191689530 ∧ code e598191689530 = 9394284711738 := by decide
theorem cert_e598191689530 : check e598191689530 [[.under],[.under,.left]] .chain = true := by decide
def e598191695278 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598191695278 : Closed e598191695278 ∧ code e598191695278 = 9394284717486 := by decide
theorem cert_e598191695278 : check e598191695278 [[.under],[.under,.left]] .chain = true := by decide
def e598191695290 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598191695290 : Closed e598191695290 ∧ code e598191695290 = 9394284717498 := by decide
theorem cert_e598191695290 : check e598191695290 [[.under],[.under,.left]] .chain = true := by decide
def e598191695338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598191695338 : Closed e598191695338 ∧ code e598191695338 = 9394284717546 := by decide
theorem cert_e598191695338 : check e598191695338 [[.under],[.under,.left]] .chain = true := by decide
def e598191695470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598191695470 : Closed e598191695470 ∧ code e598191695470 = 9394284717678 := by decide
theorem cert_e598191695470 : check e598191695470 [[.under],[.under,.left]] .chain = true := by decide
def e598191695482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598191695482 : Closed e598191695482 ∧ code e598191695482 = 9394284717690 := by decide
theorem cert_e598191695482 : check e598191695482 [[.under],[.under,.left]] .chain = true := by decide
def e598191695770 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598191695770 : Closed e598191695770 ∧ code e598191695770 = 9394284717978 := by decide
theorem cert_e598191695770 : check e598191695770 [[.under],[.under,.left]] .chain = true := by decide
def e598191698646 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e598191698646 : Closed e598191698646 ∧ code e598191698646 = 9394284720854 := by decide
theorem cert_e598191698646 : check e598191698646 [[.under],[.under,.left]] .chain = true := by decide
def e598191698650 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e598191698650 : Closed e598191698650 ∧ code e598191698650 = 9394284720858 := by decide
theorem cert_e598191698650 : check e598191698650 [[.under],[.under,.left]] .chain = true := by decide
def e598191698666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e598191698666 : Closed e598191698666 ∧ code e598191698666 = 9394284720874 := by decide
theorem cert_e598191698666 : check e598191698666 [[.under],[.under,.left]] .chain = true := by decide
def e598191698742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e598191698742 : Closed e598191698742 ∧ code e598191698742 = 9394284720950 := by decide
theorem cert_e598191698742 : check e598191698742 [[.under],[.under,.left]] .chain = true := by decide
def e598191698746 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e598191698746 : Closed e598191698746 ∧ code e598191698746 = 9394284720954 := by decide
theorem cert_e598191698746 : check e598191698746 [[.under],[.under,.left]] .chain = true := by decide
def e598191698842 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e598191698842 : Closed e598191698842 ∧ code e598191698842 = 9394284721050 := by decide
theorem cert_e598191698842 : check e598191698842 [[.under],[.under,.left]] .chain = true := by decide
def e598191836014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598191836014 : Closed e598191836014 ∧ code e598191836014 = 9394284858222 := by decide
theorem cert_e598191836014 : check e598191836014 [[.under],[.under,.left]] .chain = true := by decide
def e598191836022 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598191836022 : Closed e598191836022 ∧ code e598191836022 = 9394284858230 := by decide
theorem cert_e598191836022 : check e598191836022 [[.under],[.under,.left]] .chain = true := by decide
def e598191836078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598191836078 : Closed e598191836078 ∧ code e598191836078 = 9394284858286 := by decide
theorem cert_e598191836078 : check e598191836078 [[.under],[.under,.left]] .chain = true := by decide
def e598191836090 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598191836090 : Closed e598191836090 ∧ code e598191836090 = 9394284858298 := by decide
theorem cert_e598191836090 : check e598191836090 [[.under],[.under,.left]] .chain = true := by decide
def e598191836118 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598191836118 : Closed e598191836118 ∧ code e598191836118 = 9394284858326 := by decide
theorem cert_e598191836118 : check e598191836118 [[.under],[.under,.left]] .chain = true := by decide
def e598191836122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598191836122 : Closed e598191836122 ∧ code e598191836122 = 9394284858330 := by decide
theorem cert_e598191836122 : check e598191836122 [[.under],[.under,.left]] .chain = true := by decide
def e598191836398 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598191836398 : Closed e598191836398 ∧ code e598191836398 = 9394284858606 := by decide
theorem cert_e598191836398 : check e598191836398 [[.under],[.under,.left]] .chain = true := by decide
def e598191836406 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598191836406 : Closed e598191836406 ∧ code e598191836406 = 9394284858614 := by decide
theorem cert_e598191836406 : check e598191836406 [[.under],[.under,.left]] .chain = true := by decide
def e598191836782 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598191836782 : Closed e598191836782 ∧ code e598191836782 = 9394284858990 := by decide
theorem cert_e598191836782 : check e598191836782 [[.under],[.under,.left]] .chain = true := by decide
def e598191836794 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598191836794 : Closed e598191836794 ∧ code e598191836794 = 9394284859002 := by decide
theorem cert_e598191836794 : check e598191836794 [[.under],[.under,.left]] .chain = true := by decide
def e598191836982 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598191836982 : Closed e598191836982 ∧ code e598191836982 = 9394284859190 := by decide
theorem cert_e598191836982 : check e598191836982 [[.under],[.under,.left]] .chain = true := by decide
def e598191836986 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598191836986 : Closed e598191836986 ∧ code e598191836986 = 9394284859194 := by decide
theorem cert_e598191836986 : check e598191836986 [[.under],[.under,.left]] .chain = true := by decide
def e598192425838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598192425838 : Closed e598192425838 ∧ code e598192425838 = 9394285448046 := by decide
theorem cert_e598192425838 : check e598192425838 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e598192425846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598192425846 : Closed e598192425846 ∧ code e598192425846 = 9394285448054 := by decide
theorem cert_e598192425846 : check e598192425846 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e598192425902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598192425902 : Closed e598192425902 ∧ code e598192425902 = 9394285448110 := by decide
theorem cert_e598192425902 : check e598192425902 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e598192425914 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598192425914 : Closed e598192425914 ∧ code e598192425914 = 9394285448122 := by decide
private def t_e598192425914 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e598192425914 : ¬ IsSelfInterpreter e598192425914 :=
  wSource (t := t_e598192425914) (replay_sound (ps := []) (t := e598192425914) (by decide)) (by decide)
def e598192425942 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598192425942 : Closed e598192425942 ∧ code e598192425942 = 9394285448150 := by decide
theorem cert_e598192425942 : check e598192425942 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e598192425946 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598192425946 : Closed e598192425946 ∧ code e598192425946 = 9394285448154 := by decide
private def t_e598192425946 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e598192425946 : ¬ IsSelfInterpreter e598192425946 :=
  wSource (t := t_e598192425946) (replay_sound (ps := []) (t := e598192425946) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e598192425914
#print axioms Blc.Floor43.cert_e598192425946
