import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e755961388570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961388570 : Closed e755961388570 ∧ code e755961388570 = 9552054410778 := by decide
theorem cert_e755961388570 : check e755961388570 [] .sourceHead = true := by decide
def e755961391130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961391130 : Closed e755961391130 ∧ code e755961391130 = 9552054413338 := by decide
theorem cert_e755961391130 : check e755961391130 [] .sourceHead = true := by decide
def e755961392666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961392666 : Closed e755961392666 ∧ code e755961392666 = 9552054414874 := by decide
theorem cert_e755961392666 : check e755961392666 [] .sourceHead = true := by decide
def e755961394714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961394714 : Closed e755961394714 ∧ code e755961394714 = 9552054416922 := by decide
theorem cert_e755961394714 : check e755961394714 [] .sourceHead = true := by decide
def e755961395738 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961395738 : Closed e755961395738 ∧ code e755961395738 = 9552054417946 := by decide
theorem cert_e755961395738 : check e755961395738 [] .sourceHead = true := by decide
def e755961409050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961409050 : Closed e755961409050 ∧ code e755961409050 = 9552054431258 := by decide
theorem cert_e755961409050 : check e755961409050 [] .sourceHead = true := by decide
def e755961411098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961411098 : Closed e755961411098 ∧ code e755961411098 = 9552054433306 := by decide
theorem cert_e755961411098 : check e755961411098 [] .sourceHead = true := by decide
def e755961412122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961412122 : Closed e755961412122 ∧ code e755961412122 = 9552054434330 := by decide
theorem cert_e755961412122 : check e755961412122 [] .sourceHead = true := by decide
def e755961673754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961673754 : Closed e755961673754 ∧ code e755961673754 = 9552054695962 := by decide
theorem cert_e755961673754 : check e755961673754 [] .sourceHead = true := by decide
def e755961681946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755961681946 : Closed e755961681946 ∧ code e755961681946 = 9552054704154 := by decide
theorem cert_e755961681946 : check e755961681946 [] .sourceHead = true := by decide
def e755961683482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961683482 : Closed e755961683482 ∧ code e755961683482 = 9552054705690 := by decide
theorem cert_e755961683482 : check e755961683482 [] .sourceHead = true := by decide
def e755961687578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755961687578 : Closed e755961687578 ∧ code e755961687578 = 9552054709786 := by decide
theorem cert_e755961687578 : check e755961687578 [] .sourceHead = true := by decide
def e755962066970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755962066970 : Closed e755962066970 ∧ code e755962066970 = 9552055089178 := by decide
theorem cert_e755962066970 : check e755962066970 [] .sourceHead = true := by decide
def e755962076698 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962076698 : Closed e755962076698 ∧ code e755962076698 = 9552055098906 := by decide
theorem cert_e755962076698 : check e755962076698 [] .sourceHead = true := by decide
def e755962079258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755962079258 : Closed e755962079258 ∧ code e755962079258 = 9552055101466 := by decide
theorem cert_e755962079258 : check e755962079258 [] .sourceHead = true := by decide
def e755962080794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962080794 : Closed e755962080794 ∧ code e755962080794 = 9552055103002 := by decide
theorem cert_e755962080794 : check e755962080794 [] .sourceHead = true := by decide
def e755962082842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962082842 : Closed e755962082842 ∧ code e755962082842 = 9552055105050 := by decide
theorem cert_e755962082842 : check e755962082842 [] .sourceHead = true := by decide
def e755962271770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755962271770 : Closed e755962271770 ∧ code e755962271770 = 9552055293978 := by decide
theorem cert_e755962271770 : check e755962271770 [] .sourceHead = true := by decide
def e755962273306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962273306 : Closed e755962273306 ∧ code e755962273306 = 9552055295514 := by decide
theorem cert_e755962273306 : check e755962273306 [] .sourceHead = true := by decide
def e755962275866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755962275866 : Closed e755962275866 ∧ code e755962275866 = 9552055298074 := by decide
theorem cert_e755962275866 : check e755962275866 [] .sourceHead = true := by decide
def e755962277402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962277402 : Closed e755962277402 ∧ code e755962277402 = 9552055299610 := by decide
theorem cert_e755962277402 : check e755962277402 [] .sourceHead = true := by decide
def e755962279450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962279450 : Closed e755962279450 ∧ code e755962279450 = 9552055301658 := by decide
theorem cert_e755962279450 : check e755962279450 [] .sourceHead = true := by decide
def e755962280474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962280474 : Closed e755962280474 ∧ code e755962280474 = 9552055302682 := by decide
theorem cert_e755962280474 : check e755962280474 [] .sourceHead = true := by decide
def e755962375706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962375706 : Closed e755962375706 ∧ code e755962375706 = 9552055397914 := by decide
theorem cert_e755962375706 : check e755962375706 [] .sourceHead = true := by decide
def e755962377754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962377754 : Closed e755962377754 ∧ code e755962377754 = 9552055399962 := by decide
theorem cert_e755962377754 : check e755962377754 [] .sourceHead = true := by decide
def e755962378778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962378778 : Closed e755962378778 ∧ code e755962378778 = 9552055400986 := by decide
theorem cert_e755962378778 : check e755962378778 [] .sourceHead = true := by decide
def e755962918938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755962918938 : Closed e755962918938 ∧ code e755962918938 = 9552055941146 := by decide
theorem cert_e755962918938 : check e755962918938 [] .sourceHead = true := by decide
def e755962928666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962928666 : Closed e755962928666 ∧ code e755962928666 = 9552055950874 := by decide
theorem cert_e755962928666 : check e755962928666 [] .sourceHead = true := by decide
def e755962931226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755962931226 : Closed e755962931226 ∧ code e755962931226 = 9552055953434 := by decide
theorem cert_e755962931226 : check e755962931226 [] .sourceHead = true := by decide
def e755962932762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962932762 : Closed e755962932762 ∧ code e755962932762 = 9552055954970 := by decide
theorem cert_e755962932762 : check e755962932762 [] .sourceHead = true := by decide
def e755962934810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962934810 : Closed e755962934810 ∧ code e755962934810 = 9552055957018 := by decide
theorem cert_e755962934810 : check e755962934810 [] .sourceHead = true := by decide
def e755962961434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962961434 : Closed e755962961434 ∧ code e755962961434 = 9552055983642 := by decide
theorem cert_e755962961434 : check e755962961434 [] .sourceHead = true := by decide
def e755962968602 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962968602 : Closed e755962968602 ∧ code e755962968602 = 9552055990810 := by decide
theorem cert_e755962968602 : check e755962968602 [] .sourceHead = true := by decide
def e755962980378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755962980378 : Closed e755962980378 ∧ code e755962980378 = 9552056002586 := by decide
theorem cert_e755962980378 : check e755962980378 [] .sourceHead = true := by decide
def e755962981914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962981914 : Closed e755962981914 ∧ code e755962981914 = 9552056004122 := by decide
theorem cert_e755962981914 : check e755962981914 [] .sourceHead = true := by decide
def e755962984986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962984986 : Closed e755962984986 ∧ code e755962984986 = 9552056007194 := by decide
theorem cert_e755962984986 : check e755962984986 [] .sourceHead = true := by decide
def e755962992154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962992154 : Closed e755962992154 ∧ code e755962992154 = 9552056014362 := by decide
theorem cert_e755962992154 : check e755962992154 [] .sourceHead = true := by decide
def e755962993178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755962993178 : Closed e755962993178 ∧ code e755962993178 = 9552056015386 := by decide
theorem cert_e755962993178 : check e755962993178 [] .sourceHead = true := by decide
def e755963115546 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963115546 : Closed e755963115546 ∧ code e755963115546 = 9552056137754 := by decide
theorem cert_e755963115546 : check e755963115546 [] .sourceHead = true := by decide
def e755963125274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963125274 : Closed e755963125274 ∧ code e755963125274 = 9552056147482 := by decide
theorem cert_e755963125274 : check e755963125274 [] .sourceHead = true := by decide
def e755963127834 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963127834 : Closed e755963127834 ∧ code e755963127834 = 9552056150042 := by decide
theorem cert_e755963127834 : check e755963127834 [] .sourceHead = true := by decide
def e755963129370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963129370 : Closed e755963129370 ∧ code e755963129370 = 9552056151578 := by decide
theorem cert_e755963129370 : check e755963129370 [] .sourceHead = true := by decide
def e755963131418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963131418 : Closed e755963131418 ∧ code e755963131418 = 9552056153626 := by decide
theorem cert_e755963131418 : check e755963131418 [] .sourceHead = true := by decide
def e755963321882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963321882 : Closed e755963321882 ∧ code e755963321882 = 9552056344090 := by decide
theorem cert_e755963321882 : check e755963321882 [] .sourceHead = true := by decide
def e755963329050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963329050 : Closed e755963329050 ∧ code e755963329050 = 9552056351258 := by decide
theorem cert_e755963329050 : check e755963329050 [] .sourceHead = true := by decide
def e755963422746 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963422746 : Closed e755963422746 ∧ code e755963422746 = 9552056444954 := by decide
theorem cert_e755963422746 : check e755963422746 [] .sourceHead = true := by decide
def e755963424282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963424282 : Closed e755963424282 ∧ code e755963424282 = 9552056446490 := by decide
theorem cert_e755963424282 : check e755963424282 [] .sourceHead = true := by decide
def e755963427354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963427354 : Closed e755963427354 ∧ code e755963427354 = 9552056449562 := by decide
theorem cert_e755963427354 : check e755963427354 [] .sourceHead = true := by decide
def e755963475482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963475482 : Closed e755963475482 ∧ code e755963475482 = 9552056497690 := by decide
theorem cert_e755963475482 : check e755963475482 [] .sourceHead = true := by decide
def e755963476506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963476506 : Closed e755963476506 ∧ code e755963476506 = 9552056498714 := by decide
theorem cert_e755963476506 : check e755963476506 [] .sourceHead = true := by decide
def e755963746330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963746330 : Closed e755963746330 ∧ code e755963746330 = 9552056768538 := by decide
theorem cert_e755963746330 : check e755963746330 [] .sourceHead = true := by decide
def e755963747866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963747866 : Closed e755963747866 ∧ code e755963747866 = 9552056770074 := by decide
theorem cert_e755963747866 : check e755963747866 [] .sourceHead = true := by decide
def e755963750426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963750426 : Closed e755963750426 ∧ code e755963750426 = 9552056772634 := by decide
theorem cert_e755963750426 : check e755963750426 [] .sourceHead = true := by decide
def e755963751962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963751962 : Closed e755963751962 ∧ code e755963751962 = 9552056774170 := by decide
theorem cert_e755963751962 : check e755963751962 [] .sourceHead = true := by decide
def e755963754010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963754010 : Closed e755963754010 ∧ code e755963754010 = 9552056776218 := by decide
theorem cert_e755963754010 : check e755963754010 [] .sourceHead = true := by decide
def e755963755034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963755034 : Closed e755963755034 ∧ code e755963755034 = 9552056777242 := by decide
theorem cert_e755963755034 : check e755963755034 [] .sourceHead = true := by decide
def e755963766810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963766810 : Closed e755963766810 ∧ code e755963766810 = 9552056789018 := by decide
theorem cert_e755963766810 : check e755963766810 [] .sourceHead = true := by decide
def e755963768346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963768346 : Closed e755963768346 ∧ code e755963768346 = 9552056790554 := by decide
theorem cert_e755963768346 : check e755963768346 [] .sourceHead = true := by decide
def e755963771418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963771418 : Closed e755963771418 ∧ code e755963771418 = 9552056793626 := by decide
theorem cert_e755963771418 : check e755963771418 [] .sourceHead = true := by decide
def e755963778586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963778586 : Closed e755963778586 ∧ code e755963778586 = 9552056800794 := by decide
theorem cert_e755963778586 : check e755963778586 [] .sourceHead = true := by decide
def e755963779610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963779610 : Closed e755963779610 ∧ code e755963779610 = 9552056801818 := by decide
theorem cert_e755963779610 : check e755963779610 [] .sourceHead = true := by decide
def e755963783706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963783706 : Closed e755963783706 ∧ code e755963783706 = 9552056805914 := by decide
theorem cert_e755963783706 : check e755963783706 [] .sourceHead = true := by decide
def e755963844634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963844634 : Closed e755963844634 ∧ code e755963844634 = 9552056866842 := by decide
theorem cert_e755963844634 : check e755963844634 [] .sourceHead = true := by decide
def e755963846170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963846170 : Closed e755963846170 ∧ code e755963846170 = 9552056868378 := by decide
theorem cert_e755963846170 : check e755963846170 [] .sourceHead = true := by decide
def e755963848730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963848730 : Closed e755963848730 ∧ code e755963848730 = 9552056870938 := by decide
theorem cert_e755963848730 : check e755963848730 [] .sourceHead = true := by decide
def e755963850266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963850266 : Closed e755963850266 ∧ code e755963850266 = 9552056872474 := by decide
theorem cert_e755963850266 : check e755963850266 [] .sourceHead = true := by decide
def e755963852314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963852314 : Closed e755963852314 ∧ code e755963852314 = 9552056874522 := by decide
theorem cert_e755963852314 : check e755963852314 [] .sourceHead = true := by decide
def e755963853338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963853338 : Closed e755963853338 ∧ code e755963853338 = 9552056875546 := by decide
theorem cert_e755963853338 : check e755963853338 [] .sourceHead = true := by decide
def e755963947034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755963947034 : Closed e755963947034 ∧ code e755963947034 = 9552056969242 := by decide
theorem cert_e755963947034 : check e755963947034 [] .sourceHead = true := by decide
def e755963948570 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963948570 : Closed e755963948570 ∧ code e755963948570 = 9552056970778 := by decide
theorem cert_e755963948570 : check e755963948570 [] .sourceHead = true := by decide
def e755963951642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963951642 : Closed e755963951642 ∧ code e755963951642 = 9552056973850 := by decide
theorem cert_e755963951642 : check e755963951642 [] .sourceHead = true := by decide
def e755963999770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755963999770 : Closed e755963999770 ∧ code e755963999770 = 9552057021978 := by decide
theorem cert_e755963999770 : check e755963999770 [] .sourceHead = true := by decide
def e755964000794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964000794 : Closed e755964000794 ∧ code e755964000794 = 9552057023002 := by decide
theorem cert_e755964000794 : check e755964000794 [] .sourceHead = true := by decide
def e755964025370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964025370 : Closed e755964025370 ∧ code e755964025370 = 9552057047578 := by decide
theorem cert_e755964025370 : check e755964025370 [] .sourceHead = true := by decide
def e755964161562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964161562 : Closed e755964161562 ∧ code e755964161562 = 9552057183770 := by decide
theorem cert_e755964161562 : check e755964161562 [] .sourceHead = true := by decide
def e755964163610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964163610 : Closed e755964163610 ∧ code e755964163610 = 9552057185818 := by decide
theorem cert_e755964163610 : check e755964163610 [] .sourceHead = true := by decide
def e755964164634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964164634 : Closed e755964164634 ∧ code e755964164634 = 9552057186842 := by decide
theorem cert_e755964164634 : check e755964164634 [] .sourceHead = true := by decide
def e755964171802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964171802 : Closed e755964171802 ∧ code e755964171802 = 9552057194010 := by decide
theorem cert_e755964171802 : check e755964171802 [] .sourceHead = true := by decide
def e755964172826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964172826 : Closed e755964172826 ∧ code e755964172826 = 9552057195034 := by decide
theorem cert_e755964172826 : check e755964172826 [] .sourceHead = true := by decide
def e755964176922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964176922 : Closed e755964176922 ∧ code e755964176922 = 9552057199130 := by decide
theorem cert_e755964176922 : check e755964176922 [] .sourceHead = true := by decide
def e755964210714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964210714 : Closed e755964210714 ∧ code e755964210714 = 9552057232922 := by decide
theorem cert_e755964210714 : check e755964210714 [] .sourceHead = true := by decide
def e755964212762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964212762 : Closed e755964212762 ∧ code e755964212762 = 9552057234970 := by decide
theorem cert_e755964212762 : check e755964212762 [] .sourceHead = true := by decide
def e755964213786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964213786 : Closed e755964213786 ∧ code e755964213786 = 9552057235994 := by decide
theorem cert_e755964213786 : check e755964213786 [] .sourceHead = true := by decide
def e755964261914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964261914 : Closed e755964261914 ∧ code e755964261914 = 9552057284122 := by decide
theorem cert_e755964261914 : check e755964261914 [] .sourceHead = true := by decide
def e755964262938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964262938 : Closed e755964262938 ∧ code e755964262938 = 9552057285146 := by decide
theorem cert_e755964262938 : check e755964262938 [] .sourceHead = true := by decide
def e755964287514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755964287514 : Closed e755964287514 ∧ code e755964287514 = 9552057309722 := by decide
theorem cert_e755964287514 : check e755964287514 [] .sourceHead = true := by decide
def e755965324826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965324826 : Closed e755965324826 ∧ code e755965324826 = 9552058347034 := by decide
theorem cert_e755965324826 : check e755965324826 [] .sourceHead = true := by decide
def e755965326874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965326874 : Closed e755965326874 ∧ code e755965326874 = 9552058349082 := by decide
theorem cert_e755965326874 : check e755965326874 [] .sourceHead = true := by decide
def e755965341210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965341210 : Closed e755965341210 ∧ code e755965341210 = 9552058363418 := by decide
theorem cert_e755965341210 : check e755965341210 [] .sourceHead = true := by decide
def e755965344282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965344282 : Closed e755965344282 ∧ code e755965344282 = 9552058366490 := by decide
theorem cert_e755965344282 : check e755965344282 [] .sourceHead = true := by decide
def e755965351450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965351450 : Closed e755965351450 ∧ code e755965351450 = 9552058373658 := by decide
theorem cert_e755965351450 : check e755965351450 [] .sourceHead = true := by decide
def e755965352474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965352474 : Closed e755965352474 ∧ code e755965352474 = 9552058374682 := by decide
theorem cert_e755965352474 : check e755965352474 [] .sourceHead = true := by decide
def e755965423130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965423130 : Closed e755965423130 ∧ code e755965423130 = 9552058445338 := by decide
theorem cert_e755965423130 : check e755965423130 [] .sourceHead = true := by decide
def e755965425178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965425178 : Closed e755965425178 ∧ code e755965425178 = 9552058447386 := by decide
theorem cert_e755965425178 : check e755965425178 [] .sourceHead = true := by decide
def e755965521434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965521434 : Closed e755965521434 ∧ code e755965521434 = 9552058543642 := by decide
theorem cert_e755965521434 : check e755965521434 [] .sourceHead = true := by decide
def e755965524506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965524506 : Closed e755965524506 ∧ code e755965524506 = 9552058546714 := by decide
theorem cert_e755965524506 : check e755965524506 [] .sourceHead = true := by decide
def e755965572634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965572634 : Closed e755965572634 ∧ code e755965572634 = 9552058594842 := by decide
theorem cert_e755965572634 : check e755965572634 [] .sourceHead = true := by decide
def e755965573658 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755965573658 : Closed e755965573658 ∧ code e755965573658 = 9552058595866 := by decide
theorem cert_e755965573658 : check e755965573658 [] .sourceHead = true := by decide
def e755967571994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967571994 : Closed e755967571994 ∧ code e755967571994 = 9552060594202 := by decide
theorem cert_e755967571994 : check e755967571994 [] .sourceHead = true := by decide
def e755967580186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967580186 : Closed e755967580186 ∧ code e755967580186 = 9552060602394 := by decide
theorem cert_e755967580186 : check e755967580186 [] .sourceHead = true := by decide
def e755967581722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967581722 : Closed e755967581722 ∧ code e755967581722 = 9552060603930 := by decide
theorem cert_e755967581722 : check e755967581722 [] .sourceHead = true := by decide
def e755967585818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967585818 : Closed e755967585818 ∧ code e755967585818 = 9552060608026 := by decide
theorem cert_e755967585818 : check e755967585818 [] .sourceHead = true := by decide
def e755967637530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967637530 : Closed e755967637530 ∧ code e755967637530 = 9552060659738 := by decide
theorem cert_e755967637530 : check e755967637530 [] .sourceHead = true := by decide
def e755967647258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967647258 : Closed e755967647258 ∧ code e755967647258 = 9552060669466 := by decide
theorem cert_e755967647258 : check e755967647258 [] .sourceHead = true := by decide
def e755967649818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967649818 : Closed e755967649818 ∧ code e755967649818 = 9552060672026 := by decide
theorem cert_e755967649818 : check e755967649818 [] .sourceHead = true := by decide
def e755967651354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967651354 : Closed e755967651354 ∧ code e755967651354 = 9552060673562 := by decide
theorem cert_e755967651354 : check e755967651354 [] .sourceHead = true := by decide
def e755967653402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967653402 : Closed e755967653402 ∧ code e755967653402 = 9552060675610 := by decide
theorem cert_e755967653402 : check e755967653402 [] .sourceHead = true := by decide
def e755967678490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967678490 : Closed e755967678490 ∧ code e755967678490 = 9552060700698 := by decide
theorem cert_e755967678490 : check e755967678490 [] .sourceHead = true := by decide
def e755967680026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967680026 : Closed e755967680026 ∧ code e755967680026 = 9552060702234 := by decide
theorem cert_e755967680026 : check e755967680026 [] .sourceHead = true := by decide
def e755967682586 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967682586 : Closed e755967682586 ∧ code e755967682586 = 9552060704794 := by decide
theorem cert_e755967682586 : check e755967682586 [] .sourceHead = true := by decide
def e755967684122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967684122 : Closed e755967684122 ∧ code e755967684122 = 9552060706330 := by decide
theorem cert_e755967684122 : check e755967684122 [] .sourceHead = true := by decide
def e755967686170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967686170 : Closed e755967686170 ∧ code e755967686170 = 9552060708378 := by decide
theorem cert_e755967686170 : check e755967686170 [] .sourceHead = true := by decide
def e755967687194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967687194 : Closed e755967687194 ∧ code e755967687194 = 9552060709402 := by decide
theorem cert_e755967687194 : check e755967687194 [] .sourceHead = true := by decide
def e755967700506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967700506 : Closed e755967700506 ∧ code e755967700506 = 9552060722714 := by decide
theorem cert_e755967700506 : check e755967700506 [] .sourceHead = true := by decide
def e755967702554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967702554 : Closed e755967702554 ∧ code e755967702554 = 9552060724762 := by decide
theorem cert_e755967702554 : check e755967702554 [] .sourceHead = true := by decide
def e755967703578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967703578 : Closed e755967703578 ∧ code e755967703578 = 9552060725786 := by decide
theorem cert_e755967703578 : check e755967703578 [] .sourceHead = true := by decide
def e755967965210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967965210 : Closed e755967965210 ∧ code e755967965210 = 9552060987418 := by decide
theorem cert_e755967965210 : check e755967965210 [] .sourceHead = true := by decide
def e755967973402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755967973402 : Closed e755967973402 ∧ code e755967973402 = 9552060995610 := by decide
theorem cert_e755967973402 : check e755967973402 [] .sourceHead = true := by decide
def e755967974938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967974938 : Closed e755967974938 ∧ code e755967974938 = 9552060997146 := by decide
theorem cert_e755967974938 : check e755967974938 [] .sourceHead = true := by decide
def e755967979034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755967979034 : Closed e755967979034 ∧ code e755967979034 = 9552061001242 := by decide
theorem cert_e755967979034 : check e755967979034 [] .sourceHead = true := by decide
def e755968358426 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755968358426 : Closed e755968358426 ∧ code e755968358426 = 9552061380634 := by decide
theorem cert_e755968358426 : check e755968358426 [] .sourceHead = true := by decide
def e755968368154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968368154 : Closed e755968368154 ∧ code e755968368154 = 9552061390362 := by decide
theorem cert_e755968368154 : check e755968368154 [] .sourceHead = true := by decide
def e755968370714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755968370714 : Closed e755968370714 ∧ code e755968370714 = 9552061392922 := by decide
theorem cert_e755968370714 : check e755968370714 [] .sourceHead = true := by decide
def e755968372250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968372250 : Closed e755968372250 ∧ code e755968372250 = 9552061394458 := by decide
theorem cert_e755968372250 : check e755968372250 [] .sourceHead = true := by decide
def e755968374298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968374298 : Closed e755968374298 ∧ code e755968374298 = 9552061396506 := by decide
theorem cert_e755968374298 : check e755968374298 [] .sourceHead = true := by decide
def e755968563226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755968563226 : Closed e755968563226 ∧ code e755968563226 = 9552061585434 := by decide
theorem cert_e755968563226 : check e755968563226 [] .sourceHead = true := by decide
def e755968564762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968564762 : Closed e755968564762 ∧ code e755968564762 = 9552061586970 := by decide
theorem cert_e755968564762 : check e755968564762 [] .sourceHead = true := by decide
def e755968567322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755968567322 : Closed e755968567322 ∧ code e755968567322 = 9552061589530 := by decide
theorem cert_e755968567322 : check e755968567322 [] .sourceHead = true := by decide
def e755968568858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968568858 : Closed e755968568858 ∧ code e755968568858 = 9552061591066 := by decide
theorem cert_e755968568858 : check e755968568858 [] .sourceHead = true := by decide
def e755968570906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968570906 : Closed e755968570906 ∧ code e755968570906 = 9552061593114 := by decide
theorem cert_e755968570906 : check e755968570906 [] .sourceHead = true := by decide
def e755968571930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968571930 : Closed e755968571930 ∧ code e755968571930 = 9552061594138 := by decide
theorem cert_e755968571930 : check e755968571930 [] .sourceHead = true := by decide
def e755968667162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968667162 : Closed e755968667162 ∧ code e755968667162 = 9552061689370 := by decide
theorem cert_e755968667162 : check e755968667162 [] .sourceHead = true := by decide
def e755968669210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968669210 : Closed e755968669210 ∧ code e755968669210 = 9552061691418 := by decide
theorem cert_e755968669210 : check e755968669210 [] .sourceHead = true := by decide
def e755968670234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755968670234 : Closed e755968670234 ∧ code e755968670234 = 9552061692442 := by decide
theorem cert_e755968670234 : check e755968670234 [] .sourceHead = true := by decide
def e755974453274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755974453274 : Closed e755974453274 ∧ code e755974453274 = 9552067475482 := by decide
theorem cert_e755974453274 : check e755974453274 [] .sourceHead = true := by decide
def e755974463002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974463002 : Closed e755974463002 ∧ code e755974463002 = 9552067485210 := by decide
theorem cert_e755974463002 : check e755974463002 [] .sourceHead = true := by decide
def e755974465562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755974465562 : Closed e755974465562 ∧ code e755974465562 = 9552067487770 := by decide
theorem cert_e755974465562 : check e755974465562 [] .sourceHead = true := by decide
def e755974467098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974467098 : Closed e755974467098 ∧ code e755974467098 = 9552067489306 := by decide
theorem cert_e755974467098 : check e755974467098 [] .sourceHead = true := by decide
def e755974469146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974469146 : Closed e755974469146 ∧ code e755974469146 = 9552067491354 := by decide
theorem cert_e755974469146 : check e755974469146 [] .sourceHead = true := by decide
def e755974495770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974495770 : Closed e755974495770 ∧ code e755974495770 = 9552067517978 := by decide
theorem cert_e755974495770 : check e755974495770 [] .sourceHead = true := by decide
def e755974502938 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974502938 : Closed e755974502938 ∧ code e755974502938 = 9552067525146 := by decide
theorem cert_e755974502938 : check e755974502938 [] .sourceHead = true := by decide
def e755974514714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755974514714 : Closed e755974514714 ∧ code e755974514714 = 9552067536922 := by decide
theorem cert_e755974514714 : check e755974514714 [] .sourceHead = true := by decide
def e755974516250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974516250 : Closed e755974516250 ∧ code e755974516250 = 9552067538458 := by decide
theorem cert_e755974516250 : check e755974516250 [] .sourceHead = true := by decide
def e755974519322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974519322 : Closed e755974519322 ∧ code e755974519322 = 9552067541530 := by decide
theorem cert_e755974519322 : check e755974519322 [] .sourceHead = true := by decide
def e755974526490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974526490 : Closed e755974526490 ∧ code e755974526490 = 9552067548698 := by decide
theorem cert_e755974526490 : check e755974526490 [] .sourceHead = true := by decide
def e755974527514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974527514 : Closed e755974527514 ∧ code e755974527514 = 9552067549722 := by decide
theorem cert_e755974527514 : check e755974527514 [] .sourceHead = true := by decide
def e755974649882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755974649882 : Closed e755974649882 ∧ code e755974649882 = 9552067672090 := by decide
theorem cert_e755974649882 : check e755974649882 [] .sourceHead = true := by decide
def e755974659610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974659610 : Closed e755974659610 ∧ code e755974659610 = 9552067681818 := by decide
theorem cert_e755974659610 : check e755974659610 [] .sourceHead = true := by decide
def e755974662170 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755974662170 : Closed e755974662170 ∧ code e755974662170 = 9552067684378 := by decide
theorem cert_e755974662170 : check e755974662170 [] .sourceHead = true := by decide
def e755974663706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974663706 : Closed e755974663706 ∧ code e755974663706 = 9552067685914 := by decide
theorem cert_e755974663706 : check e755974663706 [] .sourceHead = true := by decide
def e755974665754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974665754 : Closed e755974665754 ∧ code e755974665754 = 9552067687962 := by decide
theorem cert_e755974665754 : check e755974665754 [] .sourceHead = true := by decide
def e755974856218 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974856218 : Closed e755974856218 ∧ code e755974856218 = 9552067878426 := by decide
theorem cert_e755974856218 : check e755974856218 [] .sourceHead = true := by decide
def e755974863386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974863386 : Closed e755974863386 ∧ code e755974863386 = 9552067885594 := by decide
theorem cert_e755974863386 : check e755974863386 [] .sourceHead = true := by decide
def e755974957082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755974957082 : Closed e755974957082 ∧ code e755974957082 = 9552067979290 := by decide
theorem cert_e755974957082 : check e755974957082 [] .sourceHead = true := by decide
def e755974958618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974958618 : Closed e755974958618 ∧ code e755974958618 = 9552067980826 := by decide
theorem cert_e755974958618 : check e755974958618 [] .sourceHead = true := by decide
def e755974961690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755974961690 : Closed e755974961690 ∧ code e755974961690 = 9552067983898 := by decide
theorem cert_e755974961690 : check e755974961690 [] .sourceHead = true := by decide
def e755975009818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755975009818 : Closed e755975009818 ∧ code e755975009818 = 9552068032026 := by decide
theorem cert_e755975009818 : check e755975009818 [] .sourceHead = true := by decide
def e755975010842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755975010842 : Closed e755975010842 ∧ code e755975010842 = 9552068033050 := by decide
theorem cert_e755975010842 : check e755975010842 [] .sourceHead = true := by decide
def e755977902106 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e755977902106 : Closed e755977902106 ∧ code e755977902106 = 9552070924314 := by decide
theorem cert_e755977902106 : check e755977902106 [] .sourceHead = true := by decide
def e755977903642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e755977903642 : Closed e755977903642 ∧ code e755977903642 = 9552070925850 := by decide
theorem cert_e755977903642 : check e755977903642 [] .sourceHead = true := by decide
end Blc.Floor43
