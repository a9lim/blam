import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407481114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407481114 : Closed e2422407481114 ∧ code e2422407481114 = 11218500503322 := by decide
theorem cert_e2422407481114 : check e2422407481114 [[],[]] .chain = true := by decide
def e2422407481158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407481158 : Closed e2422407481158 ∧ code e2422407481158 = 11218500503366 := by decide
theorem cert_e2422407481158 : check e2422407481158 [[],[]] .chain = true := by decide
def e2422407481186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422407481186 : Closed e2422407481186 ∧ code e2422407481186 = 11218500503394 := by decide
theorem cert_e2422407481186 : check e2422407481186 [[],[]] .chain = true := by decide
def e2422407481198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2422407481198 : Closed e2422407481198 ∧ code e2422407481198 = 11218500503406 := by decide
theorem cert_e2422407481198 : check e2422407481198 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407481206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2422407481206 : Closed e2422407481206 ∧ code e2422407481206 = 11218500503414 := by decide
theorem cert_e2422407481206 : check e2422407481206 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407481270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e2422407481270 : Closed e2422407481270 ∧ code e2422407481270 = 11218500503478 := by decide
theorem cert_e2422407481270 : check e2422407481270 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407482454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422407482454 : Closed e2422407482454 ∧ code e2422407482454 = 11218500504662 := by decide
theorem cert_e2422407482454 : check e2422407482454 [[],[]] .chain = true := by decide
def e2422407482458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422407482458 : Closed e2422407482458 ∧ code e2422407482458 = 11218500504666 := by decide
theorem cert_e2422407482458 : check e2422407482458 [[],[]] .chain = true := by decide
def e2422407482646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422407482646 : Closed e2422407482646 ∧ code e2422407482646 = 11218500504854 := by decide
theorem cert_e2422407482646 : check e2422407482646 [[],[]] .chain = true := by decide
def e2422407482722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422407482722 : Closed e2422407482722 ∧ code e2422407482722 = 11218500504930 := by decide
theorem cert_e2422407482722 : check e2422407482722 [[],[]] .chain = true := by decide
def e2422407482734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422407482734 : Closed e2422407482734 ∧ code e2422407482734 = 11218500504942 := by decide
theorem cert_e2422407482734 : check e2422407482734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407482742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422407482742 : Closed e2422407482742 ∧ code e2422407482742 = 11218500504950 := by decide
theorem cert_e2422407482742 : check e2422407482742 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407482762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407482762 : Closed e2422407482762 ∧ code e2422407482762 = 11218500504970 := by decide
theorem cert_e2422407482762 : check e2422407482762 [[],[]] .chain = true := by decide
def e2422407482786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407482786 : Closed e2422407482786 ∧ code e2422407482786 = 11218500504994 := by decide
theorem cert_e2422407482786 : check e2422407482786 [[],[]] .chain = true := by decide
def e2422407482798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422407482798 : Closed e2422407482798 ∧ code e2422407482798 = 11218500505006 := by decide
theorem cert_e2422407482798 : check e2422407482798 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407482806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422407482806 : Closed e2422407482806 ∧ code e2422407482806 = 11218500505014 := by decide
theorem cert_e2422407482806 : check e2422407482806 [[],[]] .chain = true := by decide
def e2422407482810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422407482810 : Closed e2422407482810 ∧ code e2422407482810 = 11218500505018 := by decide
theorem cert_e2422407482810 : check e2422407482810 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407482838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422407482838 : Closed e2422407482838 ∧ code e2422407482838 = 11218500505046 := by decide
theorem cert_e2422407482838 : checkPay e2422407482838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] 0 [[.right],[.right,.left,.left],[.right,.left,.left,.left],[.right,.left,.left],[.right,.left],[.right,.left,.left,.left],[.right,.left,.left],[.right,.left,.left],[.right,.left],[.right,.left],[.right]] = true := by decide
def e2422407482842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422407482842 : Closed e2422407482842 ∧ code e2422407482842 = 11218500505050 := by decide
theorem cert_e2422407482842 : check e2422407482842 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407482922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407482922 : Closed e2422407482922 ∧ code e2422407482922 = 11218500505130 := by decide
theorem cert_e2422407482922 : check e2422407482922 [[],[]] .chain = true := by decide
def e2422407483018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407483018 : Closed e2422407483018 ∧ code e2422407483018 = 11218500505226 := by decide
theorem cert_e2422407483018 : check e2422407483018 [[],[]] .chain = true := by decide
def e2422407483042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407483042 : Closed e2422407483042 ∧ code e2422407483042 = 11218500505250 := by decide
theorem cert_e2422407483042 : check e2422407483042 [[],[]] .chain = true := by decide
def e2422407483054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422407483054 : Closed e2422407483054 ∧ code e2422407483054 = 11218500505262 := by decide
theorem cert_e2422407483054 : check e2422407483054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407483062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2422407483062 : Closed e2422407483062 ∧ code e2422407483062 = 11218500505270 := by decide
theorem cert_e2422407483062 : check e2422407483062 [[],[]] .chain = true := by decide
def e2422407483066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422407483066 : Closed e2422407483066 ∧ code e2422407483066 = 11218500505274 := by decide
theorem cert_e2422407483066 : check e2422407483066 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407483094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422407483094 : Closed e2422407483094 ∧ code e2422407483094 = 11218500505302 := by decide
theorem cert_e2422407483094 : check e2422407483094 [[],[]] .chain = true := by decide
def e2422407483098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422407483098 : Closed e2422407483098 ∧ code e2422407483098 = 11218500505306 := by decide
theorem cert_e2422407483098 : check e2422407483098 [[],[]] .chain = true := by decide
def e2422407483114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422407483114 : Closed e2422407483114 ∧ code e2422407483114 = 11218500505322 := by decide
theorem cert_e2422407483114 : check e2422407483114 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407483222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422407483222 : Closed e2422407483222 ∧ code e2422407483222 = 11218500505430 := by decide
theorem cert_e2422407483222 : checkPay e2422407483222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] = true := by decide
def e2422407483226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422407483226 : Closed e2422407483226 ∧ code e2422407483226 = 11218500505434 := by decide
def e2422407483242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422407483242 : Closed e2422407483242 ∧ code e2422407483242 = 11218500505450 := by decide
theorem cert_e2422407483242 : check e2422407483242 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407483414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407483414 : Closed e2422407483414 ∧ code e2422407483414 = 11218500505622 := by decide
theorem cert_e2422407483414 : check e2422407483414 [[],[]] .chain = true := by decide
def e2422407483510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422407483510 : Closed e2422407483510 ∧ code e2422407483510 = 11218500505718 := by decide
theorem cert_e2422407483510 : check e2422407483510 [[],[]] .chain = true := by decide
def e2422407483514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407483514 : Closed e2422407483514 ∧ code e2422407483514 = 11218500505722 := by decide
theorem cert_e2422407483514 : check e2422407483514 [[],[]] .chain = true := by decide
def e2422407483606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407483606 : Closed e2422407483606 ∧ code e2422407483606 = 11218500505814 := by decide
theorem cert_e2422407483606 : check e2422407483606 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407483702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407483702 : Closed e2422407483702 ∧ code e2422407483702 = 11218500505910 := by decide
theorem cert_e2422407483702 : check e2422407483702 [[],[]] .chain = true := by decide
def e2422407483706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407483706 : Closed e2422407483706 ∧ code e2422407483706 = 11218500505914 := by decide
theorem cert_e2422407483706 : check e2422407483706 [[],[]] .chain = true := by decide
def e2422407483790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422407483790 : Closed e2422407483790 ∧ code e2422407483790 = 11218500505998 := by decide
theorem cert_e2422407483790 : check e2422407483790 [[],[]] .chain = true := by decide
def e2422407483846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407483846 : Closed e2422407483846 ∧ code e2422407483846 = 11218500506054 := by decide
theorem cert_e2422407483846 : check e2422407483846 [[],[]] .chain = true := by decide
def e2422407484182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407484182 : Closed e2422407484182 ∧ code e2422407484182 = 11218500506390 := by decide
theorem cert_e2422407484182 : check e2422407484182 [[],[]] .chain = true := by decide
def e2422407484258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407484258 : Closed e2422407484258 ∧ code e2422407484258 = 11218500506466 := by decide
theorem cert_e2422407484258 : check e2422407484258 [[],[]] .chain = true := by decide
def e2422407484270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422407484270 : Closed e2422407484270 ∧ code e2422407484270 = 11218500506478 := by decide
theorem cert_e2422407484270 : check e2422407484270 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407484278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422407484278 : Closed e2422407484278 ∧ code e2422407484278 = 11218500506486 := by decide
theorem cert_e2422407484278 : check e2422407484278 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407484298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407484298 : Closed e2422407484298 ∧ code e2422407484298 = 11218500506506 := by decide
theorem cert_e2422407484298 : check e2422407484298 [[],[]] .chain = true := by decide
def e2422407484322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407484322 : Closed e2422407484322 ∧ code e2422407484322 = 11218500506530 := by decide
theorem cert_e2422407484322 : check e2422407484322 [[],[]] .chain = true := by decide
def e2422407484334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422407484334 : Closed e2422407484334 ∧ code e2422407484334 = 11218500506542 := by decide
theorem cert_e2422407484334 : check e2422407484334 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407484342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2422407484342 : Closed e2422407484342 ∧ code e2422407484342 = 11218500506550 := by decide
theorem cert_e2422407484342 : check e2422407484342 [[],[]] .chain = true := by decide
def e2422407484346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422407484346 : Closed e2422407484346 ∧ code e2422407484346 = 11218500506554 := by decide
theorem cert_e2422407484346 : check e2422407484346 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407484374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422407484374 : Closed e2422407484374 ∧ code e2422407484374 = 11218500506582 := by decide
theorem cert_e2422407484374 : check e2422407484374 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407484378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422407484378 : Closed e2422407484378 ∧ code e2422407484378 = 11218500506586 := by decide
theorem cert_e2422407484378 : check e2422407484378 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407484446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422407484446 : Closed e2422407484446 ∧ code e2422407484446 = 11218500506654 := by decide
theorem cert_e2422407484446 : check e2422407484446 [[],[]] .chain = true := by decide
def e2422407484642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407484642 : Closed e2422407484642 ∧ code e2422407484642 = 11218500506850 := by decide
theorem cert_e2422407484642 : check e2422407484642 [[],[]] .chain = true := by decide
def e2422407484654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407484654 : Closed e2422407484654 ∧ code e2422407484654 = 11218500506862 := by decide
theorem cert_e2422407484654 : check e2422407484654 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407484662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407484662 : Closed e2422407484662 ∧ code e2422407484662 = 11218500506870 := by decide
theorem cert_e2422407484662 : check e2422407484662 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407484930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407484930 : Closed e2422407484930 ∧ code e2422407484930 = 11218500507138 := by decide
theorem cert_e2422407484930 : check e2422407484930 [[],[]] .chain = true := by decide
def e2422407484942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407484942 : Closed e2422407484942 ∧ code e2422407484942 = 11218500507150 := by decide
theorem cert_e2422407484942 : check e2422407484942 [[],[]] .chain = true := by decide
def e2422407484954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407484954 : Closed e2422407484954 ∧ code e2422407484954 = 11218500507162 := by decide
theorem cert_e2422407484954 : check e2422407484954 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407485026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407485026 : Closed e2422407485026 ∧ code e2422407485026 = 11218500507234 := by decide
theorem cert_e2422407485026 : check e2422407485026 [[],[]] .chain = true := by decide
def e2422407485038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407485038 : Closed e2422407485038 ∧ code e2422407485038 = 11218500507246 := by decide
theorem cert_e2422407485038 : check e2422407485038 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407485046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407485046 : Closed e2422407485046 ∧ code e2422407485046 = 11218500507254 := by decide
theorem cert_e2422407485046 : check e2422407485046 [[],[]] .chain = true := by decide
def e2422407485050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407485050 : Closed e2422407485050 ∧ code e2422407485050 = 11218500507258 := by decide
theorem cert_e2422407485050 : check e2422407485050 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407485238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407485238 : Closed e2422407485238 ∧ code e2422407485238 = 11218500507446 := by decide
theorem cert_e2422407485238 : check e2422407485238 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407485242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407485242 : Closed e2422407485242 ∧ code e2422407485242 = 11218500507450 := by decide
theorem cert_e2422407485242 : check e2422407485242 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407485450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407485450 : Closed e2422407485450 ∧ code e2422407485450 = 11218500507658 := by decide
theorem cert_e2422407485450 : check e2422407485450 [[],[]] .chain = true := by decide
def e2422407485486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407485486 : Closed e2422407485486 ∧ code e2422407485486 = 11218500507694 := by decide
theorem cert_e2422407485486 : check e2422407485486 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407485494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407485494 : Closed e2422407485494 ∧ code e2422407485494 = 11218500507702 := by decide
theorem cert_e2422407485494 : check e2422407485494 [[],[]] .chain = true := by decide
def e2422407485498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407485498 : Closed e2422407485498 ∧ code e2422407485498 = 11218500507706 := by decide
theorem cert_e2422407485498 : check e2422407485498 [[],[]] .chain = true := by decide
def e2422407485546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407485546 : Closed e2422407485546 ∧ code e2422407485546 = 11218500507754 := by decide
theorem cert_e2422407485546 : check e2422407485546 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407485582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407485582 : Closed e2422407485582 ∧ code e2422407485582 = 11218500507790 := by decide
theorem cert_e2422407485582 : check e2422407485582 [[],[]] .chain = true := by decide
def e2422407485594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407485594 : Closed e2422407485594 ∧ code e2422407485594 = 11218500507802 := by decide
theorem cert_e2422407485594 : check e2422407485594 [[],[]] .chain = true := by decide
def e2422407485638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407485638 : Closed e2422407485638 ∧ code e2422407485638 = 11218500507846 := by decide
theorem cert_e2422407485638 : check e2422407485638 [[],[]] .chain = true := by decide
def e2422407485666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407485666 : Closed e2422407485666 ∧ code e2422407485666 = 11218500507874 := by decide
theorem cert_e2422407485666 : check e2422407485666 [[],[]] .chain = true := by decide
def e2422407485678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422407485678 : Closed e2422407485678 ∧ code e2422407485678 = 11218500507886 := by decide
theorem cert_e2422407485678 : check e2422407485678 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407485686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422407485686 : Closed e2422407485686 ∧ code e2422407485686 = 11218500507894 := by decide
theorem cert_e2422407485686 : check e2422407485686 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407485834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407485834 : Closed e2422407485834 ∧ code e2422407485834 = 11218500508042 := by decide
theorem cert_e2422407485834 : check e2422407485834 [[],[]] .chain = true := by decide
def e2422407485858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407485858 : Closed e2422407485858 ∧ code e2422407485858 = 11218500508066 := by decide
theorem cert_e2422407485858 : check e2422407485858 [[],[]] .chain = true := by decide
def e2422407485870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407485870 : Closed e2422407485870 ∧ code e2422407485870 = 11218500508078 := by decide
theorem cert_e2422407485870 : check e2422407485870 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407485878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422407485878 : Closed e2422407485878 ∧ code e2422407485878 = 11218500508086 := by decide
theorem cert_e2422407485878 : check e2422407485878 [[],[]] .chain = true := by decide
def e2422407485882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407485882 : Closed e2422407485882 ∧ code e2422407485882 = 11218500508090 := by decide
theorem cert_e2422407485882 : check e2422407485882 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407485910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422407485910 : Closed e2422407485910 ∧ code e2422407485910 = 11218500508118 := by decide
theorem cert_e2422407485910 : check e2422407485910 [[],[]] .chain = true := by decide
def e2422407485914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422407485914 : Closed e2422407485914 ∧ code e2422407485914 = 11218500508122 := by decide
theorem cert_e2422407485914 : check e2422407485914 [[],[]] .chain = true := by decide
def e2422407485930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407485930 : Closed e2422407485930 ∧ code e2422407485930 = 11218500508138 := by decide
theorem cert_e2422407485930 : check e2422407485930 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407485954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407485954 : Closed e2422407485954 ∧ code e2422407485954 = 11218500508162 := by decide
theorem cert_e2422407485954 : check e2422407485954 [[],[]] .chain = true := by decide
def e2422407485966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407485966 : Closed e2422407485966 ∧ code e2422407485966 = 11218500508174 := by decide
theorem cert_e2422407485966 : check e2422407485966 [[],[]] .chain = true := by decide
def e2422407485978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407485978 : Closed e2422407485978 ∧ code e2422407485978 = 11218500508186 := by decide
theorem cert_e2422407485978 : check e2422407485978 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407486050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407486050 : Closed e2422407486050 ∧ code e2422407486050 = 11218500508258 := by decide
theorem cert_e2422407486050 : check e2422407486050 [[],[]] .chain = true := by decide
def e2422407486062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407486062 : Closed e2422407486062 ∧ code e2422407486062 = 11218500508270 := by decide
theorem cert_e2422407486062 : check e2422407486062 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407486070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407486070 : Closed e2422407486070 ∧ code e2422407486070 = 11218500508278 := by decide
theorem cert_e2422407486070 : check e2422407486070 [[],[]] .chain = true := by decide
def e2422407486074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407486074 : Closed e2422407486074 ∧ code e2422407486074 = 11218500508282 := by decide
theorem cert_e2422407486074 : check e2422407486074 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407486214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407486214 : Closed e2422407486214 ∧ code e2422407486214 = 11218500508422 := by decide
theorem cert_e2422407486214 : check e2422407486214 [[],[]] .chain = true := by decide
def e2422407486238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422407486238 : Closed e2422407486238 ∧ code e2422407486238 = 11218500508446 := by decide
theorem cert_e2422407486238 : check e2422407486238 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407486262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407486262 : Closed e2422407486262 ∧ code e2422407486262 = 11218500508470 := by decide
theorem cert_e2422407486262 : check e2422407486262 [[],[]] .chain = true := by decide
def e2422407486266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407486266 : Closed e2422407486266 ∧ code e2422407486266 = 11218500508474 := by decide
theorem cert_e2422407486266 : check e2422407486266 [[],[]] .chain = true := by decide
def e2422407486338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407486338 : Closed e2422407486338 ∧ code e2422407486338 = 11218500508546 := by decide
theorem cert_e2422407486338 : check e2422407486338 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407486350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422407486350 : Closed e2422407486350 ∧ code e2422407486350 = 11218500508558 := by decide
theorem cert_e2422407486350 : check e2422407486350 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407486362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407486362 : Closed e2422407486362 ∧ code e2422407486362 = 11218500508570 := by decide
theorem cert_e2422407486362 : check e2422407486362 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407486486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407486486 : Closed e2422407486486 ∧ code e2422407486486 = 11218500508694 := by decide
theorem cert_e2422407486486 : check e2422407486486 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407486582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422407486582 : Closed e2422407486582 ∧ code e2422407486582 = 11218500508790 := by decide
theorem cert_e2422407486582 : check e2422407486582 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407486678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407486678 : Closed e2422407486678 ∧ code e2422407486678 = 11218500508886 := by decide
theorem cert_e2422407486678 : check e2422407486678 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407486682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407486682 : Closed e2422407486682 ∧ code e2422407486682 = 11218500508890 := by decide
def e2422407486698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407486698 : Closed e2422407486698 ∧ code e2422407486698 = 11218500508906 := by decide
def e2422407486774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407486774 : Closed e2422407486774 ∧ code e2422407486774 = 11218500508982 := by decide
def e2422407486778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407486778 : Closed e2422407486778 ∧ code e2422407486778 = 11218500508986 := by decide
def e2422407486850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407486850 : Closed e2422407486850 ∧ code e2422407486850 = 11218500509058 := by decide
theorem cert_e2422407486850 : check e2422407486850 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407486862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422407486862 : Closed e2422407486862 ∧ code e2422407486862 = 11218500509070 := by decide
theorem cert_e2422407486862 : check e2422407486862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407486874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407486874 : Closed e2422407486874 ∧ code e2422407486874 = 11218500509082 := by decide
def e2422407487530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))))
theorem wire_e2422407487530 : Closed e2422407487530 ∧ code e2422407487530 = 11218500509738 := by decide
theorem cert_e2422407487530 : check e2422407487530 [[],[]] .chain = true := by decide
def e2422407487662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422407487662 : Closed e2422407487662 ∧ code e2422407487662 = 11218500509870 := by decide
theorem cert_e2422407487662 : check e2422407487662 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407487674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422407487674 : Closed e2422407487674 ∧ code e2422407487674 = 11218500509882 := by decide
theorem cert_e2422407487674 : check e2422407487674 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407487702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e2422407487702 : Closed e2422407487702 ∧ code e2422407487702 = 11218500509910 := by decide
theorem cert_e2422407487702 : check e2422407487702 [[],[]] .chain = true := by decide
def e2422407487706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e2422407487706 : Closed e2422407487706 ∧ code e2422407487706 = 11218500509914 := by decide
theorem cert_e2422407487706 : check e2422407487706 [[],[]] .chain = true := by decide
def e2422407487722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0)) (.var 0))))))
theorem wire_e2422407487722 : Closed e2422407487722 ∧ code e2422407487722 = 11218500509930 := by decide
theorem cert_e2422407487722 : check e2422407487722 [[],[]] .chain = true := by decide
def e2422407487914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407487914 : Closed e2422407487914 ∧ code e2422407487914 = 11218500510122 := by decide
theorem cert_e2422407487914 : check e2422407487914 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407488054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407488054 : Closed e2422407488054 ∧ code e2422407488054 = 11218500510262 := by decide
theorem cert_e2422407488054 : check e2422407488054 [[],[]] .chain = true := by decide
def e2422407488058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407488058 : Closed e2422407488058 ∧ code e2422407488058 = 11218500510266 := by decide
theorem cert_e2422407488058 : check e2422407488058 [[],[]] .chain = true := by decide
def e2422407488106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422407488106 : Closed e2422407488106 ∧ code e2422407488106 = 11218500510314 := by decide
theorem cert_e2422407488106 : check e2422407488106 [[],[]] .chain = true := by decide
def e2422407488142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407488142 : Closed e2422407488142 ∧ code e2422407488142 = 11218500510350 := by decide
theorem cert_e2422407488142 : check e2422407488142 [[],[]] .chain = true := by decide
def e2422407488154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407488154 : Closed e2422407488154 ∧ code e2422407488154 = 11218500510362 := by decide
theorem cert_e2422407488154 : check e2422407488154 [[],[]] .chain = true := by decide
def e2422407488198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407488198 : Closed e2422407488198 ∧ code e2422407488198 = 11218500510406 := by decide
theorem cert_e2422407488198 : check e2422407488198 [[],[]] .chain = true := by decide
def e2422407488278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422407488278 : Closed e2422407488278 ∧ code e2422407488278 = 11218500510486 := by decide
theorem cert_e2422407488278 : check e2422407488278 [[],[]] .chain = true := by decide
def e2422407488282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407488282 : Closed e2422407488282 ∧ code e2422407488282 = 11218500510490 := by decide
theorem cert_e2422407488282 : check e2422407488282 [[],[]] .chain = true := by decide
def e2422407488326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407488326 : Closed e2422407488326 ∧ code e2422407488326 = 11218500510534 := by decide
theorem cert_e2422407488326 : check e2422407488326 [[],[]] .chain = true := by decide
def e2422407488354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422407488354 : Closed e2422407488354 ∧ code e2422407488354 = 11218500510562 := by decide
theorem cert_e2422407488354 : check e2422407488354 [[],[]] .chain = true := by decide
def e2422407488366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422407488366 : Closed e2422407488366 ∧ code e2422407488366 = 11218500510574 := by decide
theorem cert_e2422407488366 : check e2422407488366 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407488374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422407488374 : Closed e2422407488374 ∧ code e2422407488374 = 11218500510582 := by decide
theorem cert_e2422407488374 : check e2422407488374 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407488394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407488394 : Closed e2422407488394 ∧ code e2422407488394 = 11218500510602 := by decide
theorem cert_e2422407488394 : check e2422407488394 [[],[]] .chain = true := by decide
def e2422407488418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407488418 : Closed e2422407488418 ∧ code e2422407488418 = 11218500510626 := by decide
theorem cert_e2422407488418 : check e2422407488418 [[],[]] .chain = true := by decide
def e2422407488430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422407488430 : Closed e2422407488430 ∧ code e2422407488430 = 11218500510638 := by decide
theorem cert_e2422407488430 : check e2422407488430 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407488442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422407488442 : Closed e2422407488442 ∧ code e2422407488442 = 11218500510650 := by decide
theorem cert_e2422407488442 : check e2422407488442 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407488470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2422407488470 : Closed e2422407488470 ∧ code e2422407488470 = 11218500510678 := by decide
theorem cert_e2422407488470 : check e2422407488470 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407488474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2422407488474 : Closed e2422407488474 ∧ code e2422407488474 = 11218500510682 := by decide
theorem cert_e2422407488474 : check e2422407488474 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407489066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407489066 : Closed e2422407489066 ∧ code e2422407489066 = 11218500511274 := by decide
theorem cert_e2422407489066 : check e2422407489066 [[],[]] .chain = true := by decide
def e2422407489162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407489162 : Closed e2422407489162 ∧ code e2422407489162 = 11218500511370 := by decide
theorem cert_e2422407489162 : check e2422407489162 [[],[]] .chain = true := by decide
def e2422407489186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407489186 : Closed e2422407489186 ∧ code e2422407489186 = 11218500511394 := by decide
theorem cert_e2422407489186 : check e2422407489186 [[],[]] .chain = true := by decide
def e2422407489198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422407489198 : Closed e2422407489198 ∧ code e2422407489198 = 11218500511406 := by decide
theorem cert_e2422407489198 : check e2422407489198 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407489206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2422407489206 : Closed e2422407489206 ∧ code e2422407489206 = 11218500511414 := by decide
theorem cert_e2422407489206 : check e2422407489206 [[],[]] .chain = true := by decide
def e2422407489210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422407489210 : Closed e2422407489210 ∧ code e2422407489210 = 11218500511418 := by decide
theorem cert_e2422407489210 : check e2422407489210 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407489238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422407489238 : Closed e2422407489238 ∧ code e2422407489238 = 11218500511446 := by decide
theorem cert_e2422407489238 : check e2422407489238 [[],[]] .chain = true := by decide
def e2422407489242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422407489242 : Closed e2422407489242 ∧ code e2422407489242 = 11218500511450 := by decide
theorem cert_e2422407489242 : check e2422407489242 [[],[]] .chain = true := by decide
def e2422407489258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422407489258 : Closed e2422407489258 ∧ code e2422407489258 = 11218500511466 := by decide
theorem cert_e2422407489258 : check e2422407489258 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407489366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422407489366 : Closed e2422407489366 ∧ code e2422407489366 = 11218500511574 := by decide
theorem cert_e2422407489366 : check e2422407489366 [[],[]] .chain = true := by decide
def e2422407489370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422407489370 : Closed e2422407489370 ∧ code e2422407489370 = 11218500511578 := by decide
theorem cert_e2422407489370 : check e2422407489370 [[],[]] .chain = true := by decide
def e2422407489386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422407489386 : Closed e2422407489386 ∧ code e2422407489386 = 11218500511594 := by decide
theorem cert_e2422407489386 : check e2422407489386 [[],[]] .chain = true := by decide
def e2422407489450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422407489450 : Closed e2422407489450 ∧ code e2422407489450 = 11218500511658 := by decide
theorem cert_e2422407489450 : check e2422407489450 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407489546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407489546 : Closed e2422407489546 ∧ code e2422407489546 = 11218500511754 := by decide
theorem cert_e2422407489546 : check e2422407489546 [[],[]] .chain = true := by decide
def e2422407489582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407489582 : Closed e2422407489582 ∧ code e2422407489582 = 11218500511790 := by decide
theorem cert_e2422407489582 : check e2422407489582 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407489590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407489590 : Closed e2422407489590 ∧ code e2422407489590 = 11218500511798 := by decide
theorem cert_e2422407489590 : check e2422407489590 [[],[]] .chain = true := by decide
def e2422407489594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407489594 : Closed e2422407489594 ∧ code e2422407489594 = 11218500511802 := by decide
theorem cert_e2422407489594 : check e2422407489594 [[],[]] .chain = true := by decide
def e2422407489642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407489642 : Closed e2422407489642 ∧ code e2422407489642 = 11218500511850 := by decide
theorem cert_e2422407489642 : check e2422407489642 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407489678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407489678 : Closed e2422407489678 ∧ code e2422407489678 = 11218500511886 := by decide
theorem cert_e2422407489678 : check e2422407489678 [[],[]] .chain = true := by decide
def e2422407489690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407489690 : Closed e2422407489690 ∧ code e2422407489690 = 11218500511898 := by decide
theorem cert_e2422407489690 : check e2422407489690 [[],[]] .chain = true := by decide
def e2422407489734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407489734 : Closed e2422407489734 ∧ code e2422407489734 = 11218500511942 := by decide
theorem cert_e2422407489734 : check e2422407489734 [[],[]] .chain = true := by decide
def e2422407489762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407489762 : Closed e2422407489762 ∧ code e2422407489762 = 11218500511970 := by decide
theorem cert_e2422407489762 : check e2422407489762 [[],[]] .chain = true := by decide
def e2422407489774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422407489774 : Closed e2422407489774 ∧ code e2422407489774 = 11218500511982 := by decide
theorem cert_e2422407489774 : check e2422407489774 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407489782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422407489782 : Closed e2422407489782 ∧ code e2422407489782 = 11218500511990 := by decide
theorem cert_e2422407489782 : check e2422407489782 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407489930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407489930 : Closed e2422407489930 ∧ code e2422407489930 = 11218500512138 := by decide
theorem cert_e2422407489930 : check e2422407489930 [[],[]] .chain = true := by decide
def e2422407489954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407489954 : Closed e2422407489954 ∧ code e2422407489954 = 11218500512162 := by decide
theorem cert_e2422407489954 : check e2422407489954 [[],[]] .chain = true := by decide
def e2422407489966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407489966 : Closed e2422407489966 ∧ code e2422407489966 = 11218500512174 := by decide
theorem cert_e2422407489966 : check e2422407489966 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407489974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422407489974 : Closed e2422407489974 ∧ code e2422407489974 = 11218500512182 := by decide
theorem cert_e2422407489974 : check e2422407489974 [[],[]] .chain = true := by decide
def e2422407489978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407489978 : Closed e2422407489978 ∧ code e2422407489978 = 11218500512186 := by decide
theorem cert_e2422407489978 : check e2422407489978 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
end Blc.Floor43
