import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418335202682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2418335202682 : Closed e2418335202682 ∧ code e2418335202682 = 11214428224890 := by decide
theorem cert_e2418335202682 : check e2418335202682 [[],[]] .three = true := by decide
def e2418335202734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2418335202734 : Closed e2418335202734 ∧ code e2418335202734 = 11214428224942 := by decide
theorem cert_e2418335202734 : check e2418335202734 [[],[]] .smaller = true := by decide
def e2418335202746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2418335202746 : Closed e2418335202746 ∧ code e2418335202746 = 11214428224954 := by decide
theorem cert_e2418335202746 : check e2418335202746 [[],[]] .smaller = true := by decide
def e2418335202774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2418335202774 : Closed e2418335202774 ∧ code e2418335202774 = 11214428224982 := by decide
theorem cert_e2418335202774 : check e2418335202774 [[],[]] .smaller = true := by decide
def e2418335202778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2418335202778 : Closed e2418335202778 ∧ code e2418335202778 = 11214428224986 := by decide
theorem cert_e2418335202778 : check e2418335202778 [[],[]] .smaller = true := by decide
def e2418335202794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2418335202794 : Closed e2418335202794 ∧ code e2418335202794 = 11214428225002 := by decide
theorem cert_e2418335202794 : check e2418335202794 [[],[]] .three = true := by decide
def e2418335202990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2418335202990 : Closed e2418335202990 ∧ code e2418335202990 = 11214428225198 := by decide
theorem cert_e2418335202990 : check e2418335202990 [[],[]] .three = true := by decide
def e2418335202998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2418335202998 : Closed e2418335202998 ∧ code e2418335202998 = 11214428225206 := by decide
theorem cert_e2418335202998 : check e2418335202998 [[],[]] .three = true := by decide
def e2418335203002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2418335203002 : Closed e2418335203002 ∧ code e2418335203002 = 11214428225210 := by decide
theorem cert_e2418335203002 : check e2418335203002 [[],[]] .three = true := by decide
def e2418335203030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2418335203030 : Closed e2418335203030 ∧ code e2418335203030 = 11214428225238 := by decide
theorem cert_e2418335203030 : check e2418335203030 [[],[]] .three = true := by decide
def e2418335203034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2418335203034 : Closed e2418335203034 ∧ code e2418335203034 = 11214428225242 := by decide
theorem cert_e2418335203034 : check e2418335203034 [[],[]] .three = true := by decide
def e2418335203050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2418335203050 : Closed e2418335203050 ∧ code e2418335203050 = 11214428225258 := by decide
theorem cert_e2418335203050 : check e2418335203050 [[],[]] .three = true := by decide
def e2418335206878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2418335206878 : Closed e2418335206878 ∧ code e2418335206878 = 11214428229086 := by decide
theorem cert_e2418335206878 : check e2418335206878 [[],[]] .three = true := by decide
def e2418335206894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2418335206894 : Closed e2418335206894 ∧ code e2418335206894 = 11214428229102 := by decide
theorem cert_e2418335206894 : check e2418335206894 [[],[]] .three = true := by decide
def e2418335207134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2418335207134 : Closed e2418335207134 ∧ code e2418335207134 = 11214428229342 := by decide
theorem cert_e2418335207134 : check e2418335207134 [[],[]] .three = true := by decide
def e2418335207150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2418335207150 : Closed e2418335207150 ∧ code e2418335207150 = 11214428229358 := by decide
theorem cert_e2418335207150 : check e2418335207150 [[],[]] .smaller = true := by decide
def e2418335207158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2418335207158 : Closed e2418335207158 ∧ code e2418335207158 = 11214428229366 := by decide
theorem cert_e2418335207158 : check e2418335207158 [[],[]] .three = true := by decide
def e2418335207262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2418335207262 : Closed e2418335207262 ∧ code e2418335207262 = 11214428229470 := by decide
theorem cert_e2418335207262 : check e2418335207262 [[],[]] .three = true := by decide
def e2418335207278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2418335207278 : Closed e2418335207278 ∧ code e2418335207278 = 11214428229486 := by decide
theorem cert_e2418335207278 : check e2418335207278 [[],[]] .smaller = true := by decide
def e2418335207286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2418335207286 : Closed e2418335207286 ∧ code e2418335207286 = 11214428229494 := by decide
theorem cert_e2418335207286 : check e2418335207286 [[],[]] .smaller = true := by decide
def e2418335207290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2418335207290 : Closed e2418335207290 ∧ code e2418335207290 = 11214428229498 := by decide
theorem cert_e2418335207290 : check e2418335207290 [[],[]] .three = true := by decide
def e2418335207342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2418335207342 : Closed e2418335207342 ∧ code e2418335207342 = 11214428229550 := by decide
theorem cert_e2418335207342 : check e2418335207342 [[],[]] .three = true := by decide
def e2418335207350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2418335207350 : Closed e2418335207350 ∧ code e2418335207350 = 11214428229558 := by decide
theorem cert_e2418335207350 : check e2418335207350 [[],[]] .three = true := by decide
def e2418335207354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2418335207354 : Closed e2418335207354 ∧ code e2418335207354 = 11214428229562 := by decide
theorem cert_e2418335207354 : check e2418335207354 [[],[]] .three = true := by decide
def e2418335208414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2418335208414 : Closed e2418335208414 ∧ code e2418335208414 = 11214428230622 := by decide
theorem cert_e2418335208414 : check e2418335208414 [[],[]] .three = true := by decide
def e2418335208430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2418335208430 : Closed e2418335208430 ∧ code e2418335208430 = 11214428230638 := by decide
theorem cert_e2418335208430 : check e2418335208430 [[],[]] .three = true := by decide
def e2418335209950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2418335209950 : Closed e2418335209950 ∧ code e2418335209950 = 11214428232158 := by decide
theorem cert_e2418335209950 : check e2418335209950 [[],[]] .three = true := by decide
def e2418335209966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))))
theorem wire_e2418335209966 : Closed e2418335209966 ∧ code e2418335209966 = 11214428232174 := by decide
theorem cert_e2418335209966 : check e2418335209966 [[],[]] .smaller = true := by decide
def e2418335209974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2418335209974 : Closed e2418335209974 ∧ code e2418335209974 = 11214428232182 := by decide
theorem cert_e2418335209974 : check e2418335209974 [[],[]] .three = true := by decide
def e2418335210718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2418335210718 : Closed e2418335210718 ∧ code e2418335210718 = 11214428232926 := by decide
theorem cert_e2418335210718 : check e2418335210718 [[],[]] .three = true := by decide
def e2418335210734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418335210734 : Closed e2418335210734 ∧ code e2418335210734 = 11214428232942 := by decide
theorem cert_e2418335210734 : check e2418335210734 [[],[]] .smaller = true := by decide
def e2418335210742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418335210742 : Closed e2418335210742 ∧ code e2418335210742 = 11214428232950 := by decide
theorem cert_e2418335210742 : check e2418335210742 [[],[]] .smaller = true := by decide
def e2418335210746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2418335210746 : Closed e2418335210746 ∧ code e2418335210746 = 11214428232954 := by decide
theorem cert_e2418335210746 : check e2418335210746 [[],[]] .three = true := by decide
def e2418335211118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335211118 : Closed e2418335211118 ∧ code e2418335211118 = 11214428233326 := by decide
theorem cert_e2418335211118 : check e2418335211118 [[],[]] .three = true := by decide
def e2418335211126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2418335211126 : Closed e2418335211126 ∧ code e2418335211126 = 11214428233334 := by decide
theorem cert_e2418335211126 : check e2418335211126 [[],[]] .three = true := by decide
def e2418335211130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335211130 : Closed e2418335211130 ∧ code e2418335211130 = 11214428233338 := by decide
theorem cert_e2418335211130 : check e2418335211130 [[],[]] .three = true := by decide
def e2418335213278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2418335213278 : Closed e2418335213278 ∧ code e2418335213278 = 11214428235486 := by decide
theorem cert_e2418335213278 : check e2418335213278 [[],[]] .three = true := by decide
def e2418335213294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2418335213294 : Closed e2418335213294 ∧ code e2418335213294 = 11214428235502 := by decide
theorem cert_e2418335213294 : check e2418335213294 [[],[]] .smaller = true := by decide
def e2418335213302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2418335213302 : Closed e2418335213302 ∧ code e2418335213302 = 11214428235510 := by decide
theorem cert_e2418335213302 : check e2418335213302 [[],[]] .three = true := by decide
def e2418335213406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2418335213406 : Closed e2418335213406 ∧ code e2418335213406 = 11214428235614 := by decide
theorem cert_e2418335213406 : check e2418335213406 [[],[]] .three = true := by decide
def e2418335213434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2418335213434 : Closed e2418335213434 ∧ code e2418335213434 = 11214428235642 := by decide
theorem cert_e2418335213434 : check e2418335213434 [[],[]] .three = true := by decide
def e2418335213486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2418335213486 : Closed e2418335213486 ∧ code e2418335213486 = 11214428235694 := by decide
theorem cert_e2418335213486 : check e2418335213486 [[],[]] .smaller = true := by decide
def e2418335213498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2418335213498 : Closed e2418335213498 ∧ code e2418335213498 = 11214428235706 := by decide
theorem cert_e2418335213498 : check e2418335213498 [[],[]] .smaller = true := by decide
def e2418335213526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2418335213526 : Closed e2418335213526 ∧ code e2418335213526 = 11214428235734 := by decide
theorem cert_e2418335213526 : check e2418335213526 [[],[]] .three = true := by decide
def e2418335213530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2418335213530 : Closed e2418335213530 ∧ code e2418335213530 = 11214428235738 := by decide
theorem cert_e2418335213530 : check e2418335213530 [[],[]] .three = true := by decide
def e2418335214046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2418335214046 : Closed e2418335214046 ∧ code e2418335214046 = 11214428236254 := by decide
theorem cert_e2418335214046 : check e2418335214046 [[],[]] .three = true := by decide
def e2418335214062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2418335214062 : Closed e2418335214062 ∧ code e2418335214062 = 11214428236270 := by decide
theorem cert_e2418335214062 : check e2418335214062 [[],[]] .smaller = true := by decide
def e2418335214070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2418335214070 : Closed e2418335214070 ∧ code e2418335214070 = 11214428236278 := by decide
theorem cert_e2418335214070 : check e2418335214070 [[],[]] .three = true := by decide
def e2418335214814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2418335214814 : Closed e2418335214814 ∧ code e2418335214814 = 11214428237022 := by decide
theorem cert_e2418335214814 : check e2418335214814 [[],[]] .three = true := by decide
def e2418335214842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2418335214842 : Closed e2418335214842 ∧ code e2418335214842 = 11214428237050 := by decide
theorem cert_e2418335214842 : check e2418335214842 [[],[]] .three = true := by decide
def e2418335215214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335215214 : Closed e2418335215214 ∧ code e2418335215214 = 11214428237422 := by decide
theorem cert_e2418335215214 : check e2418335215214 [[],[]] .smaller = true := by decide
def e2418335215226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335215226 : Closed e2418335215226 ∧ code e2418335215226 = 11214428237434 := by decide
theorem cert_e2418335215226 : check e2418335215226 [[],[]] .smaller = true := by decide
def e2418335215414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335215414 : Closed e2418335215414 ∧ code e2418335215414 = 11214428237622 := by decide
theorem cert_e2418335215414 : check e2418335215414 [[],[]] .three = true := by decide
def e2418335215418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335215418 : Closed e2418335215418 ∧ code e2418335215418 = 11214428237626 := by decide
theorem cert_e2418335215418 : check e2418335215418 [[],[]] .three = true := by decide
def e2418335216478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2418335216478 : Closed e2418335216478 ∧ code e2418335216478 = 11214428238686 := by decide
theorem cert_e2418335216478 : check e2418335216478 [[],[]] .three = true := by decide
def e2418335216494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2418335216494 : Closed e2418335216494 ∧ code e2418335216494 = 11214428238702 := by decide
theorem cert_e2418335216494 : check e2418335216494 [[],[]] .smaller = true := by decide
def e2418335216502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2418335216502 : Closed e2418335216502 ∧ code e2418335216502 = 11214428238710 := by decide
theorem cert_e2418335216502 : check e2418335216502 [[],[]] .smaller = true := by decide
def e2418335216506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2418335216506 : Closed e2418335216506 ∧ code e2418335216506 = 11214428238714 := by decide
theorem cert_e2418335216506 : check e2418335216506 [[],[]] .three = true := by decide
def e2418335216558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2418335216558 : Closed e2418335216558 ∧ code e2418335216558 = 11214428238766 := by decide
theorem cert_e2418335216558 : check e2418335216558 [[],[]] .smaller = true := by decide
def e2418335216570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2418335216570 : Closed e2418335216570 ∧ code e2418335216570 = 11214428238778 := by decide
theorem cert_e2418335216570 : check e2418335216570 [[],[]] .smaller = true := by decide
def e2418335216598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2418335216598 : Closed e2418335216598 ∧ code e2418335216598 = 11214428238806 := by decide
theorem cert_e2418335216598 : check e2418335216598 [[],[]] .smaller = true := by decide
def e2418335216602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2418335216602 : Closed e2418335216602 ∧ code e2418335216602 = 11214428238810 := by decide
theorem cert_e2418335216602 : check e2418335216602 [[],[]] .smaller = true := by decide
def e2418335216618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2418335216618 : Closed e2418335216618 ∧ code e2418335216618 = 11214428238826 := by decide
theorem cert_e2418335216618 : check e2418335216618 [[],[]] .three = true := by decide
def e2418335216862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2418335216862 : Closed e2418335216862 ∧ code e2418335216862 = 11214428239070 := by decide
theorem cert_e2418335216862 : check e2418335216862 [[],[]] .three = true := by decide
def e2418335216878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418335216878 : Closed e2418335216878 ∧ code e2418335216878 = 11214428239086 := by decide
theorem cert_e2418335216878 : check e2418335216878 [[],[]] .smaller = true := by decide
def e2418335216886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418335216886 : Closed e2418335216886 ∧ code e2418335216886 = 11214428239094 := by decide
theorem cert_e2418335216886 : check e2418335216886 [[],[]] .smaller = true := by decide
def e2418335216890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2418335216890 : Closed e2418335216890 ∧ code e2418335216890 = 11214428239098 := by decide
theorem cert_e2418335216890 : check e2418335216890 [[],[]] .three = true := by decide
def e2418335217262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335217262 : Closed e2418335217262 ∧ code e2418335217262 = 11214428239470 := by decide
theorem cert_e2418335217262 : check e2418335217262 [[],[]] .smaller = true := by decide
def e2418335217274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335217274 : Closed e2418335217274 ∧ code e2418335217274 = 11214428239482 := by decide
theorem cert_e2418335217274 : check e2418335217274 [[],[]] .smaller = true := by decide
def e2418335217462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335217462 : Closed e2418335217462 ∧ code e2418335217462 = 11214428239670 := by decide
theorem cert_e2418335217462 : check e2418335217462 [[],[]] .smaller = true := by decide
def e2418335217466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335217466 : Closed e2418335217466 ∧ code e2418335217466 = 11214428239674 := by decide
theorem cert_e2418335217466 : check e2418335217466 [[],[]] .smaller = true := by decide
def e2418335217562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335217562 : Closed e2418335217562 ∧ code e2418335217562 = 11214428239770 := by decide
theorem cert_e2418335217562 : check e2418335217562 [[],[]] .three = true := by decide
def e2418335218094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2418335218094 : Closed e2418335218094 ∧ code e2418335218094 = 11214428240302 := by decide
theorem cert_e2418335218094 : check e2418335218094 [[],[]] .three = true := by decide
def e2418335218102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2418335218102 : Closed e2418335218102 ∧ code e2418335218102 = 11214428240310 := by decide
theorem cert_e2418335218102 : check e2418335218102 [[],[]] .three = true := by decide
def e2418335218106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2418335218106 : Closed e2418335218106 ∧ code e2418335218106 = 11214428240314 := by decide
theorem cert_e2418335218106 : check e2418335218106 [[],[]] .three = true := by decide
def e2418335218134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2418335218134 : Closed e2418335218134 ∧ code e2418335218134 = 11214428240342 := by decide
theorem cert_e2418335218134 : check e2418335218134 [[],[]] .three = true := by decide
def e2418335218138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2418335218138 : Closed e2418335218138 ∧ code e2418335218138 = 11214428240346 := by decide
theorem cert_e2418335218138 : check e2418335218138 [[],[]] .three = true := by decide
def e2418335218154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2418335218154 : Closed e2418335218154 ∧ code e2418335218154 = 11214428240362 := by decide
theorem cert_e2418335218154 : check e2418335218154 [[],[]] .three = true := by decide
def e2418335218286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335218286 : Closed e2418335218286 ∧ code e2418335218286 = 11214428240494 := by decide
theorem cert_e2418335218286 : check e2418335218286 [[],[]] .three = true := by decide
def e2418335218294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2418335218294 : Closed e2418335218294 ∧ code e2418335218294 = 11214428240502 := by decide
theorem cert_e2418335218294 : check e2418335218294 [[],[]] .three = true := by decide
def e2418335218298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335218298 : Closed e2418335218298 ∧ code e2418335218298 = 11214428240506 := by decide
theorem cert_e2418335218298 : check e2418335218298 [[],[]] .three = true := by decide
def e2418335218486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335218486 : Closed e2418335218486 ∧ code e2418335218486 = 11214428240694 := by decide
theorem cert_e2418335218486 : check e2418335218486 [[],[]] .three = true := by decide
def e2418335218490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335218490 : Closed e2418335218490 ∧ code e2418335218490 = 11214428240698 := by decide
theorem cert_e2418335218490 : check e2418335218490 [[],[]] .three = true := by decide
def e2418335218586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335218586 : Closed e2418335218586 ∧ code e2418335218586 = 11214428240794 := by decide
theorem cert_e2418335218586 : check e2418335218586 [[],[]] .three = true := by decide
def e2418335222638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2418335222638 : Closed e2418335222638 ∧ code e2418335222638 = 11214428244846 := by decide
theorem cert_e2418335222638 : check e2418335222638 [[],[]] .smaller = true := by decide
def e2418335222646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2418335222646 : Closed e2418335222646 ∧ code e2418335222646 = 11214428244854 := by decide
theorem cert_e2418335222646 : check e2418335222646 [[],[]] .smaller = true := by decide
def e2418335222702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2418335222702 : Closed e2418335222702 ∧ code e2418335222702 = 11214428244910 := by decide
theorem cert_e2418335222702 : check e2418335222702 [[],[]] .smaller = true := by decide
def e2418335222714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2418335222714 : Closed e2418335222714 ∧ code e2418335222714 = 11214428244922 := by decide
theorem cert_e2418335222714 : check e2418335222714 [[],[]] .smaller = true := by decide
def e2418335222742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2418335222742 : Closed e2418335222742 ∧ code e2418335222742 = 11214428244950 := by decide
theorem cert_e2418335222742 : check e2418335222742 [[],[]] .smaller = true := by decide
def e2418335222746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2418335222746 : Closed e2418335222746 ∧ code e2418335222746 = 11214428244954 := by decide
theorem cert_e2418335222746 : check e2418335222746 [[],[]] .smaller = true := by decide
def e2418335223022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2418335223022 : Closed e2418335223022 ∧ code e2418335223022 = 11214428245230 := by decide
theorem cert_e2418335223022 : check e2418335223022 [[],[]] .smaller = true := by decide
def e2418335223030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2418335223030 : Closed e2418335223030 ∧ code e2418335223030 = 11214428245238 := by decide
theorem cert_e2418335223030 : check e2418335223030 [[],[]] .smaller = true := by decide
def e2418335223406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2418335223406 : Closed e2418335223406 ∧ code e2418335223406 = 11214428245614 := by decide
theorem cert_e2418335223406 : check e2418335223406 [[],[]] .smaller = true := by decide
def e2418335223418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2418335223418 : Closed e2418335223418 ∧ code e2418335223418 = 11214428245626 := by decide
theorem cert_e2418335223418 : check e2418335223418 [[],[]] .smaller = true := by decide
def e2418335223606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2418335223606 : Closed e2418335223606 ∧ code e2418335223606 = 11214428245814 := by decide
theorem cert_e2418335223606 : check e2418335223606 [[],[]] .smaller = true := by decide
def e2418335223610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2418335223610 : Closed e2418335223610 ∧ code e2418335223610 = 11214428245818 := by decide
theorem cert_e2418335223610 : check e2418335223610 [[],[]] .smaller = true := by decide
def e2418335231454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2418335231454 : Closed e2418335231454 ∧ code e2418335231454 = 11214428253662 := by decide
theorem cert_e2418335231454 : check e2418335231454 [[],[]] .three = true := by decide
def e2418335231470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2418335231470 : Closed e2418335231470 ∧ code e2418335231470 = 11214428253678 := by decide
theorem cert_e2418335231470 : check e2418335231470 [[],[]] .three = true := by decide
def e2418335231710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))
theorem wire_e2418335231710 : Closed e2418335231710 ∧ code e2418335231710 = 11214428253918 := by decide
theorem cert_e2418335231710 : check e2418335231710 [[],[]] .three = true := by decide
def e2418335231726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2418335231726 : Closed e2418335231726 ∧ code e2418335231726 = 11214428253934 := by decide
theorem cert_e2418335231726 : check e2418335231726 [[],[]] .smaller = true := by decide
def e2418335231734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))
theorem wire_e2418335231734 : Closed e2418335231734 ∧ code e2418335231734 = 11214428253942 := by decide
theorem cert_e2418335231734 : check e2418335231734 [[],[]] .three = true := by decide
def e2418335231838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2418335231838 : Closed e2418335231838 ∧ code e2418335231838 = 11214428254046 := by decide
theorem cert_e2418335231838 : check e2418335231838 [[],[]] .three = true := by decide
def e2418335231854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2418335231854 : Closed e2418335231854 ∧ code e2418335231854 = 11214428254062 := by decide
theorem cert_e2418335231854 : check e2418335231854 [[],[]] .smaller = true := by decide
def e2418335231862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2418335231862 : Closed e2418335231862 ∧ code e2418335231862 = 11214428254070 := by decide
theorem cert_e2418335231862 : check e2418335231862 [[],[]] .smaller = true := by decide
def e2418335231866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2418335231866 : Closed e2418335231866 ∧ code e2418335231866 = 11214428254074 := by decide
theorem cert_e2418335231866 : check e2418335231866 [[],[]] .three = true := by decide
def e2418335231918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2418335231918 : Closed e2418335231918 ∧ code e2418335231918 = 11214428254126 := by decide
theorem cert_e2418335231918 : check e2418335231918 [[],[]] .three = true := by decide
def e2418335231926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))
theorem wire_e2418335231926 : Closed e2418335231926 ∧ code e2418335231926 = 11214428254134 := by decide
theorem cert_e2418335231926 : check e2418335231926 [[],[]] .three = true := by decide
def e2418335231930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2418335231930 : Closed e2418335231930 ∧ code e2418335231930 = 11214428254138 := by decide
theorem cert_e2418335231930 : check e2418335231930 [[],[]] .three = true := by decide
def e2418335232990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2418335232990 : Closed e2418335232990 ∧ code e2418335232990 = 11214428255198 := by decide
theorem cert_e2418335232990 : check e2418335232990 [[],[]] .three = true := by decide
def e2418335233006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2418335233006 : Closed e2418335233006 ∧ code e2418335233006 = 11214428255214 := by decide
theorem cert_e2418335233006 : check e2418335233006 [[],[]] .three = true := by decide
def e2418335234526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))
theorem wire_e2418335234526 : Closed e2418335234526 ∧ code e2418335234526 = 11214428256734 := by decide
theorem cert_e2418335234526 : check e2418335234526 [[],[]] .three = true := by decide
def e2418335234542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2418335234542 : Closed e2418335234542 ∧ code e2418335234542 = 11214428256750 := by decide
theorem cert_e2418335234542 : check e2418335234542 [[],[]] .smaller = true := by decide
def e2418335234550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))
theorem wire_e2418335234550 : Closed e2418335234550 ∧ code e2418335234550 = 11214428256758 := by decide
theorem cert_e2418335234550 : check e2418335234550 [[],[]] .three = true := by decide
def e2418335235294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418335235294 : Closed e2418335235294 ∧ code e2418335235294 = 11214428257502 := by decide
theorem cert_e2418335235294 : check e2418335235294 [[],[]] .three = true := by decide
def e2418335235310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418335235310 : Closed e2418335235310 ∧ code e2418335235310 = 11214428257518 := by decide
theorem cert_e2418335235310 : check e2418335235310 [[],[]] .smaller = true := by decide
def e2418335235318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418335235318 : Closed e2418335235318 ∧ code e2418335235318 = 11214428257526 := by decide
theorem cert_e2418335235318 : check e2418335235318 [[],[]] .smaller = true := by decide
def e2418335235322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418335235322 : Closed e2418335235322 ∧ code e2418335235322 = 11214428257530 := by decide
theorem cert_e2418335235322 : check e2418335235322 [[],[]] .three = true := by decide
def e2418335235694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335235694 : Closed e2418335235694 ∧ code e2418335235694 = 11214428257902 := by decide
theorem cert_e2418335235694 : check e2418335235694 [[],[]] .three = true := by decide
def e2418335235702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))
theorem wire_e2418335235702 : Closed e2418335235702 ∧ code e2418335235702 = 11214428257910 := by decide
theorem cert_e2418335235702 : check e2418335235702 [[],[]] .three = true := by decide
def e2418335235706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335235706 : Closed e2418335235706 ∧ code e2418335235706 = 11214428257914 := by decide
theorem cert_e2418335235706 : check e2418335235706 [[],[]] .three = true := by decide
def e2418335258334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2418335258334 : Closed e2418335258334 ∧ code e2418335258334 = 11214428280542 := by decide
theorem cert_e2418335258334 : check e2418335258334 [[],[]] .three = true := by decide
def e2418335258350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2418335258350 : Closed e2418335258350 ∧ code e2418335258350 = 11214428280558 := by decide
theorem cert_e2418335258350 : check e2418335258350 [[],[]] .smaller = true := by decide
def e2418335258358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2418335258358 : Closed e2418335258358 ∧ code e2418335258358 = 11214428280566 := by decide
theorem cert_e2418335258358 : check e2418335258358 [[],[]] .three = true := by decide
def e2418335258462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2418335258462 : Closed e2418335258462 ∧ code e2418335258462 = 11214428280670 := by decide
theorem cert_e2418335258462 : check e2418335258462 [[],[]] .three = true := by decide
def e2418335258490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2418335258490 : Closed e2418335258490 ∧ code e2418335258490 = 11214428280698 := by decide
theorem cert_e2418335258490 : check e2418335258490 [[],[]] .three = true := by decide
def e2418335258542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2418335258542 : Closed e2418335258542 ∧ code e2418335258542 = 11214428280750 := by decide
theorem cert_e2418335258542 : check e2418335258542 [[],[]] .smaller = true := by decide
def e2418335258554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2418335258554 : Closed e2418335258554 ∧ code e2418335258554 = 11214428280762 := by decide
theorem cert_e2418335258554 : check e2418335258554 [[],[]] .smaller = true := by decide
def e2418335258582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2418335258582 : Closed e2418335258582 ∧ code e2418335258582 = 11214428280790 := by decide
theorem cert_e2418335258582 : check e2418335258582 [[],[]] .three = true := by decide
def e2418335258586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2418335258586 : Closed e2418335258586 ∧ code e2418335258586 = 11214428280794 := by decide
theorem cert_e2418335258586 : check e2418335258586 [[],[]] .three = true := by decide
def e2418335259102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2418335259102 : Closed e2418335259102 ∧ code e2418335259102 = 11214428281310 := by decide
theorem cert_e2418335259102 : check e2418335259102 [[],[]] .three = true := by decide
def e2418335259118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2418335259118 : Closed e2418335259118 ∧ code e2418335259118 = 11214428281326 := by decide
theorem cert_e2418335259118 : check e2418335259118 [[],[]] .smaller = true := by decide
def e2418335259126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2418335259126 : Closed e2418335259126 ∧ code e2418335259126 = 11214428281334 := by decide
theorem cert_e2418335259126 : check e2418335259126 [[],[]] .three = true := by decide
def e2418335259870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418335259870 : Closed e2418335259870 ∧ code e2418335259870 = 11214428282078 := by decide
theorem cert_e2418335259870 : check e2418335259870 [[],[]] .three = true := by decide
def e2418335259898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418335259898 : Closed e2418335259898 ∧ code e2418335259898 = 11214428282106 := by decide
theorem cert_e2418335259898 : check e2418335259898 [[],[]] .three = true := by decide
def e2418335260270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335260270 : Closed e2418335260270 ∧ code e2418335260270 = 11214428282478 := by decide
theorem cert_e2418335260270 : check e2418335260270 [[],[]] .smaller = true := by decide
def e2418335260282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335260282 : Closed e2418335260282 ∧ code e2418335260282 = 11214428282490 := by decide
theorem cert_e2418335260282 : check e2418335260282 [[],[]] .smaller = true := by decide
def e2418335260470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418335260470 : Closed e2418335260470 ∧ code e2418335260470 = 11214428282678 := by decide
theorem cert_e2418335260470 : check e2418335260470 [[],[]] .three = true := by decide
def e2418335260474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418335260474 : Closed e2418335260474 ∧ code e2418335260474 = 11214428282682 := by decide
theorem cert_e2418335260474 : check e2418335260474 [[],[]] .three = true := by decide
def e2418335271774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2418335271774 : Closed e2418335271774 ∧ code e2418335271774 = 11214428293982 := by decide
theorem cert_e2418335271774 : check e2418335271774 [[],[]] .three = true := by decide
def e2418335271790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418335271790 : Closed e2418335271790 ∧ code e2418335271790 = 11214428293998 := by decide
theorem cert_e2418335271790 : check e2418335271790 [[],[]] .smaller = true := by decide
def e2418335271798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418335271798 : Closed e2418335271798 ∧ code e2418335271798 = 11214428294006 := by decide
theorem cert_e2418335271798 : check e2418335271798 [[],[]] .smaller = true := by decide
def e2418335271802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2418335271802 : Closed e2418335271802 ∧ code e2418335271802 = 11214428294010 := by decide
theorem cert_e2418335271802 : check e2418335271802 [[],[]] .three = true := by decide
def e2418335271854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418335271854 : Closed e2418335271854 ∧ code e2418335271854 = 11214428294062 := by decide
theorem cert_e2418335271854 : check e2418335271854 [[],[]] .smaller = true := by decide
def e2418335271866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418335271866 : Closed e2418335271866 ∧ code e2418335271866 = 11214428294074 := by decide
theorem cert_e2418335271866 : check e2418335271866 [[],[]] .smaller = true := by decide
def e2418335271894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418335271894 : Closed e2418335271894 ∧ code e2418335271894 = 11214428294102 := by decide
theorem cert_e2418335271894 : check e2418335271894 [[],[]] .smaller = true := by decide
def e2418335271898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418335271898 : Closed e2418335271898 ∧ code e2418335271898 = 11214428294106 := by decide
theorem cert_e2418335271898 : check e2418335271898 [[],[]] .smaller = true := by decide
def e2418335271914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2418335271914 : Closed e2418335271914 ∧ code e2418335271914 = 11214428294122 := by decide
theorem cert_e2418335271914 : check e2418335271914 [[],[]] .three = true := by decide
def e2418335272158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418335272158 : Closed e2418335272158 ∧ code e2418335272158 = 11214428294366 := by decide
theorem cert_e2418335272158 : check e2418335272158 [[],[]] .three = true := by decide
def e2418335272174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418335272174 : Closed e2418335272174 ∧ code e2418335272174 = 11214428294382 := by decide
theorem cert_e2418335272174 : check e2418335272174 [[],[]] .smaller = true := by decide
def e2418335272182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418335272182 : Closed e2418335272182 ∧ code e2418335272182 = 11214428294390 := by decide
theorem cert_e2418335272182 : check e2418335272182 [[],[]] .smaller = true := by decide
def e2418335272186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418335272186 : Closed e2418335272186 ∧ code e2418335272186 = 11214428294394 := by decide
theorem cert_e2418335272186 : check e2418335272186 [[],[]] .three = true := by decide
def e2418335272558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418335272558 : Closed e2418335272558 ∧ code e2418335272558 = 11214428294766 := by decide
theorem cert_e2418335272558 : check e2418335272558 [[],[]] .smaller = true := by decide
def e2418335272570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418335272570 : Closed e2418335272570 ∧ code e2418335272570 = 11214428294778 := by decide
theorem cert_e2418335272570 : check e2418335272570 [[],[]] .smaller = true := by decide
def e2418335272758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418335272758 : Closed e2418335272758 ∧ code e2418335272758 = 11214428294966 := by decide
theorem cert_e2418335272758 : check e2418335272758 [[],[]] .smaller = true := by decide
def e2418335272762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418335272762 : Closed e2418335272762 ∧ code e2418335272762 = 11214428294970 := by decide
theorem cert_e2418335272762 : check e2418335272762 [[],[]] .smaller = true := by decide
def e2418335272858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418335272858 : Closed e2418335272858 ∧ code e2418335272858 = 11214428295066 := by decide
theorem cert_e2418335272858 : check e2418335272858 [[],[]] .three = true := by decide
def e2418335278510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2418335278510 : Closed e2418335278510 ∧ code e2418335278510 = 11214428300718 := by decide
theorem cert_e2418335278510 : check e2418335278510 [[],[]] .three = true := by decide
def e2418335278518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2418335278518 : Closed e2418335278518 ∧ code e2418335278518 = 11214428300726 := by decide
theorem cert_e2418335278518 : check e2418335278518 [[],[]] .three = true := by decide
def e2418335278522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2418335278522 : Closed e2418335278522 ∧ code e2418335278522 = 11214428300730 := by decide
theorem cert_e2418335278522 : check e2418335278522 [[],[]] .three = true := by decide
def e2418335278550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2418335278550 : Closed e2418335278550 ∧ code e2418335278550 = 11214428300758 := by decide
theorem cert_e2418335278550 : check e2418335278550 [[],[]] .three = true := by decide
end Blc.Floor43
