import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422361617130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))))
theorem wire_e2422361617130 : Closed e2422361617130 ∧ code e2422361617130 = 11218454639338 := by decide
theorem cert_e2422361617130 : check e2422361617130 [[],[]] .smaller = true := by decide
def e2422361617206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))))
theorem wire_e2422361617206 : Closed e2422361617206 ∧ code e2422361617206 = 11218454639414 := by decide
theorem cert_e2422361617206 : check e2422361617206 [[],[]] .smaller = true := by decide
def e2422361617210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))))
theorem wire_e2422361617210 : Closed e2422361617210 ∧ code e2422361617210 = 11218454639418 := by decide
theorem cert_e2422361617210 : check e2422361617210 [[],[]] .smaller = true := by decide
def e2422361617306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))))
theorem wire_e2422361617306 : Closed e2422361617306 ∧ code e2422361617306 = 11218454639514 := by decide
theorem cert_e2422361617306 : check e2422361617306 [[],[]] .smaller = true := by decide
def e2422361732542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4))))))))))
theorem wire_e2422361732542 : Closed e2422361732542 ∧ code e2422361732542 = 11218454754750 := by decide
theorem cert_e2422361732542 : check e2422361732542 [[],[]] .smaller = true := by decide
def e2422361732574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))))
theorem wire_e2422361732574 : Closed e2422361732574 ∧ code e2422361732574 = 11218454754782 := by decide
theorem cert_e2422361732574 : check e2422361732574 [[],[]] .smaller = true := by decide
def e2422361732590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))))
theorem wire_e2422361732590 : Closed e2422361732590 ∧ code e2422361732590 = 11218454754798 := by decide
theorem cert_e2422361732590 : check e2422361732590 [[],[]] .smaller = true := by decide
def e2422361732598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1))))))))))
theorem wire_e2422361732598 : Closed e2422361732598 ∧ code e2422361732598 = 11218454754806 := by decide
theorem cert_e2422361732598 : check e2422361732598 [[],[]] .smaller = true := by decide
def e2422361732798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4))))))))))
theorem wire_e2422361732798 : Closed e2422361732798 ∧ code e2422361732798 = 11218454755006 := by decide
theorem cert_e2422361732798 : check e2422361732798 [[],[]] .smaller = true := by decide
def e2422361732830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))))
theorem wire_e2422361732830 : Closed e2422361732830 ∧ code e2422361732830 = 11218454755038 := by decide
theorem cert_e2422361732830 : check e2422361732830 [[],[]] .smaller = true := by decide
def e2422361732846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))))
theorem wire_e2422361732846 : Closed e2422361732846 ∧ code e2422361732846 = 11218454755054 := by decide
theorem cert_e2422361732846 : check e2422361732846 [[],[]] .smaller = true := by decide
def e2422361732854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))))
theorem wire_e2422361732854 : Closed e2422361732854 ∧ code e2422361732854 = 11218454755062 := by decide
theorem cert_e2422361732854 : check e2422361732854 [[],[]] .smaller = true := by decide
def e2422361732858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0))))))))))
theorem wire_e2422361732858 : Closed e2422361732858 ∧ code e2422361732858 = 11218454755066 := by decide
theorem cert_e2422361732858 : check e2422361732858 [[],[]] .smaller = true := by decide
def e2422361732958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))))
theorem wire_e2422361732958 : Closed e2422361732958 ∧ code e2422361732958 = 11218454755166 := by decide
theorem cert_e2422361732958 : check e2422361732958 [[],[]] .smaller = true := by decide
def e2422361732974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))))
theorem wire_e2422361732974 : Closed e2422361732974 ∧ code e2422361732974 = 11218454755182 := by decide
theorem cert_e2422361732974 : check e2422361732974 [[],[]] .smaller = true := by decide
def e2422361732982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))))
theorem wire_e2422361732982 : Closed e2422361732982 ∧ code e2422361732982 = 11218454755190 := by decide
theorem cert_e2422361732982 : check e2422361732982 [[],[]] .smaller = true := by decide
def e2422361732986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))))
theorem wire_e2422361732986 : Closed e2422361732986 ∧ code e2422361732986 = 11218454755194 := by decide
theorem cert_e2422361732986 : check e2422361732986 [[],[]] .smaller = true := by decide
def e2422361733038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))))
theorem wire_e2422361733038 : Closed e2422361733038 ∧ code e2422361733038 = 11218454755246 := by decide
theorem cert_e2422361733038 : check e2422361733038 [[],[]] .smaller = true := by decide
def e2422361733046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))))
theorem wire_e2422361733046 : Closed e2422361733046 ∧ code e2422361733046 = 11218454755254 := by decide
theorem cert_e2422361733046 : check e2422361733046 [[],[]] .smaller = true := by decide
def e2422361733050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))))
theorem wire_e2422361733050 : Closed e2422361733050 ∧ code e2422361733050 = 11218454755258 := by decide
theorem cert_e2422361733050 : check e2422361733050 [[],[]] .smaller = true := by decide
def e2422361733078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1))))))))))
theorem wire_e2422361733078 : Closed e2422361733078 ∧ code e2422361733078 = 11218454755286 := by decide
theorem cert_e2422361733078 : check e2422361733078 [[],[]] .smaller = true := by decide
def e2422361733082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0))))))))))
theorem wire_e2422361733082 : Closed e2422361733082 ∧ code e2422361733082 = 11218454755290 := by decide
theorem cert_e2422361733082 : check e2422361733082 [[],[]] .smaller = true := by decide
def e2422361733822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4))))))))))
theorem wire_e2422361733822 : Closed e2422361733822 ∧ code e2422361733822 = 11218454756030 := by decide
theorem cert_e2422361733822 : check e2422361733822 [[],[]] .smaller = true := by decide
def e2422361733854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))))
theorem wire_e2422361733854 : Closed e2422361733854 ∧ code e2422361733854 = 11218454756062 := by decide
theorem cert_e2422361733854 : check e2422361733854 [[],[]] .smaller = true := by decide
def e2422361733870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))))
theorem wire_e2422361733870 : Closed e2422361733870 ∧ code e2422361733870 = 11218454756078 := by decide
theorem cert_e2422361733870 : check e2422361733870 [[],[]] .smaller = true := by decide
def e2422361733878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))))
theorem wire_e2422361733878 : Closed e2422361733878 ∧ code e2422361733878 = 11218454756086 := by decide
theorem cert_e2422361733878 : check e2422361733878 [[],[]] .smaller = true := by decide
def e2422361733882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0))))))))))
theorem wire_e2422361733882 : Closed e2422361733882 ∧ code e2422361733882 = 11218454756090 := by decide
theorem cert_e2422361733882 : check e2422361733882 [[],[]] .smaller = true := by decide
def e2422361733982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))))
theorem wire_e2422361733982 : Closed e2422361733982 ∧ code e2422361733982 = 11218454756190 := by decide
theorem cert_e2422361733982 : check e2422361733982 [[],[]] .smaller = true := by decide
def e2422361734010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))))
theorem wire_e2422361734010 : Closed e2422361734010 ∧ code e2422361734010 = 11218454756218 := by decide
theorem cert_e2422361734010 : check e2422361734010 [[],[]] .smaller = true := by decide
def e2422361734062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))))
theorem wire_e2422361734062 : Closed e2422361734062 ∧ code e2422361734062 = 11218454756270 := by decide
theorem cert_e2422361734062 : check e2422361734062 [[],[]] .smaller = true := by decide
def e2422361734074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))))
theorem wire_e2422361734074 : Closed e2422361734074 ∧ code e2422361734074 = 11218454756282 := by decide
theorem cert_e2422361734074 : check e2422361734074 [[],[]] .smaller = true := by decide
def e2422361734102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))))
theorem wire_e2422361734102 : Closed e2422361734102 ∧ code e2422361734102 = 11218454756310 := by decide
theorem cert_e2422361734102 : check e2422361734102 [[],[]] .smaller = true := by decide
def e2422361734106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))))
theorem wire_e2422361734106 : Closed e2422361734106 ∧ code e2422361734106 = 11218454756314 := by decide
theorem cert_e2422361734106 : check e2422361734106 [[],[]] .smaller = true := by decide
def e2422361734122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0))))))))))
theorem wire_e2422361734122 : Closed e2422361734122 ∧ code e2422361734122 = 11218454756330 := by decide
theorem cert_e2422361734122 : check e2422361734122 [[],[]] .smaller = true := by decide
def e2422361734494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))))
theorem wire_e2422361734494 : Closed e2422361734494 ∧ code e2422361734494 = 11218454756702 := by decide
theorem cert_e2422361734494 : check e2422361734494 [[],[]] .smaller = true := by decide
def e2422361734510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e2422361734510 : Closed e2422361734510 ∧ code e2422361734510 = 11218454756718 := by decide
theorem cert_e2422361734510 : check e2422361734510 [[],[]] .smaller = true := by decide
def e2422361734518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e2422361734518 : Closed e2422361734518 ∧ code e2422361734518 = 11218454756726 := by decide
theorem cert_e2422361734518 : check e2422361734518 [[],[]] .smaller = true := by decide
def e2422361734522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))))
theorem wire_e2422361734522 : Closed e2422361734522 ∧ code e2422361734522 = 11218454756730 := by decide
theorem cert_e2422361734522 : check e2422361734522 [[],[]] .smaller = true := by decide
def e2422361734574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e2422361734574 : Closed e2422361734574 ∧ code e2422361734574 = 11218454756782 := by decide
theorem cert_e2422361734574 : check e2422361734574 [[],[]] .smaller = true := by decide
def e2422361734586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e2422361734586 : Closed e2422361734586 ∧ code e2422361734586 = 11218454756794 := by decide
theorem cert_e2422361734586 : check e2422361734586 [[],[]] .smaller = true := by decide
def e2422361734614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e2422361734614 : Closed e2422361734614 ∧ code e2422361734614 = 11218454756822 := by decide
theorem cert_e2422361734614 : check e2422361734614 [[],[]] .smaller = true := by decide
def e2422361734618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e2422361734618 : Closed e2422361734618 ∧ code e2422361734618 = 11218454756826 := by decide
theorem cert_e2422361734618 : check e2422361734618 [[],[]] .smaller = true := by decide
def e2422361734634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))))
theorem wire_e2422361734634 : Closed e2422361734634 ∧ code e2422361734634 = 11218454756842 := by decide
theorem cert_e2422361734634 : check e2422361734634 [[],[]] .smaller = true := by decide
def e2422361734830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e2422361734830 : Closed e2422361734830 ∧ code e2422361734830 = 11218454757038 := by decide
theorem cert_e2422361734830 : check e2422361734830 [[],[]] .smaller = true := by decide
def e2422361734838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))))
theorem wire_e2422361734838 : Closed e2422361734838 ∧ code e2422361734838 = 11218454757046 := by decide
theorem cert_e2422361734838 : check e2422361734838 [[],[]] .smaller = true := by decide
def e2422361734842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e2422361734842 : Closed e2422361734842 ∧ code e2422361734842 = 11218454757050 := by decide
theorem cert_e2422361734842 : check e2422361734842 [[],[]] .smaller = true := by decide
def e2422361734870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))))
theorem wire_e2422361734870 : Closed e2422361734870 ∧ code e2422361734870 = 11218454757078 := by decide
theorem cert_e2422361734870 : check e2422361734870 [[],[]] .smaller = true := by decide
def e2422361734874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))))
theorem wire_e2422361734874 : Closed e2422361734874 ∧ code e2422361734874 = 11218454757082 := by decide
theorem cert_e2422361734874 : check e2422361734874 [[],[]] .smaller = true := by decide
def e2422361734890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e2422361734890 : Closed e2422361734890 ∧ code e2422361734890 = 11218454757098 := by decide
theorem cert_e2422361734890 : check e2422361734890 [[],[]] .smaller = true := by decide
def e2422361734998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e2422361734998 : Closed e2422361734998 ∧ code e2422361734998 = 11218454757206 := by decide
theorem cert_e2422361734998 : check e2422361734998 [[],[]] .smaller = true := by decide
def e2422361735002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e2422361735002 : Closed e2422361735002 ∧ code e2422361735002 = 11218454757210 := by decide
theorem cert_e2422361735002 : check e2422361735002 [[],[]] .smaller = true := by decide
def e2422361735018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e2422361735018 : Closed e2422361735018 ∧ code e2422361735018 = 11218454757226 := by decide
theorem cert_e2422361735018 : check e2422361735018 [[],[]] .smaller = true := by decide
def e2422361738686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4))))))))))
theorem wire_e2422361738686 : Closed e2422361738686 ∧ code e2422361738686 = 11218454760894 := by decide
theorem cert_e2422361738686 : check e2422361738686 [[],[]] .smaller = true := by decide
def e2422361738718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))))
theorem wire_e2422361738718 : Closed e2422361738718 ∧ code e2422361738718 = 11218454760926 := by decide
theorem cert_e2422361738718 : check e2422361738718 [[],[]] .smaller = true := by decide
def e2422361738734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))))
theorem wire_e2422361738734 : Closed e2422361738734 ∧ code e2422361738734 = 11218454760942 := by decide
theorem cert_e2422361738734 : check e2422361738734 [[],[]] .smaller = true := by decide
def e2422361738742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1))))))))))
theorem wire_e2422361738742 : Closed e2422361738742 ∧ code e2422361738742 = 11218454760950 := by decide
theorem cert_e2422361738742 : check e2422361738742 [[],[]] .smaller = true := by decide
def e2422361738942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4))))))))))
theorem wire_e2422361738942 : Closed e2422361738942 ∧ code e2422361738942 = 11218454761150 := by decide
theorem cert_e2422361738942 : check e2422361738942 [[],[]] .smaller = true := by decide
def e2422361738974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))))
theorem wire_e2422361738974 : Closed e2422361738974 ∧ code e2422361738974 = 11218454761182 := by decide
theorem cert_e2422361738974 : check e2422361738974 [[],[]] .smaller = true := by decide
def e2422361738990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))))
theorem wire_e2422361738990 : Closed e2422361738990 ∧ code e2422361738990 = 11218454761198 := by decide
theorem cert_e2422361738990 : check e2422361738990 [[],[]] .smaller = true := by decide
def e2422361738998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))))
theorem wire_e2422361738998 : Closed e2422361738998 ∧ code e2422361738998 = 11218454761206 := by decide
theorem cert_e2422361738998 : check e2422361738998 [[],[]] .smaller = true := by decide
def e2422361739002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0))))))))))
theorem wire_e2422361739002 : Closed e2422361739002 ∧ code e2422361739002 = 11218454761210 := by decide
theorem cert_e2422361739002 : check e2422361739002 [[],[]] .smaller = true := by decide
def e2422361739102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))))
theorem wire_e2422361739102 : Closed e2422361739102 ∧ code e2422361739102 = 11218454761310 := by decide
theorem cert_e2422361739102 : check e2422361739102 [[],[]] .smaller = true := by decide
def e2422361739118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))))
theorem wire_e2422361739118 : Closed e2422361739118 ∧ code e2422361739118 = 11218454761326 := by decide
theorem cert_e2422361739118 : check e2422361739118 [[],[]] .smaller = true := by decide
def e2422361739126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))))
theorem wire_e2422361739126 : Closed e2422361739126 ∧ code e2422361739126 = 11218454761334 := by decide
theorem cert_e2422361739126 : check e2422361739126 [[],[]] .smaller = true := by decide
def e2422361739130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))))
theorem wire_e2422361739130 : Closed e2422361739130 ∧ code e2422361739130 = 11218454761338 := by decide
theorem cert_e2422361739130 : check e2422361739130 [[],[]] .smaller = true := by decide
def e2422361739182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))))
theorem wire_e2422361739182 : Closed e2422361739182 ∧ code e2422361739182 = 11218454761390 := by decide
theorem cert_e2422361739182 : check e2422361739182 [[],[]] .smaller = true := by decide
def e2422361739190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))))
theorem wire_e2422361739190 : Closed e2422361739190 ∧ code e2422361739190 = 11218454761398 := by decide
theorem cert_e2422361739190 : check e2422361739190 [[],[]] .smaller = true := by decide
def e2422361739194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))))
theorem wire_e2422361739194 : Closed e2422361739194 ∧ code e2422361739194 = 11218454761402 := by decide
theorem cert_e2422361739194 : check e2422361739194 [[],[]] .smaller = true := by decide
def e2422361739222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1))))))))))
theorem wire_e2422361739222 : Closed e2422361739222 ∧ code e2422361739222 = 11218454761430 := by decide
theorem cert_e2422361739222 : check e2422361739222 [[],[]] .smaller = true := by decide
def e2422361739226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0))))))))))
theorem wire_e2422361739226 : Closed e2422361739226 ∧ code e2422361739226 = 11218454761434 := by decide
theorem cert_e2422361739226 : check e2422361739226 [[],[]] .smaller = true := by decide
def e2422361740222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422361740222 : Closed e2422361740222 ∧ code e2422361740222 = 11218454762430 := by decide
theorem cert_e2422361740222 : check e2422361740222 [[],[]] .smaller = true := by decide
def e2422361740254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422361740254 : Closed e2422361740254 ∧ code e2422361740254 = 11218454762462 := by decide
theorem cert_e2422361740254 : check e2422361740254 [[],[]] .smaller = true := by decide
def e2422361740270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422361740270 : Closed e2422361740270 ∧ code e2422361740270 = 11218454762478 := by decide
theorem cert_e2422361740270 : check e2422361740270 [[],[]] .smaller = true := by decide
def e2422361740278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422361740278 : Closed e2422361740278 ∧ code e2422361740278 = 11218454762486 := by decide
theorem cert_e2422361740278 : check e2422361740278 [[],[]] .smaller = true := by decide
def e2422361741758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422361741758 : Closed e2422361741758 ∧ code e2422361741758 = 11218454763966 := by decide
theorem cert_e2422361741758 : check e2422361741758 [[],[]] .smaller = true := by decide
def e2422361741790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422361741790 : Closed e2422361741790 ∧ code e2422361741790 = 11218454763998 := by decide
theorem cert_e2422361741790 : check e2422361741790 [[],[]] .smaller = true := by decide
def e2422361741806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422361741806 : Closed e2422361741806 ∧ code e2422361741806 = 11218454764014 := by decide
theorem cert_e2422361741806 : check e2422361741806 [[],[]] .smaller = true := by decide
def e2422361741814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422361741814 : Closed e2422361741814 ∧ code e2422361741814 = 11218454764022 := by decide
theorem cert_e2422361741814 : check e2422361741814 [[],[]] .smaller = true := by decide
def e2422361741818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422361741818 : Closed e2422361741818 ∧ code e2422361741818 = 11218454764026 := by decide
theorem cert_e2422361741818 : check e2422361741818 [[],[]] .smaller = true := by decide
def e2422361742558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422361742558 : Closed e2422361742558 ∧ code e2422361742558 = 11218454764766 := by decide
theorem cert_e2422361742558 : check e2422361742558 [[],[]] .smaller = true := by decide
def e2422361742574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422361742574 : Closed e2422361742574 ∧ code e2422361742574 = 11218454764782 := by decide
theorem cert_e2422361742574 : check e2422361742574 [[],[]] .smaller = true := by decide
def e2422361742582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422361742582 : Closed e2422361742582 ∧ code e2422361742582 = 11218454764790 := by decide
theorem cert_e2422361742582 : check e2422361742582 [[],[]] .smaller = true := by decide
def e2422361742586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422361742586 : Closed e2422361742586 ∧ code e2422361742586 = 11218454764794 := by decide
theorem cert_e2422361742586 : check e2422361742586 [[],[]] .smaller = true := by decide
def e2422361742958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422361742958 : Closed e2422361742958 ∧ code e2422361742958 = 11218454765166 := by decide
theorem cert_e2422361742958 : check e2422361742958 [[],[]] .smaller = true := by decide
def e2422361742966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422361742966 : Closed e2422361742966 ∧ code e2422361742966 = 11218454765174 := by decide
theorem cert_e2422361742966 : check e2422361742966 [[],[]] .smaller = true := by decide
def e2422361742970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422361742970 : Closed e2422361742970 ∧ code e2422361742970 = 11218454765178 := by decide
theorem cert_e2422361742970 : check e2422361742970 [[],[]] .smaller = true := by decide
def e2422361743158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422361743158 : Closed e2422361743158 ∧ code e2422361743158 = 11218454765366 := by decide
theorem cert_e2422361743158 : check e2422361743158 [[],[]] .smaller = true := by decide
def e2422361743162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422361743162 : Closed e2422361743162 ∧ code e2422361743162 = 11218454765370 := by decide
theorem cert_e2422361743162 : check e2422361743162 [[],[]] .smaller = true := by decide
def e2422361745086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4))))))))))
theorem wire_e2422361745086 : Closed e2422361745086 ∧ code e2422361745086 = 11218454767294 := by decide
theorem cert_e2422361745086 : check e2422361745086 [[],[]] .smaller = true := by decide
def e2422361745118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))))
theorem wire_e2422361745118 : Closed e2422361745118 ∧ code e2422361745118 = 11218454767326 := by decide
theorem cert_e2422361745118 : check e2422361745118 [[],[]] .smaller = true := by decide
def e2422361745134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))))
theorem wire_e2422361745134 : Closed e2422361745134 ∧ code e2422361745134 = 11218454767342 := by decide
theorem cert_e2422361745134 : check e2422361745134 [[],[]] .smaller = true := by decide
def e2422361745142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))))
theorem wire_e2422361745142 : Closed e2422361745142 ∧ code e2422361745142 = 11218454767350 := by decide
theorem cert_e2422361745142 : check e2422361745142 [[],[]] .smaller = true := by decide
def e2422361745146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0))))))))))
theorem wire_e2422361745146 : Closed e2422361745146 ∧ code e2422361745146 = 11218454767354 := by decide
theorem cert_e2422361745146 : check e2422361745146 [[],[]] .smaller = true := by decide
def e2422361745246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))))
theorem wire_e2422361745246 : Closed e2422361745246 ∧ code e2422361745246 = 11218454767454 := by decide
theorem cert_e2422361745246 : check e2422361745246 [[],[]] .smaller = true := by decide
def e2422361745274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))))
theorem wire_e2422361745274 : Closed e2422361745274 ∧ code e2422361745274 = 11218454767482 := by decide
theorem cert_e2422361745274 : check e2422361745274 [[],[]] .smaller = true := by decide
def e2422361745326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))))
theorem wire_e2422361745326 : Closed e2422361745326 ∧ code e2422361745326 = 11218454767534 := by decide
theorem cert_e2422361745326 : check e2422361745326 [[],[]] .smaller = true := by decide
def e2422361745338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))))
theorem wire_e2422361745338 : Closed e2422361745338 ∧ code e2422361745338 = 11218454767546 := by decide
theorem cert_e2422361745338 : check e2422361745338 [[],[]] .smaller = true := by decide
def e2422361745366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))))
theorem wire_e2422361745366 : Closed e2422361745366 ∧ code e2422361745366 = 11218454767574 := by decide
theorem cert_e2422361745366 : check e2422361745366 [[],[]] .smaller = true := by decide
def e2422361745370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))))
theorem wire_e2422361745370 : Closed e2422361745370 ∧ code e2422361745370 = 11218454767578 := by decide
theorem cert_e2422361745370 : check e2422361745370 [[],[]] .smaller = true := by decide
def e2422361745386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 4) (.var 0))) (.var 0))))))))))
theorem wire_e2422361745386 : Closed e2422361745386 ∧ code e2422361745386 = 11218454767594 := by decide
theorem cert_e2422361745386 : check e2422361745386 [[],[]] .smaller = true := by decide
def e2422361745854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 4)))))))))))
theorem wire_e2422361745854 : Closed e2422361745854 ∧ code e2422361745854 = 11218454768062 := by decide
theorem cert_e2422361745854 : check e2422361745854 [[],[]] .smaller = true := by decide
def e2422361745886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422361745886 : Closed e2422361745886 ∧ code e2422361745886 = 11218454768094 := by decide
theorem cert_e2422361745886 : check e2422361745886 [[],[]] .smaller = true := by decide
def e2422361745902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422361745902 : Closed e2422361745902 ∧ code e2422361745902 = 11218454768110 := by decide
theorem cert_e2422361745902 : check e2422361745902 [[],[]] .smaller = true := by decide
def e2422361745910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422361745910 : Closed e2422361745910 ∧ code e2422361745910 = 11218454768118 := by decide
theorem cert_e2422361745910 : check e2422361745910 [[],[]] .smaller = true := by decide
def e2422361745914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 4) (.var 0)))))))))))
theorem wire_e2422361745914 : Closed e2422361745914 ∧ code e2422361745914 = 11218454768122 := by decide
theorem cert_e2422361745914 : check e2422361745914 [[],[]] .smaller = true := by decide
def e2422361746654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422361746654 : Closed e2422361746654 ∧ code e2422361746654 = 11218454768862 := by decide
theorem cert_e2422361746654 : check e2422361746654 [[],[]] .smaller = true := by decide
def e2422361746682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422361746682 : Closed e2422361746682 ∧ code e2422361746682 = 11218454768890 := by decide
theorem cert_e2422361746682 : check e2422361746682 [[],[]] .smaller = true := by decide
def e2422361747054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422361747054 : Closed e2422361747054 ∧ code e2422361747054 = 11218454769262 := by decide
theorem cert_e2422361747054 : check e2422361747054 [[],[]] .smaller = true := by decide
def e2422361747066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422361747066 : Closed e2422361747066 ∧ code e2422361747066 = 11218454769274 := by decide
theorem cert_e2422361747066 : check e2422361747066 [[],[]] .smaller = true := by decide
def e2422361747254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422361747254 : Closed e2422361747254 ∧ code e2422361747254 = 11218454769462 := by decide
theorem cert_e2422361747254 : check e2422361747254 [[],[]] .smaller = true := by decide
def e2422361747258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422361747258 : Closed e2422361747258 ∧ code e2422361747258 = 11218454769466 := by decide
theorem cert_e2422361747258 : check e2422361747258 [[],[]] .smaller = true := by decide
def e2422361747354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422361747354 : Closed e2422361747354 ∧ code e2422361747354 = 11218454769562 := by decide
theorem cert_e2422361747354 : check e2422361747354 [[],[]] .smaller = true := by decide
def e2422361748318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))))
theorem wire_e2422361748318 : Closed e2422361748318 ∧ code e2422361748318 = 11218454770526 := by decide
theorem cert_e2422361748318 : check e2422361748318 [[],[]] .smaller = true := by decide
def e2422361748334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e2422361748334 : Closed e2422361748334 ∧ code e2422361748334 = 11218454770542 := by decide
theorem cert_e2422361748334 : check e2422361748334 [[],[]] .smaller = true := by decide
def e2422361748342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e2422361748342 : Closed e2422361748342 ∧ code e2422361748342 = 11218454770550 := by decide
theorem cert_e2422361748342 : check e2422361748342 [[],[]] .smaller = true := by decide
def e2422361748346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))))
theorem wire_e2422361748346 : Closed e2422361748346 ∧ code e2422361748346 = 11218454770554 := by decide
theorem cert_e2422361748346 : check e2422361748346 [[],[]] .smaller = true := by decide
def e2422361748398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e2422361748398 : Closed e2422361748398 ∧ code e2422361748398 = 11218454770606 := by decide
theorem cert_e2422361748398 : check e2422361748398 [[],[]] .smaller = true := by decide
def e2422361748410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e2422361748410 : Closed e2422361748410 ∧ code e2422361748410 = 11218454770618 := by decide
theorem cert_e2422361748410 : check e2422361748410 [[],[]] .smaller = true := by decide
def e2422361748438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e2422361748438 : Closed e2422361748438 ∧ code e2422361748438 = 11218454770646 := by decide
theorem cert_e2422361748438 : check e2422361748438 [[],[]] .smaller = true := by decide
def e2422361748442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e2422361748442 : Closed e2422361748442 ∧ code e2422361748442 = 11218454770650 := by decide
theorem cert_e2422361748442 : check e2422361748442 [[],[]] .smaller = true := by decide
def e2422361748458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))))
theorem wire_e2422361748458 : Closed e2422361748458 ∧ code e2422361748458 = 11218454770666 := by decide
theorem cert_e2422361748458 : check e2422361748458 [[],[]] .smaller = true := by decide
def e2422361748702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422361748702 : Closed e2422361748702 ∧ code e2422361748702 = 11218454770910 := by decide
theorem cert_e2422361748702 : check e2422361748702 [[],[]] .smaller = true := by decide
def e2422361748718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422361748718 : Closed e2422361748718 ∧ code e2422361748718 = 11218454770926 := by decide
theorem cert_e2422361748718 : check e2422361748718 [[],[]] .smaller = true := by decide
def e2422361748726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422361748726 : Closed e2422361748726 ∧ code e2422361748726 = 11218454770934 := by decide
theorem cert_e2422361748726 : check e2422361748726 [[],[]] .smaller = true := by decide
def e2422361748730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422361748730 : Closed e2422361748730 ∧ code e2422361748730 = 11218454770938 := by decide
theorem cert_e2422361748730 : check e2422361748730 [[],[]] .smaller = true := by decide
def e2422361749102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422361749102 : Closed e2422361749102 ∧ code e2422361749102 = 11218454771310 := by decide
theorem cert_e2422361749102 : check e2422361749102 [[],[]] .smaller = true := by decide
def e2422361749114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422361749114 : Closed e2422361749114 ∧ code e2422361749114 = 11218454771322 := by decide
theorem cert_e2422361749114 : check e2422361749114 [[],[]] .smaller = true := by decide
def e2422361749302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422361749302 : Closed e2422361749302 ∧ code e2422361749302 = 11218454771510 := by decide
theorem cert_e2422361749302 : check e2422361749302 [[],[]] .smaller = true := by decide
def e2422361749306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422361749306 : Closed e2422361749306 ∧ code e2422361749306 = 11218454771514 := by decide
theorem cert_e2422361749306 : check e2422361749306 [[],[]] .smaller = true := by decide
def e2422361749402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422361749402 : Closed e2422361749402 ∧ code e2422361749402 = 11218454771610 := by decide
theorem cert_e2422361749402 : check e2422361749402 [[],[]] .smaller = true := by decide
def e2422361749934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e2422361749934 : Closed e2422361749934 ∧ code e2422361749934 = 11218454772142 := by decide
theorem cert_e2422361749934 : check e2422361749934 [[],[]] .smaller = true := by decide
def e2422361749942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))))
theorem wire_e2422361749942 : Closed e2422361749942 ∧ code e2422361749942 = 11218454772150 := by decide
theorem cert_e2422361749942 : check e2422361749942 [[],[]] .smaller = true := by decide
def e2422361749946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e2422361749946 : Closed e2422361749946 ∧ code e2422361749946 = 11218454772154 := by decide
theorem cert_e2422361749946 : check e2422361749946 [[],[]] .smaller = true := by decide
def e2422361749974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))))
theorem wire_e2422361749974 : Closed e2422361749974 ∧ code e2422361749974 = 11218454772182 := by decide
theorem cert_e2422361749974 : check e2422361749974 [[],[]] .smaller = true := by decide
def e2422361749978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))))
theorem wire_e2422361749978 : Closed e2422361749978 ∧ code e2422361749978 = 11218454772186 := by decide
theorem cert_e2422361749978 : check e2422361749978 [[],[]] .smaller = true := by decide
def e2422361749994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e2422361749994 : Closed e2422361749994 ∧ code e2422361749994 = 11218454772202 := by decide
theorem cert_e2422361749994 : check e2422361749994 [[],[]] .smaller = true := by decide
def e2422361750126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422361750126 : Closed e2422361750126 ∧ code e2422361750126 = 11218454772334 := by decide
theorem cert_e2422361750126 : check e2422361750126 [[],[]] .smaller = true := by decide
def e2422361750134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422361750134 : Closed e2422361750134 ∧ code e2422361750134 = 11218454772342 := by decide
theorem cert_e2422361750134 : check e2422361750134 [[],[]] .smaller = true := by decide
def e2422361750138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422361750138 : Closed e2422361750138 ∧ code e2422361750138 = 11218454772346 := by decide
theorem cert_e2422361750138 : check e2422361750138 [[],[]] .smaller = true := by decide
def e2422361750326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422361750326 : Closed e2422361750326 ∧ code e2422361750326 = 11218454772534 := by decide
theorem cert_e2422361750326 : check e2422361750326 [[],[]] .smaller = true := by decide
def e2422361750330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422361750330 : Closed e2422361750330 ∧ code e2422361750330 = 11218454772538 := by decide
theorem cert_e2422361750330 : check e2422361750330 [[],[]] .smaller = true := by decide
def e2422361750426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422361750426 : Closed e2422361750426 ∧ code e2422361750426 = 11218454772634 := by decide
theorem cert_e2422361750426 : check e2422361750426 [[],[]] .smaller = true := by decide
def e2422361750742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e2422361750742 : Closed e2422361750742 ∧ code e2422361750742 = 11218454772950 := by decide
theorem cert_e2422361750742 : check e2422361750742 [[],[]] .smaller = true := by decide
def e2422361750746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e2422361750746 : Closed e2422361750746 ∧ code e2422361750746 = 11218454772954 := by decide
theorem cert_e2422361750746 : check e2422361750746 [[],[]] .smaller = true := by decide
def e2422361750762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e2422361750762 : Closed e2422361750762 ∧ code e2422361750762 = 11218454772970 := by decide
theorem cert_e2422361750762 : check e2422361750762 [[],[]] .smaller = true := by decide
def e2422361750838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422361750838 : Closed e2422361750838 ∧ code e2422361750838 = 11218454773046 := by decide
theorem cert_e2422361750838 : check e2422361750838 [[],[]] .smaller = true := by decide
def e2422361750842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422361750842 : Closed e2422361750842 ∧ code e2422361750842 = 11218454773050 := by decide
theorem cert_e2422361750842 : check e2422361750842 [[],[]] .smaller = true := by decide
def e2422361750938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422361750938 : Closed e2422361750938 ∧ code e2422361750938 = 11218454773146 := by decide
theorem cert_e2422361750938 : check e2422361750938 [[],[]] .smaller = true := by decide
def e2422361754478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))))
theorem wire_e2422361754478 : Closed e2422361754478 ∧ code e2422361754478 = 11218454776686 := by decide
theorem cert_e2422361754478 : check e2422361754478 [[],[]] .smaller = true := by decide
def e2422361754486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))))
theorem wire_e2422361754486 : Closed e2422361754486 ∧ code e2422361754486 = 11218454776694 := by decide
theorem cert_e2422361754486 : check e2422361754486 [[],[]] .smaller = true := by decide
def e2422361754542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))))
theorem wire_e2422361754542 : Closed e2422361754542 ∧ code e2422361754542 = 11218454776750 := by decide
theorem cert_e2422361754542 : check e2422361754542 [[],[]] .smaller = true := by decide
def e2422361754554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))))
theorem wire_e2422361754554 : Closed e2422361754554 ∧ code e2422361754554 = 11218454776762 := by decide
theorem cert_e2422361754554 : check e2422361754554 [[],[]] .smaller = true := by decide
def e2422361754582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))))
theorem wire_e2422361754582 : Closed e2422361754582 ∧ code e2422361754582 = 11218454776790 := by decide
theorem cert_e2422361754582 : check e2422361754582 [[],[]] .smaller = true := by decide
def e2422361754586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))))
theorem wire_e2422361754586 : Closed e2422361754586 ∧ code e2422361754586 = 11218454776794 := by decide
theorem cert_e2422361754586 : check e2422361754586 [[],[]] .smaller = true := by decide
def e2422361754862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))))
theorem wire_e2422361754862 : Closed e2422361754862 ∧ code e2422361754862 = 11218454777070 := by decide
theorem cert_e2422361754862 : check e2422361754862 [[],[]] .smaller = true := by decide
def e2422361754870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))))
theorem wire_e2422361754870 : Closed e2422361754870 ∧ code e2422361754870 = 11218454777078 := by decide
theorem cert_e2422361754870 : check e2422361754870 [[],[]] .smaller = true := by decide
def e2422361755246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))))
theorem wire_e2422361755246 : Closed e2422361755246 ∧ code e2422361755246 = 11218454777454 := by decide
theorem cert_e2422361755246 : check e2422361755246 [[],[]] .smaller = true := by decide
def e2422361755258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))))
theorem wire_e2422361755258 : Closed e2422361755258 ∧ code e2422361755258 = 11218454777466 := by decide
theorem cert_e2422361755258 : check e2422361755258 [[],[]] .smaller = true := by decide
def e2422361755446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))))
theorem wire_e2422361755446 : Closed e2422361755446 ∧ code e2422361755446 = 11218454777654 := by decide
theorem cert_e2422361755446 : check e2422361755446 [[],[]] .smaller = true := by decide
def e2422361755450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))))
theorem wire_e2422361755450 : Closed e2422361755450 ∧ code e2422361755450 = 11218454777658 := by decide
theorem cert_e2422361755450 : check e2422361755450 [[],[]] .smaller = true := by decide
end Blc.Floor43
