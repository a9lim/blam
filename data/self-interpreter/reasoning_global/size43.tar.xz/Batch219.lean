import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392566068122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392566068122 : Closed e2392566068122 ∧ code e2392566068122 = 11188659090330 := by decide
theorem cert_e2392566068122 : check e2392566068122 [[],[.left]] .chain = true := by decide
def e2392566159022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2392566159022 : Closed e2392566159022 ∧ code e2392566159022 = 11188659181230 := by decide
theorem cert_e2392566159022 : check e2392566159022 [[],[.left]] .chain = true := by decide
def e2392566159034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2392566159034 : Closed e2392566159034 ∧ code e2392566159034 = 11188659181242 := by decide
theorem cert_e2392566159034 : check e2392566159034 [[],[.left]] .chain = true := by decide
def e2392566159082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2392566159082 : Closed e2392566159082 ∧ code e2392566159082 = 11188659181290 := by decide
theorem cert_e2392566159082 : check e2392566159082 [[],[.left]] .chain = true := by decide
def e2392566159274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2392566159274 : Closed e2392566159274 ∧ code e2392566159274 = 11188659181482 := by decide
theorem cert_e2392566159274 : check e2392566159274 [[],[.left]] .chain = true := by decide
def e2392566159598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2392566159598 : Closed e2392566159598 ∧ code e2392566159598 = 11188659181806 := by decide
theorem cert_e2392566159598 : check e2392566159598 [[],[.left]] .chain = true := by decide
def e2392566159606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2392566159606 : Closed e2392566159606 ∧ code e2392566159606 = 11188659181814 := by decide
theorem cert_e2392566159606 : check e2392566159606 [[],[.left]] .chain = true := by decide
def e2392566159790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2392566159790 : Closed e2392566159790 ∧ code e2392566159790 = 11188659181998 := by decide
theorem cert_e2392566159790 : check e2392566159790 [[],[.left]] .chain = true := by decide
def e2392566159802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2392566159802 : Closed e2392566159802 ∧ code e2392566159802 = 11188659182010 := by decide
theorem cert_e2392566159802 : check e2392566159802 [[],[.left]] .chain = true := by decide
def e2392566159850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2392566159850 : Closed e2392566159850 ∧ code e2392566159850 = 11188659182058 := by decide
theorem cert_e2392566159850 : check e2392566159850 [[],[.left]] .chain = true := by decide
def e2392566159982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392566159982 : Closed e2392566159982 ∧ code e2392566159982 = 11188659182190 := by decide
theorem cert_e2392566159982 : check e2392566159982 [[],[.left]] .chain = true := by decide
def e2392566159994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392566159994 : Closed e2392566159994 ∧ code e2392566159994 = 11188659182202 := by decide
theorem cert_e2392566159994 : check e2392566159994 [[],[.left]] .chain = true := by decide
def e2392566160158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2392566160158 : Closed e2392566160158 ∧ code e2392566160158 = 11188659182366 := by decide
theorem cert_e2392566160158 : check e2392566160158 [[],[.left]] .chain = true := by decide
def e2392566160270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2392566160270 : Closed e2392566160270 ∧ code e2392566160270 = 11188659182478 := by decide
theorem cert_e2392566160270 : check e2392566160270 [[],[.left]] .chain = true := by decide
def e2392566160282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392566160282 : Closed e2392566160282 ∧ code e2392566160282 = 11188659182490 := by decide
theorem cert_e2392566160282 : check e2392566160282 [[],[.left]] .chain = true := by decide
def e2392566160494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2392566160494 : Closed e2392566160494 ∧ code e2392566160494 = 11188659182702 := by decide
theorem cert_e2392566160494 : check e2392566160494 [[],[.left]] .chain = true := by decide
def e2392566160506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2392566160506 : Closed e2392566160506 ∧ code e2392566160506 = 11188659182714 := by decide
theorem cert_e2392566160506 : check e2392566160506 [[],[.left]] .chain = true := by decide
def e2392566160670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2392566160670 : Closed e2392566160670 ∧ code e2392566160670 = 11188659182878 := by decide
theorem cert_e2392566160670 : check e2392566160670 [[],[.left]] .chain = true := by decide
def e2392566160838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2392566160838 : Closed e2392566160838 ∧ code e2392566160838 = 11188659183046 := by decide
theorem cert_e2392566160838 : check e2392566160838 [[],[.left]] .chain = true := by decide
def e2392566160950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2392566160950 : Closed e2392566160950 ∧ code e2392566160950 = 11188659183158 := by decide
theorem cert_e2392566160950 : check e2392566160950 [[],[.left]] .chain = true := by decide
def e2392566160954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2392566160954 : Closed e2392566160954 ∧ code e2392566160954 = 11188659183162 := by decide
theorem cert_e2392566160954 : check e2392566160954 [[],[.left]] .chain = true := by decide
def e2392566161002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2392566161002 : Closed e2392566161002 ∧ code e2392566161002 = 11188659183210 := by decide
theorem cert_e2392566161002 : check e2392566161002 [[],[.left]] .chain = true := by decide
def e2392566161038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2392566161038 : Closed e2392566161038 ∧ code e2392566161038 = 11188659183246 := by decide
theorem cert_e2392566161038 : check e2392566161038 [[],[.left]] .chain = true := by decide
def e2392566161050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392566161050 : Closed e2392566161050 ∧ code e2392566161050 = 11188659183258 := by decide
theorem cert_e2392566161050 : check e2392566161050 [[],[.left]] .chain = true := by decide
def e2392566161094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2392566161094 : Closed e2392566161094 ∧ code e2392566161094 = 11188659183302 := by decide
theorem cert_e2392566161094 : check e2392566161094 [[],[.left]] .chain = true := by decide
def e2392566161886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2392566161886 : Closed e2392566161886 ∧ code e2392566161886 = 11188659184094 := by decide
theorem cert_e2392566161886 : check e2392566161886 [[],[.left]] .chain = true := by decide
def e2392566161910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2392566161910 : Closed e2392566161910 ∧ code e2392566161910 = 11188659184118 := by decide
theorem cert_e2392566161910 : check e2392566161910 [[],[.left]] .chain = true := by decide
def e2392566162862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2392566162862 : Closed e2392566162862 ∧ code e2392566162862 = 11188659185070 := by decide
theorem cert_e2392566162862 : check e2392566162862 [[],[.left]] .chain = true := by decide
def e2392566162874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2392566162874 : Closed e2392566162874 ∧ code e2392566162874 = 11188659185082 := by decide
theorem cert_e2392566162874 : check e2392566162874 [[],[.left]] .chain = true := by decide
def e2392566162922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2392566162922 : Closed e2392566162922 ∧ code e2392566162922 = 11188659185130 := by decide
theorem cert_e2392566162922 : check e2392566162922 [[],[.left]] .chain = true := by decide
def e2392566163054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392566163054 : Closed e2392566163054 ∧ code e2392566163054 = 11188659185262 := by decide
theorem cert_e2392566163054 : check e2392566163054 [[],[.left]] .chain = true := by decide
def e2392566163066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392566163066 : Closed e2392566163066 ∧ code e2392566163066 = 11188659185274 := by decide
theorem cert_e2392566163066 : check e2392566163066 [[],[.left]] .chain = true := by decide
def e2392566163230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2392566163230 : Closed e2392566163230 ∧ code e2392566163230 = 11188659185438 := by decide
theorem cert_e2392566163230 : check e2392566163230 [[],[.left]] .chain = true := by decide
def e2392566163342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2392566163342 : Closed e2392566163342 ∧ code e2392566163342 = 11188659185550 := by decide
theorem cert_e2392566163342 : check e2392566163342 [[],[.left]] .chain = true := by decide
def e2392566163354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392566163354 : Closed e2392566163354 ∧ code e2392566163354 = 11188659185562 := by decide
theorem cert_e2392566163354 : check e2392566163354 [[],[.left]] .chain = true := by decide
def e2392566166302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2392566166302 : Closed e2392566166302 ∧ code e2392566166302 = 11188659188510 := by decide
theorem cert_e2392566166302 : check e2392566166302 [[],[.left]] .chain = true := by decide
def e2392566166470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2392566166470 : Closed e2392566166470 ∧ code e2392566166470 = 11188659188678 := by decide
theorem cert_e2392566166470 : check e2392566166470 [[],[.left]] .chain = true := by decide
def e2392566167670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2392566167670 : Closed e2392566167670 ∧ code e2392566167670 = 11188659189878 := by decide
theorem cert_e2392566167670 : check e2392566167670 [[],[.left]] .chain = true := by decide
def e2392566167914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2392566167914 : Closed e2392566167914 ∧ code e2392566167914 = 11188659190122 := by decide
theorem cert_e2392566167914 : check e2392566167914 [[],[.left]] .chain = true := by decide
def e2392566167950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2392566167950 : Closed e2392566167950 ∧ code e2392566167950 = 11188659190158 := by decide
theorem cert_e2392566167950 : check e2392566167950 [[],[.left]] .chain = true := by decide
def e2392566167962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392566167962 : Closed e2392566167962 ∧ code e2392566167962 = 11188659190170 := by decide
theorem cert_e2392566167962 : check e2392566167962 [[],[.left]] .chain = true := by decide
def e2392566168006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2392566168006 : Closed e2392566168006 ∧ code e2392566168006 = 11188659190214 := by decide
theorem cert_e2392566168006 : check e2392566168006 [[],[.left]] .chain = true := by decide
def e2392566213462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2392566213462 : Closed e2392566213462 ∧ code e2392566213462 = 11188659235670 := by decide
theorem cert_e2392566213462 : check e2392566213462 [[],[.left]] .chain = true := by decide
def e2392566213466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2392566213466 : Closed e2392566213466 ∧ code e2392566213466 = 11188659235674 := by decide
theorem cert_e2392566213466 : check e2392566213466 [[],[.left]] .chain = true := by decide
def e2392566213482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2392566213482 : Closed e2392566213482 ∧ code e2392566213482 = 11188659235690 := by decide
theorem cert_e2392566213482 : check e2392566213482 [[],[.left]] .chain = true := by decide
def e2392566213546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2392566213546 : Closed e2392566213546 ∧ code e2392566213546 = 11188659235754 := by decide
theorem cert_e2392566213546 : check e2392566213546 [[],[.left]] .chain = true := by decide
def e2392566213750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2392566213750 : Closed e2392566213750 ∧ code e2392566213750 = 11188659235958 := by decide
theorem cert_e2392566213750 : check e2392566213750 [[],[.left]] .chain = true := by decide
def e2392566213846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2392566213846 : Closed e2392566213846 ∧ code e2392566213846 = 11188659236054 := by decide
theorem cert_e2392566213846 : check e2392566213846 [[],[.left]] .chain = true := by decide
def e2392566213850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2392566213850 : Closed e2392566213850 ∧ code e2392566213850 = 11188659236058 := by decide
theorem cert_e2392566213850 : check e2392566213850 [[],[.left]] .chain = true := by decide
def e2392566213866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2392566213866 : Closed e2392566213866 ∧ code e2392566213866 = 11188659236074 := by decide
theorem cert_e2392566213866 : check e2392566213866 [[],[.left]] .chain = true := by decide
def e2392566213942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392566213942 : Closed e2392566213942 ∧ code e2392566213942 = 11188659236150 := by decide
theorem cert_e2392566213942 : check e2392566213942 [[],[.left]] .chain = true := by decide
def e2392566213946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392566213946 : Closed e2392566213946 ∧ code e2392566213946 = 11188659236154 := by decide
theorem cert_e2392566213946 : check e2392566213946 [[],[.left]] .chain = true := by decide
def e2392566214030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2392566214030 : Closed e2392566214030 ∧ code e2392566214030 = 11188659236238 := by decide
theorem cert_e2392566214030 : check e2392566214030 [[],[.left]] .chain = true := by decide
def e2392566214042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392566214042 : Closed e2392566214042 ∧ code e2392566214042 = 11188659236250 := by decide
theorem cert_e2392566214042 : check e2392566214042 [[],[.left]] .chain = true := by decide
def e2392566214198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2392566214198 : Closed e2392566214198 ∧ code e2392566214198 = 11188659236406 := by decide
theorem cert_e2392566214198 : check e2392566214198 [[],[.left]] .chain = true := by decide
def e2392566214202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2392566214202 : Closed e2392566214202 ∧ code e2392566214202 = 11188659236410 := by decide
theorem cert_e2392566214202 : check e2392566214202 [[],[.left]] .chain = true := by decide
def e2392566214250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2392566214250 : Closed e2392566214250 ∧ code e2392566214250 = 11188659236458 := by decide
theorem cert_e2392566214250 : check e2392566214250 [[],[.left]] .chain = true := by decide
def e2392566214286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2392566214286 : Closed e2392566214286 ∧ code e2392566214286 = 11188659236494 := by decide
theorem cert_e2392566214286 : check e2392566214286 [[],[.left]] .chain = true := by decide
def e2392566214298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392566214298 : Closed e2392566214298 ∧ code e2392566214298 = 11188659236506 := by decide
theorem cert_e2392566214298 : check e2392566214298 [[],[.left]] .chain = true := by decide
def e2392566214342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2392566214342 : Closed e2392566214342 ∧ code e2392566214342 = 11188659236550 := by decide
theorem cert_e2392566214342 : check e2392566214342 [[],[.left]] .chain = true := by decide
def e2392566214894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2392566214894 : Closed e2392566214894 ∧ code e2392566214894 = 11188659237102 := by decide
theorem cert_e2392566214894 : check e2392566214894 [[],[.left]] .chain = true := by decide
def e2392566214902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2392566214902 : Closed e2392566214902 ∧ code e2392566214902 = 11188659237110 := by decide
theorem cert_e2392566214902 : check e2392566214902 [[],[.left]] .chain = true := by decide
def e2392566215382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2392566215382 : Closed e2392566215382 ∧ code e2392566215382 = 11188659237590 := by decide
theorem cert_e2392566215382 : check e2392566215382 [[],[.left]] .chain = true := by decide
def e2392566215386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2392566215386 : Closed e2392566215386 ∧ code e2392566215386 = 11188659237594 := by decide
theorem cert_e2392566215386 : check e2392566215386 [[],[.left]] .chain = true := by decide
def e2392566215402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2392566215402 : Closed e2392566215402 ∧ code e2392566215402 = 11188659237610 := by decide
theorem cert_e2392566215402 : check e2392566215402 [[],[.left]] .chain = true := by decide
def e2392566215478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392566215478 : Closed e2392566215478 ∧ code e2392566215478 = 11188659237686 := by decide
theorem cert_e2392566215478 : check e2392566215478 [[],[.left]] .chain = true := by decide
def e2392566215482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392566215482 : Closed e2392566215482 ∧ code e2392566215482 = 11188659237690 := by decide
theorem cert_e2392566215482 : check e2392566215482 [[],[.left]] .chain = true := by decide
def e2392566215566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2392566215566 : Closed e2392566215566 ∧ code e2392566215566 = 11188659237774 := by decide
theorem cert_e2392566215566 : check e2392566215566 [[],[.left]] .chain = true := by decide
def e2392566215578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392566215578 : Closed e2392566215578 ∧ code e2392566215578 = 11188659237786 := by decide
theorem cert_e2392566215578 : check e2392566215578 [[],[.left]] .chain = true := by decide
def e2392566216822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2392566216822 : Closed e2392566216822 ∧ code e2392566216822 = 11188659239030 := by decide
theorem cert_e2392566216822 : check e2392566216822 [[],[.left]] .chain = true := by decide
def e2392566217066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2392566217066 : Closed e2392566217066 ∧ code e2392566217066 = 11188659239274 := by decide
theorem cert_e2392566217066 : check e2392566217066 [[],[.left]] .chain = true := by decide
def e2392566217102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2392566217102 : Closed e2392566217102 ∧ code e2392566217102 = 11188659239310 := by decide
theorem cert_e2392566217102 : check e2392566217102 [[],[.left]] .chain = true := by decide
def e2392566217114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392566217114 : Closed e2392566217114 ∧ code e2392566217114 = 11188659239322 := by decide
theorem cert_e2392566217114 : check e2392566217114 [[],[.left]] .chain = true := by decide
def e2392566217158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2392566217158 : Closed e2392566217158 ∧ code e2392566217158 = 11188659239366 := by decide
theorem cert_e2392566217158 : check e2392566217158 [[],[.left]] .chain = true := by decide
def e2392568114618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))
theorem wire_e2392568114618 : Closed e2392568114618 ∧ code e2392568114618 = 11188661136826 := by decide
theorem cert_e2392568114618 : check e2392568114618 [[],[.left]] .chain = true := by decide
def e2392568114650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))
theorem wire_e2392568114650 : Closed e2392568114650 ∧ code e2392568114650 = 11188661136858 := by decide
theorem cert_e2392568114650 : check e2392568114650 [[],[.left]] .chain = true := by decide
def e2392568114874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))
theorem wire_e2392568114874 : Closed e2392568114874 ∧ code e2392568114874 = 11188661137082 := by decide
theorem cert_e2392568114874 : check e2392568114874 [[],[.left]] .chain = true := by decide
def e2392568114922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))
theorem wire_e2392568114922 : Closed e2392568114922 ∧ code e2392568114922 = 11188661137130 := by decide
theorem cert_e2392568114922 : check e2392568114922 [[],[.left]] .chain = true := by decide
def e2392568115034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))
theorem wire_e2392568115034 : Closed e2392568115034 ∧ code e2392568115034 = 11188661137242 := by decide
theorem cert_e2392568115034 : check e2392568115034 [[],[.left]] .chain = true := by decide
def e2392568115050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))
theorem wire_e2392568115050 : Closed e2392568115050 ∧ code e2392568115050 = 11188661137258 := by decide
theorem cert_e2392568115050 : check e2392568115050 [[],[.left]] .chain = true := by decide
def e2392568116154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))
theorem wire_e2392568116154 : Closed e2392568116154 ∧ code e2392568116154 = 11188661138362 := by decide
theorem cert_e2392568116154 : check e2392568116154 [[],[.left]] .chain = true := by decide
def e2392568116186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))
theorem wire_e2392568116186 : Closed e2392568116186 ∧ code e2392568116186 = 11188661138394 := by decide
theorem cert_e2392568116186 : check e2392568116186 [[],[.left]] .chain = true := by decide
def e2392568117690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))
theorem wire_e2392568117690 : Closed e2392568117690 ∧ code e2392568117690 = 11188661139898 := by decide
theorem cert_e2392568117690 : check e2392568117690 [[],[.left]] .chain = true := by decide
def e2392568117738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))
theorem wire_e2392568117738 : Closed e2392568117738 ∧ code e2392568117738 = 11188661139946 := by decide
theorem cert_e2392568117738 : check e2392568117738 [[],[.left]] .chain = true := by decide
def e2392568118490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))
theorem wire_e2392568118490 : Closed e2392568118490 ∧ code e2392568118490 = 11188661140698 := by decide
theorem cert_e2392568118490 : check e2392568118490 [[],[.left]] .chain = true := by decide
def e2392568118506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))
theorem wire_e2392568118506 : Closed e2392568118506 ∧ code e2392568118506 = 11188661140714 := by decide
theorem cert_e2392568118506 : check e2392568118506 [[],[.left]] .chain = true := by decide
def e2392568171374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392568171374 : Closed e2392568171374 ∧ code e2392568171374 = 11188661193582 := by decide
theorem cert_e2392568171374 : check e2392568171374 [[],[.left]] .chain = true := by decide
def e2392568171382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392568171382 : Closed e2392568171382 ∧ code e2392568171382 = 11188661193590 := by decide
theorem cert_e2392568171382 : check e2392568171382 [[],[.left]] .chain = true := by decide
def e2392568171438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392568171438 : Closed e2392568171438 ∧ code e2392568171438 = 11188661193646 := by decide
theorem cert_e2392568171438 : check e2392568171438 [[],[.left]] .chain = true := by decide
def e2392568171450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392568171450 : Closed e2392568171450 ∧ code e2392568171450 = 11188661193658 := by decide
theorem cert_e2392568171450 : check e2392568171450 [[],[.left]] .chain = true := by decide
def e2392568171478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392568171478 : Closed e2392568171478 ∧ code e2392568171478 = 11188661193686 := by decide
theorem cert_e2392568171478 : check e2392568171478 [[],[.left]] .chain = true := by decide
def e2392568171482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392568171482 : Closed e2392568171482 ∧ code e2392568171482 = 11188661193690 := by decide
theorem cert_e2392568171482 : check e2392568171482 [[],[.left]] .chain = true := by decide
def e2392568171758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392568171758 : Closed e2392568171758 ∧ code e2392568171758 = 11188661193966 := by decide
theorem cert_e2392568171758 : check e2392568171758 [[],[.left]] .chain = true := by decide
def e2392568171766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392568171766 : Closed e2392568171766 ∧ code e2392568171766 = 11188661193974 := by decide
theorem cert_e2392568171766 : check e2392568171766 [[],[.left]] .chain = true := by decide
def e2392568172142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392568172142 : Closed e2392568172142 ∧ code e2392568172142 = 11188661194350 := by decide
theorem cert_e2392568172142 : check e2392568172142 [[],[.left]] .chain = true := by decide
def e2392568172154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392568172154 : Closed e2392568172154 ∧ code e2392568172154 = 11188661194362 := by decide
theorem cert_e2392568172154 : check e2392568172154 [[],[.left]] .chain = true := by decide
def e2392568172342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392568172342 : Closed e2392568172342 ∧ code e2392568172342 = 11188661194550 := by decide
theorem cert_e2392568172342 : check e2392568172342 [[],[.left]] .chain = true := by decide
def e2392568172346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392568172346 : Closed e2392568172346 ∧ code e2392568172346 = 11188661194554 := by decide
theorem cert_e2392568172346 : check e2392568172346 [[],[.left]] .chain = true := by decide
def e2392568376798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2392568376798 : Closed e2392568376798 ∧ code e2392568376798 = 11188661399006 := by decide
theorem cert_e2392568376798 : check e2392568376798 [[],[.left]] .chain = true := by decide
def e2392568376814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2392568376814 : Closed e2392568376814 ∧ code e2392568376814 = 11188661399022 := by decide
theorem cert_e2392568376814 : check e2392568376814 [[],[.left]] .chain = true := by decide
def e2392568377182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2392568377182 : Closed e2392568377182 ∧ code e2392568377182 = 11188661399390 := by decide
theorem cert_e2392568377182 : check e2392568377182 [[],[.left]] .chain = true := by decide
def e2392568377210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2392568377210 : Closed e2392568377210 ∧ code e2392568377210 = 11188661399418 := by decide
theorem cert_e2392568377210 : check e2392568377210 [[],[.left]] .chain = true := by decide
def e2392568377262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2392568377262 : Closed e2392568377262 ∧ code e2392568377262 = 11188661399470 := by decide
theorem cert_e2392568377262 : check e2392568377262 [[],[.left]] .chain = true := by decide
def e2392568377274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2392568377274 : Closed e2392568377274 ∧ code e2392568377274 = 11188661399482 := by decide
theorem cert_e2392568377274 : check e2392568377274 [[],[.left]] .chain = true := by decide
def e2392568378334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2392568378334 : Closed e2392568378334 ∧ code e2392568378334 = 11188661400542 := by decide
theorem cert_e2392568378334 : check e2392568378334 [[],[.left]] .chain = true := by decide
def e2392568378350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2392568378350 : Closed e2392568378350 ∧ code e2392568378350 = 11188661400558 := by decide
theorem cert_e2392568378350 : check e2392568378350 [[],[.left]] .chain = true := by decide
def e2392568380638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392568380638 : Closed e2392568380638 ∧ code e2392568380638 = 11188661402846 := by decide
theorem cert_e2392568380638 : check e2392568380638 [[],[.left]] .chain = true := by decide
def e2392568380666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392568380666 : Closed e2392568380666 ∧ code e2392568380666 = 11188661402874 := by decide
theorem cert_e2392568380666 : check e2392568380666 [[],[.left]] .chain = true := by decide
def e2392568381038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392568381038 : Closed e2392568381038 ∧ code e2392568381038 = 11188661403246 := by decide
theorem cert_e2392568381038 : check e2392568381038 [[],[.left]] .chain = true := by decide
def e2392568381050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392568381050 : Closed e2392568381050 ∧ code e2392568381050 = 11188661403258 := by decide
theorem cert_e2392568381050 : check e2392568381050 [[],[.left]] .chain = true := by decide
def e2392568409454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2392568409454 : Closed e2392568409454 ∧ code e2392568409454 = 11188661431662 := by decide
theorem cert_e2392568409454 : check e2392568409454 [[],[.left]] .chain = true := by decide
def e2392568409462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2392568409462 : Closed e2392568409462 ∧ code e2392568409462 = 11188661431670 := by decide
theorem cert_e2392568409462 : check e2392568409462 [[],[.left]] .chain = true := by decide
def e2392568409518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2392568409518 : Closed e2392568409518 ∧ code e2392568409518 = 11188661431726 := by decide
theorem cert_e2392568409518 : check e2392568409518 [[],[.left]] .chain = true := by decide
def e2392568409530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2392568409530 : Closed e2392568409530 ∧ code e2392568409530 = 11188661431738 := by decide
theorem cert_e2392568409530 : check e2392568409530 [[],[.left]] .chain = true := by decide
def e2392568409558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2392568409558 : Closed e2392568409558 ∧ code e2392568409558 = 11188661431766 := by decide
theorem cert_e2392568409558 : check e2392568409558 [[],[.left]] .chain = true := by decide
def e2392568409562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2392568409562 : Closed e2392568409562 ∧ code e2392568409562 = 11188661431770 := by decide
theorem cert_e2392568409562 : check e2392568409562 [[],[.left]] .chain = true := by decide
def e2392568409774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2392568409774 : Closed e2392568409774 ∧ code e2392568409774 = 11188661431982 := by decide
theorem cert_e2392568409774 : check e2392568409774 [[],[.left]] .chain = true := by decide
def e2392568409786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2392568409786 : Closed e2392568409786 ∧ code e2392568409786 = 11188661431994 := by decide
theorem cert_e2392568409786 : check e2392568409786 [[],[.left]] .chain = true := by decide
def e2392568409834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2392568409834 : Closed e2392568409834 ∧ code e2392568409834 = 11188661432042 := by decide
theorem cert_e2392568409834 : check e2392568409834 [[],[.left]] .chain = true := by decide
def e2392568409942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2392568409942 : Closed e2392568409942 ∧ code e2392568409942 = 11188661432150 := by decide
theorem cert_e2392568409942 : check e2392568409942 [[],[.left]] .chain = true := by decide
def e2392568409946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2392568409946 : Closed e2392568409946 ∧ code e2392568409946 = 11188661432154 := by decide
theorem cert_e2392568409946 : check e2392568409946 [[],[.left]] .chain = true := by decide
def e2392568409962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2392568409962 : Closed e2392568409962 ∧ code e2392568409962 = 11188661432170 := by decide
theorem cert_e2392568409962 : check e2392568409962 [[],[.left]] .chain = true := by decide
def e2392568410990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2392568410990 : Closed e2392568410990 ∧ code e2392568410990 = 11188661433198 := by decide
theorem cert_e2392568410990 : check e2392568410990 [[],[.left]] .chain = true := by decide
def e2392568410998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2392568410998 : Closed e2392568410998 ∧ code e2392568410998 = 11188661433206 := by decide
theorem cert_e2392568410998 : check e2392568410998 [[],[.left]] .chain = true := by decide
def e2392568411054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2392568411054 : Closed e2392568411054 ∧ code e2392568411054 = 11188661433262 := by decide
theorem cert_e2392568411054 : check e2392568411054 [[],[.left]] .chain = true := by decide
def e2392568411066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2392568411066 : Closed e2392568411066 ∧ code e2392568411066 = 11188661433274 := by decide
theorem cert_e2392568411066 : check e2392568411066 [[],[.left]] .chain = true := by decide
def e2392568411094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2392568411094 : Closed e2392568411094 ∧ code e2392568411094 = 11188661433302 := by decide
theorem cert_e2392568411094 : check e2392568411094 [[],[.left]] .chain = true := by decide
def e2392568411098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2392568411098 : Closed e2392568411098 ∧ code e2392568411098 = 11188661433306 := by decide
theorem cert_e2392568411098 : check e2392568411098 [[],[.left]] .chain = true := by decide
def e2392568411374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392568411374 : Closed e2392568411374 ∧ code e2392568411374 = 11188661433582 := by decide
theorem cert_e2392568411374 : check e2392568411374 [[],[.left]] .chain = true := by decide
def e2392568411382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392568411382 : Closed e2392568411382 ∧ code e2392568411382 = 11188661433590 := by decide
theorem cert_e2392568411382 : check e2392568411382 [[],[.left]] .chain = true := by decide
def e2392568411758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392568411758 : Closed e2392568411758 ∧ code e2392568411758 = 11188661433966 := by decide
theorem cert_e2392568411758 : check e2392568411758 [[],[.left]] .chain = true := by decide
def e2392568411770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392568411770 : Closed e2392568411770 ∧ code e2392568411770 = 11188661433978 := by decide
theorem cert_e2392568411770 : check e2392568411770 [[],[.left]] .chain = true := by decide
def e2392568411958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392568411958 : Closed e2392568411958 ∧ code e2392568411958 = 11188661434166 := by decide
theorem cert_e2392568411958 : check e2392568411958 [[],[.left]] .chain = true := by decide
def e2392568411962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392568411962 : Closed e2392568411962 ∧ code e2392568411962 = 11188661434170 := by decide
theorem cert_e2392568411962 : check e2392568411962 [[],[.left]] .chain = true := by decide
def e2392568412590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2392568412590 : Closed e2392568412590 ∧ code e2392568412590 = 11188661434798 := by decide
theorem cert_e2392568412590 : check e2392568412590 [[],[.left]] .chain = true := by decide
def e2392568412602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2392568412602 : Closed e2392568412602 ∧ code e2392568412602 = 11188661434810 := by decide
theorem cert_e2392568412602 : check e2392568412602 [[],[.left]] .chain = true := by decide
def e2392568412650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2392568412650 : Closed e2392568412650 ∧ code e2392568412650 = 11188661434858 := by decide
theorem cert_e2392568412650 : check e2392568412650 [[],[.left]] .chain = true := by decide
def e2392568412782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392568412782 : Closed e2392568412782 ∧ code e2392568412782 = 11188661434990 := by decide
theorem cert_e2392568412782 : check e2392568412782 [[],[.left]] .chain = true := by decide
def e2392568412794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392568412794 : Closed e2392568412794 ∧ code e2392568412794 = 11188661435002 := by decide
theorem cert_e2392568412794 : check e2392568412794 [[],[.left]] .chain = true := by decide
def e2392568413082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392568413082 : Closed e2392568413082 ∧ code e2392568413082 = 11188661435290 := by decide
theorem cert_e2392568413082 : check e2392568413082 [[],[.left]] .chain = true := by decide
def e2392568413398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2392568413398 : Closed e2392568413398 ∧ code e2392568413398 = 11188661435606 := by decide
theorem cert_e2392568413398 : check e2392568413398 [[],[.left]] .chain = true := by decide
def e2392568413402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2392568413402 : Closed e2392568413402 ∧ code e2392568413402 = 11188661435610 := by decide
theorem cert_e2392568413402 : check e2392568413402 [[],[.left]] .chain = true := by decide
def e2392568413418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2392568413418 : Closed e2392568413418 ∧ code e2392568413418 = 11188661435626 := by decide
theorem cert_e2392568413418 : check e2392568413418 [[],[.left]] .chain = true := by decide
def e2392568413494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392568413494 : Closed e2392568413494 ∧ code e2392568413494 = 11188661435702 := by decide
theorem cert_e2392568413494 : check e2392568413494 [[],[.left]] .chain = true := by decide
def e2392568413498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392568413498 : Closed e2392568413498 ∧ code e2392568413498 = 11188661435706 := by decide
theorem cert_e2392568413498 : check e2392568413498 [[],[.left]] .chain = true := by decide
def e2392568413594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392568413594 : Closed e2392568413594 ∧ code e2392568413594 = 11188661435802 := by decide
theorem cert_e2392568413594 : check e2392568413594 [[],[.left]] .chain = true := by decide
def e2392568415198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2392568415198 : Closed e2392568415198 ∧ code e2392568415198 = 11188661437406 := by decide
theorem cert_e2392568415198 : check e2392568415198 [[],[.left]] .chain = true := by decide
def e2392568415214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2392568415214 : Closed e2392568415214 ∧ code e2392568415214 = 11188661437422 := by decide
theorem cert_e2392568415214 : check e2392568415214 [[],[.left]] .chain = true := by decide
def e2392568417134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392568417134 : Closed e2392568417134 ∧ code e2392568417134 = 11188661439342 := by decide
theorem cert_e2392568417134 : check e2392568417134 [[],[.left]] .chain = true := by decide
def e2392568417142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392568417142 : Closed e2392568417142 ∧ code e2392568417142 = 11188661439350 := by decide
theorem cert_e2392568417142 : check e2392568417142 [[],[.left]] .chain = true := by decide
def e2392568417198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392568417198 : Closed e2392568417198 ∧ code e2392568417198 = 11188661439406 := by decide
theorem cert_e2392568417198 : check e2392568417198 [[],[.left]] .chain = true := by decide
def e2392568417210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392568417210 : Closed e2392568417210 ∧ code e2392568417210 = 11188661439418 := by decide
theorem cert_e2392568417210 : check e2392568417210 [[],[.left]] .chain = true := by decide
def e2392568417238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392568417238 : Closed e2392568417238 ∧ code e2392568417238 = 11188661439446 := by decide
theorem cert_e2392568417238 : check e2392568417238 [[],[.left]] .chain = true := by decide
def e2392568417242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392568417242 : Closed e2392568417242 ∧ code e2392568417242 = 11188661439450 := by decide
theorem cert_e2392568417242 : check e2392568417242 [[],[.left]] .chain = true := by decide
def e2392568417518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392568417518 : Closed e2392568417518 ∧ code e2392568417518 = 11188661439726 := by decide
theorem cert_e2392568417518 : check e2392568417518 [[],[.left]] .chain = true := by decide
def e2392568417526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392568417526 : Closed e2392568417526 ∧ code e2392568417526 = 11188661439734 := by decide
theorem cert_e2392568417526 : check e2392568417526 [[],[.left]] .chain = true := by decide
def e2392568417902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392568417902 : Closed e2392568417902 ∧ code e2392568417902 = 11188661440110 := by decide
theorem cert_e2392568417902 : check e2392568417902 [[],[.left]] .chain = true := by decide
def e2392568417914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392568417914 : Closed e2392568417914 ∧ code e2392568417914 = 11188661440122 := by decide
theorem cert_e2392568417914 : check e2392568417914 [[],[.left]] .chain = true := by decide
def e2392568418102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392568418102 : Closed e2392568418102 ∧ code e2392568418102 = 11188661440310 := by decide
theorem cert_e2392568418102 : check e2392568418102 [[],[.left]] .chain = true := by decide
def e2392568418106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392568418106 : Closed e2392568418106 ∧ code e2392568418106 = 11188661440314 := by decide
theorem cert_e2392568418106 : check e2392568418106 [[],[.left]] .chain = true := by decide
end Blc.Floor43
