import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407530266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407530266 : Closed e2422407530266 ∧ code e2422407530266 = 11218500552474 := by decide
theorem cert_e2422407530266 : check e2422407530266 [[],[]] .chain = true := by decide
def e2422407530310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407530310 : Closed e2422407530310 ∧ code e2422407530310 = 11218500552518 := by decide
theorem cert_e2422407530310 : check e2422407530310 [[],[]] .chain = true := by decide
def e2422407530338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407530338 : Closed e2422407530338 ∧ code e2422407530338 = 11218500552546 := by decide
theorem cert_e2422407530338 : check e2422407530338 [[],[]] .chain = true := by decide
def e2422407530350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422407530350 : Closed e2422407530350 ∧ code e2422407530350 = 11218500552558 := by decide
theorem cert_e2422407530350 : check e2422407530350 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407530358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2422407530358 : Closed e2422407530358 ∧ code e2422407530358 = 11218500552566 := by decide
theorem cert_e2422407530358 : check e2422407530358 [[],[]] .chain = true := by decide
def e2422407530362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e2422407530362 : Closed e2422407530362 ∧ code e2422407530362 = 11218500552570 := by decide
theorem cert_e2422407530362 : check e2422407530362 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407530378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407530378 : Closed e2422407530378 ∧ code e2422407530378 = 11218500552586 := by decide
theorem cert_e2422407530378 : check e2422407530378 [[],[]] .chain = true := by decide
def e2422407530422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2422407530422 : Closed e2422407530422 ∧ code e2422407530422 = 11218500552630 := by decide
theorem cert_e2422407530422 : check e2422407530422 [[],[]] .chain = true := by decide
def e2422407530426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2422407530426 : Closed e2422407530426 ∧ code e2422407530426 = 11218500552634 := by decide
theorem cert_e2422407530426 : check e2422407530426 [[],[]] .chain = true := by decide
def e2422407530458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e2422407530458 : Closed e2422407530458 ∧ code e2422407530458 = 11218500552666 := by decide
theorem cert_e2422407530458 : check e2422407530458 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407530614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2422407530614 : Closed e2422407530614 ∧ code e2422407530614 = 11218500552822 := by decide
theorem cert_e2422407530614 : check e2422407530614 [[],[]] .chain = true := by decide
def e2422407530858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2422407530858 : Closed e2422407530858 ∧ code e2422407530858 = 11218500553066 := by decide
theorem cert_e2422407530858 : check e2422407530858 [[],[]] .chain = true := by decide
def e2422407530894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407530894 : Closed e2422407530894 ∧ code e2422407530894 = 11218500553102 := by decide
theorem cert_e2422407530894 : check e2422407530894 [[],[]] .chain = true := by decide
def e2422407530906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407530906 : Closed e2422407530906 ∧ code e2422407530906 = 11218500553114 := by decide
theorem cert_e2422407530906 : check e2422407530906 [[],[]] .chain = true := by decide
def e2422407530950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407530950 : Closed e2422407530950 ∧ code e2422407530950 = 11218500553158 := by decide
theorem cert_e2422407530950 : check e2422407530950 [[],[]] .chain = true := by decide
def e2422407531550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407531550 : Closed e2422407531550 ∧ code e2422407531550 = 11218500553758 := by decide
theorem cert_e2422407531550 : check e2422407531550 [[],[]] .chain = true := by decide
def e2422407531574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407531574 : Closed e2422407531574 ∧ code e2422407531574 = 11218500553782 := by decide
theorem cert_e2422407531574 : check e2422407531574 [[],[]] .chain = true := by decide
def e2422407531578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407531578 : Closed e2422407531578 ∧ code e2422407531578 = 11218500553786 := by decide
theorem cert_e2422407531578 : check e2422407531578 [[],[]] .chain = true := by decide
def e2422407531718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407531718 : Closed e2422407531718 ∧ code e2422407531718 = 11218500553926 := by decide
theorem cert_e2422407531718 : check e2422407531718 [[],[]] .chain = true := by decide
def e2422407531746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407531746 : Closed e2422407531746 ∧ code e2422407531746 = 11218500553954 := by decide
theorem cert_e2422407531746 : check e2422407531746 [[],[]] .chain = true := by decide
def e2422407531758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407531758 : Closed e2422407531758 ∧ code e2422407531758 = 11218500553966 := by decide
theorem cert_e2422407531758 : check e2422407531758 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407531766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407531766 : Closed e2422407531766 ∧ code e2422407531766 = 11218500553974 := by decide
theorem cert_e2422407531766 : check e2422407531766 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407532046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407532046 : Closed e2422407532046 ∧ code e2422407532046 = 11218500554254 := by decide
theorem cert_e2422407532046 : check e2422407532046 [[],[]] .chain = true := by decide
def e2422407532130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407532130 : Closed e2422407532130 ∧ code e2422407532130 = 11218500554338 := by decide
theorem cert_e2422407532130 : check e2422407532130 [[],[]] .chain = true := by decide
def e2422407532142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407532142 : Closed e2422407532142 ∧ code e2422407532142 = 11218500554350 := by decide
theorem cert_e2422407532142 : check e2422407532142 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407532154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407532154 : Closed e2422407532154 ∧ code e2422407532154 = 11218500554362 := by decide
theorem cert_e2422407532154 : check e2422407532154 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407532342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407532342 : Closed e2422407532342 ∧ code e2422407532342 = 11218500554550 := by decide
theorem cert_e2422407532342 : check e2422407532342 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407532346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407532346 : Closed e2422407532346 ∧ code e2422407532346 = 11218500554554 := by decide
theorem cert_e2422407532346 : check e2422407532346 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407534122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422407534122 : Closed e2422407534122 ∧ code e2422407534122 = 11218500556330 := by decide
theorem cert_e2422407534122 : check e2422407534122 [[],[]] .chain = true := by decide
def e2422407534218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407534218 : Closed e2422407534218 ∧ code e2422407534218 = 11218500556426 := by decide
theorem cert_e2422407534218 : check e2422407534218 [[],[]] .chain = true := by decide
def e2422407534242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407534242 : Closed e2422407534242 ∧ code e2422407534242 = 11218500556450 := by decide
theorem cert_e2422407534242 : check e2422407534242 [[],[]] .chain = true := by decide
def e2422407534254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407534254 : Closed e2422407534254 ∧ code e2422407534254 = 11218500556462 := by decide
theorem cert_e2422407534254 : check e2422407534254 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407534262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422407534262 : Closed e2422407534262 ∧ code e2422407534262 = 11218500556470 := by decide
theorem cert_e2422407534262 : check e2422407534262 [[],[]] .chain = true := by decide
def e2422407534266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407534266 : Closed e2422407534266 ∧ code e2422407534266 = 11218500556474 := by decide
theorem cert_e2422407534266 : check e2422407534266 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407534294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422407534294 : Closed e2422407534294 ∧ code e2422407534294 = 11218500556502 := by decide
theorem cert_e2422407534294 : check e2422407534294 [[],[]] .chain = true := by decide
def e2422407534298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422407534298 : Closed e2422407534298 ∧ code e2422407534298 = 11218500556506 := by decide
theorem cert_e2422407534298 : check e2422407534298 [[],[]] .chain = true := by decide
def e2422407534314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407534314 : Closed e2422407534314 ∧ code e2422407534314 = 11218500556522 := by decide
theorem cert_e2422407534314 : check e2422407534314 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407534422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422407534422 : Closed e2422407534422 ∧ code e2422407534422 = 11218500556630 := by decide
theorem cert_e2422407534422 : check e2422407534422 [[],[]] .chain = true := by decide
def e2422407534426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422407534426 : Closed e2422407534426 ∧ code e2422407534426 = 11218500556634 := by decide
theorem cert_e2422407534426 : check e2422407534426 [[],[]] .chain = true := by decide
def e2422407534442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422407534442 : Closed e2422407534442 ∧ code e2422407534442 = 11218500556650 := by decide
theorem cert_e2422407534442 : check e2422407534442 [[],[]] .chain = true := by decide
def e2422407534506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2422407534506 : Closed e2422407534506 ∧ code e2422407534506 = 11218500556714 := by decide
theorem cert_e2422407534506 : check e2422407534506 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407534602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407534602 : Closed e2422407534602 ∧ code e2422407534602 = 11218500556810 := by decide
theorem cert_e2422407534602 : check e2422407534602 [[],[]] .chain = true := by decide
def e2422407534638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407534638 : Closed e2422407534638 ∧ code e2422407534638 = 11218500556846 := by decide
theorem cert_e2422407534638 : check e2422407534638 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407534646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407534646 : Closed e2422407534646 ∧ code e2422407534646 = 11218500556854 := by decide
theorem cert_e2422407534646 : check e2422407534646 [[],[]] .chain = true := by decide
def e2422407534650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407534650 : Closed e2422407534650 ∧ code e2422407534650 = 11218500556858 := by decide
theorem cert_e2422407534650 : check e2422407534650 [[],[]] .chain = true := by decide
def e2422407534698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407534698 : Closed e2422407534698 ∧ code e2422407534698 = 11218500556906 := by decide
theorem cert_e2422407534698 : check e2422407534698 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407534734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407534734 : Closed e2422407534734 ∧ code e2422407534734 = 11218500556942 := by decide
theorem cert_e2422407534734 : check e2422407534734 [[],[]] .chain = true := by decide
def e2422407534746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407534746 : Closed e2422407534746 ∧ code e2422407534746 = 11218500556954 := by decide
theorem cert_e2422407534746 : check e2422407534746 [[],[]] .chain = true := by decide
def e2422407534790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407534790 : Closed e2422407534790 ∧ code e2422407534790 = 11218500556998 := by decide
theorem cert_e2422407534790 : check e2422407534790 [[],[]] .chain = true := by decide
def e2422407534818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407534818 : Closed e2422407534818 ∧ code e2422407534818 = 11218500557026 := by decide
theorem cert_e2422407534818 : check e2422407534818 [[],[]] .chain = true := by decide
def e2422407534830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407534830 : Closed e2422407534830 ∧ code e2422407534830 = 11218500557038 := by decide
theorem cert_e2422407534830 : check e2422407534830 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407534838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407534838 : Closed e2422407534838 ∧ code e2422407534838 = 11218500557046 := by decide
theorem cert_e2422407534838 : check e2422407534838 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407534986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407534986 : Closed e2422407534986 ∧ code e2422407534986 = 11218500557194 := by decide
theorem cert_e2422407534986 : check e2422407534986 [[],[]] .chain = true := by decide
def e2422407535010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407535010 : Closed e2422407535010 ∧ code e2422407535010 = 11218500557218 := by decide
theorem cert_e2422407535010 : check e2422407535010 [[],[]] .chain = true := by decide
def e2422407535022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407535022 : Closed e2422407535022 ∧ code e2422407535022 = 11218500557230 := by decide
theorem cert_e2422407535022 : check e2422407535022 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407535030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422407535030 : Closed e2422407535030 ∧ code e2422407535030 = 11218500557238 := by decide
theorem cert_e2422407535030 : check e2422407535030 [[],[]] .chain = true := by decide
def e2422407535034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407535034 : Closed e2422407535034 ∧ code e2422407535034 = 11218500557242 := by decide
theorem cert_e2422407535034 : check e2422407535034 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407535062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422407535062 : Closed e2422407535062 ∧ code e2422407535062 = 11218500557270 := by decide
theorem cert_e2422407535062 : check e2422407535062 [[],[]] .chain = true := by decide
def e2422407535066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422407535066 : Closed e2422407535066 ∧ code e2422407535066 = 11218500557274 := by decide
theorem cert_e2422407535066 : check e2422407535066 [[],[]] .chain = true := by decide
def e2422407535082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407535082 : Closed e2422407535082 ∧ code e2422407535082 = 11218500557290 := by decide
theorem cert_e2422407535082 : check e2422407535082 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407535106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407535106 : Closed e2422407535106 ∧ code e2422407535106 = 11218500557314 := by decide
theorem cert_e2422407535106 : check e2422407535106 [[],[]] .chain = true := by decide
def e2422407535118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407535118 : Closed e2422407535118 ∧ code e2422407535118 = 11218500557326 := by decide
theorem cert_e2422407535118 : check e2422407535118 [[],[]] .chain = true := by decide
def e2422407535130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407535130 : Closed e2422407535130 ∧ code e2422407535130 = 11218500557338 := by decide
theorem cert_e2422407535130 : check e2422407535130 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407535202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407535202 : Closed e2422407535202 ∧ code e2422407535202 = 11218500557410 := by decide
theorem cert_e2422407535202 : check e2422407535202 [[],[]] .chain = true := by decide
def e2422407535214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407535214 : Closed e2422407535214 ∧ code e2422407535214 = 11218500557422 := by decide
theorem cert_e2422407535214 : check e2422407535214 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407535222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407535222 : Closed e2422407535222 ∧ code e2422407535222 = 11218500557430 := by decide
theorem cert_e2422407535222 : check e2422407535222 [[],[]] .chain = true := by decide
def e2422407535226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407535226 : Closed e2422407535226 ∧ code e2422407535226 = 11218500557434 := by decide
theorem cert_e2422407535226 : check e2422407535226 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407535366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407535366 : Closed e2422407535366 ∧ code e2422407535366 = 11218500557574 := by decide
theorem cert_e2422407535366 : check e2422407535366 [[],[]] .chain = true := by decide
def e2422407535390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407535390 : Closed e2422407535390 ∧ code e2422407535390 = 11218500557598 := by decide
theorem cert_e2422407535390 : check e2422407535390 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407535414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407535414 : Closed e2422407535414 ∧ code e2422407535414 = 11218500557622 := by decide
theorem cert_e2422407535414 : check e2422407535414 [[],[]] .chain = true := by decide
def e2422407535418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407535418 : Closed e2422407535418 ∧ code e2422407535418 = 11218500557626 := by decide
theorem cert_e2422407535418 : check e2422407535418 [[],[]] .chain = true := by decide
def e2422407535490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407535490 : Closed e2422407535490 ∧ code e2422407535490 = 11218500557698 := by decide
theorem cert_e2422407535490 : check e2422407535490 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407535502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407535502 : Closed e2422407535502 ∧ code e2422407535502 = 11218500557710 := by decide
theorem cert_e2422407535502 : check e2422407535502 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407535514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407535514 : Closed e2422407535514 ∧ code e2422407535514 = 11218500557722 := by decide
theorem cert_e2422407535514 : check e2422407535514 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407535642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407535642 : Closed e2422407535642 ∧ code e2422407535642 = 11218500557850 := by decide
theorem cert_e2422407535642 : check e2422407535642 [[],[]] .chain = true := by decide
def e2422407535686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407535686 : Closed e2422407535686 ∧ code e2422407535686 = 11218500557894 := by decide
theorem cert_e2422407535686 : check e2422407535686 [[],[]] .chain = true := by decide
def e2422407535714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407535714 : Closed e2422407535714 ∧ code e2422407535714 = 11218500557922 := by decide
theorem cert_e2422407535714 : check e2422407535714 [[],[]] .chain = true := by decide
def e2422407535726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422407535726 : Closed e2422407535726 ∧ code e2422407535726 = 11218500557934 := by decide
theorem cert_e2422407535726 : check e2422407535726 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407535738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407535738 : Closed e2422407535738 ∧ code e2422407535738 = 11218500557946 := by decide
theorem cert_e2422407535738 : check e2422407535738 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407535830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407535830 : Closed e2422407535830 ∧ code e2422407535830 = 11218500558038 := by decide
theorem cert_e2422407535830 : check e2422407535830 [[],[]] .chain = true := by decide
def e2422407535834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407535834 : Closed e2422407535834 ∧ code e2422407535834 = 11218500558042 := by decide
theorem cert_e2422407535834 : check e2422407535834 [[],[]] .chain = true := by decide
def e2422407535850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407535850 : Closed e2422407535850 ∧ code e2422407535850 = 11218500558058 := by decide
theorem cert_e2422407535850 : check e2422407535850 [[],[]] .chain = true := by decide
def e2422407535878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407535878 : Closed e2422407535878 ∧ code e2422407535878 = 11218500558086 := by decide
theorem cert_e2422407535878 : check e2422407535878 [[],[]] .chain = true := by decide
def e2422407535902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422407535902 : Closed e2422407535902 ∧ code e2422407535902 = 11218500558110 := by decide
theorem cert_e2422407535902 : check e2422407535902 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407535926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407535926 : Closed e2422407535926 ∧ code e2422407535926 = 11218500558134 := by decide
theorem cert_e2422407535926 : check e2422407535926 [[],[]] .chain = true := by decide
def e2422407535930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407535930 : Closed e2422407535930 ∧ code e2422407535930 = 11218500558138 := by decide
theorem cert_e2422407535930 : check e2422407535930 [[],[]] .chain = true := by decide
def e2422407536026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407536026 : Closed e2422407536026 ∧ code e2422407536026 = 11218500558234 := by decide
theorem cert_e2422407536026 : check e2422407536026 [[],[]] .chain = true := by decide
def e2422407536070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407536070 : Closed e2422407536070 ∧ code e2422407536070 = 11218500558278 := by decide
theorem cert_e2422407536070 : check e2422407536070 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407536138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407536138 : Closed e2422407536138 ∧ code e2422407536138 = 11218500558346 := by decide
theorem cert_e2422407536138 : check e2422407536138 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407536182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407536182 : Closed e2422407536182 ∧ code e2422407536182 = 11218500558390 := by decide
theorem cert_e2422407536182 : check e2422407536182 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407536186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407536186 : Closed e2422407536186 ∧ code e2422407536186 = 11218500558394 := by decide
theorem cert_e2422407536186 : check e2422407536186 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407536234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407536234 : Closed e2422407536234 ∧ code e2422407536234 = 11218500558442 := by decide
theorem cert_e2422407536234 : check e2422407536234 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407536258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407536258 : Closed e2422407536258 ∧ code e2422407536258 = 11218500558466 := by decide
theorem cert_e2422407536258 : check e2422407536258 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407536270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407536270 : Closed e2422407536270 ∧ code e2422407536270 = 11218500558478 := by decide
theorem cert_e2422407536270 : check e2422407536270 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407536282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407536282 : Closed e2422407536282 ∧ code e2422407536282 = 11218500558490 := by decide
theorem cert_e2422407536282 : check e2422407536282 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407536326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407536326 : Closed e2422407536326 ∧ code e2422407536326 = 11218500558534 := by decide
theorem cert_e2422407536326 : check e2422407536326 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407536666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422407536666 : Closed e2422407536666 ∧ code e2422407536666 = 11218500558874 := by decide
theorem cert_e2422407536666 : check e2422407536666 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407536702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422407536702 : Closed e2422407536702 ∧ code e2422407536702 = 11218500558910 := by decide
theorem cert_e2422407536702 : check e2422407536702 [[],[]] .chain = true := by decide
def e2422407536750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422407536750 : Closed e2422407536750 ∧ code e2422407536750 = 11218500558958 := by decide
theorem cert_e2422407536750 : check e2422407536750 [[],[]] .chain = true := by decide
def e2422407536758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422407536758 : Closed e2422407536758 ∧ code e2422407536758 = 11218500558966 := by decide
theorem cert_e2422407536758 : check e2422407536758 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407536762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422407536762 : Closed e2422407536762 ∧ code e2422407536762 = 11218500558970 := by decide
theorem cert_e2422407536762 : check e2422407536762 [[],[]] .chain = true := by decide
def e2422407537002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422407537002 : Closed e2422407537002 ∧ code e2422407537002 = 11218500559210 := by decide
theorem cert_e2422407537002 : check e2422407537002 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407537038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422407537038 : Closed e2422407537038 ∧ code e2422407537038 = 11218500559246 := by decide
theorem cert_e2422407537038 : check e2422407537038 [[],[]] .chain = true := by decide
def e2422407537050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407537050 : Closed e2422407537050 ∧ code e2422407537050 = 11218500559258 := by decide
theorem cert_e2422407537050 : check e2422407537050 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407537094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422407537094 : Closed e2422407537094 ∧ code e2422407537094 = 11218500559302 := by decide
theorem cert_e2422407537094 : check e2422407537094 [[],[]] .chain = true := by decide
def e2422407537118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407537118 : Closed e2422407537118 ∧ code e2422407537118 = 11218500559326 := by decide
theorem cert_e2422407537118 : check e2422407537118 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407537122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407537122 : Closed e2422407537122 ∧ code e2422407537122 = 11218500559330 := by decide
theorem cert_e2422407537122 : check e2422407537122 [[],[]] .chain = true := by decide
def e2422407537134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422407537134 : Closed e2422407537134 ∧ code e2422407537134 = 11218500559342 := by decide
theorem cert_e2422407537134 : check e2422407537134 [[],[]] .chain = true := by decide
def e2422407537142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407537142 : Closed e2422407537142 ∧ code e2422407537142 = 11218500559350 := by decide
theorem cert_e2422407537142 : check e2422407537142 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407538058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407538058 : Closed e2422407538058 ∧ code e2422407538058 = 11218500560266 := by decide
theorem cert_e2422407538058 : check e2422407538058 [[],[]] .chain = true := by decide
def e2422407538082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407538082 : Closed e2422407538082 ∧ code e2422407538082 = 11218500560290 := by decide
theorem cert_e2422407538082 : check e2422407538082 [[],[]] .chain = true := by decide
def e2422407538094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407538094 : Closed e2422407538094 ∧ code e2422407538094 = 11218500560302 := by decide
theorem cert_e2422407538094 : check e2422407538094 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407538102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422407538102 : Closed e2422407538102 ∧ code e2422407538102 = 11218500560310 := by decide
theorem cert_e2422407538102 : check e2422407538102 [[],[]] .chain = true := by decide
def e2422407538106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407538106 : Closed e2422407538106 ∧ code e2422407538106 = 11218500560314 := by decide
theorem cert_e2422407538106 : check e2422407538106 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407538134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422407538134 : Closed e2422407538134 ∧ code e2422407538134 = 11218500560342 := by decide
theorem cert_e2422407538134 : check e2422407538134 [[],[]] .chain = true := by decide
def e2422407538138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422407538138 : Closed e2422407538138 ∧ code e2422407538138 = 11218500560346 := by decide
theorem cert_e2422407538138 : check e2422407538138 [[],[]] .chain = true := by decide
def e2422407538154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407538154 : Closed e2422407538154 ∧ code e2422407538154 = 11218500560362 := by decide
theorem cert_e2422407538154 : check e2422407538154 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407538178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407538178 : Closed e2422407538178 ∧ code e2422407538178 = 11218500560386 := by decide
theorem cert_e2422407538178 : check e2422407538178 [[],[]] .chain = true := by decide
def e2422407538190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407538190 : Closed e2422407538190 ∧ code e2422407538190 = 11218500560398 := by decide
theorem cert_e2422407538190 : check e2422407538190 [[],[]] .chain = true := by decide
def e2422407538202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407538202 : Closed e2422407538202 ∧ code e2422407538202 = 11218500560410 := by decide
theorem cert_e2422407538202 : check e2422407538202 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407538274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407538274 : Closed e2422407538274 ∧ code e2422407538274 = 11218500560482 := by decide
theorem cert_e2422407538274 : check e2422407538274 [[],[]] .chain = true := by decide
def e2422407538286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407538286 : Closed e2422407538286 ∧ code e2422407538286 = 11218500560494 := by decide
theorem cert_e2422407538286 : check e2422407538286 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407538294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407538294 : Closed e2422407538294 ∧ code e2422407538294 = 11218500560502 := by decide
theorem cert_e2422407538294 : check e2422407538294 [[],[]] .chain = true := by decide
def e2422407538298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407538298 : Closed e2422407538298 ∧ code e2422407538298 = 11218500560506 := by decide
theorem cert_e2422407538298 : check e2422407538298 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407538438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407538438 : Closed e2422407538438 ∧ code e2422407538438 = 11218500560646 := by decide
theorem cert_e2422407538438 : check e2422407538438 [[],[]] .chain = true := by decide
def e2422407538462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407538462 : Closed e2422407538462 ∧ code e2422407538462 = 11218500560670 := by decide
theorem cert_e2422407538462 : check e2422407538462 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407538486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407538486 : Closed e2422407538486 ∧ code e2422407538486 = 11218500560694 := by decide
theorem cert_e2422407538486 : check e2422407538486 [[],[]] .chain = true := by decide
def e2422407538490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407538490 : Closed e2422407538490 ∧ code e2422407538490 = 11218500560698 := by decide
theorem cert_e2422407538490 : check e2422407538490 [[],[]] .chain = true := by decide
def e2422407538562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407538562 : Closed e2422407538562 ∧ code e2422407538562 = 11218500560770 := by decide
theorem cert_e2422407538562 : check e2422407538562 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407538574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407538574 : Closed e2422407538574 ∧ code e2422407538574 = 11218500560782 := by decide
theorem cert_e2422407538574 : check e2422407538574 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407538586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407538586 : Closed e2422407538586 ∧ code e2422407538586 = 11218500560794 := by decide
theorem cert_e2422407538586 : check e2422407538586 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407540766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e2422407540766 : Closed e2422407540766 ∧ code e2422407540766 = 11218500562974 := by decide
theorem cert_e2422407540766 : check e2422407540766 [[],[]] .chain = true := by decide
def e2422407540962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422407540962 : Closed e2422407540962 ∧ code e2422407540962 = 11218500563170 := by decide
theorem cert_e2422407540962 : check e2422407540962 [[],[]] .chain = true := by decide
def e2422407540974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407540974 : Closed e2422407540974 ∧ code e2422407540974 = 11218500563182 := by decide
theorem cert_e2422407540974 : check e2422407540974 [[],[]] .chain = true := by decide
def e2422407540982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407540982 : Closed e2422407540982 ∧ code e2422407540982 = 11218500563190 := by decide
theorem cert_e2422407540982 : check e2422407540982 [[],[]] .chain = true := by decide
def e2422407541462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407541462 : Closed e2422407541462 ∧ code e2422407541462 = 11218500563670 := by decide
theorem cert_e2422407541462 : check e2422407541462 [[],[]] .chain = true := by decide
def e2422407541466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407541466 : Closed e2422407541466 ∧ code e2422407541466 = 11218500563674 := by decide
theorem cert_e2422407541466 : check e2422407541466 [[],[]] .chain = true := by decide
def e2422407541482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407541482 : Closed e2422407541482 ∧ code e2422407541482 = 11218500563690 := by decide
theorem cert_e2422407541482 : check e2422407541482 [[],[]] .chain = true := by decide
def e2422407541510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407541510 : Closed e2422407541510 ∧ code e2422407541510 = 11218500563718 := by decide
theorem cert_e2422407541510 : check e2422407541510 [[],[]] .chain = true := by decide
def e2422407541534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407541534 : Closed e2422407541534 ∧ code e2422407541534 = 11218500563742 := by decide
theorem cert_e2422407541534 : check e2422407541534 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407541558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407541558 : Closed e2422407541558 ∧ code e2422407541558 = 11218500563766 := by decide
theorem cert_e2422407541558 : check e2422407541558 [[],[]] .chain = true := by decide
def e2422407541562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407541562 : Closed e2422407541562 ∧ code e2422407541562 = 11218500563770 := by decide
theorem cert_e2422407541562 : check e2422407541562 [[],[]] .chain = true := by decide
def e2422407541658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407541658 : Closed e2422407541658 ∧ code e2422407541658 = 11218500563866 := by decide
theorem cert_e2422407541658 : check e2422407541658 [[],[]] .chain = true := by decide
def e2422407541702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407541702 : Closed e2422407541702 ∧ code e2422407541702 = 11218500563910 := by decide
theorem cert_e2422407541702 : check e2422407541702 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407542902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2422407542902 : Closed e2422407542902 ∧ code e2422407542902 = 11218500565110 := by decide
theorem cert_e2422407542902 : check e2422407542902 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407543146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2422407543146 : Closed e2422407543146 ∧ code e2422407543146 = 11218500565354 := by decide
theorem cert_e2422407543146 : check e2422407543146 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407543170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407543170 : Closed e2422407543170 ∧ code e2422407543170 = 11218500565378 := by decide
theorem cert_e2422407543170 : check e2422407543170 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407543182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407543182 : Closed e2422407543182 ∧ code e2422407543182 = 11218500565390 := by decide
theorem cert_e2422407543182 : check e2422407543182 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407543194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407543194 : Closed e2422407543194 ∧ code e2422407543194 = 11218500565402 := by decide
theorem cert_e2422407543194 : check e2422407543194 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407543238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407543238 : Closed e2422407543238 ∧ code e2422407543238 = 11218500565446 := by decide
theorem cert_e2422407543238 : check e2422407543238 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407545142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407545142 : Closed e2422407545142 ∧ code e2422407545142 = 11218500567350 := by decide
private def t_e2422407545142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem cert_e2422407545142 : ¬ IsSelfInterpreter e2422407545142 :=
  wSource (t := t_e2422407545142) (replay_sound (ps := []) (t := e2422407545142) (by decide)) (by decide)
def e2422407545146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407545146 : Closed e2422407545146 ∧ code e2422407545146 = 11218500567354 := by decide
private def t_e2422407545146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem cert_e2422407545146 : ¬ IsSelfInterpreter e2422407545146 :=
  wSource (t := t_e2422407545146) (replay_sound (ps := []) (t := e2422407545146) (by decide)) (by decide)
def e2422407545782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2422407545782 : Closed e2422407545782 ∧ code e2422407545782 = 11218500567990 := by decide
private def t_e2422407545782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem cert_e2422407545782 : ¬ IsSelfInterpreter e2422407545782 :=
  wSource (t := t_e2422407545782) (replay_sound (ps := []) (t := e2422407545782) (by decide)) (by decide)
def e2422407545786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422407545786 : Closed e2422407545786 ∧ code e2422407545786 = 11218500567994 := by decide
private def t_e2422407545786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem cert_e2422407545786 : ¬ IsSelfInterpreter e2422407545786 :=
  wSource (t := t_e2422407545786) (replay_sound (ps := []) (t := e2422407545786) (by decide)) (by decide)
def e2422407545818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422407545818 : Closed e2422407545818 ∧ code e2422407545818 = 11218500568026 := by decide
private def t_e2422407545818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem cert_e2422407545818 : ¬ IsSelfInterpreter e2422407545818 :=
  wSource (t := t_e2422407545818) (replay_sound (ps := []) (t := e2422407545818) (by decide)) (by decide)
def e2422407546486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407546486 : Closed e2422407546486 ∧ code e2422407546486 = 11218500568694 := by decide
private def t_e2422407546486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem cert_e2422407546486 : ¬ IsSelfInterpreter e2422407546486 :=
  wSource (t := t_e2422407546486) (replay_sound (ps := []) (t := e2422407546486) (by decide)) (by decide)
def e2422407546678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407546678 : Closed e2422407546678 ∧ code e2422407546678 = 11218500568886 := by decide
private def t_e2422407546678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem cert_e2422407546678 : ¬ IsSelfInterpreter e2422407546678 :=
  wSource (t := t_e2422407546678) (replay_sound (ps := []) (t := e2422407546678) (by decide)) (by decide)
def e2422407546682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407546682 : Closed e2422407546682 ∧ code e2422407546682 = 11218500568890 := by decide
private def t_e2422407546682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem cert_e2422407546682 : ¬ IsSelfInterpreter e2422407546682 :=
  wSource (t := t_e2422407546682) (replay_sound (ps := []) (t := e2422407546682) (by decide)) (by decide)
def e2422407547734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422407547734 : Closed e2422407547734 ∧ code e2422407547734 = 11218500569942 := by decide
private def t_e2422407547734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem cert_e2422407547734 : ¬ IsSelfInterpreter e2422407547734 :=
  wSource (t := t_e2422407547734) (replay_sound (ps := []) (t := e2422407547734) (by decide)) (by decide)
def e2422407547738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422407547738 : Closed e2422407547738 ∧ code e2422407547738 = 11218500569946 := by decide
private def t_e2422407547738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem cert_e2422407547738 : ¬ IsSelfInterpreter e2422407547738 :=
  wSource (t := t_e2422407547738) (replay_sound (ps := []) (t := e2422407547738) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422407545142
#print axioms Blc.Floor43.cert_e2422407545146
#print axioms Blc.Floor43.cert_e2422407545782
#print axioms Blc.Floor43.cert_e2422407545786
#print axioms Blc.Floor43.cert_e2422407545818
#print axioms Blc.Floor43.cert_e2422407546486
#print axioms Blc.Floor43.cert_e2422407546678
#print axioms Blc.Floor43.cert_e2422407546682
#print axioms Blc.Floor43.cert_e2422407547734
#print axioms Blc.Floor43.cert_e2422407547738
