import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374000034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422374000034 : Closed e2422374000034 ∧ code e2422374000034 = 11218467022242 := by decide
theorem cert_e2422374000034 : check e2422374000034 [[],[]] .three = true := by decide
def e2422374000046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422374000046 : Closed e2422374000046 ∧ code e2422374000046 = 11218467022254 := by decide
theorem cert_e2422374000046 : check e2422374000046 [[],[]] .three = true := by decide
def e2422374000054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2422374000054 : Closed e2422374000054 ∧ code e2422374000054 = 11218467022262 := by decide
theorem cert_e2422374000054 : check e2422374000054 [[],[]] .three = true := by decide
def e2422374000058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422374000058 : Closed e2422374000058 ∧ code e2422374000058 = 11218467022266 := by decide
theorem cert_e2422374000058 : check e2422374000058 [[],[]] .three = true := by decide
def e2422374000086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2422374000086 : Closed e2422374000086 ∧ code e2422374000086 = 11218467022294 := by decide
theorem cert_e2422374000086 : check e2422374000086 [[],[]] .three = true := by decide
def e2422374000090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2422374000090 : Closed e2422374000090 ∧ code e2422374000090 = 11218467022298 := by decide
theorem cert_e2422374000090 : check e2422374000090 [[],[]] .three = true := by decide
def e2422374000106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422374000106 : Closed e2422374000106 ∧ code e2422374000106 = 11218467022314 := by decide
theorem cert_e2422374000106 : check e2422374000106 [[],[]] .three = true := by decide
def e2422374000142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2422374000142 : Closed e2422374000142 ∧ code e2422374000142 = 11218467022350 := by decide
theorem cert_e2422374000142 : check e2422374000142 [[],[]] .three = true := by decide
def e2422374000154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374000154 : Closed e2422374000154 ∧ code e2422374000154 = 11218467022362 := by decide
theorem cert_e2422374000154 : check e2422374000154 [[],[]] .three = true := by decide
def e2422374000190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422374000190 : Closed e2422374000190 ∧ code e2422374000190 = 11218467022398 := by decide
theorem cert_e2422374000190 : check e2422374000190 [[],[]] .three = true := by decide
def e2422374000226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422374000226 : Closed e2422374000226 ∧ code e2422374000226 = 11218467022434 := by decide
theorem cert_e2422374000226 : check e2422374000226 [[],[]] .three = true := by decide
def e2422374000238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374000238 : Closed e2422374000238 ∧ code e2422374000238 = 11218467022446 := by decide
theorem cert_e2422374000238 : check e2422374000238 [[],[]] .three = true := by decide
def e2422374000246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374000246 : Closed e2422374000246 ∧ code e2422374000246 = 11218467022454 := by decide
theorem cert_e2422374000246 : check e2422374000246 [[],[]] .three = true := by decide
def e2422374000250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374000250 : Closed e2422374000250 ∧ code e2422374000250 = 11218467022458 := by decide
theorem cert_e2422374000250 : check e2422374000250 [[],[]] .three = true := by decide
def e2422374000414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422374000414 : Closed e2422374000414 ∧ code e2422374000414 = 11218467022622 := by decide
theorem cert_e2422374000414 : check e2422374000414 [[],[]] .three = true := by decide
def e2422374000438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374000438 : Closed e2422374000438 ∧ code e2422374000438 = 11218467022646 := by decide
theorem cert_e2422374000438 : check e2422374000438 [[],[]] .three = true := by decide
def e2422374000442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374000442 : Closed e2422374000442 ∧ code e2422374000442 = 11218467022650 := by decide
theorem cert_e2422374000442 : check e2422374000442 [[],[]] .three = true := by decide
def e2422374000526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422374000526 : Closed e2422374000526 ∧ code e2422374000526 = 11218467022734 := by decide
theorem cert_e2422374000526 : check e2422374000526 [[],[]] .three = true := by decide
def e2422374000538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374000538 : Closed e2422374000538 ∧ code e2422374000538 = 11218467022746 := by decide
theorem cert_e2422374000538 : check e2422374000538 [[],[]] .three = true := by decide
def e2422374000582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422374000582 : Closed e2422374000582 ∧ code e2422374000582 = 11218467022790 := by decide
theorem cert_e2422374000582 : check e2422374000582 [[],[]] .three = true := by decide
def e2422374010478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422374010478 : Closed e2422374010478 ∧ code e2422374010478 = 11218467032686 := by decide
theorem cert_e2422374010478 : check e2422374010478 [[],[]] .three = true := by decide
def e2422374010486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422374010486 : Closed e2422374010486 ∧ code e2422374010486 = 11218467032694 := by decide
theorem cert_e2422374010486 : check e2422374010486 [[],[]] .three = true := by decide
def e2422374010490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422374010490 : Closed e2422374010490 ∧ code e2422374010490 = 11218467032698 := by decide
theorem cert_e2422374010490 : check e2422374010490 [[],[]] .three = true := by decide
def e2422374010678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374010678 : Closed e2422374010678 ∧ code e2422374010678 = 11218467032886 := by decide
theorem cert_e2422374010678 : check e2422374010678 [[],[]] .three = true := by decide
def e2422374010682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374010682 : Closed e2422374010682 ∧ code e2422374010682 = 11218467032890 := by decide
theorem cert_e2422374010682 : check e2422374010682 [[],[]] .three = true := by decide
def e2422374010778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374010778 : Closed e2422374010778 ∧ code e2422374010778 = 11218467032986 := by decide
theorem cert_e2422374010778 : check e2422374010778 [[],[]] .three = true := by decide
def e2422374012598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1)))))))
theorem wire_e2422374012598 : Closed e2422374012598 ∧ code e2422374012598 = 11218467034806 := by decide
private def t_e2422374012598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1)))))))
theorem cert_e2422374012598 : ¬ IsSelfInterpreter e2422374012598 :=
  wSource (t := t_e2422374012598) (replay_sound (ps := []) (t := e2422374012598) (by decide)) (by decide)
def e2422374012602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e2422374012602 : Closed e2422374012602 ∧ code e2422374012602 = 11218467034810 := by decide
private def t_e2422374012602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)))))))
theorem cert_e2422374012602 : ¬ IsSelfInterpreter e2422374012602 :=
  wSource (t := t_e2422374012602) (replay_sound (ps := []) (t := e2422374012602) (by decide)) (by decide)
def e2422374012630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1)))))))
theorem wire_e2422374012630 : Closed e2422374012630 ∧ code e2422374012630 = 11218467034838 := by decide
theorem cert_e2422374012630 : check e2422374012630 [[],[]] .three = true := by decide
def e2422374012650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e2422374012650 : Closed e2422374012650 ∧ code e2422374012650 = 11218467034858 := by decide
theorem cert_e2422374012650 : check e2422374012650 [[],[]] .three = true := by decide
def e2422374012758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 1)))))))
theorem wire_e2422374012758 : Closed e2422374012758 ∧ code e2422374012758 = 11218467034966 := by decide
theorem cert_e2422374012758 : check e2422374012758 [[],[]] .three = true := by decide
def e2422374012842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422374012842 : Closed e2422374012842 ∧ code e2422374012842 = 11218467035050 := by decide
theorem cert_e2422374012842 : check e2422374012842 [[],[]] .three = true := by decide
def e2422374013366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422374013366 : Closed e2422374013366 ∧ code e2422374013366 = 11218467035574 := by decide
theorem cert_e2422374013366 : check e2422374013366 [[],[]] .three = true := by decide
def e2422374013370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422374013370 : Closed e2422374013370 ∧ code e2422374013370 = 11218467035578 := by decide
theorem cert_e2422374013370 : check e2422374013370 [[],[]] .three = true := by decide
def e2422374013398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422374013398 : Closed e2422374013398 ∧ code e2422374013398 = 11218467035606 := by decide
theorem cert_e2422374013398 : check e2422374013398 [[],[]] .three = true := by decide
def e2422374013418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422374013418 : Closed e2422374013418 ∧ code e2422374013418 = 11218467035626 := by decide
theorem cert_e2422374013418 : check e2422374013418 [[],[]] .three = true := by decide
def e2422374013550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422374013550 : Closed e2422374013550 ∧ code e2422374013550 = 11218467035758 := by decide
private def t_e2422374013550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem cert_e2422374013550 : ¬ IsSelfInterpreter e2422374013550 :=
  wSource (t := t_e2422374013550) (replay_sound (ps := []) (t := e2422374013550) (by decide)) (by decide)
def e2422374013562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422374013562 : Closed e2422374013562 ∧ code e2422374013562 = 11218467035770 := by decide
private def t_e2422374013562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem cert_e2422374013562 : ¬ IsSelfInterpreter e2422374013562 :=
  wSource (t := t_e2422374013562) (replay_sound (ps := []) (t := e2422374013562) (by decide)) (by decide)
def e2422374013750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374013750 : Closed e2422374013750 ∧ code e2422374013750 = 11218467035958 := by decide
theorem cert_e2422374013750 : check e2422374013750 [[],[]] .three = true := by decide
def e2422374013754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374013754 : Closed e2422374013754 ∧ code e2422374013754 = 11218467035962 := by decide
theorem cert_e2422374013754 : check e2422374013754 [[],[]] .three = true := by decide
def e2422374013850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374013850 : Closed e2422374013850 ∧ code e2422374013850 = 11218467036058 := by decide
theorem cert_e2422374013850 : check e2422374013850 [[],[]] .three = true := by decide
def e2422374014070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422374014070 : Closed e2422374014070 ∧ code e2422374014070 = 11218467036278 := by decide
theorem cert_e2422374014070 : check e2422374014070 [[],[]] .three = true := by decide
def e2422374014074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422374014074 : Closed e2422374014074 ∧ code e2422374014074 = 11218467036282 := by decide
theorem cert_e2422374014074 : check e2422374014074 [[],[]] .three = true := by decide
def e2422374014166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e2422374014166 : Closed e2422374014166 ∧ code e2422374014166 = 11218467036374 := by decide
theorem cert_e2422374014166 : check e2422374014166 [[],[]] .three = true := by decide
def e2422374014262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422374014262 : Closed e2422374014262 ∧ code e2422374014262 = 11218467036470 := by decide
theorem cert_e2422374014262 : check e2422374014262 [[],[]] .three = true := by decide
def e2422374014266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422374014266 : Closed e2422374014266 ∧ code e2422374014266 = 11218467036474 := by decide
theorem cert_e2422374014266 : check e2422374014266 [[],[]] .three = true := by decide
def e2422374014350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422374014350 : Closed e2422374014350 ∧ code e2422374014350 = 11218467036558 := by decide
theorem cert_e2422374014350 : check e2422374014350 [[],[]] .three = true := by decide
def e2422374014406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422374014406 : Closed e2422374014406 ∧ code e2422374014406 = 11218467036614 := by decide
theorem cert_e2422374014406 : check e2422374014406 [[],[]] .three = true := by decide
def e2422374014430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e2422374014430 : Closed e2422374014430 ∧ code e2422374014430 = 11218467036638 := by decide
theorem cert_e2422374014430 : check e2422374014430 [[],[]] .three = true := by decide
def e2422374014446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e2422374014446 : Closed e2422374014446 ∧ code e2422374014446 = 11218467036654 := by decide
theorem cert_e2422374014446 : check e2422374014446 [[],[]] .three = true := by decide
def e2422374014454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 1) (.var 4)))) (.var 1)))))))
theorem wire_e2422374014454 : Closed e2422374014454 ∧ code e2422374014454 = 11218467036662 := by decide
theorem cert_e2422374014454 : check e2422374014454 [[],[]] .three = true := by decide
def e2422374014522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422374014522 : Closed e2422374014522 ∧ code e2422374014522 = 11218467036730 := by decide
theorem cert_e2422374014522 : check e2422374014522 [[],[]] .three = true := by decide
def e2422374014570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422374014570 : Closed e2422374014570 ∧ code e2422374014570 = 11218467036778 := by decide
theorem cert_e2422374014570 : check e2422374014570 [[],[]] .three = true := by decide
def e2422374014618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422374014618 : Closed e2422374014618 ∧ code e2422374014618 = 11218467036826 := by decide
theorem cert_e2422374014618 : check e2422374014618 [[],[]] .three = true := by decide
def e2422374014662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422374014662 : Closed e2422374014662 ∧ code e2422374014662 = 11218467036870 := by decide
theorem cert_e2422374014662 : check e2422374014662 [[],[]] .three = true := by decide
def e2422374014686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 1)))) (.var 3)))))))
theorem wire_e2422374014686 : Closed e2422374014686 ∧ code e2422374014686 = 11218467036894 := by decide
theorem cert_e2422374014686 : check e2422374014686 [[],[]] .three = true := by decide
def e2422374014702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 2)))) (.var 2)))))))
theorem wire_e2422374014702 : Closed e2422374014702 ∧ code e2422374014702 = 11218467036910 := by decide
theorem cert_e2422374014702 : check e2422374014702 [[],[]] .three = true := by decide
def e2422374014710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 3)))) (.var 1)))))))
theorem wire_e2422374014710 : Closed e2422374014710 ∧ code e2422374014710 = 11218467036918 := by decide
theorem cert_e2422374014710 : check e2422374014710 [[],[]] .three = true := by decide
def e2422374014714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 2) (.var 4)))) (.var 0)))))))
theorem wire_e2422374014714 : Closed e2422374014714 ∧ code e2422374014714 = 11218467036922 := by decide
theorem cert_e2422374014714 : check e2422374014714 [[],[]] .three = true := by decide
def e2422374014830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 3) (.var 1)))) (.var 2)))))))
theorem wire_e2422374014830 : Closed e2422374014830 ∧ code e2422374014830 = 11218467037038 := by decide
theorem cert_e2422374014830 : check e2422374014830 [[],[]] .three = true := by decide
def e2422374014838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 3) (.var 2)))) (.var 1)))))))
theorem wire_e2422374014838 : Closed e2422374014838 ∧ code e2422374014838 = 11218467037046 := by decide
theorem cert_e2422374014838 : check e2422374014838 [[],[]] .three = true := by decide
def e2422374014842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 3) (.var 3)))) (.var 0)))))))
theorem wire_e2422374014842 : Closed e2422374014842 ∧ code e2422374014842 = 11218467037050 := by decide
theorem cert_e2422374014842 : check e2422374014842 [[],[]] .three = true := by decide
def e2422374014902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 4) (.var 1)))) (.var 1)))))))
theorem wire_e2422374014902 : Closed e2422374014902 ∧ code e2422374014902 = 11218467037110 := by decide
theorem cert_e2422374014902 : check e2422374014902 [[],[]] .three = true := by decide
def e2422374014906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.app (.var 4) (.var 2)))) (.var 0)))))))
theorem wire_e2422374014906 : Closed e2422374014906 ∧ code e2422374014906 = 11218467037114 := by decide
theorem cert_e2422374014906 : check e2422374014906 [[],[]] .three = true := by decide
def e2422374016430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422374016430 : Closed e2422374016430 ∧ code e2422374016430 = 11218467038638 := by decide
theorem cert_e2422374016430 : check e2422374016430 [[],[]] .three = true := by decide
def e2422374016438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2422374016438 : Closed e2422374016438 ∧ code e2422374016438 = 11218467038646 := by decide
theorem cert_e2422374016438 : check e2422374016438 [[],[]] .three = true := by decide
def e2422374016442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422374016442 : Closed e2422374016442 ∧ code e2422374016442 = 11218467038650 := by decide
theorem cert_e2422374016442 : check e2422374016442 [[],[]] .three = true := by decide
def e2422374016470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2422374016470 : Closed e2422374016470 ∧ code e2422374016470 = 11218467038678 := by decide
theorem cert_e2422374016470 : check e2422374016470 [[],[]] .three = true := by decide
def e2422374016474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2422374016474 : Closed e2422374016474 ∧ code e2422374016474 = 11218467038682 := by decide
theorem cert_e2422374016474 : check e2422374016474 [[],[]] .three = true := by decide
def e2422374016490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422374016490 : Closed e2422374016490 ∧ code e2422374016490 = 11218467038698 := by decide
theorem cert_e2422374016490 : check e2422374016490 [[],[]] .three = true := by decide
def e2422374016622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374016622 : Closed e2422374016622 ∧ code e2422374016622 = 11218467038830 := by decide
theorem cert_e2422374016622 : check e2422374016622 [[],[]] .three = true := by decide
def e2422374016630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374016630 : Closed e2422374016630 ∧ code e2422374016630 = 11218467038838 := by decide
theorem cert_e2422374016630 : check e2422374016630 [[],[]] .three = true := by decide
def e2422374016634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374016634 : Closed e2422374016634 ∧ code e2422374016634 = 11218467038842 := by decide
theorem cert_e2422374016634 : check e2422374016634 [[],[]] .three = true := by decide
def e2422374016822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374016822 : Closed e2422374016822 ∧ code e2422374016822 = 11218467039030 := by decide
theorem cert_e2422374016822 : check e2422374016822 [[],[]] .three = true := by decide
def e2422374016826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374016826 : Closed e2422374016826 ∧ code e2422374016826 = 11218467039034 := by decide
theorem cert_e2422374016826 : check e2422374016826 [[],[]] .three = true := by decide
def e2422374016922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374016922 : Closed e2422374016922 ∧ code e2422374016922 = 11218467039130 := by decide
theorem cert_e2422374016922 : check e2422374016922 [[],[]] .three = true := by decide
def e2422374019310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374019310 : Closed e2422374019310 ∧ code e2422374019310 = 11218467041518 := by decide
theorem cert_e2422374019310 : check e2422374019310 [[],[]] .three = true := by decide
def e2422374019318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374019318 : Closed e2422374019318 ∧ code e2422374019318 = 11218467041526 := by decide
theorem cert_e2422374019318 : check e2422374019318 [[],[]] .three = true := by decide
def e2422374019798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422374019798 : Closed e2422374019798 ∧ code e2422374019798 = 11218467042006 := by decide
theorem cert_e2422374019798 : check e2422374019798 [[],[]] .three = true := by decide
def e2422374019802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422374019802 : Closed e2422374019802 ∧ code e2422374019802 = 11218467042010 := by decide
theorem cert_e2422374019802 : check e2422374019802 [[],[]] .three = true := by decide
def e2422374019818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422374019818 : Closed e2422374019818 ∧ code e2422374019818 = 11218467042026 := by decide
theorem cert_e2422374019818 : check e2422374019818 [[],[]] .three = true := by decide
def e2422374019870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422374019870 : Closed e2422374019870 ∧ code e2422374019870 = 11218467042078 := by decide
theorem cert_e2422374019870 : check e2422374019870 [[],[]] .three = true := by decide
def e2422374019894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374019894 : Closed e2422374019894 ∧ code e2422374019894 = 11218467042102 := by decide
theorem cert_e2422374019894 : check e2422374019894 [[],[]] .three = true := by decide
def e2422374019898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374019898 : Closed e2422374019898 ∧ code e2422374019898 = 11218467042106 := by decide
theorem cert_e2422374019898 : check e2422374019898 [[],[]] .three = true := by decide
def e2422374019982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422374019982 : Closed e2422374019982 ∧ code e2422374019982 = 11218467042190 := by decide
theorem cert_e2422374019982 : check e2422374019982 [[],[]] .three = true := by decide
def e2422374019994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374019994 : Closed e2422374019994 ∧ code e2422374019994 = 11218467042202 := by decide
theorem cert_e2422374019994 : check e2422374019994 [[],[]] .three = true := by decide
def e2422374020038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422374020038 : Closed e2422374020038 ∧ code e2422374020038 = 11218467042246 := by decide
theorem cert_e2422374020038 : check e2422374020038 [[],[]] .three = true := by decide
def e2422374020062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422374020062 : Closed e2422374020062 ∧ code e2422374020062 = 11218467042270 := by decide
theorem cert_e2422374020062 : check e2422374020062 [[],[]] .three = true := by decide
def e2422374020078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422374020078 : Closed e2422374020078 ∧ code e2422374020078 = 11218467042286 := by decide
theorem cert_e2422374020078 : check e2422374020078 [[],[]] .three = true := by decide
def e2422374021238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374021238 : Closed e2422374021238 ∧ code e2422374021238 = 11218467043446 := by decide
theorem cert_e2422374021238 : check e2422374021238 [[],[]] .three = true := by decide
def e2422374021482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422374021482 : Closed e2422374021482 ∧ code e2422374021482 = 11218467043690 := by decide
theorem cert_e2422374021482 : check e2422374021482 [[],[]] .three = true := by decide
def e2422374021518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422374021518 : Closed e2422374021518 ∧ code e2422374021518 = 11218467043726 := by decide
theorem cert_e2422374021518 : check e2422374021518 [[],[]] .three = true := by decide
def e2422374021530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374021530 : Closed e2422374021530 ∧ code e2422374021530 = 11218467043738 := by decide
theorem cert_e2422374021530 : check e2422374021530 [[],[]] .three = true := by decide
def e2422374021574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422374021574 : Closed e2422374021574 ∧ code e2422374021574 = 11218467043782 := by decide
theorem cert_e2422374021574 : check e2422374021574 [[],[]] .three = true := by decide
def e2422374021614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422374021614 : Closed e2422374021614 ∧ code e2422374021614 = 11218467043822 := by decide
theorem cert_e2422374021614 : check e2422374021614 [[],[]] .three = true := by decide
def e2422374022342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422374022342 : Closed e2422374022342 ∧ code e2422374022342 = 11218467044550 := by decide
theorem cert_e2422374022342 : check e2422374022342 [[],[]] .three = true := by decide
def e2422374022366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422374022366 : Closed e2422374022366 ∧ code e2422374022366 = 11218467044574 := by decide
theorem cert_e2422374022366 : check e2422374022366 [[],[]] .three = true := by decide
def e2422374022382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422374022382 : Closed e2422374022382 ∧ code e2422374022382 = 11218467044590 := by decide
theorem cert_e2422374022382 : check e2422374022382 [[],[]] .three = true := by decide
def e2422374022390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422374022390 : Closed e2422374022390 ∧ code e2422374022390 = 11218467044598 := by decide
theorem cert_e2422374022390 : check e2422374022390 [[],[]] .three = true := by decide
def e2422374022394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 3))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422374022394 : Closed e2422374022394 ∧ code e2422374022394 = 11218467044602 := by decide
theorem cert_e2422374022394 : check e2422374022394 [[],[]] .three = true := by decide
def e2422374022766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 4))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422374022766 : Closed e2422374022766 ∧ code e2422374022766 = 11218467044974 := by decide
theorem cert_e2422374022766 : check e2422374022766 [[],[]] .three = true := by decide
def e2422374022778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 4))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422374022778 : Closed e2422374022778 ∧ code e2422374022778 = 11218467044986 := by decide
theorem cert_e2422374022778 : check e2422374022778 [[],[]] .three = true := by decide
def e2422374029486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2)))))))
theorem wire_e2422374029486 : Closed e2422374029486 ∧ code e2422374029486 = 11218467051694 := by decide
theorem cert_e2422374029486 : check e2422374029486 [[],[]] .three = true := by decide
def e2422374029494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 1)))))))
theorem wire_e2422374029494 : Closed e2422374029494 ∧ code e2422374029494 = 11218467051702 := by decide
theorem cert_e2422374029494 : check e2422374029494 [[],[]] .three = true := by decide
def e2422374029498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0)))))))
theorem wire_e2422374029498 : Closed e2422374029498 ∧ code e2422374029498 = 11218467051706 := by decide
theorem cert_e2422374029498 : check e2422374029498 [[],[]] .three = true := by decide
def e2422374029526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 1)))))))
theorem wire_e2422374029526 : Closed e2422374029526 ∧ code e2422374029526 = 11218467051734 := by decide
theorem cert_e2422374029526 : check e2422374029526 [[],[]] .three = true := by decide
def e2422374029530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 0)))))))
theorem wire_e2422374029530 : Closed e2422374029530 ∧ code e2422374029530 = 11218467051738 := by decide
theorem cert_e2422374029530 : check e2422374029530 [[],[]] .three = true := by decide
def e2422374029546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 0)))))))
theorem wire_e2422374029546 : Closed e2422374029546 ∧ code e2422374029546 = 11218467051754 := by decide
theorem cert_e2422374029546 : check e2422374029546 [[],[]] .three = true := by decide
def e2422374029870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422374029870 : Closed e2422374029870 ∧ code e2422374029870 = 11218467052078 := by decide
theorem cert_e2422374029870 : check e2422374029870 [[],[]] .three = true := by decide
def e2422374029878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422374029878 : Closed e2422374029878 ∧ code e2422374029878 = 11218467052086 := by decide
theorem cert_e2422374029878 : check e2422374029878 [[],[]] .three = true := by decide
def e2422374029882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422374029882 : Closed e2422374029882 ∧ code e2422374029882 = 11218467052090 := by decide
theorem cert_e2422374029882 : check e2422374029882 [[],[]] .three = true := by decide
def e2422374029966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422374029966 : Closed e2422374029966 ∧ code e2422374029966 = 11218467052174 := by decide
theorem cert_e2422374029966 : check e2422374029966 [[],[]] .three = true := by decide
def e2422374030022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422374030022 : Closed e2422374030022 ∧ code e2422374030022 = 11218467052230 := by decide
theorem cert_e2422374030022 : check e2422374030022 [[],[]] .three = true := by decide
def e2422374030046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3)))))))
theorem wire_e2422374030046 : Closed e2422374030046 ∧ code e2422374030046 = 11218467052254 := by decide
theorem cert_e2422374030046 : check e2422374030046 [[],[]] .three = true := by decide
def e2422374030050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422374030050 : Closed e2422374030050 ∧ code e2422374030050 = 11218467052258 := by decide
theorem cert_e2422374030050 : check e2422374030050 [[],[]] .three = true := by decide
def e2422374030062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2)))))))
theorem wire_e2422374030062 : Closed e2422374030062 ∧ code e2422374030062 = 11218467052270 := by decide
theorem cert_e2422374030062 : check e2422374030062 [[],[]] .three = true := by decide
def e2422374030070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1)))))))
theorem wire_e2422374030070 : Closed e2422374030070 ∧ code e2422374030070 = 11218467052278 := by decide
theorem cert_e2422374030070 : check e2422374030070 [[],[]] .three = true := by decide
def e2422374030102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422374030102 : Closed e2422374030102 ∧ code e2422374030102 = 11218467052310 := by decide
theorem cert_e2422374030102 : check e2422374030102 [[],[]] .three = true := by decide
def e2422374030106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422374030106 : Closed e2422374030106 ∧ code e2422374030106 = 11218467052314 := by decide
theorem cert_e2422374030106 : check e2422374030106 [[],[]] .three = true := by decide
def e2422374030150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422374030150 : Closed e2422374030150 ∧ code e2422374030150 = 11218467052358 := by decide
theorem cert_e2422374030150 : check e2422374030150 [[],[]] .three = true := by decide
def e2422374030174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3)))))))
theorem wire_e2422374030174 : Closed e2422374030174 ∧ code e2422374030174 = 11218467052382 := by decide
theorem cert_e2422374030174 : check e2422374030174 [[],[]] .three = true := by decide
def e2422374030178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422374030178 : Closed e2422374030178 ∧ code e2422374030178 = 11218467052386 := by decide
theorem cert_e2422374030178 : check e2422374030178 [[],[]] .three = true := by decide
def e2422374030190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)))))))
theorem wire_e2422374030190 : Closed e2422374030190 ∧ code e2422374030190 = 11218467052398 := by decide
theorem cert_e2422374030190 : check e2422374030190 [[],[]] .three = true := by decide
def e2422374030198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)))))))
theorem wire_e2422374030198 : Closed e2422374030198 ∧ code e2422374030198 = 11218467052406 := by decide
theorem cert_e2422374030198 : check e2422374030198 [[],[]] .three = true := by decide
def e2422374030202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0)))))))
theorem wire_e2422374030202 : Closed e2422374030202 ∧ code e2422374030202 = 11218467052410 := by decide
theorem cert_e2422374030202 : check e2422374030202 [[],[]] .three = true := by decide
def e2422374030218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422374030218 : Closed e2422374030218 ∧ code e2422374030218 = 11218467052426 := by decide
theorem cert_e2422374030218 : check e2422374030218 [[],[]] .three = true := by decide
def e2422374030242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422374030242 : Closed e2422374030242 ∧ code e2422374030242 = 11218467052450 := by decide
theorem cert_e2422374030242 : check e2422374030242 [[],[]] .three = true := by decide
def e2422374030254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2)))))))
theorem wire_e2422374030254 : Closed e2422374030254 ∧ code e2422374030254 = 11218467052462 := by decide
theorem cert_e2422374030254 : check e2422374030254 [[],[]] .three = true := by decide
def e2422374030262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)))))))
theorem wire_e2422374030262 : Closed e2422374030262 ∧ code e2422374030262 = 11218467052470 := by decide
theorem cert_e2422374030262 : check e2422374030262 [[],[]] .three = true := by decide
def e2422374030266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0)))))))
theorem wire_e2422374030266 : Closed e2422374030266 ∧ code e2422374030266 = 11218467052474 := by decide
theorem cert_e2422374030266 : check e2422374030266 [[],[]] .three = true := by decide
def e2422374030294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1)))))))
theorem wire_e2422374030294 : Closed e2422374030294 ∧ code e2422374030294 = 11218467052502 := by decide
theorem cert_e2422374030294 : check e2422374030294 [[],[]] .three = true := by decide
def e2422374030298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0)))))))
theorem wire_e2422374030298 : Closed e2422374030298 ∧ code e2422374030298 = 11218467052506 := by decide
theorem cert_e2422374030298 : check e2422374030298 [[],[]] .three = true := by decide
def e2422374030422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 1)))))))
theorem wire_e2422374030422 : Closed e2422374030422 ∧ code e2422374030422 = 11218467052630 := by decide
theorem cert_e2422374030422 : check e2422374030422 [[],[]] .three = true := by decide
def e2422374030426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 0)))))))
theorem wire_e2422374030426 : Closed e2422374030426 ∧ code e2422374030426 = 11218467052634 := by decide
theorem cert_e2422374030426 : check e2422374030426 [[],[]] .three = true := by decide
def e2422374030442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 0)))))))
theorem wire_e2422374030442 : Closed e2422374030442 ∧ code e2422374030442 = 11218467052650 := by decide
theorem cert_e2422374030442 : check e2422374030442 [[],[]] .three = true := by decide
def e2422374030614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422374030614 : Closed e2422374030614 ∧ code e2422374030614 = 11218467052822 := by decide
theorem cert_e2422374030614 : check e2422374030614 [[],[]] .three = true := by decide
def e2422374030618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422374030618 : Closed e2422374030618 ∧ code e2422374030618 = 11218467052826 := by decide
theorem cert_e2422374030618 : check e2422374030618 [[],[]] .three = true := by decide
def e2422374030662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422374030662 : Closed e2422374030662 ∧ code e2422374030662 = 11218467052870 := by decide
theorem cert_e2422374030662 : check e2422374030662 [[],[]] .three = true := by decide
def e2422374030686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3)))))))
theorem wire_e2422374030686 : Closed e2422374030686 ∧ code e2422374030686 = 11218467052894 := by decide
theorem cert_e2422374030686 : check e2422374030686 [[],[]] .three = true := by decide
def e2422374030690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422374030690 : Closed e2422374030690 ∧ code e2422374030690 = 11218467052898 := by decide
theorem cert_e2422374030690 : check e2422374030690 [[],[]] .three = true := by decide
def e2422374030702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e2422374030702 : Closed e2422374030702 ∧ code e2422374030702 = 11218467052910 := by decide
theorem cert_e2422374030702 : check e2422374030702 [[],[]] .three = true := by decide
def e2422374030710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e2422374030710 : Closed e2422374030710 ∧ code e2422374030710 = 11218467052918 := by decide
theorem cert_e2422374030710 : check e2422374030710 [[],[]] .three = true := by decide
def e2422374030714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0)))))))
theorem wire_e2422374030714 : Closed e2422374030714 ∧ code e2422374030714 = 11218467052922 := by decide
theorem cert_e2422374030714 : check e2422374030714 [[],[]] .three = true := by decide
def e2422374030730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422374030730 : Closed e2422374030730 ∧ code e2422374030730 = 11218467052938 := by decide
theorem cert_e2422374030730 : check e2422374030730 [[],[]] .three = true := by decide
def e2422374030754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422374030754 : Closed e2422374030754 ∧ code e2422374030754 = 11218467052962 := by decide
theorem cert_e2422374030754 : check e2422374030754 [[],[]] .three = true := by decide
def e2422374030766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e2422374030766 : Closed e2422374030766 ∧ code e2422374030766 = 11218467052974 := by decide
theorem cert_e2422374030766 : check e2422374030766 [[],[]] .three = true := by decide
def e2422374030778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e2422374030778 : Closed e2422374030778 ∧ code e2422374030778 = 11218467052986 := by decide
theorem cert_e2422374030778 : check e2422374030778 [[],[]] .three = true := by decide
def e2422374030806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e2422374030806 : Closed e2422374030806 ∧ code e2422374030806 = 11218467053014 := by decide
theorem cert_e2422374030806 : check e2422374030806 [[],[]] .three = true := by decide
def e2422374030810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e2422374030810 : Closed e2422374030810 ∧ code e2422374030810 = 11218467053018 := by decide
theorem cert_e2422374030810 : check e2422374030810 [[],[]] .three = true := by decide
def e2422374030826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0)))))))
theorem wire_e2422374030826 : Closed e2422374030826 ∧ code e2422374030826 = 11218467053034 := by decide
theorem cert_e2422374030826 : check e2422374030826 [[],[]] .three = true := by decide
def e2422374030890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0)))))))
theorem wire_e2422374030890 : Closed e2422374030890 ∧ code e2422374030890 = 11218467053098 := by decide
theorem cert_e2422374030890 : check e2422374030890 [[],[]] .three = true := by decide
def e2422374030986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422374030986 : Closed e2422374030986 ∧ code e2422374030986 = 11218467053194 := by decide
theorem cert_e2422374030986 : check e2422374030986 [[],[]] .three = true := by decide
def e2422374031010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422374031010 : Closed e2422374031010 ∧ code e2422374031010 = 11218467053218 := by decide
theorem cert_e2422374031010 : check e2422374031010 [[],[]] .three = true := by decide
def e2422374031022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422374031022 : Closed e2422374031022 ∧ code e2422374031022 = 11218467053230 := by decide
theorem cert_e2422374031022 : check e2422374031022 [[],[]] .three = true := by decide
def e2422374031030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)))))))
theorem wire_e2422374031030 : Closed e2422374031030 ∧ code e2422374031030 = 11218467053238 := by decide
theorem cert_e2422374031030 : check e2422374031030 [[],[]] .three = true := by decide
def e2422374031034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422374031034 : Closed e2422374031034 ∧ code e2422374031034 = 11218467053242 := by decide
theorem cert_e2422374031034 : check e2422374031034 [[],[]] .three = true := by decide
def e2422374031062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)))))))
theorem wire_e2422374031062 : Closed e2422374031062 ∧ code e2422374031062 = 11218467053270 := by decide
theorem cert_e2422374031062 : check e2422374031062 [[],[]] .three = true := by decide
def e2422374031066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)))))))
theorem wire_e2422374031066 : Closed e2422374031066 ∧ code e2422374031066 = 11218467053274 := by decide
theorem cert_e2422374031066 : check e2422374031066 [[],[]] .three = true := by decide
def e2422374031082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422374031082 : Closed e2422374031082 ∧ code e2422374031082 = 11218467053290 := by decide
theorem cert_e2422374031082 : check e2422374031082 [[],[]] .three = true := by decide
def e2422374031190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2422374031190 : Closed e2422374031190 ∧ code e2422374031190 = 11218467053398 := by decide
theorem cert_e2422374031190 : check e2422374031190 [[],[]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422374012598
#print axioms Blc.Floor43.cert_e2422374012602
#print axioms Blc.Floor43.cert_e2422374013550
#print axioms Blc.Floor43.cert_e2422374013562
