import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701156400250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701156400250 : Closed e701156400250 ∧ code e701156400250 = 9497249422458 := by decide
theorem cert_e701156400250 : check e701156400250 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156400582 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701156400582 : Closed e701156400582 ∧ code e701156400582 = 9497249422790 := by decide
theorem cert_e701156400582 : check e701156400582 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156400698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156400698 : Closed e701156400698 ∧ code e701156400698 = 9497249422906 := by decide
theorem cert_e701156400698 : check e701156400698 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156400746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156400746 : Closed e701156400746 ∧ code e701156400746 = 9497249422954 := by decide
theorem cert_e701156400746 : check e701156400746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156400794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156400794 : Closed e701156400794 ∧ code e701156400794 = 9497249423002 := by decide
theorem cert_e701156400794 : check e701156400794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156400838 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156400838 : Closed e701156400838 ∧ code e701156400838 = 9497249423046 := by decide
theorem cert_e701156400838 : check e701156400838 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156410298 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701156410298 : Closed e701156410298 ∧ code e701156410298 = 9497249432506 := by decide
theorem cert_e701156410298 : check e701156410298 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156410330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701156410330 : Closed e701156410330 ∧ code e701156410330 = 9497249432538 := by decide
theorem cert_e701156410330 : check e701156410330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156412250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701156412250 : Closed e701156412250 ∧ code e701156412250 = 9497249434458 := by decide
theorem cert_e701156412250 : check e701156412250 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156412266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701156412266 : Closed e701156412266 ∧ code e701156412266 = 9497249434474 := by decide
theorem cert_e701156412266 : check e701156412266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156412330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156412330 : Closed e701156412330 ∧ code e701156412330 = 9497249434538 := by decide
theorem cert_e701156412330 : check e701156412330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156412634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701156412634 : Closed e701156412634 ∧ code e701156412634 = 9497249434842 := by decide
theorem cert_e701156412634 : check e701156412634 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156412650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701156412650 : Closed e701156412650 ∧ code e701156412650 = 9497249434858 := by decide
theorem cert_e701156412650 : check e701156412650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156412826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156412826 : Closed e701156412826 ∧ code e701156412826 = 9497249435034 := by decide
theorem cert_e701156412826 : check e701156412826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156412986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156412986 : Closed e701156412986 ∧ code e701156412986 = 9497249435194 := by decide
theorem cert_e701156412986 : check e701156412986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156413034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156413034 : Closed e701156413034 ∧ code e701156413034 = 9497249435242 := by decide
theorem cert_e701156413034 : check e701156413034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156413082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156413082 : Closed e701156413082 ∧ code e701156413082 = 9497249435290 := by decide
theorem cert_e701156413082 : check e701156413082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156413126 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156413126 : Closed e701156413126 ∧ code e701156413126 = 9497249435334 := by decide
theorem cert_e701156413126 : check e701156413126 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156433338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))) (.var 0)))
theorem wire_e701156433338 : Closed e701156433338 ∧ code e701156433338 = 9497249455546 := by decide
theorem cert_e701156433338 : check e701156433338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156433386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))) (.var 0)))
theorem wire_e701156433386 : Closed e701156433386 ∧ code e701156433386 = 9497249455594 := by decide
theorem cert_e701156433386 : check e701156433386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156433770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))) (.var 0)))
theorem wire_e701156433770 : Closed e701156433770 ∧ code e701156433770 = 9497249455978 := by decide
theorem cert_e701156433770 : check e701156433770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156438970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e701156438970 : Closed e701156438970 ∧ code e701156438970 = 9497249461178 := by decide
theorem cert_e701156438970 : check e701156438970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156439002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e701156439002 : Closed e701156439002 ∧ code e701156439002 = 9497249461210 := by decide
theorem cert_e701156439002 : check e701156439002 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156440506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e701156440506 : Closed e701156440506 ∧ code e701156440506 = 9497249462714 := by decide
theorem cert_e701156440506 : check e701156440506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156440554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e701156440554 : Closed e701156440554 ∧ code e701156440554 = 9497249462762 := by decide
theorem cert_e701156440554 : check e701156440554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156441306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156441306 : Closed e701156441306 ∧ code e701156441306 = 9497249463514 := by decide
theorem cert_e701156441306 : check e701156441306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156441322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156441322 : Closed e701156441322 ∧ code e701156441322 = 9497249463530 := by decide
theorem cert_e701156441322 : check e701156441322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156448954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e701156448954 : Closed e701156448954 ∧ code e701156448954 = 9497249471162 := by decide
theorem cert_e701156448954 : check e701156448954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156449002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156449002 : Closed e701156449002 ∧ code e701156449002 = 9497249471210 := by decide
theorem cert_e701156449002 : check e701156449002 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156449194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156449194 : Closed e701156449194 ∧ code e701156449194 = 9497249471402 := by decide
theorem cert_e701156449194 : check e701156449194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156449962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156449962 : Closed e701156449962 ∧ code e701156449962 = 9497249472170 := by decide
theorem cert_e701156449962 : check e701156449962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156451258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.var 0)))
theorem wire_e701156451258 : Closed e701156451258 ∧ code e701156451258 = 9497249473466 := by decide
theorem cert_e701156451258 : check e701156451258 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156451290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.var 0)))
theorem wire_e701156451290 : Closed e701156451290 ∧ code e701156451290 = 9497249473498 := by decide
theorem cert_e701156451290 : check e701156451290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156452026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))) (.var 0)))
theorem wire_e701156452026 : Closed e701156452026 ∧ code e701156452026 = 9497249474234 := by decide
theorem cert_e701156452026 : check e701156452026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156452074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e701156452074 : Closed e701156452074 ∧ code e701156452074 = 9497249474282 := by decide
theorem cert_e701156452074 : check e701156452074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156452266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))) (.var 0)))
theorem wire_e701156452266 : Closed e701156452266 ∧ code e701156452266 = 9497249474474 := by decide
theorem cert_e701156452266 : check e701156452266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156452794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e701156452794 : Closed e701156452794 ∧ code e701156452794 = 9497249475002 := by decide
theorem cert_e701156452794 : check e701156452794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156452842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e701156452842 : Closed e701156452842 ∧ code e701156452842 = 9497249475050 := by decide
theorem cert_e701156452842 : check e701156452842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156453274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156453274 : Closed e701156453274 ∧ code e701156453274 = 9497249475482 := by decide
theorem cert_e701156453274 : check e701156453274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156453498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.var 0)))
theorem wire_e701156453498 : Closed e701156453498 ∧ code e701156453498 = 9497249475706 := by decide
theorem cert_e701156453498 : check e701156453498 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156453830 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.var 1))))
theorem wire_e701156453830 : Closed e701156453830 ∧ code e701156453830 = 9497249476038 := by decide
theorem cert_e701156453830 : check e701156453830 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156453946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156453946 : Closed e701156453946 ∧ code e701156453946 = 9497249476154 := by decide
theorem cert_e701156453946 : check e701156453946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156453994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156453994 : Closed e701156453994 ∧ code e701156453994 = 9497249476202 := by decide
theorem cert_e701156453994 : check e701156453994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156454042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156454042 : Closed e701156454042 ∧ code e701156454042 = 9497249476250 := by decide
theorem cert_e701156454042 : check e701156454042 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156454086 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156454086 : Closed e701156454086 ∧ code e701156454086 = 9497249476294 := by decide
theorem cert_e701156454086 : check e701156454086 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156454842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.var 0)))
theorem wire_e701156454842 : Closed e701156454842 ∧ code e701156454842 = 9497249477050 := by decide
theorem cert_e701156454842 : check e701156454842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156454890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.var 0)))
theorem wire_e701156454890 : Closed e701156454890 ∧ code e701156454890 = 9497249477098 := by decide
theorem cert_e701156454890 : check e701156454890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156455546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.var 0)))
theorem wire_e701156455546 : Closed e701156455546 ∧ code e701156455546 = 9497249477754 := by decide
theorem cert_e701156455546 : check e701156455546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156455878 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.var 1))))
theorem wire_e701156455878 : Closed e701156455878 ∧ code e701156455878 = 9497249478086 := by decide
theorem cert_e701156455878 : check e701156455878 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156456218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e701156456218 : Closed e701156456218 ∧ code e701156456218 = 9497249478426 := by decide
theorem cert_e701156456218 : check e701156456218 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156456262 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e701156456262 : Closed e701156456262 ∧ code e701156456262 = 9497249478470 := by decide
theorem cert_e701156456262 : check e701156456262 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156456666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.var 0)))
theorem wire_e701156456666 : Closed e701156456666 ∧ code e701156456666 = 9497249478874 := by decide
theorem cert_e701156456666 : check e701156456666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156456682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e701156456682 : Closed e701156456682 ∧ code e701156456682 = 9497249478890 := by decide
theorem cert_e701156456682 : check e701156456682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156456874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))) (.var 0)))
theorem wire_e701156456874 : Closed e701156456874 ∧ code e701156456874 = 9497249479082 := by decide
theorem cert_e701156456874 : check e701156456874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156457018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156457018 : Closed e701156457018 ∧ code e701156457018 = 9497249479226 := by decide
theorem cert_e701156457018 : check e701156457018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156457066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156457066 : Closed e701156457066 ∧ code e701156457066 = 9497249479274 := by decide
theorem cert_e701156457066 : check e701156457066 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156457114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156457114 : Closed e701156457114 ∧ code e701156457114 = 9497249479322 := by decide
theorem cert_e701156457114 : check e701156457114 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156457158 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156457158 : Closed e701156457158 ∧ code e701156457158 = 9497249479366 := by decide
theorem cert_e701156457158 : check e701156457158 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156457242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e701156457242 : Closed e701156457242 ∧ code e701156457242 = 9497249479450 := by decide
theorem cert_e701156457242 : check e701156457242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156457286 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e701156457286 : Closed e701156457286 ∧ code e701156457286 = 9497249479494 := by decide
theorem cert_e701156457286 : check e701156457286 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156460410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))) (.var 0)))
theorem wire_e701156460410 : Closed e701156460410 ∧ code e701156460410 = 9497249482618 := by decide
theorem cert_e701156460410 : check e701156460410 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156460506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))) (.var 0)))
theorem wire_e701156460506 : Closed e701156460506 ∧ code e701156460506 = 9497249482714 := by decide
theorem cert_e701156460506 : check e701156460506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156464314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701156464314 : Closed e701156464314 ∧ code e701156464314 = 9497249486522 := by decide
theorem cert_e701156464314 : check e701156464314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156464362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701156464362 : Closed e701156464362 ∧ code e701156464362 = 9497249486570 := by decide
theorem cert_e701156464362 : check e701156464362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156464554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156464554 : Closed e701156464554 ∧ code e701156464554 = 9497249486762 := by decide
theorem cert_e701156464554 : check e701156464554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156465082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701156465082 : Closed e701156465082 ∧ code e701156465082 = 9497249487290 := by decide
theorem cert_e701156465082 : check e701156465082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156465130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701156465130 : Closed e701156465130 ∧ code e701156465130 = 9497249487338 := by decide
theorem cert_e701156465130 : check e701156465130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156465562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156465562 : Closed e701156465562 ∧ code e701156465562 = 9497249487770 := by decide
theorem cert_e701156465562 : check e701156465562 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156465786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701156465786 : Closed e701156465786 ∧ code e701156465786 = 9497249487994 := by decide
theorem cert_e701156465786 : check e701156465786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156466118 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701156466118 : Closed e701156466118 ∧ code e701156466118 = 9497249488326 := by decide
theorem cert_e701156466118 : check e701156466118 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156466234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156466234 : Closed e701156466234 ∧ code e701156466234 = 9497249488442 := by decide
theorem cert_e701156466234 : check e701156466234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156466282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156466282 : Closed e701156466282 ∧ code e701156466282 = 9497249488490 := by decide
theorem cert_e701156466282 : check e701156466282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156466330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156466330 : Closed e701156466330 ∧ code e701156466330 = 9497249488538 := by decide
theorem cert_e701156466330 : check e701156466330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156466374 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156466374 : Closed e701156466374 ∧ code e701156466374 = 9497249488582 := by decide
theorem cert_e701156466374 : check e701156466374 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156478074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.var 0)))
theorem wire_e701156478074 : Closed e701156478074 ∧ code e701156478074 = 9497249500282 := by decide
theorem cert_e701156478074 : check e701156478074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156478406 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.var 1))))
theorem wire_e701156478406 : Closed e701156478406 ∧ code e701156478406 = 9497249500614 := by decide
theorem cert_e701156478406 : check e701156478406 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156478746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701156478746 : Closed e701156478746 ∧ code e701156478746 = 9497249500954 := by decide
theorem cert_e701156478746 : check e701156478746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156478790 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701156478790 : Closed e701156478790 ∧ code e701156478790 = 9497249500998 := by decide
theorem cert_e701156478790 : check e701156478790 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156483546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e701156483546 : Closed e701156483546 ∧ code e701156483546 = 9497249505754 := by decide
theorem cert_e701156483546 : check e701156483546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156484522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156484522 : Closed e701156484522 ∧ code e701156484522 = 9497249506730 := by decide
theorem cert_e701156484522 : check e701156484522 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156484666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156484666 : Closed e701156484666 ∧ code e701156484666 = 9497249506874 := by decide
theorem cert_e701156484666 : check e701156484666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156484714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156484714 : Closed e701156484714 ∧ code e701156484714 = 9497249506922 := by decide
theorem cert_e701156484714 : check e701156484714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156484762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156484762 : Closed e701156484762 ∧ code e701156484762 = 9497249506970 := by decide
theorem cert_e701156484762 : check e701156484762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156484806 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156484806 : Closed e701156484806 ∧ code e701156484806 = 9497249507014 := by decide
theorem cert_e701156484806 : check e701156484806 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156484890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701156484890 : Closed e701156484890 ∧ code e701156484890 = 9497249507098 := by decide
theorem cert_e701156484890 : check e701156484890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156484934 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701156484934 : Closed e701156484934 ∧ code e701156484934 = 9497249507142 := by decide
theorem cert_e701156484934 : check e701156484934 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156495066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))) (.var 0)))
theorem wire_e701156495066 : Closed e701156495066 ∧ code e701156495066 = 9497249517274 := by decide
theorem cert_e701156495066 : check e701156495066 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156495082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e701156495082 : Closed e701156495082 ∧ code e701156495082 = 9497249517290 := by decide
theorem cert_e701156495082 : check e701156495082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156495210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))) (.var 0)))
theorem wire_e701156495210 : Closed e701156495210 ∧ code e701156495210 = 9497249517418 := by decide
theorem cert_e701156495210 : check e701156495210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156497882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))) (.var 0)))
theorem wire_e701156497882 : Closed e701156497882 ∧ code e701156497882 = 9497249520090 := by decide
theorem cert_e701156497882 : check e701156497882 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156498650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156498650 : Closed e701156498650 ∧ code e701156498650 = 9497249520858 := by decide
theorem cert_e701156498650 : check e701156498650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156498666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156498666 : Closed e701156498666 ∧ code e701156498666 = 9497249520874 := by decide
theorem cert_e701156498666 : check e701156498666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156502874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e701156502874 : Closed e701156502874 ∧ code e701156502874 = 9497249525082 := by decide
theorem cert_e701156502874 : check e701156502874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156502890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e701156502890 : Closed e701156502890 ∧ code e701156502890 = 9497249525098 := by decide
theorem cert_e701156502890 : check e701156502890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156502954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156502954 : Closed e701156502954 ∧ code e701156502954 = 9497249525162 := by decide
theorem cert_e701156502954 : check e701156502954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156503210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156503210 : Closed e701156503210 ∧ code e701156503210 = 9497249525418 := by decide
theorem cert_e701156503210 : check e701156503210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156504026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))) (.var 0)))
theorem wire_e701156504026 : Closed e701156504026 ∧ code e701156504026 = 9497249526234 := by decide
theorem cert_e701156504026 : check e701156504026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156504410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))) (.var 0)))
theorem wire_e701156504410 : Closed e701156504410 ∧ code e701156504410 = 9497249526618 := by decide
theorem cert_e701156504410 : check e701156504410 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156504426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))) (.var 0)))
theorem wire_e701156504426 : Closed e701156504426 ∧ code e701156504426 = 9497249526634 := by decide
theorem cert_e701156504426 : check e701156504426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156504490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))) (.var 0)))
theorem wire_e701156504490 : Closed e701156504490 ∧ code e701156504490 = 9497249526698 := by decide
theorem cert_e701156504490 : check e701156504490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156504794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156504794 : Closed e701156504794 ∧ code e701156504794 = 9497249527002 := by decide
theorem cert_e701156504794 : check e701156504794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156504810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156504810 : Closed e701156504810 ∧ code e701156504810 = 9497249527018 := by decide
theorem cert_e701156504810 : check e701156504810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156504986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156504986 : Closed e701156504986 ∧ code e701156504986 = 9497249527194 := by decide
theorem cert_e701156504986 : check e701156504986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156505146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156505146 : Closed e701156505146 ∧ code e701156505146 = 9497249527354 := by decide
theorem cert_e701156505146 : check e701156505146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156505194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156505194 : Closed e701156505194 ∧ code e701156505194 = 9497249527402 := by decide
theorem cert_e701156505194 : check e701156505194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156505242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156505242 : Closed e701156505242 ∧ code e701156505242 = 9497249527450 := by decide
theorem cert_e701156505242 : check e701156505242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156505286 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156505286 : Closed e701156505286 ∧ code e701156505286 = 9497249527494 := by decide
theorem cert_e701156505286 : check e701156505286 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156505818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))) (.var 0)))
theorem wire_e701156505818 : Closed e701156505818 ∧ code e701156505818 = 9497249528026 := by decide
theorem cert_e701156505818 : check e701156505818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156505834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e701156505834 : Closed e701156505834 ∧ code e701156505834 = 9497249528042 := by decide
theorem cert_e701156505834 : check e701156505834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156506026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))) (.var 0)))
theorem wire_e701156506026 : Closed e701156506026 ∧ code e701156506026 = 9497249528234 := by decide
theorem cert_e701156506026 : check e701156506026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156506170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156506170 : Closed e701156506170 ∧ code e701156506170 = 9497249528378 := by decide
theorem cert_e701156506170 : check e701156506170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156506218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156506218 : Closed e701156506218 ∧ code e701156506218 = 9497249528426 := by decide
theorem cert_e701156506218 : check e701156506218 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156506266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156506266 : Closed e701156506266 ∧ code e701156506266 = 9497249528474 := by decide
theorem cert_e701156506266 : check e701156506266 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156506310 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156506310 : Closed e701156506310 ∧ code e701156506310 = 9497249528518 := by decide
theorem cert_e701156506310 : check e701156506310 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156506394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))) (.var 0)))
theorem wire_e701156506394 : Closed e701156506394 ∧ code e701156506394 = 9497249528602 := by decide
theorem cert_e701156506394 : check e701156506394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156506438 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.var 1))))
theorem wire_e701156506438 : Closed e701156506438 ∧ code e701156506438 = 9497249528646 := by decide
theorem cert_e701156506438 : check e701156506438 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156508602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701156508602 : Closed e701156508602 ∧ code e701156508602 = 9497249530810 := by decide
theorem cert_e701156508602 : check e701156508602 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156508634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701156508634 : Closed e701156508634 ∧ code e701156508634 = 9497249530842 := by decide
theorem cert_e701156508634 : check e701156508634 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156510554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701156510554 : Closed e701156510554 ∧ code e701156510554 = 9497249532762 := by decide
theorem cert_e701156510554 : check e701156510554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156510570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701156510570 : Closed e701156510570 ∧ code e701156510570 = 9497249532778 := by decide
theorem cert_e701156510570 : check e701156510570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156510634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156510634 : Closed e701156510634 ∧ code e701156510634 = 9497249532842 := by decide
theorem cert_e701156510634 : check e701156510634 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156510938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701156510938 : Closed e701156510938 ∧ code e701156510938 = 9497249533146 := by decide
theorem cert_e701156510938 : check e701156510938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156510954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701156510954 : Closed e701156510954 ∧ code e701156510954 = 9497249533162 := by decide
theorem cert_e701156510954 : check e701156510954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156511130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156511130 : Closed e701156511130 ∧ code e701156511130 = 9497249533338 := by decide
theorem cert_e701156511130 : check e701156511130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156511290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156511290 : Closed e701156511290 ∧ code e701156511290 = 9497249533498 := by decide
theorem cert_e701156511290 : check e701156511290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156511338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156511338 : Closed e701156511338 ∧ code e701156511338 = 9497249533546 := by decide
theorem cert_e701156511338 : check e701156511338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156511386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156511386 : Closed e701156511386 ∧ code e701156511386 = 9497249533594 := by decide
theorem cert_e701156511386 : check e701156511386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156511430 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156511430 : Closed e701156511430 ∧ code e701156511430 = 9497249533638 := by decide
theorem cert_e701156511430 : check e701156511430 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156516314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e701156516314 : Closed e701156516314 ∧ code e701156516314 = 9497249538522 := by decide
theorem cert_e701156516314 : check e701156516314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156517290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156517290 : Closed e701156517290 ∧ code e701156517290 = 9497249539498 := by decide
theorem cert_e701156517290 : check e701156517290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156517434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))) (.var 0)))
theorem wire_e701156517434 : Closed e701156517434 ∧ code e701156517434 = 9497249539642 := by decide
theorem cert_e701156517434 : check e701156517434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156517482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701156517482 : Closed e701156517482 ∧ code e701156517482 = 9497249539690 := by decide
theorem cert_e701156517482 : check e701156517482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156517530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156517530 : Closed e701156517530 ∧ code e701156517530 = 9497249539738 := by decide
theorem cert_e701156517530 : check e701156517530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156517574 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))) (.lam (.var 1))))
theorem wire_e701156517574 : Closed e701156517574 ∧ code e701156517574 = 9497249539782 := by decide
theorem cert_e701156517574 : check e701156517574 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156517658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))) (.var 0)))
theorem wire_e701156517658 : Closed e701156517658 ∧ code e701156517658 = 9497249539866 := by decide
theorem cert_e701156517658 : check e701156517658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156517702 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))) (.lam (.var 1))))
theorem wire_e701156517702 : Closed e701156517702 ∧ code e701156517702 = 9497249539910 := by decide
theorem cert_e701156517702 : check e701156517702 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156568506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.var 0)))
theorem wire_e701156568506 : Closed e701156568506 ∧ code e701156568506 = 9497249590714 := by decide
theorem cert_e701156568506 : check e701156568506 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156568538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.var 0)))
theorem wire_e701156568538 : Closed e701156568538 ∧ code e701156568538 = 9497249590746 := by decide
theorem cert_e701156568538 : check e701156568538 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156568762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.var 0)))
theorem wire_e701156568762 : Closed e701156568762 ∧ code e701156568762 = 9497249590970 := by decide
theorem cert_e701156568762 : check e701156568762 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156568810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.var 0)))
theorem wire_e701156568810 : Closed e701156568810 ∧ code e701156568810 = 9497249591018 := by decide
theorem cert_e701156568810 : check e701156568810 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156568922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.var 0)))
theorem wire_e701156568922 : Closed e701156568922 ∧ code e701156568922 = 9497249591130 := by decide
theorem cert_e701156568922 : check e701156568922 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156568938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.var 0)))
theorem wire_e701156568938 : Closed e701156568938 ∧ code e701156568938 = 9497249591146 := by decide
theorem cert_e701156568938 : check e701156568938 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156570042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.var 0)))
theorem wire_e701156570042 : Closed e701156570042 ∧ code e701156570042 = 9497249592250 := by decide
theorem cert_e701156570042 : check e701156570042 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156570074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.var 0)))
theorem wire_e701156570074 : Closed e701156570074 ∧ code e701156570074 = 9497249592282 := by decide
theorem cert_e701156570074 : check e701156570074 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156571578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.var 0)))
theorem wire_e701156571578 : Closed e701156571578 ∧ code e701156571578 = 9497249593786 := by decide
theorem cert_e701156571578 : check e701156571578 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156571626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.var 0)))
theorem wire_e701156571626 : Closed e701156571626 ∧ code e701156571626 = 9497249593834 := by decide
theorem cert_e701156571626 : check e701156571626 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156572378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.var 0)))
theorem wire_e701156572378 : Closed e701156572378 ∧ code e701156572378 = 9497249594586 := by decide
theorem cert_e701156572378 : check e701156572378 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156572394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.var 0)))
theorem wire_e701156572394 : Closed e701156572394 ∧ code e701156572394 = 9497249594602 := by decide
theorem cert_e701156572394 : check e701156572394 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701156734394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701156734394 : Closed e701156734394 ∧ code e701156734394 = 9497249756602 := by decide
theorem cert_e701156734394 : check e701156734394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156734426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701156734426 : Closed e701156734426 ∧ code e701156734426 = 9497249756634 := by decide
theorem cert_e701156734426 : check e701156734426 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156734650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701156734650 : Closed e701156734650 ∧ code e701156734650 = 9497249756858 := by decide
theorem cert_e701156734650 : check e701156734650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156734698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701156734698 : Closed e701156734698 ∧ code e701156734698 = 9497249756906 := by decide
theorem cert_e701156734698 : check e701156734698 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156734810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701156734810 : Closed e701156734810 ∧ code e701156734810 = 9497249757018 := by decide
theorem cert_e701156734810 : check e701156734810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156734826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701156734826 : Closed e701156734826 ∧ code e701156734826 = 9497249757034 := by decide
theorem cert_e701156734826 : check e701156734826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156735674 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701156735674 : Closed e701156735674 ∧ code e701156735674 = 9497249757882 := by decide
theorem cert_e701156735674 : check e701156735674 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156735722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701156735722 : Closed e701156735722 ∧ code e701156735722 = 9497249757930 := by decide
theorem cert_e701156735722 : check e701156735722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156735914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156735914 : Closed e701156735914 ∧ code e701156735914 = 9497249758122 := by decide
theorem cert_e701156735914 : check e701156735914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156736346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701156736346 : Closed e701156736346 ∧ code e701156736346 = 9497249758554 := by decide
theorem cert_e701156736346 : check e701156736346 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156736362 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701156736362 : Closed e701156736362 ∧ code e701156736362 = 9497249758570 := by decide
theorem cert_e701156736362 : check e701156736362 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156736426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156736426 : Closed e701156736426 ∧ code e701156736426 = 9497249758634 := by decide
theorem cert_e701156736426 : check e701156736426 [[.under,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor43
