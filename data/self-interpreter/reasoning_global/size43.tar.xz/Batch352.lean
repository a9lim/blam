import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419143331054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143331054 : Closed e2419143331054 ∧ code e2419143331054 = 11215236353262 := by decide
theorem cert_e2419143331054 : check e2419143331054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2419143331062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143331062 : Closed e2419143331062 ∧ code e2419143331062 = 11215236353270 := by decide
theorem cert_e2419143331062 : check e2419143331062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2419143331342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143331342 : Closed e2419143331342 ∧ code e2419143331342 = 11215236353550 := by decide
theorem cert_e2419143331342 : check e2419143331342 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143331354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143331354 : Closed e2419143331354 ∧ code e2419143331354 = 11215236353562 := by decide
theorem cert_e2419143331354 : check e2419143331354 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143331426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143331426 : Closed e2419143331426 ∧ code e2419143331426 = 11215236353634 := by decide
theorem cert_e2419143331426 : check e2419143331426 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143331438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143331438 : Closed e2419143331438 ∧ code e2419143331438 = 11215236353646 := by decide
theorem cert_e2419143331438 : check e2419143331438 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143331446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143331446 : Closed e2419143331446 ∧ code e2419143331446 = 11215236353654 := by decide
theorem cert_e2419143331446 : check e2419143331446 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143331450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143331450 : Closed e2419143331450 ∧ code e2419143331450 = 11215236353658 := by decide
theorem cert_e2419143331450 : check e2419143331450 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2419143331638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143331638 : Closed e2419143331638 ∧ code e2419143331638 = 11215236353846 := by decide
def e2419143331642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143331642 : Closed e2419143331642 ∧ code e2419143331642 = 11215236353850 := by decide
theorem cert_e2419143331642 : check e2419143331642 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2419143347822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143347822 : Closed e2419143347822 ∧ code e2419143347822 = 11215236370030 := by decide
theorem cert_e2419143347822 : checkPay e2419143347822 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143347834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143347834 : Closed e2419143347834 ∧ code e2419143347834 = 11215236370042 := by decide
theorem cert_e2419143347834 : checkPay e2419143347834 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143348122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143348122 : Closed e2419143348122 ∧ code e2419143348122 = 11215236370330 := by decide
theorem cert_e2419143348122 : checkPay e2419143348122 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.under]] = true := by decide
def e2419143350894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143350894 : Closed e2419143350894 ∧ code e2419143350894 = 11215236373102 := by decide
theorem cert_e2419143350894 : checkPay e2419143350894 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143350906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143350906 : Closed e2419143350906 ∧ code e2419143350906 = 11215236373114 := by decide
theorem cert_e2419143350906 : checkPay e2419143350906 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143351790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2))))))
theorem wire_e2419143351790 : Closed e2419143351790 ∧ code e2419143351790 = 11215236373998 := by decide
theorem cert_e2419143351790 : checkPay e2419143351790 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.under,.left],[.under,.under,.under,.left,.left]] = true := by decide
def e2419143352174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2))))))
theorem wire_e2419143352174 : Closed e2419143352174 ∧ code e2419143352174 = 11215236374382 := by decide
theorem cert_e2419143352174 : checkPay e2419143352174 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] = true := by decide
def e2419143352186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0))))))
theorem wire_e2419143352186 : Closed e2419143352186 ∧ code e2419143352186 = 11215236374394 := by decide
theorem cert_e2419143352186 : checkPay e2419143352186 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2419143353774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2419143353774 : Closed e2419143353774 ∧ code e2419143353774 = 11215236375982 := by decide
theorem cert_e2419143353774 : checkPay e2419143353774 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143353786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2419143353786 : Closed e2419143353786 ∧ code e2419143353786 = 11215236375994 := by decide
theorem cert_e2419143353786 : checkPay e2419143353786 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143353834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2419143353834 : Closed e2419143353834 ∧ code e2419143353834 = 11215236376042 := by decide
theorem cert_e2419143353834 : checkPay e2419143353834 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143353966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143353966 : Closed e2419143353966 ∧ code e2419143353966 = 11215236376174 := by decide
theorem cert_e2419143353966 : checkPay e2419143353966 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143353978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143353978 : Closed e2419143353978 ∧ code e2419143353978 = 11215236376186 := by decide
theorem cert_e2419143353978 : checkPay e2419143353978 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143354266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2419143354266 : Closed e2419143354266 ∧ code e2419143354266 = 11215236376474 := by decide
theorem cert_e2419143354266 : checkPay e2419143354266 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143357214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2419143357214 : Closed e2419143357214 ∧ code e2419143357214 = 11215236379422 := by decide
theorem cert_e2419143357214 : checkPay e2419143357214 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143357382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2419143357382 : Closed e2419143357382 ∧ code e2419143357382 = 11215236379590 := by decide
theorem cert_e2419143357382 : checkPay e2419143357382 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143359686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2419143359686 : Closed e2419143359686 ∧ code e2419143359686 = 11215236381894 := by decide
theorem cert_e2419143359686 : checkPay e2419143359686 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e2419143366830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2419143366830 : Closed e2419143366830 ∧ code e2419143366830 = 11215236389038 := by decide
theorem cert_e2419143366830 : checkPay e2419143366830 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143366842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2419143366842 : Closed e2419143366842 ∧ code e2419143366842 = 11215236389050 := by decide
theorem cert_e2419143366842 : checkPay e2419143366842 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2419143367214 : Closed e2419143367214 ∧ code e2419143367214 = 11215236389422 := by decide
theorem cert_e2419143367214 : checkPay e2419143367214 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2419143367394 : Closed e2419143367394 ∧ code e2419143367394 = 11215236389602 := by decide
theorem cert_e2419143367394 : checkPay e2419143367394 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2419143367406 : Closed e2419143367406 ∧ code e2419143367406 = 11215236389614 := by decide
theorem cert_e2419143367406 : checkPay e2419143367406 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2419143367534 : Closed e2419143367534 ∧ code e2419143367534 = 11215236389742 := by decide
theorem cert_e2419143367534 : checkPay e2419143367534 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left]] = true := by decide
def e2419143367542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2419143367542 : Closed e2419143367542 ∧ code e2419143367542 = 11215236389750 := by decide
theorem cert_e2419143367542 : checkPay e2419143367542 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.right]] = true := by decide
def e2419143367562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143367562 : Closed e2419143367562 ∧ code e2419143367562 = 11215236389770 := by decide
theorem cert_e2419143367562 : checkPay e2419143367562 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143367586 : Closed e2419143367586 ∧ code e2419143367586 = 11215236389794 := by decide
theorem cert_e2419143367586 : checkPay e2419143367586 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2419143367598 : Closed e2419143367598 ∧ code e2419143367598 = 11215236389806 := by decide
theorem cert_e2419143367598 : checkPay e2419143367598 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2419143367606 : Closed e2419143367606 ∧ code e2419143367606 = 11215236389814 := by decide
theorem cert_e2419143367606 : checkPay e2419143367606 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143367610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2419143367610 : Closed e2419143367610 ∧ code e2419143367610 = 11215236389818 := by decide
theorem cert_e2419143367610 : checkPay e2419143367610 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[]] = true := by decide
def e2419143368046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2419143368046 : Closed e2419143368046 ∧ code e2419143368046 = 11215236390254 := by decide
theorem cert_e2419143368046 : checkPay e2419143368046 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143368054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2419143368054 : Closed e2419143368054 ∧ code e2419143368054 = 11215236390262 := by decide
theorem cert_e2419143368054 : checkPay e2419143368054 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2419143368110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2419143368110 : Closed e2419143368110 ∧ code e2419143368110 = 11215236390318 := by decide
theorem cert_e2419143368110 : checkPay e2419143368110 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143368122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2419143368122 : Closed e2419143368122 ∧ code e2419143368122 = 11215236390330 := by decide
theorem cert_e2419143368122 : checkPay e2419143368122 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2419143368150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2419143368150 : Closed e2419143368150 ∧ code e2419143368150 = 11215236390358 := by decide
theorem cert_e2419143368150 : checkPay e2419143368150 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.right]] = true := by decide
def e2419143368154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2419143368154 : Closed e2419143368154 ∧ code e2419143368154 = 11215236390362 := by decide
theorem cert_e2419143368154 : checkPay e2419143368154 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.right]] = true := by decide
def e2419143368234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2419143368234 : Closed e2419143368234 ∧ code e2419143368234 = 11215236390442 := by decide
theorem cert_e2419143368234 : checkPay e2419143368234 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143368330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2419143368330 : Closed e2419143368330 ∧ code e2419143368330 = 11215236390538 := by decide
theorem cert_e2419143368330 : checkPay e2419143368330 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] = true := by decide
def e2419143368354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2419143368354 : Closed e2419143368354 ∧ code e2419143368354 = 11215236390562 := by decide
theorem cert_e2419143368354 : checkPay e2419143368354 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143368366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2419143368366 : Closed e2419143368366 ∧ code e2419143368366 = 11215236390574 := by decide
theorem cert_e2419143368366 : checkPay e2419143368366 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143368374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2419143368374 : Closed e2419143368374 ∧ code e2419143368374 = 11215236390582 := by decide
theorem cert_e2419143368374 : checkPay e2419143368374 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] = true := by decide
def e2419143368378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2419143368378 : Closed e2419143368378 ∧ code e2419143368378 = 11215236390586 := by decide
theorem cert_e2419143368378 : checkPay e2419143368378 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2419143368406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2419143368406 : Closed e2419143368406 ∧ code e2419143368406 = 11215236390614 := by decide
theorem cert_e2419143368406 : checkPay e2419143368406 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left,.right,.left],[.left,.right],[.left,.right,.under,.left]] = true := by decide
def e2419143368410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2419143368410 : Closed e2419143368410 ∧ code e2419143368410 = 11215236390618 := by decide
theorem cert_e2419143368410 : checkPay e2419143368410 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left,.right,.left],[.left,.right]] = true := by decide
def e2419143368426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2419143368426 : Closed e2419143368426 ∧ code e2419143368426 = 11215236390634 := by decide
theorem cert_e2419143368426 : checkPay e2419143368426 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2419143368942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2419143368942 : Closed e2419143368942 ∧ code e2419143368942 = 11215236391150 := by decide
theorem cert_e2419143368942 : checkPay e2419143368942 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e2419143368954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2419143368954 : Closed e2419143368954 ∧ code e2419143368954 = 11215236391162 := by decide
theorem cert_e2419143368954 : checkPay e2419143368954 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[]] = true := by decide
def e2419143369134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))
theorem wire_e2419143369134 : Closed e2419143369134 ∧ code e2419143369134 = 11215236391342 := by decide
theorem cert_e2419143369134 : checkPay e2419143369134 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[]] = true := by decide
def e2419143369326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143369326 : Closed e2419143369326 ∧ code e2419143369326 = 11215236391534 := by decide
theorem cert_e2419143369326 : checkPay e2419143369326 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e2419143369338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143369338 : Closed e2419143369338 ∧ code e2419143369338 = 11215236391546 := by decide
theorem cert_e2419143369338 : checkPay e2419143369338 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e2419143369502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2419143369502 : Closed e2419143369502 ∧ code e2419143369502 = 11215236391710 := by decide
theorem cert_e2419143369502 : checkPay e2419143369502 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143369670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2419143369670 : Closed e2419143369670 ∧ code e2419143369670 = 11215236391878 := by decide
theorem cert_e2419143369670 : checkPay e2419143369670 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e2419143370286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2419143370286 : Closed e2419143370286 ∧ code e2419143370286 = 11215236392494 := by decide
theorem cert_e2419143370286 : checkPay e2419143370286 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143370466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2419143370466 : Closed e2419143370466 ∧ code e2419143370466 = 11215236392674 := by decide
theorem cert_e2419143370466 : checkPay e2419143370466 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143370478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2419143370478 : Closed e2419143370478 ∧ code e2419143370478 = 11215236392686 := by decide
theorem cert_e2419143370478 : checkPay e2419143370478 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] = true := by decide
def e2419143370606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2419143370606 : Closed e2419143370606 ∧ code e2419143370606 = 11215236392814 := by decide
theorem cert_e2419143370606 : checkPay e2419143370606 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143370614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2419143370614 : Closed e2419143370614 ∧ code e2419143370614 = 11215236392822 := by decide
theorem cert_e2419143370614 : checkPay e2419143370614 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.right]] = true := by decide
def e2419143370634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2419143370634 : Closed e2419143370634 ∧ code e2419143370634 = 11215236392842 := by decide
theorem cert_e2419143370634 : checkPay e2419143370634 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e2419143370658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2419143370658 : Closed e2419143370658 ∧ code e2419143370658 = 11215236392866 := by decide
theorem cert_e2419143370658 : checkPay e2419143370658 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143370670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2419143370670 : Closed e2419143370670 ∧ code e2419143370670 = 11215236392878 := by decide
theorem cert_e2419143370670 : checkPay e2419143370670 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] = true := by decide
def e2419143370678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2419143370678 : Closed e2419143370678 ∧ code e2419143370678 = 11215236392886 := by decide
theorem cert_e2419143370678 : checkPay e2419143370678 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.right],[.left,.left,.right,.under]] = true := by decide
def e2419143370682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2419143370682 : Closed e2419143370682 ∧ code e2419143370682 = 11215236392890 := by decide
theorem cert_e2419143370682 : checkPay e2419143370682 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[]] = true := by decide
def e2419143370814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2419143370814 : Closed e2419143370814 ∧ code e2419143370814 = 11215236393022 := by decide
theorem cert_e2419143370814 : checkPay e2419143370814 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143371234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2419143371234 : Closed e2419143371234 ∧ code e2419143371234 = 11215236393442 := by decide
theorem cert_e2419143371234 : checkPay e2419143371234 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143371246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2419143371246 : Closed e2419143371246 ∧ code e2419143371246 = 11215236393454 := by decide
theorem cert_e2419143371246 : checkPay e2419143371246 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143372014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143372014 : Closed e2419143372014 ∧ code e2419143372014 = 11215236394222 := by decide
theorem cert_e2419143372014 : checkPay e2419143372014 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143372022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143372022 : Closed e2419143372022 ∧ code e2419143372022 = 11215236394230 := by decide
theorem cert_e2419143372022 : checkPay e2419143372022 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143372302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2419143372302 : Closed e2419143372302 ∧ code e2419143372302 = 11215236394510 := by decide
theorem cert_e2419143372302 : checkPay e2419143372302 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e2419143372314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143372314 : Closed e2419143372314 ∧ code e2419143372314 = 11215236394522 := by decide
theorem cert_e2419143372314 : checkPay e2419143372314 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e2419143372386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143372386 : Closed e2419143372386 ∧ code e2419143372386 = 11215236394594 := by decide
theorem cert_e2419143372386 : checkPay e2419143372386 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e2419143372398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143372398 : Closed e2419143372398 ∧ code e2419143372398 = 11215236394606 := by decide
theorem cert_e2419143372398 : checkPay e2419143372398 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e2419143372406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143372406 : Closed e2419143372406 ∧ code e2419143372406 = 11215236394614 := by decide
theorem cert_e2419143372406 : checkPay e2419143372406 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left],[.under,.right],[.under,.right,.left],[.under,.right,.left,.left],[.under,.right,.left],[.under,.right],[.under,.right,.left],[.under,.right,.left,.left],[.under,.right,.left],[.under,.right]] = true := by decide
def e2419143372410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143372410 : Closed e2419143372410 ∧ code e2419143372410 = 11215236394618 := by decide
theorem cert_e2419143372410 : checkPay e2419143372410 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left],[.under,.right]] = true := by decide
def e2419143373678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2419143373678 : Closed e2419143373678 ∧ code e2419143373678 = 11215236395886 := by decide
theorem cert_e2419143373678 : checkPay e2419143373678 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2419143373686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2419143373686 : Closed e2419143373686 ∧ code e2419143373686 = 11215236395894 := by decide
theorem cert_e2419143373686 : checkPay e2419143373686 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.left,.left],[.right,.left],[.right],[.right,.left],[.right],[.right],[.right,.under],[.right,.under,.left],[.right,.under],[.right,.under,.under,.left],[.right,.under,.under,.left,.left,.left]] = true := by decide
def e2419143373742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2419143373742 : Closed e2419143373742 ∧ code e2419143373742 = 11215236395950 := by decide
theorem cert_e2419143373742 : checkPay e2419143373742 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143373754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2419143373754 : Closed e2419143373754 ∧ code e2419143373754 = 11215236395962 := by decide
theorem cert_e2419143373754 : checkPay e2419143373754 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right,.right]] = true := by decide
def e2419143373782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2419143373782 : Closed e2419143373782 ∧ code e2419143373782 = 11215236395990 := by decide
theorem cert_e2419143373782 : checkPay e2419143373782 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left,.left,.left,.left],[.right,.under,.left,.left,.left,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left,.left,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left,.left],[.right,.under,.left,.left]] = true := by decide
def e2419143373786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2419143373786 : Closed e2419143373786 ∧ code e2419143373786 = 11215236395994 := by decide
theorem cert_e2419143373786 : checkPay e2419143373786 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.left,.right,.right]] = true := by decide
def e2419143374062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2419143374062 : Closed e2419143374062 ∧ code e2419143374062 = 11215236396270 := by decide
theorem cert_e2419143374062 : checkPay e2419143374062 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143374070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2419143374070 : Closed e2419143374070 ∧ code e2419143374070 = 11215236396278 := by decide
theorem cert_e2419143374070 : checkPay e2419143374070 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143374446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143374446 : Closed e2419143374446 ∧ code e2419143374446 = 11215236396654 := by decide
theorem cert_e2419143374446 : checkPay e2419143374446 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143374458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143374458 : Closed e2419143374458 ∧ code e2419143374458 = 11215236396666 := by decide
theorem cert_e2419143374458 : checkPay e2419143374458 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143374646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143374646 : Closed e2419143374646 ∧ code e2419143374646 = 11215236396854 := by decide
theorem cert_e2419143374646 : checkPay e2419143374646 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2419143374650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143374650 : Closed e2419143374650 ∧ code e2419143374650 = 11215236396858 := by decide
theorem cert_e2419143374650 : checkPay e2419143374650 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2419143374906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2419143374906 : Closed e2419143374906 ∧ code e2419143374906 = 11215236397114 := by decide
theorem cert_e2419143374906 : checkPay e2419143374906 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under]] = true := by decide
def e2419143374954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2419143374954 : Closed e2419143374954 ∧ code e2419143374954 = 11215236397162 := by decide
theorem cert_e2419143374954 : checkPay e2419143374954 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2419143375002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143375002 : Closed e2419143375002 ∧ code e2419143375002 = 11215236397210 := by decide
theorem cert_e2419143375002 : checkPay e2419143375002 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.right]] = true := by decide
def e2419143375046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2419143375046 : Closed e2419143375046 ∧ code e2419143375046 = 11215236397254 := by decide
theorem cert_e2419143375046 : checkPay e2419143375046 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under],[.under,.left]] = true := by decide
def e2419143375242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2419143375242 : Closed e2419143375242 ∧ code e2419143375242 = 11215236397450 := by decide
theorem cert_e2419143375242 : checkPay e2419143375242 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] = true := by decide
def e2419143375266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2419143375266 : Closed e2419143375266 ∧ code e2419143375266 = 11215236397474 := by decide
theorem cert_e2419143375266 : checkPay e2419143375266 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] = true := by decide
def e2419143375278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2419143375278 : Closed e2419143375278 ∧ code e2419143375278 = 11215236397486 := by decide
theorem cert_e2419143375278 : checkPay e2419143375278 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] = true := by decide
def e2419143375286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2419143375286 : Closed e2419143375286 ∧ code e2419143375286 = 11215236397494 := by decide
theorem cert_e2419143375286 : checkPay e2419143375286 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.right],[.under,.left,.right,.under,.under,.left,.right,.left,.right],[.under,.right]] = true := by decide
def e2419143375290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2419143375290 : Closed e2419143375290 ∧ code e2419143375290 = 11215236397498 := by decide
theorem cert_e2419143375290 : checkPay e2419143375290 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.right],[.under,.left,.left,.left,.left,.left,.right,.left],[.under,.left,.left,.left,.left,.left,.right],[.under,.left,.left,.left,.left,.left,.right,.under,.left],[.under,.left,.left,.left,.left,.left,.right,.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.right,.under,.left,.left],[.under,.left,.left,.right,.right],[.under,.left,.left,.right,.right,.left],[.under,.left,.left,.right,.right],[.under,.left,.left,.right,.right,.under,.left],[.under,.left,.left,.right,.right,.under,.left,.left,.left],[.under,.left,.left,.right,.right,.under,.left,.left]] = true := by decide
def e2419143375318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2419143375318 : Closed e2419143375318 ∧ code e2419143375318 = 11215236397526 := by decide
theorem cert_e2419143375318 : checkPay e2419143375318 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e2419143375322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2419143375322 : Closed e2419143375322 ∧ code e2419143375322 = 11215236397530 := by decide
theorem cert_e2419143375322 : checkPay e2419143375322 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e2419143375338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2419143375338 : Closed e2419143375338 ∧ code e2419143375338 = 11215236397546 := by decide
theorem cert_e2419143375338 : checkPay e2419143375338 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2419143375374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2419143375374 : Closed e2419143375374 ∧ code e2419143375374 = 11215236397582 := by decide
theorem cert_e2419143375374 : checkPay e2419143375374 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e2419143375386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2419143375386 : Closed e2419143375386 ∧ code e2419143375386 = 11215236397594 := by decide
theorem cert_e2419143375386 : checkPay e2419143375386 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e2419143375458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2419143375458 : Closed e2419143375458 ∧ code e2419143375458 = 11215236397666 := by decide
theorem cert_e2419143375458 : checkPay e2419143375458 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e2419143375470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2419143375470 : Closed e2419143375470 ∧ code e2419143375470 = 11215236397678 := by decide
theorem cert_e2419143375470 : checkPay e2419143375470 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left]] = true := by decide
def e2419143375478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2419143375478 : Closed e2419143375478 ∧ code e2419143375478 = 11215236397686 := by decide
theorem cert_e2419143375478 : checkPay e2419143375478 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.right],[.under,.right,.left],[.under,.right,.left,.left],[.under,.right,.left],[.under,.right]] = true := by decide
def e2419143375482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2419143375482 : Closed e2419143375482 ∧ code e2419143375482 = 11215236397690 := by decide
theorem cert_e2419143375482 : checkPay e2419143375482 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.right]] = true := by decide
def e2419143375670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2419143375670 : Closed e2419143375670 ∧ code e2419143375670 = 11215236397878 := by decide
theorem cert_e2419143375670 : checkPay e2419143375670 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e2419143375674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2419143375674 : Closed e2419143375674 ∧ code e2419143375674 = 11215236397882 := by decide
theorem cert_e2419143375674 : checkPay e2419143375674 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right]] = true := by decide
def e2419143375770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2419143375770 : Closed e2419143375770 ∧ code e2419143375770 = 11215236397978 := by decide
theorem cert_e2419143375770 : checkPay e2419143375770 [[.left,.left],[.left,.left],[.left],[]] 1 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2419143378910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2419143378910 : Closed e2419143378910 ∧ code e2419143378910 = 11215236401118 := by decide
theorem cert_e2419143378910 : checkPay e2419143378910 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419143382574 : Closed e2419143382574 ∧ code e2419143382574 = 11215236404782 := by decide
theorem cert_e2419143382574 : checkPay e2419143382574 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419143382754 : Closed e2419143382754 ∧ code e2419143382754 = 11215236404962 := by decide
theorem cert_e2419143382754 : checkPay e2419143382754 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2419143382766 : Closed e2419143382766 ∧ code e2419143382766 = 11215236404974 := by decide
theorem cert_e2419143382766 : checkPay e2419143382766 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2419143382894 : Closed e2419143382894 ∧ code e2419143382894 = 11215236405102 := by decide
theorem cert_e2419143382894 : checkPay e2419143382894 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2419143382902 : Closed e2419143382902 ∧ code e2419143382902 = 11215236405110 := by decide
theorem cert_e2419143382902 : checkPay e2419143382902 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143382922 : Closed e2419143382922 ∧ code e2419143382922 = 11215236405130 := by decide
theorem cert_e2419143382922 : checkPay e2419143382922 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143382946 : Closed e2419143382946 ∧ code e2419143382946 = 11215236405154 := by decide
theorem cert_e2419143382946 : checkPay e2419143382946 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2419143382958 : Closed e2419143382958 ∧ code e2419143382958 = 11215236405166 := by decide
theorem cert_e2419143382958 : checkPay e2419143382958 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2419143382966 : Closed e2419143382966 ∧ code e2419143382966 = 11215236405174 := by decide
theorem cert_e2419143382966 : checkPay e2419143382966 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143382970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2419143382970 : Closed e2419143382970 ∧ code e2419143382970 = 11215236405178 := by decide
theorem cert_e2419143382970 : checkPay e2419143382970 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143383102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2419143383102 : Closed e2419143383102 ∧ code e2419143383102 = 11215236405310 := by decide
theorem cert_e2419143383102 : checkPay e2419143383102 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143383522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419143383522 : Closed e2419143383522 ∧ code e2419143383522 = 11215236405730 := by decide
theorem cert_e2419143383522 : checkPay e2419143383522 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143383534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2419143383534 : Closed e2419143383534 ∧ code e2419143383534 = 11215236405742 := by decide
theorem cert_e2419143383534 : checkPay e2419143383534 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143384302 : Closed e2419143384302 ∧ code e2419143384302 = 11215236406510 := by decide
theorem cert_e2419143384302 : checkPay e2419143384302 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143384310 : Closed e2419143384310 ∧ code e2419143384310 = 11215236406518 := by decide
theorem cert_e2419143384310 : checkPay e2419143384310 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143384590 : Closed e2419143384590 ∧ code e2419143384590 = 11215236406798 := by decide
theorem cert_e2419143384590 : checkPay e2419143384590 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419143384602 : Closed e2419143384602 ∧ code e2419143384602 = 11215236406810 := by decide
theorem cert_e2419143384602 : checkPay e2419143384602 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419143384674 : Closed e2419143384674 ∧ code e2419143384674 = 11215236406882 := by decide
theorem cert_e2419143384674 : checkPay e2419143384674 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143384686 : Closed e2419143384686 ∧ code e2419143384686 = 11215236406894 := by decide
theorem cert_e2419143384686 : checkPay e2419143384686 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2419143384694 : Closed e2419143384694 ∧ code e2419143384694 = 11215236406902 := by decide
theorem cert_e2419143384694 : checkPay e2419143384694 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143384698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143384698 : Closed e2419143384698 ∧ code e2419143384698 = 11215236406906 := by decide
theorem cert_e2419143384698 : checkPay e2419143384698 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419143396206 : Closed e2419143396206 ∧ code e2419143396206 = 11215236418414 := by decide
theorem cert_e2419143396206 : checkPay e2419143396206 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419143396214 : Closed e2419143396214 ∧ code e2419143396214 = 11215236418422 := by decide
theorem cert_e2419143396214 : checkPay e2419143396214 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419143396270 : Closed e2419143396270 ∧ code e2419143396270 = 11215236418478 := by decide
theorem cert_e2419143396270 : checkPay e2419143396270 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419143396282 : Closed e2419143396282 ∧ code e2419143396282 = 11215236418490 := by decide
theorem cert_e2419143396282 : checkPay e2419143396282 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419143396310 : Closed e2419143396310 ∧ code e2419143396310 = 11215236418518 := by decide
theorem cert_e2419143396310 : checkPay e2419143396310 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419143396314 : Closed e2419143396314 ∧ code e2419143396314 = 11215236418522 := by decide
theorem cert_e2419143396314 : checkPay e2419143396314 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419143396590 : Closed e2419143396590 ∧ code e2419143396590 = 11215236418798 := by decide
theorem cert_e2419143396590 : checkPay e2419143396590 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419143396598 : Closed e2419143396598 ∧ code e2419143396598 = 11215236418806 := by decide
theorem cert_e2419143396598 : checkPay e2419143396598 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419143396974 : Closed e2419143396974 ∧ code e2419143396974 = 11215236419182 := by decide
theorem cert_e2419143396974 : checkPay e2419143396974 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143396986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419143396986 : Closed e2419143396986 ∧ code e2419143396986 = 11215236419194 := by decide
theorem cert_e2419143396986 : checkPay e2419143396986 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143397174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419143397174 : Closed e2419143397174 ∧ code e2419143397174 = 11215236419382 := by decide
theorem cert_e2419143397174 : checkPay e2419143397174 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143397178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419143397178 : Closed e2419143397178 ∧ code e2419143397178 = 11215236419386 := by decide
theorem cert_e2419143397178 : checkPay e2419143397178 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419143401950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2419143401950 : Closed e2419143401950 ∧ code e2419143401950 = 11215236424158 := by decide
theorem cert_e2419143401950 : checkPay e2419143401950 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143401974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2419143401974 : Closed e2419143401974 ∧ code e2419143401974 = 11215236424182 := by decide
theorem cert_e2419143401974 : checkPay e2419143401974 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right,.under]] = true := by decide
def e2419143402890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419143402890 : Closed e2419143402890 ∧ code e2419143402890 = 11215236425098 := by decide
theorem cert_e2419143402890 : checkPay e2419143402890 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143402914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419143402914 : Closed e2419143402914 ∧ code e2419143402914 = 11215236425122 := by decide
theorem cert_e2419143402914 : checkPay e2419143402914 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143402926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2419143402926 : Closed e2419143402926 ∧ code e2419143402926 = 11215236425134 := by decide
theorem cert_e2419143402926 : checkPay e2419143402926 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143402934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2419143402934 : Closed e2419143402934 ∧ code e2419143402934 = 11215236425142 := by decide
theorem cert_e2419143402934 : checkPay e2419143402934 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143402938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2419143402938 : Closed e2419143402938 ∧ code e2419143402938 = 11215236425146 := by decide
theorem cert_e2419143402938 : checkPay e2419143402938 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143402966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2419143402966 : Closed e2419143402966 ∧ code e2419143402966 = 11215236425174 := by decide
theorem cert_e2419143402966 : checkPay e2419143402966 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143402970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2419143402970 : Closed e2419143402970 ∧ code e2419143402970 = 11215236425178 := by decide
theorem cert_e2419143402970 : checkPay e2419143402970 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2419143402986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2419143402986 : Closed e2419143402986 ∧ code e2419143402986 = 11215236425194 := by decide
theorem cert_e2419143402986 : checkPay e2419143402986 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.right,.left],[.under,.under,.right]] = true := by decide
def e2419143403022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2419143403022 : Closed e2419143403022 ∧ code e2419143403022 = 11215236425230 := by decide
theorem cert_e2419143403022 : checkPay e2419143403022 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
end Blc.Floor43
