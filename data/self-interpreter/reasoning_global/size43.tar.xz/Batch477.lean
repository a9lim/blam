import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407286134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422407286134 : Closed e2422407286134 ∧ code e2422407286134 = 11218500308342 := by decide
theorem cert_e2422407286134 : check e2422407286134 [[],[]] .chain = true := by decide
def e2422407286190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422407286190 : Closed e2422407286190 ∧ code e2422407286190 = 11218500308398 := by decide
theorem cert_e2422407286190 : check e2422407286190 [[],[]] .chain = true := by decide
def e2422407286202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422407286202 : Closed e2422407286202 ∧ code e2422407286202 = 11218500308410 := by decide
theorem cert_e2422407286202 : check e2422407286202 [[],[]] .chain = true := by decide
def e2422407286230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422407286230 : Closed e2422407286230 ∧ code e2422407286230 = 11218500308438 := by decide
theorem cert_e2422407286230 : check e2422407286230 [[],[]] .chain = true := by decide
def e2422407286234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422407286234 : Closed e2422407286234 ∧ code e2422407286234 = 11218500308442 := by decide
theorem cert_e2422407286234 : check e2422407286234 [[],[]] .chain = true := by decide
def e2422407286446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422407286446 : Closed e2422407286446 ∧ code e2422407286446 = 11218500308654 := by decide
theorem cert_e2422407286446 : check e2422407286446 [[],[]] .chain = true := by decide
def e2422407286458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422407286458 : Closed e2422407286458 ∧ code e2422407286458 = 11218500308666 := by decide
theorem cert_e2422407286458 : check e2422407286458 [[],[]] .chain = true := by decide
def e2422407286506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422407286506 : Closed e2422407286506 ∧ code e2422407286506 = 11218500308714 := by decide
theorem cert_e2422407286506 : check e2422407286506 [[],[]] .chain = true := by decide
def e2422407286614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422407286614 : Closed e2422407286614 ∧ code e2422407286614 = 11218500308822 := by decide
theorem cert_e2422407286614 : check e2422407286614 [[],[]] .chain = true := by decide
def e2422407286618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422407286618 : Closed e2422407286618 ∧ code e2422407286618 = 11218500308826 := by decide
theorem cert_e2422407286618 : check e2422407286618 [[],[]] .chain = true := by decide
def e2422407286634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422407286634 : Closed e2422407286634 ∧ code e2422407286634 = 11218500308842 := by decide
theorem cert_e2422407286634 : check e2422407286634 [[],[]] .chain = true := by decide
def e2422407286894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422407286894 : Closed e2422407286894 ∧ code e2422407286894 = 11218500309102 := by decide
theorem cert_e2422407286894 : check e2422407286894 [[],[]] .chain = true := by decide
def e2422407287070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422407287070 : Closed e2422407287070 ∧ code e2422407287070 = 11218500309278 := by decide
theorem cert_e2422407287070 : check e2422407287070 [[],[]] .chain = true := by decide
def e2422407287266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e2422407287266 : Closed e2422407287266 ∧ code e2422407287266 = 11218500309474 := by decide
theorem cert_e2422407287266 : check e2422407287266 [[],[]] .chain = true := by decide
def e2422407287278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 2))))))
theorem wire_e2422407287278 : Closed e2422407287278 ∧ code e2422407287278 = 11218500309486 := by decide
theorem cert_e2422407287278 : check e2422407287278 [[],[]] .sourceHead = true := by decide
def e2422407287662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422407287662 : Closed e2422407287662 ∧ code e2422407287662 = 11218500309870 := by decide
theorem cert_e2422407287662 : check e2422407287662 [[],[]] .chain = true := by decide
def e2422407287670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422407287670 : Closed e2422407287670 ∧ code e2422407287670 = 11218500309878 := by decide
theorem cert_e2422407287670 : check e2422407287670 [[],[]] .chain = true := by decide
def e2422407287726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422407287726 : Closed e2422407287726 ∧ code e2422407287726 = 11218500309934 := by decide
theorem cert_e2422407287726 : check e2422407287726 [[],[]] .chain = true := by decide
def e2422407287738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422407287738 : Closed e2422407287738 ∧ code e2422407287738 = 11218500309946 := by decide
theorem cert_e2422407287738 : check e2422407287738 [[],[]] .chain = true := by decide
def e2422407287766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422407287766 : Closed e2422407287766 ∧ code e2422407287766 = 11218500309974 := by decide
theorem cert_e2422407287766 : check e2422407287766 [[],[]] .chain = true := by decide
def e2422407287770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422407287770 : Closed e2422407287770 ∧ code e2422407287770 = 11218500309978 := by decide
theorem cert_e2422407287770 : check e2422407287770 [[],[]] .chain = true := by decide
def e2422407288046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407288046 : Closed e2422407288046 ∧ code e2422407288046 = 11218500310254 := by decide
theorem cert_e2422407288046 : check e2422407288046 [[],[]] .chain = true := by decide
def e2422407288054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407288054 : Closed e2422407288054 ∧ code e2422407288054 = 11218500310262 := by decide
theorem cert_e2422407288054 : check e2422407288054 [[],[]] .chain = true := by decide
def e2422407288430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407288430 : Closed e2422407288430 ∧ code e2422407288430 = 11218500310638 := by decide
theorem cert_e2422407288430 : check e2422407288430 [[],[]] .chain = true := by decide
def e2422407288442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407288442 : Closed e2422407288442 ∧ code e2422407288442 = 11218500310650 := by decide
theorem cert_e2422407288442 : check e2422407288442 [[],[]] .chain = true := by decide
def e2422407288582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407288582 : Closed e2422407288582 ∧ code e2422407288582 = 11218500310790 := by decide
theorem cert_e2422407288582 : check e2422407288582 [[],[]] .chain = true := by decide
def e2422407288606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 3)))))))
theorem wire_e2422407288606 : Closed e2422407288606 ∧ code e2422407288606 = 11218500310814 := by decide
theorem cert_e2422407288606 : check e2422407288606 [[],[]] .sourceHead = true := by decide
def e2422407288630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407288630 : Closed e2422407288630 ∧ code e2422407288630 = 11218500310838 := by decide
theorem cert_e2422407288630 : check e2422407288630 [[],[]] .chain = true := by decide
def e2422407288634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407288634 : Closed e2422407288634 ∧ code e2422407288634 = 11218500310842 := by decide
theorem cert_e2422407288634 : check e2422407288634 [[],[]] .chain = true := by decide
def e2422407289262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407289262 : Closed e2422407289262 ∧ code e2422407289262 = 11218500311470 := by decide
theorem cert_e2422407289262 : check e2422407289262 [[],[]] .chain = true := by decide
def e2422407289274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407289274 : Closed e2422407289274 ∧ code e2422407289274 = 11218500311482 := by decide
theorem cert_e2422407289274 : check e2422407289274 [[],[]] .chain = true := by decide
def e2422407289322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407289322 : Closed e2422407289322 ∧ code e2422407289322 = 11218500311530 := by decide
theorem cert_e2422407289322 : check e2422407289322 [[],[]] .chain = true := by decide
def e2422407289454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407289454 : Closed e2422407289454 ∧ code e2422407289454 = 11218500311662 := by decide
theorem cert_e2422407289454 : check e2422407289454 [[],[]] .chain = true := by decide
def e2422407289466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407289466 : Closed e2422407289466 ∧ code e2422407289466 = 11218500311674 := by decide
theorem cert_e2422407289466 : check e2422407289466 [[],[]] .chain = true := by decide
def e2422407289754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407289754 : Closed e2422407289754 ∧ code e2422407289754 = 11218500311962 := by decide
theorem cert_e2422407289754 : check e2422407289754 [[],[]] .chain = true := by decide
def e2422407289882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422407289882 : Closed e2422407289882 ∧ code e2422407289882 = 11218500312090 := by decide
theorem cert_e2422407289882 : check e2422407289882 [[],[]] .chain = true := by decide
def e2422407289926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422407289926 : Closed e2422407289926 ∧ code e2422407289926 = 11218500312134 := by decide
theorem cert_e2422407289926 : check e2422407289926 [[],[]] .chain = true := by decide
def e2422407289954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407289954 : Closed e2422407289954 ∧ code e2422407289954 = 11218500312162 := by decide
theorem cert_e2422407289954 : check e2422407289954 [[],[]] .chain = true := by decide
def e2422407289966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407289966 : Closed e2422407289966 ∧ code e2422407289966 = 11218500312174 := by decide
theorem cert_e2422407289966 : check e2422407289966 [[],[]] .sourceHead = true := by decide
def e2422407289978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407289978 : Closed e2422407289978 ∧ code e2422407289978 = 11218500312186 := by decide
theorem cert_e2422407289978 : check e2422407289978 [[],[]] .sourceHead = true := by decide
def e2422407290070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407290070 : Closed e2422407290070 ∧ code e2422407290070 = 11218500312278 := by decide
theorem cert_e2422407290070 : check e2422407290070 [[],[]] .chain = true := by decide
def e2422407290074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407290074 : Closed e2422407290074 ∧ code e2422407290074 = 11218500312282 := by decide
theorem cert_e2422407290074 : check e2422407290074 [[],[]] .chain = true := by decide
def e2422407290090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407290090 : Closed e2422407290090 ∧ code e2422407290090 = 11218500312298 := by decide
theorem cert_e2422407290090 : check e2422407290090 [[],[]] .chain = true := by decide
def e2422407290118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407290118 : Closed e2422407290118 ∧ code e2422407290118 = 11218500312326 := by decide
theorem cert_e2422407290118 : check e2422407290118 [[],[]] .chain = true := by decide
def e2422407290142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407290142 : Closed e2422407290142 ∧ code e2422407290142 = 11218500312350 := by decide
theorem cert_e2422407290142 : check e2422407290142 [[],[]] .sourceHead = true := by decide
def e2422407290166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407290166 : Closed e2422407290166 ∧ code e2422407290166 = 11218500312374 := by decide
theorem cert_e2422407290166 : check e2422407290166 [[],[]] .chain = true := by decide
def e2422407290170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407290170 : Closed e2422407290170 ∧ code e2422407290170 = 11218500312378 := by decide
theorem cert_e2422407290170 : check e2422407290170 [[],[]] .chain = true := by decide
def e2422407290266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407290266 : Closed e2422407290266 ∧ code e2422407290266 = 11218500312474 := by decide
theorem cert_e2422407290266 : check e2422407290266 [[],[]] .chain = true := by decide
def e2422407290310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407290310 : Closed e2422407290310 ∧ code e2422407290310 = 11218500312518 := by decide
theorem cert_e2422407290310 : check e2422407290310 [[],[]] .sourceHead = true := by decide
def e2422407290922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 0))))))
theorem wire_e2422407290922 : Closed e2422407290922 ∧ code e2422407290922 = 11218500313130 := by decide
theorem cert_e2422407290922 : check e2422407290922 [[],[]] .chain = true := by decide
def e2422407291054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422407291054 : Closed e2422407291054 ∧ code e2422407291054 = 11218500313262 := by decide
theorem cert_e2422407291054 : check e2422407291054 [[],[]] .sourceHead = true := by decide
def e2422407291066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422407291066 : Closed e2422407291066 ∧ code e2422407291066 = 11218500313274 := by decide
theorem cert_e2422407291066 : check e2422407291066 [[],[]] .sourceHead = true := by decide
def e2422407291094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e2422407291094 : Closed e2422407291094 ∧ code e2422407291094 = 11218500313302 := by decide
theorem cert_e2422407291094 : check e2422407291094 [[],[]] .chain = true := by decide
def e2422407291098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e2422407291098 : Closed e2422407291098 ∧ code e2422407291098 = 11218500313306 := by decide
theorem cert_e2422407291098 : check e2422407291098 [[],[]] .chain = true := by decide
def e2422407291114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0)) (.var 0))))))
theorem wire_e2422407291114 : Closed e2422407291114 ∧ code e2422407291114 = 11218500313322 := by decide
theorem cert_e2422407291114 : check e2422407291114 [[],[]] .chain = true := by decide
def e2422407291306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407291306 : Closed e2422407291306 ∧ code e2422407291306 = 11218500313514 := by decide
theorem cert_e2422407291306 : check e2422407291306 [[],[]] .sourceHead = true := by decide
def e2422407291446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407291446 : Closed e2422407291446 ∧ code e2422407291446 = 11218500313654 := by decide
theorem cert_e2422407291446 : check e2422407291446 [[],[]] .chain = true := by decide
def e2422407291450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407291450 : Closed e2422407291450 ∧ code e2422407291450 = 11218500313658 := by decide
theorem cert_e2422407291450 : check e2422407291450 [[],[]] .chain = true := by decide
def e2422407291498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422407291498 : Closed e2422407291498 ∧ code e2422407291498 = 11218500313706 := by decide
theorem cert_e2422407291498 : check e2422407291498 [[],[]] .chain = true := by decide
def e2422407291534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407291534 : Closed e2422407291534 ∧ code e2422407291534 = 11218500313742 := by decide
theorem cert_e2422407291534 : check e2422407291534 [[],[]] .chain = true := by decide
def e2422407291546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407291546 : Closed e2422407291546 ∧ code e2422407291546 = 11218500313754 := by decide
theorem cert_e2422407291546 : check e2422407291546 [[],[]] .chain = true := by decide
def e2422407291590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407291590 : Closed e2422407291590 ∧ code e2422407291590 = 11218500313798 := by decide
theorem cert_e2422407291590 : check e2422407291590 [[],[]] .chain = true := by decide
def e2422407291670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422407291670 : Closed e2422407291670 ∧ code e2422407291670 = 11218500313878 := by decide
theorem cert_e2422407291670 : check e2422407291670 [[],[]] .chain = true := by decide
def e2422407291674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407291674 : Closed e2422407291674 ∧ code e2422407291674 = 11218500313882 := by decide
theorem cert_e2422407291674 : check e2422407291674 [[],[]] .chain = true := by decide
def e2422407291718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407291718 : Closed e2422407291718 ∧ code e2422407291718 = 11218500313926 := by decide
theorem cert_e2422407291718 : check e2422407291718 [[],[]] .chain = true := by decide
def e2422407291746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422407291746 : Closed e2422407291746 ∧ code e2422407291746 = 11218500313954 := by decide
theorem cert_e2422407291746 : check e2422407291746 [[],[]] .chain = true := by decide
def e2422407291758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422407291758 : Closed e2422407291758 ∧ code e2422407291758 = 11218500313966 := by decide
theorem cert_e2422407291758 : check e2422407291758 [[],[]] .sourceHead = true := by decide
def e2422407291766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422407291766 : Closed e2422407291766 ∧ code e2422407291766 = 11218500313974 := by decide
theorem cert_e2422407291766 : check e2422407291766 [[],[]] .sourceHead = true := by decide
def e2422407291786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407291786 : Closed e2422407291786 ∧ code e2422407291786 = 11218500313994 := by decide
theorem cert_e2422407291786 : check e2422407291786 [[],[]] .chain = true := by decide
def e2422407291810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407291810 : Closed e2422407291810 ∧ code e2422407291810 = 11218500314018 := by decide
theorem cert_e2422407291810 : check e2422407291810 [[],[]] .chain = true := by decide
def e2422407291822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422407291822 : Closed e2422407291822 ∧ code e2422407291822 = 11218500314030 := by decide
theorem cert_e2422407291822 : check e2422407291822 [[],[]] .sourceHead = true := by decide
def e2422407291834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422407291834 : Closed e2422407291834 ∧ code e2422407291834 = 11218500314042 := by decide
theorem cert_e2422407291834 : check e2422407291834 [[],[]] .sourceHead = true := by decide
def e2422407291862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2422407291862 : Closed e2422407291862 ∧ code e2422407291862 = 11218500314070 := by decide
theorem cert_e2422407291862 : check e2422407291862 [[],[]] .sourceHead = true := by decide
def e2422407291866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2422407291866 : Closed e2422407291866 ∧ code e2422407291866 = 11218500314074 := by decide
theorem cert_e2422407291866 : check e2422407291866 [[],[]] .sourceHead = true := by decide
def e2422407292458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407292458 : Closed e2422407292458 ∧ code e2422407292458 = 11218500314666 := by decide
theorem cert_e2422407292458 : check e2422407292458 [[],[]] .chain = true := by decide
def e2422407292554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407292554 : Closed e2422407292554 ∧ code e2422407292554 = 11218500314762 := by decide
theorem cert_e2422407292554 : check e2422407292554 [[],[]] .chain = true := by decide
def e2422407292578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407292578 : Closed e2422407292578 ∧ code e2422407292578 = 11218500314786 := by decide
theorem cert_e2422407292578 : check e2422407292578 [[],[]] .chain = true := by decide
def e2422407292590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422407292590 : Closed e2422407292590 ∧ code e2422407292590 = 11218500314798 := by decide
theorem cert_e2422407292590 : check e2422407292590 [[],[]] .sourceHead = true := by decide
def e2422407292598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2422407292598 : Closed e2422407292598 ∧ code e2422407292598 = 11218500314806 := by decide
theorem cert_e2422407292598 : check e2422407292598 [[],[]] .chain = true := by decide
def e2422407292602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422407292602 : Closed e2422407292602 ∧ code e2422407292602 = 11218500314810 := by decide
theorem cert_e2422407292602 : check e2422407292602 [[],[]] .sourceHead = true := by decide
def e2422407292630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422407292630 : Closed e2422407292630 ∧ code e2422407292630 = 11218500314838 := by decide
theorem cert_e2422407292630 : check e2422407292630 [[],[]] .chain = true := by decide
def e2422407292634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422407292634 : Closed e2422407292634 ∧ code e2422407292634 = 11218500314842 := by decide
theorem cert_e2422407292634 : check e2422407292634 [[],[]] .chain = true := by decide
def e2422407292650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422407292650 : Closed e2422407292650 ∧ code e2422407292650 = 11218500314858 := by decide
theorem cert_e2422407292650 : check e2422407292650 [[],[]] .sourceHead = true := by decide
def e2422407292758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422407292758 : Closed e2422407292758 ∧ code e2422407292758 = 11218500314966 := by decide
theorem cert_e2422407292758 : check e2422407292758 [[],[]] .chain = true := by decide
def e2422407292762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422407292762 : Closed e2422407292762 ∧ code e2422407292762 = 11218500314970 := by decide
theorem cert_e2422407292762 : check e2422407292762 [[],[]] .chain = true := by decide
def e2422407292778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422407292778 : Closed e2422407292778 ∧ code e2422407292778 = 11218500314986 := by decide
theorem cert_e2422407292778 : check e2422407292778 [[],[]] .chain = true := by decide
def e2422407292842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422407292842 : Closed e2422407292842 ∧ code e2422407292842 = 11218500315050 := by decide
theorem cert_e2422407292842 : check e2422407292842 [[],[]] .sourceHead = true := by decide
def e2422407292938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407292938 : Closed e2422407292938 ∧ code e2422407292938 = 11218500315146 := by decide
theorem cert_e2422407292938 : check e2422407292938 [[],[]] .chain = true := by decide
def e2422407292974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407292974 : Closed e2422407292974 ∧ code e2422407292974 = 11218500315182 := by decide
theorem cert_e2422407292974 : check e2422407292974 [[],[]] .sourceHead = true := by decide
def e2422407292982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407292982 : Closed e2422407292982 ∧ code e2422407292982 = 11218500315190 := by decide
theorem cert_e2422407292982 : check e2422407292982 [[],[]] .chain = true := by decide
def e2422407292986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407292986 : Closed e2422407292986 ∧ code e2422407292986 = 11218500315194 := by decide
theorem cert_e2422407292986 : check e2422407292986 [[],[]] .chain = true := by decide
def e2422407293034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407293034 : Closed e2422407293034 ∧ code e2422407293034 = 11218500315242 := by decide
theorem cert_e2422407293034 : check e2422407293034 [[],[]] .sourceHead = true := by decide
def e2422407293070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407293070 : Closed e2422407293070 ∧ code e2422407293070 = 11218500315278 := by decide
theorem cert_e2422407293070 : check e2422407293070 [[],[]] .chain = true := by decide
def e2422407293082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407293082 : Closed e2422407293082 ∧ code e2422407293082 = 11218500315290 := by decide
theorem cert_e2422407293082 : check e2422407293082 [[],[]] .chain = true := by decide
def e2422407293126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407293126 : Closed e2422407293126 ∧ code e2422407293126 = 11218500315334 := by decide
theorem cert_e2422407293126 : check e2422407293126 [[],[]] .chain = true := by decide
def e2422407293154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407293154 : Closed e2422407293154 ∧ code e2422407293154 = 11218500315362 := by decide
theorem cert_e2422407293154 : check e2422407293154 [[],[]] .chain = true := by decide
def e2422407293166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422407293166 : Closed e2422407293166 ∧ code e2422407293166 = 11218500315374 := by decide
theorem cert_e2422407293166 : check e2422407293166 [[],[]] .sourceHead = true := by decide
def e2422407293174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422407293174 : Closed e2422407293174 ∧ code e2422407293174 = 11218500315382 := by decide
theorem cert_e2422407293174 : check e2422407293174 [[],[]] .sourceHead = true := by decide
def e2422407293322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407293322 : Closed e2422407293322 ∧ code e2422407293322 = 11218500315530 := by decide
theorem cert_e2422407293322 : check e2422407293322 [[],[]] .chain = true := by decide
def e2422407293346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407293346 : Closed e2422407293346 ∧ code e2422407293346 = 11218500315554 := by decide
theorem cert_e2422407293346 : check e2422407293346 [[],[]] .chain = true := by decide
def e2422407293358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407293358 : Closed e2422407293358 ∧ code e2422407293358 = 11218500315566 := by decide
theorem cert_e2422407293358 : check e2422407293358 [[],[]] .sourceHead = true := by decide
def e2422407293366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422407293366 : Closed e2422407293366 ∧ code e2422407293366 = 11218500315574 := by decide
theorem cert_e2422407293366 : check e2422407293366 [[],[]] .chain = true := by decide
def e2422407293370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407293370 : Closed e2422407293370 ∧ code e2422407293370 = 11218500315578 := by decide
theorem cert_e2422407293370 : check e2422407293370 [[],[]] .sourceHead = true := by decide
def e2422407293398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422407293398 : Closed e2422407293398 ∧ code e2422407293398 = 11218500315606 := by decide
theorem cert_e2422407293398 : check e2422407293398 [[],[]] .chain = true := by decide
def e2422407293402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422407293402 : Closed e2422407293402 ∧ code e2422407293402 = 11218500315610 := by decide
theorem cert_e2422407293402 : check e2422407293402 [[],[]] .chain = true := by decide
def e2422407293418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407293418 : Closed e2422407293418 ∧ code e2422407293418 = 11218500315626 := by decide
theorem cert_e2422407293418 : check e2422407293418 [[],[]] .sourceHead = true := by decide
def e2422407293442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407293442 : Closed e2422407293442 ∧ code e2422407293442 = 11218500315650 := by decide
theorem cert_e2422407293442 : check e2422407293442 [[],[]] .chain = true := by decide
def e2422407293454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407293454 : Closed e2422407293454 ∧ code e2422407293454 = 11218500315662 := by decide
theorem cert_e2422407293454 : check e2422407293454 [[],[]] .chain = true := by decide
def e2422407293466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407293466 : Closed e2422407293466 ∧ code e2422407293466 = 11218500315674 := by decide
theorem cert_e2422407293466 : check e2422407293466 [[],[]] .sourceHead = true := by decide
def e2422407293538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407293538 : Closed e2422407293538 ∧ code e2422407293538 = 11218500315746 := by decide
theorem cert_e2422407293538 : check e2422407293538 [[],[]] .chain = true := by decide
def e2422407293550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407293550 : Closed e2422407293550 ∧ code e2422407293550 = 11218500315758 := by decide
theorem cert_e2422407293550 : check e2422407293550 [[],[]] .sourceHead = true := by decide
def e2422407293558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407293558 : Closed e2422407293558 ∧ code e2422407293558 = 11218500315766 := by decide
theorem cert_e2422407293558 : check e2422407293558 [[],[]] .chain = true := by decide
def e2422407293562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407293562 : Closed e2422407293562 ∧ code e2422407293562 = 11218500315770 := by decide
theorem cert_e2422407293562 : check e2422407293562 [[],[]] .sourceHead = true := by decide
def e2422407293702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407293702 : Closed e2422407293702 ∧ code e2422407293702 = 11218500315910 := by decide
theorem cert_e2422407293702 : check e2422407293702 [[],[]] .chain = true := by decide
def e2422407293726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422407293726 : Closed e2422407293726 ∧ code e2422407293726 = 11218500315934 := by decide
theorem cert_e2422407293726 : check e2422407293726 [[],[]] .sourceHead = true := by decide
def e2422407293750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407293750 : Closed e2422407293750 ∧ code e2422407293750 = 11218500315958 := by decide
theorem cert_e2422407293750 : check e2422407293750 [[],[]] .chain = true := by decide
def e2422407293754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407293754 : Closed e2422407293754 ∧ code e2422407293754 = 11218500315962 := by decide
theorem cert_e2422407293754 : check e2422407293754 [[],[]] .chain = true := by decide
def e2422407293826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407293826 : Closed e2422407293826 ∧ code e2422407293826 = 11218500316034 := by decide
theorem cert_e2422407293826 : check e2422407293826 [[],[]] .sourceHead = true := by decide
def e2422407293838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422407293838 : Closed e2422407293838 ∧ code e2422407293838 = 11218500316046 := by decide
theorem cert_e2422407293838 : check e2422407293838 [[],[]] .sourceHead = true := by decide
def e2422407293850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407293850 : Closed e2422407293850 ∧ code e2422407293850 = 11218500316058 := by decide
theorem cert_e2422407293850 : check e2422407293850 [[],[]] .sourceHead = true := by decide
def e2422407293978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422407293978 : Closed e2422407293978 ∧ code e2422407293978 = 11218500316186 := by decide
theorem cert_e2422407293978 : check e2422407293978 [[],[]] .chain = true := by decide
def e2422407294022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422407294022 : Closed e2422407294022 ∧ code e2422407294022 = 11218500316230 := by decide
theorem cert_e2422407294022 : check e2422407294022 [[],[]] .chain = true := by decide
def e2422407294050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407294050 : Closed e2422407294050 ∧ code e2422407294050 = 11218500316258 := by decide
theorem cert_e2422407294050 : check e2422407294050 [[],[]] .chain = true := by decide
def e2422407294062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407294062 : Closed e2422407294062 ∧ code e2422407294062 = 11218500316270 := by decide
theorem cert_e2422407294062 : check e2422407294062 [[],[]] .sourceHead = true := by decide
def e2422407294074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407294074 : Closed e2422407294074 ∧ code e2422407294074 = 11218500316282 := by decide
theorem cert_e2422407294074 : check e2422407294074 [[],[]] .sourceHead = true := by decide
def e2422407294166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407294166 : Closed e2422407294166 ∧ code e2422407294166 = 11218500316374 := by decide
theorem cert_e2422407294166 : check e2422407294166 [[],[]] .chain = true := by decide
def e2422407294170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407294170 : Closed e2422407294170 ∧ code e2422407294170 = 11218500316378 := by decide
theorem cert_e2422407294170 : check e2422407294170 [[],[]] .chain = true := by decide
def e2422407294186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407294186 : Closed e2422407294186 ∧ code e2422407294186 = 11218500316394 := by decide
theorem cert_e2422407294186 : check e2422407294186 [[],[]] .chain = true := by decide
def e2422407294214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e2422407294214 : Closed e2422407294214 ∧ code e2422407294214 = 11218500316422 := by decide
theorem cert_e2422407294214 : check e2422407294214 [[],[]] .chain = true := by decide
def e2422407294238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407294238 : Closed e2422407294238 ∧ code e2422407294238 = 11218500316446 := by decide
theorem cert_e2422407294238 : check e2422407294238 [[],[]] .sourceHead = true := by decide
def e2422407294262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407294262 : Closed e2422407294262 ∧ code e2422407294262 = 11218500316470 := by decide
theorem cert_e2422407294262 : check e2422407294262 [[],[]] .chain = true := by decide
def e2422407294266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407294266 : Closed e2422407294266 ∧ code e2422407294266 = 11218500316474 := by decide
theorem cert_e2422407294266 : check e2422407294266 [[],[]] .chain = true := by decide
def e2422407294362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407294362 : Closed e2422407294362 ∧ code e2422407294362 = 11218500316570 := by decide
theorem cert_e2422407294362 : check e2422407294362 [[],[]] .chain = true := by decide
def e2422407294406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407294406 : Closed e2422407294406 ∧ code e2422407294406 = 11218500316614 := by decide
theorem cert_e2422407294406 : check e2422407294406 [[],[]] .sourceHead = true := by decide
def e2422407294474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407294474 : Closed e2422407294474 ∧ code e2422407294474 = 11218500316682 := by decide
theorem cert_e2422407294474 : check e2422407294474 [[],[]] .sourceHead = true := by decide
def e2422407294518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407294518 : Closed e2422407294518 ∧ code e2422407294518 = 11218500316726 := by decide
theorem cert_e2422407294518 : check e2422407294518 [[],[]] .sourceHead = true := by decide
def e2422407294522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407294522 : Closed e2422407294522 ∧ code e2422407294522 = 11218500316730 := by decide
theorem cert_e2422407294522 : check e2422407294522 [[],[]] .sourceHead = true := by decide
def e2422407294570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422407294570 : Closed e2422407294570 ∧ code e2422407294570 = 11218500316778 := by decide
theorem cert_e2422407294570 : check e2422407294570 [[],[]] .sourceHead = true := by decide
def e2422407294594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e2422407294594 : Closed e2422407294594 ∧ code e2422407294594 = 11218500316802 := by decide
theorem cert_e2422407294594 : check e2422407294594 [[],[]] .sourceHead = true := by decide
def e2422407294606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407294606 : Closed e2422407294606 ∧ code e2422407294606 = 11218500316814 := by decide
theorem cert_e2422407294606 : check e2422407294606 [[],[]] .sourceHead = true := by decide
def e2422407294618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407294618 : Closed e2422407294618 ∧ code e2422407294618 = 11218500316826 := by decide
theorem cert_e2422407294618 : check e2422407294618 [[],[]] .sourceHead = true := by decide
def e2422407294662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407294662 : Closed e2422407294662 ∧ code e2422407294662 = 11218500316870 := by decide
theorem cert_e2422407294662 : check e2422407294662 [[],[]] .sourceHead = true := by decide
def e2422407299502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e2422407299502 : Closed e2422407299502 ∧ code e2422407299502 = 11218500321710 := by decide
theorem cert_e2422407299502 : check e2422407299502 [[],[]] .sourceHead = true := by decide
def e2422407299694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407299694 : Closed e2422407299694 ∧ code e2422407299694 = 11218500321902 := by decide
theorem cert_e2422407299694 : check e2422407299694 [[],[]] .chain = true := by decide
def e2422407299706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407299706 : Closed e2422407299706 ∧ code e2422407299706 = 11218500321914 := by decide
theorem cert_e2422407299706 : check e2422407299706 [[],[]] .chain = true := by decide
def e2422407300078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 4))))) (.var 2))))))
theorem wire_e2422407300078 : Closed e2422407300078 ∧ code e2422407300078 = 11218500322286 := by decide
theorem cert_e2422407300078 : check e2422407300078 [[],[]] .chain = true := by decide
def e2422407300086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 5))))) (.var 1))))))
theorem wire_e2422407300086 : Closed e2422407300086 ∧ code e2422407300086 = 11218500322294 := by decide
theorem cert_e2422407300086 : check e2422407300086 [[],[]] .chain = true := by decide
def e2422407300846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e2422407300846 : Closed e2422407300846 ∧ code e2422407300846 = 11218500323054 := by decide
theorem cert_e2422407300846 : check e2422407300846 [[],[]] .chain = true := by decide
def e2422407300858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.var 4))))) (.var 0))))))
theorem wire_e2422407300858 : Closed e2422407300858 ∧ code e2422407300858 = 11218500323066 := by decide
theorem cert_e2422407300858 : check e2422407300858 [[],[]] .chain = true := by decide
def e2422407300974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e2422407300974 : Closed e2422407300974 ∧ code e2422407300974 = 11218500323182 := by decide
theorem cert_e2422407300974 : check e2422407300974 [[],[]] .sourceHead = true := by decide
def e2422407301038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e2422407301038 : Closed e2422407301038 ∧ code e2422407301038 = 11218500323246 := by decide
theorem cert_e2422407301038 : check e2422407301038 [[],[]] .chain = true := by decide
def e2422407301098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 4) (.var 0))))) (.var 0))))))
theorem wire_e2422407301098 : Closed e2422407301098 ∧ code e2422407301098 = 11218500323306 := by decide
theorem cert_e2422407301098 : check e2422407301098 [[],[]] .chain = true := by decide
def e2422407301614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407301614 : Closed e2422407301614 ∧ code e2422407301614 = 11218500323822 := by decide
theorem cert_e2422407301614 : check e2422407301614 [[],[]] .sourceHead = true := by decide
def e2422407302382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407302382 : Closed e2422407302382 ∧ code e2422407302382 = 11218500324590 := by decide
theorem cert_e2422407302382 : check e2422407302382 [[],[]] .chain = true := by decide
def e2422407302390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407302390 : Closed e2422407302390 ∧ code e2422407302390 = 11218500324598 := by decide
theorem cert_e2422407302390 : check e2422407302390 [[],[]] .chain = true := by decide
def e2422407302766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407302766 : Closed e2422407302766 ∧ code e2422407302766 = 11218500324974 := by decide
theorem cert_e2422407302766 : check e2422407302766 [[],[]] .chain = true := by decide
def e2422407302778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407302778 : Closed e2422407302778 ∧ code e2422407302778 = 11218500324986 := by decide
theorem cert_e2422407302778 : check e2422407302778 [[],[]] .chain = true := by decide
def e2422407302942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 3)))) (.lam (.var 3)))))))
theorem wire_e2422407302942 : Closed e2422407302942 ∧ code e2422407302942 = 11218500325150 := by decide
theorem cert_e2422407302942 : check e2422407302942 [[],[]] .chain = true := by decide
def e2422407303054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.lam (.var 2)))))))
theorem wire_e2422407303054 : Closed e2422407303054 ∧ code e2422407303054 = 11218500325262 := by decide
theorem cert_e2422407303054 : check e2422407303054 [[],[]] .chain = true := by decide
def e2422407303066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407303066 : Closed e2422407303066 ∧ code e2422407303066 = 11218500325274 := by decide
theorem cert_e2422407303066 : check e2422407303066 [[],[]] .chain = true := by decide
end Blc.Floor43
