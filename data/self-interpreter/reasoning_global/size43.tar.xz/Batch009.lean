import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e599735192814 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e599735192814 : Closed e599735192814 ∧ code e599735192814 = 9395828215022 := by decide
theorem cert_e599735192814 : check e599735192814 [[.under]] .sourceHead = true := by decide
def e599735192822 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e599735192822 : Closed e599735192822 ∧ code e599735192822 = 9395828215030 := by decide
theorem cert_e599735192822 : check e599735192822 [[.under]] .sourceHead = true := by decide
def e599735193198 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e599735193198 : Closed e599735193198 ∧ code e599735193198 = 9395828215406 := by decide
theorem cert_e599735193198 : check e599735193198 [[.under]] .sourceHead = true := by decide
def e599735193210 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e599735193210 : Closed e599735193210 ∧ code e599735193210 = 9395828215418 := by decide
theorem cert_e599735193210 : check e599735193210 [[.under]] .sourceHead = true := by decide
def e599735193398 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e599735193398 : Closed e599735193398 ∧ code e599735193398 = 9395828215606 := by decide
theorem cert_e599735193398 : check e599735193398 [[.under]] .sourceHead = true := by decide
def e599735193402 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e599735193402 : Closed e599735193402 ∧ code e599735193402 = 9395828215610 := by decide
theorem cert_e599735193402 : check e599735193402 [[.under]] .sourceHead = true := by decide
def e599735199150 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e599735199150 : Closed e599735199150 ∧ code e599735199150 = 9395828221358 := by decide
theorem cert_e599735199150 : check e599735199150 [[.under]] .sourceHead = true := by decide
def e599735199162 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e599735199162 : Closed e599735199162 ∧ code e599735199162 = 9395828221370 := by decide
theorem cert_e599735199162 : check e599735199162 [[.under]] .sourceHead = true := by decide
def e599735199210 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e599735199210 : Closed e599735199210 ∧ code e599735199210 = 9395828221418 := by decide
theorem cert_e599735199210 : check e599735199210 [[.under]] .sourceHead = true := by decide
def e599735199342 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e599735199342 : Closed e599735199342 ∧ code e599735199342 = 9395828221550 := by decide
theorem cert_e599735199342 : check e599735199342 [[.under]] .sourceHead = true := by decide
def e599735199354 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e599735199354 : Closed e599735199354 ∧ code e599735199354 = 9395828221562 := by decide
theorem cert_e599735199354 : check e599735199354 [[.under]] .sourceHead = true := by decide
def e599735199642 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e599735199642 : Closed e599735199642 ∧ code e599735199642 = 9395828221850 := by decide
theorem cert_e599735199642 : check e599735199642 [[.under]] .sourceHead = true := by decide
def e599735202518 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e599735202518 : Closed e599735202518 ∧ code e599735202518 = 9395828224726 := by decide
theorem cert_e599735202518 : check e599735202518 [[.under]] .sourceHead = true := by decide
def e599735202522 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e599735202522 : Closed e599735202522 ∧ code e599735202522 = 9395828224730 := by decide
theorem cert_e599735202522 : check e599735202522 [[.under]] .sourceHead = true := by decide
def e599735202538 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e599735202538 : Closed e599735202538 ∧ code e599735202538 = 9395828224746 := by decide
theorem cert_e599735202538 : check e599735202538 [[.under]] .sourceHead = true := by decide
def e599735202614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e599735202614 : Closed e599735202614 ∧ code e599735202614 = 9395828224822 := by decide
theorem cert_e599735202614 : check e599735202614 [[.under]] .sourceHead = true := by decide
def e599735202618 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e599735202618 : Closed e599735202618 ∧ code e599735202618 = 9395828224826 := by decide
theorem cert_e599735202618 : check e599735202618 [[.under]] .sourceHead = true := by decide
def e599735202714 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e599735202714 : Closed e599735202714 ∧ code e599735202714 = 9395828224922 := by decide
theorem cert_e599735202714 : check e599735202714 [[.under]] .sourceHead = true := by decide
def e599735339886 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e599735339886 : Closed e599735339886 ∧ code e599735339886 = 9395828362094 := by decide
theorem cert_e599735339886 : check e599735339886 [[.under]] .sourceHead = true := by decide
def e599735339894 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e599735339894 : Closed e599735339894 ∧ code e599735339894 = 9395828362102 := by decide
theorem cert_e599735339894 : check e599735339894 [[.under]] .sourceHead = true := by decide
def e599735339950 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e599735339950 : Closed e599735339950 ∧ code e599735339950 = 9395828362158 := by decide
theorem cert_e599735339950 : check e599735339950 [[.under]] .sourceHead = true := by decide
def e599735339962 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e599735339962 : Closed e599735339962 ∧ code e599735339962 = 9395828362170 := by decide
theorem cert_e599735339962 : check e599735339962 [[.under]] .sourceHead = true := by decide
def e599735339990 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e599735339990 : Closed e599735339990 ∧ code e599735339990 = 9395828362198 := by decide
theorem cert_e599735339990 : check e599735339990 [[.under]] .sourceHead = true := by decide
def e599735339994 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e599735339994 : Closed e599735339994 ∧ code e599735339994 = 9395828362202 := by decide
theorem cert_e599735339994 : check e599735339994 [[.under]] .sourceHead = true := by decide
def e599735340270 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e599735340270 : Closed e599735340270 ∧ code e599735340270 = 9395828362478 := by decide
theorem cert_e599735340270 : check e599735340270 [[.under]] .sourceHead = true := by decide
def e599735340278 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e599735340278 : Closed e599735340278 ∧ code e599735340278 = 9395828362486 := by decide
theorem cert_e599735340278 : check e599735340278 [[.under]] .sourceHead = true := by decide
def e599735340654 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e599735340654 : Closed e599735340654 ∧ code e599735340654 = 9395828362862 := by decide
theorem cert_e599735340654 : check e599735340654 [[.under]] .sourceHead = true := by decide
def e599735340666 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e599735340666 : Closed e599735340666 ∧ code e599735340666 = 9395828362874 := by decide
theorem cert_e599735340666 : check e599735340666 [[.under]] .sourceHead = true := by decide
def e599735340854 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e599735340854 : Closed e599735340854 ∧ code e599735340854 = 9395828363062 := by decide
theorem cert_e599735340854 : check e599735340854 [[.under]] .sourceHead = true := by decide
def e599735340858 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e599735340858 : Closed e599735340858 ∧ code e599735340858 = 9395828363066 := by decide
theorem cert_e599735340858 : check e599735340858 [[.under]] .sourceHead = true := by decide
def e599735929710 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e599735929710 : Closed e599735929710 ∧ code e599735929710 = 9395828951918 := by decide
theorem cert_e599735929710 : check e599735929710 [[.under]] .sourceHead = true := by decide
def e599735929718 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e599735929718 : Closed e599735929718 ∧ code e599735929718 = 9395828951926 := by decide
theorem cert_e599735929718 : check e599735929718 [[.under]] .sourceHead = true := by decide
def e599735929774 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e599735929774 : Closed e599735929774 ∧ code e599735929774 = 9395828951982 := by decide
theorem cert_e599735929774 : check e599735929774 [[.under]] .sourceHead = true := by decide
def e599735929786 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e599735929786 : Closed e599735929786 ∧ code e599735929786 = 9395828951994 := by decide
theorem cert_e599735929786 : check e599735929786 [[.under]] .sourceHead = true := by decide
def e599735929814 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e599735929814 : Closed e599735929814 ∧ code e599735929814 = 9395828952022 := by decide
theorem cert_e599735929814 : check e599735929814 [[.under]] .sourceHead = true := by decide
def e599735929818 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e599735929818 : Closed e599735929818 ∧ code e599735929818 = 9395828952026 := by decide
theorem cert_e599735929818 : check e599735929818 [[.under]] .sourceHead = true := by decide
def e599735930094 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e599735930094 : Closed e599735930094 ∧ code e599735930094 = 9395828952302 := by decide
theorem cert_e599735930094 : check e599735930094 [[.under]] .sourceHead = true := by decide
def e599735930102 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e599735930102 : Closed e599735930102 ∧ code e599735930102 = 9395828952310 := by decide
theorem cert_e599735930102 : check e599735930102 [[.under]] .sourceHead = true := by decide
def e599735930478 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e599735930478 : Closed e599735930478 ∧ code e599735930478 = 9395828952686 := by decide
theorem cert_e599735930478 : check e599735930478 [[.under]] .sourceHead = true := by decide
def e599735930490 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e599735930490 : Closed e599735930490 ∧ code e599735930490 = 9395828952698 := by decide
theorem cert_e599735930490 : check e599735930490 [[.under]] .sourceHead = true := by decide
def e599735930678 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e599735930678 : Closed e599735930678 ∧ code e599735930678 = 9395828952886 := by decide
theorem cert_e599735930678 : check e599735930678 [[.under]] .sourceHead = true := by decide
def e599735930682 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e599735930682 : Closed e599735930682 ∧ code e599735930682 = 9395828952890 := by decide
theorem cert_e599735930682 : check e599735930682 [[.under]] .sourceHead = true := by decide
def e599819115230 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e599819115230 : Closed e599819115230 ∧ code e599819115230 = 9395912137438 := by decide
theorem cert_e599819115230 : check e599819115230 [[.under]] .sourceHead = true := by decide
def e599819115254 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e599819115254 : Closed e599819115254 ∧ code e599819115254 = 9395912137462 := by decide
theorem cert_e599819115254 : check e599819115254 [[.under]] .sourceHead = true := by decide
def e599819115358 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e599819115358 : Closed e599819115358 ∧ code e599819115358 = 9395912137566 := by decide
theorem cert_e599819115358 : check e599819115358 [[.under]] .sourceHead = true := by decide
def e599819115374 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e599819115374 : Closed e599819115374 ∧ code e599819115374 = 9395912137582 := by decide
theorem cert_e599819115374 : check e599819115374 [[.under]] .sourceHead = true := by decide
def e599819115382 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e599819115382 : Closed e599819115382 ∧ code e599819115382 = 9395912137590 := by decide
theorem cert_e599819115382 : check e599819115382 [[.under]] .sourceHead = true := by decide
def e599819115386 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e599819115386 : Closed e599819115386 ∧ code e599819115386 = 9395912137594 := by decide
theorem cert_e599819115386 : check e599819115386 [[.under]] .sourceHead = true := by decide
def e599819115446 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e599819115446 : Closed e599819115446 ∧ code e599819115446 = 9395912137654 := by decide
theorem cert_e599819115446 : check e599819115446 [[.under]] .sourceHead = true := by decide
def e599819115478 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e599819115478 : Closed e599819115478 ∧ code e599819115478 = 9395912137686 := by decide
theorem cert_e599819115478 : check e599819115478 [[.under]] .sourceHead = true := by decide
def e599819115482 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e599819115482 : Closed e599819115482 ∧ code e599819115482 = 9395912137690 := by decide
theorem cert_e599819115482 : check e599819115482 [[.under]] .sourceHead = true := by decide
def e599819115870 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e599819115870 : Closed e599819115870 ∧ code e599819115870 = 9395912138078 := by decide
theorem cert_e599819115870 : check e599819115870 [[.under]] .sourceHead = true := by decide
def e599819115886 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e599819115886 : Closed e599819115886 ∧ code e599819115886 = 9395912138094 := by decide
theorem cert_e599819115886 : check e599819115886 [[.under]] .sourceHead = true := by decide
def e599819115894 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e599819115894 : Closed e599819115894 ∧ code e599819115894 = 9395912138102 := by decide
theorem cert_e599819115894 : check e599819115894 [[.under]] .sourceHead = true := by decide
def e599819115898 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e599819115898 : Closed e599819115898 ∧ code e599819115898 = 9395912138106 := by decide
theorem cert_e599819115898 : check e599819115898 [[.under]] .sourceHead = true := by decide
def e599819115950 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e599819115950 : Closed e599819115950 ∧ code e599819115950 = 9395912138158 := by decide
theorem cert_e599819115950 : check e599819115950 [[.under]] .sourceHead = true := by decide
def e599819115962 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e599819115962 : Closed e599819115962 ∧ code e599819115962 = 9395912138170 := by decide
theorem cert_e599819115962 : check e599819115962 [[.under]] .sourceHead = true := by decide
def e599819115990 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e599819115990 : Closed e599819115990 ∧ code e599819115990 = 9395912138198 := by decide
theorem cert_e599819115990 : check e599819115990 [[.under]] .sourceHead = true := by decide
def e599819115994 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e599819115994 : Closed e599819115994 ∧ code e599819115994 = 9395912138202 := by decide
theorem cert_e599819115994 : check e599819115994 [[.under]] .sourceHead = true := by decide
def e599819116010 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e599819116010 : Closed e599819116010 ∧ code e599819116010 = 9395912138218 := by decide
theorem cert_e599819116010 : check e599819116010 [[.under]] .sourceHead = true := by decide
def e599819116214 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e599819116214 : Closed e599819116214 ∧ code e599819116214 = 9395912138422 := by decide
theorem cert_e599819116214 : check e599819116214 [[.under]] .sourceHead = true := by decide
def e599819116246 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e599819116246 : Closed e599819116246 ∧ code e599819116246 = 9395912138454 := by decide
theorem cert_e599819116246 : check e599819116246 [[.under]] .sourceHead = true := by decide
def e599819116250 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e599819116250 : Closed e599819116250 ∧ code e599819116250 = 9395912138458 := by decide
theorem cert_e599819116250 : check e599819116250 [[.under]] .sourceHead = true := by decide
def e599819116374 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e599819116374 : Closed e599819116374 ∧ code e599819116374 = 9395912138582 := by decide
theorem cert_e599819116374 : check e599819116374 [[.under]] .sourceHead = true := by decide
def e599819116378 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e599819116378 : Closed e599819116378 ∧ code e599819116378 = 9395912138586 := by decide
theorem cert_e599819116378 : check e599819116378 [[.under]] .sourceHead = true := by decide
def e599819116394 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e599819116394 : Closed e599819116394 ∧ code e599819116394 = 9395912138602 := by decide
theorem cert_e599819116394 : check e599819116394 [[.under]] .sourceHead = true := by decide
def e599819118302 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e599819118302 : Closed e599819118302 ∧ code e599819118302 = 9395912140510 := by decide
theorem cert_e599819118302 : check e599819118302 [[.under]] .sourceHead = true := by decide
def e599819118326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e599819118326 : Closed e599819118326 ∧ code e599819118326 = 9395912140534 := by decide
theorem cert_e599819118326 : check e599819118326 [[.under]] .sourceHead = true := by decide
def e599819118430 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e599819118430 : Closed e599819118430 ∧ code e599819118430 = 9395912140638 := by decide
theorem cert_e599819118430 : check e599819118430 [[.under]] .sourceHead = true := by decide
def e599819118446 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e599819118446 : Closed e599819118446 ∧ code e599819118446 = 9395912140654 := by decide
theorem cert_e599819118446 : check e599819118446 [[.under]] .sourceHead = true := by decide
def e599819118454 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e599819118454 : Closed e599819118454 ∧ code e599819118454 = 9395912140662 := by decide
theorem cert_e599819118454 : check e599819118454 [[.under]] .sourceHead = true := by decide
def e599819118458 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e599819118458 : Closed e599819118458 ∧ code e599819118458 = 9395912140666 := by decide
theorem cert_e599819118458 : check e599819118458 [[.under]] .sourceHead = true := by decide
def e599819118518 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e599819118518 : Closed e599819118518 ∧ code e599819118518 = 9395912140726 := by decide
theorem cert_e599819118518 : check e599819118518 [[.under]] .sourceHead = true := by decide
def e599819118550 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e599819118550 : Closed e599819118550 ∧ code e599819118550 = 9395912140758 := by decide
theorem cert_e599819118550 : check e599819118550 [[.under]] .sourceHead = true := by decide
def e599819118554 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e599819118554 : Closed e599819118554 ∧ code e599819118554 = 9395912140762 := by decide
theorem cert_e599819118554 : check e599819118554 [[.under]] .sourceHead = true := by decide
def e599819119070 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e599819119070 : Closed e599819119070 ∧ code e599819119070 = 9395912141278 := by decide
theorem cert_e599819119070 : check e599819119070 [[.under]] .sourceHead = true := by decide
def e599819119094 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e599819119094 : Closed e599819119094 ∧ code e599819119094 = 9395912141302 := by decide
theorem cert_e599819119094 : check e599819119094 [[.under]] .sourceHead = true := by decide
def e599819119838 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e599819119838 : Closed e599819119838 ∧ code e599819119838 = 9395912142046 := by decide
theorem cert_e599819119838 : check e599819119838 [[.under]] .sourceHead = true := by decide
def e599819119854 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e599819119854 : Closed e599819119854 ∧ code e599819119854 = 9395912142062 := by decide
theorem cert_e599819119854 : check e599819119854 [[.under]] .sourceHead = true := by decide
def e599819119862 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e599819119862 : Closed e599819119862 ∧ code e599819119862 = 9395912142070 := by decide
theorem cert_e599819119862 : check e599819119862 [[.under]] .sourceHead = true := by decide
def e599819119866 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e599819119866 : Closed e599819119866 ∧ code e599819119866 = 9395912142074 := by decide
theorem cert_e599819119866 : check e599819119866 [[.under]] .sourceHead = true := by decide
def e599819120246 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e599819120246 : Closed e599819120246 ∧ code e599819120246 = 9395912142454 := by decide
theorem cert_e599819120246 : check e599819120246 [[.under]] .sourceHead = true := by decide
def e599819120438 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e599819120438 : Closed e599819120438 ∧ code e599819120438 = 9395912142646 := by decide
theorem cert_e599819120438 : check e599819120438 [[.under]] .sourceHead = true := by decide
def e599819120442 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e599819120442 : Closed e599819120442 ∧ code e599819120442 = 9395912142650 := by decide
theorem cert_e599819120442 : check e599819120442 [[.under]] .sourceHead = true := by decide
def e599819121502 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e599819121502 : Closed e599819121502 ∧ code e599819121502 = 9395912143710 := by decide
theorem cert_e599819121502 : check e599819121502 [[.under]] .sourceHead = true := by decide
def e599819121518 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e599819121518 : Closed e599819121518 ∧ code e599819121518 = 9395912143726 := by decide
theorem cert_e599819121518 : check e599819121518 [[.under]] .sourceHead = true := by decide
def e599819121526 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e599819121526 : Closed e599819121526 ∧ code e599819121526 = 9395912143734 := by decide
theorem cert_e599819121526 : check e599819121526 [[.under]] .sourceHead = true := by decide
def e599819121530 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e599819121530 : Closed e599819121530 ∧ code e599819121530 = 9395912143738 := by decide
theorem cert_e599819121530 : check e599819121530 [[.under]] .sourceHead = true := by decide
def e599819121582 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e599819121582 : Closed e599819121582 ∧ code e599819121582 = 9395912143790 := by decide
theorem cert_e599819121582 : check e599819121582 [[.under]] .sourceHead = true := by decide
def e599819121594 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e599819121594 : Closed e599819121594 ∧ code e599819121594 = 9395912143802 := by decide
theorem cert_e599819121594 : check e599819121594 [[.under]] .sourceHead = true := by decide
def e599819121622 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e599819121622 : Closed e599819121622 ∧ code e599819121622 = 9395912143830 := by decide
theorem cert_e599819121622 : check e599819121622 [[.under]] .sourceHead = true := by decide
def e599819121626 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e599819121626 : Closed e599819121626 ∧ code e599819121626 = 9395912143834 := by decide
theorem cert_e599819121626 : check e599819121626 [[.under]] .sourceHead = true := by decide
def e599819121642 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e599819121642 : Closed e599819121642 ∧ code e599819121642 = 9395912143850 := by decide
theorem cert_e599819121642 : check e599819121642 [[.under]] .sourceHead = true := by decide
def e599819121886 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e599819121886 : Closed e599819121886 ∧ code e599819121886 = 9395912144094 := by decide
theorem cert_e599819121886 : check e599819121886 [[.under]] .sourceHead = true := by decide
def e599819121902 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e599819121902 : Closed e599819121902 ∧ code e599819121902 = 9395912144110 := by decide
theorem cert_e599819121902 : check e599819121902 [[.under]] .sourceHead = true := by decide
def e599819121910 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e599819121910 : Closed e599819121910 ∧ code e599819121910 = 9395912144118 := by decide
theorem cert_e599819121910 : check e599819121910 [[.under]] .sourceHead = true := by decide
def e599819121914 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e599819121914 : Closed e599819121914 ∧ code e599819121914 = 9395912144122 := by decide
theorem cert_e599819121914 : check e599819121914 [[.under]] .sourceHead = true := by decide
def e599819122286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e599819122286 : Closed e599819122286 ∧ code e599819122286 = 9395912144494 := by decide
theorem cert_e599819122286 : check e599819122286 [[.under]] .sourceHead = true := by decide
def e599819122298 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e599819122298 : Closed e599819122298 ∧ code e599819122298 = 9395912144506 := by decide
theorem cert_e599819122298 : check e599819122298 [[.under]] .sourceHead = true := by decide
def e599819122486 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e599819122486 : Closed e599819122486 ∧ code e599819122486 = 9395912144694 := by decide
theorem cert_e599819122486 : check e599819122486 [[.under]] .sourceHead = true := by decide
def e599819122490 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e599819122490 : Closed e599819122490 ∧ code e599819122490 = 9395912144698 := by decide
theorem cert_e599819122490 : check e599819122490 [[.under]] .sourceHead = true := by decide
def e599819122586 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e599819122586 : Closed e599819122586 ∧ code e599819122586 = 9395912144794 := by decide
theorem cert_e599819122586 : check e599819122586 [[.under]] .sourceHead = true := by decide
def e599819123126 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e599819123126 : Closed e599819123126 ∧ code e599819123126 = 9395912145334 := by decide
theorem cert_e599819123126 : check e599819123126 [[.under]] .sourceHead = true := by decide
def e599819123158 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e599819123158 : Closed e599819123158 ∧ code e599819123158 = 9395912145366 := by decide
theorem cert_e599819123158 : check e599819123158 [[.under]] .sourceHead = true := by decide
def e599819123162 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e599819123162 : Closed e599819123162 ∧ code e599819123162 = 9395912145370 := by decide
theorem cert_e599819123162 : check e599819123162 [[.under]] .sourceHead = true := by decide
def e599819123318 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e599819123318 : Closed e599819123318 ∧ code e599819123318 = 9395912145526 := by decide
theorem cert_e599819123318 : check e599819123318 [[.under]] .sourceHead = true := by decide
def e599819123510 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e599819123510 : Closed e599819123510 ∧ code e599819123510 = 9395912145718 := by decide
theorem cert_e599819123510 : check e599819123510 [[.under]] .sourceHead = true := by decide
def e599819123514 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e599819123514 : Closed e599819123514 ∧ code e599819123514 = 9395912145722 := by decide
theorem cert_e599819123514 : check e599819123514 [[.under]] .sourceHead = true := by decide
def e599819123926 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e599819123926 : Closed e599819123926 ∧ code e599819123926 = 9395912146134 := by decide
theorem cert_e599819123926 : check e599819123926 [[.under]] .sourceHead = true := by decide
def e599819123930 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e599819123930 : Closed e599819123930 ∧ code e599819123930 = 9395912146138 := by decide
theorem cert_e599819123930 : check e599819123930 [[.under]] .sourceHead = true := by decide
def e599819123946 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e599819123946 : Closed e599819123946 ∧ code e599819123946 = 9395912146154 := by decide
theorem cert_e599819123946 : check e599819123946 [[.under]] .sourceHead = true := by decide
def e599819124022 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e599819124022 : Closed e599819124022 ∧ code e599819124022 = 9395912146230 := by decide
theorem cert_e599819124022 : check e599819124022 [[.under]] .sourceHead = true := by decide
def e599819124026 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e599819124026 : Closed e599819124026 ∧ code e599819124026 = 9395912146234 := by decide
theorem cert_e599819124026 : check e599819124026 [[.under]] .sourceHead = true := by decide
def e599819124122 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e599819124122 : Closed e599819124122 ∧ code e599819124122 = 9395912146330 := by decide
theorem cert_e599819124122 : check e599819124122 [[.under]] .sourceHead = true := by decide
def e599819130590 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e599819130590 : Closed e599819130590 ∧ code e599819130590 = 9395912152798 := by decide
theorem cert_e599819130590 : check e599819130590 [[.under]] .sourceHead = true := by decide
def e599819130614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e599819130614 : Closed e599819130614 ∧ code e599819130614 = 9395912152822 := by decide
theorem cert_e599819130614 : check e599819130614 [[.under]] .sourceHead = true := by decide
def e599819130718 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e599819130718 : Closed e599819130718 ∧ code e599819130718 = 9395912152926 := by decide
theorem cert_e599819130718 : check e599819130718 [[.under]] .sourceHead = true := by decide
def e599819130734 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e599819130734 : Closed e599819130734 ∧ code e599819130734 = 9395912152942 := by decide
theorem cert_e599819130734 : check e599819130734 [[.under]] .sourceHead = true := by decide
def e599819130742 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e599819130742 : Closed e599819130742 ∧ code e599819130742 = 9395912152950 := by decide
theorem cert_e599819130742 : check e599819130742 [[.under]] .sourceHead = true := by decide
def e599819130746 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e599819130746 : Closed e599819130746 ∧ code e599819130746 = 9395912152954 := by decide
theorem cert_e599819130746 : check e599819130746 [[.under]] .sourceHead = true := by decide
def e599819130806 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e599819130806 : Closed e599819130806 ∧ code e599819130806 = 9395912153014 := by decide
theorem cert_e599819130806 : check e599819130806 [[.under]] .sourceHead = true := by decide
def e599819130838 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e599819130838 : Closed e599819130838 ∧ code e599819130838 = 9395912153046 := by decide
theorem cert_e599819130838 : check e599819130838 [[.under]] .sourceHead = true := by decide
def e599819130842 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e599819130842 : Closed e599819130842 ∧ code e599819130842 = 9395912153050 := by decide
theorem cert_e599819130842 : check e599819130842 [[.under]] .sourceHead = true := by decide
def e599819131358 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e599819131358 : Closed e599819131358 ∧ code e599819131358 = 9395912153566 := by decide
theorem cert_e599819131358 : check e599819131358 [[.under]] .sourceHead = true := by decide
def e599819131382 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e599819131382 : Closed e599819131382 ∧ code e599819131382 = 9395912153590 := by decide
theorem cert_e599819131382 : check e599819131382 [[.under]] .sourceHead = true := by decide
def e599819132126 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e599819132126 : Closed e599819132126 ∧ code e599819132126 = 9395912154334 := by decide
theorem cert_e599819132126 : check e599819132126 [[.under]] .sourceHead = true := by decide
def e599819132142 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e599819132142 : Closed e599819132142 ∧ code e599819132142 = 9395912154350 := by decide
theorem cert_e599819132142 : check e599819132142 [[.under]] .sourceHead = true := by decide
def e599819132150 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e599819132150 : Closed e599819132150 ∧ code e599819132150 = 9395912154358 := by decide
theorem cert_e599819132150 : check e599819132150 [[.under]] .sourceHead = true := by decide
def e599819132154 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e599819132154 : Closed e599819132154 ∧ code e599819132154 = 9395912154362 := by decide
theorem cert_e599819132154 : check e599819132154 [[.under]] .sourceHead = true := by decide
def e599819132534 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e599819132534 : Closed e599819132534 ∧ code e599819132534 = 9395912154742 := by decide
theorem cert_e599819132534 : check e599819132534 [[.under]] .sourceHead = true := by decide
def e599819132726 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e599819132726 : Closed e599819132726 ∧ code e599819132726 = 9395912154934 := by decide
theorem cert_e599819132726 : check e599819132726 [[.under]] .sourceHead = true := by decide
def e599819132730 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e599819132730 : Closed e599819132730 ∧ code e599819132730 = 9395912154938 := by decide
theorem cert_e599819132730 : check e599819132730 [[.under]] .sourceHead = true := by decide
def e599819144030 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e599819144030 : Closed e599819144030 ∧ code e599819144030 = 9395912166238 := by decide
theorem cert_e599819144030 : check e599819144030 [[.under]] .sourceHead = true := by decide
def e599819144046 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e599819144046 : Closed e599819144046 ∧ code e599819144046 = 9395912166254 := by decide
theorem cert_e599819144046 : check e599819144046 [[.under]] .sourceHead = true := by decide
def e599819144054 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e599819144054 : Closed e599819144054 ∧ code e599819144054 = 9395912166262 := by decide
theorem cert_e599819144054 : check e599819144054 [[.under]] .sourceHead = true := by decide
def e599819144058 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e599819144058 : Closed e599819144058 ∧ code e599819144058 = 9395912166266 := by decide
theorem cert_e599819144058 : check e599819144058 [[.under]] .sourceHead = true := by decide
def e599819144110 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e599819144110 : Closed e599819144110 ∧ code e599819144110 = 9395912166318 := by decide
theorem cert_e599819144110 : check e599819144110 [[.under]] .sourceHead = true := by decide
def e599819144122 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e599819144122 : Closed e599819144122 ∧ code e599819144122 = 9395912166330 := by decide
theorem cert_e599819144122 : check e599819144122 [[.under]] .sourceHead = true := by decide
def e599819144150 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e599819144150 : Closed e599819144150 ∧ code e599819144150 = 9395912166358 := by decide
theorem cert_e599819144150 : check e599819144150 [[.under]] .sourceHead = true := by decide
def e599819144154 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e599819144154 : Closed e599819144154 ∧ code e599819144154 = 9395912166362 := by decide
theorem cert_e599819144154 : check e599819144154 [[.under]] .sourceHead = true := by decide
def e599819144170 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e599819144170 : Closed e599819144170 ∧ code e599819144170 = 9395912166378 := by decide
theorem cert_e599819144170 : check e599819144170 [[.under]] .sourceHead = true := by decide
def e599819144414 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e599819144414 : Closed e599819144414 ∧ code e599819144414 = 9395912166622 := by decide
theorem cert_e599819144414 : check e599819144414 [[.under]] .sourceHead = true := by decide
def e599819144430 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e599819144430 : Closed e599819144430 ∧ code e599819144430 = 9395912166638 := by decide
theorem cert_e599819144430 : check e599819144430 [[.under]] .sourceHead = true := by decide
def e599819144438 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e599819144438 : Closed e599819144438 ∧ code e599819144438 = 9395912166646 := by decide
theorem cert_e599819144438 : check e599819144438 [[.under]] .sourceHead = true := by decide
def e599819144442 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e599819144442 : Closed e599819144442 ∧ code e599819144442 = 9395912166650 := by decide
theorem cert_e599819144442 : check e599819144442 [[.under]] .sourceHead = true := by decide
def e599819144814 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e599819144814 : Closed e599819144814 ∧ code e599819144814 = 9395912167022 := by decide
theorem cert_e599819144814 : check e599819144814 [[.under]] .sourceHead = true := by decide
def e599819144826 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e599819144826 : Closed e599819144826 ∧ code e599819144826 = 9395912167034 := by decide
theorem cert_e599819144826 : check e599819144826 [[.under]] .sourceHead = true := by decide
def e599819145014 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e599819145014 : Closed e599819145014 ∧ code e599819145014 = 9395912167222 := by decide
theorem cert_e599819145014 : check e599819145014 [[.under]] .sourceHead = true := by decide
def e599819145018 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e599819145018 : Closed e599819145018 ∧ code e599819145018 = 9395912167226 := by decide
theorem cert_e599819145018 : check e599819145018 [[.under]] .sourceHead = true := by decide
def e599819145114 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e599819145114 : Closed e599819145114 ∧ code e599819145114 = 9395912167322 := by decide
theorem cert_e599819145114 : check e599819145114 [[.under]] .sourceHead = true := by decide
def e599819150774 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e599819150774 : Closed e599819150774 ∧ code e599819150774 = 9395912172982 := by decide
theorem cert_e599819150774 : check e599819150774 [[.under]] .sourceHead = true := by decide
def e599819150806 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e599819150806 : Closed e599819150806 ∧ code e599819150806 = 9395912173014 := by decide
theorem cert_e599819150806 : check e599819150806 [[.under]] .sourceHead = true := by decide
def e599819150810 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e599819150810 : Closed e599819150810 ∧ code e599819150810 = 9395912173018 := by decide
theorem cert_e599819150810 : check e599819150810 [[.under]] .sourceHead = true := by decide
def e599819150966 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e599819150966 : Closed e599819150966 ∧ code e599819150966 = 9395912173174 := by decide
theorem cert_e599819150966 : check e599819150966 [[.under]] .sourceHead = true := by decide
def e599819151158 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e599819151158 : Closed e599819151158 ∧ code e599819151158 = 9395912173366 := by decide
theorem cert_e599819151158 : check e599819151158 [[.under]] .sourceHead = true := by decide
def e599819151162 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e599819151162 : Closed e599819151162 ∧ code e599819151162 = 9395912173370 := by decide
theorem cert_e599819151162 : check e599819151162 [[.under]] .sourceHead = true := by decide
def e599819154134 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e599819154134 : Closed e599819154134 ∧ code e599819154134 = 9395912176342 := by decide
theorem cert_e599819154134 : check e599819154134 [[.under]] .sourceHead = true := by decide
def e599819154138 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e599819154138 : Closed e599819154138 ∧ code e599819154138 = 9395912176346 := by decide
theorem cert_e599819154138 : check e599819154138 [[.under]] .sourceHead = true := by decide
def e599819154154 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e599819154154 : Closed e599819154154 ∧ code e599819154154 = 9395912176362 := by decide
theorem cert_e599819154154 : check e599819154154 [[.under]] .sourceHead = true := by decide
def e599819154230 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e599819154230 : Closed e599819154230 ∧ code e599819154230 = 9395912176438 := by decide
theorem cert_e599819154230 : check e599819154230 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
