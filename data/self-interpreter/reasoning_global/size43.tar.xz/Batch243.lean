import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393383301430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393383301430 : Closed e2393383301430 ∧ code e2393383301430 = 11189476323638 := by decide
theorem cert_e2393383301430 : check e2393383301430 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393383301434 : Closed e2393383301434 ∧ code e2393383301434 = 11189476323642 := by decide
theorem cert_e2393383301434 : check e2393383301434 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2393383301518 : Closed e2393383301518 ∧ code e2393383301518 = 11189476323726 := by decide
theorem cert_e2393383301518 : check e2393383301518 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2393383301574 : Closed e2393383301574 ∧ code e2393383301574 = 11189476323782 := by decide
theorem cert_e2393383301574 : check e2393383301574 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2393383301910 : Closed e2393383301910 ∧ code e2393383301910 = 11189476324118 := by decide
theorem cert_e2393383301910 : check e2393383301910 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2393383301986 : Closed e2393383301986 ∧ code e2393383301986 = 11189476324194 := by decide
theorem cert_e2393383301986 : check e2393383301986 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383301998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393383301998 : Closed e2393383301998 ∧ code e2393383301998 = 11189476324206 := by decide
theorem cert_e2393383301998 : check e2393383301998 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393383302006 : Closed e2393383302006 ∧ code e2393383302006 = 11189476324214 := by decide
theorem cert_e2393383302006 : check e2393383302006 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393383302026 : Closed e2393383302026 ∧ code e2393383302026 = 11189476324234 := by decide
theorem cert_e2393383302026 : check e2393383302026 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393383302050 : Closed e2393383302050 ∧ code e2393383302050 = 11189476324258 := by decide
theorem cert_e2393383302050 : check e2393383302050 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393383302062 : Closed e2393383302062 ∧ code e2393383302062 = 11189476324270 := by decide
theorem cert_e2393383302062 : check e2393383302062 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393383302074 : Closed e2393383302074 ∧ code e2393383302074 = 11189476324282 := by decide
theorem cert_e2393383302074 : check e2393383302074 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393383302102 : Closed e2393383302102 ∧ code e2393383302102 = 11189476324310 := by decide
theorem cert_e2393383302102 : check e2393383302102 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393383302106 : Closed e2393383302106 ∧ code e2393383302106 = 11189476324314 := by decide
theorem cert_e2393383302106 : check e2393383302106 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2393383302174 : Closed e2393383302174 ∧ code e2393383302174 = 11189476324382 := by decide
theorem cert_e2393383302174 : check e2393383302174 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393383302370 : Closed e2393383302370 ∧ code e2393383302370 = 11189476324578 := by decide
theorem cert_e2393383302370 : check e2393383302370 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393383302382 : Closed e2393383302382 ∧ code e2393383302382 = 11189476324590 := by decide
theorem cert_e2393383302382 : check e2393383302382 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393383302390 : Closed e2393383302390 ∧ code e2393383302390 = 11189476324598 := by decide
theorem cert_e2393383302390 : check e2393383302390 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393383302670 : Closed e2393383302670 ∧ code e2393383302670 = 11189476324878 := by decide
theorem cert_e2393383302670 : check e2393383302670 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393383302754 : Closed e2393383302754 ∧ code e2393383302754 = 11189476324962 := by decide
theorem cert_e2393383302754 : check e2393383302754 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393383302766 : Closed e2393383302766 ∧ code e2393383302766 = 11189476324974 := by decide
theorem cert_e2393383302766 : check e2393383302766 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393383302778 : Closed e2393383302778 ∧ code e2393383302778 = 11189476324986 := by decide
theorem cert_e2393383302778 : check e2393383302778 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393383302966 : Closed e2393383302966 ∧ code e2393383302966 = 11189476325174 := by decide
theorem cert_e2393383302966 : check e2393383302966 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383302970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393383302970 : Closed e2393383302970 ∧ code e2393383302970 = 11189476325178 := by decide
theorem cert_e2393383302970 : check e2393383302970 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383308142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393383308142 : Closed e2393383308142 ∧ code e2393383308142 = 11189476330350 := by decide
theorem cert_e2393383308142 : check e2393383308142 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393383308150 : Closed e2393383308150 ∧ code e2393383308150 = 11189476330358 := by decide
theorem cert_e2393383308150 : check e2393383308150 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393383308206 : Closed e2393383308206 ∧ code e2393383308206 = 11189476330414 := by decide
theorem cert_e2393383308206 : check e2393383308206 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393383308218 : Closed e2393383308218 ∧ code e2393383308218 = 11189476330426 := by decide
theorem cert_e2393383308218 : check e2393383308218 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393383308246 : Closed e2393383308246 ∧ code e2393383308246 = 11189476330454 := by decide
theorem cert_e2393383308246 : check e2393383308246 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393383308250 : Closed e2393383308250 ∧ code e2393383308250 = 11189476330458 := by decide
theorem cert_e2393383308250 : check e2393383308250 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393383308526 : Closed e2393383308526 ∧ code e2393383308526 = 11189476330734 := by decide
theorem cert_e2393383308526 : check e2393383308526 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393383308534 : Closed e2393383308534 ∧ code e2393383308534 = 11189476330742 := by decide
theorem cert_e2393383308534 : check e2393383308534 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393383308910 : Closed e2393383308910 ∧ code e2393383308910 = 11189476331118 := by decide
theorem cert_e2393383308910 : check e2393383308910 [[],[.left],[],[]] .smaller = true := by decide
def e2393383308922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393383308922 : Closed e2393383308922 ∧ code e2393383308922 = 11189476331130 := by decide
theorem cert_e2393383308922 : check e2393383308922 [[],[.left],[],[]] .smaller = true := by decide
def e2393383309110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393383309110 : Closed e2393383309110 ∧ code e2393383309110 = 11189476331318 := by decide
theorem cert_e2393383309110 : check e2393383309110 [[],[.left],[],[]] .smaller = true := by decide
def e2393383309114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393383309114 : Closed e2393383309114 ∧ code e2393383309114 = 11189476331322 := by decide
theorem cert_e2393383309114 : check e2393383309114 [[],[.left],[],[]] .smaller = true := by decide
def e2393383317038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2393383317038 : Closed e2393383317038 ∧ code e2393383317038 = 11189476339246 := by decide
theorem cert_e2393383317038 : check e2393383317038 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383317218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2393383317218 : Closed e2393383317218 ∧ code e2393383317218 = 11189476339426 := by decide
theorem cert_e2393383317218 : check e2393383317218 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383317230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2393383317230 : Closed e2393383317230 ∧ code e2393383317230 = 11189476339438 := by decide
theorem cert_e2393383317230 : check e2393383317230 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383317270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2393383317270 : Closed e2393383317270 ∧ code e2393383317270 = 11189476339478 := by decide
theorem cert_e2393383317270 : check e2393383317270 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383317346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2393383317346 : Closed e2393383317346 ∧ code e2393383317346 = 11189476339554 := by decide
theorem cert_e2393383317346 : check e2393383317346 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383317358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2393383317358 : Closed e2393383317358 ∧ code e2393383317358 = 11189476339566 := by decide
theorem cert_e2393383317358 : check e2393383317358 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383317366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2393383317366 : Closed e2393383317366 ∧ code e2393383317366 = 11189476339574 := by decide
theorem cert_e2393383317366 : check e2393383317366 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383319614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2393383319614 : Closed e2393383319614 ∧ code e2393383319614 = 11189476341822 := by decide
theorem cert_e2393383319614 : check e2393383319614 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383320034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2393383320034 : Closed e2393383320034 ∧ code e2393383320034 = 11189476342242 := by decide
theorem cert_e2393383320034 : check e2393383320034 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383320046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393383320046 : Closed e2393383320046 ∧ code e2393383320046 = 11189476342254 := by decide
theorem cert_e2393383320046 : check e2393383320046 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383320606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2393383320606 : Closed e2393383320606 ∧ code e2393383320606 = 11189476342814 := by decide
theorem cert_e2393383320606 : check e2393383320606 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383320802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2393383320802 : Closed e2393383320802 ∧ code e2393383320802 = 11189476343010 := by decide
theorem cert_e2393383320802 : check e2393383320802 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383320814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393383320814 : Closed e2393383320814 ∧ code e2393383320814 = 11189476343022 := by decide
theorem cert_e2393383320814 : check e2393383320814 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383320822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393383320822 : Closed e2393383320822 ∧ code e2393383320822 = 11189476343030 := by decide
theorem cert_e2393383320822 : check e2393383320822 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383343662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2393383343662 : Closed e2393383343662 ∧ code e2393383343662 = 11189476365870 := by decide
theorem cert_e2393383343662 : check e2393383343662 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383343842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2393383343842 : Closed e2393383343842 ∧ code e2393383343842 = 11189476366050 := by decide
theorem cert_e2393383343842 : check e2393383343842 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383343854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2393383343854 : Closed e2393383343854 ∧ code e2393383343854 = 11189476366062 := by decide
theorem cert_e2393383343854 : check e2393383343854 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383344010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393383344010 : Closed e2393383344010 ∧ code e2393383344010 = 11189476366218 := by decide
theorem cert_e2393383344010 : check e2393383344010 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383344034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393383344034 : Closed e2393383344034 ∧ code e2393383344034 = 11189476366242 := by decide
theorem cert_e2393383344034 : check e2393383344034 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383344046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2393383344046 : Closed e2393383344046 ∧ code e2393383344046 = 11189476366254 := by decide
theorem cert_e2393383344046 : check e2393383344046 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383344058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2393383344058 : Closed e2393383344058 ∧ code e2393383344058 = 11189476366266 := by decide
theorem cert_e2393383344058 : check e2393383344058 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383344190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2393383344190 : Closed e2393383344190 ∧ code e2393383344190 = 11189476366398 := by decide
theorem cert_e2393383344190 : check e2393383344190 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383344610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2393383344610 : Closed e2393383344610 ∧ code e2393383344610 = 11189476366818 := by decide
theorem cert_e2393383344610 : check e2393383344610 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383344622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2393383344622 : Closed e2393383344622 ∧ code e2393383344622 = 11189476366830 := by decide
theorem cert_e2393383344622 : check e2393383344622 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383345678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2393383345678 : Closed e2393383345678 ∧ code e2393383345678 = 11189476367886 := by decide
theorem cert_e2393383345678 : check e2393383345678 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383345762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393383345762 : Closed e2393383345762 ∧ code e2393383345762 = 11189476367970 := by decide
theorem cert_e2393383345762 : check e2393383345762 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383345774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393383345774 : Closed e2393383345774 ∧ code e2393383345774 = 11189476367982 := by decide
theorem cert_e2393383345774 : check e2393383345774 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383345786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393383345786 : Closed e2393383345786 ∧ code e2393383345786 = 11189476367994 := by decide
theorem cert_e2393383345786 : check e2393383345786 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2393383357206 : Closed e2393383357206 ∧ code e2393383357206 = 11189476379414 := by decide
theorem cert_e2393383357206 : check e2393383357206 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2393383357282 : Closed e2393383357282 ∧ code e2393383357282 = 11189476379490 := by decide
theorem cert_e2393383357282 : check e2393383357282 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393383357294 : Closed e2393383357294 ∧ code e2393383357294 = 11189476379502 := by decide
theorem cert_e2393383357294 : check e2393383357294 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393383357302 : Closed e2393383357302 ∧ code e2393383357302 = 11189476379510 := by decide
theorem cert_e2393383357302 : check e2393383357302 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393383357322 : Closed e2393383357322 ∧ code e2393383357322 = 11189476379530 := by decide
theorem cert_e2393383357322 : check e2393383357322 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393383357346 : Closed e2393383357346 ∧ code e2393383357346 = 11189476379554 := by decide
theorem cert_e2393383357346 : check e2393383357346 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393383357358 : Closed e2393383357358 ∧ code e2393383357358 = 11189476379566 := by decide
theorem cert_e2393383357358 : check e2393383357358 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393383357370 : Closed e2393383357370 ∧ code e2393383357370 = 11189476379578 := by decide
theorem cert_e2393383357370 : check e2393383357370 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393383357398 : Closed e2393383357398 ∧ code e2393383357398 = 11189476379606 := by decide
theorem cert_e2393383357398 : check e2393383357398 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393383357402 : Closed e2393383357402 ∧ code e2393383357402 = 11189476379610 := by decide
theorem cert_e2393383357402 : check e2393383357402 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2393383357470 : Closed e2393383357470 ∧ code e2393383357470 = 11189476379678 := by decide
theorem cert_e2393383357470 : check e2393383357470 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2393383357666 : Closed e2393383357666 ∧ code e2393383357666 = 11189476379874 := by decide
theorem cert_e2393383357666 : check e2393383357666 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393383357678 : Closed e2393383357678 ∧ code e2393383357678 = 11189476379886 := by decide
theorem cert_e2393383357678 : check e2393383357678 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393383357686 : Closed e2393383357686 ∧ code e2393383357686 = 11189476379894 := by decide
theorem cert_e2393383357686 : check e2393383357686 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383357966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2393383357966 : Closed e2393383357966 ∧ code e2393383357966 = 11189476380174 := by decide
theorem cert_e2393383357966 : check e2393383357966 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383358050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393383358050 : Closed e2393383358050 ∧ code e2393383358050 = 11189476380258 := by decide
theorem cert_e2393383358050 : check e2393383358050 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383358062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393383358062 : Closed e2393383358062 ∧ code e2393383358062 = 11189476380270 := by decide
theorem cert_e2393383358062 : check e2393383358062 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383358074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393383358074 : Closed e2393383358074 ∧ code e2393383358074 = 11189476380282 := by decide
theorem cert_e2393383358074 : check e2393383358074 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383358262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393383358262 : Closed e2393383358262 ∧ code e2393383358262 = 11189476380470 := by decide
theorem cert_e2393383358262 : check e2393383358262 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383358266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393383358266 : Closed e2393383358266 ∧ code e2393383358266 = 11189476380474 := by decide
theorem cert_e2393383358266 : check e2393383358266 [[],[.left],[],[]] .sourceHead = true := by decide
def e2393383897966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393383897966 : Closed e2393383897966 ∧ code e2393383897966 = 11189476920174 := by decide
theorem cert_e2393383897966 : check e2393383897966 [[],[.left],[],[]] .smaller = true := by decide
def e2393383897974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393383897974 : Closed e2393383897974 ∧ code e2393383897974 = 11189476920182 := by decide
theorem cert_e2393383897974 : check e2393383897974 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393383898030 : Closed e2393383898030 ∧ code e2393383898030 = 11189476920238 := by decide
theorem cert_e2393383898030 : check e2393383898030 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393383898042 : Closed e2393383898042 ∧ code e2393383898042 = 11189476920250 := by decide
theorem cert_e2393383898042 : check e2393383898042 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393383898070 : Closed e2393383898070 ∧ code e2393383898070 = 11189476920278 := by decide
theorem cert_e2393383898070 : check e2393383898070 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393383898074 : Closed e2393383898074 ∧ code e2393383898074 = 11189476920282 := by decide
theorem cert_e2393383898074 : check e2393383898074 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393383898350 : Closed e2393383898350 ∧ code e2393383898350 = 11189476920558 := by decide
theorem cert_e2393383898350 : check e2393383898350 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393383898358 : Closed e2393383898358 ∧ code e2393383898358 = 11189476920566 := by decide
theorem cert_e2393383898358 : check e2393383898358 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393383898734 : Closed e2393383898734 ∧ code e2393383898734 = 11189476920942 := by decide
theorem cert_e2393383898734 : check e2393383898734 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393383898746 : Closed e2393383898746 ∧ code e2393383898746 = 11189476920954 := by decide
theorem cert_e2393383898746 : check e2393383898746 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393383898934 : Closed e2393383898934 ∧ code e2393383898934 = 11189476921142 := by decide
theorem cert_e2393383898934 : check e2393383898934 [[],[.left],[],[]] .smaller = true := by decide
def e2393383898938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393383898938 : Closed e2393383898938 ∧ code e2393383898938 = 11189476921146 := by decide
theorem cert_e2393383898938 : check e2393383898938 [[],[.left],[],[]] .smaller = true := by decide
def e2393385229790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2393385229790 : Closed e2393385229790 ∧ code e2393385229790 = 11189478251998 := by decide
theorem cert_e2393385229790 : check e2393385229790 [[],[.left],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393385229806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2393385229806 : Closed e2393385229806 ∧ code e2393385229806 = 11189478252014 := by decide
private def t_e2393385229806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem cert_e2393385229806 : ¬ IsSelfInterpreter e2393385229806 :=
  wSource (t := t_e2393385229806) (replay_sound (ps := []) (t := e2393385229806) (by decide)) (by decide)
def e2393385230046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2393385230046 : Closed e2393385230046 ∧ code e2393385230046 = 11189478252254 := by decide
theorem cert_e2393385230046 : check e2393385230046 [[],[.left],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2393385230070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2393385230070 : Closed e2393385230070 ∧ code e2393385230070 = 11189478252278 := by decide
theorem cert_e2393385230070 : check e2393385230070 [[],[.left],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2393385230190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2393385230190 : Closed e2393385230190 ∧ code e2393385230190 = 11189478252398 := by decide
private def t_e2393385230190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem cert_e2393385230190 : ¬ IsSelfInterpreter e2393385230190 :=
  wSource (t := t_e2393385230190) (replay_sound (ps := []) (t := e2393385230190) (by decide)) (by decide)
def e2393385230198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2393385230198 : Closed e2393385230198 ∧ code e2393385230198 = 11189478252406 := by decide
theorem cert_e2393385230198 : check e2393385230198 [[],[.left],[],[],[.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2393385235422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2393385235422 : Closed e2393385235422 ∧ code e2393385235422 = 11189478257630 := by decide
theorem cert_e2393385235422 : check e2393385235422 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2393385235438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2393385235438 : Closed e2393385235438 ∧ code e2393385235438 = 11189478257646 := by decide
theorem cert_e2393385235438 : check e2393385235438 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2393385236958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2393385236958 : Closed e2393385236958 ∧ code e2393385236958 = 11189478259166 := by decide
theorem cert_e2393385236958 : check e2393385236958 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2393385236982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2393385236982 : Closed e2393385236982 ∧ code e2393385236982 = 11189478259190 := by decide
theorem cert_e2393385236982 : check e2393385236982 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2393385237742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393385237742 : Closed e2393385237742 ∧ code e2393385237742 = 11189478259950 := by decide
theorem cert_e2393385237742 : check e2393385237742 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2393385237750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393385237750 : Closed e2393385237750 ∧ code e2393385237750 = 11189478259958 := by decide
theorem cert_e2393385237750 : check e2393385237750 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2393385294702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2393385294702 : Closed e2393385294702 ∧ code e2393385294702 = 11189478316910 := by decide
theorem cert_e2393385294702 : check e2393385294702 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2393385294710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2393385294710 : Closed e2393385294710 ∧ code e2393385294710 = 11189478316918 := by decide
theorem cert_e2393385294710 : check e2393385294710 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2393385294774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2393385294774 : Closed e2393385294774 ∧ code e2393385294774 = 11189478316982 := by decide
private def t_e2393385294774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem cert_e2393385294774 : ¬ IsSelfInterpreter e2393385294774 :=
  wSource (t := t_e2393385294774) (replay_sound (ps := []) (t := e2393385294774) (by decide)) (by decide)
def e2393385295214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2393385295214 : Closed e2393385295214 ∧ code e2393385295214 = 11189478317422 := by decide
theorem cert_e2393385295214 : check e2393385295214 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e2393385295222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2393385295222 : Closed e2393385295222 ∧ code e2393385295222 = 11189478317430 := by decide
theorem cert_e2393385295222 : check e2393385295222 [[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e2393385295278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2393385295278 : Closed e2393385295278 ∧ code e2393385295278 = 11189478317486 := by decide
def e2393385295290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2393385295290 : Closed e2393385295290 ∧ code e2393385295290 = 11189478317498 := by decide
def e2393385295318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2393385295318 : Closed e2393385295318 ∧ code e2393385295318 = 11189478317526 := by decide
def e2393385295322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2393385295322 : Closed e2393385295322 ∧ code e2393385295322 = 11189478317530 := by decide
def e2393385295542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2393385295542 : Closed e2393385295542 ∧ code e2393385295542 = 11189478317750 := by decide
private def t_e2393385295542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem cert_e2393385295542 : ¬ IsSelfInterpreter e2393385295542 :=
  wSource (t := t_e2393385295542) (replay_sound (ps := []) (t := e2393385295542) (by decide)) (by decide)
def e2393385295574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2393385295574 : Closed e2393385295574 ∧ code e2393385295574 = 11189478317782 := by decide
def e2393385295578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2393385295578 : Closed e2393385295578 ∧ code e2393385295578 = 11189478317786 := by decide
def e2393385297774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2393385297774 : Closed e2393385297774 ∧ code e2393385297774 = 11189478319982 := by decide
theorem cert_e2393385297774 : check e2393385297774 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393385297782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2393385297782 : Closed e2393385297782 ∧ code e2393385297782 = 11189478319990 := by decide
theorem cert_e2393385297782 : check e2393385297782 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393385297846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2393385297846 : Closed e2393385297846 ∧ code e2393385297846 = 11189478320054 := by decide
def e2393385299182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393385299182 : Closed e2393385299182 ∧ code e2393385299182 = 11189478321390 := by decide
theorem cert_e2393385299182 : check e2393385299182 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393385299190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393385299190 : Closed e2393385299190 ∧ code e2393385299190 = 11189478321398 := by decide
theorem cert_e2393385299190 : check e2393385299190 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393385299574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393385299574 : Closed e2393385299574 ∧ code e2393385299574 = 11189478321782 := by decide
private def t_e2393385299574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem cert_e2393385299574 : ¬ IsSelfInterpreter e2393385299574 :=
  wSource (t := t_e2393385299574) (replay_sound (ps := []) (t := e2393385299574) (by decide)) (by decide)
def e2393385300846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2393385300846 : Closed e2393385300846 ∧ code e2393385300846 = 11189478323054 := by decide
theorem cert_e2393385300846 : check e2393385300846 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e2393385300854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2393385300854 : Closed e2393385300854 ∧ code e2393385300854 = 11189478323062 := by decide
theorem cert_e2393385300854 : check e2393385300854 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e2393385300910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2393385300910 : Closed e2393385300910 ∧ code e2393385300910 = 11189478323118 := by decide
def e2393385300922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2393385300922 : Closed e2393385300922 ∧ code e2393385300922 = 11189478323130 := by decide
def e2393385300950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2393385300950 : Closed e2393385300950 ∧ code e2393385300950 = 11189478323158 := by decide
def e2393385300954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2393385300954 : Closed e2393385300954 ∧ code e2393385300954 = 11189478323162 := by decide
def e2393385301230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393385301230 : Closed e2393385301230 ∧ code e2393385301230 = 11189478323438 := by decide
theorem cert_e2393385301230 : check e2393385301230 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393385301238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393385301238 : Closed e2393385301238 ∧ code e2393385301238 = 11189478323446 := by decide
theorem cert_e2393385301238 : check e2393385301238 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393385301614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393385301614 : Closed e2393385301614 ∧ code e2393385301614 = 11189478323822 := by decide
def e2393385301626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393385301626 : Closed e2393385301626 ∧ code e2393385301626 = 11189478323834 := by decide
def e2393385301814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393385301814 : Closed e2393385301814 ∧ code e2393385301814 = 11189478324022 := by decide
def e2393385301818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393385301818 : Closed e2393385301818 ∧ code e2393385301818 = 11189478324026 := by decide
def e2393385302454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2393385302454 : Closed e2393385302454 ∧ code e2393385302454 = 11189478324662 := by decide
theorem cert_e2393385302454 : check e2393385302454 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2393385302486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2393385302486 : Closed e2393385302486 ∧ code e2393385302486 = 11189478324694 := by decide
def e2393385302490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2393385302490 : Closed e2393385302490 ∧ code e2393385302490 = 11189478324698 := by decide
def e2393385302646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393385302646 : Closed e2393385302646 ∧ code e2393385302646 = 11189478324854 := by decide
private def t_e2393385302646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem cert_e2393385302646 : ¬ IsSelfInterpreter e2393385302646 :=
  wSource (t := t_e2393385302646) (replay_sound (ps := []) (t := e2393385302646) (by decide)) (by decide)
def e2393385302838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393385302838 : Closed e2393385302838 ∧ code e2393385302838 = 11189478325046 := by decide
def e2393385302842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393385302842 : Closed e2393385302842 ∧ code e2393385302842 = 11189478325050 := by decide
def e2393385310062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2393385310062 : Closed e2393385310062 ∧ code e2393385310062 = 11189478332270 := by decide
def e2393385310070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2393385310070 : Closed e2393385310070 ∧ code e2393385310070 = 11189478332278 := by decide
def e2393385310134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2393385310134 : Closed e2393385310134 ∧ code e2393385310134 = 11189478332342 := by decide
def e2393385311470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393385311470 : Closed e2393385311470 ∧ code e2393385311470 = 11189478333678 := by decide
def e2393385311478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393385311478 : Closed e2393385311478 ∧ code e2393385311478 = 11189478333686 := by decide
def e2393385311862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393385311862 : Closed e2393385311862 ∧ code e2393385311862 = 11189478334070 := by decide
def e2393385323374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393385323374 : Closed e2393385323374 ∧ code e2393385323374 = 11189478345582 := by decide
theorem cert_e2393385323374 : check e2393385323374 [[],[.left],[],[],[.under],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2393385323382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393385323382 : Closed e2393385323382 ∧ code e2393385323382 = 11189478345590 := by decide
theorem cert_e2393385323382 : check e2393385323382 [[],[.left],[],[],[.under],[.under],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2393385323438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393385323438 : Closed e2393385323438 ∧ code e2393385323438 = 11189478345646 := by decide
def e2393385323450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393385323450 : Closed e2393385323450 ∧ code e2393385323450 = 11189478345658 := by decide
def e2393385323478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393385323478 : Closed e2393385323478 ∧ code e2393385323478 = 11189478345686 := by decide
def e2393385323482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393385323482 : Closed e2393385323482 ∧ code e2393385323482 = 11189478345690 := by decide
def e2393385323758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393385323758 : Closed e2393385323758 ∧ code e2393385323758 = 11189478345966 := by decide
def e2393385323766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393385323766 : Closed e2393385323766 ∧ code e2393385323766 = 11189478345974 := by decide
def e2393385324142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393385324142 : Closed e2393385324142 ∧ code e2393385324142 = 11189478346350 := by decide
def e2393385324154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393385324154 : Closed e2393385324154 ∧ code e2393385324154 = 11189478346362 := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393385229806
#print axioms Blc.Floor43.cert_e2393385230190
#print axioms Blc.Floor43.cert_e2393385294774
#print axioms Blc.Floor43.cert_e2393385295542
#print axioms Blc.Floor43.cert_e2393385299574
#print axioms Blc.Floor43.cert_e2393385302646
