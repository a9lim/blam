import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406203546138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406203546138 : Closed e2406203546138 ∧ code e2406203546138 = 11202296568346 := by decide
theorem cert_e2406203546138 : check e2406203546138 [[]] .width = true := by decide
def e2406203546210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406203546210 : Closed e2406203546210 ∧ code e2406203546210 = 11202296568418 := by decide
theorem cert_e2406203546210 : check e2406203546210 [[]] .width = true := by decide
def e2406203547674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406203547674 : Closed e2406203547674 ∧ code e2406203547674 = 11202296569882 := by decide
theorem cert_e2406203547674 : check e2406203547674 [[]] .width = true := by decide
def e2406203547758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2406203547758 : Closed e2406203547758 ∧ code e2406203547758 = 11202296569966 := by decide
theorem cert_e2406203547758 : check e2406203547758 [[]] .width = true := by decide
def e2406203547766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406203547766 : Closed e2406203547766 ∧ code e2406203547766 = 11202296569974 := by decide
theorem cert_e2406203547766 : check e2406203547766 [[]] .width = true := by decide
def e2406203547770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2406203547770 : Closed e2406203547770 ∧ code e2406203547770 = 11202296569978 := by decide
theorem cert_e2406203547770 : check e2406203547770 [[]] .width = true := by decide
def e2406203548010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406203548010 : Closed e2406203548010 ∧ code e2406203548010 = 11202296570218 := by decide
theorem cert_e2406203548010 : check e2406203548010 [[]] .width = true := by decide
def e2406203548046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406203548046 : Closed e2406203548046 ∧ code e2406203548046 = 11202296570254 := by decide
theorem cert_e2406203548046 : check e2406203548046 [[]] .width = true := by decide
def e2406203548058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406203548058 : Closed e2406203548058 ∧ code e2406203548058 = 11202296570266 := by decide
theorem cert_e2406203548058 : check e2406203548058 [[]] .width = true := by decide
def e2406203548102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406203548102 : Closed e2406203548102 ∧ code e2406203548102 = 11202296570310 := by decide
theorem cert_e2406203548102 : check e2406203548102 [[]] .width = true := by decide
def e2406203549066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2406203549066 : Closed e2406203549066 ∧ code e2406203549066 = 11202296571274 := by decide
theorem cert_e2406203549066 : check e2406203549066 [[]] .width = true := by decide
def e2406203549090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2406203549090 : Closed e2406203549090 ∧ code e2406203549090 = 11202296571298 := by decide
theorem cert_e2406203549090 : check e2406203549090 [[]] .width = true := by decide
def e2406203549186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2406203549186 : Closed e2406203549186 ∧ code e2406203549186 = 11202296571394 := by decide
theorem cert_e2406203549186 : check e2406203549186 [[]] .width = true := by decide
def e2406203549198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2406203549198 : Closed e2406203549198 ∧ code e2406203549198 = 11202296571406 := by decide
theorem cert_e2406203549198 : check e2406203549198 [[]] .width = true := by decide
def e2406203549210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406203549210 : Closed e2406203549210 ∧ code e2406203549210 = 11202296571418 := by decide
theorem cert_e2406203549210 : check e2406203549210 [[]] .width = true := by decide
def e2406203549282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2406203549282 : Closed e2406203549282 ∧ code e2406203549282 = 11202296571490 := by decide
theorem cert_e2406203549282 : check e2406203549282 [[]] .width = true := by decide
def e2406203595266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2406203595266 : Closed e2406203595266 ∧ code e2406203595266 = 11202296617474 := by decide
theorem cert_e2406203595266 : check e2406203595266 [[]] .width = true := by decide
def e2406203595290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406203595290 : Closed e2406203595290 ∧ code e2406203595290 = 11202296617498 := by decide
theorem cert_e2406203595290 : check e2406203595290 [[]] .width = true := by decide
def e2406204108314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204108314 : Closed e2406204108314 ∧ code e2406204108314 = 11202297130522 := by decide
theorem cert_e2406204108314 : check e2406204108314 [[]] .width = true := by decide
def e2406204110362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204110362 : Closed e2406204110362 ∧ code e2406204110362 = 11202297132570 := by decide
theorem cert_e2406204110362 : check e2406204110362 [[]] .width = true := by decide
def e2406204233242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204233242 : Closed e2406204233242 ∧ code e2406204233242 = 11202297255450 := by decide
theorem cert_e2406204233242 : check e2406204233242 [[]] .width = true := by decide
def e2406204234266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204234266 : Closed e2406204234266 ∧ code e2406204234266 = 11202297256474 := by decide
theorem cert_e2406204234266 : check e2406204234266 [[]] .width = true := by decide
def e2406204238362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204238362 : Closed e2406204238362 ∧ code e2406204238362 = 11202297260570 := by decide
theorem cert_e2406204238362 : check e2406204238362 [[]] .width = true := by decide
def e2406204257818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204257818 : Closed e2406204257818 ∧ code e2406204257818 = 11202297280026 := by decide
theorem cert_e2406204257818 : check e2406204257818 [[]] .width = true := by decide
def e2406204258842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204258842 : Closed e2406204258842 ∧ code e2406204258842 = 11202297281050 := by decide
theorem cert_e2406204258842 : check e2406204258842 [[]] .width = true := by decide
def e2406204268570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406204268570 : Closed e2406204268570 ∧ code e2406204268570 = 11202297290778 := by decide
theorem cert_e2406204268570 : check e2406204268570 [[]] .width = true := by decide
def e2406204268662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406204268662 : Closed e2406204268662 ∧ code e2406204268662 = 11202297290870 := by decide
theorem cert_e2406204268662 : check e2406204268662 [[]] .width = true := by decide
def e2406204268906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406204268906 : Closed e2406204268906 ∧ code e2406204268906 = 11202297291114 := by decide
theorem cert_e2406204268906 : check e2406204268906 [[]] .width = true := by decide
def e2406204268954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406204268954 : Closed e2406204268954 ∧ code e2406204268954 = 11202297291162 := by decide
theorem cert_e2406204268954 : check e2406204268954 [[]] .width = true := by decide
def e2406204283418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406204283418 : Closed e2406204283418 ∧ code e2406204283418 = 11202297305626 := by decide
theorem cert_e2406204283418 : check e2406204283418 [[]] .width = true := by decide
def e2406204284954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406204284954 : Closed e2406204284954 ∧ code e2406204284954 = 11202297307162 := by decide
theorem cert_e2406204284954 : check e2406204284954 [[]] .width = true := by decide
def e2406204285046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406204285046 : Closed e2406204285046 ∧ code e2406204285046 = 11202297307254 := by decide
theorem cert_e2406204285046 : check e2406204285046 [[]] .width = true := by decide
def e2406204285290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406204285290 : Closed e2406204285290 ∧ code e2406204285290 = 11202297307498 := by decide
theorem cert_e2406204285290 : check e2406204285290 [[]] .width = true := by decide
def e2406204285338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406204285338 : Closed e2406204285338 ∧ code e2406204285338 = 11202297307546 := by decide
theorem cert_e2406204285338 : check e2406204285338 [[]] .width = true := by decide
def e2406205140334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2406205140334 : Closed e2406205140334 ∧ code e2406205140334 = 11202298162542 := by decide
theorem cert_e2406205140334 : check e2406205140334 [[],[]] .chain = true := by decide
def e2406205140342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2406205140342 : Closed e2406205140342 ∧ code e2406205140342 = 11202298162550 := by decide
theorem cert_e2406205140342 : check e2406205140342 [[],[]] .chain = true := by decide
def e2406205140398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2406205140398 : Closed e2406205140398 ∧ code e2406205140398 = 11202298162606 := by decide
theorem cert_e2406205140398 : check e2406205140398 [[],[]] .chain = true := by decide
def e2406205140410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2406205140410 : Closed e2406205140410 ∧ code e2406205140410 = 11202298162618 := by decide
theorem cert_e2406205140410 : check e2406205140410 [[],[]] .chain = true := by decide
def e2406205140438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2406205140438 : Closed e2406205140438 ∧ code e2406205140438 = 11202298162646 := by decide
theorem cert_e2406205140438 : check e2406205140438 [[],[]] .chain = true := by decide
def e2406205140442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2406205140442 : Closed e2406205140442 ∧ code e2406205140442 = 11202298162650 := by decide
theorem cert_e2406205140442 : check e2406205140442 [[],[]] .chain = true := by decide
def e2406205140654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2406205140654 : Closed e2406205140654 ∧ code e2406205140654 = 11202298162862 := by decide
theorem cert_e2406205140654 : check e2406205140654 [[],[]] .chain = true := by decide
def e2406205140666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2406205140666 : Closed e2406205140666 ∧ code e2406205140666 = 11202298162874 := by decide
theorem cert_e2406205140666 : check e2406205140666 [[],[]] .chain = true := by decide
def e2406205140714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2406205140714 : Closed e2406205140714 ∧ code e2406205140714 = 11202298162922 := by decide
theorem cert_e2406205140714 : check e2406205140714 [[],[]] .chain = true := by decide
def e2406205140822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2406205140822 : Closed e2406205140822 ∧ code e2406205140822 = 11202298163030 := by decide
theorem cert_e2406205140822 : check e2406205140822 [[],[]] .chain = true := by decide
def e2406205140826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2406205140826 : Closed e2406205140826 ∧ code e2406205140826 = 11202298163034 := by decide
theorem cert_e2406205140826 : check e2406205140826 [[],[]] .chain = true := by decide
def e2406205140842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2406205140842 : Closed e2406205140842 ∧ code e2406205140842 = 11202298163050 := by decide
theorem cert_e2406205140842 : check e2406205140842 [[],[]] .chain = true := by decide
def e2406205141870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2406205141870 : Closed e2406205141870 ∧ code e2406205141870 = 11202298164078 := by decide
theorem cert_e2406205141870 : check e2406205141870 [[],[]] .chain = true := by decide
def e2406205141878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2406205141878 : Closed e2406205141878 ∧ code e2406205141878 = 11202298164086 := by decide
theorem cert_e2406205141878 : check e2406205141878 [[],[]] .chain = true := by decide
def e2406205141934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2406205141934 : Closed e2406205141934 ∧ code e2406205141934 = 11202298164142 := by decide
theorem cert_e2406205141934 : check e2406205141934 [[],[]] .chain = true := by decide
def e2406205141946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2406205141946 : Closed e2406205141946 ∧ code e2406205141946 = 11202298164154 := by decide
theorem cert_e2406205141946 : check e2406205141946 [[],[]] .chain = true := by decide
def e2406205141974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2406205141974 : Closed e2406205141974 ∧ code e2406205141974 = 11202298164182 := by decide
theorem cert_e2406205141974 : check e2406205141974 [[],[]] .chain = true := by decide
def e2406205141978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2406205141978 : Closed e2406205141978 ∧ code e2406205141978 = 11202298164186 := by decide
theorem cert_e2406205141978 : check e2406205141978 [[],[]] .chain = true := by decide
def e2406205142254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2406205142254 : Closed e2406205142254 ∧ code e2406205142254 = 11202298164462 := by decide
theorem cert_e2406205142254 : check e2406205142254 [[],[]] .chain = true := by decide
def e2406205142262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2406205142262 : Closed e2406205142262 ∧ code e2406205142262 = 11202298164470 := by decide
theorem cert_e2406205142262 : check e2406205142262 [[],[]] .chain = true := by decide
def e2406205142638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2406205142638 : Closed e2406205142638 ∧ code e2406205142638 = 11202298164846 := by decide
theorem cert_e2406205142638 : check e2406205142638 [[],[]] .chain = true := by decide
def e2406205142650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2406205142650 : Closed e2406205142650 ∧ code e2406205142650 = 11202298164858 := by decide
theorem cert_e2406205142650 : check e2406205142650 [[],[]] .chain = true := by decide
def e2406205142838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2406205142838 : Closed e2406205142838 ∧ code e2406205142838 = 11202298165046 := by decide
theorem cert_e2406205142838 : check e2406205142838 [[],[]] .chain = true := by decide
def e2406205142842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2406205142842 : Closed e2406205142842 ∧ code e2406205142842 = 11202298165050 := by decide
theorem cert_e2406205142842 : check e2406205142842 [[],[]] .chain = true := by decide
def e2406205143470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2406205143470 : Closed e2406205143470 ∧ code e2406205143470 = 11202298165678 := by decide
theorem cert_e2406205143470 : check e2406205143470 [[],[]] .chain = true := by decide
def e2406205143482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2406205143482 : Closed e2406205143482 ∧ code e2406205143482 = 11202298165690 := by decide
theorem cert_e2406205143482 : check e2406205143482 [[],[]] .chain = true := by decide
def e2406205143530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2406205143530 : Closed e2406205143530 ∧ code e2406205143530 = 11202298165738 := by decide
theorem cert_e2406205143530 : check e2406205143530 [[],[]] .chain = true := by decide
def e2406205143662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2406205143662 : Closed e2406205143662 ∧ code e2406205143662 = 11202298165870 := by decide
theorem cert_e2406205143662 : check e2406205143662 [[],[]] .chain = true := by decide
def e2406205143674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2406205143674 : Closed e2406205143674 ∧ code e2406205143674 = 11202298165882 := by decide
theorem cert_e2406205143674 : check e2406205143674 [[],[]] .chain = true := by decide
def e2406205143962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2406205143962 : Closed e2406205143962 ∧ code e2406205143962 = 11202298166170 := by decide
theorem cert_e2406205143962 : check e2406205143962 [[],[]] .chain = true := by decide
def e2406205144278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2406205144278 : Closed e2406205144278 ∧ code e2406205144278 = 11202298166486 := by decide
theorem cert_e2406205144278 : check e2406205144278 [[],[]] .chain = true := by decide
def e2406205144282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2406205144282 : Closed e2406205144282 ∧ code e2406205144282 = 11202298166490 := by decide
theorem cert_e2406205144282 : check e2406205144282 [[],[]] .chain = true := by decide
def e2406205144298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2406205144298 : Closed e2406205144298 ∧ code e2406205144298 = 11202298166506 := by decide
theorem cert_e2406205144298 : check e2406205144298 [[],[]] .chain = true := by decide
def e2406205144374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2406205144374 : Closed e2406205144374 ∧ code e2406205144374 = 11202298166582 := by decide
theorem cert_e2406205144374 : check e2406205144374 [[],[]] .chain = true := by decide
def e2406205144378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2406205144378 : Closed e2406205144378 ∧ code e2406205144378 = 11202298166586 := by decide
theorem cert_e2406205144378 : check e2406205144378 [[],[]] .chain = true := by decide
def e2406205144474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2406205144474 : Closed e2406205144474 ∧ code e2406205144474 = 11202298166682 := by decide
theorem cert_e2406205144474 : check e2406205144474 [[],[]] .chain = true := by decide
def e2406205148014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2406205148014 : Closed e2406205148014 ∧ code e2406205148014 = 11202298170222 := by decide
theorem cert_e2406205148014 : check e2406205148014 [[],[]] .chain = true := by decide
def e2406205148022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2406205148022 : Closed e2406205148022 ∧ code e2406205148022 = 11202298170230 := by decide
theorem cert_e2406205148022 : check e2406205148022 [[],[]] .chain = true := by decide
def e2406205148078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2406205148078 : Closed e2406205148078 ∧ code e2406205148078 = 11202298170286 := by decide
theorem cert_e2406205148078 : check e2406205148078 [[],[]] .chain = true := by decide
def e2406205148090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2406205148090 : Closed e2406205148090 ∧ code e2406205148090 = 11202298170298 := by decide
theorem cert_e2406205148090 : check e2406205148090 [[],[]] .chain = true := by decide
def e2406205148118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2406205148118 : Closed e2406205148118 ∧ code e2406205148118 = 11202298170326 := by decide
theorem cert_e2406205148118 : check e2406205148118 [[],[]] .chain = true := by decide
def e2406205148122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2406205148122 : Closed e2406205148122 ∧ code e2406205148122 = 11202298170330 := by decide
theorem cert_e2406205148122 : check e2406205148122 [[],[]] .chain = true := by decide
def e2406205148398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2406205148398 : Closed e2406205148398 ∧ code e2406205148398 = 11202298170606 := by decide
theorem cert_e2406205148398 : check e2406205148398 [[],[]] .chain = true := by decide
def e2406205148406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2406205148406 : Closed e2406205148406 ∧ code e2406205148406 = 11202298170614 := by decide
theorem cert_e2406205148406 : check e2406205148406 [[],[]] .chain = true := by decide
def e2406205148782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2406205148782 : Closed e2406205148782 ∧ code e2406205148782 = 11202298170990 := by decide
theorem cert_e2406205148782 : check e2406205148782 [[],[]] .chain = true := by decide
def e2406205148794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2406205148794 : Closed e2406205148794 ∧ code e2406205148794 = 11202298171002 := by decide
theorem cert_e2406205148794 : check e2406205148794 [[],[]] .chain = true := by decide
def e2406205148982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2406205148982 : Closed e2406205148982 ∧ code e2406205148982 = 11202298171190 := by decide
theorem cert_e2406205148982 : check e2406205148982 [[],[]] .chain = true := by decide
def e2406205148986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2406205148986 : Closed e2406205148986 ∧ code e2406205148986 = 11202298171194 := by decide
theorem cert_e2406205148986 : check e2406205148986 [[],[]] .chain = true := by decide
def e2406205154734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2406205154734 : Closed e2406205154734 ∧ code e2406205154734 = 11202298176942 := by decide
theorem cert_e2406205154734 : check e2406205154734 [[],[]] .chain = true := by decide
def e2406205154746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2406205154746 : Closed e2406205154746 ∧ code e2406205154746 = 11202298176954 := by decide
theorem cert_e2406205154746 : check e2406205154746 [[],[]] .chain = true := by decide
def e2406205154794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2406205154794 : Closed e2406205154794 ∧ code e2406205154794 = 11202298177002 := by decide
theorem cert_e2406205154794 : check e2406205154794 [[],[]] .chain = true := by decide
def e2406205154926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2406205154926 : Closed e2406205154926 ∧ code e2406205154926 = 11202298177134 := by decide
theorem cert_e2406205154926 : check e2406205154926 [[],[]] .chain = true := by decide
def e2406205154938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2406205154938 : Closed e2406205154938 ∧ code e2406205154938 = 11202298177146 := by decide
theorem cert_e2406205154938 : check e2406205154938 [[],[]] .chain = true := by decide
def e2406205155226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2406205155226 : Closed e2406205155226 ∧ code e2406205155226 = 11202298177434 := by decide
theorem cert_e2406205155226 : check e2406205155226 [[],[]] .chain = true := by decide
def e2406205158102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2406205158102 : Closed e2406205158102 ∧ code e2406205158102 = 11202298180310 := by decide
theorem cert_e2406205158102 : check e2406205158102 [[],[]] .chain = true := by decide
def e2406205158106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2406205158106 : Closed e2406205158106 ∧ code e2406205158106 = 11202298180314 := by decide
theorem cert_e2406205158106 : check e2406205158106 [[],[]] .chain = true := by decide
def e2406205158122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2406205158122 : Closed e2406205158122 ∧ code e2406205158122 = 11202298180330 := by decide
theorem cert_e2406205158122 : check e2406205158122 [[],[]] .chain = true := by decide
def e2406205158198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2406205158198 : Closed e2406205158198 ∧ code e2406205158198 = 11202298180406 := by decide
theorem cert_e2406205158198 : check e2406205158198 [[],[]] .chain = true := by decide
def e2406205158202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2406205158202 : Closed e2406205158202 ∧ code e2406205158202 = 11202298180410 := by decide
theorem cert_e2406205158202 : check e2406205158202 [[],[]] .chain = true := by decide
def e2406205158298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2406205158298 : Closed e2406205158298 ∧ code e2406205158298 = 11202298180506 := by decide
theorem cert_e2406205158298 : check e2406205158298 [[],[]] .chain = true := by decide
def e2406205295470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2406205295470 : Closed e2406205295470 ∧ code e2406205295470 = 11202298317678 := by decide
theorem cert_e2406205295470 : check e2406205295470 [[],[]] .chain = true := by decide
def e2406205295478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2406205295478 : Closed e2406205295478 ∧ code e2406205295478 = 11202298317686 := by decide
theorem cert_e2406205295478 : check e2406205295478 [[],[]] .chain = true := by decide
def e2406205295534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2406205295534 : Closed e2406205295534 ∧ code e2406205295534 = 11202298317742 := by decide
theorem cert_e2406205295534 : check e2406205295534 [[],[]] .chain = true := by decide
def e2406205295546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2406205295546 : Closed e2406205295546 ∧ code e2406205295546 = 11202298317754 := by decide
theorem cert_e2406205295546 : check e2406205295546 [[],[]] .chain = true := by decide
def e2406205295574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2406205295574 : Closed e2406205295574 ∧ code e2406205295574 = 11202298317782 := by decide
theorem cert_e2406205295574 : check e2406205295574 [[],[]] .chain = true := by decide
def e2406205295578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2406205295578 : Closed e2406205295578 ∧ code e2406205295578 = 11202298317786 := by decide
theorem cert_e2406205295578 : check e2406205295578 [[],[]] .chain = true := by decide
def e2406205295854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2406205295854 : Closed e2406205295854 ∧ code e2406205295854 = 11202298318062 := by decide
theorem cert_e2406205295854 : check e2406205295854 [[],[]] .chain = true := by decide
def e2406205295862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2406205295862 : Closed e2406205295862 ∧ code e2406205295862 = 11202298318070 := by decide
theorem cert_e2406205295862 : check e2406205295862 [[],[]] .chain = true := by decide
def e2406205296238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2406205296238 : Closed e2406205296238 ∧ code e2406205296238 = 11202298318446 := by decide
theorem cert_e2406205296238 : check e2406205296238 [[],[]] .chain = true := by decide
def e2406205296250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2406205296250 : Closed e2406205296250 ∧ code e2406205296250 = 11202298318458 := by decide
theorem cert_e2406205296250 : check e2406205296250 [[],[]] .chain = true := by decide
def e2406205296438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2406205296438 : Closed e2406205296438 ∧ code e2406205296438 = 11202298318646 := by decide
theorem cert_e2406205296438 : check e2406205296438 [[],[]] .chain = true := by decide
def e2406205296442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2406205296442 : Closed e2406205296442 ∧ code e2406205296442 = 11202298318650 := by decide
theorem cert_e2406205296442 : check e2406205296442 [[],[]] .chain = true := by decide
def e2406205885294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2406205885294 : Closed e2406205885294 ∧ code e2406205885294 = 11202298907502 := by decide
theorem cert_e2406205885294 : check e2406205885294 [[],[],[]] .smaller = true := by decide
def e2406205885302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2406205885302 : Closed e2406205885302 ∧ code e2406205885302 = 11202298907510 := by decide
theorem cert_e2406205885302 : check e2406205885302 [[],[],[]] .smaller = true := by decide
def e2406205885358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2406205885358 : Closed e2406205885358 ∧ code e2406205885358 = 11202298907566 := by decide
theorem cert_e2406205885358 : check e2406205885358 [[],[],[]] .smaller = true := by decide
def e2406205885370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2406205885370 : Closed e2406205885370 ∧ code e2406205885370 = 11202298907578 := by decide
theorem cert_e2406205885370 : check e2406205885370 [[],[],[]] .smaller = true := by decide
def e2406205885398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2406205885398 : Closed e2406205885398 ∧ code e2406205885398 = 11202298907606 := by decide
theorem cert_e2406205885398 : check e2406205885398 [[],[],[]] .smaller = true := by decide
def e2406205885402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2406205885402 : Closed e2406205885402 ∧ code e2406205885402 = 11202298907610 := by decide
theorem cert_e2406205885402 : check e2406205885402 [[],[],[]] .smaller = true := by decide
def e2406205885678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2406205885678 : Closed e2406205885678 ∧ code e2406205885678 = 11202298907886 := by decide
theorem cert_e2406205885678 : check e2406205885678 [[],[],[]] .smaller = true := by decide
def e2406205885686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2406205885686 : Closed e2406205885686 ∧ code e2406205885686 = 11202298907894 := by decide
theorem cert_e2406205885686 : check e2406205885686 [[],[],[]] .smaller = true := by decide
def e2406205886062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2406205886062 : Closed e2406205886062 ∧ code e2406205886062 = 11202298908270 := by decide
theorem cert_e2406205886062 : check e2406205886062 [[],[],[]] .smaller = true := by decide
def e2406205886074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2406205886074 : Closed e2406205886074 ∧ code e2406205886074 = 11202298908282 := by decide
theorem cert_e2406205886074 : check e2406205886074 [[],[],[]] .smaller = true := by decide
def e2406205886262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2406205886262 : Closed e2406205886262 ∧ code e2406205886262 = 11202298908470 := by decide
theorem cert_e2406205886262 : check e2406205886262 [[],[],[]] .smaller = true := by decide
def e2406205886266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2406205886266 : Closed e2406205886266 ∧ code e2406205886266 = 11202298908474 := by decide
theorem cert_e2406205886266 : check e2406205886266 [[],[],[]] .smaller = true := by decide
def e2407060778350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2407060778350 : Closed e2407060778350 ∧ code e2407060778350 = 11203153800558 := by decide
theorem cert_e2407060778350 : check e2407060778350 [[],[]] .smaller = true := by decide
def e2407060778358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2407060778358 : Closed e2407060778358 ∧ code e2407060778358 = 11203153800566 := by decide
theorem cert_e2407060778358 : check e2407060778358 [[],[]] .smaller = true := by decide
def e2407060778414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2407060778414 : Closed e2407060778414 ∧ code e2407060778414 = 11203153800622 := by decide
theorem cert_e2407060778414 : check e2407060778414 [[],[]] .smaller = true := by decide
def e2407060778426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2407060778426 : Closed e2407060778426 ∧ code e2407060778426 = 11203153800634 := by decide
theorem cert_e2407060778426 : check e2407060778426 [[],[]] .smaller = true := by decide
def e2407060778454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2407060778454 : Closed e2407060778454 ∧ code e2407060778454 = 11203153800662 := by decide
theorem cert_e2407060778454 : check e2407060778454 [[],[]] .smaller = true := by decide
def e2407060778458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2407060778458 : Closed e2407060778458 ∧ code e2407060778458 = 11203153800666 := by decide
theorem cert_e2407060778458 : check e2407060778458 [[],[]] .smaller = true := by decide
def e2407060778670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2407060778670 : Closed e2407060778670 ∧ code e2407060778670 = 11203153800878 := by decide
theorem cert_e2407060778670 : check e2407060778670 [[],[]] .smaller = true := by decide
def e2407060778682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2407060778682 : Closed e2407060778682 ∧ code e2407060778682 = 11203153800890 := by decide
theorem cert_e2407060778682 : check e2407060778682 [[],[]] .smaller = true := by decide
def e2407060778730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2407060778730 : Closed e2407060778730 ∧ code e2407060778730 = 11203153800938 := by decide
theorem cert_e2407060778730 : check e2407060778730 [[],[]] .smaller = true := by decide
def e2407060778838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2407060778838 : Closed e2407060778838 ∧ code e2407060778838 = 11203153801046 := by decide
theorem cert_e2407060778838 : check e2407060778838 [[],[]] .smaller = true := by decide
def e2407060778842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2407060778842 : Closed e2407060778842 ∧ code e2407060778842 = 11203153801050 := by decide
theorem cert_e2407060778842 : check e2407060778842 [[],[]] .smaller = true := by decide
def e2407060778858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2407060778858 : Closed e2407060778858 ∧ code e2407060778858 = 11203153801066 := by decide
theorem cert_e2407060778858 : check e2407060778858 [[],[]] .smaller = true := by decide
def e2407060779886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2407060779886 : Closed e2407060779886 ∧ code e2407060779886 = 11203153802094 := by decide
theorem cert_e2407060779886 : check e2407060779886 [[],[]] .smaller = true := by decide
def e2407060779894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2407060779894 : Closed e2407060779894 ∧ code e2407060779894 = 11203153802102 := by decide
theorem cert_e2407060779894 : check e2407060779894 [[],[]] .smaller = true := by decide
def e2407060779950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2407060779950 : Closed e2407060779950 ∧ code e2407060779950 = 11203153802158 := by decide
theorem cert_e2407060779950 : check e2407060779950 [[],[]] .smaller = true := by decide
def e2407060779962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2407060779962 : Closed e2407060779962 ∧ code e2407060779962 = 11203153802170 := by decide
theorem cert_e2407060779962 : check e2407060779962 [[],[]] .smaller = true := by decide
def e2407060779990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2407060779990 : Closed e2407060779990 ∧ code e2407060779990 = 11203153802198 := by decide
theorem cert_e2407060779990 : check e2407060779990 [[],[]] .smaller = true := by decide
def e2407060779994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2407060779994 : Closed e2407060779994 ∧ code e2407060779994 = 11203153802202 := by decide
theorem cert_e2407060779994 : check e2407060779994 [[],[]] .smaller = true := by decide
def e2407060780270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407060780270 : Closed e2407060780270 ∧ code e2407060780270 = 11203153802478 := by decide
theorem cert_e2407060780270 : check e2407060780270 [[],[]] .smaller = true := by decide
def e2407060780278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407060780278 : Closed e2407060780278 ∧ code e2407060780278 = 11203153802486 := by decide
theorem cert_e2407060780278 : check e2407060780278 [[],[]] .smaller = true := by decide
def e2407060780654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407060780654 : Closed e2407060780654 ∧ code e2407060780654 = 11203153802862 := by decide
theorem cert_e2407060780654 : check e2407060780654 [[],[]] .smaller = true := by decide
def e2407060780666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407060780666 : Closed e2407060780666 ∧ code e2407060780666 = 11203153802874 := by decide
theorem cert_e2407060780666 : check e2407060780666 [[],[]] .smaller = true := by decide
def e2407060780854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407060780854 : Closed e2407060780854 ∧ code e2407060780854 = 11203153803062 := by decide
theorem cert_e2407060780854 : check e2407060780854 [[],[]] .smaller = true := by decide
def e2407060780858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407060780858 : Closed e2407060780858 ∧ code e2407060780858 = 11203153803066 := by decide
theorem cert_e2407060780858 : check e2407060780858 [[],[]] .smaller = true := by decide
def e2407060781486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2407060781486 : Closed e2407060781486 ∧ code e2407060781486 = 11203153803694 := by decide
theorem cert_e2407060781486 : check e2407060781486 [[],[]] .smaller = true := by decide
def e2407060781498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2407060781498 : Closed e2407060781498 ∧ code e2407060781498 = 11203153803706 := by decide
theorem cert_e2407060781498 : check e2407060781498 [[],[]] .smaller = true := by decide
def e2407060781546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2407060781546 : Closed e2407060781546 ∧ code e2407060781546 = 11203153803754 := by decide
theorem cert_e2407060781546 : check e2407060781546 [[],[]] .smaller = true := by decide
def e2407060781678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407060781678 : Closed e2407060781678 ∧ code e2407060781678 = 11203153803886 := by decide
theorem cert_e2407060781678 : check e2407060781678 [[],[]] .smaller = true := by decide
def e2407060781690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407060781690 : Closed e2407060781690 ∧ code e2407060781690 = 11203153803898 := by decide
theorem cert_e2407060781690 : check e2407060781690 [[],[]] .smaller = true := by decide
def e2407060781978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407060781978 : Closed e2407060781978 ∧ code e2407060781978 = 11203153804186 := by decide
theorem cert_e2407060781978 : check e2407060781978 [[],[]] .smaller = true := by decide
def e2407060782294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2407060782294 : Closed e2407060782294 ∧ code e2407060782294 = 11203153804502 := by decide
theorem cert_e2407060782294 : check e2407060782294 [[],[]] .smaller = true := by decide
def e2407060782298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2407060782298 : Closed e2407060782298 ∧ code e2407060782298 = 11203153804506 := by decide
theorem cert_e2407060782298 : check e2407060782298 [[],[]] .smaller = true := by decide
def e2407060782314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2407060782314 : Closed e2407060782314 ∧ code e2407060782314 = 11203153804522 := by decide
theorem cert_e2407060782314 : check e2407060782314 [[],[]] .smaller = true := by decide
def e2407060782390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407060782390 : Closed e2407060782390 ∧ code e2407060782390 = 11203153804598 := by decide
theorem cert_e2407060782390 : check e2407060782390 [[],[]] .smaller = true := by decide
def e2407060782394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407060782394 : Closed e2407060782394 ∧ code e2407060782394 = 11203153804602 := by decide
theorem cert_e2407060782394 : check e2407060782394 [[],[]] .smaller = true := by decide
def e2407060782490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407060782490 : Closed e2407060782490 ∧ code e2407060782490 = 11203153804698 := by decide
theorem cert_e2407060782490 : check e2407060782490 [[],[]] .smaller = true := by decide
def e2407060786030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2407060786030 : Closed e2407060786030 ∧ code e2407060786030 = 11203153808238 := by decide
theorem cert_e2407060786030 : check e2407060786030 [[],[]] .smaller = true := by decide
def e2407060786038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2407060786038 : Closed e2407060786038 ∧ code e2407060786038 = 11203153808246 := by decide
theorem cert_e2407060786038 : check e2407060786038 [[],[]] .smaller = true := by decide
def e2407060786094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2407060786094 : Closed e2407060786094 ∧ code e2407060786094 = 11203153808302 := by decide
theorem cert_e2407060786094 : check e2407060786094 [[],[]] .smaller = true := by decide
def e2407060786106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2407060786106 : Closed e2407060786106 ∧ code e2407060786106 = 11203153808314 := by decide
theorem cert_e2407060786106 : check e2407060786106 [[],[]] .smaller = true := by decide
def e2407060786134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2407060786134 : Closed e2407060786134 ∧ code e2407060786134 = 11203153808342 := by decide
theorem cert_e2407060786134 : check e2407060786134 [[],[]] .smaller = true := by decide
def e2407060786138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2407060786138 : Closed e2407060786138 ∧ code e2407060786138 = 11203153808346 := by decide
theorem cert_e2407060786138 : check e2407060786138 [[],[]] .smaller = true := by decide
end Blc.Floor43
