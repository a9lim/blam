import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372970974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2422372970974 : Closed e2422372970974 ∧ code e2422372970974 = 11218465993182 := by decide
theorem cert_e2422372970974 : check e2422372970974 [[],[]] .three = true := by decide
def e2422372970990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 2)))))))
theorem wire_e2422372970990 : Closed e2422372970990 ∧ code e2422372970990 = 11218465993198 := by decide
theorem cert_e2422372970990 : check e2422372970990 [[],[]] .smaller = true := by decide
def e2422372970998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2422372970998 : Closed e2422372970998 ∧ code e2422372970998 = 11218465993206 := by decide
theorem cert_e2422372970998 : check e2422372970998 [[],[]] .three = true := by decide
def e2422372971358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2422372971358 : Closed e2422372971358 ∧ code e2422372971358 = 11218465993566 := by decide
theorem cert_e2422372971358 : check e2422372971358 [[],[]] .three = true := by decide
def e2422372971374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422372971374 : Closed e2422372971374 ∧ code e2422372971374 = 11218465993582 := by decide
theorem cert_e2422372971374 : check e2422372971374 [[],[]] .smaller = true := by decide
def e2422372971382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422372971382 : Closed e2422372971382 ∧ code e2422372971382 = 11218465993590 := by decide
theorem cert_e2422372971382 : check e2422372971382 [[],[]] .smaller = true := by decide
def e2422372971386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2422372971386 : Closed e2422372971386 ∧ code e2422372971386 = 11218465993594 := by decide
theorem cert_e2422372971386 : check e2422372971386 [[],[]] .three = true := by decide
def e2422372971438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422372971438 : Closed e2422372971438 ∧ code e2422372971438 = 11218465993646 := by decide
theorem cert_e2422372971438 : check e2422372971438 [[],[]] .smaller = true := by decide
def e2422372971450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422372971450 : Closed e2422372971450 ∧ code e2422372971450 = 11218465993658 := by decide
theorem cert_e2422372971450 : check e2422372971450 [[],[]] .smaller = true := by decide
def e2422372971478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422372971478 : Closed e2422372971478 ∧ code e2422372971478 = 11218465993686 := by decide
theorem cert_e2422372971478 : check e2422372971478 [[],[]] .smaller = true := by decide
def e2422372971482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422372971482 : Closed e2422372971482 ∧ code e2422372971482 = 11218465993690 := by decide
theorem cert_e2422372971482 : check e2422372971482 [[],[]] .smaller = true := by decide
def e2422372971498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2422372971498 : Closed e2422372971498 ∧ code e2422372971498 = 11218465993706 := by decide
theorem cert_e2422372971498 : check e2422372971498 [[],[]] .three = true := by decide
def e2422372971742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372971742 : Closed e2422372971742 ∧ code e2422372971742 = 11218465993950 := by decide
theorem cert_e2422372971742 : check e2422372971742 [[],[]] .three = true := by decide
def e2422372971758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372971758 : Closed e2422372971758 ∧ code e2422372971758 = 11218465993966 := by decide
theorem cert_e2422372971758 : check e2422372971758 [[],[]] .smaller = true := by decide
def e2422372971766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372971766 : Closed e2422372971766 ∧ code e2422372971766 = 11218465993974 := by decide
theorem cert_e2422372971766 : check e2422372971766 [[],[]] .smaller = true := by decide
def e2422372971770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372971770 : Closed e2422372971770 ∧ code e2422372971770 = 11218465993978 := by decide
theorem cert_e2422372971770 : check e2422372971770 [[],[]] .three = true := by decide
def e2422372972094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2422372972094 : Closed e2422372972094 ∧ code e2422372972094 = 11218465994302 := by decide
theorem cert_e2422372972094 : check e2422372972094 [[],[]] .three = true := by decide
def e2422372972142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372972142 : Closed e2422372972142 ∧ code e2422372972142 = 11218465994350 := by decide
theorem cert_e2422372972142 : check e2422372972142 [[],[]] .smaller = true := by decide
def e2422372972154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372972154 : Closed e2422372972154 ∧ code e2422372972154 = 11218465994362 := by decide
theorem cert_e2422372972154 : check e2422372972154 [[],[]] .smaller = true := by decide
def e2422372972318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 3))))))))
theorem wire_e2422372972318 : Closed e2422372972318 ∧ code e2422372972318 = 11218465994526 := by decide
theorem cert_e2422372972318 : check e2422372972318 [[],[]] .smaller = true := by decide
def e2422372972342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372972342 : Closed e2422372972342 ∧ code e2422372972342 = 11218465994550 := by decide
theorem cert_e2422372972342 : check e2422372972342 [[],[]] .smaller = true := by decide
def e2422372972346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372972346 : Closed e2422372972346 ∧ code e2422372972346 = 11218465994554 := by decide
theorem cert_e2422372972346 : check e2422372972346 [[],[]] .smaller = true := by decide
def e2422372972430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2422372972430 : Closed e2422372972430 ∧ code e2422372972430 = 11218465994638 := by decide
theorem cert_e2422372972430 : check e2422372972430 [[],[]] .three = true := by decide
def e2422372972442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372972442 : Closed e2422372972442 ∧ code e2422372972442 = 11218465994650 := by decide
theorem cert_e2422372972442 : check e2422372972442 [[],[]] .three = true := by decide
def e2422372972766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372972766 : Closed e2422372972766 ∧ code e2422372972766 = 11218465994974 := by decide
theorem cert_e2422372972766 : check e2422372972766 [[],[]] .three = true := by decide
def e2422372972794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372972794 : Closed e2422372972794 ∧ code e2422372972794 = 11218465995002 := by decide
theorem cert_e2422372972794 : check e2422372972794 [[],[]] .three = true := by decide
def e2422372972974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372972974 : Closed e2422372972974 ∧ code e2422372972974 = 11218465995182 := by decide
theorem cert_e2422372972974 : check e2422372972974 [[],[]] .smaller = true := by decide
def e2422372972986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372972986 : Closed e2422372972986 ∧ code e2422372972986 = 11218465995194 := by decide
theorem cert_e2422372972986 : check e2422372972986 [[],[]] .smaller = true := by decide
def e2422372973034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372973034 : Closed e2422372973034 ∧ code e2422372973034 = 11218465995242 := by decide
theorem cert_e2422372973034 : check e2422372973034 [[],[]] .smaller = true := by decide
def e2422372973118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372973118 : Closed e2422372973118 ∧ code e2422372973118 = 11218465995326 := by decide
theorem cert_e2422372973118 : check e2422372973118 [[],[]] .three = true := by decide
def e2422372973166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372973166 : Closed e2422372973166 ∧ code e2422372973166 = 11218465995374 := by decide
theorem cert_e2422372973166 : check e2422372973166 [[],[]] .smaller = true := by decide
def e2422372973178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372973178 : Closed e2422372973178 ∧ code e2422372973178 = 11218465995386 := by decide
theorem cert_e2422372973178 : check e2422372973178 [[],[]] .smaller = true := by decide
def e2422372973466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372973466 : Closed e2422372973466 ∧ code e2422372973466 = 11218465995674 := by decide
theorem cert_e2422372973466 : check e2422372973466 [[],[]] .smaller = true := by decide
def e2422372973510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372973510 : Closed e2422372973510 ∧ code e2422372973510 = 11218465995718 := by decide
theorem cert_e2422372973510 : check e2422372973510 [[],[]] .three = true := by decide
def e2422372973678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372973678 : Closed e2422372973678 ∧ code e2422372973678 = 11218465995886 := by decide
theorem cert_e2422372973678 : check e2422372973678 [[],[]] .smaller = true := by decide
def e2422372973690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372973690 : Closed e2422372973690 ∧ code e2422372973690 = 11218465995898 := by decide
theorem cert_e2422372973690 : check e2422372973690 [[],[]] .smaller = true := by decide
def e2422372973782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422372973782 : Closed e2422372973782 ∧ code e2422372973782 = 11218465995990 := by decide
theorem cert_e2422372973782 : check e2422372973782 [[],[]] .smaller = true := by decide
def e2422372973786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422372973786 : Closed e2422372973786 ∧ code e2422372973786 = 11218465995994 := by decide
theorem cert_e2422372973786 : check e2422372973786 [[],[]] .smaller = true := by decide
def e2422372973802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422372973802 : Closed e2422372973802 ∧ code e2422372973802 = 11218465996010 := by decide
theorem cert_e2422372973802 : check e2422372973802 [[],[]] .smaller = true := by decide
def e2422372973854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372973854 : Closed e2422372973854 ∧ code e2422372973854 = 11218465996062 := by decide
theorem cert_e2422372973854 : check e2422372973854 [[],[]] .smaller = true := by decide
def e2422372973878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372973878 : Closed e2422372973878 ∧ code e2422372973878 = 11218465996086 := by decide
theorem cert_e2422372973878 : check e2422372973878 [[],[]] .smaller = true := by decide
def e2422372973882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372973882 : Closed e2422372973882 ∧ code e2422372973882 = 11218465996090 := by decide
theorem cert_e2422372973882 : check e2422372973882 [[],[]] .smaller = true := by decide
def e2422372973978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372973978 : Closed e2422372973978 ∧ code e2422372973978 = 11218465996186 := by decide
theorem cert_e2422372973978 : check e2422372973978 [[],[]] .smaller = true := by decide
def e2422372974022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372974022 : Closed e2422372974022 ∧ code e2422372974022 = 11218465996230 := by decide
theorem cert_e2422372974022 : check e2422372974022 [[],[]] .smaller = true := by decide
def e2422372974046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 3)))))))
theorem wire_e2422372974046 : Closed e2422372974046 ∧ code e2422372974046 = 11218465996254 := by decide
theorem cert_e2422372974046 : check e2422372974046 [[],[]] .three = true := by decide
def e2422372974062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 3)) (.var 2)))))))
theorem wire_e2422372974062 : Closed e2422372974062 ∧ code e2422372974062 = 11218465996270 := by decide
theorem cert_e2422372974062 : check e2422372974062 [[],[]] .three = true := by decide
def e2422372974134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372974134 : Closed e2422372974134 ∧ code e2422372974134 = 11218465996342 := by decide
theorem cert_e2422372974134 : check e2422372974134 [[],[]] .three = true := by decide
def e2422372974138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372974138 : Closed e2422372974138 ∧ code e2422372974138 = 11218465996346 := by decide
theorem cert_e2422372974138 : check e2422372974138 [[],[]] .three = true := by decide
def e2422372974186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372974186 : Closed e2422372974186 ∧ code e2422372974186 = 11218465996394 := by decide
theorem cert_e2422372974186 : check e2422372974186 [[],[]] .three = true := by decide
def e2422372974222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372974222 : Closed e2422372974222 ∧ code e2422372974222 = 11218465996430 := by decide
theorem cert_e2422372974222 : check e2422372974222 [[],[]] .three = true := by decide
def e2422372974234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372974234 : Closed e2422372974234 ∧ code e2422372974234 = 11218465996442 := by decide
theorem cert_e2422372974234 : check e2422372974234 [[],[]] .three = true := by decide
def e2422372974278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372974278 : Closed e2422372974278 ∧ code e2422372974278 = 11218465996486 := by decide
theorem cert_e2422372974278 : check e2422372974278 [[],[]] .three = true := by decide
def e2422372974318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 2)) (.var 2)))))))
theorem wire_e2422372974318 : Closed e2422372974318 ∧ code e2422372974318 = 11218465996526 := by decide
theorem cert_e2422372974318 : check e2422372974318 [[],[]] .three = true := by decide
def e2422372981422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372981422 : Closed e2422372981422 ∧ code e2422372981422 = 11218466003630 := by decide
theorem cert_e2422372981422 : check e2422372981422 [[],[]] .smaller = true := by decide
def e2422372981434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372981434 : Closed e2422372981434 ∧ code e2422372981434 = 11218466003642 := by decide
theorem cert_e2422372981434 : check e2422372981434 [[],[]] .smaller = true := by decide
def e2422372981482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372981482 : Closed e2422372981482 ∧ code e2422372981482 = 11218466003690 := by decide
theorem cert_e2422372981482 : check e2422372981482 [[],[]] .smaller = true := by decide
def e2422372981674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372981674 : Closed e2422372981674 ∧ code e2422372981674 = 11218466003882 := by decide
theorem cert_e2422372981674 : check e2422372981674 [[],[]] .smaller = true := by decide
def e2422372982442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372982442 : Closed e2422372982442 ∧ code e2422372982442 = 11218466004650 := by decide
theorem cert_e2422372982442 : check e2422372982442 [[],[]] .smaller = true := by decide
def e2422372982958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)) (.var 2)))))))
theorem wire_e2422372982958 : Closed e2422372982958 ∧ code e2422372982958 = 11218466005166 := by decide
theorem cert_e2422372982958 : check e2422372982958 [[],[]] .smaller = true := by decide
def e2422372982970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)) (.var 0)))))))
theorem wire_e2422372982970 : Closed e2422372982970 ∧ code e2422372982970 = 11218466005178 := by decide
theorem cert_e2422372982970 : check e2422372982970 [[],[]] .smaller = true := by decide
def e2422372983518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 3)))))))
theorem wire_e2422372983518 : Closed e2422372983518 ∧ code e2422372983518 = 11218466005726 := by decide
theorem cert_e2422372983518 : check e2422372983518 [[],[]] .three = true := by decide
def e2422372983534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 2)))))))
theorem wire_e2422372983534 : Closed e2422372983534 ∧ code e2422372983534 = 11218466005742 := by decide
theorem cert_e2422372983534 : check e2422372983534 [[],[]] .smaller = true := by decide
def e2422372983542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 3)) (.var 1)))))))
theorem wire_e2422372983542 : Closed e2422372983542 ∧ code e2422372983542 = 11218466005750 := by decide
theorem cert_e2422372983542 : check e2422372983542 [[],[]] .three = true := by decide
def e2422372983646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372983646 : Closed e2422372983646 ∧ code e2422372983646 = 11218466005854 := by decide
theorem cert_e2422372983646 : check e2422372983646 [[],[]] .three = true := by decide
def e2422372983662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372983662 : Closed e2422372983662 ∧ code e2422372983662 = 11218466005870 := by decide
theorem cert_e2422372983662 : check e2422372983662 [[],[]] .smaller = true := by decide
def e2422372983670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372983670 : Closed e2422372983670 ∧ code e2422372983670 = 11218466005878 := by decide
theorem cert_e2422372983670 : check e2422372983670 [[],[]] .smaller = true := by decide
def e2422372983674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372983674 : Closed e2422372983674 ∧ code e2422372983674 = 11218466005882 := by decide
theorem cert_e2422372983674 : check e2422372983674 [[],[]] .three = true := by decide
def e2422372983726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372983726 : Closed e2422372983726 ∧ code e2422372983726 = 11218466005934 := by decide
theorem cert_e2422372983726 : check e2422372983726 [[],[]] .smaller = true := by decide
def e2422372983738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372983738 : Closed e2422372983738 ∧ code e2422372983738 = 11218466005946 := by decide
theorem cert_e2422372983738 : check e2422372983738 [[],[]] .smaller = true := by decide
def e2422372983766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372983766 : Closed e2422372983766 ∧ code e2422372983766 = 11218466005974 := by decide
theorem cert_e2422372983766 : check e2422372983766 [[],[]] .smaller = true := by decide
def e2422372983770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372983770 : Closed e2422372983770 ∧ code e2422372983770 = 11218466005978 := by decide
theorem cert_e2422372983770 : check e2422372983770 [[],[]] .smaller = true := by decide
def e2422372983786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 4)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372983786 : Closed e2422372983786 ∧ code e2422372983786 = 11218466005994 := by decide
theorem cert_e2422372983786 : check e2422372983786 [[],[]] .three = true := by decide
def e2422372984494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372984494 : Closed e2422372984494 ∧ code e2422372984494 = 11218466006702 := by decide
theorem cert_e2422372984494 : check e2422372984494 [[],[]] .smaller = true := by decide
def e2422372984506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372984506 : Closed e2422372984506 ∧ code e2422372984506 = 11218466006714 := by decide
theorem cert_e2422372984506 : check e2422372984506 [[],[]] .smaller = true := by decide
def e2422372984554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372984554 : Closed e2422372984554 ∧ code e2422372984554 = 11218466006762 := by decide
theorem cert_e2422372984554 : check e2422372984554 [[],[]] .smaller = true := by decide
def e2422372984746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372984746 : Closed e2422372984746 ∧ code e2422372984746 = 11218466006954 := by decide
theorem cert_e2422372984746 : check e2422372984746 [[],[]] .smaller = true := by decide
def e2422372984878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372984878 : Closed e2422372984878 ∧ code e2422372984878 = 11218466007086 := by decide
theorem cert_e2422372984878 : check e2422372984878 [[],[]] .smaller = true := by decide
def e2422372985054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372985054 : Closed e2422372985054 ∧ code e2422372985054 = 11218466007262 := by decide
theorem cert_e2422372985054 : check e2422372985054 [[],[]] .three = true := by decide
def e2422372985070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422372985070 : Closed e2422372985070 ∧ code e2422372985070 = 11218466007278 := by decide
theorem cert_e2422372985070 : check e2422372985070 [[],[]] .smaller = true := by decide
def e2422372985078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422372985078 : Closed e2422372985078 ∧ code e2422372985078 = 11218466007286 := by decide
theorem cert_e2422372985078 : check e2422372985078 [[],[]] .smaller = true := by decide
def e2422372985082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372985082 : Closed e2422372985082 ∧ code e2422372985082 = 11218466007290 := by decide
theorem cert_e2422372985082 : check e2422372985082 [[],[]] .three = true := by decide
def e2422372985262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372985262 : Closed e2422372985262 ∧ code e2422372985262 = 11218466007470 := by decide
theorem cert_e2422372985262 : check e2422372985262 [[],[]] .smaller = true := by decide
def e2422372985274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372985274 : Closed e2422372985274 ∧ code e2422372985274 = 11218466007482 := by decide
theorem cert_e2422372985274 : check e2422372985274 [[],[]] .smaller = true := by decide
def e2422372985322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372985322 : Closed e2422372985322 ∧ code e2422372985322 = 11218466007530 := by decide
theorem cert_e2422372985322 : check e2422372985322 [[],[]] .smaller = true := by decide
def e2422372985406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372985406 : Closed e2422372985406 ∧ code e2422372985406 = 11218466007614 := by decide
theorem cert_e2422372985406 : check e2422372985406 [[],[]] .three = true := by decide
def e2422372985454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372985454 : Closed e2422372985454 ∧ code e2422372985454 = 11218466007662 := by decide
theorem cert_e2422372985454 : check e2422372985454 [[],[]] .smaller = true := by decide
def e2422372985466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372985466 : Closed e2422372985466 ∧ code e2422372985466 = 11218466007674 := by decide
theorem cert_e2422372985466 : check e2422372985466 [[],[]] .smaller = true := by decide
def e2422372985630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422372985630 : Closed e2422372985630 ∧ code e2422372985630 = 11218466007838 := by decide
theorem cert_e2422372985630 : check e2422372985630 [[],[]] .smaller = true := by decide
def e2422372985730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372985730 : Closed e2422372985730 ∧ code e2422372985730 = 11218466007938 := by decide
theorem cert_e2422372985730 : check e2422372985730 [[],[]] .smaller = true := by decide
def e2422372985742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422372985742 : Closed e2422372985742 ∧ code e2422372985742 = 11218466007950 := by decide
theorem cert_e2422372985742 : check e2422372985742 [[],[]] .smaller = true := by decide
def e2422372985754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372985754 : Closed e2422372985754 ∧ code e2422372985754 = 11218466007962 := by decide
theorem cert_e2422372985754 : check e2422372985754 [[],[]] .smaller = true := by decide
def e2422372985798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372985798 : Closed e2422372985798 ∧ code e2422372985798 = 11218466008006 := by decide
theorem cert_e2422372985798 : check e2422372985798 [[],[]] .three = true := by decide
def e2422372985822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)) (.var 3)))))))
theorem wire_e2422372985822 : Closed e2422372985822 ∧ code e2422372985822 = 11218466008030 := by decide
theorem cert_e2422372985822 : check e2422372985822 [[],[]] .three = true := by decide
def e2422372985950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372985950 : Closed e2422372985950 ∧ code e2422372985950 = 11218466008158 := by decide
theorem cert_e2422372985950 : check e2422372985950 [[],[]] .three = true := by decide
def e2422372985966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372985966 : Closed e2422372985966 ∧ code e2422372985966 = 11218466008174 := by decide
theorem cert_e2422372985966 : check e2422372985966 [[],[]] .smaller = true := by decide
def e2422372985978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372985978 : Closed e2422372985978 ∧ code e2422372985978 = 11218466008186 := by decide
theorem cert_e2422372985978 : check e2422372985978 [[],[]] .smaller = true := by decide
def e2422372986142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372986142 : Closed e2422372986142 ∧ code e2422372986142 = 11218466008350 := by decide
theorem cert_e2422372986142 : check e2422372986142 [[],[]] .smaller = true := by decide
def e2422372986310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372986310 : Closed e2422372986310 ∧ code e2422372986310 = 11218466008518 := by decide
theorem cert_e2422372986310 : check e2422372986310 [[],[]] .smaller = true := by decide
def e2422372986334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e2422372986334 : Closed e2422372986334 ∧ code e2422372986334 = 11218466008542 := by decide
theorem cert_e2422372986334 : check e2422372986334 [[],[]] .three = true := by decide
def e2422372986338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372986338 : Closed e2422372986338 ∧ code e2422372986338 = 11218466008546 := by decide
theorem cert_e2422372986338 : check e2422372986338 [[],[]] .three = true := by decide
def e2422372986350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e2422372986350 : Closed e2422372986350 ∧ code e2422372986350 = 11218466008558 := by decide
theorem cert_e2422372986350 : check e2422372986350 [[],[]] .three = true := by decide
def e2422372986378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372986378 : Closed e2422372986378 ∧ code e2422372986378 = 11218466008586 := by decide
theorem cert_e2422372986378 : check e2422372986378 [[],[]] .smaller = true := by decide
def e2422372986414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372986414 : Closed e2422372986414 ∧ code e2422372986414 = 11218466008622 := by decide
theorem cert_e2422372986414 : check e2422372986414 [[],[]] .smaller = true := by decide
def e2422372986422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372986422 : Closed e2422372986422 ∧ code e2422372986422 = 11218466008630 := by decide
theorem cert_e2422372986422 : check e2422372986422 [[],[]] .smaller = true := by decide
def e2422372986426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372986426 : Closed e2422372986426 ∧ code e2422372986426 = 11218466008634 := by decide
theorem cert_e2422372986426 : check e2422372986426 [[],[]] .smaller = true := by decide
def e2422372986474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372986474 : Closed e2422372986474 ∧ code e2422372986474 = 11218466008682 := by decide
theorem cert_e2422372986474 : check e2422372986474 [[],[]] .smaller = true := by decide
def e2422372986498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372986498 : Closed e2422372986498 ∧ code e2422372986498 = 11218466008706 := by decide
theorem cert_e2422372986498 : check e2422372986498 [[],[]] .smaller = true := by decide
def e2422372986510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372986510 : Closed e2422372986510 ∧ code e2422372986510 = 11218466008718 := by decide
theorem cert_e2422372986510 : check e2422372986510 [[],[]] .smaller = true := by decide
def e2422372986522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372986522 : Closed e2422372986522 ∧ code e2422372986522 = 11218466008730 := by decide
theorem cert_e2422372986522 : check e2422372986522 [[],[]] .smaller = true := by decide
def e2422372986566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372986566 : Closed e2422372986566 ∧ code e2422372986566 = 11218466008774 := by decide
theorem cert_e2422372986566 : check e2422372986566 [[],[]] .smaller = true := by decide
def e2422372986590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e2422372986590 : Closed e2422372986590 ∧ code e2422372986590 = 11218466008798 := by decide
theorem cert_e2422372986590 : check e2422372986590 [[],[]] .three = true := by decide
def e2422372986594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372986594 : Closed e2422372986594 ∧ code e2422372986594 = 11218466008802 := by decide
theorem cert_e2422372986594 : check e2422372986594 [[],[]] .smaller = true := by decide
def e2422372986606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 2)))))))
theorem wire_e2422372986606 : Closed e2422372986606 ∧ code e2422372986606 = 11218466008814 := by decide
theorem cert_e2422372986606 : check e2422372986606 [[],[]] .smaller = true := by decide
def e2422372986614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e2422372986614 : Closed e2422372986614 ∧ code e2422372986614 = 11218466008822 := by decide
theorem cert_e2422372986614 : check e2422372986614 [[],[]] .three = true := by decide
def e2422372986646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372986646 : Closed e2422372986646 ∧ code e2422372986646 = 11218466008854 := by decide
theorem cert_e2422372986646 : check e2422372986646 [[],[]] .three = true := by decide
def e2422372986650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372986650 : Closed e2422372986650 ∧ code e2422372986650 = 11218466008858 := by decide
theorem cert_e2422372986650 : check e2422372986650 [[],[]] .three = true := by decide
def e2422372986694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372986694 : Closed e2422372986694 ∧ code e2422372986694 = 11218466008902 := by decide
theorem cert_e2422372986694 : check e2422372986694 [[],[]] .three = true := by decide
def e2422372986718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)) (.var 3)))))))
theorem wire_e2422372986718 : Closed e2422372986718 ∧ code e2422372986718 = 11218466008926 := by decide
theorem cert_e2422372986718 : check e2422372986718 [[],[]] .three = true := by decide
def e2422372986722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372986722 : Closed e2422372986722 ∧ code e2422372986722 = 11218466008930 := by decide
theorem cert_e2422372986722 : check e2422372986722 [[],[]] .three = true := by decide
def e2422372986734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e2422372986734 : Closed e2422372986734 ∧ code e2422372986734 = 11218466008942 := by decide
theorem cert_e2422372986734 : check e2422372986734 [[],[]] .three = true := by decide
def e2422372986742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e2422372986742 : Closed e2422372986742 ∧ code e2422372986742 = 11218466008950 := by decide
theorem cert_e2422372986742 : check e2422372986742 [[],[]] .three = true := by decide
def e2422372986746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 3)) (.var 0)))))))
theorem wire_e2422372986746 : Closed e2422372986746 ∧ code e2422372986746 = 11218466008954 := by decide
theorem cert_e2422372986746 : check e2422372986746 [[],[]] .three = true := by decide
def e2422372987230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372987230 : Closed e2422372987230 ∧ code e2422372987230 = 11218466009438 := by decide
theorem cert_e2422372987230 : check e2422372987230 [[],[]] .three = true := by decide
def e2422372987258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372987258 : Closed e2422372987258 ∧ code e2422372987258 = 11218466009466 := by decide
theorem cert_e2422372987258 : check e2422372987258 [[],[]] .three = true := by decide
def e2422372987310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372987310 : Closed e2422372987310 ∧ code e2422372987310 = 11218466009518 := by decide
theorem cert_e2422372987310 : check e2422372987310 [[],[]] .smaller = true := by decide
def e2422372987322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372987322 : Closed e2422372987322 ∧ code e2422372987322 = 11218466009530 := by decide
theorem cert_e2422372987322 : check e2422372987322 [[],[]] .smaller = true := by decide
def e2422372987370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372987370 : Closed e2422372987370 ∧ code e2422372987370 = 11218466009578 := by decide
theorem cert_e2422372987370 : check e2422372987370 [[],[]] .smaller = true := by decide
def e2422372987998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372987998 : Closed e2422372987998 ∧ code e2422372987998 = 11218466010206 := by decide
theorem cert_e2422372987998 : check e2422372987998 [[],[]] .three = true := by decide
def e2422372988014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372988014 : Closed e2422372988014 ∧ code e2422372988014 = 11218466010222 := by decide
theorem cert_e2422372988014 : check e2422372988014 [[],[]] .smaller = true := by decide
def e2422372988026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372988026 : Closed e2422372988026 ∧ code e2422372988026 = 11218466010234 := by decide
theorem cert_e2422372988026 : check e2422372988026 [[],[]] .smaller = true := by decide
def e2422372988190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372988190 : Closed e2422372988190 ∧ code e2422372988190 = 11218466010398 := by decide
theorem cert_e2422372988190 : check e2422372988190 [[],[]] .smaller = true := by decide
def e2422372988358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372988358 : Closed e2422372988358 ∧ code e2422372988358 = 11218466010566 := by decide
theorem cert_e2422372988358 : check e2422372988358 [[],[]] .smaller = true := by decide
def e2422372988382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e2422372988382 : Closed e2422372988382 ∧ code e2422372988382 = 11218466010590 := by decide
theorem cert_e2422372988382 : check e2422372988382 [[],[]] .three = true := by decide
def e2422372988386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372988386 : Closed e2422372988386 ∧ code e2422372988386 = 11218466010594 := by decide
theorem cert_e2422372988386 : check e2422372988386 [[],[]] .three = true := by decide
def e2422372988398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e2422372988398 : Closed e2422372988398 ∧ code e2422372988398 = 11218466010606 := by decide
theorem cert_e2422372988398 : check e2422372988398 [[],[]] .three = true := by decide
def e2422372988698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372988698 : Closed e2422372988698 ∧ code e2422372988698 = 11218466010906 := by decide
theorem cert_e2422372988698 : check e2422372988698 [[],[]] .smaller = true := by decide
def e2422372988742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372988742 : Closed e2422372988742 ∧ code e2422372988742 = 11218466010950 := by decide
theorem cert_e2422372988742 : check e2422372988742 [[],[]] .smaller = true := by decide
def e2422372988766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e2422372988766 : Closed e2422372988766 ∧ code e2422372988766 = 11218466010974 := by decide
theorem cert_e2422372988766 : check e2422372988766 [[],[]] .three = true := by decide
def e2422372988794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e2422372988794 : Closed e2422372988794 ∧ code e2422372988794 = 11218466011002 := by decide
theorem cert_e2422372988794 : check e2422372988794 [[],[]] .three = true := by decide
def e2422372988810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372988810 : Closed e2422372988810 ∧ code e2422372988810 = 11218466011018 := by decide
theorem cert_e2422372988810 : check e2422372988810 [[],[]] .three = true := by decide
def e2422372988834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372988834 : Closed e2422372988834 ∧ code e2422372988834 = 11218466011042 := by decide
theorem cert_e2422372988834 : check e2422372988834 [[],[]] .three = true := by decide
def e2422372988846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e2422372988846 : Closed e2422372988846 ∧ code e2422372988846 = 11218466011054 := by decide
theorem cert_e2422372988846 : check e2422372988846 [[],[]] .three = true := by decide
def e2422372988858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e2422372988858 : Closed e2422372988858 ∧ code e2422372988858 = 11218466011066 := by decide
theorem cert_e2422372988858 : check e2422372988858 [[],[]] .three = true := by decide
def e2422372988970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)) (.var 0)))))))
theorem wire_e2422372988970 : Closed e2422372988970 ∧ code e2422372988970 = 11218466011178 := by decide
theorem cert_e2422372988970 : check e2422372988970 [[],[]] .smaller = true := by decide
def e2422372989102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372989102 : Closed e2422372989102 ∧ code e2422372989102 = 11218466011310 := by decide
theorem cert_e2422372989102 : check e2422372989102 [[],[]] .smaller = true := by decide
def e2422372989114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372989114 : Closed e2422372989114 ∧ code e2422372989114 = 11218466011322 := by decide
theorem cert_e2422372989114 : check e2422372989114 [[],[]] .smaller = true := by decide
def e2422372989142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372989142 : Closed e2422372989142 ∧ code e2422372989142 = 11218466011350 := by decide
theorem cert_e2422372989142 : check e2422372989142 [[],[]] .smaller = true := by decide
def e2422372989146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372989146 : Closed e2422372989146 ∧ code e2422372989146 = 11218466011354 := by decide
theorem cert_e2422372989146 : check e2422372989146 [[],[]] .smaller = true := by decide
def e2422372989162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372989162 : Closed e2422372989162 ∧ code e2422372989162 = 11218466011370 := by decide
theorem cert_e2422372989162 : check e2422372989162 [[],[]] .smaller = true := by decide
def e2422372989354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372989354 : Closed e2422372989354 ∧ code e2422372989354 = 11218466011562 := by decide
theorem cert_e2422372989354 : check e2422372989354 [[],[]] .smaller = true := by decide
def e2422372989450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372989450 : Closed e2422372989450 ∧ code e2422372989450 = 11218466011658 := by decide
theorem cert_e2422372989450 : check e2422372989450 [[],[]] .smaller = true := by decide
def e2422372989486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372989486 : Closed e2422372989486 ∧ code e2422372989486 = 11218466011694 := by decide
theorem cert_e2422372989486 : check e2422372989486 [[],[]] .smaller = true := by decide
def e2422372989494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372989494 : Closed e2422372989494 ∧ code e2422372989494 = 11218466011702 := by decide
theorem cert_e2422372989494 : check e2422372989494 [[],[]] .smaller = true := by decide
def e2422372989498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372989498 : Closed e2422372989498 ∧ code e2422372989498 = 11218466011706 := by decide
theorem cert_e2422372989498 : check e2422372989498 [[],[]] .smaller = true := by decide
def e2422372989546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372989546 : Closed e2422372989546 ∧ code e2422372989546 = 11218466011754 := by decide
theorem cert_e2422372989546 : check e2422372989546 [[],[]] .smaller = true := by decide
def e2422372989570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372989570 : Closed e2422372989570 ∧ code e2422372989570 = 11218466011778 := by decide
theorem cert_e2422372989570 : check e2422372989570 [[],[]] .smaller = true := by decide
def e2422372989582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372989582 : Closed e2422372989582 ∧ code e2422372989582 = 11218466011790 := by decide
theorem cert_e2422372989582 : check e2422372989582 [[],[]] .smaller = true := by decide
def e2422372989594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372989594 : Closed e2422372989594 ∧ code e2422372989594 = 11218466011802 := by decide
theorem cert_e2422372989594 : check e2422372989594 [[],[]] .smaller = true := by decide
def e2422372989638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372989638 : Closed e2422372989638 ∧ code e2422372989638 = 11218466011846 := by decide
theorem cert_e2422372989638 : check e2422372989638 [[],[]] .smaller = true := by decide
def e2422372989662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e2422372989662 : Closed e2422372989662 ∧ code e2422372989662 = 11218466011870 := by decide
theorem cert_e2422372989662 : check e2422372989662 [[],[]] .three = true := by decide
end Blc.Floor43
