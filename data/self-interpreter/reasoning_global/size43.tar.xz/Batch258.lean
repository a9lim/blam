import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405962338502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405962338502 : Closed e2405962338502 ∧ code e2405962338502 = 11202055360710 := by decide
theorem cert_e2405962338502 : check e2405962338502 [[]] .width = true := by decide
def e2405962341914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405962341914 : Closed e2405962341914 ∧ code e2405962341914 = 11202055364122 := by decide
theorem cert_e2405962341914 : check e2405962341914 [[]] .width = true := by decide
def e2405962809542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405962809542 : Closed e2405962809542 ∧ code e2405962809542 = 11202055831750 := by decide
theorem cert_e2405962809542 : check e2405962809542 [[]] .width = true := by decide
def e2405962810070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405962810070 : Closed e2405962810070 ∧ code e2405962810070 = 11202055832278 := by decide
theorem cert_e2405962810070 : check e2405962810070 [[]] .width = true := by decide
def e2405962810074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405962810074 : Closed e2405962810074 ∧ code e2405962810074 = 11202055832282 := by decide
theorem cert_e2405962810074 : check e2405962810074 [[]] .width = true := by decide
def e2405962810090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405962810090 : Closed e2405962810090 ∧ code e2405962810090 = 11202055832298 := by decide
theorem cert_e2405962810090 : check e2405962810090 [[]] .width = true := by decide
def e2405962810166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405962810166 : Closed e2405962810166 ∧ code e2405962810166 = 11202055832374 := by decide
theorem cert_e2405962810166 : check e2405962810166 [[]] .width = true := by decide
def e2405962810170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405962810170 : Closed e2405962810170 ∧ code e2405962810170 = 11202055832378 := by decide
theorem cert_e2405962810170 : check e2405962810170 [[]] .width = true := by decide
def e2405962810254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405962810254 : Closed e2405962810254 ∧ code e2405962810254 = 11202055832462 := by decide
theorem cert_e2405962810254 : check e2405962810254 [[]] .width = true := by decide
def e2405962810266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405962810266 : Closed e2405962810266 ∧ code e2405962810266 = 11202055832474 := by decide
theorem cert_e2405962810266 : check e2405962810266 [[]] .width = true := by decide
def e2405962812186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405962812186 : Closed e2405962812186 ∧ code e2405962812186 = 11202055834394 := by decide
theorem cert_e2405962812186 : check e2405962812186 [[]] .width = true := by decide
def e2405962812230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405962812230 : Closed e2405962812230 ∧ code e2405962812230 = 11202055834438 := by decide
theorem cert_e2405962812230 : check e2405962812230 [[]] .width = true := by decide
def e2405962812470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405962812470 : Closed e2405962812470 ∧ code e2405962812470 = 11202055834678 := by decide
theorem cert_e2405962812470 : check e2405962812470 [[]] .width = true := by decide
def e2405962812474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405962812474 : Closed e2405962812474 ∧ code e2405962812474 = 11202055834682 := by decide
theorem cert_e2405962812474 : check e2405962812474 [[]] .width = true := by decide
def e2405962812614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405962812614 : Closed e2405962812614 ∧ code e2405962812614 = 11202055834822 := by decide
theorem cert_e2405962812614 : check e2405962812614 [[]] .width = true := by decide
def e2405963315226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963315226 : Closed e2405963315226 ∧ code e2405963315226 = 11202056337434 := by decide
theorem cert_e2405963315226 : check e2405963315226 [[]] .width = true := by decide
def e2405963327514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963327514 : Closed e2405963327514 ∧ code e2405963327514 = 11202056349722 := by decide
theorem cert_e2405963327514 : check e2405963327514 [[]] .width = true := by decide
def e2405963329050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405963329050 : Closed e2405963329050 ∧ code e2405963329050 = 11202056351258 := by decide
theorem cert_e2405963329050 : check e2405963329050 [[]] .width = true := by decide
def e2405963376666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963376666 : Closed e2405963376666 ∧ code e2405963376666 = 11202056398874 := by decide
theorem cert_e2405963376666 : check e2405963376666 [[]] .width = true := by decide
def e2405963378202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405963378202 : Closed e2405963378202 ∧ code e2405963378202 = 11202056400410 := by decide
theorem cert_e2405963378202 : check e2405963378202 [[]] .width = true := by decide
def e2405963381274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405963381274 : Closed e2405963381274 ∧ code e2405963381274 = 11202056403482 := by decide
theorem cert_e2405963381274 : check e2405963381274 [[]] .width = true := by decide
def e2405963460806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405963460806 : Closed e2405963460806 ∧ code e2405963460806 = 11202056483014 := by decide
theorem cert_e2405963460806 : check e2405963460806 [[]] .width = true := by decide
def e2405963511834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963511834 : Closed e2405963511834 ∧ code e2405963511834 = 11202056534042 := by decide
theorem cert_e2405963511834 : check e2405963511834 [[]] .width = true := by decide
def e2405963524122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963524122 : Closed e2405963524122 ∧ code e2405963524122 = 11202056546330 := by decide
theorem cert_e2405963524122 : check e2405963524122 [[]] .width = true := by decide
def e2405963525658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405963525658 : Closed e2405963525658 ∧ code e2405963525658 = 11202056547866 := by decide
theorem cert_e2405963525658 : check e2405963525658 [[]] .width = true := by decide
def e2405963628570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405963628570 : Closed e2405963628570 ∧ code e2405963628570 = 11202056650778 := by decide
theorem cert_e2405963628570 : check e2405963628570 [[]] .width = true := by decide
def e2405963628662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405963628662 : Closed e2405963628662 ∧ code e2405963628662 = 11202056650870 := by decide
theorem cert_e2405963628662 : check e2405963628662 [[]] .width = true := by decide
def e2405963628906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405963628906 : Closed e2405963628906 ∧ code e2405963628906 = 11202056651114 := by decide
theorem cert_e2405963628906 : check e2405963628906 [[]] .width = true := by decide
def e2405963628954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405963628954 : Closed e2405963628954 ∧ code e2405963628954 = 11202056651162 := by decide
theorem cert_e2405963628954 : check e2405963628954 [[]] .width = true := by decide
def e2405963629962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405963629962 : Closed e2405963629962 ∧ code e2405963629962 = 11202056652170 := by decide
theorem cert_e2405963629962 : check e2405963629962 [[]] .width = true := by decide
def e2405963629986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405963629986 : Closed e2405963629986 ∧ code e2405963629986 = 11202056652194 := by decide
theorem cert_e2405963629986 : check e2405963629986 [[]] .width = true := by decide
def e2405963630094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405963630094 : Closed e2405963630094 ∧ code e2405963630094 = 11202056652302 := by decide
theorem cert_e2405963630094 : check e2405963630094 [[]] .width = true := by decide
def e2405963630106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405963630106 : Closed e2405963630106 ∧ code e2405963630106 = 11202056652314 := by decide
theorem cert_e2405963630106 : check e2405963630106 [[]] .width = true := by decide
def e2405963630178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405963630178 : Closed e2405963630178 ∧ code e2405963630178 = 11202056652386 := by decide
theorem cert_e2405963630178 : check e2405963630178 [[]] .width = true := by decide
def e2405963776198 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405963776198 : Closed e2405963776198 ∧ code e2405963776198 = 11202056798406 := by decide
theorem cert_e2405963776198 : check e2405963776198 [[]] .width = true := by decide
def e2405963794458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963794458 : Closed e2405963794458 ∧ code e2405963794458 = 11202056816666 := by decide
theorem cert_e2405963794458 : check e2405963794458 [[]] .width = true := by decide
def e2405963800602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405963800602 : Closed e2405963800602 ∧ code e2405963800602 = 11202056822810 := by decide
theorem cert_e2405963800602 : check e2405963800602 [[]] .width = true := by decide
def e2405963800694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405963800694 : Closed e2405963800694 ∧ code e2405963800694 = 11202056822902 := by decide
theorem cert_e2405963800694 : check e2405963800694 [[]] .width = true := by decide
def e2405963800938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405963800938 : Closed e2405963800938 ∧ code e2405963800938 = 11202056823146 := by decide
theorem cert_e2405963800938 : check e2405963800938 [[]] .width = true := by decide
def e2405963800986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405963800986 : Closed e2405963800986 ∧ code e2405963800986 = 11202056823194 := by decide
theorem cert_e2405963800986 : check e2405963800986 [[]] .width = true := by decide
def e2405963804870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405963804870 : Closed e2405963804870 ∧ code e2405963804870 = 11202056827078 := by decide
theorem cert_e2405963804870 : check e2405963804870 [[]] .width = true := by decide
def e2405963806746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963806746 : Closed e2405963806746 ∧ code e2405963806746 = 11202056828954 := by decide
theorem cert_e2405963806746 : check e2405963806746 [[]] .width = true := by decide
def e2405963819034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405963819034 : Closed e2405963819034 ∧ code e2405963819034 = 11202056841242 := by decide
theorem cert_e2405963819034 : check e2405963819034 [[]] .width = true := by decide
def e2405963820570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405963820570 : Closed e2405963820570 ∧ code e2405963820570 = 11202056842778 := by decide
theorem cert_e2405963820570 : check e2405963820570 [[]] .width = true := by decide
def e2405963823642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405963823642 : Closed e2405963823642 ∧ code e2405963823642 = 11202056845850 := by decide
theorem cert_e2405963823642 : check e2405963823642 [[]] .width = true := by decide
def e2405963825178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405963825178 : Closed e2405963825178 ∧ code e2405963825178 = 11202056847386 := by decide
theorem cert_e2405963825178 : check e2405963825178 [[]] .width = true := by decide
def e2405963825270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405963825270 : Closed e2405963825270 ∧ code e2405963825270 = 11202056847478 := by decide
theorem cert_e2405963825270 : check e2405963825270 [[]] .width = true := by decide
def e2405963825514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405963825514 : Closed e2405963825514 ∧ code e2405963825514 = 11202056847722 := by decide
theorem cert_e2405963825514 : check e2405963825514 [[]] .width = true := by decide
def e2405963825562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405963825562 : Closed e2405963825562 ∧ code e2405963825562 = 11202056847770 := by decide
theorem cert_e2405963825562 : check e2405963825562 [[]] .width = true := by decide
def e2405963826570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405963826570 : Closed e2405963826570 ∧ code e2405963826570 = 11202056848778 := by decide
theorem cert_e2405963826570 : check e2405963826570 [[]] .width = true := by decide
def e2405963826594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405963826594 : Closed e2405963826594 ∧ code e2405963826594 = 11202056848802 := by decide
theorem cert_e2405963826594 : check e2405963826594 [[]] .width = true := by decide
def e2405963826702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405963826702 : Closed e2405963826702 ∧ code e2405963826702 = 11202056848910 := by decide
theorem cert_e2405963826702 : check e2405963826702 [[]] .width = true := by decide
def e2405963826714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405963826714 : Closed e2405963826714 ∧ code e2405963826714 = 11202056848922 := by decide
theorem cert_e2405963826714 : check e2405963826714 [[]] .width = true := by decide
def e2405963826786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405963826786 : Closed e2405963826786 ∧ code e2405963826786 = 11202056848994 := by decide
theorem cert_e2405963826786 : check e2405963826786 [[]] .width = true := by decide
def e2405963841734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405963841734 : Closed e2405963841734 ∧ code e2405963841734 = 11202056863942 := by decide
theorem cert_e2405963841734 : check e2405963841734 [[]] .width = true := by decide
def e2405963849754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405963849754 : Closed e2405963849754 ∧ code e2405963849754 = 11202056871962 := by decide
theorem cert_e2405963849754 : check e2405963849754 [[]] .width = true := by decide
def e2405963849846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405963849846 : Closed e2405963849846 ∧ code e2405963849846 = 11202056872054 := by decide
theorem cert_e2405963849846 : check e2405963849846 [[]] .width = true := by decide
def e2405963850090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405963850090 : Closed e2405963850090 ∧ code e2405963850090 = 11202056872298 := by decide
theorem cert_e2405963850090 : check e2405963850090 [[]] .width = true := by decide
def e2405963850138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405963850138 : Closed e2405963850138 ∧ code e2405963850138 = 11202056872346 := by decide
theorem cert_e2405963850138 : check e2405963850138 [[]] .width = true := by decide
def e2405965496346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2405965496346 : Closed e2405965496346 ∧ code e2405965496346 = 11202058518554 := by decide
theorem cert_e2405965496346 : check e2405965496346 [[]] .width = true := by decide
def e2405965496438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2405965496438 : Closed e2405965496438 ∧ code e2405965496438 = 11202058518646 := by decide
theorem cert_e2405965496438 : check e2405965496438 [[]] .width = true := by decide
def e2405965496682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2405965496682 : Closed e2405965496682 ∧ code e2405965496682 = 11202058518890 := by decide
theorem cert_e2405965496682 : check e2405965496682 [[]] .width = true := by decide
def e2405965496730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2405965496730 : Closed e2405965496730 ∧ code e2405965496730 = 11202058518938 := by decide
theorem cert_e2405965496730 : check e2405965496730 [[]] .width = true := by decide
def e2405965496814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2405965496814 : Closed e2405965496814 ∧ code e2405965496814 = 11202058519022 := by decide
theorem cert_e2405965496814 : check e2405965496814 [[]] .width = true := by decide
def e2405965497738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2405965497738 : Closed e2405965497738 ∧ code e2405965497738 = 11202058519946 := by decide
theorem cert_e2405965497738 : check e2405965497738 [[]] .width = true := by decide
def e2405965497762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2405965497762 : Closed e2405965497762 ∧ code e2405965497762 = 11202058519970 := by decide
theorem cert_e2405965497762 : check e2405965497762 [[]] .width = true := by decide
def e2405965497774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2405965497774 : Closed e2405965497774 ∧ code e2405965497774 = 11202058519982 := by decide
theorem cert_e2405965497774 : check e2405965497774 [[]] .width = true := by decide
def e2405965497782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2405965497782 : Closed e2405965497782 ∧ code e2405965497782 = 11202058519990 := by decide
theorem cert_e2405965497782 : check e2405965497782 [[]] .width = true := by decide
def e2405965497786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2405965497786 : Closed e2405965497786 ∧ code e2405965497786 = 11202058519994 := by decide
theorem cert_e2405965497786 : check e2405965497786 [[]] .width = true := by decide
def e2405965497814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2405965497814 : Closed e2405965497814 ∧ code e2405965497814 = 11202058520022 := by decide
theorem cert_e2405965497814 : check e2405965497814 [[]] .width = true := by decide
def e2405965497818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2405965497818 : Closed e2405965497818 ∧ code e2405965497818 = 11202058520026 := by decide
theorem cert_e2405965497818 : check e2405965497818 [[]] .width = true := by decide
def e2405965497834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2405965497834 : Closed e2405965497834 ∧ code e2405965497834 = 11202058520042 := by decide
theorem cert_e2405965497834 : check e2405965497834 [[]] .width = true := by decide
def e2405965497870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2405965497870 : Closed e2405965497870 ∧ code e2405965497870 = 11202058520078 := by decide
theorem cert_e2405965497870 : check e2405965497870 [[]] .width = true := by decide
def e2405965497882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405965497882 : Closed e2405965497882 ∧ code e2405965497882 = 11202058520090 := by decide
theorem cert_e2405965497882 : check e2405965497882 [[]] .width = true := by decide
def e2405965497954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2405965497954 : Closed e2405965497954 ∧ code e2405965497954 = 11202058520162 := by decide
theorem cert_e2405965497954 : check e2405965497954 [[]] .width = true := by decide
def e2405965497966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2405965497966 : Closed e2405965497966 ∧ code e2405965497966 = 11202058520174 := by decide
theorem cert_e2405965497966 : check e2405965497966 [[]] .width = true := by decide
def e2405965497974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2405965497974 : Closed e2405965497974 ∧ code e2405965497974 = 11202058520182 := by decide
theorem cert_e2405965497974 : check e2405965497974 [[]] .width = true := by decide
def e2405965497978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2405965497978 : Closed e2405965497978 ∧ code e2405965497978 = 11202058520186 := by decide
theorem cert_e2405965497978 : check e2405965497978 [[]] .width = true := by decide
def e2405965498166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2405965498166 : Closed e2405965498166 ∧ code e2405965498166 = 11202058520374 := by decide
theorem cert_e2405965498166 : check e2405965498166 [[]] .width = true := by decide
def e2405965498170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2405965498170 : Closed e2405965498170 ∧ code e2405965498170 = 11202058520378 := by decide
theorem cert_e2405965498170 : check e2405965498170 [[]] .width = true := by decide
def e2405965498266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2405965498266 : Closed e2405965498266 ∧ code e2405965498266 = 11202058520474 := by decide
theorem cert_e2405965498266 : check e2405965498266 [[]] .width = true := by decide
def e2405965501866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2405965501866 : Closed e2405965501866 ∧ code e2405965501866 = 11202058524074 := by decide
theorem cert_e2405965501866 : check e2405965501866 [[]] .width = true := by decide
def e2405965501962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2405965501962 : Closed e2405965501962 ∧ code e2405965501962 = 11202058524170 := by decide
theorem cert_e2405965501962 : check e2405965501962 [[]] .width = true := by decide
def e2405965502006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2405965502006 : Closed e2405965502006 ∧ code e2405965502006 = 11202058524214 := by decide
theorem cert_e2405965502006 : check e2405965502006 [[]] .width = true := by decide
def e2405965502010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2405965502010 : Closed e2405965502010 ∧ code e2405965502010 = 11202058524218 := by decide
theorem cert_e2405965502010 : check e2405965502010 [[]] .width = true := by decide
def e2405965502058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2405965502058 : Closed e2405965502058 ∧ code e2405965502058 = 11202058524266 := by decide
theorem cert_e2405965502058 : check e2405965502058 [[]] .width = true := by decide
def e2405965502082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2405965502082 : Closed e2405965502082 ∧ code e2405965502082 = 11202058524290 := by decide
theorem cert_e2405965502082 : check e2405965502082 [[]] .width = true := by decide
def e2405965502094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2405965502094 : Closed e2405965502094 ∧ code e2405965502094 = 11202058524302 := by decide
theorem cert_e2405965502094 : check e2405965502094 [[]] .width = true := by decide
def e2405965502106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2405965502106 : Closed e2405965502106 ∧ code e2405965502106 = 11202058524314 := by decide
theorem cert_e2405965502106 : check e2405965502106 [[]] .width = true := by decide
def e2405965502150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2405965502150 : Closed e2405965502150 ∧ code e2405965502150 = 11202058524358 := by decide
theorem cert_e2405965502150 : check e2405965502150 [[]] .width = true := by decide
def e2405965502230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2405965502230 : Closed e2405965502230 ∧ code e2405965502230 = 11202058524438 := by decide
theorem cert_e2405965502230 : check e2405965502230 [[]] .width = true := by decide
def e2405965502234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2405965502234 : Closed e2405965502234 ∧ code e2405965502234 = 11202058524442 := by decide
theorem cert_e2405965502234 : check e2405965502234 [[]] .width = true := by decide
def e2405965502278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2405965502278 : Closed e2405965502278 ∧ code e2405965502278 = 11202058524486 := by decide
theorem cert_e2405965502278 : check e2405965502278 [[]] .width = true := by decide
def e2405965502306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2405965502306 : Closed e2405965502306 ∧ code e2405965502306 = 11202058524514 := by decide
theorem cert_e2405965502306 : check e2405965502306 [[]] .width = true := by decide
def e2405965502490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405965502490 : Closed e2405965502490 ∧ code e2405965502490 = 11202058524698 := by decide
theorem cert_e2405965502490 : check e2405965502490 [[]] .width = true := by decide
def e2405965502582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405965502582 : Closed e2405965502582 ∧ code e2405965502582 = 11202058524790 := by decide
theorem cert_e2405965502582 : check e2405965502582 [[]] .width = true := by decide
def e2405965502826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405965502826 : Closed e2405965502826 ∧ code e2405965502826 = 11202058525034 := by decide
theorem cert_e2405965502826 : check e2405965502826 [[]] .width = true := by decide
def e2405965502850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))))))
theorem wire_e2405965502850 : Closed e2405965502850 ∧ code e2405965502850 = 11202058525058 := by decide
theorem cert_e2405965502850 : check e2405965502850 [[]] .width = true := by decide
def e2405965502862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405965502862 : Closed e2405965502862 ∧ code e2405965502862 = 11202058525070 := by decide
theorem cert_e2405965502862 : check e2405965502862 [[]] .width = true := by decide
def e2405965502874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405965502874 : Closed e2405965502874 ∧ code e2405965502874 = 11202058525082 := by decide
theorem cert_e2405965502874 : check e2405965502874 [[]] .width = true := by decide
def e2405965502918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405965502918 : Closed e2405965502918 ∧ code e2405965502918 = 11202058525126 := by decide
theorem cert_e2405965502918 : check e2405965502918 [[]] .width = true := by decide
def e2405965503518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))))
theorem wire_e2405965503518 : Closed e2405965503518 ∧ code e2405965503518 = 11202058525726 := by decide
theorem cert_e2405965503518 : check e2405965503518 [[]] .width = true := by decide
def e2405965503686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405965503686 : Closed e2405965503686 ∧ code e2405965503686 = 11202058525894 := by decide
theorem cert_e2405965503686 : check e2405965503686 [[]] .width = true := by decide
def e2405965503714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2405965503714 : Closed e2405965503714 ∧ code e2405965503714 = 11202058525922 := by decide
theorem cert_e2405965503714 : check e2405965503714 [[]] .width = true := by decide
def e2405965518378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 0))))
theorem wire_e2405965518378 : Closed e2405965518378 ∧ code e2405965518378 = 11202058540586 := by decide
theorem cert_e2405965518378 : check e2405965518378 [[]] .width = true := by decide
def e2405965518474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2405965518474 : Closed e2405965518474 ∧ code e2405965518474 = 11202058540682 := by decide
theorem cert_e2405965518474 : check e2405965518474 [[]] .width = true := by decide
def e2405965518498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405965518498 : Closed e2405965518498 ∧ code e2405965518498 = 11202058540706 := by decide
theorem cert_e2405965518498 : check e2405965518498 [[]] .width = true := by decide
def e2405965518858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2405965518858 : Closed e2405965518858 ∧ code e2405965518858 = 11202058541066 := by decide
theorem cert_e2405965518858 : check e2405965518858 [[]] .width = true := by decide
def e2405965518906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2405965518906 : Closed e2405965518906 ∧ code e2405965518906 = 11202058541114 := by decide
theorem cert_e2405965518906 : check e2405965518906 [[]] .width = true := by decide
def e2405965518954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2405965518954 : Closed e2405965518954 ∧ code e2405965518954 = 11202058541162 := by decide
theorem cert_e2405965518954 : check e2405965518954 [[]] .width = true := by decide
def e2405965519002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2405965519002 : Closed e2405965519002 ∧ code e2405965519002 = 11202058541210 := by decide
theorem cert_e2405965519002 : check e2405965519002 [[]] .width = true := by decide
def e2405965519046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2405965519046 : Closed e2405965519046 ∧ code e2405965519046 = 11202058541254 := by decide
theorem cert_e2405965519046 : check e2405965519046 [[]] .width = true := by decide
def e2405965519242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2405965519242 : Closed e2405965519242 ∧ code e2405965519242 = 11202058541450 := by decide
theorem cert_e2405965519242 : check e2405965519242 [[]] .width = true := by decide
def e2405965519266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2405965519266 : Closed e2405965519266 ∧ code e2405965519266 = 11202058541474 := by decide
theorem cert_e2405965519266 : check e2405965519266 [[]] .width = true := by decide
def e2405965519362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2405965519362 : Closed e2405965519362 ∧ code e2405965519362 = 11202058541570 := by decide
theorem cert_e2405965519362 : check e2405965519362 [[]] .width = true := by decide
def e2405965519374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2405965519374 : Closed e2405965519374 ∧ code e2405965519374 = 11202058541582 := by decide
theorem cert_e2405965519374 : check e2405965519374 [[]] .width = true := by decide
def e2405965519386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405965519386 : Closed e2405965519386 ∧ code e2405965519386 = 11202058541594 := by decide
theorem cert_e2405965519386 : check e2405965519386 [[]] .width = true := by decide
def e2405965519458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405965519458 : Closed e2405965519458 ∧ code e2405965519458 = 11202058541666 := by decide
theorem cert_e2405965519458 : check e2405965519458 [[]] .width = true := by decide
def e2405965520922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2405965520922 : Closed e2405965520922 ∧ code e2405965520922 = 11202058543130 := by decide
theorem cert_e2405965520922 : check e2405965520922 [[]] .width = true := by decide
def e2405965521006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2405965521006 : Closed e2405965521006 ∧ code e2405965521006 = 11202058543214 := by decide
theorem cert_e2405965521006 : check e2405965521006 [[]] .width = true := by decide
def e2405965521014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2405965521014 : Closed e2405965521014 ∧ code e2405965521014 = 11202058543222 := by decide
theorem cert_e2405965521014 : check e2405965521014 [[]] .width = true := by decide
def e2405965521018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2405965521018 : Closed e2405965521018 ∧ code e2405965521018 = 11202058543226 := by decide
theorem cert_e2405965521018 : check e2405965521018 [[]] .width = true := by decide
def e2405965521258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2405965521258 : Closed e2405965521258 ∧ code e2405965521258 = 11202058543466 := by decide
theorem cert_e2405965521258 : check e2405965521258 [[]] .width = true := by decide
def e2405965521294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2405965521294 : Closed e2405965521294 ∧ code e2405965521294 = 11202058543502 := by decide
theorem cert_e2405965521294 : check e2405965521294 [[]] .width = true := by decide
def e2405965521306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2405965521306 : Closed e2405965521306 ∧ code e2405965521306 = 11202058543514 := by decide
theorem cert_e2405965521306 : check e2405965521306 [[]] .width = true := by decide
def e2405965521350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2405965521350 : Closed e2405965521350 ∧ code e2405965521350 = 11202058543558 := by decide
theorem cert_e2405965521350 : check e2405965521350 [[]] .width = true := by decide
def e2405965522314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2405965522314 : Closed e2405965522314 ∧ code e2405965522314 = 11202058544522 := by decide
theorem cert_e2405965522314 : check e2405965522314 [[]] .width = true := by decide
def e2405965522338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2405965522338 : Closed e2405965522338 ∧ code e2405965522338 = 11202058544546 := by decide
theorem cert_e2405965522338 : check e2405965522338 [[]] .width = true := by decide
def e2405965522434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2405965522434 : Closed e2405965522434 ∧ code e2405965522434 = 11202058544642 := by decide
theorem cert_e2405965522434 : check e2405965522434 [[]] .width = true := by decide
def e2405965522446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2405965522446 : Closed e2405965522446 ∧ code e2405965522446 = 11202058544654 := by decide
theorem cert_e2405965522446 : check e2405965522446 [[]] .width = true := by decide
def e2405965522458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405965522458 : Closed e2405965522458 ∧ code e2405965522458 = 11202058544666 := by decide
theorem cert_e2405965522458 : check e2405965522458 [[]] .width = true := by decide
def e2405965522530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2405965522530 : Closed e2405965522530 ∧ code e2405965522530 = 11202058544738 := by decide
theorem cert_e2405965522530 : check e2405965522530 [[]] .width = true := by decide
def e2405965568514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2405965568514 : Closed e2405965568514 ∧ code e2405965568514 = 11202058590722 := by decide
theorem cert_e2405965568514 : check e2405965568514 [[]] .width = true := by decide
def e2405965568538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405965568538 : Closed e2405965568538 ∧ code e2405965568538 = 11202058590746 := by decide
theorem cert_e2405965568538 : check e2405965568538 [[]] .width = true := by decide
def e2405966921926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405966921926 : Closed e2405966921926 ∧ code e2405966921926 = 11202059944134 := by decide
theorem cert_e2405966921926 : check e2405966921926 [[]] .width = true := by decide
def e2405967009818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405967009818 : Closed e2405967009818 ∧ code e2405967009818 = 11202060032026 := by decide
theorem cert_e2405967009818 : check e2405967009818 [[]] .width = true := by decide
def e2405967020230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405967020230 : Closed e2405967020230 ∧ code e2405967020230 = 11202060042438 := by decide
theorem cert_e2405967020230 : check e2405967020230 [[]] .width = true := by decide
def e2405968175130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405968175130 : Closed e2405968175130 ∧ code e2405968175130 = 11202061197338 := by decide
theorem cert_e2405968175130 : check e2405968175130 [[]] .width = true := by decide
def e2405968175222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405968175222 : Closed e2405968175222 ∧ code e2405968175222 = 11202061197430 := by decide
private def t_e2405968175222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405968175222 : ¬ IsSelfInterpreter e2405968175222 :=
  wSource (t := t_e2405968175222) (replay_sound (ps := []) (t := e2405968175222) (by decide)) (by decide)
def e2405968175466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405968175466 : Closed e2405968175466 ∧ code e2405968175466 = 11202061197674 := by decide
private def t_e2405968175466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405968175466 : ¬ IsSelfInterpreter e2405968175466 :=
  wSource (t := t_e2405968175466) (replay_sound (ps := []) (t := e2405968175466) (by decide)) (by decide)
def e2405968175514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405968175514 : Closed e2405968175514 ∧ code e2405968175514 = 11202061197722 := by decide
private def t_e2405968175514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405968175514 : ¬ IsSelfInterpreter e2405968175514 :=
  wSource (t := t_e2405968175514) (replay_sound (ps := []) (t := e2405968175514) (by decide)) (by decide)
def e2405968228550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405968228550 : Closed e2405968228550 ∧ code e2405968228550 = 11202061250758 := by decide
theorem cert_e2405968228550 : check e2405968228550 [[]] .width = true := by decide
def e2405968236742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405968236742 : Closed e2405968236742 ∧ code e2405968236742 = 11202061258950 := by decide
theorem cert_e2405968236742 : check e2405968236742 [[]] .width = true := by decide
def e2405968238618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405968238618 : Closed e2405968238618 ∧ code e2405968238618 = 11202061260826 := by decide
theorem cert_e2405968238618 : check e2405968238618 [[]] .width = true := by decide
def e2405968240154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968240154 : Closed e2405968240154 ∧ code e2405968240154 = 11202061262362 := by decide
private def t_e2405968240154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968240154 : ¬ IsSelfInterpreter e2405968240154 :=
  wSource (t := t_e2405968240154) (replay_sound (ps := []) (t := e2405968240154) (by decide)) (by decide)
def e2405968246298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405968246298 : Closed e2405968246298 ∧ code e2405968246298 = 11202061268506 := by decide
private def t_e2405968246298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405968246298 : ¬ IsSelfInterpreter e2405968246298 :=
  wSource (t := t_e2405968246298) (replay_sound (ps := []) (t := e2405968246298) (by decide)) (by decide)
def e2405968314566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405968314566 : Closed e2405968314566 ∧ code e2405968314566 = 11202061336774 := by decide
theorem cert_e2405968314566 : check e2405968314566 [[]] .width = true := by decide
def e2405968315094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405968315094 : Closed e2405968315094 ∧ code e2405968315094 = 11202061337302 := by decide
theorem cert_e2405968315094 : check e2405968315094 [[]] .width = true := by decide
def e2405968315098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405968315098 : Closed e2405968315098 ∧ code e2405968315098 = 11202061337306 := by decide
theorem cert_e2405968315098 : check e2405968315098 [[]] .width = true := by decide
def e2405968315114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405968315114 : Closed e2405968315114 ∧ code e2405968315114 = 11202061337322 := by decide
theorem cert_e2405968315114 : check e2405968315114 [[]] .width = true := by decide
def e2405968315190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405968315190 : Closed e2405968315190 ∧ code e2405968315190 = 11202061337398 := by decide
theorem cert_e2405968315190 : check e2405968315190 [[]] .width = true := by decide
def e2405968315194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405968315194 : Closed e2405968315194 ∧ code e2405968315194 = 11202061337402 := by decide
theorem cert_e2405968315194 : check e2405968315194 [[]] .width = true := by decide
def e2405968315278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405968315278 : Closed e2405968315278 ∧ code e2405968315278 = 11202061337486 := by decide
theorem cert_e2405968315278 : check e2405968315278 [[]] .width = true := by decide
def e2405968315290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405968315290 : Closed e2405968315290 ∧ code e2405968315290 = 11202061337498 := by decide
theorem cert_e2405968315290 : check e2405968315290 [[]] .width = true := by decide
def e2405968317210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405968317210 : Closed e2405968317210 ∧ code e2405968317210 = 11202061339418 := by decide
theorem cert_e2405968317210 : check e2405968317210 [[]] .width = true := by decide
def e2405968317254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405968317254 : Closed e2405968317254 ∧ code e2405968317254 = 11202061339462 := by decide
private def t_e2405968317254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem cert_e2405968317254 : ¬ IsSelfInterpreter e2405968317254 :=
  wSource (t := t_e2405968317254) (replay_sound (ps := []) (t := e2405968317254) (by decide)) (by decide)
def e2405968317494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405968317494 : Closed e2405968317494 ∧ code e2405968317494 = 11202061339702 := by decide
private def t_e2405968317494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem cert_e2405968317494 : ¬ IsSelfInterpreter e2405968317494 :=
  wSource (t := t_e2405968317494) (replay_sound (ps := []) (t := e2405968317494) (by decide)) (by decide)
def e2405968317498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405968317498 : Closed e2405968317498 ∧ code e2405968317498 = 11202061339706 := by decide
private def t_e2405968317498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem cert_e2405968317498 : ¬ IsSelfInterpreter e2405968317498 :=
  wSource (t := t_e2405968317498) (replay_sound (ps := []) (t := e2405968317498) (by decide)) (by decide)
def e2405968317638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405968317638 : Closed e2405968317638 ∧ code e2405968317638 = 11202061339846 := by decide
theorem cert_e2405968317638 : check e2405968317638 [[]] .width = true := by decide
def e2405968488474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405968488474 : Closed e2405968488474 ∧ code e2405968488474 = 11202061510682 := by decide
theorem cert_e2405968488474 : check e2405968488474 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405968175222
#print axioms Blc.Floor43.cert_e2405968175466
#print axioms Blc.Floor43.cert_e2405968175514
#print axioms Blc.Floor43.cert_e2405968240154
#print axioms Blc.Floor43.cert_e2405968246298
#print axioms Blc.Floor43.cert_e2405968317254
#print axioms Blc.Floor43.cert_e2405968317494
#print axioms Blc.Floor43.cert_e2405968317498
