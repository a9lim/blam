import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373300022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373300022 : Closed e2422373300022 ∧ code e2422373300022 = 11218466322230 := by decide
theorem cert_e2422373300022 : check e2422373300022 [[],[]] .smaller = true := by decide
def e2422373300026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373300026 : Closed e2422373300026 ∧ code e2422373300026 = 11218466322234 := by decide
theorem cert_e2422373300026 : check e2422373300026 [[],[]] .smaller = true := by decide
def e2422373300110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))) (.lam (.var 2))))))))
theorem wire_e2422373300110 : Closed e2422373300110 ∧ code e2422373300110 = 11218466322318 := by decide
theorem cert_e2422373300110 : check e2422373300110 [[],[]] .three = true := by decide
def e2422373300270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0)))))) (.var 2)))))))
theorem wire_e2422373300270 : Closed e2422373300270 ∧ code e2422373300270 = 11218466322478 := by decide
theorem cert_e2422373300270 : check e2422373300270 [[],[]] .smaller = true := by decide
def e2422373300446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 3)))))))
theorem wire_e2422373300446 : Closed e2422373300446 ∧ code e2422373300446 = 11218466322654 := by decide
theorem cert_e2422373300446 : check e2422373300446 [[],[]] .three = true := by decide
def e2422373300462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422373300462 : Closed e2422373300462 ∧ code e2422373300462 = 11218466322670 := by decide
theorem cert_e2422373300462 : check e2422373300462 [[],[]] .smaller = true := by decide
def e2422373300470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.var 1)))))))
theorem wire_e2422373300470 : Closed e2422373300470 ∧ code e2422373300470 = 11218466322678 := by decide
theorem cert_e2422373300470 : check e2422373300470 [[],[]] .smaller = true := by decide
def e2422373300474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422373300474 : Closed e2422373300474 ∧ code e2422373300474 = 11218466322682 := by decide
theorem cert_e2422373300474 : check e2422373300474 [[],[]] .three = true := by decide
def e2422373300654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e2422373300654 : Closed e2422373300654 ∧ code e2422373300654 = 11218466322862 := by decide
theorem cert_e2422373300654 : check e2422373300654 [[],[]] .smaller = true := by decide
def e2422373300666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373300666 : Closed e2422373300666 ∧ code e2422373300666 = 11218466322874 := by decide
theorem cert_e2422373300666 : check e2422373300666 [[],[]] .smaller = true := by decide
def e2422373300714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373300714 : Closed e2422373300714 ∧ code e2422373300714 = 11218466322922 := by decide
theorem cert_e2422373300714 : check e2422373300714 [[],[]] .smaller = true := by decide
def e2422373300798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 4))))))))
theorem wire_e2422373300798 : Closed e2422373300798 ∧ code e2422373300798 = 11218466323006 := by decide
theorem cert_e2422373300798 : check e2422373300798 [[],[]] .three = true := by decide
def e2422373300846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373300846 : Closed e2422373300846 ∧ code e2422373300846 = 11218466323054 := by decide
theorem cert_e2422373300846 : check e2422373300846 [[],[]] .smaller = true := by decide
def e2422373300858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373300858 : Closed e2422373300858 ∧ code e2422373300858 = 11218466323066 := by decide
theorem cert_e2422373300858 : check e2422373300858 [[],[]] .smaller = true := by decide
def e2422373301022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422373301022 : Closed e2422373301022 ∧ code e2422373301022 = 11218466323230 := by decide
theorem cert_e2422373301022 : check e2422373301022 [[],[]] .smaller = true := by decide
def e2422373301122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373301122 : Closed e2422373301122 ∧ code e2422373301122 = 11218466323330 := by decide
theorem cert_e2422373301122 : check e2422373301122 [[],[]] .smaller = true := by decide
def e2422373301134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 2))))))))
theorem wire_e2422373301134 : Closed e2422373301134 ∧ code e2422373301134 = 11218466323342 := by decide
theorem cert_e2422373301134 : check e2422373301134 [[],[]] .smaller = true := by decide
def e2422373301146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373301146 : Closed e2422373301146 ∧ code e2422373301146 = 11218466323354 := by decide
theorem cert_e2422373301146 : check e2422373301146 [[],[]] .smaller = true := by decide
def e2422373301190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422373301190 : Closed e2422373301190 ∧ code e2422373301190 = 11218466323398 := by decide
theorem cert_e2422373301190 : check e2422373301190 [[],[]] .three = true := by decide
def e2422373301214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 3)))))))
theorem wire_e2422373301214 : Closed e2422373301214 ∧ code e2422373301214 = 11218466323422 := by decide
theorem cert_e2422373301214 : check e2422373301214 [[],[]] .three = true := by decide
def e2422373301270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 1)))))))
theorem wire_e2422373301270 : Closed e2422373301270 ∧ code e2422373301270 = 11218466323478 := by decide
theorem cert_e2422373301270 : check e2422373301270 [[],[]] .smaller = true := by decide
def e2422373301342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e2422373301342 : Closed e2422373301342 ∧ code e2422373301342 = 11218466323550 := by decide
theorem cert_e2422373301342 : check e2422373301342 [[],[]] .three = true := by decide
def e2422373301366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373301366 : Closed e2422373301366 ∧ code e2422373301366 = 11218466323574 := by decide
theorem cert_e2422373301366 : check e2422373301366 [[],[]] .smaller = true := by decide
def e2422373301462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e2422373301462 : Closed e2422373301462 ∧ code e2422373301462 = 11218466323670 := by decide
theorem cert_e2422373301462 : check e2422373301462 [[],[]] .smaller = true := by decide
def e2422373301466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422373301466 : Closed e2422373301466 ∧ code e2422373301466 = 11218466323674 := by decide
theorem cert_e2422373301466 : check e2422373301466 [[],[]] .smaller = true := by decide
def e2422373301482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422373301482 : Closed e2422373301482 ∧ code e2422373301482 = 11218466323690 := by decide
theorem cert_e2422373301482 : check e2422373301482 [[],[]] .smaller = true := by decide
def e2422373301558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373301558 : Closed e2422373301558 ∧ code e2422373301558 = 11218466323766 := by decide
theorem cert_e2422373301558 : check e2422373301558 [[],[]] .smaller = true := by decide
def e2422373301562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373301562 : Closed e2422373301562 ∧ code e2422373301562 = 11218466323770 := by decide
theorem cert_e2422373301562 : check e2422373301562 [[],[]] .smaller = true := by decide
def e2422373301634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373301634 : Closed e2422373301634 ∧ code e2422373301634 = 11218466323842 := by decide
theorem cert_e2422373301634 : check e2422373301634 [[],[]] .smaller = true := by decide
def e2422373301646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373301646 : Closed e2422373301646 ∧ code e2422373301646 = 11218466323854 := by decide
theorem cert_e2422373301646 : check e2422373301646 [[],[]] .smaller = true := by decide
def e2422373301658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373301658 : Closed e2422373301658 ∧ code e2422373301658 = 11218466323866 := by decide
theorem cert_e2422373301658 : check e2422373301658 [[],[]] .smaller = true := by decide
def e2422373301726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 3)))))))
theorem wire_e2422373301726 : Closed e2422373301726 ∧ code e2422373301726 = 11218466323934 := by decide
theorem cert_e2422373301726 : check e2422373301726 [[],[]] .three = true := by decide
def e2422373301730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e2422373301730 : Closed e2422373301730 ∧ code e2422373301730 = 11218466323938 := by decide
theorem cert_e2422373301730 : check e2422373301730 [[],[]] .three = true := by decide
def e2422373301742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))) (.var 2)))))))
theorem wire_e2422373301742 : Closed e2422373301742 ∧ code e2422373301742 = 11218466323950 := by decide
theorem cert_e2422373301742 : check e2422373301742 [[],[]] .three = true := by decide
def e2422373301806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373301806 : Closed e2422373301806 ∧ code e2422373301806 = 11218466324014 := by decide
theorem cert_e2422373301806 : check e2422373301806 [[],[]] .three = true := by decide
def e2422373301814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373301814 : Closed e2422373301814 ∧ code e2422373301814 = 11218466324022 := by decide
theorem cert_e2422373301814 : check e2422373301814 [[],[]] .three = true := by decide
def e2422373301818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373301818 : Closed e2422373301818 ∧ code e2422373301818 = 11218466324026 := by decide
theorem cert_e2422373301818 : check e2422373301818 [[],[]] .three = true := by decide
def e2422373301902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373301902 : Closed e2422373301902 ∧ code e2422373301902 = 11218466324110 := by decide
theorem cert_e2422373301902 : check e2422373301902 [[],[]] .three = true := by decide
def e2422373301958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373301958 : Closed e2422373301958 ∧ code e2422373301958 = 11218466324166 := by decide
theorem cert_e2422373301958 : check e2422373301958 [[],[]] .three = true := by decide
def e2422373301982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 3)))))))
theorem wire_e2422373301982 : Closed e2422373301982 ∧ code e2422373301982 = 11218466324190 := by decide
theorem cert_e2422373301982 : check e2422373301982 [[],[]] .three = true := by decide
def e2422373301986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373301986 : Closed e2422373301986 ∧ code e2422373301986 = 11218466324194 := by decide
theorem cert_e2422373301986 : check e2422373301986 [[],[]] .three = true := by decide
def e2422373301998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))) (.var 2)))))))
theorem wire_e2422373301998 : Closed e2422373301998 ∧ code e2422373301998 = 11218466324206 := by decide
theorem cert_e2422373301998 : check e2422373301998 [[],[]] .three = true := by decide
def e2422373302006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 3)))) (.var 1)))))))
theorem wire_e2422373302006 : Closed e2422373302006 ∧ code e2422373302006 = 11218466324214 := by decide
theorem cert_e2422373302006 : check e2422373302006 [[],[]] .three = true := by decide
def e2422373303262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373303262 : Closed e2422373303262 ∧ code e2422373303262 = 11218466325470 := by decide
theorem cert_e2422373303262 : check e2422373303262 [[],[]] .smaller = true := by decide
def e2422373303278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373303278 : Closed e2422373303278 ∧ code e2422373303278 = 11218466325486 := by decide
theorem cert_e2422373303278 : check e2422373303278 [[],[]] .smaller = true := by decide
def e2422373305198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422373305198 : Closed e2422373305198 ∧ code e2422373305198 = 11218466327406 := by decide
theorem cert_e2422373305198 : check e2422373305198 [[],[]] .smaller = true := by decide
def e2422373305206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422373305206 : Closed e2422373305206 ∧ code e2422373305206 = 11218466327414 := by decide
theorem cert_e2422373305206 : check e2422373305206 [[],[]] .smaller = true := by decide
def e2422373305262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422373305262 : Closed e2422373305262 ∧ code e2422373305262 = 11218466327470 := by decide
theorem cert_e2422373305262 : check e2422373305262 [[],[]] .smaller = true := by decide
def e2422373305274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422373305274 : Closed e2422373305274 ∧ code e2422373305274 = 11218466327482 := by decide
theorem cert_e2422373305274 : check e2422373305274 [[],[]] .smaller = true := by decide
def e2422373305302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422373305302 : Closed e2422373305302 ∧ code e2422373305302 = 11218466327510 := by decide
theorem cert_e2422373305302 : check e2422373305302 [[],[]] .smaller = true := by decide
def e2422373305306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422373305306 : Closed e2422373305306 ∧ code e2422373305306 = 11218466327514 := by decide
theorem cert_e2422373305306 : check e2422373305306 [[],[]] .smaller = true := by decide
def e2422373305582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373305582 : Closed e2422373305582 ∧ code e2422373305582 = 11218466327790 := by decide
theorem cert_e2422373305582 : check e2422373305582 [[],[]] .smaller = true := by decide
def e2422373305590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373305590 : Closed e2422373305590 ∧ code e2422373305590 = 11218466327798 := by decide
theorem cert_e2422373305590 : check e2422373305590 [[],[]] .smaller = true := by decide
def e2422373305918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2422373305918 : Closed e2422373305918 ∧ code e2422373305918 = 11218466328126 := by decide
theorem cert_e2422373305918 : check e2422373305918 [[],[]] .three = true := by decide
def e2422373305966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373305966 : Closed e2422373305966 ∧ code e2422373305966 = 11218466328174 := by decide
theorem cert_e2422373305966 : check e2422373305966 [[],[]] .smaller = true := by decide
def e2422373305978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373305978 : Closed e2422373305978 ∧ code e2422373305978 = 11218466328186 := by decide
theorem cert_e2422373305978 : check e2422373305978 [[],[]] .smaller = true := by decide
def e2422373306166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373306166 : Closed e2422373306166 ∧ code e2422373306166 = 11218466328374 := by decide
theorem cert_e2422373306166 : check e2422373306166 [[],[]] .smaller = true := by decide
def e2422373306170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373306170 : Closed e2422373306170 ∧ code e2422373306170 = 11218466328378 := by decide
theorem cert_e2422373306170 : check e2422373306170 [[],[]] .smaller = true := by decide
def e2422373306254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2422373306254 : Closed e2422373306254 ∧ code e2422373306254 = 11218466328462 := by decide
theorem cert_e2422373306254 : check e2422373306254 [[],[]] .three = true := by decide
def e2422373310910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422373310910 : Closed e2422373310910 ∧ code e2422373310910 = 11218466333118 := by decide
theorem cert_e2422373310910 : check e2422373310910 [[],[]] .three = true := by decide
def e2422373310942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373310942 : Closed e2422373310942 ∧ code e2422373310942 = 11218466333150 := by decide
theorem cert_e2422373310942 : check e2422373310942 [[],[]] .smaller = true := by decide
def e2422373310966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373310966 : Closed e2422373310966 ∧ code e2422373310966 = 11218466333174 := by decide
theorem cert_e2422373310966 : check e2422373310966 [[],[]] .smaller = true := by decide
def e2422373310970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422373310970 : Closed e2422373310970 ∧ code e2422373310970 = 11218466333178 := by decide
theorem cert_e2422373310970 : check e2422373310970 [[],[]] .three = true := by decide
def e2422373311918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422373311918 : Closed e2422373311918 ∧ code e2422373311918 = 11218466334126 := by decide
theorem cert_e2422373311918 : check e2422373311918 [[],[]] .smaller = true := by decide
def e2422373311930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422373311930 : Closed e2422373311930 ∧ code e2422373311930 = 11218466334138 := by decide
theorem cert_e2422373311930 : check e2422373311930 [[],[]] .smaller = true := by decide
def e2422373311978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422373311978 : Closed e2422373311978 ∧ code e2422373311978 = 11218466334186 := by decide
theorem cert_e2422373311978 : check e2422373311978 [[],[]] .smaller = true := by decide
def e2422373312062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422373312062 : Closed e2422373312062 ∧ code e2422373312062 = 11218466334270 := by decide
theorem cert_e2422373312062 : check e2422373312062 [[],[]] .three = true := by decide
def e2422373312110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373312110 : Closed e2422373312110 ∧ code e2422373312110 = 11218466334318 := by decide
theorem cert_e2422373312110 : check e2422373312110 [[],[]] .smaller = true := by decide
def e2422373312122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373312122 : Closed e2422373312122 ∧ code e2422373312122 = 11218466334330 := by decide
theorem cert_e2422373312122 : check e2422373312122 [[],[]] .smaller = true := by decide
def e2422373312286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422373312286 : Closed e2422373312286 ∧ code e2422373312286 = 11218466334494 := by decide
theorem cert_e2422373312286 : check e2422373312286 [[],[]] .smaller = true := by decide
def e2422373312386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373312386 : Closed e2422373312386 ∧ code e2422373312386 = 11218466334594 := by decide
theorem cert_e2422373312386 : check e2422373312386 [[],[]] .smaller = true := by decide
def e2422373312398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422373312398 : Closed e2422373312398 ∧ code e2422373312398 = 11218466334606 := by decide
theorem cert_e2422373312398 : check e2422373312398 [[],[]] .smaller = true := by decide
def e2422373312410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373312410 : Closed e2422373312410 ∧ code e2422373312410 = 11218466334618 := by decide
theorem cert_e2422373312410 : check e2422373312410 [[],[]] .smaller = true := by decide
def e2422373312454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422373312454 : Closed e2422373312454 ∧ code e2422373312454 = 11218466334662 := by decide
theorem cert_e2422373312454 : check e2422373312454 [[],[]] .three = true := by decide
def e2422373312478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 3))))))))
theorem wire_e2422373312478 : Closed e2422373312478 ∧ code e2422373312478 = 11218466334686 := by decide
theorem cert_e2422373312478 : check e2422373312478 [[],[]] .three = true := by decide
def e2422373314686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373314686 : Closed e2422373314686 ∧ code e2422373314686 = 11218466336894 := by decide
theorem cert_e2422373314686 : check e2422373314686 [[],[]] .three = true := by decide
def e2422373314798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373314798 : Closed e2422373314798 ∧ code e2422373314798 = 11218466337006 := by decide
theorem cert_e2422373314798 : check e2422373314798 [[],[]] .smaller = true := by decide
def e2422373314806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373314806 : Closed e2422373314806 ∧ code e2422373314806 = 11218466337014 := by decide
theorem cert_e2422373314806 : check e2422373314806 [[],[]] .smaller = true := by decide
def e2422373315286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373315286 : Closed e2422373315286 ∧ code e2422373315286 = 11218466337494 := by decide
theorem cert_e2422373315286 : check e2422373315286 [[],[]] .smaller = true := by decide
def e2422373315290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373315290 : Closed e2422373315290 ∧ code e2422373315290 = 11218466337498 := by decide
theorem cert_e2422373315290 : check e2422373315290 [[],[]] .smaller = true := by decide
def e2422373315306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373315306 : Closed e2422373315306 ∧ code e2422373315306 = 11218466337514 := by decide
theorem cert_e2422373315306 : check e2422373315306 [[],[]] .smaller = true := by decide
def e2422373315382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373315382 : Closed e2422373315382 ∧ code e2422373315382 = 11218466337590 := by decide
theorem cert_e2422373315382 : check e2422373315382 [[],[]] .smaller = true := by decide
def e2422373315386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373315386 : Closed e2422373315386 ∧ code e2422373315386 = 11218466337594 := by decide
theorem cert_e2422373315386 : check e2422373315386 [[],[]] .smaller = true := by decide
def e2422373315458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373315458 : Closed e2422373315458 ∧ code e2422373315458 = 11218466337666 := by decide
theorem cert_e2422373315458 : check e2422373315458 [[],[]] .smaller = true := by decide
def e2422373315470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422373315470 : Closed e2422373315470 ∧ code e2422373315470 = 11218466337678 := by decide
theorem cert_e2422373315470 : check e2422373315470 [[],[]] .smaller = true := by decide
def e2422373315482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373315482 : Closed e2422373315482 ∧ code e2422373315482 = 11218466337690 := by decide
theorem cert_e2422373315482 : check e2422373315482 [[],[]] .smaller = true := by decide
def e2422373315550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373315550 : Closed e2422373315550 ∧ code e2422373315550 = 11218466337758 := by decide
theorem cert_e2422373315550 : check e2422373315550 [[],[]] .three = true := by decide
def e2422373315554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373315554 : Closed e2422373315554 ∧ code e2422373315554 = 11218466337762 := by decide
theorem cert_e2422373315554 : check e2422373315554 [[],[]] .three = true := by decide
def e2422373315566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373315566 : Closed e2422373315566 ∧ code e2422373315566 = 11218466337774 := by decide
theorem cert_e2422373315566 : check e2422373315566 [[],[]] .three = true := by decide
def e2422373316670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373316670 : Closed e2422373316670 ∧ code e2422373316670 = 11218466338878 := by decide
theorem cert_e2422373316670 : check e2422373316670 [[],[]] .three = true := by decide
def e2422373316718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373316718 : Closed e2422373316718 ∧ code e2422373316718 = 11218466338926 := by decide
theorem cert_e2422373316718 : check e2422373316718 [[],[]] .three = true := by decide
def e2422373316730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373316730 : Closed e2422373316730 ∧ code e2422373316730 = 11218466338938 := by decide
theorem cert_e2422373316730 : check e2422373316730 [[],[]] .three = true := by decide
def e2422373317006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373317006 : Closed e2422373317006 ∧ code e2422373317006 = 11218466339214 := by decide
theorem cert_e2422373317006 : check e2422373317006 [[],[]] .three = true := by decide
def e2422373317062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373317062 : Closed e2422373317062 ∧ code e2422373317062 = 11218466339270 := by decide
theorem cert_e2422373317062 : check e2422373317062 [[],[]] .three = true := by decide
def e2422373317086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373317086 : Closed e2422373317086 ∧ code e2422373317086 = 11218466339294 := by decide
theorem cert_e2422373317086 : check e2422373317086 [[],[]] .three = true := by decide
def e2422373317090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373317090 : Closed e2422373317090 ∧ code e2422373317090 = 11218466339298 := by decide
theorem cert_e2422373317090 : check e2422373317090 [[],[]] .three = true := by decide
def e2422373317102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373317102 : Closed e2422373317102 ∧ code e2422373317102 = 11218466339310 := by decide
theorem cert_e2422373317102 : check e2422373317102 [[],[]] .three = true := by decide
def e2422373317110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373317110 : Closed e2422373317110 ∧ code e2422373317110 = 11218466339318 := by decide
theorem cert_e2422373317110 : check e2422373317110 [[],[]] .three = true := by decide
def e2422373319086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2)))))))
theorem wire_e2422373319086 : Closed e2422373319086 ∧ code e2422373319086 = 11218466341294 := by decide
theorem cert_e2422373319086 : check e2422373319086 [[],[]] .smaller = true := by decide
def e2422373319278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373319278 : Closed e2422373319278 ∧ code e2422373319278 = 11218466341486 := by decide
theorem cert_e2422373319278 : check e2422373319278 [[],[]] .smaller = true := by decide
def e2422373319290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373319290 : Closed e2422373319290 ∧ code e2422373319290 = 11218466341498 := by decide
theorem cert_e2422373319290 : check e2422373319290 [[],[]] .smaller = true := by decide
def e2422373319646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 3)))))))
theorem wire_e2422373319646 : Closed e2422373319646 ∧ code e2422373319646 = 11218466341854 := by decide
theorem cert_e2422373319646 : check e2422373319646 [[],[]] .three = true := by decide
def e2422373319662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 2)))))))
theorem wire_e2422373319662 : Closed e2422373319662 ∧ code e2422373319662 = 11218466341870 := by decide
theorem cert_e2422373319662 : check e2422373319662 [[],[]] .smaller = true := by decide
def e2422373319670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 5))))) (.var 1)))))))
theorem wire_e2422373319670 : Closed e2422373319670 ∧ code e2422373319670 = 11218466341878 := by decide
theorem cert_e2422373319670 : check e2422373319670 [[],[]] .three = true := by decide
def e2422373320414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 3)))))))
theorem wire_e2422373320414 : Closed e2422373320414 ∧ code e2422373320414 = 11218466342622 := by decide
theorem cert_e2422373320414 : check e2422373320414 [[],[]] .three = true := by decide
def e2422373320430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 2))))) (.var 2)))))))
theorem wire_e2422373320430 : Closed e2422373320430 ∧ code e2422373320430 = 11218466342638 := by decide
theorem cert_e2422373320430 : check e2422373320430 [[],[]] .smaller = true := by decide
def e2422373320438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 1)))))))
theorem wire_e2422373320438 : Closed e2422373320438 ∧ code e2422373320438 = 11218466342646 := by decide
theorem cert_e2422373320438 : check e2422373320438 [[],[]] .smaller = true := by decide
def e2422373320442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 4))))) (.var 0)))))))
theorem wire_e2422373320442 : Closed e2422373320442 ∧ code e2422373320442 = 11218466342650 := by decide
theorem cert_e2422373320442 : check e2422373320442 [[],[]] .three = true := by decide
def e2422373320542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 3)))))))
theorem wire_e2422373320542 : Closed e2422373320542 ∧ code e2422373320542 = 11218466342750 := by decide
theorem cert_e2422373320542 : check e2422373320542 [[],[]] .three = true := by decide
def e2422373320558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))) (.var 2)))))))
theorem wire_e2422373320558 : Closed e2422373320558 ∧ code e2422373320558 = 11218466342766 := by decide
theorem cert_e2422373320558 : check e2422373320558 [[],[]] .smaller = true := by decide
def e2422373320570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))) (.var 0)))))))
theorem wire_e2422373320570 : Closed e2422373320570 ∧ code e2422373320570 = 11218466342778 := by decide
theorem cert_e2422373320570 : check e2422373320570 [[],[]] .smaller = true := by decide
def e2422373320622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 2) (.var 0))))) (.var 2)))))))
theorem wire_e2422373320622 : Closed e2422373320622 ∧ code e2422373320622 = 11218466342830 := by decide
theorem cert_e2422373320622 : check e2422373320622 [[],[]] .smaller = true := by decide
def e2422373320662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 1)))))))
theorem wire_e2422373320662 : Closed e2422373320662 ∧ code e2422373320662 = 11218466342870 := by decide
theorem cert_e2422373320662 : check e2422373320662 [[],[]] .smaller = true := by decide
def e2422373320666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))) (.var 0)))))))
theorem wire_e2422373320666 : Closed e2422373320666 ∧ code e2422373320666 = 11218466342874 := by decide
theorem cert_e2422373320666 : check e2422373320666 [[],[]] .smaller = true := by decide
def e2422373320682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 4) (.var 0))))) (.var 0)))))))
theorem wire_e2422373320682 : Closed e2422373320682 ∧ code e2422373320682 = 11218466342890 := by decide
theorem cert_e2422373320682 : check e2422373320682 [[],[]] .three = true := by decide
def e2422373321182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373321182 : Closed e2422373321182 ∧ code e2422373321182 = 11218466343390 := by decide
theorem cert_e2422373321182 : check e2422373321182 [[],[]] .three = true := by decide
def e2422373321198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373321198 : Closed e2422373321198 ∧ code e2422373321198 = 11218466343406 := by decide
theorem cert_e2422373321198 : check e2422373321198 [[],[]] .smaller = true := by decide
def e2422373321206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373321206 : Closed e2422373321206 ∧ code e2422373321206 = 11218466343414 := by decide
theorem cert_e2422373321206 : check e2422373321206 [[],[]] .three = true := by decide
def e2422373321950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373321950 : Closed e2422373321950 ∧ code e2422373321950 = 11218466344158 := by decide
theorem cert_e2422373321950 : check e2422373321950 [[],[]] .three = true := by decide
def e2422373321966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373321966 : Closed e2422373321966 ∧ code e2422373321966 = 11218466344174 := by decide
theorem cert_e2422373321966 : check e2422373321966 [[],[]] .smaller = true := by decide
def e2422373321974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373321974 : Closed e2422373321974 ∧ code e2422373321974 = 11218466344182 := by decide
theorem cert_e2422373321974 : check e2422373321974 [[],[]] .smaller = true := by decide
def e2422373321978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373321978 : Closed e2422373321978 ∧ code e2422373321978 = 11218466344186 := by decide
theorem cert_e2422373321978 : check e2422373321978 [[],[]] .three = true := by decide
def e2422373322302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 4))))))))
theorem wire_e2422373322302 : Closed e2422373322302 ∧ code e2422373322302 = 11218466344510 := by decide
theorem cert_e2422373322302 : check e2422373322302 [[],[]] .three = true := by decide
def e2422373322350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373322350 : Closed e2422373322350 ∧ code e2422373322350 = 11218466344558 := by decide
theorem cert_e2422373322350 : check e2422373322350 [[],[]] .smaller = true := by decide
def e2422373322362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373322362 : Closed e2422373322362 ∧ code e2422373322362 = 11218466344570 := by decide
theorem cert_e2422373322362 : check e2422373322362 [[],[]] .smaller = true := by decide
def e2422373322526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 3))))))))
theorem wire_e2422373322526 : Closed e2422373322526 ∧ code e2422373322526 = 11218466344734 := by decide
theorem cert_e2422373322526 : check e2422373322526 [[],[]] .smaller = true := by decide
def e2422373322550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373322550 : Closed e2422373322550 ∧ code e2422373322550 = 11218466344758 := by decide
theorem cert_e2422373322550 : check e2422373322550 [[],[]] .smaller = true := by decide
def e2422373322554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373322554 : Closed e2422373322554 ∧ code e2422373322554 = 11218466344762 := by decide
theorem cert_e2422373322554 : check e2422373322554 [[],[]] .smaller = true := by decide
def e2422373322638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.lam (.var 2))))))))
theorem wire_e2422373322638 : Closed e2422373322638 ∧ code e2422373322638 = 11218466344846 := by decide
theorem cert_e2422373322638 : check e2422373322638 [[],[]] .three = true := by decide
def e2422373322650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373322650 : Closed e2422373322650 ∧ code e2422373322650 = 11218466344858 := by decide
theorem cert_e2422373322650 : check e2422373322650 [[],[]] .three = true := by decide
def e2422373324462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2)))))))
theorem wire_e2422373324462 : Closed e2422373324462 ∧ code e2422373324462 = 11218466346670 := by decide
theorem cert_e2422373324462 : check e2422373324462 [[],[]] .smaller = true := by decide
def e2422373324474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373324474 : Closed e2422373324474 ∧ code e2422373324474 = 11218466346682 := by decide
theorem cert_e2422373324474 : check e2422373324474 [[],[]] .smaller = true := by decide
def e2422373324522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373324522 : Closed e2422373324522 ∧ code e2422373324522 = 11218466346730 := by decide
theorem cert_e2422373324522 : check e2422373324522 [[],[]] .smaller = true := by decide
def e2422373324714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373324714 : Closed e2422373324714 ∧ code e2422373324714 = 11218466346922 := by decide
theorem cert_e2422373324714 : check e2422373324714 [[],[]] .smaller = true := by decide
def e2422373324846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 2)))))))
theorem wire_e2422373324846 : Closed e2422373324846 ∧ code e2422373324846 = 11218466347054 := by decide
theorem cert_e2422373324846 : check e2422373324846 [[],[]] .smaller = true := by decide
def e2422373325022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 3)))))))
theorem wire_e2422373325022 : Closed e2422373325022 ∧ code e2422373325022 = 11218466347230 := by decide
theorem cert_e2422373325022 : check e2422373325022 [[],[]] .three = true := by decide
def e2422373325038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422373325038 : Closed e2422373325038 ∧ code e2422373325038 = 11218466347246 := by decide
theorem cert_e2422373325038 : check e2422373325038 [[],[]] .smaller = true := by decide
def e2422373325046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 1)))))))
theorem wire_e2422373325046 : Closed e2422373325046 ∧ code e2422373325046 = 11218466347254 := by decide
theorem cert_e2422373325046 : check e2422373325046 [[],[]] .smaller = true := by decide
def e2422373325050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422373325050 : Closed e2422373325050 ∧ code e2422373325050 = 11218466347258 := by decide
theorem cert_e2422373325050 : check e2422373325050 [[],[]] .three = true := by decide
def e2422373325230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e2422373325230 : Closed e2422373325230 ∧ code e2422373325230 = 11218466347438 := by decide
theorem cert_e2422373325230 : check e2422373325230 [[],[]] .smaller = true := by decide
def e2422373325242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373325242 : Closed e2422373325242 ∧ code e2422373325242 = 11218466347450 := by decide
theorem cert_e2422373325242 : check e2422373325242 [[],[]] .smaller = true := by decide
def e2422373325290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373325290 : Closed e2422373325290 ∧ code e2422373325290 = 11218466347498 := by decide
theorem cert_e2422373325290 : check e2422373325290 [[],[]] .smaller = true := by decide
def e2422373325374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 4))))))))
theorem wire_e2422373325374 : Closed e2422373325374 ∧ code e2422373325374 = 11218466347582 := by decide
theorem cert_e2422373325374 : check e2422373325374 [[],[]] .three = true := by decide
def e2422373325422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373325422 : Closed e2422373325422 ∧ code e2422373325422 = 11218466347630 := by decide
theorem cert_e2422373325422 : check e2422373325422 [[],[]] .smaller = true := by decide
def e2422373325434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373325434 : Closed e2422373325434 ∧ code e2422373325434 = 11218466347642 := by decide
theorem cert_e2422373325434 : check e2422373325434 [[],[]] .smaller = true := by decide
def e2422373325598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422373325598 : Closed e2422373325598 ∧ code e2422373325598 = 11218466347806 := by decide
theorem cert_e2422373325598 : check e2422373325598 [[],[]] .smaller = true := by decide
def e2422373325698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373325698 : Closed e2422373325698 ∧ code e2422373325698 = 11218466347906 := by decide
theorem cert_e2422373325698 : check e2422373325698 [[],[]] .smaller = true := by decide
def e2422373325710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 2))))))))
theorem wire_e2422373325710 : Closed e2422373325710 ∧ code e2422373325710 = 11218466347918 := by decide
theorem cert_e2422373325710 : check e2422373325710 [[],[]] .smaller = true := by decide
def e2422373325722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373325722 : Closed e2422373325722 ∧ code e2422373325722 = 11218466347930 := by decide
theorem cert_e2422373325722 : check e2422373325722 [[],[]] .smaller = true := by decide
def e2422373325766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422373325766 : Closed e2422373325766 ∧ code e2422373325766 = 11218466347974 := by decide
theorem cert_e2422373325766 : check e2422373325766 [[],[]] .three = true := by decide
def e2422373325790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 3)))))))
theorem wire_e2422373325790 : Closed e2422373325790 ∧ code e2422373325790 = 11218466347998 := by decide
theorem cert_e2422373325790 : check e2422373325790 [[],[]] .three = true := by decide
def e2422373325918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e2422373325918 : Closed e2422373325918 ∧ code e2422373325918 = 11218466348126 := by decide
theorem cert_e2422373325918 : check e2422373325918 [[],[]] .three = true := by decide
def e2422373325934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e2422373325934 : Closed e2422373325934 ∧ code e2422373325934 = 11218466348142 := by decide
theorem cert_e2422373325934 : check e2422373325934 [[],[]] .smaller = true := by decide
def e2422373325946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373325946 : Closed e2422373325946 ∧ code e2422373325946 = 11218466348154 := by decide
theorem cert_e2422373325946 : check e2422373325946 [[],[]] .smaller = true := by decide
def e2422373326110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e2422373326110 : Closed e2422373326110 ∧ code e2422373326110 = 11218466348318 := by decide
theorem cert_e2422373326110 : check e2422373326110 [[],[]] .smaller = true := by decide
def e2422373326278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373326278 : Closed e2422373326278 ∧ code e2422373326278 = 11218466348486 := by decide
theorem cert_e2422373326278 : check e2422373326278 [[],[]] .smaller = true := by decide
def e2422373326302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 3)))))))
theorem wire_e2422373326302 : Closed e2422373326302 ∧ code e2422373326302 = 11218466348510 := by decide
theorem cert_e2422373326302 : check e2422373326302 [[],[]] .three = true := by decide
def e2422373326306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e2422373326306 : Closed e2422373326306 ∧ code e2422373326306 = 11218466348514 := by decide
theorem cert_e2422373326306 : check e2422373326306 [[],[]] .three = true := by decide
def e2422373326318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 2)))))))
theorem wire_e2422373326318 : Closed e2422373326318 ∧ code e2422373326318 = 11218466348526 := by decide
theorem cert_e2422373326318 : check e2422373326318 [[],[]] .three = true := by decide
def e2422373326346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))) (.var 0)))))))
theorem wire_e2422373326346 : Closed e2422373326346 ∧ code e2422373326346 = 11218466348554 := by decide
theorem cert_e2422373326346 : check e2422373326346 [[],[]] .smaller = true := by decide
end Blc.Floor43
