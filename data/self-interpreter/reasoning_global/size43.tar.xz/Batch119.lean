import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2210795020650 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210795020650 : Closed e2210795020650 ∧ code e2210795020650 = 11006888042858 := by decide
theorem cert_e2210795020650 : check e2210795020650 [[]] .width = true := by decide
def e2210795020698 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210795020698 : Closed e2210795020698 ∧ code e2210795020698 = 11006888042906 := by decide
theorem cert_e2210795020698 : check e2210795020698 [[]] .width = true := by decide
def e2210795069466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210795069466 : Closed e2210795069466 ∧ code e2210795069466 = 11006888091674 := by decide
theorem cert_e2210795069466 : check e2210795069466 [[]] .width = true := by decide
def e2210795069558 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210795069558 : Closed e2210795069558 ∧ code e2210795069558 = 11006888091766 := by decide
theorem cert_e2210795069558 : check e2210795069558 [[]] .width = true := by decide
def e2210795069802 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210795069802 : Closed e2210795069802 ∧ code e2210795069802 = 11006888092010 := by decide
theorem cert_e2210795069802 : check e2210795069802 [[]] .width = true := by decide
def e2210795069850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210795069850 : Closed e2210795069850 ∧ code e2210795069850 = 11006888092058 := by decide
theorem cert_e2210795069850 : check e2210795069850 [[]] .width = true := by decide
def e2210795075610 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210795075610 : Closed e2210795075610 ∧ code e2210795075610 = 11006888097818 := by decide
theorem cert_e2210795075610 : check e2210795075610 [[]] .width = true := by decide
def e2210795487258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2210795487258 : Closed e2210795487258 ∧ code e2210795487258 = 11006888509466 := by decide
theorem cert_e2210795487258 : check e2210795487258 [[]] .width = true := by decide
def e2210795487350 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2210795487350 : Closed e2210795487350 ∧ code e2210795487350 = 11006888509558 := by decide
theorem cert_e2210795487350 : check e2210795487350 [[]] .width = true := by decide
def e2210795487594 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2210795487594 : Closed e2210795487594 ∧ code e2210795487594 = 11006888509802 := by decide
theorem cert_e2210795487594 : check e2210795487594 [[]] .width = true := by decide
def e2210795487642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2210795487642 : Closed e2210795487642 ∧ code e2210795487642 = 11006888509850 := by decide
theorem cert_e2210795487642 : check e2210795487642 [[]] .width = true := by decide
def e2210795487726 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2210795487726 : Closed e2210795487726 ∧ code e2210795487726 = 11006888509934 := by decide
theorem cert_e2210795487726 : check e2210795487726 [[]] .width = true := by decide
def e2210795488650 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2210795488650 : Closed e2210795488650 ∧ code e2210795488650 = 11006888510858 := by decide
theorem cert_e2210795488650 : check e2210795488650 [[]] .width = true := by decide
def e2210795488674 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2210795488674 : Closed e2210795488674 ∧ code e2210795488674 = 11006888510882 := by decide
theorem cert_e2210795488674 : check e2210795488674 [[]] .width = true := by decide
def e2210795488694 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2210795488694 : Closed e2210795488694 ∧ code e2210795488694 = 11006888510902 := by decide
theorem cert_e2210795488694 : check e2210795488694 [[]] .width = true := by decide
def e2210795488726 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2210795488726 : Closed e2210795488726 ∧ code e2210795488726 = 11006888510934 := by decide
theorem cert_e2210795488726 : check e2210795488726 [[]] .width = true := by decide
def e2210795488730 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2210795488730 : Closed e2210795488730 ∧ code e2210795488730 = 11006888510938 := by decide
theorem cert_e2210795488730 : check e2210795488730 [[]] .width = true := by decide
def e2210795488782 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2210795488782 : Closed e2210795488782 ∧ code e2210795488782 = 11006888510990 := by decide
theorem cert_e2210795488782 : check e2210795488782 [[]] .width = true := by decide
def e2210795488794 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210795488794 : Closed e2210795488794 ∧ code e2210795488794 = 11006888511002 := by decide
theorem cert_e2210795488794 : check e2210795488794 [[]] .width = true := by decide
def e2210795488866 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2210795488866 : Closed e2210795488866 ∧ code e2210795488866 = 11006888511074 := by decide
theorem cert_e2210795488866 : check e2210795488866 [[]] .width = true := by decide
def e2210795488886 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2210795488886 : Closed e2210795488886 ∧ code e2210795488886 = 11006888511094 := by decide
theorem cert_e2210795488886 : check e2210795488886 [[]] .width = true := by decide
def e2210795489078 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2210795489078 : Closed e2210795489078 ∧ code e2210795489078 = 11006888511286 := by decide
theorem cert_e2210795489078 : check e2210795489078 [[]] .width = true := by decide
def e2210795489082 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2210795489082 : Closed e2210795489082 ∧ code e2210795489082 = 11006888511290 := by decide
theorem cert_e2210795489082 : check e2210795489082 [[]] .width = true := by decide
def e2210795492778 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2210795492778 : Closed e2210795492778 ∧ code e2210795492778 = 11006888514986 := by decide
theorem cert_e2210795492778 : check e2210795492778 [[]] .width = true := by decide
def e2210795492874 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2210795492874 : Closed e2210795492874 ∧ code e2210795492874 = 11006888515082 := by decide
theorem cert_e2210795492874 : check e2210795492874 [[]] .width = true := by decide
def e2210795492970 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2210795492970 : Closed e2210795492970 ∧ code e2210795492970 = 11006888515178 := by decide
theorem cert_e2210795492970 : check e2210795492970 [[]] .width = true := by decide
def e2210795492994 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2210795492994 : Closed e2210795492994 ∧ code e2210795492994 = 11006888515202 := by decide
theorem cert_e2210795492994 : check e2210795492994 [[]] .width = true := by decide
def e2210795493018 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2210795493018 : Closed e2210795493018 ∧ code e2210795493018 = 11006888515226 := by decide
theorem cert_e2210795493018 : check e2210795493018 [[]] .width = true := by decide
def e2210795493402 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210795493402 : Closed e2210795493402 ∧ code e2210795493402 = 11006888515610 := by decide
theorem cert_e2210795493402 : check e2210795493402 [[]] .width = true := by decide
def e2210795493494 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2210795493494 : Closed e2210795493494 ∧ code e2210795493494 = 11006888515702 := by decide
theorem cert_e2210795493494 : check e2210795493494 [[]] .width = true := by decide
def e2210795493738 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2210795493738 : Closed e2210795493738 ∧ code e2210795493738 = 11006888515946 := by decide
theorem cert_e2210795493738 : check e2210795493738 [[]] .width = true := by decide
def e2210795493762 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2210795493762 : Closed e2210795493762 ∧ code e2210795493762 = 11006888515970 := by decide
theorem cert_e2210795493762 : check e2210795493762 [[]] .width = true := by decide
def e2210795493786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2210795493786 : Closed e2210795493786 ∧ code e2210795493786 = 11006888515994 := by decide
theorem cert_e2210795493786 : check e2210795493786 [[]] .width = true := by decide
def e2210796191942 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210796191942 : Closed e2210796191942 ∧ code e2210796191942 = 11006889214150 := by decide
theorem cert_e2210796191942 : check e2210796191942 [[]] .width = true := by decide
def e2210796249114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210796249114 : Closed e2210796249114 ∧ code e2210796249114 = 11006889271322 := by decide
theorem cert_e2210796249114 : check e2210796249114 [[]] .width = true := by decide
def e2210796249206 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210796249206 : Closed e2210796249206 ∧ code e2210796249206 = 11006889271414 := by decide
theorem cert_e2210796249206 : check e2210796249206 [[]] .width = true := by decide
def e2210796249450 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210796249450 : Closed e2210796249450 ∧ code e2210796249450 = 11006889271658 := by decide
theorem cert_e2210796249450 : check e2210796249450 [[]] .width = true := by decide
def e2210796249498 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210796249498 : Closed e2210796249498 ∧ code e2210796249498 = 11006889271706 := by decide
theorem cert_e2210796249498 : check e2210796249498 [[]] .width = true := by decide
def e2210796255258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210796255258 : Closed e2210796255258 ∧ code e2210796255258 = 11006889277466 := by decide
theorem cert_e2210796255258 : check e2210796255258 [[]] .width = true := by decide
def e2210796267546 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210796267546 : Closed e2210796267546 ∧ code e2210796267546 = 11006889289754 := by decide
theorem cert_e2210796267546 : check e2210796267546 [[]] .width = true := by decide
def e2210796273690 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2210796273690 : Closed e2210796273690 ∧ code e2210796273690 = 11006889295898 := by decide
theorem cert_e2210796273690 : check e2210796273690 [[]] .width = true := by decide
def e2210796273782 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2210796273782 : Closed e2210796273782 ∧ code e2210796273782 = 11006889295990 := by decide
theorem cert_e2210796273782 : check e2210796273782 [[]] .width = true := by decide
def e2210796274026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2210796274026 : Closed e2210796274026 ∧ code e2210796274026 = 11006889296234 := by decide
theorem cert_e2210796274026 : check e2210796274026 [[]] .width = true := by decide
def e2210796274074 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2210796274074 : Closed e2210796274074 ∧ code e2210796274074 = 11006889296282 := by decide
theorem cert_e2210796274074 : check e2210796274074 [[]] .width = true := by decide
def e2210796274158 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2210796274158 : Closed e2210796274158 ∧ code e2210796274158 = 11006889296366 := by decide
theorem cert_e2210796274158 : check e2210796274158 [[]] .width = true := by decide
def e2210796275082 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2210796275082 : Closed e2210796275082 ∧ code e2210796275082 = 11006889297290 := by decide
theorem cert_e2210796275082 : check e2210796275082 [[]] .width = true := by decide
def e2210796275106 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2210796275106 : Closed e2210796275106 ∧ code e2210796275106 = 11006889297314 := by decide
theorem cert_e2210796275106 : check e2210796275106 [[]] .width = true := by decide
def e2210796275126 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2210796275126 : Closed e2210796275126 ∧ code e2210796275126 = 11006889297334 := by decide
theorem cert_e2210796275126 : check e2210796275126 [[]] .width = true := by decide
def e2210796275158 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2210796275158 : Closed e2210796275158 ∧ code e2210796275158 = 11006889297366 := by decide
theorem cert_e2210796275158 : check e2210796275158 [[]] .width = true := by decide
def e2210796275162 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2210796275162 : Closed e2210796275162 ∧ code e2210796275162 = 11006889297370 := by decide
theorem cert_e2210796275162 : check e2210796275162 [[]] .width = true := by decide
def e2210796275214 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2210796275214 : Closed e2210796275214 ∧ code e2210796275214 = 11006889297422 := by decide
theorem cert_e2210796275214 : check e2210796275214 [[]] .width = true := by decide
def e2210796275226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210796275226 : Closed e2210796275226 ∧ code e2210796275226 = 11006889297434 := by decide
theorem cert_e2210796275226 : check e2210796275226 [[]] .width = true := by decide
def e2210796275298 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2210796275298 : Closed e2210796275298 ∧ code e2210796275298 = 11006889297506 := by decide
theorem cert_e2210796275298 : check e2210796275298 [[]] .width = true := by decide
def e2210796275318 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2210796275318 : Closed e2210796275318 ∧ code e2210796275318 = 11006889297526 := by decide
theorem cert_e2210796275318 : check e2210796275318 [[]] .width = true := by decide
def e2210796275510 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2210796275510 : Closed e2210796275510 ∧ code e2210796275510 = 11006889297718 := by decide
theorem cert_e2210796275510 : check e2210796275510 [[]] .width = true := by decide
def e2210796275514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2210796275514 : Closed e2210796275514 ∧ code e2210796275514 = 11006889297722 := by decide
theorem cert_e2210796275514 : check e2210796275514 [[]] .width = true := by decide
def e2210796279210 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2210796279210 : Closed e2210796279210 ∧ code e2210796279210 = 11006889301418 := by decide
theorem cert_e2210796279210 : check e2210796279210 [[]] .width = true := by decide
def e2210796279306 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2210796279306 : Closed e2210796279306 ∧ code e2210796279306 = 11006889301514 := by decide
theorem cert_e2210796279306 : check e2210796279306 [[]] .width = true := by decide
def e2210796279402 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2210796279402 : Closed e2210796279402 ∧ code e2210796279402 = 11006889301610 := by decide
theorem cert_e2210796279402 : check e2210796279402 [[]] .width = true := by decide
def e2210796279426 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2210796279426 : Closed e2210796279426 ∧ code e2210796279426 = 11006889301634 := by decide
theorem cert_e2210796279426 : check e2210796279426 [[]] .width = true := by decide
def e2210796279450 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2210796279450 : Closed e2210796279450 ∧ code e2210796279450 = 11006889301658 := by decide
theorem cert_e2210796279450 : check e2210796279450 [[]] .width = true := by decide
def e2210796279834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210796279834 : Closed e2210796279834 ∧ code e2210796279834 = 11006889302042 := by decide
theorem cert_e2210796279834 : check e2210796279834 [[]] .width = true := by decide
def e2210796279926 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2210796279926 : Closed e2210796279926 ∧ code e2210796279926 = 11006889302134 := by decide
theorem cert_e2210796279926 : check e2210796279926 [[]] .width = true := by decide
def e2210796280170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2210796280170 : Closed e2210796280170 ∧ code e2210796280170 = 11006889302378 := by decide
theorem cert_e2210796280170 : check e2210796280170 [[]] .width = true := by decide
def e2210796280194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2210796280194 : Closed e2210796280194 ∧ code e2210796280194 = 11006889302402 := by decide
theorem cert_e2210796280194 : check e2210796280194 [[]] .width = true := by decide
def e2210796280218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2210796280218 : Closed e2210796280218 ∧ code e2210796280218 = 11006889302426 := by decide
theorem cert_e2210796280218 : check e2210796280218 [[]] .width = true := by decide
def e2210797109446 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210797109446 : Closed e2210797109446 ∧ code e2210797109446 = 11006890131654 := by decide
theorem cert_e2210797109446 : check e2210797109446 [[]] .width = true := by decide
def e2210797142214 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210797142214 : Closed e2210797142214 ∧ code e2210797142214 = 11006890164422 := by decide
theorem cert_e2210797142214 : check e2210797142214 [[]] .width = true := by decide
def e2210797543450 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210797543450 : Closed e2210797543450 ∧ code e2210797543450 = 11006890565658 := by decide
theorem cert_e2210797543450 : check e2210797543450 [[]] .width = true := by decide
def e2210797543542 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210797543542 : Closed e2210797543542 ∧ code e2210797543542 = 11006890565750 := by decide
private def t_e2210797543542 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210797543542 : ¬ IsSelfInterpreter e2210797543542 :=
  wSource (t := t_e2210797543542) (replay_sound (ps := []) (t := e2210797543542) (by decide)) (by decide)
def e2210797543786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210797543786 : Closed e2210797543786 ∧ code e2210797543786 = 11006890565994 := by decide
private def t_e2210797543786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210797543786 : ¬ IsSelfInterpreter e2210797543786 :=
  wSource (t := t_e2210797543786) (replay_sound (ps := []) (t := e2210797543786) (by decide)) (by decide)
def e2210797543834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210797543834 : Closed e2210797543834 ∧ code e2210797543834 = 11006890566042 := by decide
private def t_e2210797543834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210797543834 : ¬ IsSelfInterpreter e2210797543834 :=
  wSource (t := t_e2210797543834) (replay_sound (ps := []) (t := e2210797543834) (by decide)) (by decide)
def e2210797559834 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210797559834 : Closed e2210797559834 ∧ code e2210797559834 = 11006890582042 := by decide
theorem cert_e2210797559834 : check e2210797559834 [[]] .width = true := by decide
def e2210797559926 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210797559926 : Closed e2210797559926 ∧ code e2210797559926 = 11006890582134 := by decide
private def t_e2210797559926 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210797559926 : ¬ IsSelfInterpreter e2210797559926 :=
  wSource (t := t_e2210797559926) (replay_sound (ps := []) (t := e2210797559926) (by decide)) (by decide)
def e2210797560170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210797560170 : Closed e2210797560170 ∧ code e2210797560170 = 11006890582378 := by decide
private def t_e2210797560170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210797560170 : ¬ IsSelfInterpreter e2210797560170 :=
  wSource (t := t_e2210797560170) (replay_sound (ps := []) (t := e2210797560170) (by decide)) (by decide)
def e2210797560218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210797560218 : Closed e2210797560218 ∧ code e2210797560218 = 11006890582426 := by decide
private def t_e2210797560218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210797560218 : ¬ IsSelfInterpreter e2210797560218 :=
  wSource (t := t_e2210797560218) (replay_sound (ps := []) (t := e2210797560218) (by decide)) (by decide)
def e2210797565978 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797565978 : Closed e2210797565978 ∧ code e2210797565978 = 11006890588186 := by decide
theorem cert_e2210797565978 : check e2210797565978 [[]] .width = true := by decide
def e2210797574170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797574170 : Closed e2210797574170 ∧ code e2210797574170 = 11006890596378 := by decide
theorem cert_e2210797574170 : check e2210797574170 [[]] .width = true := by decide
def e2210797625370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210797625370 : Closed e2210797625370 ∧ code e2210797625370 = 11006890647578 := by decide
theorem cert_e2210797625370 : check e2210797625370 [[]] .width = true := by decide
def e2210797625462 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210797625462 : Closed e2210797625462 ∧ code e2210797625462 = 11006890647670 := by decide
private def t_e2210797625462 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210797625462 : ¬ IsSelfInterpreter e2210797625462 :=
  wSource (t := t_e2210797625462) (replay_sound (ps := []) (t := e2210797625462) (by decide)) (by decide)
def e2210797625706 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210797625706 : Closed e2210797625706 ∧ code e2210797625706 = 11006890647914 := by decide
private def t_e2210797625706 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210797625706 : ¬ IsSelfInterpreter e2210797625706 :=
  wSource (t := t_e2210797625706) (replay_sound (ps := []) (t := e2210797625706) (by decide)) (by decide)
def e2210797625754 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210797625754 : Closed e2210797625754 ∧ code e2210797625754 = 11006890647962 := by decide
private def t_e2210797625754 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210797625754 : ¬ IsSelfInterpreter e2210797625754 :=
  wSource (t := t_e2210797625754) (replay_sound (ps := []) (t := e2210797625754) (by decide)) (by decide)
def e2210797631514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797631514 : Closed e2210797631514 ∧ code e2210797631514 = 11006890653722 := by decide
theorem cert_e2210797631514 : check e2210797631514 [[]] .width = true := by decide
def e2210797643802 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797643802 : Closed e2210797643802 ∧ code e2210797643802 = 11006890666010 := by decide
theorem cert_e2210797643802 : check e2210797643802 [[]] .width = true := by decide
def e2210797672474 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797672474 : Closed e2210797672474 ∧ code e2210797672474 = 11006890694682 := by decide
theorem cert_e2210797672474 : check e2210797672474 [[]] .width = true := by decide
def e2210797676570 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797676570 : Closed e2210797676570 ∧ code e2210797676570 = 11006890698778 := by decide
theorem cert_e2210797676570 : check e2210797676570 [[]] .width = true := by decide
def e2210797830342 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210797830342 : Closed e2210797830342 ∧ code e2210797830342 = 11006890852550 := by decide
theorem cert_e2210797830342 : check e2210797830342 [[]] .width = true := by decide
def e2210797936666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210797936666 : Closed e2210797936666 ∧ code e2210797936666 = 11006890958874 := by decide
theorem cert_e2210797936666 : check e2210797936666 [[]] .width = true := by decide
def e2210797936758 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210797936758 : Closed e2210797936758 ∧ code e2210797936758 = 11006890958966 := by decide
private def t_e2210797936758 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210797936758 : ¬ IsSelfInterpreter e2210797936758 :=
  wSource (t := t_e2210797936758) (replay_sound (ps := []) (t := e2210797936758) (by decide)) (by decide)
def e2210797937002 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210797937002 : Closed e2210797937002 ∧ code e2210797937002 = 11006890959210 := by decide
private def t_e2210797937002 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210797937002 : ¬ IsSelfInterpreter e2210797937002 :=
  wSource (t := t_e2210797937002) (replay_sound (ps := []) (t := e2210797937002) (by decide)) (by decide)
def e2210797937050 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210797937050 : Closed e2210797937050 ∧ code e2210797937050 = 11006890959258 := by decide
private def t_e2210797937050 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210797937050 : ¬ IsSelfInterpreter e2210797937050 :=
  wSource (t := t_e2210797937050) (replay_sound (ps := []) (t := e2210797937050) (by decide)) (by decide)
def e2210797953050 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210797953050 : Closed e2210797953050 ∧ code e2210797953050 = 11006890975258 := by decide
theorem cert_e2210797953050 : check e2210797953050 [[]] .width = true := by decide
def e2210797953142 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210797953142 : Closed e2210797953142 ∧ code e2210797953142 = 11006890975350 := by decide
private def t_e2210797953142 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210797953142 : ¬ IsSelfInterpreter e2210797953142 :=
  wSource (t := t_e2210797953142) (replay_sound (ps := []) (t := e2210797953142) (by decide)) (by decide)
def e2210797953386 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210797953386 : Closed e2210797953386 ∧ code e2210797953386 = 11006890975594 := by decide
private def t_e2210797953386 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210797953386 : ¬ IsSelfInterpreter e2210797953386 :=
  wSource (t := t_e2210797953386) (replay_sound (ps := []) (t := e2210797953386) (by decide)) (by decide)
def e2210797953434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210797953434 : Closed e2210797953434 ∧ code e2210797953434 = 11006890975642 := by decide
private def t_e2210797953434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210797953434 : ¬ IsSelfInterpreter e2210797953434 :=
  wSource (t := t_e2210797953434) (replay_sound (ps := []) (t := e2210797953434) (by decide)) (by decide)
def e2210797959194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797959194 : Closed e2210797959194 ∧ code e2210797959194 = 11006890981402 := by decide
theorem cert_e2210797959194 : check e2210797959194 [[]] .width = true := by decide
def e2210797967386 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210797967386 : Closed e2210797967386 ∧ code e2210797967386 = 11006890989594 := by decide
theorem cert_e2210797967386 : check e2210797967386 [[]] .width = true := by decide
def e2210798108698 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2210798108698 : Closed e2210798108698 ∧ code e2210798108698 = 11006891130906 := by decide
theorem cert_e2210798108698 : check e2210798108698 [[]] .width = true := by decide
def e2210798108790 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2210798108790 : Closed e2210798108790 ∧ code e2210798108790 = 11006891130998 := by decide
theorem cert_e2210798108790 : check e2210798108790 [[]] .width = true := by decide
def e2210798109034 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2210798109034 : Closed e2210798109034 ∧ code e2210798109034 = 11006891131242 := by decide
theorem cert_e2210798109034 : check e2210798109034 [[]] .width = true := by decide
def e2210798109082 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2210798109082 : Closed e2210798109082 ∧ code e2210798109082 = 11006891131290 := by decide
theorem cert_e2210798109082 : check e2210798109082 [[]] .width = true := by decide
def e2210798109166 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2210798109166 : Closed e2210798109166 ∧ code e2210798109166 = 11006891131374 := by decide
private def t_e2210798109166 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e2210798109166 : ¬ IsSelfInterpreter e2210798109166 :=
  wSource (t := t_e2210798109166) (replay_sound (ps := []) (t := e2210798109166) (by decide)) (by decide)
def e2210798110090 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2210798110090 : Closed e2210798110090 ∧ code e2210798110090 = 11006891132298 := by decide
theorem cert_e2210798110090 : check e2210798110090 [[]] .width = true := by decide
def e2210798110114 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2210798110114 : Closed e2210798110114 ∧ code e2210798110114 = 11006891132322 := by decide
theorem cert_e2210798110114 : check e2210798110114 [[]] .width = true := by decide
def e2210798110134 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2210798110134 : Closed e2210798110134 ∧ code e2210798110134 = 11006891132342 := by decide
theorem cert_e2210798110134 : check e2210798110134 [[]] .width = true := by decide
def e2210798110166 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2210798110166 : Closed e2210798110166 ∧ code e2210798110166 = 11006891132374 := by decide
theorem cert_e2210798110166 : check e2210798110166 [[]] .width = true := by decide
def e2210798110170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2210798110170 : Closed e2210798110170 ∧ code e2210798110170 = 11006891132378 := by decide
private def t_e2210798110170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e2210798110170 : ¬ IsSelfInterpreter e2210798110170 :=
  wSource (t := t_e2210798110170) (replay_sound (ps := []) (t := e2210798110170) (by decide)) (by decide)
def e2210798110222 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2210798110222 : Closed e2210798110222 ∧ code e2210798110222 = 11006891132430 := by decide
theorem cert_e2210798110222 : check e2210798110222 [[]] .width = true := by decide
def e2210798110234 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210798110234 : Closed e2210798110234 ∧ code e2210798110234 = 11006891132442 := by decide
theorem cert_e2210798110234 : check e2210798110234 [[]] .width = true := by decide
def e2210798110306 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2210798110306 : Closed e2210798110306 ∧ code e2210798110306 = 11006891132514 := by decide
theorem cert_e2210798110306 : check e2210798110306 [[]] .width = true := by decide
def e2210798110326 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2210798110326 : Closed e2210798110326 ∧ code e2210798110326 = 11006891132534 := by decide
theorem cert_e2210798110326 : check e2210798110326 [[]] .width = true := by decide
def e2210798110518 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2210798110518 : Closed e2210798110518 ∧ code e2210798110518 = 11006891132726 := by decide
theorem cert_e2210798110518 : check e2210798110518 [[]] .width = true := by decide
def e2210798110522 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2210798110522 : Closed e2210798110522 ∧ code e2210798110522 = 11006891132730 := by decide
theorem cert_e2210798110522 : check e2210798110522 [[]] .width = true := by decide
def e2210798114218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2210798114218 : Closed e2210798114218 ∧ code e2210798114218 = 11006891136426 := by decide
private def t_e2210798114218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e2210798114218 : ¬ IsSelfInterpreter e2210798114218 :=
  wSource (t := t_e2210798114218) (replay_sound (ps := []) (t := e2210798114218) (by decide)) (by decide)
def e2210798114314 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2210798114314 : Closed e2210798114314 ∧ code e2210798114314 = 11006891136522 := by decide
theorem cert_e2210798114314 : check e2210798114314 [[]] .width = true := by decide
def e2210798114410 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2210798114410 : Closed e2210798114410 ∧ code e2210798114410 = 11006891136618 := by decide
private def t_e2210798114410 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e2210798114410 : ¬ IsSelfInterpreter e2210798114410 :=
  wSource (t := t_e2210798114410) (replay_sound (ps := []) (t := e2210798114410) (by decide)) (by decide)
def e2210798114434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2210798114434 : Closed e2210798114434 ∧ code e2210798114434 = 11006891136642 := by decide
private def t_e2210798114434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e2210798114434 : ¬ IsSelfInterpreter e2210798114434 :=
  wSource (t := t_e2210798114434) (replay_sound (ps := []) (t := e2210798114434) (by decide)) (by decide)
def e2210798114458 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2210798114458 : Closed e2210798114458 ∧ code e2210798114458 = 11006891136666 := by decide
private def t_e2210798114458 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e2210798114458 : ¬ IsSelfInterpreter e2210798114458 :=
  wSource (t := t_e2210798114458) (replay_sound (ps := []) (t := e2210798114458) (by decide)) (by decide)
def e2210798114842 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210798114842 : Closed e2210798114842 ∧ code e2210798114842 = 11006891137050 := by decide
theorem cert_e2210798114842 : check e2210798114842 [[]] .width = true := by decide
def e2210798114934 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2210798114934 : Closed e2210798114934 ∧ code e2210798114934 = 11006891137142 := by decide
private def t_e2210798114934 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e2210798114934 : ¬ IsSelfInterpreter e2210798114934 :=
  wSource (t := t_e2210798114934) (replay_sound (ps := []) (t := e2210798114934) (by decide)) (by decide)
def e2210798115178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2210798115178 : Closed e2210798115178 ∧ code e2210798115178 = 11006891137386 := by decide
private def t_e2210798115178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e2210798115178 : ¬ IsSelfInterpreter e2210798115178 :=
  wSource (t := t_e2210798115178) (replay_sound (ps := []) (t := e2210798115178) (by decide)) (by decide)
def e2210798115202 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2210798115202 : Closed e2210798115202 ∧ code e2210798115202 = 11006891137410 := by decide
theorem cert_e2210798115202 : check e2210798115202 [[]] .width = true := by decide
def e2210798115226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2210798115226 : Closed e2210798115226 ∧ code e2210798115226 = 11006891137434 := by decide
private def t_e2210798115226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e2210798115226 : ¬ IsSelfInterpreter e2210798115226 :=
  wSource (t := t_e2210798115226) (replay_sound (ps := []) (t := e2210798115226) (by decide)) (by decide)
def e2210798289094 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210798289094 : Closed e2210798289094 ∧ code e2210798289094 = 11006891311302 := by decide
theorem cert_e2210798289094 : check e2210798289094 [[]] .width = true := by decide
def e2210798346266 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210798346266 : Closed e2210798346266 ∧ code e2210798346266 = 11006891368474 := by decide
theorem cert_e2210798346266 : check e2210798346266 [[]] .width = true := by decide
def e2210798346358 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210798346358 : Closed e2210798346358 ∧ code e2210798346358 = 11006891368566 := by decide
private def t_e2210798346358 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210798346358 : ¬ IsSelfInterpreter e2210798346358 :=
  wSource (t := t_e2210798346358) (replay_sound (ps := []) (t := e2210798346358) (by decide)) (by decide)
def e2210798346602 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210798346602 : Closed e2210798346602 ∧ code e2210798346602 = 11006891368810 := by decide
private def t_e2210798346602 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210798346602 : ¬ IsSelfInterpreter e2210798346602 :=
  wSource (t := t_e2210798346602) (replay_sound (ps := []) (t := e2210798346602) (by decide)) (by decide)
def e2210798346650 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210798346650 : Closed e2210798346650 ∧ code e2210798346650 = 11006891368858 := by decide
private def t_e2210798346650 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210798346650 : ¬ IsSelfInterpreter e2210798346650 :=
  wSource (t := t_e2210798346650) (replay_sound (ps := []) (t := e2210798346650) (by decide)) (by decide)
def e2210798352410 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210798352410 : Closed e2210798352410 ∧ code e2210798352410 = 11006891374618 := by decide
theorem cert_e2210798352410 : check e2210798352410 [[]] .width = true := by decide
def e2210798364698 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210798364698 : Closed e2210798364698 ∧ code e2210798364698 = 11006891386906 := by decide
theorem cert_e2210798364698 : check e2210798364698 [[]] .width = true := by decide
def e2210798370842 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2210798370842 : Closed e2210798370842 ∧ code e2210798370842 = 11006891393050 := by decide
theorem cert_e2210798370842 : check e2210798370842 [[]] .width = true := by decide
def e2210798370934 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2210798370934 : Closed e2210798370934 ∧ code e2210798370934 = 11006891393142 := by decide
theorem cert_e2210798370934 : check e2210798370934 [[]] .width = true := by decide
def e2210798371178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2210798371178 : Closed e2210798371178 ∧ code e2210798371178 = 11006891393386 := by decide
theorem cert_e2210798371178 : check e2210798371178 [[]] .width = true := by decide
def e2210798371226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2210798371226 : Closed e2210798371226 ∧ code e2210798371226 = 11006891393434 := by decide
theorem cert_e2210798371226 : check e2210798371226 [[]] .width = true := by decide
def e2210798371310 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2210798371310 : Closed e2210798371310 ∧ code e2210798371310 = 11006891393518 := by decide
private def t_e2210798371310 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem cert_e2210798371310 : ¬ IsSelfInterpreter e2210798371310 :=
  wSource (t := t_e2210798371310) (replay_sound (ps := []) (t := e2210798371310) (by decide)) (by decide)
def e2210798372234 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2210798372234 : Closed e2210798372234 ∧ code e2210798372234 = 11006891394442 := by decide
theorem cert_e2210798372234 : check e2210798372234 [[]] .width = true := by decide
def e2210798372258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2210798372258 : Closed e2210798372258 ∧ code e2210798372258 = 11006891394466 := by decide
theorem cert_e2210798372258 : check e2210798372258 [[]] .width = true := by decide
def e2210798372278 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2210798372278 : Closed e2210798372278 ∧ code e2210798372278 = 11006891394486 := by decide
theorem cert_e2210798372278 : check e2210798372278 [[]] .width = true := by decide
def e2210798372310 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2210798372310 : Closed e2210798372310 ∧ code e2210798372310 = 11006891394518 := by decide
theorem cert_e2210798372310 : check e2210798372310 [[]] .width = true := by decide
def e2210798372314 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2210798372314 : Closed e2210798372314 ∧ code e2210798372314 = 11006891394522 := by decide
private def t_e2210798372314 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem cert_e2210798372314 : ¬ IsSelfInterpreter e2210798372314 :=
  wSource (t := t_e2210798372314) (replay_sound (ps := []) (t := e2210798372314) (by decide)) (by decide)
def e2210798372366 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2210798372366 : Closed e2210798372366 ∧ code e2210798372366 = 11006891394574 := by decide
theorem cert_e2210798372366 : check e2210798372366 [[]] .width = true := by decide
def e2210798372378 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210798372378 : Closed e2210798372378 ∧ code e2210798372378 = 11006891394586 := by decide
theorem cert_e2210798372378 : check e2210798372378 [[]] .width = true := by decide
def e2210798372450 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2210798372450 : Closed e2210798372450 ∧ code e2210798372450 = 11006891394658 := by decide
theorem cert_e2210798372450 : check e2210798372450 [[]] .width = true := by decide
def e2210798372470 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2210798372470 : Closed e2210798372470 ∧ code e2210798372470 = 11006891394678 := by decide
theorem cert_e2210798372470 : check e2210798372470 [[]] .width = true := by decide
def e2210798372662 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2210798372662 : Closed e2210798372662 ∧ code e2210798372662 = 11006891394870 := by decide
theorem cert_e2210798372662 : check e2210798372662 [[]] .width = true := by decide
def e2210798372666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2210798372666 : Closed e2210798372666 ∧ code e2210798372666 = 11006891394874 := by decide
theorem cert_e2210798372666 : check e2210798372666 [[]] .width = true := by decide
def e2210798376362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2210798376362 : Closed e2210798376362 ∧ code e2210798376362 = 11006891398570 := by decide
private def t_e2210798376362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem cert_e2210798376362 : ¬ IsSelfInterpreter e2210798376362 :=
  wSource (t := t_e2210798376362) (replay_sound (ps := []) (t := e2210798376362) (by decide)) (by decide)
def e2210798376458 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2210798376458 : Closed e2210798376458 ∧ code e2210798376458 = 11006891398666 := by decide
theorem cert_e2210798376458 : check e2210798376458 [[]] .width = true := by decide
def e2210798376554 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2210798376554 : Closed e2210798376554 ∧ code e2210798376554 = 11006891398762 := by decide
private def t_e2210798376554 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem cert_e2210798376554 : ¬ IsSelfInterpreter e2210798376554 :=
  wSource (t := t_e2210798376554) (replay_sound (ps := []) (t := e2210798376554) (by decide)) (by decide)
def e2210798376578 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2210798376578 : Closed e2210798376578 ∧ code e2210798376578 = 11006891398786 := by decide
private def t_e2210798376578 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem cert_e2210798376578 : ¬ IsSelfInterpreter e2210798376578 :=
  wSource (t := t_e2210798376578) (replay_sound (ps := []) (t := e2210798376578) (by decide)) (by decide)
def e2210798376602 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2210798376602 : Closed e2210798376602 ∧ code e2210798376602 = 11006891398810 := by decide
private def t_e2210798376602 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem cert_e2210798376602 : ¬ IsSelfInterpreter e2210798376602 :=
  wSource (t := t_e2210798376602) (replay_sound (ps := []) (t := e2210798376602) (by decide)) (by decide)
def e2210798376986 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210798376986 : Closed e2210798376986 ∧ code e2210798376986 = 11006891399194 := by decide
theorem cert_e2210798376986 : check e2210798376986 [[]] .width = true := by decide
def e2210798377078 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2210798377078 : Closed e2210798377078 ∧ code e2210798377078 = 11006891399286 := by decide
private def t_e2210798377078 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem cert_e2210798377078 : ¬ IsSelfInterpreter e2210798377078 :=
  wSource (t := t_e2210798377078) (replay_sound (ps := []) (t := e2210798377078) (by decide)) (by decide)
def e2210798377322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2210798377322 : Closed e2210798377322 ∧ code e2210798377322 = 11006891399530 := by decide
private def t_e2210798377322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem cert_e2210798377322 : ¬ IsSelfInterpreter e2210798377322 :=
  wSource (t := t_e2210798377322) (replay_sound (ps := []) (t := e2210798377322) (by decide)) (by decide)
def e2210798377346 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))
theorem wire_e2210798377346 : Closed e2210798377346 ∧ code e2210798377346 = 11006891399554 := by decide
theorem cert_e2210798377346 : check e2210798377346 [[]] .width = true := by decide
def e2210798377370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2210798377370 : Closed e2210798377370 ∧ code e2210798377370 = 11006891399578 := by decide
private def t_e2210798377370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem cert_e2210798377370 : ¬ IsSelfInterpreter e2210798377370 :=
  wSource (t := t_e2210798377370) (replay_sound (ps := []) (t := e2210798377370) (by decide)) (by decide)
def e2210798557210 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210798557210 : Closed e2210798557210 ∧ code e2210798557210 = 11006891579418 := by decide
theorem cert_e2210798557210 : check e2210798557210 [[]] .width = true := by decide
def e2210798561306 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210798561306 : Closed e2210798561306 ∧ code e2210798561306 = 11006891583514 := by decide
theorem cert_e2210798561306 : check e2210798561306 [[]] .width = true := by decide
def e2210955903174 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210955903174 : Closed e2210955903174 ∧ code e2210955903174 = 11007048925382 := by decide
theorem cert_e2210955903174 : check e2210955903174 [[]] .width = true := by decide
def e2210962194630 : Term := (.app (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210962194630 : Closed e2210962194630 ∧ code e2210962194630 = 11007055216838 := by decide
theorem cert_e2210962194630 : check e2210962194630 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2210797543542
#print axioms Blc.Floor43.cert_e2210797543786
#print axioms Blc.Floor43.cert_e2210797543834
#print axioms Blc.Floor43.cert_e2210797559926
#print axioms Blc.Floor43.cert_e2210797560170
#print axioms Blc.Floor43.cert_e2210797560218
#print axioms Blc.Floor43.cert_e2210797625462
#print axioms Blc.Floor43.cert_e2210797625706
#print axioms Blc.Floor43.cert_e2210797625754
#print axioms Blc.Floor43.cert_e2210797936758
#print axioms Blc.Floor43.cert_e2210797937002
#print axioms Blc.Floor43.cert_e2210797937050
#print axioms Blc.Floor43.cert_e2210797953142
#print axioms Blc.Floor43.cert_e2210797953386
#print axioms Blc.Floor43.cert_e2210797953434
#print axioms Blc.Floor43.cert_e2210798109166
#print axioms Blc.Floor43.cert_e2210798110170
#print axioms Blc.Floor43.cert_e2210798114218
#print axioms Blc.Floor43.cert_e2210798114410
#print axioms Blc.Floor43.cert_e2210798114434
#print axioms Blc.Floor43.cert_e2210798114458
#print axioms Blc.Floor43.cert_e2210798114934
#print axioms Blc.Floor43.cert_e2210798115178
#print axioms Blc.Floor43.cert_e2210798115226
#print axioms Blc.Floor43.cert_e2210798346358
#print axioms Blc.Floor43.cert_e2210798346602
#print axioms Blc.Floor43.cert_e2210798346650
#print axioms Blc.Floor43.cert_e2210798371310
#print axioms Blc.Floor43.cert_e2210798372314
#print axioms Blc.Floor43.cert_e2210798376362
#print axioms Blc.Floor43.cert_e2210798376554
#print axioms Blc.Floor43.cert_e2210798376578
#print axioms Blc.Floor43.cert_e2210798376602
#print axioms Blc.Floor43.cert_e2210798377078
#print axioms Blc.Floor43.cert_e2210798377322
#print axioms Blc.Floor43.cert_e2210798377370
