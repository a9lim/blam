import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407508846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422407508846 : Closed e2422407508846 ∧ code e2422407508846 = 11218500531054 := by decide
def e2422407508854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422407508854 : Closed e2422407508854 ∧ code e2422407508854 = 11218500531062 := by decide
theorem cert_e2422407508854 : check e2422407508854 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407508874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407508874 : Closed e2422407508874 ∧ code e2422407508874 = 11218500531082 := by decide
theorem cert_e2422407508874 : check e2422407508874 [[],[]] .chain = true := by decide
def e2422407508898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407508898 : Closed e2422407508898 ∧ code e2422407508898 = 11218500531106 := by decide
theorem cert_e2422407508898 : check e2422407508898 [[],[]] .chain = true := by decide
def e2422407508910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422407508910 : Closed e2422407508910 ∧ code e2422407508910 = 11218500531118 := by decide
def e2422407508918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2422407508918 : Closed e2422407508918 ∧ code e2422407508918 = 11218500531126 := by decide
theorem cert_e2422407508918 : check e2422407508918 [[],[]] .chain = true := by decide
def e2422407508922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422407508922 : Closed e2422407508922 ∧ code e2422407508922 = 11218500531130 := by decide
theorem cert_e2422407508922 : check e2422407508922 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407508950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422407508950 : Closed e2422407508950 ∧ code e2422407508950 = 11218500531158 := by decide
theorem cert_e2422407508950 : check e2422407508950 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407508954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422407508954 : Closed e2422407508954 ∧ code e2422407508954 = 11218500531162 := by decide
theorem cert_e2422407508954 : check e2422407508954 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407509022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407509022 : Closed e2422407509022 ∧ code e2422407509022 = 11218500531230 := by decide
theorem cert_e2422407509022 : check e2422407509022 [[],[]] .chain = true := by decide
def e2422407509218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407509218 : Closed e2422407509218 ∧ code e2422407509218 = 11218500531426 := by decide
theorem cert_e2422407509218 : check e2422407509218 [[],[]] .chain = true := by decide
def e2422407509230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407509230 : Closed e2422407509230 ∧ code e2422407509230 = 11218500531438 := by decide
theorem cert_e2422407509230 : check e2422407509230 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407509238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407509238 : Closed e2422407509238 ∧ code e2422407509238 = 11218500531446 := by decide
theorem cert_e2422407509238 : check e2422407509238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422407509506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407509506 : Closed e2422407509506 ∧ code e2422407509506 = 11218500531714 := by decide
theorem cert_e2422407509506 : check e2422407509506 [[],[]] .chain = true := by decide
def e2422407509518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407509518 : Closed e2422407509518 ∧ code e2422407509518 = 11218500531726 := by decide
theorem cert_e2422407509518 : check e2422407509518 [[],[]] .chain = true := by decide
def e2422407509530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407509530 : Closed e2422407509530 ∧ code e2422407509530 = 11218500531738 := by decide
theorem cert_e2422407509530 : check e2422407509530 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407509602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407509602 : Closed e2422407509602 ∧ code e2422407509602 = 11218500531810 := by decide
theorem cert_e2422407509602 : check e2422407509602 [[],[]] .chain = true := by decide
def e2422407509614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407509614 : Closed e2422407509614 ∧ code e2422407509614 = 11218500531822 := by decide
theorem cert_e2422407509614 : check e2422407509614 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2422407509622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407509622 : Closed e2422407509622 ∧ code e2422407509622 = 11218500531830 := by decide
theorem cert_e2422407509622 : check e2422407509622 [[],[]] .chain = true := by decide
def e2422407509626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407509626 : Closed e2422407509626 ∧ code e2422407509626 = 11218500531834 := by decide
def e2422407509814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407509814 : Closed e2422407509814 ∧ code e2422407509814 = 11218500532022 := by decide
theorem cert_e2422407509814 : check e2422407509814 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407509818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407509818 : Closed e2422407509818 ∧ code e2422407509818 = 11218500532026 := by decide
theorem cert_e2422407509818 : check e2422407509818 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407510026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407510026 : Closed e2422407510026 ∧ code e2422407510026 = 11218500532234 := by decide
theorem cert_e2422407510026 : check e2422407510026 [[],[]] .chain = true := by decide
def e2422407510062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407510062 : Closed e2422407510062 ∧ code e2422407510062 = 11218500532270 := by decide
theorem cert_e2422407510062 : check e2422407510062 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407510070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407510070 : Closed e2422407510070 ∧ code e2422407510070 = 11218500532278 := by decide
theorem cert_e2422407510070 : check e2422407510070 [[],[]] .chain = true := by decide
def e2422407510074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407510074 : Closed e2422407510074 ∧ code e2422407510074 = 11218500532282 := by decide
theorem cert_e2422407510074 : check e2422407510074 [[],[]] .chain = true := by decide
def e2422407510122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407510122 : Closed e2422407510122 ∧ code e2422407510122 = 11218500532330 := by decide
theorem cert_e2422407510122 : check e2422407510122 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407510158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407510158 : Closed e2422407510158 ∧ code e2422407510158 = 11218500532366 := by decide
theorem cert_e2422407510158 : check e2422407510158 [[],[]] .chain = true := by decide
def e2422407510170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407510170 : Closed e2422407510170 ∧ code e2422407510170 = 11218500532378 := by decide
theorem cert_e2422407510170 : check e2422407510170 [[],[]] .chain = true := by decide
def e2422407510214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407510214 : Closed e2422407510214 ∧ code e2422407510214 = 11218500532422 := by decide
theorem cert_e2422407510214 : check e2422407510214 [[],[]] .chain = true := by decide
def e2422407510242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407510242 : Closed e2422407510242 ∧ code e2422407510242 = 11218500532450 := by decide
theorem cert_e2422407510242 : check e2422407510242 [[],[]] .chain = true := by decide
def e2422407510254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407510254 : Closed e2422407510254 ∧ code e2422407510254 = 11218500532462 := by decide
theorem cert_e2422407510254 : check e2422407510254 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407510262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407510262 : Closed e2422407510262 ∧ code e2422407510262 = 11218500532470 := by decide
theorem cert_e2422407510262 : check e2422407510262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407510410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407510410 : Closed e2422407510410 ∧ code e2422407510410 = 11218500532618 := by decide
theorem cert_e2422407510410 : check e2422407510410 [[],[]] .chain = true := by decide
def e2422407510434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407510434 : Closed e2422407510434 ∧ code e2422407510434 = 11218500532642 := by decide
theorem cert_e2422407510434 : check e2422407510434 [[],[]] .chain = true := by decide
def e2422407510446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407510446 : Closed e2422407510446 ∧ code e2422407510446 = 11218500532654 := by decide
def e2422407510454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422407510454 : Closed e2422407510454 ∧ code e2422407510454 = 11218500532662 := by decide
theorem cert_e2422407510454 : check e2422407510454 [[],[]] .chain = true := by decide
def e2422407510458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407510458 : Closed e2422407510458 ∧ code e2422407510458 = 11218500532666 := by decide
theorem cert_e2422407510458 : check e2422407510458 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407510486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422407510486 : Closed e2422407510486 ∧ code e2422407510486 = 11218500532694 := by decide
theorem cert_e2422407510486 : check e2422407510486 [[],[]] .chain = true := by decide
def e2422407510490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422407510490 : Closed e2422407510490 ∧ code e2422407510490 = 11218500532698 := by decide
theorem cert_e2422407510490 : check e2422407510490 [[],[]] .chain = true := by decide
def e2422407510506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407510506 : Closed e2422407510506 ∧ code e2422407510506 = 11218500532714 := by decide
theorem cert_e2422407510506 : check e2422407510506 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407510530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407510530 : Closed e2422407510530 ∧ code e2422407510530 = 11218500532738 := by decide
theorem cert_e2422407510530 : check e2422407510530 [[],[]] .chain = true := by decide
def e2422407510542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407510542 : Closed e2422407510542 ∧ code e2422407510542 = 11218500532750 := by decide
theorem cert_e2422407510542 : check e2422407510542 [[],[]] .chain = true := by decide
def e2422407510554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407510554 : Closed e2422407510554 ∧ code e2422407510554 = 11218500532762 := by decide
theorem cert_e2422407510554 : check e2422407510554 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407510626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407510626 : Closed e2422407510626 ∧ code e2422407510626 = 11218500532834 := by decide
theorem cert_e2422407510626 : check e2422407510626 [[],[]] .chain = true := by decide
def e2422407510638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407510638 : Closed e2422407510638 ∧ code e2422407510638 = 11218500532846 := by decide
theorem cert_e2422407510638 : check e2422407510638 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .identityHead = true := by decide
def e2422407510646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407510646 : Closed e2422407510646 ∧ code e2422407510646 = 11218500532854 := by decide
theorem cert_e2422407510646 : check e2422407510646 [[],[]] .chain = true := by decide
def e2422407510650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407510650 : Closed e2422407510650 ∧ code e2422407510650 = 11218500532858 := by decide
def e2422407510790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407510790 : Closed e2422407510790 ∧ code e2422407510790 = 11218500532998 := by decide
theorem cert_e2422407510790 : check e2422407510790 [[],[]] .chain = true := by decide
def e2422407510814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407510814 : Closed e2422407510814 ∧ code e2422407510814 = 11218500533022 := by decide
theorem cert_e2422407510814 : check e2422407510814 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407510838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407510838 : Closed e2422407510838 ∧ code e2422407510838 = 11218500533046 := by decide
theorem cert_e2422407510838 : check e2422407510838 [[],[]] .chain = true := by decide
def e2422407510842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407510842 : Closed e2422407510842 ∧ code e2422407510842 = 11218500533050 := by decide
theorem cert_e2422407510842 : check e2422407510842 [[],[]] .chain = true := by decide
def e2422407510914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407510914 : Closed e2422407510914 ∧ code e2422407510914 = 11218500533122 := by decide
theorem cert_e2422407510914 : check e2422407510914 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407510926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407510926 : Closed e2422407510926 ∧ code e2422407510926 = 11218500533134 := by decide
theorem cert_e2422407510926 : check e2422407510926 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407510938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407510938 : Closed e2422407510938 ∧ code e2422407510938 = 11218500533146 := by decide
theorem cert_e2422407510938 : check e2422407510938 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407511062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407511062 : Closed e2422407511062 ∧ code e2422407511062 = 11218500533270 := by decide
theorem cert_e2422407511062 : check e2422407511062 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407511158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422407511158 : Closed e2422407511158 ∧ code e2422407511158 = 11218500533366 := by decide
theorem cert_e2422407511158 : check e2422407511158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407511254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407511254 : Closed e2422407511254 ∧ code e2422407511254 = 11218500533462 := by decide
theorem cert_e2422407511254 : check e2422407511254 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407511258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407511258 : Closed e2422407511258 ∧ code e2422407511258 = 11218500533466 := by decide
theorem cert_e2422407511258 : check e2422407511258 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407511274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407511274 : Closed e2422407511274 ∧ code e2422407511274 = 11218500533482 := by decide
theorem cert_e2422407511274 : check e2422407511274 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407511350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407511350 : Closed e2422407511350 ∧ code e2422407511350 = 11218500533558 := by decide
theorem cert_e2422407511350 : check e2422407511350 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407511354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407511354 : Closed e2422407511354 ∧ code e2422407511354 = 11218500533562 := by decide
theorem cert_e2422407511354 : check e2422407511354 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407511426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407511426 : Closed e2422407511426 ∧ code e2422407511426 = 11218500533634 := by decide
theorem cert_e2422407511426 : check e2422407511426 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407511438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422407511438 : Closed e2422407511438 ∧ code e2422407511438 = 11218500533646 := by decide
theorem cert_e2422407511438 : check e2422407511438 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407511450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407511450 : Closed e2422407511450 ∧ code e2422407511450 = 11218500533658 := by decide
theorem cert_e2422407511450 : check e2422407511450 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407512286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422407512286 : Closed e2422407512286 ∧ code e2422407512286 = 11218500534494 := by decide
theorem cert_e2422407512286 : check e2422407512286 [[],[]] .chain = true := by decide
def e2422407512314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422407512314 : Closed e2422407512314 ∧ code e2422407512314 = 11218500534522 := by decide
theorem cert_e2422407512314 : check e2422407512314 [[],[]] .chain = true := by decide
def e2422407512862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422407512862 : Closed e2422407512862 ∧ code e2422407512862 = 11218500535070 := by decide
theorem cert_e2422407512862 : check e2422407512862 [[],[]] .chain = true := by decide
def e2422407513030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422407513030 : Closed e2422407513030 ∧ code e2422407513030 = 11218500535238 := by decide
theorem cert_e2422407513030 : check e2422407513030 [[],[]] .chain = true := by decide
def e2422407513054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407513054 : Closed e2422407513054 ∧ code e2422407513054 = 11218500535262 := by decide
theorem cert_e2422407513054 : check e2422407513054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407513070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407513070 : Closed e2422407513070 ∧ code e2422407513070 = 11218500535278 := by decide
theorem cert_e2422407513070 : check e2422407513070 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407514902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422407514902 : Closed e2422407514902 ∧ code e2422407514902 = 11218500537110 := by decide
theorem cert_e2422407514902 : check e2422407514902 [[],[]] .chain = true := by decide
def e2422407514978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422407514978 : Closed e2422407514978 ∧ code e2422407514978 = 11218500537186 := by decide
theorem cert_e2422407514978 : check e2422407514978 [[],[]] .chain = true := by decide
def e2422407514990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407514990 : Closed e2422407514990 ∧ code e2422407514990 = 11218500537198 := by decide
theorem cert_e2422407514990 : check e2422407514990 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407514998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407514998 : Closed e2422407514998 ∧ code e2422407514998 = 11218500537206 := by decide
theorem cert_e2422407514998 : check e2422407514998 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407515018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407515018 : Closed e2422407515018 ∧ code e2422407515018 = 11218500537226 := by decide
theorem cert_e2422407515018 : check e2422407515018 [[],[]] .chain = true := by decide
def e2422407515042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407515042 : Closed e2422407515042 ∧ code e2422407515042 = 11218500537250 := by decide
theorem cert_e2422407515042 : check e2422407515042 [[],[]] .chain = true := by decide
def e2422407515054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407515054 : Closed e2422407515054 ∧ code e2422407515054 = 11218500537262 := by decide
theorem cert_e2422407515054 : check e2422407515054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407515062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2422407515062 : Closed e2422407515062 ∧ code e2422407515062 = 11218500537270 := by decide
theorem cert_e2422407515062 : check e2422407515062 [[],[]] .chain = true := by decide
def e2422407515066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407515066 : Closed e2422407515066 ∧ code e2422407515066 = 11218500537274 := by decide
theorem cert_e2422407515066 : check e2422407515066 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407515094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407515094 : Closed e2422407515094 ∧ code e2422407515094 = 11218500537302 := by decide
theorem cert_e2422407515094 : check e2422407515094 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407515098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407515098 : Closed e2422407515098 ∧ code e2422407515098 = 11218500537306 := by decide
theorem cert_e2422407515098 : check e2422407515098 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407515166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2422407515166 : Closed e2422407515166 ∧ code e2422407515166 = 11218500537374 := by decide
theorem cert_e2422407515166 : check e2422407515166 [[],[]] .chain = true := by decide
def e2422407515362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422407515362 : Closed e2422407515362 ∧ code e2422407515362 = 11218500537570 := by decide
theorem cert_e2422407515362 : check e2422407515362 [[],[]] .chain = true := by decide
def e2422407515374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407515374 : Closed e2422407515374 ∧ code e2422407515374 = 11218500537582 := by decide
theorem cert_e2422407515374 : check e2422407515374 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407515382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407515382 : Closed e2422407515382 ∧ code e2422407515382 = 11218500537590 := by decide
theorem cert_e2422407515382 : check e2422407515382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407515650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407515650 : Closed e2422407515650 ∧ code e2422407515650 = 11218500537858 := by decide
theorem cert_e2422407515650 : check e2422407515650 [[],[]] .chain = true := by decide
def e2422407515662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407515662 : Closed e2422407515662 ∧ code e2422407515662 = 11218500537870 := by decide
theorem cert_e2422407515662 : check e2422407515662 [[],[]] .chain = true := by decide
def e2422407515674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407515674 : Closed e2422407515674 ∧ code e2422407515674 = 11218500537882 := by decide
theorem cert_e2422407515674 : check e2422407515674 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407515746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407515746 : Closed e2422407515746 ∧ code e2422407515746 = 11218500537954 := by decide
theorem cert_e2422407515746 : check e2422407515746 [[],[]] .chain = true := by decide
def e2422407515758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407515758 : Closed e2422407515758 ∧ code e2422407515758 = 11218500537966 := by decide
theorem cert_e2422407515758 : check e2422407515758 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407515766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407515766 : Closed e2422407515766 ∧ code e2422407515766 = 11218500537974 := by decide
theorem cert_e2422407515766 : check e2422407515766 [[],[]] .chain = true := by decide
def e2422407515770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407515770 : Closed e2422407515770 ∧ code e2422407515770 = 11218500537978 := by decide
theorem cert_e2422407515770 : check e2422407515770 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407515958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407515958 : Closed e2422407515958 ∧ code e2422407515958 = 11218500538166 := by decide
def e2422407515962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407515962 : Closed e2422407515962 ∧ code e2422407515962 = 11218500538170 := by decide
def e2422407520282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422407520282 : Closed e2422407520282 ∧ code e2422407520282 = 11218500542490 := by decide
theorem cert_e2422407520282 : check e2422407520282 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407520318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422407520318 : Closed e2422407520318 ∧ code e2422407520318 = 11218500542526 := by decide
theorem cert_e2422407520318 : check e2422407520318 [[],[]] .chain = true := by decide
def e2422407520366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422407520366 : Closed e2422407520366 ∧ code e2422407520366 = 11218500542574 := by decide
theorem cert_e2422407520366 : check e2422407520366 [[],[]] .chain = true := by decide
def e2422407520374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422407520374 : Closed e2422407520374 ∧ code e2422407520374 = 11218500542582 := by decide
theorem cert_e2422407520374 : check e2422407520374 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407520378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422407520378 : Closed e2422407520378 ∧ code e2422407520378 = 11218500542586 := by decide
theorem cert_e2422407520378 : check e2422407520378 [[],[]] .chain = true := by decide
def e2422407520618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422407520618 : Closed e2422407520618 ∧ code e2422407520618 = 11218500542826 := by decide
theorem cert_e2422407520618 : check e2422407520618 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407520654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422407520654 : Closed e2422407520654 ∧ code e2422407520654 = 11218500542862 := by decide
theorem cert_e2422407520654 : check e2422407520654 [[],[]] .chain = true := by decide
def e2422407520666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407520666 : Closed e2422407520666 ∧ code e2422407520666 = 11218500542874 := by decide
theorem cert_e2422407520666 : check e2422407520666 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407520710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422407520710 : Closed e2422407520710 ∧ code e2422407520710 = 11218500542918 := by decide
theorem cert_e2422407520710 : check e2422407520710 [[],[]] .chain = true := by decide
def e2422407520734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407520734 : Closed e2422407520734 ∧ code e2422407520734 = 11218500542942 := by decide
theorem cert_e2422407520734 : check e2422407520734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407520738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407520738 : Closed e2422407520738 ∧ code e2422407520738 = 11218500542946 := by decide
theorem cert_e2422407520738 : check e2422407520738 [[],[]] .chain = true := by decide
def e2422407520750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422407520750 : Closed e2422407520750 ∧ code e2422407520750 = 11218500542958 := by decide
theorem cert_e2422407520750 : check e2422407520750 [[],[]] .chain = true := by decide
def e2422407520758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407520758 : Closed e2422407520758 ∧ code e2422407520758 = 11218500542966 := by decide
theorem cert_e2422407520758 : check e2422407520758 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407521674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407521674 : Closed e2422407521674 ∧ code e2422407521674 = 11218500543882 := by decide
theorem cert_e2422407521674 : check e2422407521674 [[],[]] .chain = true := by decide
def e2422407521698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407521698 : Closed e2422407521698 ∧ code e2422407521698 = 11218500543906 := by decide
theorem cert_e2422407521698 : check e2422407521698 [[],[]] .chain = true := by decide
def e2422407521710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407521710 : Closed e2422407521710 ∧ code e2422407521710 = 11218500543918 := by decide
def e2422407521718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422407521718 : Closed e2422407521718 ∧ code e2422407521718 = 11218500543926 := by decide
theorem cert_e2422407521718 : check e2422407521718 [[],[]] .chain = true := by decide
def e2422407521722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407521722 : Closed e2422407521722 ∧ code e2422407521722 = 11218500543930 := by decide
def e2422407521750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422407521750 : Closed e2422407521750 ∧ code e2422407521750 = 11218500543958 := by decide
theorem cert_e2422407521750 : check e2422407521750 [[],[]] .chain = true := by decide
def e2422407521754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422407521754 : Closed e2422407521754 ∧ code e2422407521754 = 11218500543962 := by decide
theorem cert_e2422407521754 : check e2422407521754 [[],[]] .chain = true := by decide
def e2422407521770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407521770 : Closed e2422407521770 ∧ code e2422407521770 = 11218500543978 := by decide
def e2422407521794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407521794 : Closed e2422407521794 ∧ code e2422407521794 = 11218500544002 := by decide
theorem cert_e2422407521794 : check e2422407521794 [[],[]] .chain = true := by decide
def e2422407521806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407521806 : Closed e2422407521806 ∧ code e2422407521806 = 11218500544014 := by decide
theorem cert_e2422407521806 : check e2422407521806 [[],[]] .chain = true := by decide
def e2422407521818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407521818 : Closed e2422407521818 ∧ code e2422407521818 = 11218500544026 := by decide
theorem cert_e2422407521818 : check e2422407521818 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407521890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407521890 : Closed e2422407521890 ∧ code e2422407521890 = 11218500544098 := by decide
theorem cert_e2422407521890 : check e2422407521890 [[],[]] .chain = true := by decide
def e2422407521902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407521902 : Closed e2422407521902 ∧ code e2422407521902 = 11218500544110 := by decide
def e2422407521910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407521910 : Closed e2422407521910 ∧ code e2422407521910 = 11218500544118 := by decide
theorem cert_e2422407521910 : check e2422407521910 [[],[]] .chain = true := by decide
def e2422407521914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407521914 : Closed e2422407521914 ∧ code e2422407521914 = 11218500544122 := by decide
def e2422407522054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407522054 : Closed e2422407522054 ∧ code e2422407522054 = 11218500544262 := by decide
theorem cert_e2422407522054 : check e2422407522054 [[],[]] .chain = true := by decide
def e2422407522078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407522078 : Closed e2422407522078 ∧ code e2422407522078 = 11218500544286 := by decide
theorem cert_e2422407522078 : check e2422407522078 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407522102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407522102 : Closed e2422407522102 ∧ code e2422407522102 = 11218500544310 := by decide
theorem cert_e2422407522102 : check e2422407522102 [[],[]] .chain = true := by decide
def e2422407522106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407522106 : Closed e2422407522106 ∧ code e2422407522106 = 11218500544314 := by decide
theorem cert_e2422407522106 : check e2422407522106 [[],[]] .chain = true := by decide
def e2422407522178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407522178 : Closed e2422407522178 ∧ code e2422407522178 = 11218500544386 := by decide
theorem cert_e2422407522178 : check e2422407522178 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407522190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407522190 : Closed e2422407522190 ∧ code e2422407522190 = 11218500544398 := by decide
theorem cert_e2422407522190 : check e2422407522190 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407522202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407522202 : Closed e2422407522202 ∧ code e2422407522202 = 11218500544410 := by decide
def e2422407524590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407524590 : Closed e2422407524590 ∧ code e2422407524590 = 11218500546798 := by decide
theorem cert_e2422407524590 : check e2422407524590 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407524598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407524598 : Closed e2422407524598 ∧ code e2422407524598 = 11218500546806 := by decide
theorem cert_e2422407524598 : check e2422407524598 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407525078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407525078 : Closed e2422407525078 ∧ code e2422407525078 = 11218500547286 := by decide
theorem cert_e2422407525078 : check e2422407525078 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407525082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407525082 : Closed e2422407525082 ∧ code e2422407525082 = 11218500547290 := by decide
theorem cert_e2422407525082 : check e2422407525082 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407525098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407525098 : Closed e2422407525098 ∧ code e2422407525098 = 11218500547306 := by decide
theorem cert_e2422407525098 : check e2422407525098 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407525174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407525174 : Closed e2422407525174 ∧ code e2422407525174 = 11218500547382 := by decide
theorem cert_e2422407525174 : check e2422407525174 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407525178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407525178 : Closed e2422407525178 ∧ code e2422407525178 = 11218500547386 := by decide
theorem cert_e2422407525178 : check e2422407525178 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407525250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407525250 : Closed e2422407525250 ∧ code e2422407525250 = 11218500547458 := by decide
theorem cert_e2422407525250 : check e2422407525250 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407525262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422407525262 : Closed e2422407525262 ∧ code e2422407525262 = 11218500547470 := by decide
theorem cert_e2422407525262 : check e2422407525262 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407525274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407525274 : Closed e2422407525274 ∧ code e2422407525274 = 11218500547482 := by decide
theorem cert_e2422407525274 : check e2422407525274 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407528554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0))))))
theorem wire_e2422407528554 : Closed e2422407528554 ∧ code e2422407528554 = 11218500550762 := by decide
theorem cert_e2422407528554 : check e2422407528554 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407528602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407528602 : Closed e2422407528602 ∧ code e2422407528602 = 11218500550810 := by decide
theorem cert_e2422407528602 : check e2422407528602 [[],[]] .chain = true := by decide
def e2422407528694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e2422407528694 : Closed e2422407528694 ∧ code e2422407528694 = 11218500550902 := by decide
theorem cert_e2422407528694 : check e2422407528694 [[],[]] .chain = true := by decide
def e2422407528698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2422407528698 : Closed e2422407528698 ∧ code e2422407528698 = 11218500550906 := by decide
theorem cert_e2422407528698 : check e2422407528698 [[],[]] .chain = true := by decide
def e2422407528890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2422407528890 : Closed e2422407528890 ∧ code e2422407528890 = 11218500551098 := by decide
theorem cert_e2422407528890 : check e2422407528890 [[],[]] .chain = true := by decide
def e2422407528922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0))))))
theorem wire_e2422407528922 : Closed e2422407528922 ∧ code e2422407528922 = 11218500551130 := by decide
theorem cert_e2422407528922 : check e2422407528922 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407528938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2422407528938 : Closed e2422407528938 ∧ code e2422407528938 = 11218500551146 := by decide
theorem cert_e2422407528938 : check e2422407528938 [[],[]] .chain = true := by decide
def e2422407529070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407529070 : Closed e2422407529070 ∧ code e2422407529070 = 11218500551278 := by decide
theorem cert_e2422407529070 : check e2422407529070 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407529082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407529082 : Closed e2422407529082 ∧ code e2422407529082 = 11218500551290 := by decide
theorem cert_e2422407529082 : check e2422407529082 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407529270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407529270 : Closed e2422407529270 ∧ code e2422407529270 = 11218500551478 := by decide
theorem cert_e2422407529270 : check e2422407529270 [[],[]] .chain = true := by decide
def e2422407529274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407529274 : Closed e2422407529274 ∧ code e2422407529274 = 11218500551482 := by decide
theorem cert_e2422407529274 : check e2422407529274 [[],[]] .chain = true := by decide
def e2422407529358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2422407529358 : Closed e2422407529358 ∧ code e2422407529358 = 11218500551566 := by decide
theorem cert_e2422407529358 : check e2422407529358 [[],[]] .chain = true := by decide
def e2422407529370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407529370 : Closed e2422407529370 ∧ code e2422407529370 = 11218500551578 := by decide
theorem cert_e2422407529370 : check e2422407529370 [[],[]] .chain = true := by decide
def e2422407529414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2422407529414 : Closed e2422407529414 ∧ code e2422407529414 = 11218500551622 := by decide
theorem cert_e2422407529414 : check e2422407529414 [[],[]] .chain = true := by decide
def e2422407529898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e2422407529898 : Closed e2422407529898 ∧ code e2422407529898 = 11218500552106 := by decide
theorem cert_e2422407529898 : check e2422407529898 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407530042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407530042 : Closed e2422407530042 ∧ code e2422407530042 = 11218500552250 := by decide
theorem cert_e2422407530042 : check e2422407530042 [[],[]] .chain = true := by decide
def e2422407530090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407530090 : Closed e2422407530090 ∧ code e2422407530090 = 11218500552298 := by decide
theorem cert_e2422407530090 : check e2422407530090 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407530138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407530138 : Closed e2422407530138 ∧ code e2422407530138 = 11218500552346 := by decide
theorem cert_e2422407530138 : check e2422407530138 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407530182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407530182 : Closed e2422407530182 ∧ code e2422407530182 = 11218500552390 := by decide
theorem cert_e2422407530182 : check e2422407530182 [[],[]] .chain = true := by decide
def e2422407530262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407530262 : Closed e2422407530262 ∧ code e2422407530262 = 11218500552470 := by decide
theorem cert_e2422407530262 : check e2422407530262 [[],[]] .chain = true := by decide
end Blc.Floor43
