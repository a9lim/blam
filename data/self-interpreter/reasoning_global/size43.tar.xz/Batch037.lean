import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606396543722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e606396543722 : Closed e606396543722 ∧ code e606396543722 = 9402489565930 := by decide
theorem cert_e606396543722 : check e606396543722 [[.under]] .sourceHead = true := by decide
def e606396543798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606396543798 : Closed e606396543798 ∧ code e606396543798 = 9402489566006 := by decide
theorem cert_e606396543798 : check e606396543798 [[.under]] .sourceHead = true := by decide
def e606396543802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606396543802 : Closed e606396543802 ∧ code e606396543802 = 9402489566010 := by decide
theorem cert_e606396543802 : check e606396543802 [[.under]] .sourceHead = true := by decide
def e606396543886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e606396543886 : Closed e606396543886 ∧ code e606396543886 = 9402489566094 := by decide
theorem cert_e606396543886 : check e606396543886 [[.under]] .sourceHead = true := by decide
def e606396543898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606396543898 : Closed e606396543898 ∧ code e606396543898 = 9402489566106 := by decide
theorem cert_e606396543898 : check e606396543898 [[.under]] .sourceHead = true := by decide
def e606396634798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e606396634798 : Closed e606396634798 ∧ code e606396634798 = 9402489657006 := by decide
theorem cert_e606396634798 : check e606396634798 [[.under]] .sourceHead = true := by decide
def e606396634810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e606396634810 : Closed e606396634810 ∧ code e606396634810 = 9402489657018 := by decide
theorem cert_e606396634810 : check e606396634810 [[.under]] .sourceHead = true := by decide
def e606396634858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e606396634858 : Closed e606396634858 ∧ code e606396634858 = 9402489657066 := by decide
theorem cert_e606396634858 : check e606396634858 [[.under]] .sourceHead = true := by decide
def e606396635050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e606396635050 : Closed e606396635050 ∧ code e606396635050 = 9402489657258 := by decide
theorem cert_e606396635050 : check e606396635050 [[.under]] .sourceHead = true := by decide
def e606396635374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e606396635374 : Closed e606396635374 ∧ code e606396635374 = 9402489657582 := by decide
theorem cert_e606396635374 : check e606396635374 [[.under]] .sourceHead = true := by decide
def e606396635382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e606396635382 : Closed e606396635382 ∧ code e606396635382 = 9402489657590 := by decide
theorem cert_e606396635382 : check e606396635382 [[.under]] .sourceHead = true := by decide
def e606396635566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e606396635566 : Closed e606396635566 ∧ code e606396635566 = 9402489657774 := by decide
theorem cert_e606396635566 : check e606396635566 [[.under]] .sourceHead = true := by decide
def e606396635578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e606396635578 : Closed e606396635578 ∧ code e606396635578 = 9402489657786 := by decide
theorem cert_e606396635578 : check e606396635578 [[.under]] .sourceHead = true := by decide
def e606396635626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e606396635626 : Closed e606396635626 ∧ code e606396635626 = 9402489657834 := by decide
theorem cert_e606396635626 : check e606396635626 [[.under]] .sourceHead = true := by decide
def e606396635758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606396635758 : Closed e606396635758 ∧ code e606396635758 = 9402489657966 := by decide
theorem cert_e606396635758 : check e606396635758 [[.under]] .sourceHead = true := by decide
def e606396635770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606396635770 : Closed e606396635770 ∧ code e606396635770 = 9402489657978 := by decide
theorem cert_e606396635770 : check e606396635770 [[.under]] .sourceHead = true := by decide
def e606396635934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))))
theorem wire_e606396635934 : Closed e606396635934 ∧ code e606396635934 = 9402489658142 := by decide
theorem cert_e606396635934 : check e606396635934 [[.under]] .sourceHead = true := by decide
def e606396636046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))))
theorem wire_e606396636046 : Closed e606396636046 ∧ code e606396636046 = 9402489658254 := by decide
theorem cert_e606396636046 : check e606396636046 [[.under]] .sourceHead = true := by decide
def e606396636058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396636058 : Closed e606396636058 ∧ code e606396636058 = 9402489658266 := by decide
theorem cert_e606396636058 : check e606396636058 [[.under]] .sourceHead = true := by decide
def e606396636270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e606396636270 : Closed e606396636270 ∧ code e606396636270 = 9402489658478 := by decide
theorem cert_e606396636270 : check e606396636270 [[.under]] .sourceHead = true := by decide
def e606396636282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e606396636282 : Closed e606396636282 ∧ code e606396636282 = 9402489658490 := by decide
theorem cert_e606396636282 : check e606396636282 [[.under]] .sourceHead = true := by decide
def e606396636446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e606396636446 : Closed e606396636446 ∧ code e606396636446 = 9402489658654 := by decide
theorem cert_e606396636446 : check e606396636446 [[.under]] .sourceHead = true := by decide
def e606396636614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e606396636614 : Closed e606396636614 ∧ code e606396636614 = 9402489658822 := by decide
theorem cert_e606396636614 : check e606396636614 [[.under]] .sourceHead = true := by decide
def e606396636726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e606396636726 : Closed e606396636726 ∧ code e606396636726 = 9402489658934 := by decide
theorem cert_e606396636726 : check e606396636726 [[.under]] .sourceHead = true := by decide
def e606396636730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e606396636730 : Closed e606396636730 ∧ code e606396636730 = 9402489658938 := by decide
theorem cert_e606396636730 : check e606396636730 [[.under]] .sourceHead = true := by decide
def e606396636778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e606396636778 : Closed e606396636778 ∧ code e606396636778 = 9402489658986 := by decide
theorem cert_e606396636778 : check e606396636778 [[.under]] .sourceHead = true := by decide
def e606396636814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e606396636814 : Closed e606396636814 ∧ code e606396636814 = 9402489659022 := by decide
theorem cert_e606396636814 : check e606396636814 [[.under]] .sourceHead = true := by decide
def e606396636826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396636826 : Closed e606396636826 ∧ code e606396636826 = 9402489659034 := by decide
theorem cert_e606396636826 : check e606396636826 [[.under]] .sourceHead = true := by decide
def e606396636870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e606396636870 : Closed e606396636870 ∧ code e606396636870 = 9402489659078 := by decide
theorem cert_e606396636870 : check e606396636870 [[.under]] .sourceHead = true := by decide
def e606396637662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e606396637662 : Closed e606396637662 ∧ code e606396637662 = 9402489659870 := by decide
theorem cert_e606396637662 : check e606396637662 [[.under]] .sourceHead = true := by decide
def e606396637686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e606396637686 : Closed e606396637686 ∧ code e606396637686 = 9402489659894 := by decide
theorem cert_e606396637686 : check e606396637686 [[.under]] .sourceHead = true := by decide
def e606396638638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e606396638638 : Closed e606396638638 ∧ code e606396638638 = 9402489660846 := by decide
theorem cert_e606396638638 : check e606396638638 [[.under]] .sourceHead = true := by decide
def e606396638650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e606396638650 : Closed e606396638650 ∧ code e606396638650 = 9402489660858 := by decide
theorem cert_e606396638650 : check e606396638650 [[.under]] .sourceHead = true := by decide
def e606396638698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e606396638698 : Closed e606396638698 ∧ code e606396638698 = 9402489660906 := by decide
theorem cert_e606396638698 : check e606396638698 [[.under]] .sourceHead = true := by decide
def e606396638830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606396638830 : Closed e606396638830 ∧ code e606396638830 = 9402489661038 := by decide
theorem cert_e606396638830 : check e606396638830 [[.under]] .sourceHead = true := by decide
def e606396638842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606396638842 : Closed e606396638842 ∧ code e606396638842 = 9402489661050 := by decide
theorem cert_e606396638842 : check e606396638842 [[.under]] .sourceHead = true := by decide
def e606396639006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e606396639006 : Closed e606396639006 ∧ code e606396639006 = 9402489661214 := by decide
theorem cert_e606396639006 : check e606396639006 [[.under]] .sourceHead = true := by decide
def e606396639118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e606396639118 : Closed e606396639118 ∧ code e606396639118 = 9402489661326 := by decide
theorem cert_e606396639118 : check e606396639118 [[.under]] .sourceHead = true := by decide
def e606396639130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606396639130 : Closed e606396639130 ∧ code e606396639130 = 9402489661338 := by decide
theorem cert_e606396639130 : check e606396639130 [[.under]] .sourceHead = true := by decide
def e606396642078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e606396642078 : Closed e606396642078 ∧ code e606396642078 = 9402489664286 := by decide
theorem cert_e606396642078 : check e606396642078 [[.under]] .sourceHead = true := by decide
def e606396642246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e606396642246 : Closed e606396642246 ∧ code e606396642246 = 9402489664454 := by decide
theorem cert_e606396642246 : check e606396642246 [[.under]] .sourceHead = true := by decide
def e606396643446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e606396643446 : Closed e606396643446 ∧ code e606396643446 = 9402489665654 := by decide
theorem cert_e606396643446 : check e606396643446 [[.under]] .sourceHead = true := by decide
def e606396643690 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e606396643690 : Closed e606396643690 ∧ code e606396643690 = 9402489665898 := by decide
theorem cert_e606396643690 : check e606396643690 [[.under]] .sourceHead = true := by decide
def e606396643726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e606396643726 : Closed e606396643726 ∧ code e606396643726 = 9402489665934 := by decide
theorem cert_e606396643726 : check e606396643726 [[.under]] .sourceHead = true := by decide
def e606396643738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606396643738 : Closed e606396643738 ∧ code e606396643738 = 9402489665946 := by decide
theorem cert_e606396643738 : check e606396643738 [[.under]] .sourceHead = true := by decide
def e606396643782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e606396643782 : Closed e606396643782 ∧ code e606396643782 = 9402489665990 := by decide
theorem cert_e606396643782 : check e606396643782 [[.under]] .sourceHead = true := by decide
def e606396689238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e606396689238 : Closed e606396689238 ∧ code e606396689238 = 9402489711446 := by decide
theorem cert_e606396689238 : check e606396689238 [[.under]] .sourceHead = true := by decide
def e606396689242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e606396689242 : Closed e606396689242 ∧ code e606396689242 = 9402489711450 := by decide
theorem cert_e606396689242 : check e606396689242 [[.under]] .sourceHead = true := by decide
def e606396689258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e606396689258 : Closed e606396689258 ∧ code e606396689258 = 9402489711466 := by decide
theorem cert_e606396689258 : check e606396689258 [[.under]] .sourceHead = true := by decide
def e606396689322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e606396689322 : Closed e606396689322 ∧ code e606396689322 = 9402489711530 := by decide
theorem cert_e606396689322 : check e606396689322 [[.under]] .sourceHead = true := by decide
def e606396689526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e606396689526 : Closed e606396689526 ∧ code e606396689526 = 9402489711734 := by decide
theorem cert_e606396689526 : check e606396689526 [[.under]] .sourceHead = true := by decide
def e606396689622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e606396689622 : Closed e606396689622 ∧ code e606396689622 = 9402489711830 := by decide
theorem cert_e606396689622 : check e606396689622 [[.under]] .sourceHead = true := by decide
def e606396689626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e606396689626 : Closed e606396689626 ∧ code e606396689626 = 9402489711834 := by decide
theorem cert_e606396689626 : check e606396689626 [[.under]] .sourceHead = true := by decide
def e606396689642 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e606396689642 : Closed e606396689642 ∧ code e606396689642 = 9402489711850 := by decide
theorem cert_e606396689642 : check e606396689642 [[.under]] .sourceHead = true := by decide
def e606396689718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606396689718 : Closed e606396689718 ∧ code e606396689718 = 9402489711926 := by decide
theorem cert_e606396689718 : check e606396689718 [[.under]] .sourceHead = true := by decide
def e606396689722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606396689722 : Closed e606396689722 ∧ code e606396689722 = 9402489711930 := by decide
theorem cert_e606396689722 : check e606396689722 [[.under]] .sourceHead = true := by decide
def e606396689806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e606396689806 : Closed e606396689806 ∧ code e606396689806 = 9402489712014 := by decide
theorem cert_e606396689806 : check e606396689806 [[.under]] .sourceHead = true := by decide
def e606396689818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396689818 : Closed e606396689818 ∧ code e606396689818 = 9402489712026 := by decide
theorem cert_e606396689818 : check e606396689818 [[.under]] .sourceHead = true := by decide
def e606396689974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e606396689974 : Closed e606396689974 ∧ code e606396689974 = 9402489712182 := by decide
theorem cert_e606396689974 : check e606396689974 [[.under]] .sourceHead = true := by decide
def e606396689978 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e606396689978 : Closed e606396689978 ∧ code e606396689978 = 9402489712186 := by decide
theorem cert_e606396689978 : check e606396689978 [[.under]] .sourceHead = true := by decide
def e606396690026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e606396690026 : Closed e606396690026 ∧ code e606396690026 = 9402489712234 := by decide
theorem cert_e606396690026 : check e606396690026 [[.under]] .sourceHead = true := by decide
def e606396690062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e606396690062 : Closed e606396690062 ∧ code e606396690062 = 9402489712270 := by decide
theorem cert_e606396690062 : check e606396690062 [[.under]] .sourceHead = true := by decide
def e606396690074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396690074 : Closed e606396690074 ∧ code e606396690074 = 9402489712282 := by decide
theorem cert_e606396690074 : check e606396690074 [[.under]] .sourceHead = true := by decide
def e606396690118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e606396690118 : Closed e606396690118 ∧ code e606396690118 = 9402489712326 := by decide
theorem cert_e606396690118 : check e606396690118 [[.under]] .sourceHead = true := by decide
def e606396690670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e606396690670 : Closed e606396690670 ∧ code e606396690670 = 9402489712878 := by decide
theorem cert_e606396690670 : check e606396690670 [[.under]] .sourceHead = true := by decide
def e606396690678 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e606396690678 : Closed e606396690678 ∧ code e606396690678 = 9402489712886 := by decide
theorem cert_e606396690678 : check e606396690678 [[.under]] .sourceHead = true := by decide
def e606396691158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e606396691158 : Closed e606396691158 ∧ code e606396691158 = 9402489713366 := by decide
theorem cert_e606396691158 : check e606396691158 [[.under]] .sourceHead = true := by decide
def e606396691162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e606396691162 : Closed e606396691162 ∧ code e606396691162 = 9402489713370 := by decide
theorem cert_e606396691162 : check e606396691162 [[.under]] .sourceHead = true := by decide
def e606396691178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e606396691178 : Closed e606396691178 ∧ code e606396691178 = 9402489713386 := by decide
theorem cert_e606396691178 : check e606396691178 [[.under]] .sourceHead = true := by decide
def e606396691254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606396691254 : Closed e606396691254 ∧ code e606396691254 = 9402489713462 := by decide
theorem cert_e606396691254 : check e606396691254 [[.under]] .sourceHead = true := by decide
def e606396691258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606396691258 : Closed e606396691258 ∧ code e606396691258 = 9402489713466 := by decide
theorem cert_e606396691258 : check e606396691258 [[.under]] .sourceHead = true := by decide
def e606396691342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e606396691342 : Closed e606396691342 ∧ code e606396691342 = 9402489713550 := by decide
theorem cert_e606396691342 : check e606396691342 [[.under]] .sourceHead = true := by decide
def e606396691354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606396691354 : Closed e606396691354 ∧ code e606396691354 = 9402489713562 := by decide
theorem cert_e606396691354 : check e606396691354 [[.under]] .sourceHead = true := by decide
def e606396692598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e606396692598 : Closed e606396692598 ∧ code e606396692598 = 9402489714806 := by decide
theorem cert_e606396692598 : check e606396692598 [[.under]] .sourceHead = true := by decide
def e606396692842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e606396692842 : Closed e606396692842 ∧ code e606396692842 = 9402489715050 := by decide
theorem cert_e606396692842 : check e606396692842 [[.under]] .sourceHead = true := by decide
def e606396692878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e606396692878 : Closed e606396692878 ∧ code e606396692878 = 9402489715086 := by decide
theorem cert_e606396692878 : check e606396692878 [[.under]] .sourceHead = true := by decide
def e606396692890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606396692890 : Closed e606396692890 ∧ code e606396692890 = 9402489715098 := by decide
theorem cert_e606396692890 : check e606396692890 [[.under]] .sourceHead = true := by decide
def e606396692934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e606396692934 : Closed e606396692934 ∧ code e606396692934 = 9402489715142 := by decide
theorem cert_e606396692934 : check e606396692934 [[.under]] .sourceHead = true := by decide
def e606398590394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))))
theorem wire_e606398590394 : Closed e606398590394 ∧ code e606398590394 = 9402491612602 := by decide
theorem cert_e606398590394 : check e606398590394 [[.under]] .sourceHead = true := by decide
def e606398590426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))))
theorem wire_e606398590426 : Closed e606398590426 ∧ code e606398590426 = 9402491612634 := by decide
theorem cert_e606398590426 : check e606398590426 [[.under]] .sourceHead = true := by decide
def e606398590650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))))))
theorem wire_e606398590650 : Closed e606398590650 ∧ code e606398590650 = 9402491612858 := by decide
theorem cert_e606398590650 : check e606398590650 [[.under]] .sourceHead = true := by decide
def e606398590698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))))))
theorem wire_e606398590698 : Closed e606398590698 ∧ code e606398590698 = 9402491612906 := by decide
theorem cert_e606398590698 : check e606398590698 [[.under]] .sourceHead = true := by decide
def e606398590810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))))))
theorem wire_e606398590810 : Closed e606398590810 ∧ code e606398590810 = 9402491613018 := by decide
theorem cert_e606398590810 : check e606398590810 [[.under]] .sourceHead = true := by decide
def e606398590826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))))))
theorem wire_e606398590826 : Closed e606398590826 ∧ code e606398590826 = 9402491613034 := by decide
theorem cert_e606398590826 : check e606398590826 [[.under]] .sourceHead = true := by decide
def e606398591930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))))))
theorem wire_e606398591930 : Closed e606398591930 ∧ code e606398591930 = 9402491614138 := by decide
theorem cert_e606398591930 : check e606398591930 [[.under]] .sourceHead = true := by decide
def e606398591962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))))))
theorem wire_e606398591962 : Closed e606398591962 ∧ code e606398591962 = 9402491614170 := by decide
theorem cert_e606398591962 : check e606398591962 [[.under]] .sourceHead = true := by decide
def e606398593466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e606398593466 : Closed e606398593466 ∧ code e606398593466 = 9402491615674 := by decide
theorem cert_e606398593466 : check e606398593466 [[.under]] .sourceHead = true := by decide
def e606398593514 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e606398593514 : Closed e606398593514 ∧ code e606398593514 = 9402491615722 := by decide
theorem cert_e606398593514 : check e606398593514 [[.under]] .sourceHead = true := by decide
def e606398594266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e606398594266 : Closed e606398594266 ∧ code e606398594266 = 9402491616474 := by decide
theorem cert_e606398594266 : check e606398594266 [[.under]] .sourceHead = true := by decide
def e606398594282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e606398594282 : Closed e606398594282 ∧ code e606398594282 = 9402491616490 := by decide
theorem cert_e606398594282 : check e606398594282 [[.under]] .sourceHead = true := by decide
def e606398647150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e606398647150 : Closed e606398647150 ∧ code e606398647150 = 9402491669358 := by decide
theorem cert_e606398647150 : check e606398647150 [[.under]] .sourceHead = true := by decide
def e606398647158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e606398647158 : Closed e606398647158 ∧ code e606398647158 = 9402491669366 := by decide
theorem cert_e606398647158 : check e606398647158 [[.under]] .sourceHead = true := by decide
def e606398647214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e606398647214 : Closed e606398647214 ∧ code e606398647214 = 9402491669422 := by decide
theorem cert_e606398647214 : check e606398647214 [[.under]] .sourceHead = true := by decide
def e606398647226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e606398647226 : Closed e606398647226 ∧ code e606398647226 = 9402491669434 := by decide
theorem cert_e606398647226 : check e606398647226 [[.under]] .sourceHead = true := by decide
def e606398647254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e606398647254 : Closed e606398647254 ∧ code e606398647254 = 9402491669462 := by decide
theorem cert_e606398647254 : check e606398647254 [[.under]] .sourceHead = true := by decide
def e606398647258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e606398647258 : Closed e606398647258 ∧ code e606398647258 = 9402491669466 := by decide
theorem cert_e606398647258 : check e606398647258 [[.under]] .sourceHead = true := by decide
def e606398647534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e606398647534 : Closed e606398647534 ∧ code e606398647534 = 9402491669742 := by decide
theorem cert_e606398647534 : check e606398647534 [[.under]] .sourceHead = true := by decide
def e606398647542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e606398647542 : Closed e606398647542 ∧ code e606398647542 = 9402491669750 := by decide
theorem cert_e606398647542 : check e606398647542 [[.under]] .sourceHead = true := by decide
def e606398647918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e606398647918 : Closed e606398647918 ∧ code e606398647918 = 9402491670126 := by decide
theorem cert_e606398647918 : check e606398647918 [[.under]] .sourceHead = true := by decide
def e606398647930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e606398647930 : Closed e606398647930 ∧ code e606398647930 = 9402491670138 := by decide
theorem cert_e606398647930 : check e606398647930 [[.under]] .sourceHead = true := by decide
def e606398648118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e606398648118 : Closed e606398648118 ∧ code e606398648118 = 9402491670326 := by decide
theorem cert_e606398648118 : check e606398648118 [[.under]] .sourceHead = true := by decide
def e606398648122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e606398648122 : Closed e606398648122 ∧ code e606398648122 = 9402491670330 := by decide
theorem cert_e606398648122 : check e606398648122 [[.under]] .sourceHead = true := by decide
def e606398852574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e606398852574 : Closed e606398852574 ∧ code e606398852574 = 9402491874782 := by decide
theorem cert_e606398852574 : check e606398852574 [[.under]] .sourceHead = true := by decide
def e606398852590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e606398852590 : Closed e606398852590 ∧ code e606398852590 = 9402491874798 := by decide
theorem cert_e606398852590 : check e606398852590 [[.under]] .sourceHead = true := by decide
def e606398852958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e606398852958 : Closed e606398852958 ∧ code e606398852958 = 9402491875166 := by decide
theorem cert_e606398852958 : check e606398852958 [[.under]] .sourceHead = true := by decide
def e606398852986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e606398852986 : Closed e606398852986 ∧ code e606398852986 = 9402491875194 := by decide
theorem cert_e606398852986 : check e606398852986 [[.under]] .sourceHead = true := by decide
def e606398853038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e606398853038 : Closed e606398853038 ∧ code e606398853038 = 9402491875246 := by decide
theorem cert_e606398853038 : check e606398853038 [[.under]] .sourceHead = true := by decide
def e606398853050 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e606398853050 : Closed e606398853050 ∧ code e606398853050 = 9402491875258 := by decide
theorem cert_e606398853050 : check e606398853050 [[.under]] .sourceHead = true := by decide
def e606398854110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e606398854110 : Closed e606398854110 ∧ code e606398854110 = 9402491876318 := by decide
theorem cert_e606398854110 : check e606398854110 [[.under]] .sourceHead = true := by decide
def e606398854126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e606398854126 : Closed e606398854126 ∧ code e606398854126 = 9402491876334 := by decide
theorem cert_e606398854126 : check e606398854126 [[.under]] .sourceHead = true := by decide
def e606398856414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e606398856414 : Closed e606398856414 ∧ code e606398856414 = 9402491878622 := by decide
theorem cert_e606398856414 : check e606398856414 [[.under]] .sourceHead = true := by decide
def e606398856442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e606398856442 : Closed e606398856442 ∧ code e606398856442 = 9402491878650 := by decide
theorem cert_e606398856442 : check e606398856442 [[.under]] .sourceHead = true := by decide
def e606398856814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606398856814 : Closed e606398856814 ∧ code e606398856814 = 9402491879022 := by decide
theorem cert_e606398856814 : check e606398856814 [[.under]] .sourceHead = true := by decide
def e606398856826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606398856826 : Closed e606398856826 ∧ code e606398856826 = 9402491879034 := by decide
theorem cert_e606398856826 : check e606398856826 [[.under]] .sourceHead = true := by decide
def e606398885230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e606398885230 : Closed e606398885230 ∧ code e606398885230 = 9402491907438 := by decide
theorem cert_e606398885230 : check e606398885230 [[.under]] .sourceHead = true := by decide
def e606398885238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e606398885238 : Closed e606398885238 ∧ code e606398885238 = 9402491907446 := by decide
theorem cert_e606398885238 : check e606398885238 [[.under]] .sourceHead = true := by decide
def e606398885294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e606398885294 : Closed e606398885294 ∧ code e606398885294 = 9402491907502 := by decide
theorem cert_e606398885294 : check e606398885294 [[.under]] .sourceHead = true := by decide
def e606398885306 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e606398885306 : Closed e606398885306 ∧ code e606398885306 = 9402491907514 := by decide
theorem cert_e606398885306 : check e606398885306 [[.under]] .sourceHead = true := by decide
def e606398885334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e606398885334 : Closed e606398885334 ∧ code e606398885334 = 9402491907542 := by decide
theorem cert_e606398885334 : check e606398885334 [[.under]] .sourceHead = true := by decide
def e606398885338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e606398885338 : Closed e606398885338 ∧ code e606398885338 = 9402491907546 := by decide
theorem cert_e606398885338 : check e606398885338 [[.under]] .sourceHead = true := by decide
def e606398885550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e606398885550 : Closed e606398885550 ∧ code e606398885550 = 9402491907758 := by decide
theorem cert_e606398885550 : check e606398885550 [[.under]] .sourceHead = true := by decide
def e606398885562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e606398885562 : Closed e606398885562 ∧ code e606398885562 = 9402491907770 := by decide
theorem cert_e606398885562 : check e606398885562 [[.under]] .sourceHead = true := by decide
def e606398885610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e606398885610 : Closed e606398885610 ∧ code e606398885610 = 9402491907818 := by decide
theorem cert_e606398885610 : check e606398885610 [[.under]] .sourceHead = true := by decide
def e606398885718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e606398885718 : Closed e606398885718 ∧ code e606398885718 = 9402491907926 := by decide
theorem cert_e606398885718 : check e606398885718 [[.under]] .sourceHead = true := by decide
def e606398885722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e606398885722 : Closed e606398885722 ∧ code e606398885722 = 9402491907930 := by decide
theorem cert_e606398885722 : check e606398885722 [[.under]] .sourceHead = true := by decide
def e606398885738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e606398885738 : Closed e606398885738 ∧ code e606398885738 = 9402491907946 := by decide
theorem cert_e606398885738 : check e606398885738 [[.under]] .sourceHead = true := by decide
def e606398886766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e606398886766 : Closed e606398886766 ∧ code e606398886766 = 9402491908974 := by decide
theorem cert_e606398886766 : check e606398886766 [[.under]] .sourceHead = true := by decide
def e606398886774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e606398886774 : Closed e606398886774 ∧ code e606398886774 = 9402491908982 := by decide
theorem cert_e606398886774 : check e606398886774 [[.under]] .sourceHead = true := by decide
def e606398886830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e606398886830 : Closed e606398886830 ∧ code e606398886830 = 9402491909038 := by decide
theorem cert_e606398886830 : check e606398886830 [[.under]] .sourceHead = true := by decide
def e606398886842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e606398886842 : Closed e606398886842 ∧ code e606398886842 = 9402491909050 := by decide
theorem cert_e606398886842 : check e606398886842 [[.under]] .sourceHead = true := by decide
def e606398886870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e606398886870 : Closed e606398886870 ∧ code e606398886870 = 9402491909078 := by decide
theorem cert_e606398886870 : check e606398886870 [[.under]] .sourceHead = true := by decide
def e606398886874 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e606398886874 : Closed e606398886874 ∧ code e606398886874 = 9402491909082 := by decide
theorem cert_e606398886874 : check e606398886874 [[.under]] .sourceHead = true := by decide
def e606398887150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e606398887150 : Closed e606398887150 ∧ code e606398887150 = 9402491909358 := by decide
theorem cert_e606398887150 : check e606398887150 [[.under]] .sourceHead = true := by decide
def e606398887158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e606398887158 : Closed e606398887158 ∧ code e606398887158 = 9402491909366 := by decide
theorem cert_e606398887158 : check e606398887158 [[.under]] .sourceHead = true := by decide
def e606398887534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606398887534 : Closed e606398887534 ∧ code e606398887534 = 9402491909742 := by decide
theorem cert_e606398887534 : check e606398887534 [[.under]] .sourceHead = true := by decide
def e606398887546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606398887546 : Closed e606398887546 ∧ code e606398887546 = 9402491909754 := by decide
theorem cert_e606398887546 : check e606398887546 [[.under]] .sourceHead = true := by decide
def e606398887734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606398887734 : Closed e606398887734 ∧ code e606398887734 = 9402491909942 := by decide
theorem cert_e606398887734 : check e606398887734 [[.under]] .sourceHead = true := by decide
def e606398887738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606398887738 : Closed e606398887738 ∧ code e606398887738 = 9402491909946 := by decide
theorem cert_e606398887738 : check e606398887738 [[.under]] .sourceHead = true := by decide
def e606398888366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e606398888366 : Closed e606398888366 ∧ code e606398888366 = 9402491910574 := by decide
theorem cert_e606398888366 : check e606398888366 [[.under]] .sourceHead = true := by decide
def e606398888378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e606398888378 : Closed e606398888378 ∧ code e606398888378 = 9402491910586 := by decide
theorem cert_e606398888378 : check e606398888378 [[.under]] .sourceHead = true := by decide
def e606398888426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e606398888426 : Closed e606398888426 ∧ code e606398888426 = 9402491910634 := by decide
theorem cert_e606398888426 : check e606398888426 [[.under]] .sourceHead = true := by decide
def e606398888558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606398888558 : Closed e606398888558 ∧ code e606398888558 = 9402491910766 := by decide
theorem cert_e606398888558 : check e606398888558 [[.under]] .sourceHead = true := by decide
def e606398888570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606398888570 : Closed e606398888570 ∧ code e606398888570 = 9402491910778 := by decide
theorem cert_e606398888570 : check e606398888570 [[.under]] .sourceHead = true := by decide
def e606398888858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606398888858 : Closed e606398888858 ∧ code e606398888858 = 9402491911066 := by decide
theorem cert_e606398888858 : check e606398888858 [[.under]] .sourceHead = true := by decide
def e606398889174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e606398889174 : Closed e606398889174 ∧ code e606398889174 = 9402491911382 := by decide
theorem cert_e606398889174 : check e606398889174 [[.under]] .sourceHead = true := by decide
def e606398889178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e606398889178 : Closed e606398889178 ∧ code e606398889178 = 9402491911386 := by decide
theorem cert_e606398889178 : check e606398889178 [[.under]] .sourceHead = true := by decide
def e606398889194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e606398889194 : Closed e606398889194 ∧ code e606398889194 = 9402491911402 := by decide
theorem cert_e606398889194 : check e606398889194 [[.under]] .sourceHead = true := by decide
def e606398889270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606398889270 : Closed e606398889270 ∧ code e606398889270 = 9402491911478 := by decide
theorem cert_e606398889270 : check e606398889270 [[.under]] .sourceHead = true := by decide
def e606398889274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606398889274 : Closed e606398889274 ∧ code e606398889274 = 9402491911482 := by decide
theorem cert_e606398889274 : check e606398889274 [[.under]] .sourceHead = true := by decide
def e606398889370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606398889370 : Closed e606398889370 ∧ code e606398889370 = 9402491911578 := by decide
theorem cert_e606398889370 : check e606398889370 [[.under]] .sourceHead = true := by decide
def e606398890974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e606398890974 : Closed e606398890974 ∧ code e606398890974 = 9402491913182 := by decide
theorem cert_e606398890974 : check e606398890974 [[.under]] .sourceHead = true := by decide
def e606398890990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e606398890990 : Closed e606398890990 ∧ code e606398890990 = 9402491913198 := by decide
theorem cert_e606398890990 : check e606398890990 [[.under]] .sourceHead = true := by decide
def e606398892910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606398892910 : Closed e606398892910 ∧ code e606398892910 = 9402491915118 := by decide
theorem cert_e606398892910 : check e606398892910 [[.under]] .sourceHead = true := by decide
def e606398892918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606398892918 : Closed e606398892918 ∧ code e606398892918 = 9402491915126 := by decide
theorem cert_e606398892918 : check e606398892918 [[.under]] .sourceHead = true := by decide
def e606398892974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606398892974 : Closed e606398892974 ∧ code e606398892974 = 9402491915182 := by decide
theorem cert_e606398892974 : check e606398892974 [[.under]] .sourceHead = true := by decide
def e606398892986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606398892986 : Closed e606398892986 ∧ code e606398892986 = 9402491915194 := by decide
theorem cert_e606398892986 : check e606398892986 [[.under]] .sourceHead = true := by decide
def e606398893014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606398893014 : Closed e606398893014 ∧ code e606398893014 = 9402491915222 := by decide
theorem cert_e606398893014 : check e606398893014 [[.under]] .sourceHead = true := by decide
def e606398893018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606398893018 : Closed e606398893018 ∧ code e606398893018 = 9402491915226 := by decide
theorem cert_e606398893018 : check e606398893018 [[.under]] .sourceHead = true := by decide
def e606398893294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606398893294 : Closed e606398893294 ∧ code e606398893294 = 9402491915502 := by decide
theorem cert_e606398893294 : check e606398893294 [[.under]] .sourceHead = true := by decide
def e606398893302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606398893302 : Closed e606398893302 ∧ code e606398893302 = 9402491915510 := by decide
theorem cert_e606398893302 : check e606398893302 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
