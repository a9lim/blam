import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388438120046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388438120046 : Closed e2388438120046 ∧ code e2388438120046 = 11184531142254 := by decide
theorem cert_e2388438120046 : check e2388438120046 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388438120058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388438120058 : Closed e2388438120058 ∧ code e2388438120058 = 11184531142266 := by decide
theorem cert_e2388438120058 : check e2388438120058 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388438120246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388438120246 : Closed e2388438120246 ∧ code e2388438120246 = 11184531142454 := by decide
theorem cert_e2388438120246 : check e2388438120246 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2388438120250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388438120250 : Closed e2388438120250 ∧ code e2388438120250 = 11184531142458 := by decide
theorem cert_e2388438120250 : check e2388438120250 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2388438120886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2388438120886 : Closed e2388438120886 ∧ code e2388438120886 = 11184531143094 := by decide
theorem cert_e2388438120886 : check e2388438120886 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388438120918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2388438120918 : Closed e2388438120918 ∧ code e2388438120918 = 11184531143126 := by decide
theorem cert_e2388438120918 : check e2388438120918 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388438120922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2388438120922 : Closed e2388438120922 ∧ code e2388438120922 = 11184531143130 := by decide
theorem cert_e2388438120922 : check e2388438120922 [[],[.left],[],[.under,.left],[.under],[.under]] .three = true := by decide
def e2388438121078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2388438121078 : Closed e2388438121078 ∧ code e2388438121078 = 11184531143286 := by decide
theorem cert_e2388438121078 : check e2388438121078 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388438121270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388438121270 : Closed e2388438121270 ∧ code e2388438121270 = 11184531143478 := by decide
theorem cert_e2388438121270 : check e2388438121270 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388438121274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388438121274 : Closed e2388438121274 ∧ code e2388438121274 = 11184531143482 := by decide
theorem cert_e2388438121274 : check e2388438121274 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388438128494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2388438128494 : Closed e2388438128494 ∧ code e2388438128494 = 11184531150702 := by decide
theorem cert_e2388438128494 : check e2388438128494 [[],[.left],[]] .sourceHead = true := by decide
def e2388438128502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2388438128502 : Closed e2388438128502 ∧ code e2388438128502 = 11184531150710 := by decide
theorem cert_e2388438128502 : check e2388438128502 [[],[.left],[]] .sourceHead = true := by decide
def e2388438128566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2388438128566 : Closed e2388438128566 ∧ code e2388438128566 = 11184531150774 := by decide
theorem cert_e2388438128566 : check e2388438128566 [[],[.left],[]] .sourceHead = true := by decide
def e2388438129902 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2388438129902 : Closed e2388438129902 ∧ code e2388438129902 = 11184531152110 := by decide
theorem cert_e2388438129902 : check e2388438129902 [[],[.left],[]] .sourceHead = true := by decide
def e2388438129910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2388438129910 : Closed e2388438129910 ∧ code e2388438129910 = 11184531152118 := by decide
theorem cert_e2388438129910 : check e2388438129910 [[],[.left],[]] .sourceHead = true := by decide
def e2388438130294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2388438130294 : Closed e2388438130294 ∧ code e2388438130294 = 11184531152502 := by decide
theorem cert_e2388438130294 : check e2388438130294 [[],[.left],[]] .sourceHead = true := by decide
def e2388438141806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388438141806 : Closed e2388438141806 ∧ code e2388438141806 = 11184531164014 := by decide
theorem cert_e2388438141806 : check e2388438141806 [[],[.left],[],[.under]] .three = true := by decide
def e2388438141814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388438141814 : Closed e2388438141814 ∧ code e2388438141814 = 11184531164022 := by decide
theorem cert_e2388438141814 : check e2388438141814 [[],[.left],[],[.under]] .three = true := by decide
def e2388438141870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388438141870 : Closed e2388438141870 ∧ code e2388438141870 = 11184531164078 := by decide
theorem cert_e2388438141870 : check e2388438141870 [[],[.left],[],[.under]] .three = true := by decide
def e2388438141882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388438141882 : Closed e2388438141882 ∧ code e2388438141882 = 11184531164090 := by decide
theorem cert_e2388438141882 : check e2388438141882 [[],[.left],[],[.under]] .three = true := by decide
def e2388438141910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388438141910 : Closed e2388438141910 ∧ code e2388438141910 = 11184531164118 := by decide
theorem cert_e2388438141910 : check e2388438141910 [[],[.left],[],[.under]] .three = true := by decide
def e2388438141914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388438141914 : Closed e2388438141914 ∧ code e2388438141914 = 11184531164122 := by decide
theorem cert_e2388438141914 : check e2388438141914 [[],[.left],[],[.under]] .three = true := by decide
def e2388438142190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388438142190 : Closed e2388438142190 ∧ code e2388438142190 = 11184531164398 := by decide
theorem cert_e2388438142190 : check e2388438142190 [[],[.left],[],[.under]] .three = true := by decide
def e2388438142198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388438142198 : Closed e2388438142198 ∧ code e2388438142198 = 11184531164406 := by decide
theorem cert_e2388438142198 : check e2388438142198 [[],[.left],[],[.under]] .three = true := by decide
def e2388438142574 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388438142574 : Closed e2388438142574 ∧ code e2388438142574 = 11184531164782 := by decide
theorem cert_e2388438142574 : check e2388438142574 [[],[.left],[],[.under]] .three = true := by decide
def e2388438142586 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388438142586 : Closed e2388438142586 ∧ code e2388438142586 = 11184531164794 := by decide
theorem cert_e2388438142586 : check e2388438142586 [[],[.left],[],[.under]] .three = true := by decide
def e2388438142774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388438142774 : Closed e2388438142774 ∧ code e2388438142774 = 11184531164982 := by decide
theorem cert_e2388438142774 : check e2388438142774 [[],[.left],[],[.under]] .three = true := by decide
def e2388438142778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388438142778 : Closed e2388438142778 ∧ code e2388438142778 = 11184531164986 := by decide
theorem cert_e2388438142778 : check e2388438142778 [[],[.left],[],[.under]] .three = true := by decide
def e2388438148534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2388438148534 : Closed e2388438148534 ∧ code e2388438148534 = 11184531170742 := by decide
theorem cert_e2388438148534 : checkPay e2388438148534 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e2388438148566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2388438148566 : Closed e2388438148566 ∧ code e2388438148566 = 11184531170774 := by decide
theorem cert_e2388438148566 : check e2388438148566 [[],[.left],[],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2388438148570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2388438148570 : Closed e2388438148570 ∧ code e2388438148570 = 11184531170778 := by decide
theorem cert_e2388438148570 : check e2388438148570 [[],[.left],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e2388438148726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2388438148726 : Closed e2388438148726 ∧ code e2388438148726 = 11184531170934 := by decide
theorem cert_e2388438148726 : check e2388438148726 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2388438148918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2388438148918 : Closed e2388438148918 ∧ code e2388438148918 = 11184531171126 := by decide
theorem cert_e2388438148918 : check e2388438148918 [[],[.left],[],[.under],[.under,.under]] .three = true := by decide
def e2388438148922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2388438148922 : Closed e2388438148922 ∧ code e2388438148922 = 11184531171130 := by decide
theorem cert_e2388438148922 : check e2388438148922 [[],[.left],[],[.under],[.under,.under]] .three = true := by decide
def e2388438485870 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388438485870 : Closed e2388438485870 ∧ code e2388438485870 = 11184531508078 := by decide
theorem cert_e2388438485870 : check e2388438485870 [[],[.left]] .chain = true := by decide
def e2388438485878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388438485878 : Closed e2388438485878 ∧ code e2388438485878 = 11184531508086 := by decide
theorem cert_e2388438485878 : check e2388438485878 [[],[.left]] .chain = true := by decide
def e2388438485934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388438485934 : Closed e2388438485934 ∧ code e2388438485934 = 11184531508142 := by decide
theorem cert_e2388438485934 : check e2388438485934 [[],[.left]] .chain = true := by decide
def e2388438485946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388438485946 : Closed e2388438485946 ∧ code e2388438485946 = 11184531508154 := by decide
theorem cert_e2388438485946 : check e2388438485946 [[],[.left]] .chain = true := by decide
def e2388438485974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388438485974 : Closed e2388438485974 ∧ code e2388438485974 = 11184531508182 := by decide
theorem cert_e2388438485974 : check e2388438485974 [[],[.left]] .chain = true := by decide
def e2388438485978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388438485978 : Closed e2388438485978 ∧ code e2388438485978 = 11184531508186 := by decide
theorem cert_e2388438485978 : check e2388438485978 [[],[.left]] .chain = true := by decide
def e2388438486254 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388438486254 : Closed e2388438486254 ∧ code e2388438486254 = 11184531508462 := by decide
theorem cert_e2388438486254 : check e2388438486254 [[],[.left]] .chain = true := by decide
def e2388438486262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388438486262 : Closed e2388438486262 ∧ code e2388438486262 = 11184531508470 := by decide
theorem cert_e2388438486262 : check e2388438486262 [[],[.left]] .chain = true := by decide
def e2388438486638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388438486638 : Closed e2388438486638 ∧ code e2388438486638 = 11184531508846 := by decide
theorem cert_e2388438486638 : check e2388438486638 [[],[.left]] .chain = true := by decide
def e2388438486650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388438486650 : Closed e2388438486650 ∧ code e2388438486650 = 11184531508858 := by decide
theorem cert_e2388438486650 : check e2388438486650 [[],[.left]] .chain = true := by decide
def e2388438486838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388438486838 : Closed e2388438486838 ∧ code e2388438486838 = 11184531509046 := by decide
theorem cert_e2388438486838 : check e2388438486838 [[],[.left]] .chain = true := by decide
def e2388438486842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388438486842 : Closed e2388438486842 ∧ code e2388438486842 = 11184531509050 := by decide
theorem cert_e2388438486842 : check e2388438486842 [[],[.left]] .chain = true := by decide
def e2388472327706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472327706 : Closed e2388472327706 ∧ code e2388472327706 = 11184565349914 := by decide
theorem cert_e2388472327706 : check e2388472327706 [[]] .width = true := by decide
def e2388472329754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472329754 : Closed e2388472329754 ∧ code e2388472329754 = 11184565351962 := by decide
theorem cert_e2388472329754 : check e2388472329754 [[]] .width = true := by decide
def e2388472344090 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472344090 : Closed e2388472344090 ∧ code e2388472344090 = 11184565366298 := by decide
theorem cert_e2388472344090 : check e2388472344090 [[]] .width = true := by decide
def e2388472347162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472347162 : Closed e2388472347162 ∧ code e2388472347162 = 11184565369370 := by decide
theorem cert_e2388472347162 : check e2388472347162 [[]] .width = true := by decide
def e2388472354330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472354330 : Closed e2388472354330 ∧ code e2388472354330 = 11184565376538 := by decide
theorem cert_e2388472354330 : check e2388472354330 [[]] .width = true := by decide
def e2388472355354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472355354 : Closed e2388472355354 ∧ code e2388472355354 = 11184565377562 := by decide
theorem cert_e2388472355354 : check e2388472355354 [[]] .width = true := by decide
def e2388472426010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472426010 : Closed e2388472426010 ∧ code e2388472426010 = 11184565448218 := by decide
theorem cert_e2388472426010 : check e2388472426010 [[]] .width = true := by decide
def e2388472428058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472428058 : Closed e2388472428058 ∧ code e2388472428058 = 11184565450266 := by decide
theorem cert_e2388472428058 : check e2388472428058 [[]] .width = true := by decide
def e2388472524314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472524314 : Closed e2388472524314 ∧ code e2388472524314 = 11184565546522 := by decide
theorem cert_e2388472524314 : check e2388472524314 [[]] .width = true := by decide
def e2388472527386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472527386 : Closed e2388472527386 ∧ code e2388472527386 = 11184565549594 := by decide
theorem cert_e2388472527386 : check e2388472527386 [[]] .width = true := by decide
def e2388472575514 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472575514 : Closed e2388472575514 ∧ code e2388472575514 = 11184565597722 := by decide
theorem cert_e2388472575514 : check e2388472575514 [[]] .width = true := by decide
def e2388472576538 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388472576538 : Closed e2388472576538 ∧ code e2388472576538 = 11184565598746 := by decide
theorem cert_e2388472576538 : check e2388472576538 [[]] .width = true := by decide
def e2388488400238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2388488400238 : Closed e2388488400238 ∧ code e2388488400238 = 11184581422446 := by decide
theorem cert_e2388488400238 : check e2388488400238 [[],[.left],[]] .sourceHead = true := by decide
def e2388488400246 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2388488400246 : Closed e2388488400246 ∧ code e2388488400246 = 11184581422454 := by decide
theorem cert_e2388488400246 : check e2388488400246 [[],[.left],[]] .sourceHead = true := by decide
def e2388488400302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2388488400302 : Closed e2388488400302 ∧ code e2388488400302 = 11184581422510 := by decide
theorem cert_e2388488400302 : check e2388488400302 [[],[.left],[]] .sourceHead = true := by decide
def e2388488400314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2388488400314 : Closed e2388488400314 ∧ code e2388488400314 = 11184581422522 := by decide
theorem cert_e2388488400314 : check e2388488400314 [[],[.left],[]] .sourceHead = true := by decide
def e2388488400342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2388488400342 : Closed e2388488400342 ∧ code e2388488400342 = 11184581422550 := by decide
theorem cert_e2388488400342 : check e2388488400342 [[],[.left],[]] .sourceHead = true := by decide
def e2388488400346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2388488400346 : Closed e2388488400346 ∧ code e2388488400346 = 11184581422554 := by decide
theorem cert_e2388488400346 : check e2388488400346 [[],[.left],[]] .sourceHead = true := by decide
def e2388488400558 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2388488400558 : Closed e2388488400558 ∧ code e2388488400558 = 11184581422766 := by decide
theorem cert_e2388488400558 : check e2388488400558 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2388488400570 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2388488400570 : Closed e2388488400570 ∧ code e2388488400570 = 11184581422778 := by decide
theorem cert_e2388488400570 : check e2388488400570 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2388488400618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2388488400618 : Closed e2388488400618 ∧ code e2388488400618 = 11184581422826 := by decide
theorem cert_e2388488400618 : check e2388488400618 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2388488400726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2388488400726 : Closed e2388488400726 ∧ code e2388488400726 = 11184581422934 := by decide
theorem cert_e2388488400726 : check e2388488400726 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2388488400730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2388488400730 : Closed e2388488400730 ∧ code e2388488400730 = 11184581422938 := by decide
theorem cert_e2388488400730 : check e2388488400730 [[],[.left],[],[.under,.left,.left],[.under,.left]] .smaller = true := by decide
def e2388488400746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2388488400746 : Closed e2388488400746 ∧ code e2388488400746 = 11184581422954 := by decide
theorem cert_e2388488400746 : check e2388488400746 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2388488401774 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2388488401774 : Closed e2388488401774 ∧ code e2388488401774 = 11184581423982 := by decide
theorem cert_e2388488401774 : check e2388488401774 [[],[.left],[]] .sourceHead = true := by decide
def e2388488401782 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2388488401782 : Closed e2388488401782 ∧ code e2388488401782 = 11184581423990 := by decide
theorem cert_e2388488401782 : check e2388488401782 [[],[.left],[]] .sourceHead = true := by decide
def e2388488401838 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2388488401838 : Closed e2388488401838 ∧ code e2388488401838 = 11184581424046 := by decide
theorem cert_e2388488401838 : check e2388488401838 [[],[.left],[]] .sourceHead = true := by decide
def e2388488401850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2388488401850 : Closed e2388488401850 ∧ code e2388488401850 = 11184581424058 := by decide
theorem cert_e2388488401850 : check e2388488401850 [[],[.left],[]] .sourceHead = true := by decide
def e2388488401878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2388488401878 : Closed e2388488401878 ∧ code e2388488401878 = 11184581424086 := by decide
theorem cert_e2388488401878 : check e2388488401878 [[],[.left],[]] .sourceHead = true := by decide
def e2388488401882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2388488401882 : Closed e2388488401882 ∧ code e2388488401882 = 11184581424090 := by decide
theorem cert_e2388488401882 : check e2388488401882 [[],[.left],[]] .sourceHead = true := by decide
def e2388488402158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2388488402158 : Closed e2388488402158 ∧ code e2388488402158 = 11184581424366 := by decide
theorem cert_e2388488402158 : check e2388488402158 [[],[.left],[]] .sourceHead = true := by decide
def e2388488402166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2388488402166 : Closed e2388488402166 ∧ code e2388488402166 = 11184581424374 := by decide
theorem cert_e2388488402166 : check e2388488402166 [[],[.left],[]] .sourceHead = true := by decide
def e2388488402542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388488402542 : Closed e2388488402542 ∧ code e2388488402542 = 11184581424750 := by decide
theorem cert_e2388488402542 : check e2388488402542 [[],[.left],[]] .sourceHead = true := by decide
def e2388488402554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388488402554 : Closed e2388488402554 ∧ code e2388488402554 = 11184581424762 := by decide
theorem cert_e2388488402554 : check e2388488402554 [[],[.left],[]] .sourceHead = true := by decide
def e2388488402742 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388488402742 : Closed e2388488402742 ∧ code e2388488402742 = 11184581424950 := by decide
theorem cert_e2388488402742 : check e2388488402742 [[],[.left],[]] .sourceHead = true := by decide
def e2388488402746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388488402746 : Closed e2388488402746 ∧ code e2388488402746 = 11184581424954 := by decide
theorem cert_e2388488402746 : check e2388488402746 [[],[.left],[]] .sourceHead = true := by decide
def e2388488403374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2388488403374 : Closed e2388488403374 ∧ code e2388488403374 = 11184581425582 := by decide
theorem cert_e2388488403374 : check e2388488403374 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2388488403386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2388488403386 : Closed e2388488403386 ∧ code e2388488403386 = 11184581425594 := by decide
theorem cert_e2388488403386 : check e2388488403386 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388488403434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2388488403434 : Closed e2388488403434 ∧ code e2388488403434 = 11184581425642 := by decide
theorem cert_e2388488403434 : check e2388488403434 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388488403566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2388488403566 : Closed e2388488403566 ∧ code e2388488403566 = 11184581425774 := by decide
theorem cert_e2388488403566 : check e2388488403566 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2388488403578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2388488403578 : Closed e2388488403578 ∧ code e2388488403578 = 11184581425786 := by decide
theorem cert_e2388488403578 : check e2388488403578 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2388488403866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2388488403866 : Closed e2388488403866 ∧ code e2388488403866 = 11184581426074 := by decide
theorem cert_e2388488403866 : check e2388488403866 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2388488404182 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2388488404182 : Closed e2388488404182 ∧ code e2388488404182 = 11184581426390 := by decide
theorem cert_e2388488404182 : check e2388488404182 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388488404186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2388488404186 : Closed e2388488404186 ∧ code e2388488404186 = 11184581426394 := by decide
theorem cert_e2388488404186 : check e2388488404186 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388488404202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2388488404202 : Closed e2388488404202 ∧ code e2388488404202 = 11184581426410 := by decide
theorem cert_e2388488404202 : check e2388488404202 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388488404278 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2388488404278 : Closed e2388488404278 ∧ code e2388488404278 = 11184581426486 := by decide
theorem cert_e2388488404278 : check e2388488404278 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388488404282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2388488404282 : Closed e2388488404282 ∧ code e2388488404282 = 11184581426490 := by decide
theorem cert_e2388488404282 : check e2388488404282 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2388488404378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2388488404378 : Closed e2388488404378 ∧ code e2388488404378 = 11184581426586 := by decide
theorem cert_e2388488404378 : check e2388488404378 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2388488407918 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388488407918 : Closed e2388488407918 ∧ code e2388488407918 = 11184581430126 := by decide
theorem cert_e2388488407918 : check e2388488407918 [[],[.left],[]] .sourceHead = true := by decide
def e2388488407926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388488407926 : Closed e2388488407926 ∧ code e2388488407926 = 11184581430134 := by decide
theorem cert_e2388488407926 : check e2388488407926 [[],[.left],[]] .sourceHead = true := by decide
def e2388488407982 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388488407982 : Closed e2388488407982 ∧ code e2388488407982 = 11184581430190 := by decide
theorem cert_e2388488407982 : check e2388488407982 [[],[.left],[]] .sourceHead = true := by decide
def e2388488407994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388488407994 : Closed e2388488407994 ∧ code e2388488407994 = 11184581430202 := by decide
theorem cert_e2388488407994 : check e2388488407994 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408022 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388488408022 : Closed e2388488408022 ∧ code e2388488408022 = 11184581430230 := by decide
theorem cert_e2388488408022 : check e2388488408022 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388488408026 : Closed e2388488408026 ∧ code e2388488408026 = 11184581430234 := by decide
theorem cert_e2388488408026 : check e2388488408026 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388488408302 : Closed e2388488408302 ∧ code e2388488408302 = 11184581430510 := by decide
theorem cert_e2388488408302 : check e2388488408302 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388488408310 : Closed e2388488408310 ∧ code e2388488408310 = 11184581430518 := by decide
theorem cert_e2388488408310 : check e2388488408310 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388488408686 : Closed e2388488408686 ∧ code e2388488408686 = 11184581430894 := by decide
theorem cert_e2388488408686 : check e2388488408686 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388488408698 : Closed e2388488408698 ∧ code e2388488408698 = 11184581430906 := by decide
theorem cert_e2388488408698 : check e2388488408698 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388488408886 : Closed e2388488408886 ∧ code e2388488408886 = 11184581431094 := by decide
theorem cert_e2388488408886 : check e2388488408886 [[],[.left],[]] .sourceHead = true := by decide
def e2388488408890 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388488408890 : Closed e2388488408890 ∧ code e2388488408890 = 11184581431098 := by decide
theorem cert_e2388488408890 : check e2388488408890 [[],[.left],[]] .sourceHead = true := by decide
def e2388488414638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2388488414638 : Closed e2388488414638 ∧ code e2388488414638 = 11184581436846 := by decide
theorem cert_e2388488414638 : check e2388488414638 [[],[.left],[],[.under]] .three = true := by decide
def e2388488414650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2388488414650 : Closed e2388488414650 ∧ code e2388488414650 = 11184581436858 := by decide
theorem cert_e2388488414650 : check e2388488414650 [[],[.left],[],[.under]] .three = true := by decide
def e2388488414698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2388488414698 : Closed e2388488414698 ∧ code e2388488414698 = 11184581436906 := by decide
theorem cert_e2388488414698 : check e2388488414698 [[],[.left],[],[.under]] .three = true := by decide
def e2388488414830 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2388488414830 : Closed e2388488414830 ∧ code e2388488414830 = 11184581437038 := by decide
theorem cert_e2388488414830 : check e2388488414830 [[],[.left],[],[.under]] .three = true := by decide
def e2388488414842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2388488414842 : Closed e2388488414842 ∧ code e2388488414842 = 11184581437050 := by decide
theorem cert_e2388488414842 : check e2388488414842 [[],[.left],[],[.under]] .three = true := by decide
def e2388488415130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2388488415130 : Closed e2388488415130 ∧ code e2388488415130 = 11184581437338 := by decide
theorem cert_e2388488415130 : check e2388488415130 [[],[.left],[],[.under]] .three = true := by decide
def e2388488418006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2388488418006 : Closed e2388488418006 ∧ code e2388488418006 = 11184581440214 := by decide
theorem cert_e2388488418006 : check e2388488418006 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388488418010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2388488418010 : Closed e2388488418010 ∧ code e2388488418010 = 11184581440218 := by decide
theorem cert_e2388488418010 : check e2388488418010 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388488418026 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2388488418026 : Closed e2388488418026 ∧ code e2388488418026 = 11184581440234 := by decide
theorem cert_e2388488418026 : check e2388488418026 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388488418102 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2388488418102 : Closed e2388488418102 ∧ code e2388488418102 = 11184581440310 := by decide
theorem cert_e2388488418102 : check e2388488418102 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388488418106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2388488418106 : Closed e2388488418106 ∧ code e2388488418106 = 11184581440314 := by decide
theorem cert_e2388488418106 : check e2388488418106 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388488418202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2388488418202 : Closed e2388488418202 ∧ code e2388488418202 = 11184581440410 := by decide
theorem cert_e2388488418202 : check e2388488418202 [[],[.left],[],[.under]] .smaller = true := by decide
def e2388488555374 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388488555374 : Closed e2388488555374 ∧ code e2388488555374 = 11184581577582 := by decide
theorem cert_e2388488555374 : check e2388488555374 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488555382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388488555382 : Closed e2388488555382 ∧ code e2388488555382 = 11184581577590 := by decide
theorem cert_e2388488555382 : check e2388488555382 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488555438 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388488555438 : Closed e2388488555438 ∧ code e2388488555438 = 11184581577646 := by decide
theorem cert_e2388488555438 : check e2388488555438 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488555450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388488555450 : Closed e2388488555450 ∧ code e2388488555450 = 11184581577658 := by decide
theorem cert_e2388488555450 : check e2388488555450 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488555478 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388488555478 : Closed e2388488555478 ∧ code e2388488555478 = 11184581577686 := by decide
theorem cert_e2388488555478 : check e2388488555478 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488555482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388488555482 : Closed e2388488555482 ∧ code e2388488555482 = 11184581577690 := by decide
theorem cert_e2388488555482 : check e2388488555482 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488555758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388488555758 : Closed e2388488555758 ∧ code e2388488555758 = 11184581577966 := by decide
theorem cert_e2388488555758 : check e2388488555758 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488555766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388488555766 : Closed e2388488555766 ∧ code e2388488555766 = 11184581577974 := by decide
theorem cert_e2388488555766 : check e2388488555766 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488556142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388488556142 : Closed e2388488556142 ∧ code e2388488556142 = 11184581578350 := by decide
theorem cert_e2388488556142 : check e2388488556142 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488556154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388488556154 : Closed e2388488556154 ∧ code e2388488556154 = 11184581578362 := by decide
theorem cert_e2388488556154 : check e2388488556154 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488556342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388488556342 : Closed e2388488556342 ∧ code e2388488556342 = 11184581578550 := by decide
theorem cert_e2388488556342 : check e2388488556342 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388488556346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388488556346 : Closed e2388488556346 ∧ code e2388488556346 = 11184581578554 := by decide
theorem cert_e2388488556346 : check e2388488556346 [[],[.left],[],[]] .sourceHead = true := by decide
def e2388489145198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2388489145198 : Closed e2388489145198 ∧ code e2388489145198 = 11184582167406 := by decide
theorem cert_e2388489145198 : check e2388489145198 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2388489145206 : Closed e2388489145206 ∧ code e2388489145206 = 11184582167414 := by decide
theorem cert_e2388489145206 : check e2388489145206 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2388489145262 : Closed e2388489145262 ∧ code e2388489145262 = 11184582167470 := by decide
theorem cert_e2388489145262 : check e2388489145262 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2388489145274 : Closed e2388489145274 ∧ code e2388489145274 = 11184582167482 := by decide
theorem cert_e2388489145274 : check e2388489145274 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2388489145302 : Closed e2388489145302 ∧ code e2388489145302 = 11184582167510 := by decide
theorem cert_e2388489145302 : check e2388489145302 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2388489145306 : Closed e2388489145306 ∧ code e2388489145306 = 11184582167514 := by decide
theorem cert_e2388489145306 : check e2388489145306 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145582 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2388489145582 : Closed e2388489145582 ∧ code e2388489145582 = 11184582167790 := by decide
theorem cert_e2388489145582 : check e2388489145582 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2388489145590 : Closed e2388489145590 ∧ code e2388489145590 = 11184582167798 := by decide
theorem cert_e2388489145590 : check e2388489145590 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2388489145966 : Closed e2388489145966 ∧ code e2388489145966 = 11184582168174 := by decide
theorem cert_e2388489145966 : check e2388489145966 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489145978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2388489145978 : Closed e2388489145978 ∧ code e2388489145978 = 11184582168186 := by decide
theorem cert_e2388489145978 : check e2388489145978 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489146166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2388489146166 : Closed e2388489146166 ∧ code e2388489146166 = 11184582168374 := by decide
theorem cert_e2388489146166 : check e2388489146166 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388489146170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2388489146170 : Closed e2388489146170 ∧ code e2388489146170 = 11184582168378 := by decide
theorem cert_e2388489146170 : check e2388489146170 [[],[.left],[.left],[]] .smaller = true := by decide
def e2388810119706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810119706 : Closed e2388810119706 ∧ code e2388810119706 = 11184903141914 := by decide
def e2388810127898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810127898 : Closed e2388810127898 ∧ code e2388810127898 = 11184903150106 := by decide
def e2388810185242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810185242 : Closed e2388810185242 ∧ code e2388810185242 = 11184903207450 := by decide
def e2388810197530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810197530 : Closed e2388810197530 ∧ code e2388810197530 = 11184903219738 := by decide
private def t_e2388810197530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388810197530 : ¬ IsSelfInterpreter e2388810197530 :=
  wSource (t := t_e2388810197530) (replay_sound (ps := []) (t := e2388810197530) (by decide)) (by decide)
def e2388810226202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810226202 : Closed e2388810226202 ∧ code e2388810226202 = 11184903248410 := by decide
def e2388810230298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810230298 : Closed e2388810230298 ∧ code e2388810230298 = 11184903252506 := by decide
private def t_e2388810230298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388810230298 : ¬ IsSelfInterpreter e2388810230298 :=
  wSource (t := t_e2388810230298) (replay_sound (ps := []) (t := e2388810230298) (by decide)) (by decide)
def e2388810512922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810512922 : Closed e2388810512922 ∧ code e2388810512922 = 11184903535130 := by decide
def e2388810521114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810521114 : Closed e2388810521114 ∧ code e2388810521114 = 11184903543322 := by decide
def e2388810906138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810906138 : Closed e2388810906138 ∧ code e2388810906138 = 11184903928346 := by decide
theorem cert_e2388810906138 : check e2388810906138 [[],[.left],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2388810918426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388810918426 : Closed e2388810918426 ∧ code e2388810918426 = 11184903940634 := by decide
theorem cert_e2388810918426 : checkPay e2388810918426 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left]] 0 [[],[.left],[],[.right],[.right],[.right,.under],[.right,.under,.under,.left,.left],[.right,.under,.under,.left],[.right,.under,.under,.left,.right],[.right,.under,.under,.right],[.right,.under,.under,.right,.under,.right,.left],[.right,.under,.under,.right,.under,.right],[.right,.under,.under,.right,.under,.right,.right]] = true := by decide
def e2388811110938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388811110938 : Closed e2388811110938 ∧ code e2388811110938 = 11184904133146 := by decide
theorem cert_e2388811110938 : check e2388811110938 [[],[.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2388811115034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388811115034 : Closed e2388811115034 ∧ code e2388811115034 = 11184904137242 := by decide
def e2388819109914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388819109914 : Closed e2388819109914 ∧ code e2388819109914 = 11184912132122 := by decide
theorem cert_e2388819109914 : check e2388819109914 [[]] .width = true := by decide
def e2388819142682 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388819142682 : Closed e2388819142682 ∧ code e2388819142682 = 11184912164890 := by decide
theorem cert_e2388819142682 : check e2388819142682 [[]] .width = true := by decide
def e2388819372058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388819372058 : Closed e2388819372058 ∧ code e2388819372058 = 11184912394266 := by decide
theorem cert_e2388819372058 : check e2388819372058 [[]] .width = true := by decide
def e2388819421210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388819421210 : Closed e2388819421210 ∧ code e2388819421210 = 11184912443418 := by decide
theorem cert_e2388819421210 : check e2388819421210 [[]] .width = true := by decide
def e2388819535898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388819535898 : Closed e2388819535898 ∧ code e2388819535898 = 11184912558106 := by decide
theorem cert_e2388819535898 : check e2388819535898 [[]] .width = true := by decide
def e2388819552282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388819552282 : Closed e2388819552282 ∧ code e2388819552282 = 11184912574490 := by decide
theorem cert_e2388819552282 : check e2388819552282 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2388810197530
#print axioms Blc.Floor43.cert_e2388810230298
