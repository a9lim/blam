import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406894522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406894522 : Closed e2422406894522 ∧ code e2422406894522 = 11218499916730 := by decide
theorem cert_e2422406894522 : check e2422406894522 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406894550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406894550 : Closed e2422406894550 ∧ code e2422406894550 = 11218499916758 := by decide
theorem cert_e2422406894550 : check e2422406894550 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406894554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406894554 : Closed e2422406894554 ∧ code e2422406894554 = 11218499916762 := by decide
theorem cert_e2422406894554 : check e2422406894554 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406894622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406894622 : Closed e2422406894622 ∧ code e2422406894622 = 11218499916830 := by decide
theorem cert_e2422406894622 : check e2422406894622 [[],[]] .chain = true := by decide
def e2422406894818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406894818 : Closed e2422406894818 ∧ code e2422406894818 = 11218499917026 := by decide
theorem cert_e2422406894818 : check e2422406894818 [[],[]] .chain = true := by decide
def e2422406894830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406894830 : Closed e2422406894830 ∧ code e2422406894830 = 11218499917038 := by decide
theorem cert_e2422406894830 : check e2422406894830 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406894838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406894838 : Closed e2422406894838 ∧ code e2422406894838 = 11218499917046 := by decide
theorem cert_e2422406894838 : check e2422406894838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406895106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406895106 : Closed e2422406895106 ∧ code e2422406895106 = 11218499917314 := by decide
theorem cert_e2422406895106 : check e2422406895106 [[],[]] .chain = true := by decide
def e2422406895118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406895118 : Closed e2422406895118 ∧ code e2422406895118 = 11218499917326 := by decide
theorem cert_e2422406895118 : check e2422406895118 [[],[]] .chain = true := by decide
def e2422406895130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406895130 : Closed e2422406895130 ∧ code e2422406895130 = 11218499917338 := by decide
private def t_e2422406895130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2422406895130 : ¬ IsSelfInterpreter e2422406895130 :=
  wIdentity (t := t_e2422406895130) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]]) (t := (inv e2422406895130)) (by decide)) (by decide)
def e2422406895202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406895202 : Closed e2422406895202 ∧ code e2422406895202 = 11218499917410 := by decide
theorem cert_e2422406895202 : check e2422406895202 [[],[]] .chain = true := by decide
def e2422406895214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406895214 : Closed e2422406895214 ∧ code e2422406895214 = 11218499917422 := by decide
theorem cert_e2422406895214 : check e2422406895214 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406895222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406895222 : Closed e2422406895222 ∧ code e2422406895222 = 11218499917430 := by decide
theorem cert_e2422406895222 : check e2422406895222 [[],[]] .chain = true := by decide
def e2422406895226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406895226 : Closed e2422406895226 ∧ code e2422406895226 = 11218499917434 := by decide
theorem cert_e2422406895226 : check e2422406895226 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406895414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406895414 : Closed e2422406895414 ∧ code e2422406895414 = 11218499917622 := by decide
theorem cert_e2422406895414 : check e2422406895414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406895418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406895418 : Closed e2422406895418 ∧ code e2422406895418 = 11218499917626 := by decide
theorem cert_e2422406895418 : check e2422406895418 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406895626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406895626 : Closed e2422406895626 ∧ code e2422406895626 = 11218499917834 := by decide
theorem cert_e2422406895626 : check e2422406895626 [[],[]] .chain = true := by decide
def e2422406895662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406895662 : Closed e2422406895662 ∧ code e2422406895662 = 11218499917870 := by decide
theorem cert_e2422406895662 : check e2422406895662 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406895670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406895670 : Closed e2422406895670 ∧ code e2422406895670 = 11218499917878 := by decide
theorem cert_e2422406895670 : check e2422406895670 [[],[]] .chain = true := by decide
def e2422406895674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406895674 : Closed e2422406895674 ∧ code e2422406895674 = 11218499917882 := by decide
theorem cert_e2422406895674 : check e2422406895674 [[],[]] .chain = true := by decide
def e2422406895722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406895722 : Closed e2422406895722 ∧ code e2422406895722 = 11218499917930 := by decide
theorem cert_e2422406895722 : check e2422406895722 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406895758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406895758 : Closed e2422406895758 ∧ code e2422406895758 = 11218499917966 := by decide
theorem cert_e2422406895758 : check e2422406895758 [[],[]] .chain = true := by decide
def e2422406895770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406895770 : Closed e2422406895770 ∧ code e2422406895770 = 11218499917978 := by decide
theorem cert_e2422406895770 : check e2422406895770 [[],[]] .chain = true := by decide
def e2422406895814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406895814 : Closed e2422406895814 ∧ code e2422406895814 = 11218499918022 := by decide
theorem cert_e2422406895814 : check e2422406895814 [[],[]] .chain = true := by decide
def e2422406895842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406895842 : Closed e2422406895842 ∧ code e2422406895842 = 11218499918050 := by decide
theorem cert_e2422406895842 : check e2422406895842 [[],[]] .chain = true := by decide
def e2422406895854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406895854 : Closed e2422406895854 ∧ code e2422406895854 = 11218499918062 := by decide
theorem cert_e2422406895854 : check e2422406895854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406895862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406895862 : Closed e2422406895862 ∧ code e2422406895862 = 11218499918070 := by decide
theorem cert_e2422406895862 : check e2422406895862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406896010 : Closed e2422406896010 ∧ code e2422406896010 = 11218499918218 := by decide
theorem cert_e2422406896010 : check e2422406896010 [[],[]] .chain = true := by decide
def e2422406896034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406896034 : Closed e2422406896034 ∧ code e2422406896034 = 11218499918242 := by decide
theorem cert_e2422406896034 : check e2422406896034 [[],[]] .chain = true := by decide
def e2422406896046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406896046 : Closed e2422406896046 ∧ code e2422406896046 = 11218499918254 := by decide
theorem cert_e2422406896046 : check e2422406896046 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406896054 : Closed e2422406896054 ∧ code e2422406896054 = 11218499918262 := by decide
theorem cert_e2422406896054 : check e2422406896054 [[],[]] .chain = true := by decide
def e2422406896058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406896058 : Closed e2422406896058 ∧ code e2422406896058 = 11218499918266 := by decide
theorem cert_e2422406896058 : check e2422406896058 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406896086 : Closed e2422406896086 ∧ code e2422406896086 = 11218499918294 := by decide
theorem cert_e2422406896086 : check e2422406896086 [[],[]] .chain = true := by decide
def e2422406896090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406896090 : Closed e2422406896090 ∧ code e2422406896090 = 11218499918298 := by decide
theorem cert_e2422406896090 : check e2422406896090 [[],[]] .chain = true := by decide
def e2422406896106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406896106 : Closed e2422406896106 ∧ code e2422406896106 = 11218499918314 := by decide
theorem cert_e2422406896106 : check e2422406896106 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406896130 : Closed e2422406896130 ∧ code e2422406896130 = 11218499918338 := by decide
theorem cert_e2422406896130 : check e2422406896130 [[],[]] .chain = true := by decide
def e2422406896142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406896142 : Closed e2422406896142 ∧ code e2422406896142 = 11218499918350 := by decide
theorem cert_e2422406896142 : check e2422406896142 [[],[]] .chain = true := by decide
def e2422406896154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406896154 : Closed e2422406896154 ∧ code e2422406896154 = 11218499918362 := by decide
theorem cert_e2422406896154 : check e2422406896154 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406896226 : Closed e2422406896226 ∧ code e2422406896226 = 11218499918434 := by decide
theorem cert_e2422406896226 : check e2422406896226 [[],[]] .chain = true := by decide
def e2422406896238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406896238 : Closed e2422406896238 ∧ code e2422406896238 = 11218499918446 := by decide
theorem cert_e2422406896238 : check e2422406896238 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406896246 : Closed e2422406896246 ∧ code e2422406896246 = 11218499918454 := by decide
theorem cert_e2422406896246 : check e2422406896246 [[],[]] .chain = true := by decide
def e2422406896250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406896250 : Closed e2422406896250 ∧ code e2422406896250 = 11218499918458 := by decide
theorem cert_e2422406896250 : check e2422406896250 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406896390 : Closed e2422406896390 ∧ code e2422406896390 = 11218499918598 := by decide
theorem cert_e2422406896390 : check e2422406896390 [[],[]] .chain = true := by decide
def e2422406896414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406896414 : Closed e2422406896414 ∧ code e2422406896414 = 11218499918622 := by decide
theorem cert_e2422406896414 : check e2422406896414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406896438 : Closed e2422406896438 ∧ code e2422406896438 = 11218499918646 := by decide
theorem cert_e2422406896438 : check e2422406896438 [[],[]] .chain = true := by decide
def e2422406896442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406896442 : Closed e2422406896442 ∧ code e2422406896442 = 11218499918650 := by decide
theorem cert_e2422406896442 : check e2422406896442 [[],[]] .chain = true := by decide
def e2422406896514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406896514 : Closed e2422406896514 ∧ code e2422406896514 = 11218499918722 := by decide
theorem cert_e2422406896514 : check e2422406896514 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406896526 : Closed e2422406896526 ∧ code e2422406896526 = 11218499918734 := by decide
theorem cert_e2422406896526 : check e2422406896526 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406896538 : Closed e2422406896538 ∧ code e2422406896538 = 11218499918746 := by decide
theorem cert_e2422406896538 : check e2422406896538 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406896662 : Closed e2422406896662 ∧ code e2422406896662 = 11218499918870 := by decide
theorem cert_e2422406896662 : check e2422406896662 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406896758 : Closed e2422406896758 ∧ code e2422406896758 = 11218499918966 := by decide
theorem cert_e2422406896758 : check e2422406896758 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406896854 : Closed e2422406896854 ∧ code e2422406896854 = 11218499919062 := by decide
theorem cert_e2422406896854 : check e2422406896854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406896858 : Closed e2422406896858 ∧ code e2422406896858 = 11218499919066 := by decide
theorem cert_e2422406896858 : check e2422406896858 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406896874 : Closed e2422406896874 ∧ code e2422406896874 = 11218499919082 := by decide
theorem cert_e2422406896874 : check e2422406896874 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406896950 : Closed e2422406896950 ∧ code e2422406896950 = 11218499919158 := by decide
theorem cert_e2422406896950 : check e2422406896950 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406896954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406896954 : Closed e2422406896954 ∧ code e2422406896954 = 11218499919162 := by decide
theorem cert_e2422406896954 : check e2422406896954 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406897026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406897026 : Closed e2422406897026 ∧ code e2422406897026 = 11218499919234 := by decide
theorem cert_e2422406897026 : check e2422406897026 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406897038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406897038 : Closed e2422406897038 ∧ code e2422406897038 = 11218499919246 := by decide
theorem cert_e2422406897038 : check e2422406897038 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406897050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406897050 : Closed e2422406897050 ∧ code e2422406897050 = 11218499919258 := by decide
theorem cert_e2422406897050 : check e2422406897050 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406907118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406907118 : Closed e2422406907118 ∧ code e2422406907118 = 11218499929326 := by decide
theorem cert_e2422406907118 : check e2422406907118 [[],[]] .chain = true := by decide
def e2422406907126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406907126 : Closed e2422406907126 ∧ code e2422406907126 = 11218499929334 := by decide
theorem cert_e2422406907126 : check e2422406907126 [[],[]] .chain = true := by decide
def e2422406909422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.var 3))))) (.var 2))))))
theorem wire_e2422406909422 : Closed e2422406909422 ∧ code e2422406909422 = 11218499931630 := by decide
theorem cert_e2422406909422 : check e2422406909422 [[],[]] .chain = true := by decide
def e2422406909430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.var 4))))) (.var 1))))))
theorem wire_e2422406909430 : Closed e2422406909430 ∧ code e2422406909430 = 11218499931638 := by decide
theorem cert_e2422406909430 : check e2422406909430 [[],[]] .chain = true := by decide
def e2422406909870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 0))))) (.var 2))))))
theorem wire_e2422406909870 : Closed e2422406909870 ∧ code e2422406909870 = 11218499932078 := by decide
theorem cert_e2422406909870 : check e2422406909870 [[],[]] .chain = true := by decide
def e2422406909910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 4) (.var 0))))) (.var 1))))))
theorem wire_e2422406909910 : Closed e2422406909910 ∧ code e2422406909910 = 11218499932118 := by decide
theorem cert_e2422406909910 : check e2422406909910 [[],[]] .chain = true := by decide
def e2422406913262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406913262 : Closed e2422406913262 ∧ code e2422406913262 = 11218499935470 := by decide
theorem cert_e2422406913262 : check e2422406913262 [[],[]] .chain = true := by decide
def e2422406913270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406913270 : Closed e2422406913270 ∧ code e2422406913270 = 11218499935478 := by decide
theorem cert_e2422406913270 : check e2422406913270 [[],[]] .chain = true := by decide
def e2422406913646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406913646 : Closed e2422406913646 ∧ code e2422406913646 = 11218499935854 := by decide
theorem cert_e2422406913646 : check e2422406913646 [[],[]] .chain = true := by decide
def e2422406913658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406913658 : Closed e2422406913658 ∧ code e2422406913658 = 11218499935866 := by decide
theorem cert_e2422406913658 : check e2422406913658 [[],[]] .chain = true := by decide
def e2422406913846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406913846 : Closed e2422406913846 ∧ code e2422406913846 = 11218499936054 := by decide
theorem cert_e2422406913846 : check e2422406913846 [[],[]] .chain = true := by decide
def e2422406913850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406913850 : Closed e2422406913850 ∧ code e2422406913850 = 11218499936058 := by decide
theorem cert_e2422406913850 : check e2422406913850 [[],[]] .chain = true := by decide
def e2422406917562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2422406917562 : Closed e2422406917562 ∧ code e2422406917562 = 11218499939770 := by decide
theorem cert_e2422406917562 : check e2422406917562 [[],[]] .smaller = true := by decide
def e2422406917594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2422406917594 : Closed e2422406917594 ∧ code e2422406917594 = 11218499939802 := by decide
theorem cert_e2422406917594 : check e2422406917594 [[],[]] .smaller = true := by decide
def e2422406917818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2422406917818 : Closed e2422406917818 ∧ code e2422406917818 = 11218499940026 := by decide
theorem cert_e2422406917818 : check e2422406917818 [[],[]] .smaller = true := by decide
def e2422406917866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2422406917866 : Closed e2422406917866 ∧ code e2422406917866 = 11218499940074 := by decide
theorem cert_e2422406917866 : check e2422406917866 [[],[]] .smaller = true := by decide
def e2422406917978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e2422406917978 : Closed e2422406917978 ∧ code e2422406917978 = 11218499940186 := by decide
theorem cert_e2422406917978 : check e2422406917978 [[],[]] .smaller = true := by decide
def e2422406917994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e2422406917994 : Closed e2422406917994 ∧ code e2422406917994 = 11218499940202 := by decide
theorem cert_e2422406917994 : check e2422406917994 [[],[]] .smaller = true := by decide
def e2422406918638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.var 3))))) (.var 2))))))
theorem wire_e2422406918638 : Closed e2422406918638 ∧ code e2422406918638 = 11218499940846 := by decide
theorem cert_e2422406918638 : check e2422406918638 [[],[]] .chain = true := by decide
def e2422406918646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.var 4))))) (.var 1))))))
theorem wire_e2422406918646 : Closed e2422406918646 ∧ code e2422406918646 = 11218499940854 := by decide
theorem cert_e2422406918646 : check e2422406918646 [[],[]] .chain = true := by decide
def e2422406919098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2422406919098 : Closed e2422406919098 ∧ code e2422406919098 = 11218499941306 := by decide
theorem cert_e2422406919098 : check e2422406919098 [[],[]] .smaller = true := by decide
def e2422406919130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2422406919130 : Closed e2422406919130 ∧ code e2422406919130 = 11218499941338 := by decide
theorem cert_e2422406919130 : check e2422406919130 [[],[]] .smaller = true := by decide
def e2422406919406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406919406 : Closed e2422406919406 ∧ code e2422406919406 = 11218499941614 := by decide
theorem cert_e2422406919406 : check e2422406919406 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406919414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406919414 : Closed e2422406919414 ∧ code e2422406919414 = 11218499941622 := by decide
theorem cert_e2422406919414 : check e2422406919414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406919966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2422406919966 : Closed e2422406919966 ∧ code e2422406919966 = 11218499942174 := by decide
theorem cert_e2422406919966 : check e2422406919966 [[],[]] .chain = true := by decide
def e2422406920078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2422406920078 : Closed e2422406920078 ∧ code e2422406920078 = 11218499942286 := by decide
theorem cert_e2422406920078 : check e2422406920078 [[],[]] .chain = true := by decide
def e2422406920634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2422406920634 : Closed e2422406920634 ∧ code e2422406920634 = 11218499942842 := by decide
theorem cert_e2422406920634 : check e2422406920634 [[],[]] .smaller = true := by decide
def e2422406920682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2422406920682 : Closed e2422406920682 ∧ code e2422406920682 = 11218499942890 := by decide
theorem cert_e2422406920682 : check e2422406920682 [[],[]] .smaller = true := by decide
def e2422406921326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422406921326 : Closed e2422406921326 ∧ code e2422406921326 = 11218499943534 := by decide
theorem cert_e2422406921326 : check e2422406921326 [[],[]] .chain = true := by decide
def e2422406921434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2422406921434 : Closed e2422406921434 ∧ code e2422406921434 = 11218499943642 := by decide
theorem cert_e2422406921434 : check e2422406921434 [[],[]] .smaller = true := by decide
def e2422406921450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2422406921450 : Closed e2422406921450 ∧ code e2422406921450 = 11218499943658 := by decide
theorem cert_e2422406921450 : check e2422406921450 [[],[]] .smaller = true := by decide
def e2422406921502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422406921502 : Closed e2422406921502 ∧ code e2422406921502 = 11218499943710 := by decide
theorem cert_e2422406921502 : check e2422406921502 [[],[]] .chain = true := by decide
def e2422406921698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 0)))))))
theorem wire_e2422406921698 : Closed e2422406921698 ∧ code e2422406921698 = 11218499943906 := by decide
theorem cert_e2422406921698 : check e2422406921698 [[],[]] .chain = true := by decide
def e2422406921710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))) (.var 2))))))
theorem wire_e2422406921710 : Closed e2422406921710 ∧ code e2422406921710 = 11218499943918 := by decide
theorem cert_e2422406921710 : check e2422406921710 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406921782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422406921782 : Closed e2422406921782 ∧ code e2422406921782 = 11218499943990 := by decide
theorem cert_e2422406921782 : check e2422406921782 [[],[]] .chain = true := by decide
def e2422406921870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422406921870 : Closed e2422406921870 ∧ code e2422406921870 = 11218499944078 := by decide
theorem cert_e2422406921870 : check e2422406921870 [[],[]] .chain = true := by decide
def e2422406921954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422406921954 : Closed e2422406921954 ∧ code e2422406921954 = 11218499944162 := by decide
theorem cert_e2422406921954 : check e2422406921954 [[],[]] .chain = true := by decide
def e2422406921966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))) (.var 2))))))
theorem wire_e2422406921966 : Closed e2422406921966 ∧ code e2422406921966 = 11218499944174 := by decide
theorem cert_e2422406921966 : check e2422406921966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406921974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 3)))) (.var 1))))))
theorem wire_e2422406921974 : Closed e2422406921974 ∧ code e2422406921974 = 11218499944182 := by decide
theorem cert_e2422406921974 : checkPay e2422406921974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406923230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422406923230 : Closed e2422406923230 ∧ code e2422406923230 = 11218499945438 := by decide
theorem cert_e2422406923230 : check e2422406923230 [[],[]] .chain = true := by decide
def e2422406923246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422406923246 : Closed e2422406923246 ∧ code e2422406923246 = 11218499945454 := by decide
theorem cert_e2422406923246 : check e2422406923246 [[],[]] .chain = true := by decide
def e2422406925166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422406925166 : Closed e2422406925166 ∧ code e2422406925166 = 11218499947374 := by decide
theorem cert_e2422406925166 : check e2422406925166 [[],[]] .chain = true := by decide
def e2422406925174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422406925174 : Closed e2422406925174 ∧ code e2422406925174 = 11218499947382 := by decide
theorem cert_e2422406925174 : check e2422406925174 [[],[]] .chain = true := by decide
def e2422406925230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422406925230 : Closed e2422406925230 ∧ code e2422406925230 = 11218499947438 := by decide
theorem cert_e2422406925230 : check e2422406925230 [[],[]] .chain = true := by decide
def e2422406925242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422406925242 : Closed e2422406925242 ∧ code e2422406925242 = 11218499947450 := by decide
theorem cert_e2422406925242 : check e2422406925242 [[],[]] .chain = true := by decide
def e2422406925270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422406925270 : Closed e2422406925270 ∧ code e2422406925270 = 11218499947478 := by decide
theorem cert_e2422406925270 : check e2422406925270 [[],[]] .chain = true := by decide
def e2422406925274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422406925274 : Closed e2422406925274 ∧ code e2422406925274 = 11218499947482 := by decide
theorem cert_e2422406925274 : check e2422406925274 [[],[]] .chain = true := by decide
def e2422406925550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422406925550 : Closed e2422406925550 ∧ code e2422406925550 = 11218499947758 := by decide
theorem cert_e2422406925550 : check e2422406925550 [[],[]] .chain = true := by decide
def e2422406925558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422406925558 : Closed e2422406925558 ∧ code e2422406925558 = 11218499947766 := by decide
theorem cert_e2422406925558 : check e2422406925558 [[],[]] .chain = true := by decide
def e2422406925934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422406925934 : Closed e2422406925934 ∧ code e2422406925934 = 11218499948142 := by decide
theorem cert_e2422406925934 : check e2422406925934 [[],[]] .chain = true := by decide
def e2422406925946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422406925946 : Closed e2422406925946 ∧ code e2422406925946 = 11218499948154 := by decide
theorem cert_e2422406925946 : check e2422406925946 [[],[]] .chain = true := by decide
def e2422406926134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422406926134 : Closed e2422406926134 ∧ code e2422406926134 = 11218499948342 := by decide
theorem cert_e2422406926134 : check e2422406926134 [[],[]] .chain = true := by decide
def e2422406926138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422406926138 : Closed e2422406926138 ∧ code e2422406926138 = 11218499948346 := by decide
theorem cert_e2422406926138 : check e2422406926138 [[],[]] .chain = true := by decide
def e2422406932254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422406932254 : Closed e2422406932254 ∧ code e2422406932254 = 11218499954462 := by decide
theorem cert_e2422406932254 : check e2422406932254 [[],[]] .chain = true := by decide
def e2422406932366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422406932366 : Closed e2422406932366 ∧ code e2422406932366 = 11218499954574 := by decide
theorem cert_e2422406932366 : check e2422406932366 [[],[]] .chain = true := by decide
def e2422406934750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422406934750 : Closed e2422406934750 ∧ code e2422406934750 = 11218499956958 := by decide
theorem cert_e2422406934750 : check e2422406934750 [[],[]] .chain = true := by decide
def e2422406934778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422406934778 : Closed e2422406934778 ∧ code e2422406934778 = 11218499956986 := by decide
theorem cert_e2422406934778 : check e2422406934778 [[],[]] .chain = true := by decide
def e2422406935326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422406935326 : Closed e2422406935326 ∧ code e2422406935326 = 11218499957534 := by decide
theorem cert_e2422406935326 : check e2422406935326 [[],[]] .chain = true := by decide
def e2422406935494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422406935494 : Closed e2422406935494 ∧ code e2422406935494 = 11218499957702 := by decide
theorem cert_e2422406935494 : check e2422406935494 [[],[]] .chain = true := by decide
def e2422406936686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422406936686 : Closed e2422406936686 ∧ code e2422406936686 = 11218499958894 := by decide
theorem cert_e2422406936686 : check e2422406936686 [[],[]] .chain = true := by decide
def e2422406936698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422406936698 : Closed e2422406936698 ∧ code e2422406936698 = 11218499958906 := by decide
theorem cert_e2422406936698 : check e2422406936698 [[],[]] .chain = true := by decide
def e2422406936974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422406936974 : Closed e2422406936974 ∧ code e2422406936974 = 11218499959182 := by decide
theorem cert_e2422406936974 : check e2422406936974 [[],[]] .chain = true := by decide
def e2422406937030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422406937030 : Closed e2422406937030 ∧ code e2422406937030 = 11218499959238 := by decide
theorem cert_e2422406937030 : check e2422406937030 [[],[]] .chain = true := by decide
def e2422406951278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2))))))
theorem wire_e2422406951278 : Closed e2422406951278 ∧ code e2422406951278 = 11218499973486 := by decide
theorem cert_e2422406951278 : check e2422406951278 [[],[]] .chain = true := by decide
def e2422406951286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1))))))
theorem wire_e2422406951286 : Closed e2422406951286 ∧ code e2422406951286 = 11218499973494 := by decide
theorem cert_e2422406951286 : check e2422406951286 [[],[]] .chain = true := by decide
def e2422406952494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406952494 : Closed e2422406952494 ∧ code e2422406952494 = 11218499974702 := by decide
theorem cert_e2422406952494 : check e2422406952494 [[],[]] .chain = true := by decide
def e2422406952674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406952674 : Closed e2422406952674 ∧ code e2422406952674 = 11218499974882 := by decide
theorem cert_e2422406952674 : check e2422406952674 [[],[]] .chain = true := by decide
def e2422406952686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2))))))
theorem wire_e2422406952686 : Closed e2422406952686 ∧ code e2422406952686 = 11218499974894 := by decide
theorem cert_e2422406952686 : check e2422406952686 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406952726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406952726 : Closed e2422406952726 ∧ code e2422406952726 = 11218499974934 := by decide
theorem cert_e2422406952726 : check e2422406952726 [[],[]] .chain = true := by decide
def e2422406952802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406952802 : Closed e2422406952802 ∧ code e2422406952802 = 11218499975010 := by decide
theorem cert_e2422406952802 : check e2422406952802 [[],[]] .chain = true := by decide
def e2422406952814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2))))))
theorem wire_e2422406952814 : Closed e2422406952814 ∧ code e2422406952814 = 11218499975022 := by decide
theorem cert_e2422406952814 : check e2422406952814 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406952822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1))))))
theorem wire_e2422406952822 : Closed e2422406952822 ∧ code e2422406952822 = 11218499975030 := by decide
theorem cert_e2422406952822 : checkPay e2422406952822 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406953134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2))))))
theorem wire_e2422406953134 : Closed e2422406953134 ∧ code e2422406953134 = 11218499975342 := by decide
theorem cert_e2422406953134 : check e2422406953134 [[],[]] .chain = true := by decide
def e2422406953146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0))))))
theorem wire_e2422406953146 : Closed e2422406953146 ∧ code e2422406953146 = 11218499975354 := by decide
theorem cert_e2422406953146 : check e2422406953146 [[],[]] .chain = true := by decide
def e2422406953518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406953518 : Closed e2422406953518 ∧ code e2422406953518 = 11218499975726 := by decide
theorem cert_e2422406953518 : check e2422406953518 [[],[]] .chain = true := by decide
def e2422406953698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406953698 : Closed e2422406953698 ∧ code e2422406953698 = 11218499975906 := by decide
theorem cert_e2422406953698 : check e2422406953698 [[],[]] .chain = true := by decide
def e2422406953710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2))))))
theorem wire_e2422406953710 : Closed e2422406953710 ∧ code e2422406953710 = 11218499975918 := by decide
theorem cert_e2422406953710 : check e2422406953710 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406953838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2422406953838 : Closed e2422406953838 ∧ code e2422406953838 = 11218499976046 := by decide
theorem cert_e2422406953838 : check e2422406953838 [[],[]] .chain = true := by decide
def e2422406953846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2422406953846 : Closed e2422406953846 ∧ code e2422406953846 = 11218499976054 := by decide
theorem cert_e2422406953846 : check e2422406953846 [[],[]] .chain = true := by decide
def e2422406953866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406953866 : Closed e2422406953866 ∧ code e2422406953866 = 11218499976074 := by decide
theorem cert_e2422406953866 : check e2422406953866 [[],[]] .chain = true := by decide
def e2422406953890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406953890 : Closed e2422406953890 ∧ code e2422406953890 = 11218499976098 := by decide
theorem cert_e2422406953890 : check e2422406953890 [[],[]] .chain = true := by decide
def e2422406953902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2))))))
theorem wire_e2422406953902 : Closed e2422406953902 ∧ code e2422406953902 = 11218499976110 := by decide
theorem cert_e2422406953902 : check e2422406953902 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406953910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2422406953910 : Closed e2422406953910 ∧ code e2422406953910 = 11218499976118 := by decide
theorem cert_e2422406953910 : check e2422406953910 [[],[]] .chain = true := by decide
def e2422406953914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0))))))
theorem wire_e2422406953914 : Closed e2422406953914 ∧ code e2422406953914 = 11218499976122 := by decide
theorem cert_e2422406953914 : check e2422406953914 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406954070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2422406954070 : Closed e2422406954070 ∧ code e2422406954070 = 11218499976278 := by decide
theorem cert_e2422406954070 : check e2422406954070 [[],[]] .chain = true := by decide
def e2422406954074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2422406954074 : Closed e2422406954074 ∧ code e2422406954074 = 11218499976282 := by decide
theorem cert_e2422406954074 : check e2422406954074 [[],[]] .chain = true := by decide
def e2422406954262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406954262 : Closed e2422406954262 ∧ code e2422406954262 = 11218499976470 := by decide
theorem cert_e2422406954262 : check e2422406954262 [[],[]] .chain = true := by decide
def e2422406954338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406954338 : Closed e2422406954338 ∧ code e2422406954338 = 11218499976546 := by decide
theorem cert_e2422406954338 : check e2422406954338 [[],[]] .chain = true := by decide
def e2422406954350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422406954350 : Closed e2422406954350 ∧ code e2422406954350 = 11218499976558 := by decide
theorem cert_e2422406954350 : check e2422406954350 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406954358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422406954358 : Closed e2422406954358 ∧ code e2422406954358 = 11218499976566 := by decide
theorem cert_e2422406954358 : checkPay e2422406954358 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406954378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406954378 : Closed e2422406954378 ∧ code e2422406954378 = 11218499976586 := by decide
theorem cert_e2422406954378 : check e2422406954378 [[],[]] .chain = true := by decide
def e2422406954402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406954402 : Closed e2422406954402 ∧ code e2422406954402 = 11218499976610 := by decide
theorem cert_e2422406954402 : check e2422406954402 [[],[]] .chain = true := by decide
def e2422406954414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422406954414 : Closed e2422406954414 ∧ code e2422406954414 = 11218499976622 := by decide
theorem cert_e2422406954414 : check e2422406954414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406954422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2422406954422 : Closed e2422406954422 ∧ code e2422406954422 = 11218499976630 := by decide
theorem cert_e2422406954422 : check e2422406954422 [[],[]] .chain = true := by decide
def e2422406954426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422406954426 : Closed e2422406954426 ∧ code e2422406954426 = 11218499976634 := by decide
theorem cert_e2422406954426 : check e2422406954426 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406954454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422406954454 : Closed e2422406954454 ∧ code e2422406954454 = 11218499976662 := by decide
theorem cert_e2422406954454 : checkPay e2422406954454 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406954458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422406954458 : Closed e2422406954458 ∧ code e2422406954458 = 11218499976666 := by decide
theorem cert_e2422406954458 : check e2422406954458 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406955502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2422406955502 : Closed e2422406955502 ∧ code e2422406955502 = 11218499977710 := by decide
theorem cert_e2422406955502 : check e2422406955502 [[],[]] .chain = true := by decide
def e2422406955510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2422406955510 : Closed e2422406955510 ∧ code e2422406955510 = 11218499977718 := by decide
theorem cert_e2422406955510 : check e2422406955510 [[],[]] .chain = true := by decide
def e2422406956270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406956270 : Closed e2422406956270 ∧ code e2422406956270 = 11218499978478 := by decide
theorem cert_e2422406956270 : check e2422406956270 [[],[]] .chain = true := by decide
def e2422406956278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406956278 : Closed e2422406956278 ∧ code e2422406956278 = 11218499978486 := by decide
theorem cert_e2422406956278 : check e2422406956278 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422406895130
