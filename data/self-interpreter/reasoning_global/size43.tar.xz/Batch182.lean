import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262388795318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2262388795318 : Closed e2262388795318 ∧ code e2262388795318 = 11058481817526 := by decide
theorem cert_e2262388795318 : check e2262388795318 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388796654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262388796654 : Closed e2262388796654 ∧ code e2262388796654 = 11058481818862 := by decide
theorem cert_e2262388796654 : check e2262388796654 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388796662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262388796662 : Closed e2262388796662 ∧ code e2262388796662 = 11058481818870 := by decide
theorem cert_e2262388796662 : check e2262388796662 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388797046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262388797046 : Closed e2262388797046 ∧ code e2262388797046 = 11058481819254 := by decide
private def t_e2262388797046 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem cert_e2262388797046 : ¬ IsSelfInterpreter e2262388797046 :=
  wSource (t := t_e2262388797046) (replay_sound (ps := []) (t := e2262388797046) (by decide)) (by decide)
def e2262388798318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2262388798318 : Closed e2262388798318 ∧ code e2262388798318 = 11058481820526 := by decide
theorem cert_e2262388798318 : check e2262388798318 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388798326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2262388798326 : Closed e2262388798326 ∧ code e2262388798326 = 11058481820534 := by decide
theorem cert_e2262388798326 : check e2262388798326 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388798382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2262388798382 : Closed e2262388798382 ∧ code e2262388798382 = 11058481820590 := by decide
theorem cert_e2262388798382 : check e2262388798382 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388798394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2262388798394 : Closed e2262388798394 ∧ code e2262388798394 = 11058481820602 := by decide
theorem cert_e2262388798394 : check e2262388798394 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388798422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2262388798422 : Closed e2262388798422 ∧ code e2262388798422 = 11058481820630 := by decide
theorem cert_e2262388798422 : check e2262388798422 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388798426 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2262388798426 : Closed e2262388798426 ∧ code e2262388798426 = 11058481820634 := by decide
theorem cert_e2262388798426 : check e2262388798426 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388798702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262388798702 : Closed e2262388798702 ∧ code e2262388798702 = 11058481820910 := by decide
theorem cert_e2262388798702 : check e2262388798702 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388798710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262388798710 : Closed e2262388798710 ∧ code e2262388798710 = 11058481820918 := by decide
theorem cert_e2262388798710 : check e2262388798710 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388799086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262388799086 : Closed e2262388799086 ∧ code e2262388799086 = 11058481821294 := by decide
theorem cert_e2262388799086 : check e2262388799086 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388799098 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262388799098 : Closed e2262388799098 ∧ code e2262388799098 = 11058481821306 := by decide
theorem cert_e2262388799098 : check e2262388799098 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388799286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262388799286 : Closed e2262388799286 ∧ code e2262388799286 = 11058481821494 := by decide
theorem cert_e2262388799286 : check e2262388799286 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388799290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262388799290 : Closed e2262388799290 ∧ code e2262388799290 = 11058481821498 := by decide
theorem cert_e2262388799290 : check e2262388799290 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388799926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2262388799926 : Closed e2262388799926 ∧ code e2262388799926 = 11058481822134 := by decide
theorem cert_e2262388799926 : check e2262388799926 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388799958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2262388799958 : Closed e2262388799958 ∧ code e2262388799958 = 11058481822166 := by decide
theorem cert_e2262388799958 : check e2262388799958 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388799962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2262388799962 : Closed e2262388799962 ∧ code e2262388799962 = 11058481822170 := by decide
theorem cert_e2262388799962 : check e2262388799962 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388800118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262388800118 : Closed e2262388800118 ∧ code e2262388800118 = 11058481822326 := by decide
private def t_e2262388800118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem cert_e2262388800118 : ¬ IsSelfInterpreter e2262388800118 :=
  wSource (t := t_e2262388800118) (replay_sound (ps := []) (t := e2262388800118) (by decide)) (by decide)
def e2262388800310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262388800310 : Closed e2262388800310 ∧ code e2262388800310 = 11058481822518 := by decide
theorem cert_e2262388800310 : check e2262388800310 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388800314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262388800314 : Closed e2262388800314 ∧ code e2262388800314 = 11058481822522 := by decide
theorem cert_e2262388800314 : check e2262388800314 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388807534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2262388807534 : Closed e2262388807534 ∧ code e2262388807534 = 11058481829742 := by decide
theorem cert_e2262388807534 : check e2262388807534 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388807542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2262388807542 : Closed e2262388807542 ∧ code e2262388807542 = 11058481829750 := by decide
theorem cert_e2262388807542 : check e2262388807542 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388807606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2262388807606 : Closed e2262388807606 ∧ code e2262388807606 = 11058481829814 := by decide
theorem cert_e2262388807606 : check e2262388807606 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388808942 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262388808942 : Closed e2262388808942 ∧ code e2262388808942 = 11058481831150 := by decide
theorem cert_e2262388808942 : check e2262388808942 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388808950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262388808950 : Closed e2262388808950 ∧ code e2262388808950 = 11058481831158 := by decide
theorem cert_e2262388808950 : check e2262388808950 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388809334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262388809334 : Closed e2262388809334 ∧ code e2262388809334 = 11058481831542 := by decide
theorem cert_e2262388809334 : check e2262388809334 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388820846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262388820846 : Closed e2262388820846 ∧ code e2262388820846 = 11058481843054 := by decide
theorem cert_e2262388820846 : check e2262388820846 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388820854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262388820854 : Closed e2262388820854 ∧ code e2262388820854 = 11058481843062 := by decide
theorem cert_e2262388820854 : check e2262388820854 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388820910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262388820910 : Closed e2262388820910 ∧ code e2262388820910 = 11058481843118 := by decide
theorem cert_e2262388820910 : check e2262388820910 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388820922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262388820922 : Closed e2262388820922 ∧ code e2262388820922 = 11058481843130 := by decide
theorem cert_e2262388820922 : check e2262388820922 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388820950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262388820950 : Closed e2262388820950 ∧ code e2262388820950 = 11058481843158 := by decide
theorem cert_e2262388820950 : check e2262388820950 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388820954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262388820954 : Closed e2262388820954 ∧ code e2262388820954 = 11058481843162 := by decide
theorem cert_e2262388820954 : check e2262388820954 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388821230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262388821230 : Closed e2262388821230 ∧ code e2262388821230 = 11058481843438 := by decide
theorem cert_e2262388821230 : check e2262388821230 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388821238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262388821238 : Closed e2262388821238 ∧ code e2262388821238 = 11058481843446 := by decide
theorem cert_e2262388821238 : check e2262388821238 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388821614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262388821614 : Closed e2262388821614 ∧ code e2262388821614 = 11058481843822 := by decide
theorem cert_e2262388821614 : check e2262388821614 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388821626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262388821626 : Closed e2262388821626 ∧ code e2262388821626 = 11058481843834 := by decide
theorem cert_e2262388821626 : check e2262388821626 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388821814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262388821814 : Closed e2262388821814 ∧ code e2262388821814 = 11058481844022 := by decide
theorem cert_e2262388821814 : check e2262388821814 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388821818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262388821818 : Closed e2262388821818 ∧ code e2262388821818 = 11058481844026 := by decide
theorem cert_e2262388821818 : check e2262388821818 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388827574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2262388827574 : Closed e2262388827574 ∧ code e2262388827574 = 11058481849782 := by decide
theorem cert_e2262388827574 : check e2262388827574 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388827606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2262388827606 : Closed e2262388827606 ∧ code e2262388827606 = 11058481849814 := by decide
theorem cert_e2262388827606 : check e2262388827606 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388827610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2262388827610 : Closed e2262388827610 ∧ code e2262388827610 = 11058481849818 := by decide
theorem cert_e2262388827610 : check e2262388827610 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388827766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262388827766 : Closed e2262388827766 ∧ code e2262388827766 = 11058481849974 := by decide
theorem cert_e2262388827766 : check e2262388827766 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388827958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262388827958 : Closed e2262388827958 ∧ code e2262388827958 = 11058481850166 := by decide
theorem cert_e2262388827958 : check e2262388827958 [[],[.under],[.under,.under]] .three = true := by decide
def e2262388827962 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262388827962 : Closed e2262388827962 ∧ code e2262388827962 = 11058481850170 := by decide
theorem cert_e2262388827962 : check e2262388827962 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389164910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262389164910 : Closed e2262389164910 ∧ code e2262389164910 = 11058482187118 := by decide
theorem cert_e2262389164910 : check e2262389164910 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389164918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262389164918 : Closed e2262389164918 ∧ code e2262389164918 = 11058482187126 := by decide
private def t_e2262389164918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e2262389164918 : ¬ IsSelfInterpreter e2262389164918 :=
  wSource (t := t_e2262389164918) (replay_sound (ps := []) (t := e2262389164918) (by decide)) (by decide)
def e2262389164974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262389164974 : Closed e2262389164974 ∧ code e2262389164974 = 11058482187182 := by decide
theorem cert_e2262389164974 : check e2262389164974 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389164986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262389164986 : Closed e2262389164986 ∧ code e2262389164986 = 11058482187194 := by decide
theorem cert_e2262389164986 : check e2262389164986 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389165014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262389165014 : Closed e2262389165014 ∧ code e2262389165014 = 11058482187222 := by decide
private def t_e2262389165014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e2262389165014 : ¬ IsSelfInterpreter e2262389165014 :=
  wSource (t := t_e2262389165014) (replay_sound (ps := []) (t := e2262389165014) (by decide)) (by decide)
def e2262389165018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262389165018 : Closed e2262389165018 ∧ code e2262389165018 = 11058482187226 := by decide
theorem cert_e2262389165018 : check e2262389165018 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389165294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262389165294 : Closed e2262389165294 ∧ code e2262389165294 = 11058482187502 := by decide
theorem cert_e2262389165294 : check e2262389165294 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389165302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262389165302 : Closed e2262389165302 ∧ code e2262389165302 = 11058482187510 := by decide
theorem cert_e2262389165302 : check e2262389165302 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389165678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262389165678 : Closed e2262389165678 ∧ code e2262389165678 = 11058482187886 := by decide
theorem cert_e2262389165678 : check e2262389165678 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389165690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262389165690 : Closed e2262389165690 ∧ code e2262389165690 = 11058482187898 := by decide
theorem cert_e2262389165690 : check e2262389165690 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389165878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262389165878 : Closed e2262389165878 ∧ code e2262389165878 = 11058482188086 := by decide
theorem cert_e2262389165878 : check e2262389165878 [[],[.under],[.under,.under]] .three = true := by decide
def e2262389165882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262389165882 : Closed e2262389165882 ∧ code e2262389165882 = 11058482188090 := by decide
theorem cert_e2262389165882 : check e2262389165882 [[],[.under],[.under,.under]] .three = true := by decide
def e2262410988398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262410988398 : Closed e2262410988398 ∧ code e2262410988398 = 11058504010606 := by decide
theorem cert_e2262410988398 : check e2262410988398 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under],[.under]] .identityHead = true := by decide
def e2262410988406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262410988406 : Closed e2262410988406 ∧ code e2262410988406 = 11058504010614 := by decide
theorem cert_e2262410988406 : check e2262410988406 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262410988462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262410988462 : Closed e2262410988462 ∧ code e2262410988462 = 11058504010670 := by decide
theorem cert_e2262410988462 : check e2262410988462 [[.left,.left],[.left],[.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262410988474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262410988474 : Closed e2262410988474 ∧ code e2262410988474 = 11058504010682 := by decide
private def t_e2262410988474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2262410988474 : ¬ IsSelfInterpreter e2262410988474 :=
  wSource (t := t_e2262410988474) (replay_sound (ps := []) (t := e2262410988474) (by decide)) (by decide)
def e2262410988502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262410988502 : Closed e2262410988502 ∧ code e2262410988502 = 11058504010710 := by decide
theorem cert_e2262410988502 : check e2262410988502 [[],[.under],[.under],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2262410988506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262410988506 : Closed e2262410988506 ∧ code e2262410988506 = 11058504010714 := by decide
private def t_e2262410988506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2262410988506 : ¬ IsSelfInterpreter e2262410988506 :=
  wSource (t := t_e2262410988506) (replay_sound (ps := []) (t := e2262410988506) (by decide)) (by decide)
def e2262410988782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262410988782 : Closed e2262410988782 ∧ code e2262410988782 = 11058504010990 := by decide
theorem cert_e2262410988782 : check e2262410988782 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[],[]] .identityHead = true := by decide
def e2262410988790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262410988790 : Closed e2262410988790 ∧ code e2262410988790 = 11058504010998 := by decide
theorem cert_e2262410988790 : check e2262410988790 [[.left,.left],[.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[]] .identityHead = true := by decide
def e2262410989166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262410989166 : Closed e2262410989166 ∧ code e2262410989166 = 11058504011374 := by decide
theorem cert_e2262410989166 : check e2262410989166 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262410989178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262410989178 : Closed e2262410989178 ∧ code e2262410989178 = 11058504011386 := by decide
theorem cert_e2262410989178 : check e2262410989178 [[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2262410989366 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262410989366 : Closed e2262410989366 ∧ code e2262410989366 = 11058504011574 := by decide
theorem cert_e2262410989366 : check e2262410989366 [[],[.under],[.under],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2262410989370 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262410989370 : Closed e2262410989370 ∧ code e2262410989370 = 11058504011578 := by decide
theorem cert_e2262410989370 : check e2262410989370 [[],[.under],[.under],[.under],[.under,.under],[.under,.under],[.under,.under]] .three = true := by decide
def e2262420172218 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))))
theorem wire_e2262420172218 : Closed e2262420172218 ∧ code e2262420172218 = 11058513194426 := by decide
theorem cert_e2262420172218 : check e2262420172218 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420172250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))))
theorem wire_e2262420172250 : Closed e2262420172250 ∧ code e2262420172250 = 11058513194458 := by decide
theorem cert_e2262420172250 : check e2262420172250 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420172474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))))
theorem wire_e2262420172474 : Closed e2262420172474 ∧ code e2262420172474 = 11058513194682 := by decide
theorem cert_e2262420172474 : check e2262420172474 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420172522 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))))
theorem wire_e2262420172522 : Closed e2262420172522 ∧ code e2262420172522 = 11058513194730 := by decide
theorem cert_e2262420172522 : check e2262420172522 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420172634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))))
theorem wire_e2262420172634 : Closed e2262420172634 ∧ code e2262420172634 = 11058513194842 := by decide
theorem cert_e2262420172634 : check e2262420172634 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420172650 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))))
theorem wire_e2262420172650 : Closed e2262420172650 ∧ code e2262420172650 = 11058513194858 := by decide
theorem cert_e2262420172650 : check e2262420172650 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420173754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))))
theorem wire_e2262420173754 : Closed e2262420173754 ∧ code e2262420173754 = 11058513195962 := by decide
theorem cert_e2262420173754 : check e2262420173754 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420173786 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))))
theorem wire_e2262420173786 : Closed e2262420173786 ∧ code e2262420173786 = 11058513195994 := by decide
theorem cert_e2262420173786 : check e2262420173786 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420175290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))))
theorem wire_e2262420175290 : Closed e2262420175290 ∧ code e2262420175290 = 11058513197498 := by decide
theorem cert_e2262420175290 : check e2262420175290 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420175338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))))
theorem wire_e2262420175338 : Closed e2262420175338 ∧ code e2262420175338 = 11058513197546 := by decide
theorem cert_e2262420175338 : check e2262420175338 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420176090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))))
theorem wire_e2262420176090 : Closed e2262420176090 ∧ code e2262420176090 = 11058513198298 := by decide
theorem cert_e2262420176090 : check e2262420176090 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420176106 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))))
theorem wire_e2262420176106 : Closed e2262420176106 ∧ code e2262420176106 = 11058513198314 := by decide
theorem cert_e2262420176106 : check e2262420176106 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420207330 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e2262420207330 : Closed e2262420207330 ∧ code e2262420207330 = 11058513229538 := by decide
theorem cert_e2262420207330 : check e2262420207330 [[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[]] .identityHead = true := by decide
def e2262420207458 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e2262420207458 : Closed e2262420207458 ∧ code e2262420207458 = 11058513229666 := by decide
theorem cert_e2262420207458 : check e2262420207458 [[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262420208354 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.var 0)))))
theorem wire_e2262420208354 : Closed e2262420208354 ∧ code e2262420208354 = 11058513230562 := by decide
def e2262420208546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e2262420208546 : Closed e2262420208546 ∧ code e2262420208546 = 11058513230754 := by decide
private def t_e2262420208546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 0)))))
theorem cert_e2262420208546 : ¬ IsSelfInterpreter e2262420208546 :=
  wSource (t := t_e2262420208546) (replay_sound (ps := []) (t := e2262420208546) (by decide)) (by decide)
def e2262420208994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))))
theorem wire_e2262420208994 : Closed e2262420208994 ∧ code e2262420208994 = 11058513231202 := by decide
theorem cert_e2262420208994 : check e2262420208994 [[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2262420209058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))
theorem wire_e2262420209058 : Closed e2262420209058 ∧ code e2262420209058 = 11058513231266 := by decide
private def t_e2262420209058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))))
theorem cert_e2262420209058 : ¬ IsSelfInterpreter e2262420209058 :=
  wSource (t := t_e2262420209058) (replay_sound (ps := []) (t := e2262420209058) (by decide)) (by decide)
def e2262420213474 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e2262420213474 : Closed e2262420213474 ∧ code e2262420213474 = 11058513235682 := by decide
theorem cert_e2262420213474 : check e2262420213474 [[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[],[],[]] .identityHead = true := by decide
def e2262420213602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e2262420213602 : Closed e2262420213602 ∧ code e2262420213602 = 11058513235810 := by decide
theorem cert_e2262420213602 : check e2262420213602 [[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left],[],[],[]] .identityHead = true := by decide
def e2262420219618 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.var 0)))))
theorem wire_e2262420219618 : Closed e2262420219618 ∧ code e2262420219618 = 11058513241826 := by decide
theorem cert_e2262420219618 : check e2262420219618 [[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2262420219810 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e2262420219810 : Closed e2262420219810 ∧ code e2262420219810 = 11058513242018 := by decide
theorem cert_e2262420219810 : check e2262420219810 [[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2262420222818 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.var 0)))))
theorem wire_e2262420222818 : Closed e2262420222818 ∧ code e2262420222818 = 11058513245026 := by decide
theorem cert_e2262420222818 : check e2262420222818 [[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2262420222882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.var 0)))))
theorem wire_e2262420222882 : Closed e2262420222882 ∧ code e2262420222882 = 11058513245090 := by decide
def e2262420425582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2262420425582 : Closed e2262420425582 ∧ code e2262420425582 = 11058513447790 := by decide
theorem cert_e2262420425582 : check e2262420425582 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420425590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2262420425590 : Closed e2262420425590 ∧ code e2262420425590 = 11058513447798 := by decide
theorem cert_e2262420425590 : check e2262420425590 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420425646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2262420425646 : Closed e2262420425646 ∧ code e2262420425646 = 11058513447854 := by decide
theorem cert_e2262420425646 : check e2262420425646 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420425658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2262420425658 : Closed e2262420425658 ∧ code e2262420425658 = 11058513447866 := by decide
theorem cert_e2262420425658 : check e2262420425658 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420425686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2262420425686 : Closed e2262420425686 ∧ code e2262420425686 = 11058513447894 := by decide
theorem cert_e2262420425686 : check e2262420425686 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420425690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2262420425690 : Closed e2262420425690 ∧ code e2262420425690 = 11058513447898 := by decide
theorem cert_e2262420425690 : check e2262420425690 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420425966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2262420425966 : Closed e2262420425966 ∧ code e2262420425966 = 11058513448174 := by decide
theorem cert_e2262420425966 : check e2262420425966 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420425974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2262420425974 : Closed e2262420425974 ∧ code e2262420425974 = 11058513448182 := by decide
theorem cert_e2262420425974 : check e2262420425974 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420426350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2262420426350 : Closed e2262420426350 ∧ code e2262420426350 = 11058513448558 := by decide
theorem cert_e2262420426350 : check e2262420426350 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420426362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2262420426362 : Closed e2262420426362 ∧ code e2262420426362 = 11058513448570 := by decide
theorem cert_e2262420426362 : check e2262420426362 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420426550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2262420426550 : Closed e2262420426550 ∧ code e2262420426550 = 11058513448758 := by decide
theorem cert_e2262420426550 : check e2262420426550 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262420426554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2262420426554 : Closed e2262420426554 ∧ code e2262420426554 = 11058513448762 := by decide
theorem cert_e2262420426554 : check e2262420426554 [[],[.under],[.under,.left]] .chain = true := by decide
def e2262421212014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262421212014 : Closed e2262421212014 ∧ code e2262421212014 = 11058514234222 := by decide
private def t_e2262421212014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e2262421212014 : ¬ IsSelfInterpreter e2262421212014 :=
  wSource (t := t_e2262421212014) (replay_sound (ps := []) (t := e2262421212014) (by decide)) (by decide)
def e2262421212022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262421212022 : Closed e2262421212022 ∧ code e2262421212022 = 11058514234230 := by decide
private def t_e2262421212022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem cert_e2262421212022 : ¬ IsSelfInterpreter e2262421212022 :=
  wSource (t := t_e2262421212022) (replay_sound (ps := []) (t := e2262421212022) (by decide)) (by decide)
def e2262421212078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262421212078 : Closed e2262421212078 ∧ code e2262421212078 = 11058514234286 := by decide
private def t_e2262421212078 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e2262421212078 : ¬ IsSelfInterpreter e2262421212078 :=
  wSource (t := t_e2262421212078) (replay_sound (ps := []) (t := e2262421212078) (by decide)) (by decide)
def e2262421212090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262421212090 : Closed e2262421212090 ∧ code e2262421212090 = 11058514234298 := by decide
private def t_e2262421212090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2262421212090 : ¬ IsSelfInterpreter e2262421212090 :=
  wSource (t := t_e2262421212090) (replay_sound (ps := []) (t := e2262421212090) (by decide)) (by decide)
def e2262421212118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262421212118 : Closed e2262421212118 ∧ code e2262421212118 = 11058514234326 := by decide
private def t_e2262421212118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem cert_e2262421212118 : ¬ IsSelfInterpreter e2262421212118 :=
  wSource (t := t_e2262421212118) (replay_sound (ps := []) (t := e2262421212118) (by decide)) (by decide)
def e2262421212122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262421212122 : Closed e2262421212122 ∧ code e2262421212122 = 11058514234330 := by decide
private def t_e2262421212122 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2262421212122 : ¬ IsSelfInterpreter e2262421212122 :=
  wSource (t := t_e2262421212122) (replay_sound (ps := []) (t := e2262421212122) (by decide)) (by decide)
def e2262421212398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262421212398 : Closed e2262421212398 ∧ code e2262421212398 = 11058514234606 := by decide
private def t_e2262421212398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem cert_e2262421212398 : ¬ IsSelfInterpreter e2262421212398 :=
  wSource (t := t_e2262421212398) (replay_sound (ps := []) (t := e2262421212398) (by decide)) (by decide)
def e2262421212406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262421212406 : Closed e2262421212406 ∧ code e2262421212406 = 11058514234614 := by decide
private def t_e2262421212406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem cert_e2262421212406 : ¬ IsSelfInterpreter e2262421212406 :=
  wSource (t := t_e2262421212406) (replay_sound (ps := []) (t := e2262421212406) (by decide)) (by decide)
def e2262421212782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262421212782 : Closed e2262421212782 ∧ code e2262421212782 = 11058514234990 := by decide
private def t_e2262421212782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem cert_e2262421212782 : ¬ IsSelfInterpreter e2262421212782 :=
  wSource (t := t_e2262421212782) (replay_sound (ps := []) (t := e2262421212782) (by decide)) (by decide)
def e2262421212794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262421212794 : Closed e2262421212794 ∧ code e2262421212794 = 11058514235002 := by decide
private def t_e2262421212794 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem cert_e2262421212794 : ¬ IsSelfInterpreter e2262421212794 :=
  wSource (t := t_e2262421212794) (replay_sound (ps := []) (t := e2262421212794) (by decide)) (by decide)
def e2262421212982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262421212982 : Closed e2262421212982 ∧ code e2262421212982 = 11058514235190 := by decide
private def t_e2262421212982 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem cert_e2262421212982 : ¬ IsSelfInterpreter e2262421212982 :=
  wSource (t := t_e2262421212982) (replay_sound (ps := []) (t := e2262421212982) (by decide)) (by decide)
def e2262421212986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262421212986 : Closed e2262421212986 ∧ code e2262421212986 = 11058514235194 := by decide
private def t_e2262421212986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem cert_e2262421212986 : ¬ IsSelfInterpreter e2262421212986 :=
  wSource (t := t_e2262421212986) (replay_sound (ps := []) (t := e2262421212986) (by decide)) (by decide)
def e2262424366526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2262424366526 : Closed e2262424366526 ∧ code e2262424366526 = 11058517388734 := by decide
theorem cert_e2262424366526 : check e2262424366526 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424366582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2262424366582 : Closed e2262424366582 ∧ code e2262424366582 = 11058517388790 := by decide
theorem cert_e2262424366582 : check e2262424366582 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424366782 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2262424366782 : Closed e2262424366782 ∧ code e2262424366782 = 11058517388990 := by decide
theorem cert_e2262424366782 : check e2262424366782 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424366842 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2262424366842 : Closed e2262424366842 ∧ code e2262424366842 = 11058517389050 := by decide
theorem cert_e2262424366842 : check e2262424366842 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424367062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2262424367062 : Closed e2262424367062 ∧ code e2262424367062 = 11058517389270 := by decide
theorem cert_e2262424367062 : check e2262424367062 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424367066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2262424367066 : Closed e2262424367066 ∧ code e2262424367066 = 11058517389274 := by decide
theorem cert_e2262424367066 : check e2262424367066 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424368062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2262424368062 : Closed e2262424368062 ∧ code e2262424368062 = 11058517390270 := by decide
theorem cert_e2262424368062 : check e2262424368062 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424368118 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2262424368118 : Closed e2262424368118 ∧ code e2262424368118 = 11058517390326 := by decide
theorem cert_e2262424368118 : check e2262424368118 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424369598 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2262424369598 : Closed e2262424369598 ∧ code e2262424369598 = 11058517391806 := by decide
theorem cert_e2262424369598 : check e2262424369598 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424369658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2262424369658 : Closed e2262424369658 ∧ code e2262424369658 = 11058517391866 := by decide
theorem cert_e2262424369658 : check e2262424369658 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424370998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262424370998 : Closed e2262424370998 ∧ code e2262424370998 = 11058517393206 := by decide
theorem cert_e2262424370998 : check e2262424370998 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424371002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262424371002 : Closed e2262424371002 ∧ code e2262424371002 = 11058517393210 := by decide
theorem cert_e2262424371002 : check e2262424371002 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424399214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2262424399214 : Closed e2262424399214 ∧ code e2262424399214 = 11058517421422 := by decide
theorem cert_e2262424399214 : check e2262424399214 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399222 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2262424399222 : Closed e2262424399222 ∧ code e2262424399222 = 11058517421430 := by decide
theorem cert_e2262424399222 : check e2262424399222 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2262424399278 : Closed e2262424399278 ∧ code e2262424399278 = 11058517421486 := by decide
theorem cert_e2262424399278 : check e2262424399278 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2262424399290 : Closed e2262424399290 ∧ code e2262424399290 = 11058517421498 := by decide
theorem cert_e2262424399290 : check e2262424399290 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399318 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2262424399318 : Closed e2262424399318 ∧ code e2262424399318 = 11058517421526 := by decide
theorem cert_e2262424399318 : check e2262424399318 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2262424399322 : Closed e2262424399322 ∧ code e2262424399322 = 11058517421530 := by decide
theorem cert_e2262424399322 : check e2262424399322 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2262424399534 : Closed e2262424399534 ∧ code e2262424399534 = 11058517421742 := by decide
theorem cert_e2262424399534 : check e2262424399534 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2262424399546 : Closed e2262424399546 ∧ code e2262424399546 = 11058517421754 := by decide
theorem cert_e2262424399546 : check e2262424399546 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2262424399594 : Closed e2262424399594 ∧ code e2262424399594 = 11058517421802 := by decide
theorem cert_e2262424399594 : check e2262424399594 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2262424399702 : Closed e2262424399702 ∧ code e2262424399702 = 11058517421910 := by decide
theorem cert_e2262424399702 : check e2262424399702 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399706 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2262424399706 : Closed e2262424399706 ∧ code e2262424399706 = 11058517421914 := by decide
theorem cert_e2262424399706 : check e2262424399706 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424399722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2262424399722 : Closed e2262424399722 ∧ code e2262424399722 = 11058517421930 := by decide
theorem cert_e2262424399722 : check e2262424399722 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424400350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2262424400350 : Closed e2262424400350 ∧ code e2262424400350 = 11058517422558 := by decide
theorem cert_e2262424400350 : check e2262424400350 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424400374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2262424400374 : Closed e2262424400374 ∧ code e2262424400374 = 11058517422582 := by decide
theorem cert_e2262424400374 : check e2262424400374 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424400750 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2262424400750 : Closed e2262424400750 ∧ code e2262424400750 = 11058517422958 := by decide
theorem cert_e2262424400750 : check e2262424400750 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424400758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2262424400758 : Closed e2262424400758 ∧ code e2262424400758 = 11058517422966 := by decide
theorem cert_e2262424400758 : check e2262424400758 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424400814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2262424400814 : Closed e2262424400814 ∧ code e2262424400814 = 11058517423022 := by decide
theorem cert_e2262424400814 : check e2262424400814 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424400826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2262424400826 : Closed e2262424400826 ∧ code e2262424400826 = 11058517423034 := by decide
theorem cert_e2262424400826 : check e2262424400826 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424400854 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2262424400854 : Closed e2262424400854 ∧ code e2262424400854 = 11058517423062 := by decide
theorem cert_e2262424400854 : check e2262424400854 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424400858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2262424400858 : Closed e2262424400858 ∧ code e2262424400858 = 11058517423066 := by decide
theorem cert_e2262424400858 : check e2262424400858 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424401134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262424401134 : Closed e2262424401134 ∧ code e2262424401134 = 11058517423342 := by decide
theorem cert_e2262424401134 : check e2262424401134 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424401142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262424401142 : Closed e2262424401142 ∧ code e2262424401142 = 11058517423350 := by decide
theorem cert_e2262424401142 : check e2262424401142 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424401470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2262424401470 : Closed e2262424401470 ∧ code e2262424401470 = 11058517423678 := by decide
theorem cert_e2262424401470 : check e2262424401470 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424401518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262424401518 : Closed e2262424401518 ∧ code e2262424401518 = 11058517423726 := by decide
theorem cert_e2262424401518 : check e2262424401518 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424401530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262424401530 : Closed e2262424401530 ∧ code e2262424401530 = 11058517423738 := by decide
theorem cert_e2262424401530 : check e2262424401530 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424401718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262424401718 : Closed e2262424401718 ∧ code e2262424401718 = 11058517423926 := by decide
theorem cert_e2262424401718 : check e2262424401718 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424401722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262424401722 : Closed e2262424401722 ∧ code e2262424401722 = 11058517423930 := by decide
theorem cert_e2262424401722 : check e2262424401722 [[],[.under],[.under],[.under]] .smaller = true := by decide
def e2262424401806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2262424401806 : Closed e2262424401806 ∧ code e2262424401806 = 11058517424014 := by decide
theorem cert_e2262424401806 : check e2262424401806 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424402142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2262424402142 : Closed e2262424402142 ∧ code e2262424402142 = 11058517424350 := by decide
theorem cert_e2262424402142 : check e2262424402142 [[],[.under],[.under],[.under]] .three = true := by decide
def e2262424402170 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2262424402170 : Closed e2262424402170 ∧ code e2262424402170 = 11058517424378 := by decide
theorem cert_e2262424402170 : check e2262424402170 [[],[.under],[.under],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262388797046
#print axioms Blc.Floor43.cert_e2262388800118
#print axioms Blc.Floor43.cert_e2262389164918
#print axioms Blc.Floor43.cert_e2262389165014
#print axioms Blc.Floor43.cert_e2262410988474
#print axioms Blc.Floor43.cert_e2262410988506
#print axioms Blc.Floor43.cert_e2262420208546
#print axioms Blc.Floor43.cert_e2262420209058
#print axioms Blc.Floor43.cert_e2262421212014
#print axioms Blc.Floor43.cert_e2262421212022
#print axioms Blc.Floor43.cert_e2262421212078
#print axioms Blc.Floor43.cert_e2262421212090
#print axioms Blc.Floor43.cert_e2262421212118
#print axioms Blc.Floor43.cert_e2262421212122
#print axioms Blc.Floor43.cert_e2262421212398
#print axioms Blc.Floor43.cert_e2262421212406
#print axioms Blc.Floor43.cert_e2262421212782
#print axioms Blc.Floor43.cert_e2262421212794
#print axioms Blc.Floor43.cert_e2262421212982
#print axioms Blc.Floor43.cert_e2262421212986
