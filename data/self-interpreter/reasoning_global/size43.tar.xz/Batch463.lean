import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406601218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406601218 : Closed e2422406601218 ∧ code e2422406601218 = 11218499623426 := by decide
theorem cert_e2422406601218 : check e2422406601218 [[],[]] .chain = true := by decide
def e2422406601230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406601230 : Closed e2422406601230 ∧ code e2422406601230 = 11218499623438 := by decide
theorem cert_e2422406601230 : check e2422406601230 [[],[]] .chain = true := by decide
def e2422406601242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406601242 : Closed e2422406601242 ∧ code e2422406601242 = 11218499623450 := by decide
theorem cert_e2422406601242 : check e2422406601242 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406601314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406601314 : Closed e2422406601314 ∧ code e2422406601314 = 11218499623522 := by decide
theorem cert_e2422406601314 : check e2422406601314 [[],[]] .chain = true := by decide
def e2422406601326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406601326 : Closed e2422406601326 ∧ code e2422406601326 = 11218499623534 := by decide
theorem cert_e2422406601326 : check e2422406601326 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406601334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406601334 : Closed e2422406601334 ∧ code e2422406601334 = 11218499623542 := by decide
theorem cert_e2422406601334 : check e2422406601334 [[],[]] .chain = true := by decide
def e2422406601338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406601338 : Closed e2422406601338 ∧ code e2422406601338 = 11218499623546 := by decide
theorem cert_e2422406601338 : check e2422406601338 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406601478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406601478 : Closed e2422406601478 ∧ code e2422406601478 = 11218499623686 := by decide
theorem cert_e2422406601478 : check e2422406601478 [[],[]] .chain = true := by decide
def e2422406601502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406601502 : Closed e2422406601502 ∧ code e2422406601502 = 11218499623710 := by decide
theorem cert_e2422406601502 : check e2422406601502 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406601526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406601526 : Closed e2422406601526 ∧ code e2422406601526 = 11218499623734 := by decide
theorem cert_e2422406601526 : check e2422406601526 [[],[]] .chain = true := by decide
def e2422406601530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406601530 : Closed e2422406601530 ∧ code e2422406601530 = 11218499623738 := by decide
theorem cert_e2422406601530 : check e2422406601530 [[],[]] .chain = true := by decide
def e2422406601602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406601602 : Closed e2422406601602 ∧ code e2422406601602 = 11218499623810 := by decide
theorem cert_e2422406601602 : check e2422406601602 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406601614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406601614 : Closed e2422406601614 ∧ code e2422406601614 = 11218499623822 := by decide
theorem cert_e2422406601614 : check e2422406601614 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406601626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406601626 : Closed e2422406601626 ∧ code e2422406601626 = 11218499623834 := by decide
theorem cert_e2422406601626 : check e2422406601626 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406601750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406601750 : Closed e2422406601750 ∧ code e2422406601750 = 11218499623958 := by decide
theorem cert_e2422406601750 : check e2422406601750 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406601846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406601846 : Closed e2422406601846 ∧ code e2422406601846 = 11218499624054 := by decide
theorem cert_e2422406601846 : check e2422406601846 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406601942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406601942 : Closed e2422406601942 ∧ code e2422406601942 = 11218499624150 := by decide
theorem cert_e2422406601942 : check e2422406601942 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406601946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406601946 : Closed e2422406601946 ∧ code e2422406601946 = 11218499624154 := by decide
theorem cert_e2422406601946 : check e2422406601946 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406601962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406601962 : Closed e2422406601962 ∧ code e2422406601962 = 11218499624170 := by decide
theorem cert_e2422406601962 : check e2422406601962 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406602038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406602038 : Closed e2422406602038 ∧ code e2422406602038 = 11218499624246 := by decide
theorem cert_e2422406602038 : check e2422406602038 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406602042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406602042 : Closed e2422406602042 ∧ code e2422406602042 = 11218499624250 := by decide
theorem cert_e2422406602042 : check e2422406602042 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406602114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406602114 : Closed e2422406602114 ∧ code e2422406602114 = 11218499624322 := by decide
theorem cert_e2422406602114 : check e2422406602114 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406602126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406602126 : Closed e2422406602126 ∧ code e2422406602126 = 11218499624334 := by decide
theorem cert_e2422406602126 : check e2422406602126 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406602138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406602138 : Closed e2422406602138 ∧ code e2422406602138 = 11218499624346 := by decide
theorem cert_e2422406602138 : check e2422406602138 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406602794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422406602794 : Closed e2422406602794 ∧ code e2422406602794 = 11218499625002 := by decide
theorem cert_e2422406602794 : check e2422406602794 [[],[]] .chain = true := by decide
def e2422406602926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406602926 : Closed e2422406602926 ∧ code e2422406602926 = 11218499625134 := by decide
theorem cert_e2422406602926 : check e2422406602926 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406602938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406602938 : Closed e2422406602938 ∧ code e2422406602938 = 11218499625146 := by decide
theorem cert_e2422406602938 : check e2422406602938 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406602966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422406602966 : Closed e2422406602966 ∧ code e2422406602966 = 11218499625174 := by decide
theorem cert_e2422406602966 : check e2422406602966 [[],[]] .chain = true := by decide
def e2422406602970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422406602970 : Closed e2422406602970 ∧ code e2422406602970 = 11218499625178 := by decide
theorem cert_e2422406602970 : check e2422406602970 [[],[]] .chain = true := by decide
def e2422406602986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422406602986 : Closed e2422406602986 ∧ code e2422406602986 = 11218499625194 := by decide
theorem cert_e2422406602986 : check e2422406602986 [[],[]] .chain = true := by decide
def e2422406603178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406603178 : Closed e2422406603178 ∧ code e2422406603178 = 11218499625386 := by decide
theorem cert_e2422406603178 : check e2422406603178 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406603318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406603318 : Closed e2422406603318 ∧ code e2422406603318 = 11218499625526 := by decide
theorem cert_e2422406603318 : check e2422406603318 [[],[]] .chain = true := by decide
def e2422406603322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406603322 : Closed e2422406603322 ∧ code e2422406603322 = 11218499625530 := by decide
theorem cert_e2422406603322 : check e2422406603322 [[],[]] .chain = true := by decide
def e2422406603370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422406603370 : Closed e2422406603370 ∧ code e2422406603370 = 11218499625578 := by decide
theorem cert_e2422406603370 : check e2422406603370 [[],[]] .chain = true := by decide
def e2422406603406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406603406 : Closed e2422406603406 ∧ code e2422406603406 = 11218499625614 := by decide
theorem cert_e2422406603406 : check e2422406603406 [[],[]] .chain = true := by decide
def e2422406603418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406603418 : Closed e2422406603418 ∧ code e2422406603418 = 11218499625626 := by decide
theorem cert_e2422406603418 : check e2422406603418 [[],[]] .chain = true := by decide
def e2422406603462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406603462 : Closed e2422406603462 ∧ code e2422406603462 = 11218499625670 := by decide
theorem cert_e2422406603462 : check e2422406603462 [[],[]] .chain = true := by decide
def e2422406603542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406603542 : Closed e2422406603542 ∧ code e2422406603542 = 11218499625750 := by decide
theorem cert_e2422406603542 : check e2422406603542 [[],[]] .chain = true := by decide
def e2422406603546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406603546 : Closed e2422406603546 ∧ code e2422406603546 = 11218499625754 := by decide
theorem cert_e2422406603546 : check e2422406603546 [[],[]] .chain = true := by decide
def e2422406603590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406603590 : Closed e2422406603590 ∧ code e2422406603590 = 11218499625798 := by decide
theorem cert_e2422406603590 : check e2422406603590 [[],[]] .chain = true := by decide
def e2422406603618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406603618 : Closed e2422406603618 ∧ code e2422406603618 = 11218499625826 := by decide
theorem cert_e2422406603618 : check e2422406603618 [[],[]] .chain = true := by decide
def e2422406603630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406603630 : Closed e2422406603630 ∧ code e2422406603630 = 11218499625838 := by decide
theorem cert_e2422406603630 : check e2422406603630 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406603638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406603638 : Closed e2422406603638 ∧ code e2422406603638 = 11218499625846 := by decide
theorem cert_e2422406603638 : check e2422406603638 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406603658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406603658 : Closed e2422406603658 ∧ code e2422406603658 = 11218499625866 := by decide
theorem cert_e2422406603658 : check e2422406603658 [[],[]] .chain = true := by decide
def e2422406603682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406603682 : Closed e2422406603682 ∧ code e2422406603682 = 11218499625890 := by decide
theorem cert_e2422406603682 : check e2422406603682 [[],[]] .chain = true := by decide
def e2422406603694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406603694 : Closed e2422406603694 ∧ code e2422406603694 = 11218499625902 := by decide
theorem cert_e2422406603694 : check e2422406603694 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406603706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406603706 : Closed e2422406603706 ∧ code e2422406603706 = 11218499625914 := by decide
theorem cert_e2422406603706 : check e2422406603706 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406603734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2422406603734 : Closed e2422406603734 ∧ code e2422406603734 = 11218499625942 := by decide
theorem cert_e2422406603734 : check e2422406603734 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406603738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2422406603738 : Closed e2422406603738 ∧ code e2422406603738 = 11218499625946 := by decide
theorem cert_e2422406603738 : check e2422406603738 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406604330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406604330 : Closed e2422406604330 ∧ code e2422406604330 = 11218499626538 := by decide
theorem cert_e2422406604330 : check e2422406604330 [[],[]] .chain = true := by decide
def e2422406604426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406604426 : Closed e2422406604426 ∧ code e2422406604426 = 11218499626634 := by decide
theorem cert_e2422406604426 : check e2422406604426 [[],[]] .chain = true := by decide
def e2422406604450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406604450 : Closed e2422406604450 ∧ code e2422406604450 = 11218499626658 := by decide
theorem cert_e2422406604450 : check e2422406604450 [[],[]] .chain = true := by decide
def e2422406604462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406604462 : Closed e2422406604462 ∧ code e2422406604462 = 11218499626670 := by decide
theorem cert_e2422406604462 : check e2422406604462 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406604470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406604470 : Closed e2422406604470 ∧ code e2422406604470 = 11218499626678 := by decide
theorem cert_e2422406604470 : check e2422406604470 [[],[]] .chain = true := by decide
def e2422406604474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406604474 : Closed e2422406604474 ∧ code e2422406604474 = 11218499626682 := by decide
theorem cert_e2422406604474 : check e2422406604474 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406604502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406604502 : Closed e2422406604502 ∧ code e2422406604502 = 11218499626710 := by decide
theorem cert_e2422406604502 : check e2422406604502 [[],[]] .chain = true := by decide
def e2422406604506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406604506 : Closed e2422406604506 ∧ code e2422406604506 = 11218499626714 := by decide
theorem cert_e2422406604506 : check e2422406604506 [[],[]] .chain = true := by decide
def e2422406604522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406604522 : Closed e2422406604522 ∧ code e2422406604522 = 11218499626730 := by decide
theorem cert_e2422406604522 : check e2422406604522 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406604630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406604630 : Closed e2422406604630 ∧ code e2422406604630 = 11218499626838 := by decide
theorem cert_e2422406604630 : check e2422406604630 [[],[]] .chain = true := by decide
def e2422406604634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406604634 : Closed e2422406604634 ∧ code e2422406604634 = 11218499626842 := by decide
theorem cert_e2422406604634 : check e2422406604634 [[],[]] .chain = true := by decide
def e2422406604650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406604650 : Closed e2422406604650 ∧ code e2422406604650 = 11218499626858 := by decide
theorem cert_e2422406604650 : check e2422406604650 [[],[]] .chain = true := by decide
def e2422406604714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406604714 : Closed e2422406604714 ∧ code e2422406604714 = 11218499626922 := by decide
theorem cert_e2422406604714 : check e2422406604714 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406604810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406604810 : Closed e2422406604810 ∧ code e2422406604810 = 11218499627018 := by decide
theorem cert_e2422406604810 : check e2422406604810 [[],[]] .chain = true := by decide
def e2422406604846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406604846 : Closed e2422406604846 ∧ code e2422406604846 = 11218499627054 := by decide
theorem cert_e2422406604846 : check e2422406604846 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406604854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406604854 : Closed e2422406604854 ∧ code e2422406604854 = 11218499627062 := by decide
theorem cert_e2422406604854 : check e2422406604854 [[],[]] .chain = true := by decide
def e2422406604858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406604858 : Closed e2422406604858 ∧ code e2422406604858 = 11218499627066 := by decide
theorem cert_e2422406604858 : check e2422406604858 [[],[]] .chain = true := by decide
def e2422406604906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406604906 : Closed e2422406604906 ∧ code e2422406604906 = 11218499627114 := by decide
theorem cert_e2422406604906 : check e2422406604906 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406604942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406604942 : Closed e2422406604942 ∧ code e2422406604942 = 11218499627150 := by decide
theorem cert_e2422406604942 : check e2422406604942 [[],[]] .chain = true := by decide
def e2422406604954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406604954 : Closed e2422406604954 ∧ code e2422406604954 = 11218499627162 := by decide
theorem cert_e2422406604954 : check e2422406604954 [[],[]] .chain = true := by decide
def e2422406604998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406604998 : Closed e2422406604998 ∧ code e2422406604998 = 11218499627206 := by decide
theorem cert_e2422406604998 : check e2422406604998 [[],[]] .chain = true := by decide
def e2422406605026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406605026 : Closed e2422406605026 ∧ code e2422406605026 = 11218499627234 := by decide
theorem cert_e2422406605026 : check e2422406605026 [[],[]] .chain = true := by decide
def e2422406605038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406605038 : Closed e2422406605038 ∧ code e2422406605038 = 11218499627246 := by decide
theorem cert_e2422406605038 : check e2422406605038 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406605046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406605046 : Closed e2422406605046 ∧ code e2422406605046 = 11218499627254 := by decide
theorem cert_e2422406605046 : check e2422406605046 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406605194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406605194 : Closed e2422406605194 ∧ code e2422406605194 = 11218499627402 := by decide
theorem cert_e2422406605194 : check e2422406605194 [[],[]] .chain = true := by decide
def e2422406605218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406605218 : Closed e2422406605218 ∧ code e2422406605218 = 11218499627426 := by decide
theorem cert_e2422406605218 : check e2422406605218 [[],[]] .chain = true := by decide
def e2422406605230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406605230 : Closed e2422406605230 ∧ code e2422406605230 = 11218499627438 := by decide
theorem cert_e2422406605230 : check e2422406605230 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406605238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406605238 : Closed e2422406605238 ∧ code e2422406605238 = 11218499627446 := by decide
theorem cert_e2422406605238 : check e2422406605238 [[],[]] .chain = true := by decide
def e2422406605242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406605242 : Closed e2422406605242 ∧ code e2422406605242 = 11218499627450 := by decide
theorem cert_e2422406605242 : check e2422406605242 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406605270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406605270 : Closed e2422406605270 ∧ code e2422406605270 = 11218499627478 := by decide
theorem cert_e2422406605270 : check e2422406605270 [[],[]] .chain = true := by decide
def e2422406605274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406605274 : Closed e2422406605274 ∧ code e2422406605274 = 11218499627482 := by decide
theorem cert_e2422406605274 : check e2422406605274 [[],[]] .chain = true := by decide
def e2422406605290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406605290 : Closed e2422406605290 ∧ code e2422406605290 = 11218499627498 := by decide
theorem cert_e2422406605290 : check e2422406605290 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406605314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406605314 : Closed e2422406605314 ∧ code e2422406605314 = 11218499627522 := by decide
theorem cert_e2422406605314 : check e2422406605314 [[],[]] .chain = true := by decide
def e2422406605326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406605326 : Closed e2422406605326 ∧ code e2422406605326 = 11218499627534 := by decide
theorem cert_e2422406605326 : check e2422406605326 [[],[]] .chain = true := by decide
def e2422406605338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406605338 : Closed e2422406605338 ∧ code e2422406605338 = 11218499627546 := by decide
theorem cert_e2422406605338 : check e2422406605338 [[],[],[.under,.under,.left,.left,.left]] .width = true := by decide
def e2422406605410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406605410 : Closed e2422406605410 ∧ code e2422406605410 = 11218499627618 := by decide
theorem cert_e2422406605410 : check e2422406605410 [[],[]] .chain = true := by decide
def e2422406605422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406605422 : Closed e2422406605422 ∧ code e2422406605422 = 11218499627630 := by decide
theorem cert_e2422406605422 : check e2422406605422 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406605430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406605430 : Closed e2422406605430 ∧ code e2422406605430 = 11218499627638 := by decide
theorem cert_e2422406605430 : check e2422406605430 [[],[]] .chain = true := by decide
def e2422406605434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406605434 : Closed e2422406605434 ∧ code e2422406605434 = 11218499627642 := by decide
theorem cert_e2422406605434 : check e2422406605434 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422406605574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406605574 : Closed e2422406605574 ∧ code e2422406605574 = 11218499627782 := by decide
theorem cert_e2422406605574 : check e2422406605574 [[],[]] .chain = true := by decide
def e2422406605598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406605598 : Closed e2422406605598 ∧ code e2422406605598 = 11218499627806 := by decide
theorem cert_e2422406605598 : check e2422406605598 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406605622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406605622 : Closed e2422406605622 ∧ code e2422406605622 = 11218499627830 := by decide
theorem cert_e2422406605622 : check e2422406605622 [[],[]] .chain = true := by decide
def e2422406605626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406605626 : Closed e2422406605626 ∧ code e2422406605626 = 11218499627834 := by decide
theorem cert_e2422406605626 : check e2422406605626 [[],[]] .chain = true := by decide
def e2422406605698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406605698 : Closed e2422406605698 ∧ code e2422406605698 = 11218499627906 := by decide
theorem cert_e2422406605698 : check e2422406605698 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406605710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406605710 : Closed e2422406605710 ∧ code e2422406605710 = 11218499627918 := by decide
theorem cert_e2422406605710 : check e2422406605710 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406605722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406605722 : Closed e2422406605722 ∧ code e2422406605722 = 11218499627930 := by decide
theorem cert_e2422406605722 : check e2422406605722 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406605850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422406605850 : Closed e2422406605850 ∧ code e2422406605850 = 11218499628058 := by decide
theorem cert_e2422406605850 : check e2422406605850 [[],[]] .chain = true := by decide
def e2422406605894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422406605894 : Closed e2422406605894 ∧ code e2422406605894 = 11218499628102 := by decide
theorem cert_e2422406605894 : check e2422406605894 [[],[]] .chain = true := by decide
def e2422406605922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406605922 : Closed e2422406605922 ∧ code e2422406605922 = 11218499628130 := by decide
theorem cert_e2422406605922 : check e2422406605922 [[],[]] .chain = true := by decide
def e2422406605934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406605934 : Closed e2422406605934 ∧ code e2422406605934 = 11218499628142 := by decide
theorem cert_e2422406605934 : check e2422406605934 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406605946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406605946 : Closed e2422406605946 ∧ code e2422406605946 = 11218499628154 := by decide
theorem cert_e2422406605946 : check e2422406605946 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406606038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406606038 : Closed e2422406606038 ∧ code e2422406606038 = 11218499628246 := by decide
theorem cert_e2422406606038 : check e2422406606038 [[],[]] .chain = true := by decide
def e2422406606042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406606042 : Closed e2422406606042 ∧ code e2422406606042 = 11218499628250 := by decide
theorem cert_e2422406606042 : check e2422406606042 [[],[]] .chain = true := by decide
def e2422406606058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406606058 : Closed e2422406606058 ∧ code e2422406606058 = 11218499628266 := by decide
theorem cert_e2422406606058 : check e2422406606058 [[],[]] .chain = true := by decide
def e2422406606086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406606086 : Closed e2422406606086 ∧ code e2422406606086 = 11218499628294 := by decide
theorem cert_e2422406606086 : check e2422406606086 [[],[]] .chain = true := by decide
def e2422406606110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406606110 : Closed e2422406606110 ∧ code e2422406606110 = 11218499628318 := by decide
theorem cert_e2422406606110 : check e2422406606110 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406606134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406606134 : Closed e2422406606134 ∧ code e2422406606134 = 11218499628342 := by decide
theorem cert_e2422406606134 : check e2422406606134 [[],[]] .chain = true := by decide
def e2422406606138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406606138 : Closed e2422406606138 ∧ code e2422406606138 = 11218499628346 := by decide
theorem cert_e2422406606138 : check e2422406606138 [[],[]] .chain = true := by decide
def e2422406606234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406606234 : Closed e2422406606234 ∧ code e2422406606234 = 11218499628442 := by decide
theorem cert_e2422406606234 : check e2422406606234 [[],[]] .chain = true := by decide
def e2422406606278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406606278 : Closed e2422406606278 ∧ code e2422406606278 = 11218499628486 := by decide
theorem cert_e2422406606278 : check e2422406606278 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406606346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406606346 : Closed e2422406606346 ∧ code e2422406606346 = 11218499628554 := by decide
theorem cert_e2422406606346 : check e2422406606346 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406606390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406606390 : Closed e2422406606390 ∧ code e2422406606390 = 11218499628598 := by decide
theorem cert_e2422406606390 : check e2422406606390 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406606394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406606394 : Closed e2422406606394 ∧ code e2422406606394 = 11218499628602 := by decide
theorem cert_e2422406606394 : check e2422406606394 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406606442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422406606442 : Closed e2422406606442 ∧ code e2422406606442 = 11218499628650 := by decide
theorem cert_e2422406606442 : check e2422406606442 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406606466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406606466 : Closed e2422406606466 ∧ code e2422406606466 = 11218499628674 := by decide
theorem cert_e2422406606466 : check e2422406606466 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406606478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406606478 : Closed e2422406606478 ∧ code e2422406606478 = 11218499628686 := by decide
theorem cert_e2422406606478 : check e2422406606478 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406606490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406606490 : Closed e2422406606490 ∧ code e2422406606490 = 11218499628698 := by decide
theorem cert_e2422406606490 : check e2422406606490 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406606534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406606534 : Closed e2422406606534 ∧ code e2422406606534 = 11218499628742 := by decide
theorem cert_e2422406606534 : check e2422406606534 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2422406606934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406606934 : Closed e2422406606934 ∧ code e2422406606934 = 11218499629142 := by decide
private def t_e2422406606934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem cert_e2422406606934 : ¬ IsSelfInterpreter e2422406606934 :=
  wSource (t := t_e2422406606934) (replay_sound (ps := []) (t := e2422406606934) (by decide)) (by decide)
def e2422406606938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406606938 : Closed e2422406606938 ∧ code e2422406606938 = 11218499629146 := by decide
private def t_e2422406606938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem cert_e2422406606938 : ¬ IsSelfInterpreter e2422406606938 :=
  wSource (t := t_e2422406606938) (replay_sound (ps := []) (t := e2422406606938) (by decide)) (by decide)
def e2422406607286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422406607286 : Closed e2422406607286 ∧ code e2422406607286 = 11218499629494 := by decide
private def t_e2422406607286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem cert_e2422406607286 : ¬ IsSelfInterpreter e2422406607286 :=
  wSource (t := t_e2422406607286) (replay_sound (ps := []) (t := e2422406607286) (by decide)) (by decide)
def e2422406607318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406607318 : Closed e2422406607318 ∧ code e2422406607318 = 11218499629526 := by decide
private def t_e2422406607318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem cert_e2422406607318 : ¬ IsSelfInterpreter e2422406607318 :=
  wSource (t := t_e2422406607318) (replay_sound (ps := []) (t := e2422406607318) (by decide)) (by decide)
def e2422406607322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406607322 : Closed e2422406607322 ∧ code e2422406607322 = 11218499629530 := by decide
private def t_e2422406607322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem cert_e2422406607322 : ¬ IsSelfInterpreter e2422406607322 :=
  wSource (t := t_e2422406607322) (replay_sound (ps := []) (t := e2422406607322) (by decide)) (by decide)
def e2422406607702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406607702 : Closed e2422406607702 ∧ code e2422406607702 = 11218499629910 := by decide
private def t_e2422406607702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem cert_e2422406607702 : ¬ IsSelfInterpreter e2422406607702 :=
  wSource (t := t_e2422406607702) (replay_sound (ps := []) (t := e2422406607702) (by decide)) (by decide)
def e2422406607706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406607706 : Closed e2422406607706 ∧ code e2422406607706 = 11218499629914 := by decide
private def t_e2422406607706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem cert_e2422406607706 : ¬ IsSelfInterpreter e2422406607706 :=
  wSource (t := t_e2422406607706) (replay_sound (ps := []) (t := e2422406607706) (by decide)) (by decide)
def e2422406607722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406607722 : Closed e2422406607722 ∧ code e2422406607722 = 11218499629930 := by decide
private def t_e2422406607722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem cert_e2422406607722 : ¬ IsSelfInterpreter e2422406607722 :=
  wSource (t := t_e2422406607722) (replay_sound (ps := []) (t := e2422406607722) (by decide)) (by decide)
def e2422406607786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406607786 : Closed e2422406607786 ∧ code e2422406607786 = 11218499629994 := by decide
private def t_e2422406607786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem cert_e2422406607786 : ¬ IsSelfInterpreter e2422406607786 :=
  wSource (t := t_e2422406607786) (replay_sound (ps := []) (t := e2422406607786) (by decide)) (by decide)
def e2422406607894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406607894 : Closed e2422406607894 ∧ code e2422406607894 = 11218499630102 := by decide
private def t_e2422406607894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))
theorem cert_e2422406607894 : ¬ IsSelfInterpreter e2422406607894 :=
  wSource (t := t_e2422406607894) (replay_sound (ps := []) (t := e2422406607894) (by decide)) (by decide)
def e2422406607990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406607990 : Closed e2422406607990 ∧ code e2422406607990 = 11218499630198 := by decide
private def t_e2422406607990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem cert_e2422406607990 : ¬ IsSelfInterpreter e2422406607990 :=
  wSource (t := t_e2422406607990) (replay_sound (ps := []) (t := e2422406607990) (by decide)) (by decide)
def e2422406608086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406608086 : Closed e2422406608086 ∧ code e2422406608086 = 11218499630294 := by decide
private def t_e2422406608086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem cert_e2422406608086 : ¬ IsSelfInterpreter e2422406608086 :=
  wSource (t := t_e2422406608086) (replay_sound (ps := []) (t := e2422406608086) (by decide)) (by decide)
def e2422406608090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406608090 : Closed e2422406608090 ∧ code e2422406608090 = 11218499630298 := by decide
private def t_e2422406608090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem cert_e2422406608090 : ¬ IsSelfInterpreter e2422406608090 :=
  wSource (t := t_e2422406608090) (replay_sound (ps := []) (t := e2422406608090) (by decide)) (by decide)
def e2422406608106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406608106 : Closed e2422406608106 ∧ code e2422406608106 = 11218499630314 := by decide
private def t_e2422406608106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem cert_e2422406608106 : ¬ IsSelfInterpreter e2422406608106 :=
  wSource (t := t_e2422406608106) (replay_sound (ps := []) (t := e2422406608106) (by decide)) (by decide)
def e2422406608182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406608182 : Closed e2422406608182 ∧ code e2422406608182 = 11218499630390 := by decide
private def t_e2422406608182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem cert_e2422406608182 : ¬ IsSelfInterpreter e2422406608182 :=
  wSource (t := t_e2422406608182) (replay_sound (ps := []) (t := e2422406608182) (by decide)) (by decide)
def e2422406608186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406608186 : Closed e2422406608186 ∧ code e2422406608186 = 11218499630394 := by decide
private def t_e2422406608186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem cert_e2422406608186 : ¬ IsSelfInterpreter e2422406608186 :=
  wSource (t := t_e2422406608186) (replay_sound (ps := []) (t := e2422406608186) (by decide)) (by decide)
def e2422406608258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406608258 : Closed e2422406608258 ∧ code e2422406608258 = 11218499630466 := by decide
private def t_e2422406608258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))
theorem cert_e2422406608258 : ¬ IsSelfInterpreter e2422406608258 :=
  wSource (t := t_e2422406608258) (replay_sound (ps := []) (t := e2422406608258) (by decide)) (by decide)
def e2422406608270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406608270 : Closed e2422406608270 ∧ code e2422406608270 = 11218499630478 := by decide
private def t_e2422406608270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem cert_e2422406608270 : ¬ IsSelfInterpreter e2422406608270 :=
  wSource (t := t_e2422406608270) (replay_sound (ps := []) (t := e2422406608270) (by decide)) (by decide)
def e2422406608282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406608282 : Closed e2422406608282 ∧ code e2422406608282 = 11218499630490 := by decide
private def t_e2422406608282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem cert_e2422406608282 : ¬ IsSelfInterpreter e2422406608282 :=
  wSource (t := t_e2422406608282) (replay_sound (ps := []) (t := e2422406608282) (by decide)) (by decide)
def e2422406608394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406608394 : Closed e2422406608394 ∧ code e2422406608394 = 11218499630602 := by decide
private def t_e2422406608394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem cert_e2422406608394 : ¬ IsSelfInterpreter e2422406608394 :=
  wSource (t := t_e2422406608394) (replay_sound (ps := []) (t := e2422406608394) (by decide)) (by decide)
def e2422406608438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406608438 : Closed e2422406608438 ∧ code e2422406608438 = 11218499630646 := by decide
private def t_e2422406608438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem cert_e2422406608438 : ¬ IsSelfInterpreter e2422406608438 :=
  wSource (t := t_e2422406608438) (replay_sound (ps := []) (t := e2422406608438) (by decide)) (by decide)
def e2422406608442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406608442 : Closed e2422406608442 ∧ code e2422406608442 = 11218499630650 := by decide
private def t_e2422406608442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem cert_e2422406608442 : ¬ IsSelfInterpreter e2422406608442 :=
  wSource (t := t_e2422406608442) (replay_sound (ps := []) (t := e2422406608442) (by decide)) (by decide)
def e2422406608490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422406608490 : Closed e2422406608490 ∧ code e2422406608490 = 11218499630698 := by decide
private def t_e2422406608490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem cert_e2422406608490 : ¬ IsSelfInterpreter e2422406608490 :=
  wSource (t := t_e2422406608490) (replay_sound (ps := []) (t := e2422406608490) (by decide)) (by decide)
def e2422406608514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406608514 : Closed e2422406608514 ∧ code e2422406608514 = 11218499630722 := by decide
private def t_e2422406608514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem cert_e2422406608514 : ¬ IsSelfInterpreter e2422406608514 :=
  wSource (t := t_e2422406608514) (replay_sound (ps := []) (t := e2422406608514) (by decide)) (by decide)
def e2422406608526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406608526 : Closed e2422406608526 ∧ code e2422406608526 = 11218499630734 := by decide
private def t_e2422406608526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem cert_e2422406608526 : ¬ IsSelfInterpreter e2422406608526 :=
  wSource (t := t_e2422406608526) (replay_sound (ps := []) (t := e2422406608526) (by decide)) (by decide)
def e2422406608538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406608538 : Closed e2422406608538 ∧ code e2422406608538 = 11218499630746 := by decide
private def t_e2422406608538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem cert_e2422406608538 : ¬ IsSelfInterpreter e2422406608538 :=
  wSource (t := t_e2422406608538) (replay_sound (ps := []) (t := e2422406608538) (by decide)) (by decide)
def e2422406608582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406608582 : Closed e2422406608582 ∧ code e2422406608582 = 11218499630790 := by decide
private def t_e2422406608582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem cert_e2422406608582 : ¬ IsSelfInterpreter e2422406608582 :=
  wSource (t := t_e2422406608582) (replay_sound (ps := []) (t := e2422406608582) (by decide)) (by decide)
def e2422406647150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1)) (.var 2))))))
theorem wire_e2422406647150 : Closed e2422406647150 ∧ code e2422406647150 = 11218499669358 := by decide
theorem cert_e2422406647150 : checkPay e2422406647150 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] 0 [] = true := by decide
def e2422406647158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2)) (.var 1))))))
theorem wire_e2422406647158 : Closed e2422406647158 ∧ code e2422406647158 = 11218499669366 := by decide
theorem cert_e2422406647158 : check e2422406647158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422406648686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406648686 : Closed e2422406648686 ∧ code e2422406648686 = 11218499670894 := by decide
theorem cert_e2422406648686 : check e2422406648686 [[],[]] .chain = true := by decide
def e2422406648694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406648694 : Closed e2422406648694 ∧ code e2422406648694 = 11218499670902 := by decide
theorem cert_e2422406648694 : check e2422406648694 [[],[]] .chain = true := by decide
def e2422406648750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406648750 : Closed e2422406648750 ∧ code e2422406648750 = 11218499670958 := by decide
theorem cert_e2422406648750 : check e2422406648750 [[],[]] .chain = true := by decide
def e2422406648762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406648762 : Closed e2422406648762 ∧ code e2422406648762 = 11218499670970 := by decide
theorem cert_e2422406648762 : check e2422406648762 [[],[]] .chain = true := by decide
def e2422406648790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406648790 : Closed e2422406648790 ∧ code e2422406648790 = 11218499670998 := by decide
theorem cert_e2422406648790 : check e2422406648790 [[],[]] .chain = true := by decide
def e2422406648794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406648794 : Closed e2422406648794 ∧ code e2422406648794 = 11218499671002 := by decide
theorem cert_e2422406648794 : check e2422406648794 [[],[]] .chain = true := by decide
def e2422406649070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406649070 : Closed e2422406649070 ∧ code e2422406649070 = 11218499671278 := by decide
theorem cert_e2422406649070 : check e2422406649070 [[],[]] .chain = true := by decide
def e2422406649078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406649078 : Closed e2422406649078 ∧ code e2422406649078 = 11218499671286 := by decide
theorem cert_e2422406649078 : check e2422406649078 [[],[]] .chain = true := by decide
def e2422406649454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406649454 : Closed e2422406649454 ∧ code e2422406649454 = 11218499671662 := by decide
theorem cert_e2422406649454 : check e2422406649454 [[],[]] .chain = true := by decide
def e2422406649466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406649466 : Closed e2422406649466 ∧ code e2422406649466 = 11218499671674 := by decide
theorem cert_e2422406649466 : check e2422406649466 [[],[]] .chain = true := by decide
def e2422406649654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406649654 : Closed e2422406649654 ∧ code e2422406649654 = 11218499671862 := by decide
theorem cert_e2422406649654 : check e2422406649654 [[],[]] .chain = true := by decide
def e2422406649658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406649658 : Closed e2422406649658 ∧ code e2422406649658 = 11218499671866 := by decide
theorem cert_e2422406649658 : check e2422406649658 [[],[]] .chain = true := by decide
def e2422406651758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 1)) (.var 2))))))
theorem wire_e2422406651758 : Closed e2422406651758 ∧ code e2422406651758 = 11218499673966 := by decide
theorem cert_e2422406651758 : check e2422406651758 [[],[]] .chain = true := by decide
def e2422406651766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 4))))) (.var 2)) (.var 1))))))
theorem wire_e2422406651766 : Closed e2422406651766 ∧ code e2422406651766 = 11218499673974 := by decide
theorem cert_e2422406651766 : check e2422406651766 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422406606934
#print axioms Blc.Floor43.cert_e2422406606938
#print axioms Blc.Floor43.cert_e2422406607286
#print axioms Blc.Floor43.cert_e2422406607318
#print axioms Blc.Floor43.cert_e2422406607322
#print axioms Blc.Floor43.cert_e2422406607702
#print axioms Blc.Floor43.cert_e2422406607706
#print axioms Blc.Floor43.cert_e2422406607722
#print axioms Blc.Floor43.cert_e2422406607786
#print axioms Blc.Floor43.cert_e2422406607894
#print axioms Blc.Floor43.cert_e2422406607990
#print axioms Blc.Floor43.cert_e2422406608086
#print axioms Blc.Floor43.cert_e2422406608090
#print axioms Blc.Floor43.cert_e2422406608106
#print axioms Blc.Floor43.cert_e2422406608182
#print axioms Blc.Floor43.cert_e2422406608186
#print axioms Blc.Floor43.cert_e2422406608258
#print axioms Blc.Floor43.cert_e2422406608270
#print axioms Blc.Floor43.cert_e2422406608282
#print axioms Blc.Floor43.cert_e2422406608394
#print axioms Blc.Floor43.cert_e2422406608438
#print axioms Blc.Floor43.cert_e2422406608442
#print axioms Blc.Floor43.cert_e2422406608490
#print axioms Blc.Floor43.cert_e2422406608514
#print axioms Blc.Floor43.cert_e2422406608526
#print axioms Blc.Floor43.cert_e2422406608538
#print axioms Blc.Floor43.cert_e2422406608582
