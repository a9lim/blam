import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418347650518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2418347650518 : Closed e2418347650518 ∧ code e2418347650518 = 11214440672726 := by decide
theorem cert_e2418347650518 : check e2418347650518 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2418347650522 : Closed e2418347650522 ∧ code e2418347650522 = 11214440672730 := by decide
theorem cert_e2418347650522 : check e2418347650522 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2418347650734 : Closed e2418347650734 ∧ code e2418347650734 = 11214440672942 := by decide
theorem cert_e2418347650734 : check e2418347650734 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2418347650746 : Closed e2418347650746 ∧ code e2418347650746 = 11214440672954 := by decide
theorem cert_e2418347650746 : check e2418347650746 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2418347650794 : Closed e2418347650794 ∧ code e2418347650794 = 11214440673002 := by decide
theorem cert_e2418347650794 : check e2418347650794 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2418347650902 : Closed e2418347650902 ∧ code e2418347650902 = 11214440673110 := by decide
theorem cert_e2418347650902 : check e2418347650902 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2418347650906 : Closed e2418347650906 ∧ code e2418347650906 = 11214440673114 := by decide
theorem cert_e2418347650906 : check e2418347650906 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347650922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2418347650922 : Closed e2418347650922 ∧ code e2418347650922 = 11214440673130 := by decide
theorem cert_e2418347650922 : check e2418347650922 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347651950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2418347651950 : Closed e2418347651950 ∧ code e2418347651950 = 11214440674158 := by decide
theorem cert_e2418347651950 : check e2418347651950 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347651958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2418347651958 : Closed e2418347651958 ∧ code e2418347651958 = 11214440674166 := by decide
theorem cert_e2418347651958 : check e2418347651958 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2418347652014 : Closed e2418347652014 ∧ code e2418347652014 = 11214440674222 := by decide
theorem cert_e2418347652014 : check e2418347652014 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2418347652026 : Closed e2418347652026 ∧ code e2418347652026 = 11214440674234 := by decide
theorem cert_e2418347652026 : check e2418347652026 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2418347652054 : Closed e2418347652054 ∧ code e2418347652054 = 11214440674262 := by decide
theorem cert_e2418347652054 : check e2418347652054 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2418347652058 : Closed e2418347652058 ∧ code e2418347652058 = 11214440674266 := by decide
theorem cert_e2418347652058 : check e2418347652058 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418347652334 : Closed e2418347652334 ∧ code e2418347652334 = 11214440674542 := by decide
theorem cert_e2418347652334 : check e2418347652334 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418347652342 : Closed e2418347652342 ∧ code e2418347652342 = 11214440674550 := by decide
theorem cert_e2418347652342 : check e2418347652342 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418347652718 : Closed e2418347652718 ∧ code e2418347652718 = 11214440674926 := by decide
theorem cert_e2418347652718 : check e2418347652718 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418347652730 : Closed e2418347652730 ∧ code e2418347652730 = 11214440674938 := by decide
theorem cert_e2418347652730 : check e2418347652730 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418347652918 : Closed e2418347652918 ∧ code e2418347652918 = 11214440675126 := by decide
theorem cert_e2418347652918 : check e2418347652918 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347652922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418347652922 : Closed e2418347652922 ∧ code e2418347652922 = 11214440675130 := by decide
theorem cert_e2418347652922 : check e2418347652922 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347653550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2418347653550 : Closed e2418347653550 ∧ code e2418347653550 = 11214440675758 := by decide
theorem cert_e2418347653550 : check e2418347653550 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347653562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2418347653562 : Closed e2418347653562 ∧ code e2418347653562 = 11214440675770 := by decide
theorem cert_e2418347653562 : check e2418347653562 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347653610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2418347653610 : Closed e2418347653610 ∧ code e2418347653610 = 11214440675818 := by decide
theorem cert_e2418347653610 : check e2418347653610 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347653742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418347653742 : Closed e2418347653742 ∧ code e2418347653742 = 11214440675950 := by decide
theorem cert_e2418347653742 : check e2418347653742 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347653754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418347653754 : Closed e2418347653754 ∧ code e2418347653754 = 11214440675962 := by decide
theorem cert_e2418347653754 : check e2418347653754 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347654042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418347654042 : Closed e2418347654042 ∧ code e2418347654042 = 11214440676250 := by decide
theorem cert_e2418347654042 : check e2418347654042 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347654358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2418347654358 : Closed e2418347654358 ∧ code e2418347654358 = 11214440676566 := by decide
theorem cert_e2418347654358 : check e2418347654358 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347654362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2418347654362 : Closed e2418347654362 ∧ code e2418347654362 = 11214440676570 := by decide
theorem cert_e2418347654362 : check e2418347654362 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347654378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2418347654378 : Closed e2418347654378 ∧ code e2418347654378 = 11214440676586 := by decide
theorem cert_e2418347654378 : check e2418347654378 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347654454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418347654454 : Closed e2418347654454 ∧ code e2418347654454 = 11214440676662 := by decide
theorem cert_e2418347654454 : check e2418347654454 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347654458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418347654458 : Closed e2418347654458 ∧ code e2418347654458 = 11214440676666 := by decide
theorem cert_e2418347654458 : check e2418347654458 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347654554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418347654554 : Closed e2418347654554 ∧ code e2418347654554 = 11214440676762 := by decide
theorem cert_e2418347654554 : check e2418347654554 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347656158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2418347656158 : Closed e2418347656158 ∧ code e2418347656158 = 11214440678366 := by decide
theorem cert_e2418347656158 : check e2418347656158 [[],[],[.left]] .chain = true := by decide
def e2418347656174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2418347656174 : Closed e2418347656174 ∧ code e2418347656174 = 11214440678382 := by decide
theorem cert_e2418347656174 : check e2418347656174 [[],[],[.left]] .chain = true := by decide
def e2418347658094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418347658094 : Closed e2418347658094 ∧ code e2418347658094 = 11214440680302 := by decide
theorem cert_e2418347658094 : check e2418347658094 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418347658102 : Closed e2418347658102 ∧ code e2418347658102 = 11214440680310 := by decide
theorem cert_e2418347658102 : check e2418347658102 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418347658158 : Closed e2418347658158 ∧ code e2418347658158 = 11214440680366 := by decide
theorem cert_e2418347658158 : check e2418347658158 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418347658170 : Closed e2418347658170 ∧ code e2418347658170 = 11214440680378 := by decide
theorem cert_e2418347658170 : check e2418347658170 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418347658198 : Closed e2418347658198 ∧ code e2418347658198 = 11214440680406 := by decide
theorem cert_e2418347658198 : check e2418347658198 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418347658202 : Closed e2418347658202 ∧ code e2418347658202 = 11214440680410 := by decide
theorem cert_e2418347658202 : check e2418347658202 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418347658478 : Closed e2418347658478 ∧ code e2418347658478 = 11214440680686 := by decide
theorem cert_e2418347658478 : check e2418347658478 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418347658486 : Closed e2418347658486 ∧ code e2418347658486 = 11214440680694 := by decide
theorem cert_e2418347658486 : check e2418347658486 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418347658862 : Closed e2418347658862 ∧ code e2418347658862 = 11214440681070 := by decide
theorem cert_e2418347658862 : check e2418347658862 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347658874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418347658874 : Closed e2418347658874 ∧ code e2418347658874 = 11214440681082 := by decide
theorem cert_e2418347658874 : check e2418347658874 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347659062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418347659062 : Closed e2418347659062 ∧ code e2418347659062 = 11214440681270 := by decide
theorem cert_e2418347659062 : check e2418347659062 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347659066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418347659066 : Closed e2418347659066 ∧ code e2418347659066 = 11214440681274 := by decide
theorem cert_e2418347659066 : check e2418347659066 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347663838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2418347663838 : Closed e2418347663838 ∧ code e2418347663838 = 11214440686046 := by decide
theorem cert_e2418347663838 : check e2418347663838 [[],[],[.left]] .chain = true := by decide
def e2418347663862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2418347663862 : Closed e2418347663862 ∧ code e2418347663862 = 11214440686070 := by decide
theorem cert_e2418347663862 : check e2418347663862 [[],[],[.left]] .chain = true := by decide
def e2418347664814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2418347664814 : Closed e2418347664814 ∧ code e2418347664814 = 11214440687022 := by decide
theorem cert_e2418347664814 : check e2418347664814 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347664826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2418347664826 : Closed e2418347664826 ∧ code e2418347664826 = 11214440687034 := by decide
theorem cert_e2418347664826 : check e2418347664826 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347664874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2418347664874 : Closed e2418347664874 ∧ code e2418347664874 = 11214440687082 := by decide
theorem cert_e2418347664874 : check e2418347664874 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347665006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418347665006 : Closed e2418347665006 ∧ code e2418347665006 = 11214440687214 := by decide
theorem cert_e2418347665006 : check e2418347665006 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347665018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418347665018 : Closed e2418347665018 ∧ code e2418347665018 = 11214440687226 := by decide
theorem cert_e2418347665018 : check e2418347665018 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347665306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418347665306 : Closed e2418347665306 ∧ code e2418347665306 = 11214440687514 := by decide
theorem cert_e2418347665306 : check e2418347665306 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347667694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2418347667694 : Closed e2418347667694 ∧ code e2418347667694 = 11214440689902 := by decide
theorem cert_e2418347667694 : check e2418347667694 [[],[],[.left]] .chain = true := by decide
def e2418347667702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2418347667702 : Closed e2418347667702 ∧ code e2418347667702 = 11214440689910 := by decide
theorem cert_e2418347667702 : check e2418347667702 [[],[],[.left]] .chain = true := by decide
def e2418347668182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2418347668182 : Closed e2418347668182 ∧ code e2418347668182 = 11214440690390 := by decide
theorem cert_e2418347668182 : check e2418347668182 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347668186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2418347668186 : Closed e2418347668186 ∧ code e2418347668186 = 11214440690394 := by decide
theorem cert_e2418347668186 : check e2418347668186 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347668202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2418347668202 : Closed e2418347668202 ∧ code e2418347668202 = 11214440690410 := by decide
theorem cert_e2418347668202 : check e2418347668202 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347668278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418347668278 : Closed e2418347668278 ∧ code e2418347668278 = 11214440690486 := by decide
theorem cert_e2418347668278 : check e2418347668278 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347668282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418347668282 : Closed e2418347668282 ∧ code e2418347668282 = 11214440690490 := by decide
theorem cert_e2418347668282 : check e2418347668282 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347668378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418347668378 : Closed e2418347668378 ∧ code e2418347668378 = 11214440690586 := by decide
theorem cert_e2418347668378 : check e2418347668378 [[],[],[.left],[.left],[]] .chain = true := by decide
def e2418347805550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418347805550 : Closed e2418347805550 ∧ code e2418347805550 = 11214440827758 := by decide
private def t_e2418347805550 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.var 0))))))))
theorem cert_e2418347805550 : ¬ IsSelfInterpreter e2418347805550 :=
  wSource (t := t_e2418347805550) (replay_sound (ps := [[],[],[.left],[.left]]) (t := e2418347805550) (by decide)) (by decide)
def e2418347805558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418347805558 : Closed e2418347805558 ∧ code e2418347805558 = 11214440827766 := by decide
theorem cert_e2418347805558 : check e2418347805558 [[],[],[.left],[.left],[],[],[],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left]] .chain = true := by decide
def e2418347805614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418347805614 : Closed e2418347805614 ∧ code e2418347805614 = 11214440827822 := by decide
private def t_e2418347805614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.var 0))))))))
theorem cert_e2418347805614 : ¬ IsSelfInterpreter e2418347805614 :=
  wSource (t := t_e2418347805614) (replay_sound (ps := [[],[],[.left],[.left]]) (t := e2418347805614) (by decide)) (by decide)
def e2418347805626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418347805626 : Closed e2418347805626 ∧ code e2418347805626 = 11214440827834 := by decide
theorem cert_e2418347805626 : check e2418347805626 [[],[],[.left],[.left],[],[],[],[.left],[.left],[],[.left],[.left],[.left],[],[],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2418347805654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418347805654 : Closed e2418347805654 ∧ code e2418347805654 = 11214440827862 := by decide
def e2418347805658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418347805658 : Closed e2418347805658 ∧ code e2418347805658 = 11214440827866 := by decide
def e2418347805934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418347805934 : Closed e2418347805934 ∧ code e2418347805934 = 11214440828142 := by decide
theorem cert_e2418347805934 : check e2418347805934 [[],[],[.left],[.left],[],[],[],[],[.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .chain = true := by decide
def e2418347805942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418347805942 : Closed e2418347805942 ∧ code e2418347805942 = 11214440828150 := by decide
def e2418347806318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418347806318 : Closed e2418347806318 ∧ code e2418347806318 = 11214440828526 := by decide
theorem cert_e2418347806318 : check e2418347806318 [[],[],[.left],[.left],[],[],[],[],[.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[],[.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left]] .chain = true := by decide
def e2418347806330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418347806330 : Closed e2418347806330 ∧ code e2418347806330 = 11214440828538 := by decide
def e2418347806518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418347806518 : Closed e2418347806518 ∧ code e2418347806518 = 11214440828726 := by decide
def e2418347806522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418347806522 : Closed e2418347806522 ∧ code e2418347806522 = 11214440828730 := by decide
def e2418348395374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418348395374 : Closed e2418348395374 ∧ code e2418348395374 = 11214441417582 := by decide
theorem cert_e2418348395374 : check e2418348395374 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2418348395382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418348395382 : Closed e2418348395382 ∧ code e2418348395382 = 11214441417590 := by decide
theorem cert_e2418348395382 : check e2418348395382 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2418348395438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418348395438 : Closed e2418348395438 ∧ code e2418348395438 = 11214441417646 := by decide
theorem cert_e2418348395438 : check e2418348395438 [[],[],[.left],[.left],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2418348395450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418348395450 : Closed e2418348395450 ∧ code e2418348395450 = 11214441417658 := by decide
theorem cert_e2418348395450 : check e2418348395450 [[],[],[.left],[.left],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2418348395478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418348395478 : Closed e2418348395478 ∧ code e2418348395478 = 11214441417686 := by decide
theorem cert_e2418348395478 : check e2418348395478 [[],[],[.left],[.left],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2418348395482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418348395482 : Closed e2418348395482 ∧ code e2418348395482 = 11214441417690 := by decide
theorem cert_e2418348395482 : check e2418348395482 [[],[],[.left],[.left],[.left],[],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2418348395758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418348395758 : Closed e2418348395758 ∧ code e2418348395758 = 11214441417966 := by decide
theorem cert_e2418348395758 : check e2418348395758 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2418348395766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418348395766 : Closed e2418348395766 ∧ code e2418348395766 = 11214441417974 := by decide
theorem cert_e2418348395766 : check e2418348395766 [[],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2418348396142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418348396142 : Closed e2418348396142 ∧ code e2418348396142 = 11214441418350 := by decide
theorem cert_e2418348396142 : check e2418348396142 [[],[],[.left],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418348396154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418348396154 : Closed e2418348396154 ∧ code e2418348396154 = 11214441418362 := by decide
theorem cert_e2418348396154 : check e2418348396154 [[],[],[.left],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418348396342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418348396342 : Closed e2418348396342 ∧ code e2418348396342 = 11214441418550 := by decide
theorem cert_e2418348396342 : check e2418348396342 [[],[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2418348396346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418348396346 : Closed e2418348396346 ∧ code e2418348396346 = 11214441418554 := by decide
theorem cert_e2418348396346 : check e2418348396346 [[],[],[.left],[.left],[.left],[],[.under],[.under,.left,.left]] .chain = true := by decide
def e2418469329630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2418469329630 : Closed e2418469329630 ∧ code e2418469329630 = 11214562351838 := by decide
theorem cert_e2418469329630 : check e2418469329630 [[],[]] .three = true := by decide
def e2418469329654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2418469329654 : Closed e2418469329654 ∧ code e2418469329654 = 11214562351862 := by decide
theorem cert_e2418469329654 : check e2418469329654 [[],[]] .three = true := by decide
def e2418469329758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2418469329758 : Closed e2418469329758 ∧ code e2418469329758 = 11214562351966 := by decide
theorem cert_e2418469329758 : check e2418469329758 [[],[]] .three = true := by decide
def e2418469329774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2418469329774 : Closed e2418469329774 ∧ code e2418469329774 = 11214562351982 := by decide
theorem cert_e2418469329774 : check e2418469329774 [[],[]] .smaller = true := by decide
def e2418469329782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2418469329782 : Closed e2418469329782 ∧ code e2418469329782 = 11214562351990 := by decide
theorem cert_e2418469329782 : check e2418469329782 [[],[]] .smaller = true := by decide
def e2418469329786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2418469329786 : Closed e2418469329786 ∧ code e2418469329786 = 11214562351994 := by decide
theorem cert_e2418469329786 : check e2418469329786 [[],[]] .three = true := by decide
def e2418469329846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2418469329846 : Closed e2418469329846 ∧ code e2418469329846 = 11214562352054 := by decide
theorem cert_e2418469329846 : check e2418469329846 [[],[]] .smaller = true := by decide
def e2418469329878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2418469329878 : Closed e2418469329878 ∧ code e2418469329878 = 11214562352086 := by decide
theorem cert_e2418469329878 : check e2418469329878 [[],[]] .three = true := by decide
def e2418469329882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2418469329882 : Closed e2418469329882 ∧ code e2418469329882 = 11214562352090 := by decide
theorem cert_e2418469329882 : check e2418469329882 [[],[]] .three = true := by decide
def e2418469330270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))
theorem wire_e2418469330270 : Closed e2418469330270 ∧ code e2418469330270 = 11214562352478 := by decide
theorem cert_e2418469330270 : check e2418469330270 [[],[]] .three = true := by decide
def e2418469330286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2418469330286 : Closed e2418469330286 ∧ code e2418469330286 = 11214562352494 := by decide
theorem cert_e2418469330286 : check e2418469330286 [[],[]] .smaller = true := by decide
def e2418469330294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2418469330294 : Closed e2418469330294 ∧ code e2418469330294 = 11214562352502 := by decide
theorem cert_e2418469330294 : check e2418469330294 [[],[]] .smaller = true := by decide
def e2418469330298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))
theorem wire_e2418469330298 : Closed e2418469330298 ∧ code e2418469330298 = 11214562352506 := by decide
theorem cert_e2418469330298 : check e2418469330298 [[],[]] .three = true := by decide
def e2418469330350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2418469330350 : Closed e2418469330350 ∧ code e2418469330350 = 11214562352558 := by decide
theorem cert_e2418469330350 : check e2418469330350 [[],[]] .smaller = true := by decide
def e2418469330362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2418469330362 : Closed e2418469330362 ∧ code e2418469330362 = 11214562352570 := by decide
theorem cert_e2418469330362 : check e2418469330362 [[],[]] .smaller = true := by decide
def e2418469330390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2418469330390 : Closed e2418469330390 ∧ code e2418469330390 = 11214562352598 := by decide
theorem cert_e2418469330390 : check e2418469330390 [[],[]] .smaller = true := by decide
def e2418469330394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2418469330394 : Closed e2418469330394 ∧ code e2418469330394 = 11214562352602 := by decide
theorem cert_e2418469330394 : check e2418469330394 [[],[]] .smaller = true := by decide
def e2418469330410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))
theorem wire_e2418469330410 : Closed e2418469330410 ∧ code e2418469330410 = 11214562352618 := by decide
theorem cert_e2418469330410 : check e2418469330410 [[],[]] .three = true := by decide
def e2418469330614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2418469330614 : Closed e2418469330614 ∧ code e2418469330614 = 11214562352822 := by decide
theorem cert_e2418469330614 : check e2418469330614 [[],[]] .smaller = true := by decide
def e2418469330646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2418469330646 : Closed e2418469330646 ∧ code e2418469330646 = 11214562352854 := by decide
theorem cert_e2418469330646 : check e2418469330646 [[],[]] .smaller = true := by decide
def e2418469330650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2418469330650 : Closed e2418469330650 ∧ code e2418469330650 = 11214562352858 := by decide
theorem cert_e2418469330650 : check e2418469330650 [[],[]] .smaller = true := by decide
def e2418469330774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2418469330774 : Closed e2418469330774 ∧ code e2418469330774 = 11214562352982 := by decide
theorem cert_e2418469330774 : check e2418469330774 [[],[]] .three = true := by decide
def e2418469330778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2418469330778 : Closed e2418469330778 ∧ code e2418469330778 = 11214562352986 := by decide
theorem cert_e2418469330778 : check e2418469330778 [[],[]] .three = true := by decide
def e2418469330794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2418469330794 : Closed e2418469330794 ∧ code e2418469330794 = 11214562353002 := by decide
theorem cert_e2418469330794 : check e2418469330794 [[],[]] .three = true := by decide
def e2418469332702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2418469332702 : Closed e2418469332702 ∧ code e2418469332702 = 11214562354910 := by decide
theorem cert_e2418469332702 : check e2418469332702 [[],[]] .three = true := by decide
def e2418469332726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2418469332726 : Closed e2418469332726 ∧ code e2418469332726 = 11214562354934 := by decide
theorem cert_e2418469332726 : check e2418469332726 [[],[]] .three = true := by decide
def e2418469332830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2418469332830 : Closed e2418469332830 ∧ code e2418469332830 = 11214562355038 := by decide
theorem cert_e2418469332830 : check e2418469332830 [[],[]] .three = true := by decide
def e2418469332846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2418469332846 : Closed e2418469332846 ∧ code e2418469332846 = 11214562355054 := by decide
theorem cert_e2418469332846 : check e2418469332846 [[],[]] .smaller = true := by decide
def e2418469332854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2418469332854 : Closed e2418469332854 ∧ code e2418469332854 = 11214562355062 := by decide
theorem cert_e2418469332854 : check e2418469332854 [[],[]] .smaller = true := by decide
def e2418469332858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2418469332858 : Closed e2418469332858 ∧ code e2418469332858 = 11214562355066 := by decide
theorem cert_e2418469332858 : check e2418469332858 [[],[]] .three = true := by decide
def e2418469332918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2418469332918 : Closed e2418469332918 ∧ code e2418469332918 = 11214562355126 := by decide
theorem cert_e2418469332918 : check e2418469332918 [[],[]] .smaller = true := by decide
def e2418469332950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2418469332950 : Closed e2418469332950 ∧ code e2418469332950 = 11214562355158 := by decide
theorem cert_e2418469332950 : check e2418469332950 [[],[]] .three = true := by decide
def e2418469332954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2418469332954 : Closed e2418469332954 ∧ code e2418469332954 = 11214562355162 := by decide
theorem cert_e2418469332954 : check e2418469332954 [[],[]] .three = true := by decide
def e2418469333470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2418469333470 : Closed e2418469333470 ∧ code e2418469333470 = 11214562355678 := by decide
theorem cert_e2418469333470 : check e2418469333470 [[],[]] .three = true := by decide
def e2418469333494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2418469333494 : Closed e2418469333494 ∧ code e2418469333494 = 11214562355702 := by decide
theorem cert_e2418469333494 : check e2418469333494 [[],[]] .three = true := by decide
def e2418469334238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2418469334238 : Closed e2418469334238 ∧ code e2418469334238 = 11214562356446 := by decide
theorem cert_e2418469334238 : check e2418469334238 [[],[]] .three = true := by decide
def e2418469334254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418469334254 : Closed e2418469334254 ∧ code e2418469334254 = 11214562356462 := by decide
theorem cert_e2418469334254 : check e2418469334254 [[],[]] .smaller = true := by decide
def e2418469334262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418469334262 : Closed e2418469334262 ∧ code e2418469334262 = 11214562356470 := by decide
theorem cert_e2418469334262 : check e2418469334262 [[],[]] .smaller = true := by decide
def e2418469334266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2418469334266 : Closed e2418469334266 ∧ code e2418469334266 = 11214562356474 := by decide
theorem cert_e2418469334266 : check e2418469334266 [[],[]] .three = true := by decide
def e2418469334646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2418469334646 : Closed e2418469334646 ∧ code e2418469334646 = 11214562356854 := by decide
theorem cert_e2418469334646 : check e2418469334646 [[],[]] .smaller = true := by decide
def e2418469334838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418469334838 : Closed e2418469334838 ∧ code e2418469334838 = 11214562357046 := by decide
theorem cert_e2418469334838 : check e2418469334838 [[],[]] .three = true := by decide
def e2418469334842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418469334842 : Closed e2418469334842 ∧ code e2418469334842 = 11214562357050 := by decide
theorem cert_e2418469334842 : check e2418469334842 [[],[]] .three = true := by decide
def e2418469335902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2418469335902 : Closed e2418469335902 ∧ code e2418469335902 = 11214562358110 := by decide
theorem cert_e2418469335902 : check e2418469335902 [[],[]] .three = true := by decide
def e2418469335918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2418469335918 : Closed e2418469335918 ∧ code e2418469335918 = 11214562358126 := by decide
theorem cert_e2418469335918 : check e2418469335918 [[],[]] .smaller = true := by decide
def e2418469335926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2418469335926 : Closed e2418469335926 ∧ code e2418469335926 = 11214562358134 := by decide
theorem cert_e2418469335926 : check e2418469335926 [[],[]] .smaller = true := by decide
def e2418469335930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2418469335930 : Closed e2418469335930 ∧ code e2418469335930 = 11214562358138 := by decide
theorem cert_e2418469335930 : check e2418469335930 [[],[]] .three = true := by decide
def e2418469335982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2418469335982 : Closed e2418469335982 ∧ code e2418469335982 = 11214562358190 := by decide
theorem cert_e2418469335982 : check e2418469335982 [[],[]] .smaller = true := by decide
def e2418469335994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2418469335994 : Closed e2418469335994 ∧ code e2418469335994 = 11214562358202 := by decide
theorem cert_e2418469335994 : check e2418469335994 [[],[]] .smaller = true := by decide
def e2418469336022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2418469336022 : Closed e2418469336022 ∧ code e2418469336022 = 11214562358230 := by decide
theorem cert_e2418469336022 : check e2418469336022 [[],[]] .smaller = true := by decide
def e2418469336026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2418469336026 : Closed e2418469336026 ∧ code e2418469336026 = 11214562358234 := by decide
theorem cert_e2418469336026 : check e2418469336026 [[],[]] .smaller = true := by decide
def e2418469336042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2418469336042 : Closed e2418469336042 ∧ code e2418469336042 = 11214562358250 := by decide
theorem cert_e2418469336042 : check e2418469336042 [[],[]] .three = true := by decide
def e2418469336286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2418469336286 : Closed e2418469336286 ∧ code e2418469336286 = 11214562358494 := by decide
theorem cert_e2418469336286 : check e2418469336286 [[],[]] .three = true := by decide
def e2418469336302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418469336302 : Closed e2418469336302 ∧ code e2418469336302 = 11214562358510 := by decide
theorem cert_e2418469336302 : check e2418469336302 [[],[]] .smaller = true := by decide
def e2418469336310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418469336310 : Closed e2418469336310 ∧ code e2418469336310 = 11214562358518 := by decide
theorem cert_e2418469336310 : check e2418469336310 [[],[]] .smaller = true := by decide
def e2418469336314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2418469336314 : Closed e2418469336314 ∧ code e2418469336314 = 11214562358522 := by decide
theorem cert_e2418469336314 : check e2418469336314 [[],[]] .three = true := by decide
def e2418469336686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418469336686 : Closed e2418469336686 ∧ code e2418469336686 = 11214562358894 := by decide
theorem cert_e2418469336686 : check e2418469336686 [[],[]] .smaller = true := by decide
def e2418469336698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418469336698 : Closed e2418469336698 ∧ code e2418469336698 = 11214562358906 := by decide
theorem cert_e2418469336698 : check e2418469336698 [[],[]] .smaller = true := by decide
def e2418469336886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418469336886 : Closed e2418469336886 ∧ code e2418469336886 = 11214562359094 := by decide
theorem cert_e2418469336886 : check e2418469336886 [[],[]] .smaller = true := by decide
def e2418469336890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418469336890 : Closed e2418469336890 ∧ code e2418469336890 = 11214562359098 := by decide
theorem cert_e2418469336890 : check e2418469336890 [[],[]] .smaller = true := by decide
def e2418469336986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418469336986 : Closed e2418469336986 ∧ code e2418469336986 = 11214562359194 := by decide
theorem cert_e2418469336986 : check e2418469336986 [[],[]] .three = true := by decide
def e2418469337526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2418469337526 : Closed e2418469337526 ∧ code e2418469337526 = 11214562359734 := by decide
theorem cert_e2418469337526 : check e2418469337526 [[],[]] .smaller = true := by decide
def e2418469337558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2418469337558 : Closed e2418469337558 ∧ code e2418469337558 = 11214562359766 := by decide
theorem cert_e2418469337558 : check e2418469337558 [[],[]] .smaller = true := by decide
def e2418469337562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2418469337562 : Closed e2418469337562 ∧ code e2418469337562 = 11214562359770 := by decide
theorem cert_e2418469337562 : check e2418469337562 [[],[]] .smaller = true := by decide
def e2418469337718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2418469337718 : Closed e2418469337718 ∧ code e2418469337718 = 11214562359926 := by decide
theorem cert_e2418469337718 : check e2418469337718 [[],[]] .smaller = true := by decide
def e2418469337910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418469337910 : Closed e2418469337910 ∧ code e2418469337910 = 11214562360118 := by decide
theorem cert_e2418469337910 : check e2418469337910 [[],[]] .smaller = true := by decide
def e2418469337914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418469337914 : Closed e2418469337914 ∧ code e2418469337914 = 11214562360122 := by decide
theorem cert_e2418469337914 : check e2418469337914 [[],[]] .smaller = true := by decide
def e2418469338326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2418469338326 : Closed e2418469338326 ∧ code e2418469338326 = 11214562360534 := by decide
theorem cert_e2418469338326 : check e2418469338326 [[],[]] .three = true := by decide
def e2418469338330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2418469338330 : Closed e2418469338330 ∧ code e2418469338330 = 11214562360538 := by decide
theorem cert_e2418469338330 : check e2418469338330 [[],[]] .three = true := by decide
def e2418469338346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2418469338346 : Closed e2418469338346 ∧ code e2418469338346 = 11214562360554 := by decide
theorem cert_e2418469338346 : check e2418469338346 [[],[]] .three = true := by decide
def e2418469338422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418469338422 : Closed e2418469338422 ∧ code e2418469338422 = 11214562360630 := by decide
theorem cert_e2418469338422 : check e2418469338422 [[],[]] .three = true := by decide
def e2418469338426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418469338426 : Closed e2418469338426 ∧ code e2418469338426 = 11214562360634 := by decide
theorem cert_e2418469338426 : check e2418469338426 [[],[]] .three = true := by decide
def e2418469338522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418469338522 : Closed e2418469338522 ∧ code e2418469338522 = 11214562360730 := by decide
theorem cert_e2418469338522 : check e2418469338522 [[],[]] .three = true := by decide
def e2418469344990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2418469344990 : Closed e2418469344990 ∧ code e2418469344990 = 11214562367198 := by decide
theorem cert_e2418469344990 : check e2418469344990 [[],[]] .three = true := by decide
def e2418469345014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2418469345014 : Closed e2418469345014 ∧ code e2418469345014 = 11214562367222 := by decide
theorem cert_e2418469345014 : check e2418469345014 [[],[]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2418347805550
#print axioms Blc.Floor43.cert_e2418347805614
