import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373341678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373341678 : Closed e2422373341678 ∧ code e2422373341678 = 11218466363886 := by decide
theorem cert_e2422373341678 : check e2422373341678 [[],[]] .smaller = true := by decide
def e2422373341686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373341686 : Closed e2422373341686 ∧ code e2422373341686 = 11218466363894 := by decide
theorem cert_e2422373341686 : check e2422373341686 [[],[]] .three = true := by decide
def e2422373342238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373342238 : Closed e2422373342238 ∧ code e2422373342238 = 11218466364446 := by decide
theorem cert_e2422373342238 : check e2422373342238 [[],[]] .smaller = true := by decide
def e2422373342430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373342430 : Closed e2422373342430 ∧ code e2422373342430 = 11218466364638 := by decide
theorem cert_e2422373342430 : check e2422373342430 [[],[]] .three = true := by decide
def e2422373342434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373342434 : Closed e2422373342434 ∧ code e2422373342434 = 11218466364642 := by decide
theorem cert_e2422373342434 : check e2422373342434 [[],[]] .smaller = true := by decide
def e2422373342446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373342446 : Closed e2422373342446 ∧ code e2422373342446 = 11218466364654 := by decide
theorem cert_e2422373342446 : check e2422373342446 [[],[]] .smaller = true := by decide
def e2422373342454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373342454 : Closed e2422373342454 ∧ code e2422373342454 = 11218466364662 := by decide
theorem cert_e2422373342454 : check e2422373342454 [[],[]] .smaller = true := by decide
def e2422373342458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373342458 : Closed e2422373342458 ∧ code e2422373342458 = 11218466364666 := by decide
theorem cert_e2422373342458 : check e2422373342458 [[],[]] .three = true := by decide
def e2422373342734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373342734 : Closed e2422373342734 ∧ code e2422373342734 = 11218466364942 := by decide
theorem cert_e2422373342734 : check e2422373342734 [[],[]] .three = true := by decide
def e2422373342746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373342746 : Closed e2422373342746 ∧ code e2422373342746 = 11218466364954 := by decide
theorem cert_e2422373342746 : check e2422373342746 [[],[]] .three = true := by decide
def e2422373342782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.var 4))))))))
theorem wire_e2422373342782 : Closed e2422373342782 ∧ code e2422373342782 = 11218466364990 := by decide
theorem cert_e2422373342782 : check e2422373342782 [[],[]] .three = true := by decide
def e2422373342818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373342818 : Closed e2422373342818 ∧ code e2422373342818 = 11218466365026 := by decide
theorem cert_e2422373342818 : check e2422373342818 [[],[]] .three = true := by decide
def e2422373342830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373342830 : Closed e2422373342830 ∧ code e2422373342830 = 11218466365038 := by decide
theorem cert_e2422373342830 : check e2422373342830 [[],[]] .three = true := by decide
def e2422373342838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373342838 : Closed e2422373342838 ∧ code e2422373342838 = 11218466365046 := by decide
theorem cert_e2422373342838 : check e2422373342838 [[],[]] .three = true := by decide
def e2422373342842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373342842 : Closed e2422373342842 ∧ code e2422373342842 = 11218466365050 := by decide
theorem cert_e2422373342842 : check e2422373342842 [[],[]] .three = true := by decide
def e2422373343470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422373343470 : Closed e2422373343470 ∧ code e2422373343470 = 11218466365678 := by decide
theorem cert_e2422373343470 : check e2422373343470 [[],[]] .three = true := by decide
def e2422373343478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 3))))) (.var 1)))))))
theorem wire_e2422373343478 : Closed e2422373343478 ∧ code e2422373343478 = 11218466365686 := by decide
theorem cert_e2422373343478 : check e2422373343478 [[],[]] .three = true := by decide
def e2422373343482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422373343482 : Closed e2422373343482 ∧ code e2422373343482 = 11218466365690 := by decide
theorem cert_e2422373343482 : check e2422373343482 [[],[]] .three = true := by decide
def e2422373343662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e2422373343662 : Closed e2422373343662 ∧ code e2422373343662 = 11218466365870 := by decide
theorem cert_e2422373343662 : check e2422373343662 [[],[]] .three = true := by decide
def e2422373343670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422373343670 : Closed e2422373343670 ∧ code e2422373343670 = 11218466365878 := by decide
theorem cert_e2422373343670 : check e2422373343670 [[],[]] .three = true := by decide
def e2422373343674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373343674 : Closed e2422373343674 ∧ code e2422373343674 = 11218466365882 := by decide
theorem cert_e2422373343674 : check e2422373343674 [[],[]] .three = true := by decide
def e2422373343702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422373343702 : Closed e2422373343702 ∧ code e2422373343702 = 11218466365910 := by decide
theorem cert_e2422373343702 : check e2422373343702 [[],[]] .three = true := by decide
def e2422373343722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373343722 : Closed e2422373343722 ∧ code e2422373343722 = 11218466365930 := by decide
theorem cert_e2422373343722 : check e2422373343722 [[],[]] .three = true := by decide
def e2422373343854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373343854 : Closed e2422373343854 ∧ code e2422373343854 = 11218466366062 := by decide
theorem cert_e2422373343854 : check e2422373343854 [[],[]] .three = true := by decide
def e2422373343862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373343862 : Closed e2422373343862 ∧ code e2422373343862 = 11218466366070 := by decide
theorem cert_e2422373343862 : check e2422373343862 [[],[]] .three = true := by decide
def e2422373343866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373343866 : Closed e2422373343866 ∧ code e2422373343866 = 11218466366074 := by decide
theorem cert_e2422373343866 : check e2422373343866 [[],[]] .three = true := by decide
def e2422373344030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422373344030 : Closed e2422373344030 ∧ code e2422373344030 = 11218466366238 := by decide
theorem cert_e2422373344030 : check e2422373344030 [[],[]] .three = true := by decide
def e2422373344054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373344054 : Closed e2422373344054 ∧ code e2422373344054 = 11218466366262 := by decide
theorem cert_e2422373344054 : check e2422373344054 [[],[]] .three = true := by decide
def e2422373344058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373344058 : Closed e2422373344058 ∧ code e2422373344058 = 11218466366266 := by decide
theorem cert_e2422373344058 : check e2422373344058 [[],[]] .three = true := by decide
def e2422373344142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.lam (.var 2))))))))
theorem wire_e2422373344142 : Closed e2422373344142 ∧ code e2422373344142 = 11218466366350 := by decide
theorem cert_e2422373344142 : check e2422373344142 [[],[]] .three = true := by decide
def e2422373344154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373344154 : Closed e2422373344154 ∧ code e2422373344154 = 11218466366362 := by decide
theorem cert_e2422373344154 : check e2422373344154 [[],[]] .three = true := by decide
def e2422373344198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422373344198 : Closed e2422373344198 ∧ code e2422373344198 = 11218466366406 := by decide
theorem cert_e2422373344198 : check e2422373344198 [[],[]] .three = true := by decide
def e2422373344222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e2422373344222 : Closed e2422373344222 ∧ code e2422373344222 = 11218466366430 := by decide
theorem cert_e2422373344222 : check e2422373344222 [[],[]] .three = true := by decide
def e2422373344238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e2422373344238 : Closed e2422373344238 ∧ code e2422373344238 = 11218466366446 := by decide
theorem cert_e2422373344238 : check e2422373344238 [[],[]] .three = true := by decide
def e2422373344814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373344814 : Closed e2422373344814 ∧ code e2422373344814 = 11218466367022 := by decide
theorem cert_e2422373344814 : check e2422373344814 [[],[]] .three = true := by decide
def e2422373344822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373344822 : Closed e2422373344822 ∧ code e2422373344822 = 11218466367030 := by decide
theorem cert_e2422373344822 : check e2422373344822 [[],[]] .three = true := by decide
def e2422373344826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373344826 : Closed e2422373344826 ∧ code e2422373344826 = 11218466367034 := by decide
theorem cert_e2422373344826 : check e2422373344826 [[],[]] .three = true := by decide
def e2422373344910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373344910 : Closed e2422373344910 ∧ code e2422373344910 = 11218466367118 := by decide
theorem cert_e2422373344910 : check e2422373344910 [[],[]] .three = true := by decide
def e2422373344966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373344966 : Closed e2422373344966 ∧ code e2422373344966 = 11218466367174 := by decide
theorem cert_e2422373344966 : check e2422373344966 [[],[]] .three = true := by decide
def e2422373344990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e2422373344990 : Closed e2422373344990 ∧ code e2422373344990 = 11218466367198 := by decide
theorem cert_e2422373344990 : check e2422373344990 [[],[]] .three = true := by decide
def e2422373344994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373344994 : Closed e2422373344994 ∧ code e2422373344994 = 11218466367202 := by decide
theorem cert_e2422373344994 : check e2422373344994 [[],[]] .three = true := by decide
def e2422373345006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2422373345006 : Closed e2422373345006 ∧ code e2422373345006 = 11218466367214 := by decide
theorem cert_e2422373345006 : check e2422373345006 [[],[]] .three = true := by decide
def e2422373345014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2422373345014 : Closed e2422373345014 ∧ code e2422373345014 = 11218466367222 := by decide
theorem cert_e2422373345014 : check e2422373345014 [[],[]] .three = true := by decide
def e2422373345046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373345046 : Closed e2422373345046 ∧ code e2422373345046 = 11218466367254 := by decide
theorem cert_e2422373345046 : check e2422373345046 [[],[]] .three = true := by decide
def e2422373345050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422373345050 : Closed e2422373345050 ∧ code e2422373345050 = 11218466367258 := by decide
theorem cert_e2422373345050 : check e2422373345050 [[],[]] .three = true := by decide
def e2422373345094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422373345094 : Closed e2422373345094 ∧ code e2422373345094 = 11218466367302 := by decide
theorem cert_e2422373345094 : check e2422373345094 [[],[]] .three = true := by decide
def e2422373345118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e2422373345118 : Closed e2422373345118 ∧ code e2422373345118 = 11218466367326 := by decide
theorem cert_e2422373345118 : check e2422373345118 [[],[]] .three = true := by decide
def e2422373345122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373345122 : Closed e2422373345122 ∧ code e2422373345122 = 11218466367330 := by decide
theorem cert_e2422373345122 : check e2422373345122 [[],[]] .three = true := by decide
def e2422373345134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2422373345134 : Closed e2422373345134 ∧ code e2422373345134 = 11218466367342 := by decide
theorem cert_e2422373345134 : check e2422373345134 [[],[]] .three = true := by decide
def e2422373345142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 2)))) (.var 1)))))))
theorem wire_e2422373345142 : Closed e2422373345142 ∧ code e2422373345142 = 11218466367350 := by decide
theorem cert_e2422373345142 : check e2422373345142 [[],[]] .three = true := by decide
def e2422373345146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2422373345146 : Closed e2422373345146 ∧ code e2422373345146 = 11218466367354 := by decide
theorem cert_e2422373345146 : check e2422373345146 [[],[]] .three = true := by decide
def e2422373345162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373345162 : Closed e2422373345162 ∧ code e2422373345162 = 11218466367370 := by decide
theorem cert_e2422373345162 : check e2422373345162 [[],[]] .three = true := by decide
def e2422373345186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373345186 : Closed e2422373345186 ∧ code e2422373345186 = 11218466367394 := by decide
theorem cert_e2422373345186 : check e2422373345186 [[],[]] .three = true := by decide
def e2422373345198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2422373345198 : Closed e2422373345198 ∧ code e2422373345198 = 11218466367406 := by decide
theorem cert_e2422373345198 : check e2422373345198 [[],[]] .three = true := by decide
def e2422373345206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 1)))) (.var 1)))))))
theorem wire_e2422373345206 : Closed e2422373345206 ∧ code e2422373345206 = 11218466367414 := by decide
theorem cert_e2422373345206 : check e2422373345206 [[],[]] .three = true := by decide
def e2422373345210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e2422373345210 : Closed e2422373345210 ∧ code e2422373345210 = 11218466367418 := by decide
theorem cert_e2422373345210 : check e2422373345210 [[],[]] .three = true := by decide
def e2422373345238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2422373345238 : Closed e2422373345238 ∧ code e2422373345238 = 11218466367446 := by decide
theorem cert_e2422373345238 : check e2422373345238 [[],[]] .three = true := by decide
def e2422373345242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2422373345242 : Closed e2422373345242 ∧ code e2422373345242 = 11218466367450 := by decide
theorem cert_e2422373345242 : check e2422373345242 [[],[]] .three = true := by decide
def e2422373345342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373345342 : Closed e2422373345342 ∧ code e2422373345342 = 11218466367550 := by decide
theorem cert_e2422373345342 : check e2422373345342 [[],[]] .three = true := by decide
def e2422373345390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373345390 : Closed e2422373345390 ∧ code e2422373345390 = 11218466367598 := by decide
theorem cert_e2422373345390 : check e2422373345390 [[],[]] .three = true := by decide
def e2422373345402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373345402 : Closed e2422373345402 ∧ code e2422373345402 = 11218466367610 := by decide
theorem cert_e2422373345402 : check e2422373345402 [[],[]] .three = true := by decide
def e2422373345678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373345678 : Closed e2422373345678 ∧ code e2422373345678 = 11218466367886 := by decide
theorem cert_e2422373345678 : check e2422373345678 [[],[]] .three = true := by decide
def e2422373345734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373345734 : Closed e2422373345734 ∧ code e2422373345734 = 11218466367942 := by decide
theorem cert_e2422373345734 : check e2422373345734 [[],[]] .three = true := by decide
def e2422373345758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373345758 : Closed e2422373345758 ∧ code e2422373345758 = 11218466367966 := by decide
theorem cert_e2422373345758 : check e2422373345758 [[],[]] .three = true := by decide
def e2422373345762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373345762 : Closed e2422373345762 ∧ code e2422373345762 = 11218466367970 := by decide
theorem cert_e2422373345762 : check e2422373345762 [[],[]] .three = true := by decide
def e2422373345774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373345774 : Closed e2422373345774 ∧ code e2422373345774 = 11218466367982 := by decide
theorem cert_e2422373345774 : check e2422373345774 [[],[]] .three = true := by decide
def e2422373345782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373345782 : Closed e2422373345782 ∧ code e2422373345782 = 11218466367990 := by decide
theorem cert_e2422373345782 : check e2422373345782 [[],[]] .three = true := by decide
def e2422373346334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373346334 : Closed e2422373346334 ∧ code e2422373346334 = 11218466368542 := by decide
theorem cert_e2422373346334 : check e2422373346334 [[],[]] .three = true := by decide
def e2422373346358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373346358 : Closed e2422373346358 ∧ code e2422373346358 = 11218466368566 := by decide
theorem cert_e2422373346358 : check e2422373346358 [[],[]] .three = true := by decide
def e2422373346362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373346362 : Closed e2422373346362 ∧ code e2422373346362 = 11218466368570 := by decide
theorem cert_e2422373346362 : check e2422373346362 [[],[]] .three = true := by decide
def e2422373346502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373346502 : Closed e2422373346502 ∧ code e2422373346502 = 11218466368710 := by decide
theorem cert_e2422373346502 : check e2422373346502 [[],[]] .three = true := by decide
def e2422373346526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373346526 : Closed e2422373346526 ∧ code e2422373346526 = 11218466368734 := by decide
theorem cert_e2422373346526 : check e2422373346526 [[],[]] .three = true := by decide
def e2422373346530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373346530 : Closed e2422373346530 ∧ code e2422373346530 = 11218466368738 := by decide
theorem cert_e2422373346530 : check e2422373346530 [[],[]] .three = true := by decide
def e2422373346542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373346542 : Closed e2422373346542 ∧ code e2422373346542 = 11218466368750 := by decide
theorem cert_e2422373346542 : check e2422373346542 [[],[]] .three = true := by decide
def e2422373346550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373346550 : Closed e2422373346550 ∧ code e2422373346550 = 11218466368758 := by decide
theorem cert_e2422373346550 : check e2422373346550 [[],[]] .three = true := by decide
def e2422373346554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373346554 : Closed e2422373346554 ∧ code e2422373346554 = 11218466368762 := by decide
theorem cert_e2422373346554 : check e2422373346554 [[],[]] .three = true := by decide
def e2422373346830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373346830 : Closed e2422373346830 ∧ code e2422373346830 = 11218466369038 := by decide
theorem cert_e2422373346830 : check e2422373346830 [[],[]] .three = true := by decide
def e2422373346842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373346842 : Closed e2422373346842 ∧ code e2422373346842 = 11218466369050 := by decide
theorem cert_e2422373346842 : check e2422373346842 [[],[]] .three = true := by decide
def e2422373346878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.var 4))))))))
theorem wire_e2422373346878 : Closed e2422373346878 ∧ code e2422373346878 = 11218466369086 := by decide
theorem cert_e2422373346878 : check e2422373346878 [[],[]] .three = true := by decide
def e2422373346914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373346914 : Closed e2422373346914 ∧ code e2422373346914 = 11218466369122 := by decide
theorem cert_e2422373346914 : check e2422373346914 [[],[]] .three = true := by decide
def e2422373346926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373346926 : Closed e2422373346926 ∧ code e2422373346926 = 11218466369134 := by decide
theorem cert_e2422373346926 : check e2422373346926 [[],[]] .three = true := by decide
def e2422373346934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373346934 : Closed e2422373346934 ∧ code e2422373346934 = 11218466369142 := by decide
theorem cert_e2422373346934 : check e2422373346934 [[],[]] .three = true := by decide
def e2422373346938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373346938 : Closed e2422373346938 ∧ code e2422373346938 = 11218466369146 := by decide
theorem cert_e2422373346938 : check e2422373346938 [[],[]] .three = true := by decide
def e2422373347102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.lam (.var 3))))))))
theorem wire_e2422373347102 : Closed e2422373347102 ∧ code e2422373347102 = 11218466369310 := by decide
theorem cert_e2422373347102 : check e2422373347102 [[],[]] .three = true := by decide
def e2422373347126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373347126 : Closed e2422373347126 ∧ code e2422373347126 = 11218466369334 := by decide
theorem cert_e2422373347126 : check e2422373347126 [[],[]] .three = true := by decide
def e2422373347130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373347130 : Closed e2422373347130 ∧ code e2422373347130 = 11218466369338 := by decide
theorem cert_e2422373347130 : check e2422373347130 [[],[]] .three = true := by decide
def e2422373354350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422373354350 : Closed e2422373354350 ∧ code e2422373354350 = 11218466376558 := by decide
theorem cert_e2422373354350 : check e2422373354350 [[],[]] .smaller = true := by decide
def e2422373354358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422373354358 : Closed e2422373354358 ∧ code e2422373354358 = 11218466376566 := by decide
theorem cert_e2422373354358 : check e2422373354358 [[],[]] .smaller = true := by decide
def e2422373354414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422373354414 : Closed e2422373354414 ∧ code e2422373354414 = 11218466376622 := by decide
theorem cert_e2422373354414 : check e2422373354414 [[],[]] .smaller = true := by decide
def e2422373354426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422373354426 : Closed e2422373354426 ∧ code e2422373354426 = 11218466376634 := by decide
theorem cert_e2422373354426 : check e2422373354426 [[],[]] .smaller = true := by decide
def e2422373354454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422373354454 : Closed e2422373354454 ∧ code e2422373354454 = 11218466376662 := by decide
theorem cert_e2422373354454 : check e2422373354454 [[],[]] .smaller = true := by decide
def e2422373354458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422373354458 : Closed e2422373354458 ∧ code e2422373354458 = 11218466376666 := by decide
theorem cert_e2422373354458 : check e2422373354458 [[],[]] .smaller = true := by decide
def e2422373354734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422373354734 : Closed e2422373354734 ∧ code e2422373354734 = 11218466376942 := by decide
theorem cert_e2422373354734 : check e2422373354734 [[],[]] .smaller = true := by decide
def e2422373354742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422373354742 : Closed e2422373354742 ∧ code e2422373354742 = 11218466376950 := by decide
theorem cert_e2422373354742 : check e2422373354742 [[],[]] .smaller = true := by decide
def e2422373355118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422373355118 : Closed e2422373355118 ∧ code e2422373355118 = 11218466377326 := by decide
theorem cert_e2422373355118 : check e2422373355118 [[],[]] .smaller = true := by decide
def e2422373355130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422373355130 : Closed e2422373355130 ∧ code e2422373355130 = 11218466377338 := by decide
theorem cert_e2422373355130 : check e2422373355130 [[],[]] .smaller = true := by decide
def e2422373355318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422373355318 : Closed e2422373355318 ∧ code e2422373355318 = 11218466377526 := by decide
theorem cert_e2422373355318 : check e2422373355318 [[],[]] .smaller = true := by decide
def e2422373355322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422373355322 : Closed e2422373355322 ∧ code e2422373355322 = 11218466377530 := by decide
theorem cert_e2422373355322 : check e2422373355322 [[],[]] .smaller = true := by decide
def e2422373355454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e2422373355454 : Closed e2422373355454 ∧ code e2422373355454 = 11218466377662 := by decide
theorem cert_e2422373355454 : check e2422373355454 [[],[]] .smaller = true := by decide
def e2422373355486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e2422373355486 : Closed e2422373355486 ∧ code e2422373355486 = 11218466377694 := by decide
theorem cert_e2422373355486 : check e2422373355486 [[],[]] .smaller = true := by decide
def e2422373363134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2422373363134 : Closed e2422373363134 ∧ code e2422373363134 = 11218466385342 := by decide
theorem cert_e2422373363134 : check e2422373363134 [[],[]] .three = true := by decide
def e2422373363166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2422373363166 : Closed e2422373363166 ∧ code e2422373363166 = 11218466385374 := by decide
theorem cert_e2422373363166 : check e2422373363166 [[],[]] .smaller = true := by decide
def e2422373363182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2422373363182 : Closed e2422373363182 ∧ code e2422373363182 = 11218466385390 := by decide
theorem cert_e2422373363182 : check e2422373363182 [[],[]] .smaller = true := by decide
def e2422373363190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2422373363190 : Closed e2422373363190 ∧ code e2422373363190 = 11218466385398 := by decide
theorem cert_e2422373363190 : check e2422373363190 [[],[]] .three = true := by decide
def e2422373363390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2422373363390 : Closed e2422373363390 ∧ code e2422373363390 = 11218466385598 := by decide
theorem cert_e2422373363390 : check e2422373363390 [[],[]] .three = true := by decide
def e2422373363450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2422373363450 : Closed e2422373363450 ∧ code e2422373363450 = 11218466385658 := by decide
theorem cert_e2422373363450 : check e2422373363450 [[],[]] .three = true := by decide
def e2422373363550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2422373363550 : Closed e2422373363550 ∧ code e2422373363550 = 11218466385758 := by decide
theorem cert_e2422373363550 : check e2422373363550 [[],[]] .smaller = true := by decide
def e2422373363578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2422373363578 : Closed e2422373363578 ∧ code e2422373363578 = 11218466385786 := by decide
theorem cert_e2422373363578 : check e2422373363578 [[],[]] .smaller = true := by decide
def e2422373363630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2422373363630 : Closed e2422373363630 ∧ code e2422373363630 = 11218466385838 := by decide
theorem cert_e2422373363630 : check e2422373363630 [[],[]] .smaller = true := by decide
def e2422373363642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2422373363642 : Closed e2422373363642 ∧ code e2422373363642 = 11218466385850 := by decide
theorem cert_e2422373363642 : check e2422373363642 [[],[]] .smaller = true := by decide
def e2422373363670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2422373363670 : Closed e2422373363670 ∧ code e2422373363670 = 11218466385878 := by decide
theorem cert_e2422373363670 : check e2422373363670 [[],[]] .three = true := by decide
def e2422373363674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2422373363674 : Closed e2422373363674 ∧ code e2422373363674 = 11218466385882 := by decide
theorem cert_e2422373363674 : check e2422373363674 [[],[]] .three = true := by decide
def e2422373364670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422373364670 : Closed e2422373364670 ∧ code e2422373364670 = 11218466386878 := by decide
theorem cert_e2422373364670 : check e2422373364670 [[],[]] .three = true := by decide
def e2422373364702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422373364702 : Closed e2422373364702 ∧ code e2422373364702 = 11218466386910 := by decide
theorem cert_e2422373364702 : check e2422373364702 [[],[]] .smaller = true := by decide
def e2422373364718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422373364718 : Closed e2422373364718 ∧ code e2422373364718 = 11218466386926 := by decide
theorem cert_e2422373364718 : check e2422373364718 [[],[]] .smaller = true := by decide
def e2422373364726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422373364726 : Closed e2422373364726 ∧ code e2422373364726 = 11218466386934 := by decide
theorem cert_e2422373364726 : check e2422373364726 [[],[]] .three = true := by decide
def e2422373366206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2422373366206 : Closed e2422373366206 ∧ code e2422373366206 = 11218466388414 := by decide
theorem cert_e2422373366206 : check e2422373366206 [[],[]] .three = true := by decide
def e2422373366266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2422373366266 : Closed e2422373366266 ∧ code e2422373366266 = 11218466388474 := by decide
theorem cert_e2422373366266 : check e2422373366266 [[],[]] .three = true := by decide
def e2422373366910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 5))))))))))
theorem wire_e2422373366910 : Closed e2422373366910 ∧ code e2422373366910 = 11218466389118 := by decide
theorem cert_e2422373366910 : check e2422373366910 [[],[]] .three = true := by decide
def e2422373367006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422373367006 : Closed e2422373367006 ∧ code e2422373367006 = 11218466389214 := by decide
theorem cert_e2422373367006 : check e2422373367006 [[],[]] .smaller = true := by decide
def e2422373367034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422373367034 : Closed e2422373367034 ∧ code e2422373367034 = 11218466389242 := by decide
theorem cert_e2422373367034 : check e2422373367034 [[],[]] .smaller = true := by decide
def e2422373367406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373367406 : Closed e2422373367406 ∧ code e2422373367406 = 11218466389614 := by decide
theorem cert_e2422373367406 : check e2422373367406 [[],[]] .smaller = true := by decide
def e2422373367418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373367418 : Closed e2422373367418 ∧ code e2422373367418 = 11218466389626 := by decide
theorem cert_e2422373367418 : check e2422373367418 [[],[]] .smaller = true := by decide
def e2422373367582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.lam (.var 3))))))))))
theorem wire_e2422373367582 : Closed e2422373367582 ∧ code e2422373367582 = 11218466389790 := by decide
theorem cert_e2422373367582 : check e2422373367582 [[],[]] .three = true := by decide
def e2422373367606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373367606 : Closed e2422373367606 ∧ code e2422373367606 = 11218466389814 := by decide
theorem cert_e2422373367606 : check e2422373367606 [[],[]] .three = true := by decide
def e2422373367610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373367610 : Closed e2422373367610 ∧ code e2422373367610 = 11218466389818 := by decide
theorem cert_e2422373367610 : check e2422373367610 [[],[]] .three = true := by decide
def e2422373395822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422373395822 : Closed e2422373395822 ∧ code e2422373395822 = 11218466418030 := by decide
theorem cert_e2422373395822 : check e2422373395822 [[],[]] .smaller = true := by decide
def e2422373395830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422373395830 : Closed e2422373395830 ∧ code e2422373395830 = 11218466418038 := by decide
theorem cert_e2422373395830 : check e2422373395830 [[],[]] .smaller = true := by decide
def e2422373395886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422373395886 : Closed e2422373395886 ∧ code e2422373395886 = 11218466418094 := by decide
theorem cert_e2422373395886 : check e2422373395886 [[],[]] .smaller = true := by decide
def e2422373395898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422373395898 : Closed e2422373395898 ∧ code e2422373395898 = 11218466418106 := by decide
theorem cert_e2422373395898 : check e2422373395898 [[],[]] .smaller = true := by decide
def e2422373395926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422373395926 : Closed e2422373395926 ∧ code e2422373395926 = 11218466418134 := by decide
theorem cert_e2422373395926 : check e2422373395926 [[],[]] .smaller = true := by decide
def e2422373395930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422373395930 : Closed e2422373395930 ∧ code e2422373395930 = 11218466418138 := by decide
theorem cert_e2422373395930 : check e2422373395930 [[],[]] .smaller = true := by decide
def e2422373396142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422373396142 : Closed e2422373396142 ∧ code e2422373396142 = 11218466418350 := by decide
theorem cert_e2422373396142 : check e2422373396142 [[],[]] .smaller = true := by decide
def e2422373396154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422373396154 : Closed e2422373396154 ∧ code e2422373396154 = 11218466418362 := by decide
theorem cert_e2422373396154 : check e2422373396154 [[],[]] .smaller = true := by decide
def e2422373396202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422373396202 : Closed e2422373396202 ∧ code e2422373396202 = 11218466418410 := by decide
theorem cert_e2422373396202 : check e2422373396202 [[],[]] .smaller = true := by decide
def e2422373396310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422373396310 : Closed e2422373396310 ∧ code e2422373396310 = 11218466418518 := by decide
theorem cert_e2422373396310 : check e2422373396310 [[],[]] .smaller = true := by decide
def e2422373396314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422373396314 : Closed e2422373396314 ∧ code e2422373396314 = 11218466418522 := by decide
theorem cert_e2422373396314 : check e2422373396314 [[],[]] .smaller = true := by decide
def e2422373396330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422373396330 : Closed e2422373396330 ∧ code e2422373396330 = 11218466418538 := by decide
theorem cert_e2422373396330 : check e2422373396330 [[],[]] .smaller = true := by decide
def e2422373396958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2422373396958 : Closed e2422373396958 ∧ code e2422373396958 = 11218466419166 := by decide
theorem cert_e2422373396958 : check e2422373396958 [[],[]] .three = true := by decide
def e2422373396982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2422373396982 : Closed e2422373396982 ∧ code e2422373396982 = 11218466419190 := by decide
theorem cert_e2422373396982 : check e2422373396982 [[],[]] .three = true := by decide
def e2422373397358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422373397358 : Closed e2422373397358 ∧ code e2422373397358 = 11218466419566 := by decide
theorem cert_e2422373397358 : check e2422373397358 [[],[]] .smaller = true := by decide
def e2422373397366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422373397366 : Closed e2422373397366 ∧ code e2422373397366 = 11218466419574 := by decide
theorem cert_e2422373397366 : check e2422373397366 [[],[]] .smaller = true := by decide
def e2422373397422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422373397422 : Closed e2422373397422 ∧ code e2422373397422 = 11218466419630 := by decide
theorem cert_e2422373397422 : check e2422373397422 [[],[]] .smaller = true := by decide
def e2422373397434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422373397434 : Closed e2422373397434 ∧ code e2422373397434 = 11218466419642 := by decide
theorem cert_e2422373397434 : check e2422373397434 [[],[]] .smaller = true := by decide
def e2422373397462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422373397462 : Closed e2422373397462 ∧ code e2422373397462 = 11218466419670 := by decide
theorem cert_e2422373397462 : check e2422373397462 [[],[]] .smaller = true := by decide
def e2422373397466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422373397466 : Closed e2422373397466 ∧ code e2422373397466 = 11218466419674 := by decide
theorem cert_e2422373397466 : check e2422373397466 [[],[]] .smaller = true := by decide
def e2422373397742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373397742 : Closed e2422373397742 ∧ code e2422373397742 = 11218466419950 := by decide
theorem cert_e2422373397742 : check e2422373397742 [[],[]] .smaller = true := by decide
def e2422373397750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373397750 : Closed e2422373397750 ∧ code e2422373397750 = 11218466419958 := by decide
theorem cert_e2422373397750 : check e2422373397750 [[],[]] .smaller = true := by decide
def e2422373398078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2422373398078 : Closed e2422373398078 ∧ code e2422373398078 = 11218466420286 := by decide
theorem cert_e2422373398078 : check e2422373398078 [[],[]] .three = true := by decide
def e2422373398126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373398126 : Closed e2422373398126 ∧ code e2422373398126 = 11218466420334 := by decide
theorem cert_e2422373398126 : check e2422373398126 [[],[]] .smaller = true := by decide
def e2422373398138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373398138 : Closed e2422373398138 ∧ code e2422373398138 = 11218466420346 := by decide
theorem cert_e2422373398138 : check e2422373398138 [[],[]] .smaller = true := by decide
def e2422373398326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373398326 : Closed e2422373398326 ∧ code e2422373398326 = 11218466420534 := by decide
theorem cert_e2422373398326 : check e2422373398326 [[],[]] .smaller = true := by decide
def e2422373398330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373398330 : Closed e2422373398330 ∧ code e2422373398330 = 11218466420538 := by decide
theorem cert_e2422373398330 : check e2422373398330 [[],[]] .smaller = true := by decide
def e2422373398414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2422373398414 : Closed e2422373398414 ∧ code e2422373398414 = 11218466420622 := by decide
theorem cert_e2422373398414 : check e2422373398414 [[],[]] .three = true := by decide
def e2422373398574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422373398574 : Closed e2422373398574 ∧ code e2422373398574 = 11218466420782 := by decide
theorem cert_e2422373398574 : check e2422373398574 [[],[]] .smaller = true := by decide
def e2422373398750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422373398750 : Closed e2422373398750 ∧ code e2422373398750 = 11218466420958 := by decide
theorem cert_e2422373398750 : check e2422373398750 [[],[]] .three = true := by decide
def e2422373398766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422373398766 : Closed e2422373398766 ∧ code e2422373398766 = 11218466420974 := by decide
theorem cert_e2422373398766 : check e2422373398766 [[],[]] .smaller = true := by decide
def e2422373398774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422373398774 : Closed e2422373398774 ∧ code e2422373398774 = 11218466420982 := by decide
theorem cert_e2422373398774 : check e2422373398774 [[],[]] .smaller = true := by decide
def e2422373398778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422373398778 : Closed e2422373398778 ∧ code e2422373398778 = 11218466420986 := by decide
theorem cert_e2422373398778 : check e2422373398778 [[],[]] .three = true := by decide
def e2422373398958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422373398958 : Closed e2422373398958 ∧ code e2422373398958 = 11218466421166 := by decide
theorem cert_e2422373398958 : check e2422373398958 [[],[]] .smaller = true := by decide
end Blc.Floor43
