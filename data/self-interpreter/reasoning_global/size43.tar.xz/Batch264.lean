import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406036699674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406036699674 : Closed e2406036699674 ∧ code e2406036699674 = 11202129721882 := by decide
theorem cert_e2406036699674 : check e2406036699674 [[]] .width = true := by decide
def e2406036701210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406036701210 : Closed e2406036701210 ∧ code e2406036701210 = 11202129723418 := by decide
theorem cert_e2406036701210 : check e2406036701210 [[]] .width = true := by decide
def e2406036701302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406036701302 : Closed e2406036701302 ∧ code e2406036701302 = 11202129723510 := by decide
theorem cert_e2406036701302 : check e2406036701302 [[]] .width = true := by decide
def e2406036701546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406036701546 : Closed e2406036701546 ∧ code e2406036701546 = 11202129723754 := by decide
theorem cert_e2406036701546 : check e2406036701546 [[]] .width = true := by decide
def e2406036701594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406036701594 : Closed e2406036701594 ∧ code e2406036701594 = 11202129723802 := by decide
theorem cert_e2406036701594 : check e2406036701594 [[]] .width = true := by decide
def e2406036702602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406036702602 : Closed e2406036702602 ∧ code e2406036702602 = 11202129724810 := by decide
theorem cert_e2406036702602 : check e2406036702602 [[]] .width = true := by decide
def e2406036702626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406036702626 : Closed e2406036702626 ∧ code e2406036702626 = 11202129724834 := by decide
theorem cert_e2406036702626 : check e2406036702626 [[]] .width = true := by decide
def e2406036702734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406036702734 : Closed e2406036702734 ∧ code e2406036702734 = 11202129724942 := by decide
theorem cert_e2406036702734 : check e2406036702734 [[]] .width = true := by decide
def e2406036702746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406036702746 : Closed e2406036702746 ∧ code e2406036702746 = 11202129724954 := by decide
theorem cert_e2406036702746 : check e2406036702746 [[]] .width = true := by decide
def e2406036702818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406036702818 : Closed e2406036702818 ∧ code e2406036702818 = 11202129725026 := by decide
theorem cert_e2406036702818 : check e2406036702818 [[]] .width = true := by decide
def e2406036717766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406036717766 : Closed e2406036717766 ∧ code e2406036717766 = 11202129739974 := by decide
theorem cert_e2406036717766 : check e2406036717766 [[]] .width = true := by decide
def e2406036725786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406036725786 : Closed e2406036725786 ∧ code e2406036725786 = 11202129747994 := by decide
theorem cert_e2406036725786 : check e2406036725786 [[]] .width = true := by decide
def e2406036725878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406036725878 : Closed e2406036725878 ∧ code e2406036725878 = 11202129748086 := by decide
theorem cert_e2406036725878 : check e2406036725878 [[]] .width = true := by decide
def e2406036726122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406036726122 : Closed e2406036726122 ∧ code e2406036726122 = 11202129748330 := by decide
theorem cert_e2406036726122 : check e2406036726122 [[]] .width = true := by decide
def e2406036726170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406036726170 : Closed e2406036726170 ∧ code e2406036726170 = 11202129748378 := by decide
theorem cert_e2406036726170 : check e2406036726170 [[]] .width = true := by decide
def e2406036747802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406036747802 : Closed e2406036747802 ∧ code e2406036747802 = 11202129770010 := by decide
theorem cert_e2406036747802 : check e2406036747802 [[]] .width = true := by decide
def e2406036748826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406036748826 : Closed e2406036748826 ∧ code e2406036748826 = 11202129771034 := by decide
theorem cert_e2406036748826 : check e2406036748826 [[]] .width = true := by decide
def e2406036758554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406036758554 : Closed e2406036758554 ∧ code e2406036758554 = 11202129780762 := by decide
theorem cert_e2406036758554 : check e2406036758554 [[]] .width = true := by decide
def e2406036758646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406036758646 : Closed e2406036758646 ∧ code e2406036758646 = 11202129780854 := by decide
theorem cert_e2406036758646 : check e2406036758646 [[]] .width = true := by decide
def e2406036758890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406036758890 : Closed e2406036758890 ∧ code e2406036758890 = 11202129781098 := by decide
theorem cert_e2406036758890 : check e2406036758890 [[]] .width = true := by decide
def e2406036758938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406036758938 : Closed e2406036758938 ∧ code e2406036758938 = 11202129781146 := by decide
theorem cert_e2406036758938 : check e2406036758938 [[]] .width = true := by decide
def e2406040320026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040320026 : Closed e2406040320026 ∧ code e2406040320026 = 11202133342234 := by decide
theorem cert_e2406040320026 : check e2406040320026 [[]] .width = true := by decide
def e2406040328218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040328218 : Closed e2406040328218 ∧ code e2406040328218 = 11202133350426 := by decide
theorem cert_e2406040328218 : check e2406040328218 [[]] .width = true := by decide
def e2406040385562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040385562 : Closed e2406040385562 ∧ code e2406040385562 = 11202133407770 := by decide
theorem cert_e2406040385562 : check e2406040385562 [[]] .width = true := by decide
def e2406040397850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040397850 : Closed e2406040397850 ∧ code e2406040397850 = 11202133420058 := by decide
theorem cert_e2406040397850 : check e2406040397850 [[]] .width = true := by decide
def e2406040399386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406040399386 : Closed e2406040399386 ∧ code e2406040399386 = 11202133421594 := by decide
theorem cert_e2406040399386 : check e2406040399386 [[]] .width = true := by decide
def e2406040426522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040426522 : Closed e2406040426522 ∧ code e2406040426522 = 11202133448730 := by decide
theorem cert_e2406040426522 : check e2406040426522 [[]] .width = true := by decide
def e2406040430618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040430618 : Closed e2406040430618 ∧ code e2406040430618 = 11202133452826 := by decide
theorem cert_e2406040430618 : check e2406040430618 [[]] .width = true := by decide
def e2406040432154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406040432154 : Closed e2406040432154 ∧ code e2406040432154 = 11202133454362 := by decide
theorem cert_e2406040432154 : check e2406040432154 [[]] .width = true := by decide
def e2406040434202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406040434202 : Closed e2406040434202 ∧ code e2406040434202 = 11202133456410 := by decide
theorem cert_e2406040434202 : check e2406040434202 [[]] .width = true := by decide
def e2406040713242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040713242 : Closed e2406040713242 ∧ code e2406040713242 = 11202133735450 := by decide
theorem cert_e2406040713242 : check e2406040713242 [[]] .width = true := by decide
def e2406040721434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406040721434 : Closed e2406040721434 ∧ code e2406040721434 = 11202133743642 := by decide
theorem cert_e2406040721434 : check e2406040721434 [[]] .width = true := by decide
def e2406041055430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406041055430 : Closed e2406041055430 ∧ code e2406041055430 = 11202134077638 := by decide
theorem cert_e2406041055430 : check e2406041055430 [[]] .width = true := by decide
def e2406041106458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406041106458 : Closed e2406041106458 ∧ code e2406041106458 = 11202134128666 := by decide
theorem cert_e2406041106458 : check e2406041106458 [[]] .width = true := by decide
def e2406041118746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406041118746 : Closed e2406041118746 ∧ code e2406041118746 = 11202134140954 := by decide
theorem cert_e2406041118746 : check e2406041118746 [[]] .width = true := by decide
def e2406041120282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406041120282 : Closed e2406041120282 ∧ code e2406041120282 = 11202134142490 := by decide
theorem cert_e2406041120282 : check e2406041120282 [[]] .width = true := by decide
def e2406041223194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406041223194 : Closed e2406041223194 ∧ code e2406041223194 = 11202134245402 := by decide
theorem cert_e2406041223194 : check e2406041223194 [[]] .width = true := by decide
def e2406041223286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406041223286 : Closed e2406041223286 ∧ code e2406041223286 = 11202134245494 := by decide
theorem cert_e2406041223286 : check e2406041223286 [[]] .width = true := by decide
def e2406041223530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406041223530 : Closed e2406041223530 ∧ code e2406041223530 = 11202134245738 := by decide
theorem cert_e2406041223530 : check e2406041223530 [[]] .width = true := by decide
def e2406041223578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406041223578 : Closed e2406041223578 ∧ code e2406041223578 = 11202134245786 := by decide
theorem cert_e2406041223578 : check e2406041223578 [[]] .width = true := by decide
def e2406041224586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406041224586 : Closed e2406041224586 ∧ code e2406041224586 = 11202134246794 := by decide
theorem cert_e2406041224586 : check e2406041224586 [[]] .width = true := by decide
def e2406041224610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406041224610 : Closed e2406041224610 ∧ code e2406041224610 = 11202134246818 := by decide
theorem cert_e2406041224610 : check e2406041224610 [[]] .width = true := by decide
def e2406041224718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406041224718 : Closed e2406041224718 ∧ code e2406041224718 = 11202134246926 := by decide
theorem cert_e2406041224718 : check e2406041224718 [[]] .width = true := by decide
def e2406041224730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406041224730 : Closed e2406041224730 ∧ code e2406041224730 = 11202134246938 := by decide
theorem cert_e2406041224730 : check e2406041224730 [[]] .width = true := by decide
def e2406041224802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406041224802 : Closed e2406041224802 ∧ code e2406041224802 = 11202134247010 := by decide
theorem cert_e2406041224802 : check e2406041224802 [[]] .width = true := by decide
def e2406041284806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406041284806 : Closed e2406041284806 ∧ code e2406041284806 = 11202134307014 := by decide
theorem cert_e2406041284806 : check e2406041284806 [[]] .width = true := by decide
def e2406041311258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406041311258 : Closed e2406041311258 ∧ code e2406041311258 = 11202134333466 := by decide
theorem cert_e2406041311258 : check e2406041311258 [[]] .width = true := by decide
def e2406041315354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406041315354 : Closed e2406041315354 ∧ code e2406041315354 = 11202134337562 := by decide
theorem cert_e2406041315354 : check e2406041315354 [[]] .width = true := by decide
def e2406041316890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406041316890 : Closed e2406041316890 ∧ code e2406041316890 = 11202134339098 := by decide
theorem cert_e2406041316890 : check e2406041316890 [[]] .width = true := by decide
def e2406041318938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406041318938 : Closed e2406041318938 ∧ code e2406041318938 = 11202134341146 := by decide
theorem cert_e2406041318938 : check e2406041318938 [[]] .width = true := by decide
def e2406041354266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406041354266 : Closed e2406041354266 ∧ code e2406041354266 = 11202134376474 := by decide
theorem cert_e2406041354266 : check e2406041354266 [[]] .width = true := by decide
def e2406041354358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406041354358 : Closed e2406041354358 ∧ code e2406041354358 = 11202134376566 := by decide
theorem cert_e2406041354358 : check e2406041354358 [[]] .width = true := by decide
def e2406041354602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406041354602 : Closed e2406041354602 ∧ code e2406041354602 = 11202134376810 := by decide
theorem cert_e2406041354602 : check e2406041354602 [[]] .width = true := by decide
def e2406041354650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406041354650 : Closed e2406041354650 ∧ code e2406041354650 = 11202134376858 := by decide
theorem cert_e2406041354650 : check e2406041354650 [[]] .width = true := by decide
def e2406041355658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406041355658 : Closed e2406041355658 ∧ code e2406041355658 = 11202134377866 := by decide
theorem cert_e2406041355658 : check e2406041355658 [[]] .width = true := by decide
def e2406041355682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406041355682 : Closed e2406041355682 ∧ code e2406041355682 = 11202134377890 := by decide
theorem cert_e2406041355682 : check e2406041355682 [[]] .width = true := by decide
def e2406041355790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406041355790 : Closed e2406041355790 ∧ code e2406041355790 = 11202134377998 := by decide
theorem cert_e2406041355790 : check e2406041355790 [[]] .width = true := by decide
def e2406041355802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406041355802 : Closed e2406041355802 ∧ code e2406041355802 = 11202134378010 := by decide
theorem cert_e2406041355802 : check e2406041355802 [[]] .width = true := by decide
def e2406041355874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406041355874 : Closed e2406041355874 ∧ code e2406041355874 = 11202134378082 := by decide
theorem cert_e2406041355874 : check e2406041355874 [[]] .width = true := by decide
def e2406045966362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406045966362 : Closed e2406045966362 ∧ code e2406045966362 = 11202138988570 := by decide
theorem cert_e2406045966362 : check e2406045966362 [[]] .width = true := by decide
def e2406045966454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406045966454 : Closed e2406045966454 ∧ code e2406045966454 = 11202138988662 := by decide
theorem cert_e2406045966454 : check e2406045966454 [[]] .width = true := by decide
def e2406045966698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406045966698 : Closed e2406045966698 ∧ code e2406045966698 = 11202138988906 := by decide
theorem cert_e2406045966698 : check e2406045966698 [[]] .width = true := by decide
def e2406045966746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406045966746 : Closed e2406045966746 ∧ code e2406045966746 = 11202138988954 := by decide
theorem cert_e2406045966746 : check e2406045966746 [[]] .width = true := by decide
def e2406046167238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406046167238 : Closed e2406046167238 ∧ code e2406046167238 = 11202139189446 := by decide
theorem cert_e2406046167238 : check e2406046167238 [[]] .width = true := by decide
def e2406046224582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406046224582 : Closed e2406046224582 ∧ code e2406046224582 = 11202139246790 := by decide
theorem cert_e2406046224582 : check e2406046224582 [[]] .width = true := by decide
def e2406046227994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406046227994 : Closed e2406046227994 ∧ code e2406046227994 = 11202139250202 := by decide
theorem cert_e2406046227994 : check e2406046227994 [[]] .width = true := by decide
def e2406046695622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406046695622 : Closed e2406046695622 ∧ code e2406046695622 = 11202139717830 := by decide
theorem cert_e2406046695622 : check e2406046695622 [[]] .width = true := by decide
def e2406046696150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2406046696150 : Closed e2406046696150 ∧ code e2406046696150 = 11202139718358 := by decide
theorem cert_e2406046696150 : check e2406046696150 [[]] .width = true := by decide
def e2406046696154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2406046696154 : Closed e2406046696154 ∧ code e2406046696154 = 11202139718362 := by decide
theorem cert_e2406046696154 : check e2406046696154 [[]] .width = true := by decide
def e2406046696170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2406046696170 : Closed e2406046696170 ∧ code e2406046696170 = 11202139718378 := by decide
theorem cert_e2406046696170 : check e2406046696170 [[]] .width = true := by decide
def e2406046696246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2406046696246 : Closed e2406046696246 ∧ code e2406046696246 = 11202139718454 := by decide
theorem cert_e2406046696246 : check e2406046696246 [[]] .width = true := by decide
def e2406046696250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2406046696250 : Closed e2406046696250 ∧ code e2406046696250 = 11202139718458 := by decide
theorem cert_e2406046696250 : check e2406046696250 [[]] .width = true := by decide
def e2406046696334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2406046696334 : Closed e2406046696334 ∧ code e2406046696334 = 11202139718542 := by decide
theorem cert_e2406046696334 : check e2406046696334 [[]] .width = true := by decide
def e2406046696346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2406046696346 : Closed e2406046696346 ∧ code e2406046696346 = 11202139718554 := by decide
theorem cert_e2406046696346 : check e2406046696346 [[]] .width = true := by decide
def e2406046698266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2406046698266 : Closed e2406046698266 ∧ code e2406046698266 = 11202139720474 := by decide
theorem cert_e2406046698266 : check e2406046698266 [[]] .width = true := by decide
def e2406046698310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2406046698310 : Closed e2406046698310 ∧ code e2406046698310 = 11202139720518 := by decide
theorem cert_e2406046698310 : check e2406046698310 [[]] .width = true := by decide
def e2406046698550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2406046698550 : Closed e2406046698550 ∧ code e2406046698550 = 11202139720758 := by decide
theorem cert_e2406046698550 : check e2406046698550 [[]] .width = true := by decide
def e2406046698554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2406046698554 : Closed e2406046698554 ∧ code e2406046698554 = 11202139720762 := by decide
theorem cert_e2406046698554 : check e2406046698554 [[]] .width = true := by decide
def e2406046698694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406046698694 : Closed e2406046698694 ∧ code e2406046698694 = 11202139720902 := by decide
theorem cert_e2406046698694 : check e2406046698694 [[]] .width = true := by decide
def e2406047201306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047201306 : Closed e2406047201306 ∧ code e2406047201306 = 11202140223514 := by decide
theorem cert_e2406047201306 : check e2406047201306 [[]] .width = true := by decide
def e2406047213594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047213594 : Closed e2406047213594 ∧ code e2406047213594 = 11202140235802 := by decide
theorem cert_e2406047213594 : check e2406047213594 [[]] .width = true := by decide
def e2406047215130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406047215130 : Closed e2406047215130 ∧ code e2406047215130 = 11202140237338 := by decide
theorem cert_e2406047215130 : check e2406047215130 [[]] .width = true := by decide
def e2406047262746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047262746 : Closed e2406047262746 ∧ code e2406047262746 = 11202140284954 := by decide
theorem cert_e2406047262746 : check e2406047262746 [[]] .width = true := by decide
def e2406047264282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406047264282 : Closed e2406047264282 ∧ code e2406047264282 = 11202140286490 := by decide
theorem cert_e2406047264282 : check e2406047264282 [[]] .width = true := by decide
def e2406047267354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406047267354 : Closed e2406047267354 ∧ code e2406047267354 = 11202140289562 := by decide
theorem cert_e2406047267354 : check e2406047267354 [[]] .width = true := by decide
def e2406047346886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406047346886 : Closed e2406047346886 ∧ code e2406047346886 = 11202140369094 := by decide
theorem cert_e2406047346886 : check e2406047346886 [[]] .width = true := by decide
def e2406047397914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047397914 : Closed e2406047397914 ∧ code e2406047397914 = 11202140420122 := by decide
theorem cert_e2406047397914 : check e2406047397914 [[]] .width = true := by decide
def e2406047410202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047410202 : Closed e2406047410202 ∧ code e2406047410202 = 11202140432410 := by decide
theorem cert_e2406047410202 : check e2406047410202 [[]] .width = true := by decide
def e2406047411738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406047411738 : Closed e2406047411738 ∧ code e2406047411738 = 11202140433946 := by decide
theorem cert_e2406047411738 : check e2406047411738 [[]] .width = true := by decide
def e2406047514650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406047514650 : Closed e2406047514650 ∧ code e2406047514650 = 11202140536858 := by decide
theorem cert_e2406047514650 : check e2406047514650 [[]] .width = true := by decide
def e2406047514742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406047514742 : Closed e2406047514742 ∧ code e2406047514742 = 11202140536950 := by decide
theorem cert_e2406047514742 : check e2406047514742 [[]] .width = true := by decide
def e2406047514986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406047514986 : Closed e2406047514986 ∧ code e2406047514986 = 11202140537194 := by decide
theorem cert_e2406047514986 : check e2406047514986 [[]] .width = true := by decide
def e2406047515034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406047515034 : Closed e2406047515034 ∧ code e2406047515034 = 11202140537242 := by decide
theorem cert_e2406047515034 : check e2406047515034 [[]] .width = true := by decide
def e2406047516042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406047516042 : Closed e2406047516042 ∧ code e2406047516042 = 11202140538250 := by decide
theorem cert_e2406047516042 : check e2406047516042 [[]] .width = true := by decide
def e2406047516066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406047516066 : Closed e2406047516066 ∧ code e2406047516066 = 11202140538274 := by decide
theorem cert_e2406047516066 : check e2406047516066 [[]] .width = true := by decide
def e2406047516174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406047516174 : Closed e2406047516174 ∧ code e2406047516174 = 11202140538382 := by decide
theorem cert_e2406047516174 : check e2406047516174 [[]] .width = true := by decide
def e2406047516186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406047516186 : Closed e2406047516186 ∧ code e2406047516186 = 11202140538394 := by decide
theorem cert_e2406047516186 : check e2406047516186 [[]] .width = true := by decide
def e2406047516258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406047516258 : Closed e2406047516258 ∧ code e2406047516258 = 11202140538466 := by decide
theorem cert_e2406047516258 : check e2406047516258 [[]] .width = true := by decide
def e2406047662278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406047662278 : Closed e2406047662278 ∧ code e2406047662278 = 11202140684486 := by decide
theorem cert_e2406047662278 : check e2406047662278 [[]] .width = true := by decide
def e2406047680538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047680538 : Closed e2406047680538 ∧ code e2406047680538 = 11202140702746 := by decide
theorem cert_e2406047680538 : check e2406047680538 [[]] .width = true := by decide
def e2406047686682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406047686682 : Closed e2406047686682 ∧ code e2406047686682 = 11202140708890 := by decide
theorem cert_e2406047686682 : check e2406047686682 [[]] .width = true := by decide
def e2406047686774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406047686774 : Closed e2406047686774 ∧ code e2406047686774 = 11202140708982 := by decide
theorem cert_e2406047686774 : check e2406047686774 [[]] .width = true := by decide
def e2406047687018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406047687018 : Closed e2406047687018 ∧ code e2406047687018 = 11202140709226 := by decide
theorem cert_e2406047687018 : check e2406047687018 [[]] .width = true := by decide
def e2406047687066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406047687066 : Closed e2406047687066 ∧ code e2406047687066 = 11202140709274 := by decide
theorem cert_e2406047687066 : check e2406047687066 [[]] .width = true := by decide
def e2406047690950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406047690950 : Closed e2406047690950 ∧ code e2406047690950 = 11202140713158 := by decide
theorem cert_e2406047690950 : check e2406047690950 [[]] .width = true := by decide
def e2406047692826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047692826 : Closed e2406047692826 ∧ code e2406047692826 = 11202140715034 := by decide
theorem cert_e2406047692826 : check e2406047692826 [[]] .width = true := by decide
def e2406047705114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406047705114 : Closed e2406047705114 ∧ code e2406047705114 = 11202140727322 := by decide
theorem cert_e2406047705114 : check e2406047705114 [[]] .width = true := by decide
def e2406047706650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406047706650 : Closed e2406047706650 ∧ code e2406047706650 = 11202140728858 := by decide
theorem cert_e2406047706650 : check e2406047706650 [[]] .width = true := by decide
def e2406047709722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406047709722 : Closed e2406047709722 ∧ code e2406047709722 = 11202140731930 := by decide
theorem cert_e2406047709722 : check e2406047709722 [[]] .width = true := by decide
def e2406047711258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406047711258 : Closed e2406047711258 ∧ code e2406047711258 = 11202140733466 := by decide
theorem cert_e2406047711258 : check e2406047711258 [[]] .width = true := by decide
def e2406047711350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406047711350 : Closed e2406047711350 ∧ code e2406047711350 = 11202140733558 := by decide
theorem cert_e2406047711350 : check e2406047711350 [[]] .width = true := by decide
def e2406047711594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406047711594 : Closed e2406047711594 ∧ code e2406047711594 = 11202140733802 := by decide
theorem cert_e2406047711594 : check e2406047711594 [[]] .width = true := by decide
def e2406047711642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406047711642 : Closed e2406047711642 ∧ code e2406047711642 = 11202140733850 := by decide
theorem cert_e2406047711642 : check e2406047711642 [[]] .width = true := by decide
def e2406047712650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406047712650 : Closed e2406047712650 ∧ code e2406047712650 = 11202140734858 := by decide
theorem cert_e2406047712650 : check e2406047712650 [[]] .width = true := by decide
def e2406047712674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406047712674 : Closed e2406047712674 ∧ code e2406047712674 = 11202140734882 := by decide
theorem cert_e2406047712674 : check e2406047712674 [[]] .width = true := by decide
def e2406047712782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406047712782 : Closed e2406047712782 ∧ code e2406047712782 = 11202140734990 := by decide
theorem cert_e2406047712782 : check e2406047712782 [[]] .width = true := by decide
def e2406047712794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406047712794 : Closed e2406047712794 ∧ code e2406047712794 = 11202140735002 := by decide
theorem cert_e2406047712794 : check e2406047712794 [[]] .width = true := by decide
def e2406047712866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406047712866 : Closed e2406047712866 ∧ code e2406047712866 = 11202140735074 := by decide
theorem cert_e2406047712866 : check e2406047712866 [[]] .width = true := by decide
def e2406047727814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406047727814 : Closed e2406047727814 ∧ code e2406047727814 = 11202140750022 := by decide
theorem cert_e2406047727814 : check e2406047727814 [[]] .width = true := by decide
def e2406047735834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406047735834 : Closed e2406047735834 ∧ code e2406047735834 = 11202140758042 := by decide
theorem cert_e2406047735834 : check e2406047735834 [[]] .width = true := by decide
def e2406047735926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406047735926 : Closed e2406047735926 ∧ code e2406047735926 = 11202140758134 := by decide
theorem cert_e2406047735926 : check e2406047735926 [[]] .width = true := by decide
def e2406047736170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406047736170 : Closed e2406047736170 ∧ code e2406047736170 = 11202140758378 := by decide
theorem cert_e2406047736170 : check e2406047736170 [[]] .width = true := by decide
def e2406047736218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406047736218 : Closed e2406047736218 ∧ code e2406047736218 = 11202140758426 := by decide
theorem cert_e2406047736218 : check e2406047736218 [[]] .width = true := by decide
def e2406049382426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2406049382426 : Closed e2406049382426 ∧ code e2406049382426 = 11202142404634 := by decide
theorem cert_e2406049382426 : check e2406049382426 [[]] .width = true := by decide
def e2406049382518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2406049382518 : Closed e2406049382518 ∧ code e2406049382518 = 11202142404726 := by decide
theorem cert_e2406049382518 : check e2406049382518 [[]] .width = true := by decide
def e2406049382762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2406049382762 : Closed e2406049382762 ∧ code e2406049382762 = 11202142404970 := by decide
theorem cert_e2406049382762 : check e2406049382762 [[]] .width = true := by decide
def e2406049382810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2406049382810 : Closed e2406049382810 ∧ code e2406049382810 = 11202142405018 := by decide
theorem cert_e2406049382810 : check e2406049382810 [[]] .width = true := by decide
def e2406049382894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2406049382894 : Closed e2406049382894 ∧ code e2406049382894 = 11202142405102 := by decide
theorem cert_e2406049382894 : check e2406049382894 [[]] .width = true := by decide
def e2406049383818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2406049383818 : Closed e2406049383818 ∧ code e2406049383818 = 11202142406026 := by decide
theorem cert_e2406049383818 : check e2406049383818 [[]] .width = true := by decide
def e2406049383842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2406049383842 : Closed e2406049383842 ∧ code e2406049383842 = 11202142406050 := by decide
theorem cert_e2406049383842 : check e2406049383842 [[]] .width = true := by decide
def e2406049383854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2406049383854 : Closed e2406049383854 ∧ code e2406049383854 = 11202142406062 := by decide
theorem cert_e2406049383854 : check e2406049383854 [[]] .width = true := by decide
def e2406049383862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2406049383862 : Closed e2406049383862 ∧ code e2406049383862 = 11202142406070 := by decide
theorem cert_e2406049383862 : check e2406049383862 [[]] .width = true := by decide
def e2406049383866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2406049383866 : Closed e2406049383866 ∧ code e2406049383866 = 11202142406074 := by decide
theorem cert_e2406049383866 : check e2406049383866 [[]] .width = true := by decide
def e2406049383894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2406049383894 : Closed e2406049383894 ∧ code e2406049383894 = 11202142406102 := by decide
theorem cert_e2406049383894 : check e2406049383894 [[]] .width = true := by decide
def e2406049383898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2406049383898 : Closed e2406049383898 ∧ code e2406049383898 = 11202142406106 := by decide
theorem cert_e2406049383898 : check e2406049383898 [[]] .width = true := by decide
def e2406049383914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2406049383914 : Closed e2406049383914 ∧ code e2406049383914 = 11202142406122 := by decide
theorem cert_e2406049383914 : check e2406049383914 [[]] .width = true := by decide
def e2406049383950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2406049383950 : Closed e2406049383950 ∧ code e2406049383950 = 11202142406158 := by decide
theorem cert_e2406049383950 : check e2406049383950 [[]] .width = true := by decide
def e2406049383962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406049383962 : Closed e2406049383962 ∧ code e2406049383962 = 11202142406170 := by decide
theorem cert_e2406049383962 : check e2406049383962 [[]] .width = true := by decide
def e2406049384034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2406049384034 : Closed e2406049384034 ∧ code e2406049384034 = 11202142406242 := by decide
theorem cert_e2406049384034 : check e2406049384034 [[]] .width = true := by decide
def e2406049384046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e2406049384046 : Closed e2406049384046 ∧ code e2406049384046 = 11202142406254 := by decide
theorem cert_e2406049384046 : check e2406049384046 [[]] .width = true := by decide
def e2406049384054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1)))))))
theorem wire_e2406049384054 : Closed e2406049384054 ∧ code e2406049384054 = 11202142406262 := by decide
theorem cert_e2406049384054 : check e2406049384054 [[]] .width = true := by decide
def e2406049384058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e2406049384058 : Closed e2406049384058 ∧ code e2406049384058 = 11202142406266 := by decide
theorem cert_e2406049384058 : check e2406049384058 [[]] .width = true := by decide
def e2406049384246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1)))))))
theorem wire_e2406049384246 : Closed e2406049384246 ∧ code e2406049384246 = 11202142406454 := by decide
theorem cert_e2406049384246 : check e2406049384246 [[]] .width = true := by decide
def e2406049384250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0)))))))
theorem wire_e2406049384250 : Closed e2406049384250 ∧ code e2406049384250 = 11202142406458 := by decide
theorem cert_e2406049384250 : check e2406049384250 [[]] .width = true := by decide
def e2406049384346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e2406049384346 : Closed e2406049384346 ∧ code e2406049384346 = 11202142406554 := by decide
theorem cert_e2406049384346 : check e2406049384346 [[]] .width = true := by decide
def e2406049387946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)))))
theorem wire_e2406049387946 : Closed e2406049387946 ∧ code e2406049387946 = 11202142410154 := by decide
theorem cert_e2406049387946 : check e2406049387946 [[]] .width = true := by decide
def e2406049388042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)))))
theorem wire_e2406049388042 : Closed e2406049388042 ∧ code e2406049388042 = 11202142410250 := by decide
theorem cert_e2406049388042 : check e2406049388042 [[]] .width = true := by decide
def e2406049388086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e2406049388086 : Closed e2406049388086 ∧ code e2406049388086 = 11202142410294 := by decide
theorem cert_e2406049388086 : check e2406049388086 [[]] .width = true := by decide
def e2406049388090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e2406049388090 : Closed e2406049388090 ∧ code e2406049388090 = 11202142410298 := by decide
theorem cert_e2406049388090 : check e2406049388090 [[]] .width = true := by decide
def e2406049388138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)))))
theorem wire_e2406049388138 : Closed e2406049388138 ∧ code e2406049388138 = 11202142410346 := by decide
theorem cert_e2406049388138 : check e2406049388138 [[]] .width = true := by decide
def e2406049388162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))))))
theorem wire_e2406049388162 : Closed e2406049388162 ∧ code e2406049388162 = 11202142410370 := by decide
theorem cert_e2406049388162 : check e2406049388162 [[]] .width = true := by decide
def e2406049388174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e2406049388174 : Closed e2406049388174 ∧ code e2406049388174 = 11202142410382 := by decide
theorem cert_e2406049388174 : check e2406049388174 [[]] .width = true := by decide
def e2406049388186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))))))
theorem wire_e2406049388186 : Closed e2406049388186 ∧ code e2406049388186 = 11202142410394 := by decide
theorem cert_e2406049388186 : check e2406049388186 [[]] .width = true := by decide
def e2406049388230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e2406049388230 : Closed e2406049388230 ∧ code e2406049388230 = 11202142410438 := by decide
theorem cert_e2406049388230 : check e2406049388230 [[]] .width = true := by decide
def e2406049388310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))
theorem wire_e2406049388310 : Closed e2406049388310 ∧ code e2406049388310 = 11202142410518 := by decide
theorem cert_e2406049388310 : check e2406049388310 [[]] .width = true := by decide
def e2406049388314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e2406049388314 : Closed e2406049388314 ∧ code e2406049388314 = 11202142410522 := by decide
theorem cert_e2406049388314 : check e2406049388314 [[]] .width = true := by decide
def e2406049388358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e2406049388358 : Closed e2406049388358 ∧ code e2406049388358 = 11202142410566 := by decide
theorem cert_e2406049388358 : check e2406049388358 [[]] .width = true := by decide
def e2406049388386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))
theorem wire_e2406049388386 : Closed e2406049388386 ∧ code e2406049388386 = 11202142410594 := by decide
theorem cert_e2406049388386 : check e2406049388386 [[]] .width = true := by decide
def e2406049388570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406049388570 : Closed e2406049388570 ∧ code e2406049388570 = 11202142410778 := by decide
theorem cert_e2406049388570 : check e2406049388570 [[]] .width = true := by decide
def e2406049388662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406049388662 : Closed e2406049388662 ∧ code e2406049388662 = 11202142410870 := by decide
theorem cert_e2406049388662 : check e2406049388662 [[]] .width = true := by decide
end Blc.Floor43
