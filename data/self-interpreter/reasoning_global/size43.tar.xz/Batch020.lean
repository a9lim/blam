import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605187833066 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e605187833066 : Closed e605187833066 ∧ code e605187833066 = 9401280855274 := by decide
theorem cert_e605187833066 : check e605187833066 [[.under],[.under]] .three = true := by decide
def e605187833142 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e605187833142 : Closed e605187833142 ∧ code e605187833142 = 9401280855350 := by decide
theorem cert_e605187833142 : check e605187833142 [[.under],[.under]] .three = true := by decide
def e605187833146 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e605187833146 : Closed e605187833146 ∧ code e605187833146 = 9401280855354 := by decide
theorem cert_e605187833146 : check e605187833146 [[.under],[.under]] .three = true := by decide
def e605187833242 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e605187833242 : Closed e605187833242 ∧ code e605187833242 = 9401280855450 := by decide
theorem cert_e605187833242 : check e605187833242 [[.under],[.under]] .three = true := by decide
def e605187839710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605187839710 : Closed e605187839710 ∧ code e605187839710 = 9401280861918 := by decide
theorem cert_e605187839710 : check e605187839710 [[.under],[.under]] .three = true := by decide
def e605187839734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605187839734 : Closed e605187839734 ∧ code e605187839734 = 9401280861942 := by decide
theorem cert_e605187839734 : check e605187839734 [[.under],[.under]] .three = true := by decide
def e605187839838 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605187839838 : Closed e605187839838 ∧ code e605187839838 = 9401280862046 := by decide
theorem cert_e605187839838 : check e605187839838 [[.under],[.under]] .three = true := by decide
def e605187839854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e605187839854 : Closed e605187839854 ∧ code e605187839854 = 9401280862062 := by decide
theorem cert_e605187839854 : check e605187839854 [[.under],[.under]] .smaller = true := by decide
def e605187839862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e605187839862 : Closed e605187839862 ∧ code e605187839862 = 9401280862070 := by decide
theorem cert_e605187839862 : check e605187839862 [[.under],[.under]] .smaller = true := by decide
def e605187839866 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605187839866 : Closed e605187839866 ∧ code e605187839866 = 9401280862074 := by decide
theorem cert_e605187839866 : check e605187839866 [[.under],[.under]] .three = true := by decide
def e605187839926 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e605187839926 : Closed e605187839926 ∧ code e605187839926 = 9401280862134 := by decide
theorem cert_e605187839926 : check e605187839926 [[.under],[.under]] .smaller = true := by decide
def e605187839958 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605187839958 : Closed e605187839958 ∧ code e605187839958 = 9401280862166 := by decide
theorem cert_e605187839958 : check e605187839958 [[.under],[.under]] .three = true := by decide
def e605187839962 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605187839962 : Closed e605187839962 ∧ code e605187839962 = 9401280862170 := by decide
theorem cert_e605187839962 : check e605187839962 [[.under],[.under]] .three = true := by decide
def e605187840478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605187840478 : Closed e605187840478 ∧ code e605187840478 = 9401280862686 := by decide
theorem cert_e605187840478 : check e605187840478 [[.under],[.under]] .three = true := by decide
def e605187840502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605187840502 : Closed e605187840502 ∧ code e605187840502 = 9401280862710 := by decide
theorem cert_e605187840502 : check e605187840502 [[.under],[.under]] .three = true := by decide
def e605187841246 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605187841246 : Closed e605187841246 ∧ code e605187841246 = 9401280863454 := by decide
theorem cert_e605187841246 : check e605187841246 [[.under],[.under]] .three = true := by decide
def e605187841262 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e605187841262 : Closed e605187841262 ∧ code e605187841262 = 9401280863470 := by decide
theorem cert_e605187841262 : check e605187841262 [[.under],[.under]] .smaller = true := by decide
def e605187841270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e605187841270 : Closed e605187841270 ∧ code e605187841270 = 9401280863478 := by decide
theorem cert_e605187841270 : check e605187841270 [[.under],[.under]] .smaller = true := by decide
def e605187841274 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605187841274 : Closed e605187841274 ∧ code e605187841274 = 9401280863482 := by decide
theorem cert_e605187841274 : check e605187841274 [[.under],[.under]] .three = true := by decide
def e605187841654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e605187841654 : Closed e605187841654 ∧ code e605187841654 = 9401280863862 := by decide
theorem cert_e605187841654 : check e605187841654 [[.under],[.under]] .smaller = true := by decide
def e605187841846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605187841846 : Closed e605187841846 ∧ code e605187841846 = 9401280864054 := by decide
theorem cert_e605187841846 : check e605187841846 [[.under],[.under]] .three = true := by decide
def e605187841850 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605187841850 : Closed e605187841850 ∧ code e605187841850 = 9401280864058 := by decide
theorem cert_e605187841850 : check e605187841850 [[.under],[.under]] .three = true := by decide
def e605187853150 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e605187853150 : Closed e605187853150 ∧ code e605187853150 = 9401280875358 := by decide
theorem cert_e605187853150 : check e605187853150 [[.under],[.under]] .three = true := by decide
def e605187853166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605187853166 : Closed e605187853166 ∧ code e605187853166 = 9401280875374 := by decide
theorem cert_e605187853166 : check e605187853166 [[.under],[.under]] .smaller = true := by decide
def e605187853174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605187853174 : Closed e605187853174 ∧ code e605187853174 = 9401280875382 := by decide
theorem cert_e605187853174 : check e605187853174 [[.under],[.under]] .smaller = true := by decide
def e605187853178 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e605187853178 : Closed e605187853178 ∧ code e605187853178 = 9401280875386 := by decide
theorem cert_e605187853178 : check e605187853178 [[.under],[.under]] .three = true := by decide
def e605187853230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605187853230 : Closed e605187853230 ∧ code e605187853230 = 9401280875438 := by decide
theorem cert_e605187853230 : check e605187853230 [[.under],[.under]] .smaller = true := by decide
def e605187853242 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605187853242 : Closed e605187853242 ∧ code e605187853242 = 9401280875450 := by decide
theorem cert_e605187853242 : check e605187853242 [[.under],[.under]] .smaller = true := by decide
def e605187853270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605187853270 : Closed e605187853270 ∧ code e605187853270 = 9401280875478 := by decide
theorem cert_e605187853270 : check e605187853270 [[.under],[.under]] .smaller = true := by decide
def e605187853274 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605187853274 : Closed e605187853274 ∧ code e605187853274 = 9401280875482 := by decide
theorem cert_e605187853274 : check e605187853274 [[.under],[.under]] .smaller = true := by decide
def e605187853290 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e605187853290 : Closed e605187853290 ∧ code e605187853290 = 9401280875498 := by decide
theorem cert_e605187853290 : check e605187853290 [[.under],[.under]] .three = true := by decide
def e605187853534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e605187853534 : Closed e605187853534 ∧ code e605187853534 = 9401280875742 := by decide
theorem cert_e605187853534 : check e605187853534 [[.under],[.under]] .three = true := by decide
def e605187853550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605187853550 : Closed e605187853550 ∧ code e605187853550 = 9401280875758 := by decide
theorem cert_e605187853550 : check e605187853550 [[.under],[.under]] .smaller = true := by decide
def e605187853558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605187853558 : Closed e605187853558 ∧ code e605187853558 = 9401280875766 := by decide
theorem cert_e605187853558 : check e605187853558 [[.under],[.under]] .smaller = true := by decide
def e605187853562 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e605187853562 : Closed e605187853562 ∧ code e605187853562 = 9401280875770 := by decide
theorem cert_e605187853562 : check e605187853562 [[.under],[.under]] .three = true := by decide
def e605187853934 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605187853934 : Closed e605187853934 ∧ code e605187853934 = 9401280876142 := by decide
theorem cert_e605187853934 : check e605187853934 [[.under],[.under]] .smaller = true := by decide
def e605187853946 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605187853946 : Closed e605187853946 ∧ code e605187853946 = 9401280876154 := by decide
theorem cert_e605187853946 : check e605187853946 [[.under],[.under]] .smaller = true := by decide
def e605187854134 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605187854134 : Closed e605187854134 ∧ code e605187854134 = 9401280876342 := by decide
theorem cert_e605187854134 : check e605187854134 [[.under],[.under]] .smaller = true := by decide
def e605187854138 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605187854138 : Closed e605187854138 ∧ code e605187854138 = 9401280876346 := by decide
theorem cert_e605187854138 : check e605187854138 [[.under],[.under]] .smaller = true := by decide
def e605187854234 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e605187854234 : Closed e605187854234 ∧ code e605187854234 = 9401280876442 := by decide
theorem cert_e605187854234 : check e605187854234 [[.under],[.under]] .three = true := by decide
def e605187859894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e605187859894 : Closed e605187859894 ∧ code e605187859894 = 9401280882102 := by decide
theorem cert_e605187859894 : check e605187859894 [[.under],[.under]] .smaller = true := by decide
def e605187859926 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e605187859926 : Closed e605187859926 ∧ code e605187859926 = 9401280882134 := by decide
theorem cert_e605187859926 : check e605187859926 [[.under],[.under]] .smaller = true := by decide
def e605187859930 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e605187859930 : Closed e605187859930 ∧ code e605187859930 = 9401280882138 := by decide
theorem cert_e605187859930 : check e605187859930 [[.under],[.under]] .smaller = true := by decide
def e605187860086 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e605187860086 : Closed e605187860086 ∧ code e605187860086 = 9401280882294 := by decide
theorem cert_e605187860086 : check e605187860086 [[.under],[.under]] .smaller = true := by decide
def e605187860278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e605187860278 : Closed e605187860278 ∧ code e605187860278 = 9401280882486 := by decide
theorem cert_e605187860278 : check e605187860278 [[.under],[.under]] .smaller = true := by decide
def e605187860282 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e605187860282 : Closed e605187860282 ∧ code e605187860282 = 9401280882490 := by decide
theorem cert_e605187860282 : check e605187860282 [[.under],[.under]] .smaller = true := by decide
def e605187863254 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e605187863254 : Closed e605187863254 ∧ code e605187863254 = 9401280885462 := by decide
theorem cert_e605187863254 : check e605187863254 [[.under],[.under]] .three = true := by decide
def e605187863258 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e605187863258 : Closed e605187863258 ∧ code e605187863258 = 9401280885466 := by decide
theorem cert_e605187863258 : check e605187863258 [[.under],[.under]] .three = true := by decide
def e605187863274 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e605187863274 : Closed e605187863274 ∧ code e605187863274 = 9401280885482 := by decide
theorem cert_e605187863274 : check e605187863274 [[.under],[.under]] .three = true := by decide
def e605187863350 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e605187863350 : Closed e605187863350 ∧ code e605187863350 = 9401280885558 := by decide
theorem cert_e605187863350 : check e605187863350 [[.under],[.under]] .three = true := by decide
def e605187863354 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e605187863354 : Closed e605187863354 ∧ code e605187863354 = 9401280885562 := by decide
theorem cert_e605187863354 : check e605187863354 [[.under],[.under]] .three = true := by decide
def e605187863450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e605187863450 : Closed e605187863450 ∧ code e605187863450 = 9401280885658 := by decide
theorem cert_e605187863450 : check e605187863450 [[.under],[.under]] .three = true := by decide
def e605188088686 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605188088686 : Closed e605188088686 ∧ code e605188088686 = 9401281110894 := by decide
theorem cert_e605188088686 : check e605188088686 [[.under],[.under]] .three = true := by decide
def e605188088694 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605188088694 : Closed e605188088694 ∧ code e605188088694 = 9401281110902 := by decide
theorem cert_e605188088694 : check e605188088694 [[.under],[.under]] .three = true := by decide
def e605188088750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e605188088750 : Closed e605188088750 ∧ code e605188088750 = 9401281110958 := by decide
theorem cert_e605188088750 : check e605188088750 [[.under],[.under]] .three = true := by decide
def e605188088762 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e605188088762 : Closed e605188088762 ∧ code e605188088762 = 9401281110970 := by decide
theorem cert_e605188088762 : check e605188088762 [[.under],[.under]] .three = true := by decide
def e605188088790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605188088790 : Closed e605188088790 ∧ code e605188088790 = 9401281110998 := by decide
theorem cert_e605188088790 : check e605188088790 [[.under],[.under]] .three = true := by decide
def e605188088794 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605188088794 : Closed e605188088794 ∧ code e605188088794 = 9401281111002 := by decide
theorem cert_e605188088794 : check e605188088794 [[.under],[.under]] .three = true := by decide
def e605188090094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e605188090094 : Closed e605188090094 ∧ code e605188090094 = 9401281112302 := by decide
theorem cert_e605188090094 : check e605188090094 [[.under],[.under]] .three = true := by decide
def e605188090102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e605188090102 : Closed e605188090102 ∧ code e605188090102 = 9401281112310 := by decide
theorem cert_e605188090102 : check e605188090102 [[.under],[.under]] .three = true := by decide
def e605188090654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e605188090654 : Closed e605188090654 ∧ code e605188090654 = 9401281112862 := by decide
theorem cert_e605188090654 : check e605188090654 [[.under],[.under]] .three = true := by decide
def e605188090766 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e605188090766 : Closed e605188090766 ∧ code e605188090766 = 9401281112974 := by decide
theorem cert_e605188090766 : check e605188090766 [[.under],[.under]] .three = true := by decide
def e605188090990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605188090990 : Closed e605188090990 ∧ code e605188090990 = 9401281113198 := by decide
theorem cert_e605188090990 : check e605188090990 [[.under],[.under]] .three = true := by decide
def e605188091002 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605188091002 : Closed e605188091002 ∧ code e605188091002 = 9401281113210 := by decide
theorem cert_e605188091002 : check e605188091002 [[.under],[.under]] .three = true := by decide
def e605188091166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605188091166 : Closed e605188091166 ∧ code e605188091166 = 9401281113374 := by decide
theorem cert_e605188091166 : check e605188091166 [[.under],[.under]] .three = true := by decide
def e605188091334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605188091334 : Closed e605188091334 ∧ code e605188091334 = 9401281113542 := by decide
theorem cert_e605188091334 : check e605188091334 [[.under],[.under]] .three = true := by decide
def e605188091446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605188091446 : Closed e605188091446 ∧ code e605188091446 = 9401281113654 := by decide
theorem cert_e605188091446 : check e605188091446 [[.under],[.under]] .three = true := by decide
def e605188091450 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605188091450 : Closed e605188091450 ∧ code e605188091450 = 9401281113658 := by decide
theorem cert_e605188091450 : check e605188091450 [[.under],[.under]] .three = true := by decide
def e605188091534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605188091534 : Closed e605188091534 ∧ code e605188091534 = 9401281113742 := by decide
theorem cert_e605188091534 : check e605188091534 [[.under],[.under]] .three = true := by decide
def e605188091590 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605188091590 : Closed e605188091590 ∧ code e605188091590 = 9401281113798 := by decide
theorem cert_e605188091590 : check e605188091590 [[.under],[.under]] .three = true := by decide
def e605188092334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605188092334 : Closed e605188092334 ∧ code e605188092334 = 9401281114542 := by decide
theorem cert_e605188092334 : check e605188092334 [[.under],[.under]] .three = true := by decide
def e605188092346 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605188092346 : Closed e605188092346 ∧ code e605188092346 = 9401281114554 := by decide
theorem cert_e605188092346 : check e605188092346 [[.under],[.under]] .three = true := by decide
def e605188092394 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e605188092394 : Closed e605188092394 ∧ code e605188092394 = 9401281114602 := by decide
theorem cert_e605188092394 : check e605188092394 [[.under],[.under]] .three = true := by decide
def e605188093038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e605188093038 : Closed e605188093038 ∧ code e605188093038 = 9401281115246 := by decide
theorem cert_e605188093038 : check e605188093038 [[.under],[.under]] .three = true := by decide
def e605188093050 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e605188093050 : Closed e605188093050 ∧ code e605188093050 = 9401281115258 := by decide
theorem cert_e605188093050 : check e605188093050 [[.under],[.under]] .three = true := by decide
def e605188093214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e605188093214 : Closed e605188093214 ∧ code e605188093214 = 9401281115422 := by decide
theorem cert_e605188093214 : check e605188093214 [[.under],[.under]] .three = true := by decide
def e605188093382 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e605188093382 : Closed e605188093382 ∧ code e605188093382 = 9401281115590 := by decide
theorem cert_e605188093382 : check e605188093382 [[.under],[.under]] .three = true := by decide
def e605188093722 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605188093722 : Closed e605188093722 ∧ code e605188093722 = 9401281115930 := by decide
theorem cert_e605188093722 : check e605188093722 [[.under],[.under]] .three = true := by decide
def e605188093766 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605188093766 : Closed e605188093766 ∧ code e605188093766 = 9401281115974 := by decide
theorem cert_e605188093766 : check e605188093766 [[.under],[.under]] .three = true := by decide
def e605188094166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605188094166 : Closed e605188094166 ∧ code e605188094166 = 9401281116374 := by decide
theorem cert_e605188094166 : check e605188094166 [[.under],[.under]] .three = true := by decide
def e605188094170 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605188094170 : Closed e605188094170 ∧ code e605188094170 = 9401281116378 := by decide
theorem cert_e605188094170 : check e605188094170 [[.under],[.under]] .three = true := by decide
def e605188094186 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e605188094186 : Closed e605188094186 ∧ code e605188094186 = 9401281116394 := by decide
theorem cert_e605188094186 : check e605188094186 [[.under],[.under]] .three = true := by decide
def e605188094518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e605188094518 : Closed e605188094518 ∧ code e605188094518 = 9401281116726 := by decide
theorem cert_e605188094518 : check e605188094518 [[.under],[.under]] .three = true := by decide
def e605188094522 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e605188094522 : Closed e605188094522 ∧ code e605188094522 = 9401281116730 := by decide
theorem cert_e605188094522 : check e605188094522 [[.under],[.under]] .three = true := by decide
def e605188094606 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e605188094606 : Closed e605188094606 ∧ code e605188094606 = 9401281116814 := by decide
theorem cert_e605188094606 : check e605188094606 [[.under],[.under]] .three = true := by decide
def e605188094662 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e605188094662 : Closed e605188094662 ∧ code e605188094662 = 9401281116870 := by decide
theorem cert_e605188094662 : check e605188094662 [[.under],[.under]] .three = true := by decide
def e605188094746 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e605188094746 : Closed e605188094746 ∧ code e605188094746 = 9401281116954 := by decide
theorem cert_e605188094746 : check e605188094746 [[.under],[.under]] .three = true := by decide
def e605188094790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e605188094790 : Closed e605188094790 ∧ code e605188094790 = 9401281116998 := by decide
theorem cert_e605188094790 : check e605188094790 [[.under],[.under]] .three = true := by decide
def e605188099310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e605188099310 : Closed e605188099310 ∧ code e605188099310 = 9401281121518 := by decide
theorem cert_e605188099310 : check e605188099310 [[.under],[.under]] .three = true := by decide
def e605188099318 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e605188099318 : Closed e605188099318 ∧ code e605188099318 = 9401281121526 := by decide
theorem cert_e605188099318 : check e605188099318 [[.under],[.under]] .three = true := by decide
def e605188099694 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e605188099694 : Closed e605188099694 ∧ code e605188099694 = 9401281121902 := by decide
theorem cert_e605188099694 : check e605188099694 [[.under],[.under]] .three = true := by decide
def e605188099706 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e605188099706 : Closed e605188099706 ∧ code e605188099706 = 9401281121914 := by decide
theorem cert_e605188099706 : check e605188099706 [[.under],[.under]] .three = true := by decide
def e605188099894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e605188099894 : Closed e605188099894 ∧ code e605188099894 = 9401281122102 := by decide
theorem cert_e605188099894 : check e605188099894 [[.under],[.under]] .three = true := by decide
def e605188099898 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e605188099898 : Closed e605188099898 ∧ code e605188099898 = 9401281122106 := by decide
theorem cert_e605188099898 : check e605188099898 [[.under],[.under]] .three = true := by decide
def e605188102382 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e605188102382 : Closed e605188102382 ∧ code e605188102382 = 9401281124590 := by decide
theorem cert_e605188102382 : check e605188102382 [[.under],[.under]] .three = true := by decide
def e605188102390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e605188102390 : Closed e605188102390 ∧ code e605188102390 = 9401281124598 := by decide
theorem cert_e605188102390 : check e605188102390 [[.under],[.under]] .three = true := by decide
def e605188102942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e605188102942 : Closed e605188102942 ∧ code e605188102942 = 9401281125150 := by decide
theorem cert_e605188102942 : check e605188102942 [[.under],[.under]] .three = true := by decide
def e605188103054 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e605188103054 : Closed e605188103054 ∧ code e605188103054 = 9401281125262 := by decide
theorem cert_e605188103054 : check e605188103054 [[.under],[.under]] .three = true := by decide
def e605188103278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605188103278 : Closed e605188103278 ∧ code e605188103278 = 9401281125486 := by decide
theorem cert_e605188103278 : check e605188103278 [[.under],[.under]] .three = true := by decide
def e605188103290 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605188103290 : Closed e605188103290 ∧ code e605188103290 = 9401281125498 := by decide
theorem cert_e605188103290 : check e605188103290 [[.under],[.under]] .three = true := by decide
def e605188103454 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605188103454 : Closed e605188103454 ∧ code e605188103454 = 9401281125662 := by decide
theorem cert_e605188103454 : check e605188103454 [[.under],[.under]] .three = true := by decide
def e605188103622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605188103622 : Closed e605188103622 ∧ code e605188103622 = 9401281125830 := by decide
theorem cert_e605188103622 : check e605188103622 [[.under],[.under]] .three = true := by decide
def e605188103734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605188103734 : Closed e605188103734 ∧ code e605188103734 = 9401281125942 := by decide
theorem cert_e605188103734 : check e605188103734 [[.under],[.under]] .three = true := by decide
def e605188103738 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605188103738 : Closed e605188103738 ∧ code e605188103738 = 9401281125946 := by decide
theorem cert_e605188103738 : check e605188103738 [[.under],[.under]] .three = true := by decide
def e605188103822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605188103822 : Closed e605188103822 ∧ code e605188103822 = 9401281126030 := by decide
theorem cert_e605188103822 : check e605188103822 [[.under],[.under]] .three = true := by decide
def e605188103878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605188103878 : Closed e605188103878 ∧ code e605188103878 = 9401281126086 := by decide
theorem cert_e605188103878 : check e605188103878 [[.under],[.under]] .three = true := by decide
def e605188106014 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e605188106014 : Closed e605188106014 ∧ code e605188106014 = 9401281128222 := by decide
theorem cert_e605188106014 : check e605188106014 [[.under],[.under]] .three = true := by decide
def e605188106126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e605188106126 : Closed e605188106126 ∧ code e605188106126 = 9401281128334 := by decide
theorem cert_e605188106126 : check e605188106126 [[.under],[.under]] .three = true := by decide
def e605188109086 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605188109086 : Closed e605188109086 ∧ code e605188109086 = 9401281131294 := by decide
theorem cert_e605188109086 : check e605188109086 [[.under],[.under]] .three = true := by decide
def e605188109254 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605188109254 : Closed e605188109254 ∧ code e605188109254 = 9401281131462 := by decide
theorem cert_e605188109254 : check e605188109254 [[.under],[.under]] .three = true := by decide
def e605188110734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605188110734 : Closed e605188110734 ∧ code e605188110734 = 9401281132942 := by decide
theorem cert_e605188110734 : check e605188110734 [[.under],[.under]] .three = true := by decide
def e605188110790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605188110790 : Closed e605188110790 ∧ code e605188110790 = 9401281132998 := by decide
theorem cert_e605188110790 : check e605188110790 [[.under],[.under]] .three = true := by decide
def e605188114030 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e605188114030 : Closed e605188114030 ∧ code e605188114030 = 9401281136238 := by decide
theorem cert_e605188114030 : check e605188114030 [[.under],[.under]] .three = true := by decide
def e605188114042 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e605188114042 : Closed e605188114042 ∧ code e605188114042 = 9401281136250 := by decide
theorem cert_e605188114042 : check e605188114042 [[.under],[.under]] .three = true := by decide
def e605188114330 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e605188114330 : Closed e605188114330 ∧ code e605188114330 = 9401281136538 := by decide
theorem cert_e605188114330 : check e605188114330 [[.under],[.under]] .three = true := by decide
def e605188115566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e605188115566 : Closed e605188115566 ∧ code e605188115566 = 9401281137774 := by decide
theorem cert_e605188115566 : check e605188115566 [[.under],[.under]] .three = true := by decide
def e605188115578 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e605188115578 : Closed e605188115578 ∧ code e605188115578 = 9401281137786 := by decide
theorem cert_e605188115578 : check e605188115578 [[.under],[.under]] .three = true := by decide
def e605188115742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e605188115742 : Closed e605188115742 ∧ code e605188115742 = 9401281137950 := by decide
theorem cert_e605188115742 : check e605188115742 [[.under],[.under]] .three = true := by decide
def e605188115910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e605188115910 : Closed e605188115910 ∧ code e605188115910 = 9401281138118 := by decide
theorem cert_e605188115910 : check e605188115910 [[.under],[.under]] .three = true := by decide
def e605188116250 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e605188116250 : Closed e605188116250 ∧ code e605188116250 = 9401281138458 := by decide
theorem cert_e605188116250 : check e605188116250 [[.under],[.under]] .three = true := by decide
def e605188116294 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e605188116294 : Closed e605188116294 ∧ code e605188116294 = 9401281138502 := by decide
theorem cert_e605188116294 : check e605188116294 [[.under],[.under]] .three = true := by decide
def e605188117278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e605188117278 : Closed e605188117278 ∧ code e605188117278 = 9401281139486 := by decide
theorem cert_e605188117278 : check e605188117278 [[.under],[.under]] .three = true := by decide
def e605188117446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e605188117446 : Closed e605188117446 ∧ code e605188117446 = 9401281139654 := by decide
theorem cert_e605188117446 : check e605188117446 [[.under],[.under]] .three = true := by decide
def e605188119750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605188119750 : Closed e605188119750 ∧ code e605188119750 = 9401281141958 := by decide
theorem cert_e605188119750 : check e605188119750 [[.under],[.under]] .three = true := by decide
def e605188121398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e605188121398 : Closed e605188121398 ∧ code e605188121398 = 9401281143606 := by decide
theorem cert_e605188121398 : check e605188121398 [[.under],[.under]] .three = true := by decide
def e605188121402 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e605188121402 : Closed e605188121402 ∧ code e605188121402 = 9401281143610 := by decide
theorem cert_e605188121402 : check e605188121402 [[.under],[.under]] .three = true := by decide
def e605188121498 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e605188121498 : Closed e605188121498 ∧ code e605188121498 = 9401281143706 := by decide
theorem cert_e605188121498 : check e605188121498 [[.under],[.under]] .three = true := by decide
def e605188122166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e605188122166 : Closed e605188122166 ∧ code e605188122166 = 9401281144374 := by decide
theorem cert_e605188122166 : check e605188122166 [[.under],[.under]] .three = true := by decide
def e605188122170 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e605188122170 : Closed e605188122170 ∧ code e605188122170 = 9401281144378 := by decide
theorem cert_e605188122170 : check e605188122170 [[.under],[.under]] .three = true := by decide
def e605188122254 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e605188122254 : Closed e605188122254 ∧ code e605188122254 = 9401281144462 := by decide
theorem cert_e605188122254 : check e605188122254 [[.under],[.under]] .three = true := by decide
def e605188122310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e605188122310 : Closed e605188122310 ∧ code e605188122310 = 9401281144518 := by decide
theorem cert_e605188122310 : check e605188122310 [[.under],[.under]] .three = true := by decide
def e605188122394 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e605188122394 : Closed e605188122394 ∧ code e605188122394 = 9401281144602 := by decide
theorem cert_e605188122394 : check e605188122394 [[.under],[.under]] .three = true := by decide
def e605188122438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e605188122438 : Closed e605188122438 ∧ code e605188122438 = 9401281144646 := by decide
theorem cert_e605188122438 : check e605188122438 [[.under],[.under]] .three = true := by decide
def e605188123022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e605188123022 : Closed e605188123022 ∧ code e605188123022 = 9401281145230 := by decide
theorem cert_e605188123022 : check e605188123022 [[.under],[.under]] .three = true := by decide
def e605188123078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e605188123078 : Closed e605188123078 ∧ code e605188123078 = 9401281145286 := by decide
theorem cert_e605188123078 : check e605188123078 [[.under],[.under]] .three = true := by decide
def e605188123846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e605188123846 : Closed e605188123846 ∧ code e605188123846 = 9401281146054 := by decide
theorem cert_e605188123846 : check e605188123846 [[.under],[.under]] .three = true := by decide
def e605188134622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605188134622 : Closed e605188134622 ∧ code e605188134622 = 9401281156830 := by decide
theorem cert_e605188134622 : check e605188134622 [[.under],[.under]] .three = true := by decide
def e605188134646 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605188134646 : Closed e605188134646 ∧ code e605188134646 = 9401281156854 := by decide
theorem cert_e605188134646 : check e605188134646 [[.under],[.under]] .three = true := by decide
def e605188134750 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605188134750 : Closed e605188134750 ∧ code e605188134750 = 9401281156958 := by decide
theorem cert_e605188134750 : check e605188134750 [[.under],[.under]] .three = true := by decide
def e605188134778 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605188134778 : Closed e605188134778 ∧ code e605188134778 = 9401281156986 := by decide
theorem cert_e605188134778 : check e605188134778 [[.under],[.under]] .three = true := by decide
def e605188134870 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605188134870 : Closed e605188134870 ∧ code e605188134870 = 9401281157078 := by decide
theorem cert_e605188134870 : check e605188134870 [[.under],[.under]] .three = true := by decide
def e605188134874 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605188134874 : Closed e605188134874 ∧ code e605188134874 = 9401281157082 := by decide
theorem cert_e605188134874 : check e605188134874 [[.under],[.under]] .three = true := by decide
def e605188135390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605188135390 : Closed e605188135390 ∧ code e605188135390 = 9401281157598 := by decide
theorem cert_e605188135390 : check e605188135390 [[.under],[.under]] .three = true := by decide
def e605188135414 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605188135414 : Closed e605188135414 ∧ code e605188135414 = 9401281157622 := by decide
theorem cert_e605188135414 : check e605188135414 [[.under],[.under]] .three = true := by decide
def e605188136158 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605188136158 : Closed e605188136158 ∧ code e605188136158 = 9401281158366 := by decide
theorem cert_e605188136158 : check e605188136158 [[.under],[.under]] .three = true := by decide
def e605188136186 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605188136186 : Closed e605188136186 ∧ code e605188136186 = 9401281158394 := by decide
theorem cert_e605188136186 : check e605188136186 [[.under],[.under]] .three = true := by decide
def e605188136758 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605188136758 : Closed e605188136758 ∧ code e605188136758 = 9401281158966 := by decide
theorem cert_e605188136758 : check e605188136758 [[.under],[.under]] .three = true := by decide
def e605188136762 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605188136762 : Closed e605188136762 ∧ code e605188136762 = 9401281158970 := by decide
theorem cert_e605188136762 : check e605188136762 [[.under],[.under]] .three = true := by decide
def e605188151534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605188151534 : Closed e605188151534 ∧ code e605188151534 = 9401281173742 := by decide
theorem cert_e605188151534 : check e605188151534 [[.under],[.under]] .three = true := by decide
def e605188151542 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605188151542 : Closed e605188151542 ∧ code e605188151542 = 9401281173750 := by decide
theorem cert_e605188151542 : check e605188151542 [[.under],[.under]] .three = true := by decide
def e605188152094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605188152094 : Closed e605188152094 ∧ code e605188152094 = 9401281174302 := by decide
theorem cert_e605188152094 : check e605188152094 [[.under],[.under]] .three = true := by decide
def e605188152206 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605188152206 : Closed e605188152206 ∧ code e605188152206 = 9401281174414 := by decide
theorem cert_e605188152206 : check e605188152206 [[.under],[.under]] .three = true := by decide
def e605188152430 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605188152430 : Closed e605188152430 ∧ code e605188152430 = 9401281174638 := by decide
theorem cert_e605188152430 : check e605188152430 [[.under],[.under]] .three = true := by decide
def e605188152442 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605188152442 : Closed e605188152442 ∧ code e605188152442 = 9401281174650 := by decide
theorem cert_e605188152442 : check e605188152442 [[.under],[.under]] .three = true := by decide
def e605188152606 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605188152606 : Closed e605188152606 ∧ code e605188152606 = 9401281174814 := by decide
theorem cert_e605188152606 : check e605188152606 [[.under],[.under]] .three = true := by decide
def e605188152774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605188152774 : Closed e605188152774 ∧ code e605188152774 = 9401281174982 := by decide
theorem cert_e605188152774 : check e605188152774 [[.under],[.under]] .three = true := by decide
def e605188152886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605188152886 : Closed e605188152886 ∧ code e605188152886 = 9401281175094 := by decide
theorem cert_e605188152886 : check e605188152886 [[.under],[.under]] .three = true := by decide
def e605188152890 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605188152890 : Closed e605188152890 ∧ code e605188152890 = 9401281175098 := by decide
theorem cert_e605188152890 : check e605188152890 [[.under],[.under]] .three = true := by decide
def e605188152974 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605188152974 : Closed e605188152974 ∧ code e605188152974 = 9401281175182 := by decide
theorem cert_e605188152974 : check e605188152974 [[.under],[.under]] .three = true := by decide
def e605188153030 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605188153030 : Closed e605188153030 ∧ code e605188153030 = 9401281175238 := by decide
theorem cert_e605188153030 : check e605188153030 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
