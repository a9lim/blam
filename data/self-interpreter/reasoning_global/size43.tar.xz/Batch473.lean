import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407114158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422407114158 : Closed e2422407114158 ∧ code e2422407114158 = 11218500136366 := by decide
theorem cert_e2422407114158 : check e2422407114158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407114166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2422407114166 : Closed e2422407114166 ∧ code e2422407114166 = 11218500136374 := by decide
theorem cert_e2422407114166 : check e2422407114166 [[],[]] .chain = true := by decide
def e2422407114170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422407114170 : Closed e2422407114170 ∧ code e2422407114170 = 11218500136378 := by decide
theorem cert_e2422407114170 : check e2422407114170 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407114198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422407114198 : Closed e2422407114198 ∧ code e2422407114198 = 11218500136406 := by decide
def e2422407114202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422407114202 : Closed e2422407114202 ∧ code e2422407114202 = 11218500136410 := by decide
theorem cert_e2422407114202 : check e2422407114202 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407114282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2422407114282 : Closed e2422407114282 ∧ code e2422407114282 = 11218500136490 := by decide
theorem cert_e2422407114282 : check e2422407114282 [[],[]] .chain = true := by decide
def e2422407114378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407114378 : Closed e2422407114378 ∧ code e2422407114378 = 11218500136586 := by decide
theorem cert_e2422407114378 : check e2422407114378 [[],[]] .chain = true := by decide
def e2422407114402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407114402 : Closed e2422407114402 ∧ code e2422407114402 = 11218500136610 := by decide
theorem cert_e2422407114402 : check e2422407114402 [[],[]] .chain = true := by decide
def e2422407114414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407114414 : Closed e2422407114414 ∧ code e2422407114414 = 11218500136622 := by decide
theorem cert_e2422407114414 : check e2422407114414 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407114422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2422407114422 : Closed e2422407114422 ∧ code e2422407114422 = 11218500136630 := by decide
theorem cert_e2422407114422 : check e2422407114422 [[],[]] .chain = true := by decide
def e2422407114426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407114426 : Closed e2422407114426 ∧ code e2422407114426 = 11218500136634 := by decide
theorem cert_e2422407114426 : check e2422407114426 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407114454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2422407114454 : Closed e2422407114454 ∧ code e2422407114454 = 11218500136662 := by decide
theorem cert_e2422407114454 : check e2422407114454 [[],[]] .chain = true := by decide
def e2422407114458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2422407114458 : Closed e2422407114458 ∧ code e2422407114458 = 11218500136666 := by decide
theorem cert_e2422407114458 : check e2422407114458 [[],[]] .chain = true := by decide
def e2422407114474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407114474 : Closed e2422407114474 ∧ code e2422407114474 = 11218500136682 := by decide
theorem cert_e2422407114474 : check e2422407114474 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407114582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422407114582 : Closed e2422407114582 ∧ code e2422407114582 = 11218500136790 := by decide
def e2422407114586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422407114586 : Closed e2422407114586 ∧ code e2422407114586 = 11218500136794 := by decide
theorem cert_e2422407114586 : check e2422407114586 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407114602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422407114602 : Closed e2422407114602 ∧ code e2422407114602 = 11218500136810 := by decide
theorem cert_e2422407114602 : check e2422407114602 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407114774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422407114774 : Closed e2422407114774 ∧ code e2422407114774 = 11218500136982 := by decide
theorem cert_e2422407114774 : check e2422407114774 [[],[]] .chain = true := by decide
def e2422407114870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2422407114870 : Closed e2422407114870 ∧ code e2422407114870 = 11218500137078 := by decide
theorem cert_e2422407114870 : check e2422407114870 [[],[]] .chain = true := by decide
def e2422407114874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2422407114874 : Closed e2422407114874 ∧ code e2422407114874 = 11218500137082 := by decide
theorem cert_e2422407114874 : check e2422407114874 [[],[]] .chain = true := by decide
def e2422407114966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2422407114966 : Closed e2422407114966 ∧ code e2422407114966 = 11218500137174 := by decide
theorem cert_e2422407114966 : check e2422407114966 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407115062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407115062 : Closed e2422407115062 ∧ code e2422407115062 = 11218500137270 := by decide
theorem cert_e2422407115062 : check e2422407115062 [[],[]] .chain = true := by decide
def e2422407115066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407115066 : Closed e2422407115066 ∧ code e2422407115066 = 11218500137274 := by decide
theorem cert_e2422407115066 : check e2422407115066 [[],[]] .chain = true := by decide
def e2422407115150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2422407115150 : Closed e2422407115150 ∧ code e2422407115150 = 11218500137358 := by decide
theorem cert_e2422407115150 : check e2422407115150 [[],[]] .chain = true := by decide
def e2422407115206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2422407115206 : Closed e2422407115206 ∧ code e2422407115206 = 11218500137414 := by decide
theorem cert_e2422407115206 : check e2422407115206 [[],[]] .chain = true := by decide
def e2422407115542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407115542 : Closed e2422407115542 ∧ code e2422407115542 = 11218500137750 := by decide
theorem cert_e2422407115542 : check e2422407115542 [[],[]] .chain = true := by decide
def e2422407115618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407115618 : Closed e2422407115618 ∧ code e2422407115618 = 11218500137826 := by decide
theorem cert_e2422407115618 : check e2422407115618 [[],[]] .chain = true := by decide
def e2422407115630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422407115630 : Closed e2422407115630 ∧ code e2422407115630 = 11218500137838 := by decide
theorem cert_e2422407115630 : check e2422407115630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407115638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422407115638 : Closed e2422407115638 ∧ code e2422407115638 = 11218500137846 := by decide
theorem cert_e2422407115638 : check e2422407115638 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407115658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407115658 : Closed e2422407115658 ∧ code e2422407115658 = 11218500137866 := by decide
theorem cert_e2422407115658 : check e2422407115658 [[],[]] .chain = true := by decide
def e2422407115682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407115682 : Closed e2422407115682 ∧ code e2422407115682 = 11218500137890 := by decide
theorem cert_e2422407115682 : check e2422407115682 [[],[]] .chain = true := by decide
def e2422407115694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422407115694 : Closed e2422407115694 ∧ code e2422407115694 = 11218500137902 := by decide
theorem cert_e2422407115694 : check e2422407115694 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407115702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2422407115702 : Closed e2422407115702 ∧ code e2422407115702 = 11218500137910 := by decide
theorem cert_e2422407115702 : check e2422407115702 [[],[]] .chain = true := by decide
def e2422407115706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422407115706 : Closed e2422407115706 ∧ code e2422407115706 = 11218500137914 := by decide
theorem cert_e2422407115706 : check e2422407115706 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407115734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422407115734 : Closed e2422407115734 ∧ code e2422407115734 = 11218500137942 := by decide
def e2422407115738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422407115738 : Closed e2422407115738 ∧ code e2422407115738 = 11218500137946 := by decide
theorem cert_e2422407115738 : check e2422407115738 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407115806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2422407115806 : Closed e2422407115806 ∧ code e2422407115806 = 11218500138014 := by decide
theorem cert_e2422407115806 : check e2422407115806 [[],[]] .chain = true := by decide
def e2422407116002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407116002 : Closed e2422407116002 ∧ code e2422407116002 = 11218500138210 := by decide
theorem cert_e2422407116002 : check e2422407116002 [[],[]] .chain = true := by decide
def e2422407116014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407116014 : Closed e2422407116014 ∧ code e2422407116014 = 11218500138222 := by decide
theorem cert_e2422407116014 : check e2422407116014 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407116022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407116022 : Closed e2422407116022 ∧ code e2422407116022 = 11218500138230 := by decide
theorem cert_e2422407116022 : check e2422407116022 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407116290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407116290 : Closed e2422407116290 ∧ code e2422407116290 = 11218500138498 := by decide
theorem cert_e2422407116290 : check e2422407116290 [[],[]] .chain = true := by decide
def e2422407116302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407116302 : Closed e2422407116302 ∧ code e2422407116302 = 11218500138510 := by decide
theorem cert_e2422407116302 : check e2422407116302 [[],[]] .chain = true := by decide
def e2422407116314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407116314 : Closed e2422407116314 ∧ code e2422407116314 = 11218500138522 := by decide
theorem cert_e2422407116314 : check e2422407116314 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407116386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407116386 : Closed e2422407116386 ∧ code e2422407116386 = 11218500138594 := by decide
theorem cert_e2422407116386 : check e2422407116386 [[],[]] .chain = true := by decide
def e2422407116398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407116398 : Closed e2422407116398 ∧ code e2422407116398 = 11218500138606 := by decide
theorem cert_e2422407116398 : check e2422407116398 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407116406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407116406 : Closed e2422407116406 ∧ code e2422407116406 = 11218500138614 := by decide
theorem cert_e2422407116406 : check e2422407116406 [[],[]] .chain = true := by decide
def e2422407116410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407116410 : Closed e2422407116410 ∧ code e2422407116410 = 11218500138618 := by decide
theorem cert_e2422407116410 : check e2422407116410 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407116598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407116598 : Closed e2422407116598 ∧ code e2422407116598 = 11218500138806 := by decide
theorem cert_e2422407116598 : check e2422407116598 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407116602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407116602 : Closed e2422407116602 ∧ code e2422407116602 = 11218500138810 := by decide
theorem cert_e2422407116602 : check e2422407116602 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2422407116810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422407116810 : Closed e2422407116810 ∧ code e2422407116810 = 11218500139018 := by decide
theorem cert_e2422407116810 : check e2422407116810 [[],[]] .chain = true := by decide
def e2422407116846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407116846 : Closed e2422407116846 ∧ code e2422407116846 = 11218500139054 := by decide
theorem cert_e2422407116846 : check e2422407116846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407116854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1))))) (.var 1))))))
theorem wire_e2422407116854 : Closed e2422407116854 ∧ code e2422407116854 = 11218500139062 := by decide
theorem cert_e2422407116854 : check e2422407116854 [[],[]] .chain = true := by decide
def e2422407116858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2422407116858 : Closed e2422407116858 ∧ code e2422407116858 = 11218500139066 := by decide
theorem cert_e2422407116858 : check e2422407116858 [[],[]] .chain = true := by decide
def e2422407116906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2422407116906 : Closed e2422407116906 ∧ code e2422407116906 = 11218500139114 := by decide
theorem cert_e2422407116906 : check e2422407116906 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407116942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2422407116942 : Closed e2422407116942 ∧ code e2422407116942 = 11218500139150 := by decide
theorem cert_e2422407116942 : check e2422407116942 [[],[]] .chain = true := by decide
def e2422407116954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407116954 : Closed e2422407116954 ∧ code e2422407116954 = 11218500139162 := by decide
theorem cert_e2422407116954 : check e2422407116954 [[],[]] .chain = true := by decide
def e2422407116998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2422407116998 : Closed e2422407116998 ∧ code e2422407116998 = 11218500139206 := by decide
theorem cert_e2422407116998 : check e2422407116998 [[],[]] .chain = true := by decide
def e2422407117026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422407117026 : Closed e2422407117026 ∧ code e2422407117026 = 11218500139234 := by decide
theorem cert_e2422407117026 : check e2422407117026 [[],[]] .chain = true := by decide
def e2422407117038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407117038 : Closed e2422407117038 ∧ code e2422407117038 = 11218500139246 := by decide
theorem cert_e2422407117038 : check e2422407117038 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407117046 : Closed e2422407117046 ∧ code e2422407117046 = 11218500139254 := by decide
theorem cert_e2422407117046 : check e2422407117046 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407117194 : Closed e2422407117194 ∧ code e2422407117194 = 11218500139402 := by decide
theorem cert_e2422407117194 : check e2422407117194 [[],[]] .chain = true := by decide
def e2422407117218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422407117218 : Closed e2422407117218 ∧ code e2422407117218 = 11218500139426 := by decide
theorem cert_e2422407117218 : check e2422407117218 [[],[]] .chain = true := by decide
def e2422407117230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407117230 : Closed e2422407117230 ∧ code e2422407117230 = 11218500139438 := by decide
theorem cert_e2422407117230 : check e2422407117230 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422407117238 : Closed e2422407117238 ∧ code e2422407117238 = 11218500139446 := by decide
theorem cert_e2422407117238 : check e2422407117238 [[],[]] .chain = true := by decide
def e2422407117242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407117242 : Closed e2422407117242 ∧ code e2422407117242 = 11218500139450 := by decide
theorem cert_e2422407117242 : check e2422407117242 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422407117270 : Closed e2422407117270 ∧ code e2422407117270 = 11218500139478 := by decide
theorem cert_e2422407117270 : check e2422407117270 [[],[]] .chain = true := by decide
def e2422407117274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2422407117274 : Closed e2422407117274 ∧ code e2422407117274 = 11218500139482 := by decide
theorem cert_e2422407117274 : check e2422407117274 [[],[]] .chain = true := by decide
def e2422407117290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407117290 : Closed e2422407117290 ∧ code e2422407117290 = 11218500139498 := by decide
theorem cert_e2422407117290 : check e2422407117290 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422407117314 : Closed e2422407117314 ∧ code e2422407117314 = 11218500139522 := by decide
theorem cert_e2422407117314 : check e2422407117314 [[],[]] .chain = true := by decide
def e2422407117326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407117326 : Closed e2422407117326 ∧ code e2422407117326 = 11218500139534 := by decide
theorem cert_e2422407117326 : check e2422407117326 [[],[]] .chain = true := by decide
def e2422407117338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422407117338 : Closed e2422407117338 ∧ code e2422407117338 = 11218500139546 := by decide
theorem cert_e2422407117338 : check e2422407117338 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407117410 : Closed e2422407117410 ∧ code e2422407117410 = 11218500139618 := by decide
theorem cert_e2422407117410 : check e2422407117410 [[],[]] .chain = true := by decide
def e2422407117422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407117422 : Closed e2422407117422 ∧ code e2422407117422 = 11218500139630 := by decide
theorem cert_e2422407117422 : check e2422407117422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407117430 : Closed e2422407117430 ∧ code e2422407117430 = 11218500139638 := by decide
theorem cert_e2422407117430 : check e2422407117430 [[],[]] .chain = true := by decide
def e2422407117434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407117434 : Closed e2422407117434 ∧ code e2422407117434 = 11218500139642 := by decide
theorem cert_e2422407117434 : check e2422407117434 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407117574 : Closed e2422407117574 ∧ code e2422407117574 = 11218500139782 := by decide
theorem cert_e2422407117574 : check e2422407117574 [[],[]] .chain = true := by decide
def e2422407117598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407117598 : Closed e2422407117598 ∧ code e2422407117598 = 11218500139806 := by decide
theorem cert_e2422407117598 : check e2422407117598 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407117622 : Closed e2422407117622 ∧ code e2422407117622 = 11218500139830 := by decide
theorem cert_e2422407117622 : check e2422407117622 [[],[]] .chain = true := by decide
def e2422407117626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407117626 : Closed e2422407117626 ∧ code e2422407117626 = 11218500139834 := by decide
theorem cert_e2422407117626 : check e2422407117626 [[],[]] .chain = true := by decide
def e2422407117698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407117698 : Closed e2422407117698 ∧ code e2422407117698 = 11218500139906 := by decide
theorem cert_e2422407117698 : check e2422407117698 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407117710 : Closed e2422407117710 ∧ code e2422407117710 = 11218500139918 := by decide
theorem cert_e2422407117710 : check e2422407117710 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407117722 : Closed e2422407117722 ∧ code e2422407117722 = 11218500139930 := by decide
theorem cert_e2422407117722 : check e2422407117722 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407117846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422407117846 : Closed e2422407117846 ∧ code e2422407117846 = 11218500140054 := by decide
theorem cert_e2422407117846 : check e2422407117846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407117942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422407117942 : Closed e2422407117942 ∧ code e2422407117942 = 11218500140150 := by decide
theorem cert_e2422407117942 : check e2422407117942 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407118038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407118038 : Closed e2422407118038 ∧ code e2422407118038 = 11218500140246 := by decide
def e2422407118042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407118042 : Closed e2422407118042 ∧ code e2422407118042 = 11218500140250 := by decide
def e2422407118058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407118058 : Closed e2422407118058 ∧ code e2422407118058 = 11218500140266 := by decide
def e2422407118134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407118134 : Closed e2422407118134 ∧ code e2422407118134 = 11218500140342 := by decide
def e2422407118138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407118138 : Closed e2422407118138 ∧ code e2422407118138 = 11218500140346 := by decide
def e2422407118210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0))))))))
theorem wire_e2422407118210 : Closed e2422407118210 ∧ code e2422407118210 = 11218500140418 := by decide
theorem cert_e2422407118210 : check e2422407118210 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407118222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422407118222 : Closed e2422407118222 ∧ code e2422407118222 = 11218500140430 := by decide
theorem cert_e2422407118222 : check e2422407118222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407118234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407118234 : Closed e2422407118234 ∧ code e2422407118234 = 11218500140442 := by decide
theorem cert_e2422407118234 : check e2422407118234 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422407119070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422407119070 : Closed e2422407119070 ∧ code e2422407119070 = 11218500141278 := by decide
theorem cert_e2422407119070 : check e2422407119070 [[],[]] .chain = true := by decide
def e2422407119098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422407119098 : Closed e2422407119098 ∧ code e2422407119098 = 11218500141306 := by decide
theorem cert_e2422407119098 : check e2422407119098 [[],[]] .chain = true := by decide
def e2422407119646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422407119646 : Closed e2422407119646 ∧ code e2422407119646 = 11218500141854 := by decide
theorem cert_e2422407119646 : check e2422407119646 [[],[]] .chain = true := by decide
def e2422407119814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422407119814 : Closed e2422407119814 ∧ code e2422407119814 = 11218500142022 := by decide
theorem cert_e2422407119814 : check e2422407119814 [[],[]] .chain = true := by decide
def e2422407119838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407119838 : Closed e2422407119838 ∧ code e2422407119838 = 11218500142046 := by decide
theorem cert_e2422407119838 : checkPay e2422407119838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e2422407119854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407119854 : Closed e2422407119854 ∧ code e2422407119854 = 11218500142062 := by decide
theorem cert_e2422407119854 : check e2422407119854 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2422407121686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422407121686 : Closed e2422407121686 ∧ code e2422407121686 = 11218500143894 := by decide
theorem cert_e2422407121686 : check e2422407121686 [[],[]] .chain = true := by decide
def e2422407121762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422407121762 : Closed e2422407121762 ∧ code e2422407121762 = 11218500143970 := by decide
theorem cert_e2422407121762 : check e2422407121762 [[],[]] .chain = true := by decide
def e2422407121774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407121774 : Closed e2422407121774 ∧ code e2422407121774 = 11218500143982 := by decide
theorem cert_e2422407121774 : check e2422407121774 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407121782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407121782 : Closed e2422407121782 ∧ code e2422407121782 = 11218500143990 := by decide
theorem cert_e2422407121782 : check e2422407121782 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422407121802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407121802 : Closed e2422407121802 ∧ code e2422407121802 = 11218500144010 := by decide
theorem cert_e2422407121802 : check e2422407121802 [[],[]] .chain = true := by decide
def e2422407121826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407121826 : Closed e2422407121826 ∧ code e2422407121826 = 11218500144034 := by decide
theorem cert_e2422407121826 : check e2422407121826 [[],[]] .chain = true := by decide
def e2422407121838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407121838 : Closed e2422407121838 ∧ code e2422407121838 = 11218500144046 := by decide
theorem cert_e2422407121838 : check e2422407121838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407121846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2422407121846 : Closed e2422407121846 ∧ code e2422407121846 = 11218500144054 := by decide
theorem cert_e2422407121846 : check e2422407121846 [[],[]] .chain = true := by decide
def e2422407121850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407121850 : Closed e2422407121850 ∧ code e2422407121850 = 11218500144058 := by decide
theorem cert_e2422407121850 : check e2422407121850 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407121878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407121878 : Closed e2422407121878 ∧ code e2422407121878 = 11218500144086 := by decide
theorem cert_e2422407121878 : checkPay e2422407121878 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422407121882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407121882 : Closed e2422407121882 ∧ code e2422407121882 = 11218500144090 := by decide
theorem cert_e2422407121882 : checkPay e2422407121882 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422407121950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2422407121950 : Closed e2422407121950 ∧ code e2422407121950 = 11218500144158 := by decide
theorem cert_e2422407121950 : check e2422407121950 [[],[]] .chain = true := by decide
def e2422407122146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422407122146 : Closed e2422407122146 ∧ code e2422407122146 = 11218500144354 := by decide
theorem cert_e2422407122146 : check e2422407122146 [[],[]] .chain = true := by decide
def e2422407122158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407122158 : Closed e2422407122158 ∧ code e2422407122158 = 11218500144366 := by decide
theorem cert_e2422407122158 : check e2422407122158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407122166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407122166 : Closed e2422407122166 ∧ code e2422407122166 = 11218500144374 := by decide
theorem cert_e2422407122166 : check e2422407122166 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407122434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407122434 : Closed e2422407122434 ∧ code e2422407122434 = 11218500144642 := by decide
theorem cert_e2422407122434 : check e2422407122434 [[],[]] .chain = true := by decide
def e2422407122446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407122446 : Closed e2422407122446 ∧ code e2422407122446 = 11218500144654 := by decide
theorem cert_e2422407122446 : check e2422407122446 [[],[]] .chain = true := by decide
def e2422407122458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407122458 : Closed e2422407122458 ∧ code e2422407122458 = 11218500144666 := by decide
theorem cert_e2422407122458 : check e2422407122458 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407122530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407122530 : Closed e2422407122530 ∧ code e2422407122530 = 11218500144738 := by decide
theorem cert_e2422407122530 : check e2422407122530 [[],[]] .chain = true := by decide
def e2422407122542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407122542 : Closed e2422407122542 ∧ code e2422407122542 = 11218500144750 := by decide
theorem cert_e2422407122542 : check e2422407122542 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407122550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407122550 : Closed e2422407122550 ∧ code e2422407122550 = 11218500144758 := by decide
theorem cert_e2422407122550 : check e2422407122550 [[],[]] .chain = true := by decide
def e2422407122554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407122554 : Closed e2422407122554 ∧ code e2422407122554 = 11218500144762 := by decide
theorem cert_e2422407122554 : check e2422407122554 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407122742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407122742 : Closed e2422407122742 ∧ code e2422407122742 = 11218500144950 := by decide
theorem cert_e2422407122742 : check e2422407122742 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407122746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407122746 : Closed e2422407122746 ∧ code e2422407122746 = 11218500144954 := by decide
theorem cert_e2422407122746 : check e2422407122746 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422407127066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422407127066 : Closed e2422407127066 ∧ code e2422407127066 = 11218500149274 := by decide
theorem cert_e2422407127066 : check e2422407127066 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407127102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422407127102 : Closed e2422407127102 ∧ code e2422407127102 = 11218500149310 := by decide
theorem cert_e2422407127102 : check e2422407127102 [[],[]] .chain = true := by decide
def e2422407127150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422407127150 : Closed e2422407127150 ∧ code e2422407127150 = 11218500149358 := by decide
theorem cert_e2422407127150 : check e2422407127150 [[],[]] .chain = true := by decide
def e2422407127158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422407127158 : Closed e2422407127158 ∧ code e2422407127158 = 11218500149366 := by decide
theorem cert_e2422407127158 : check e2422407127158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407127162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422407127162 : Closed e2422407127162 ∧ code e2422407127162 = 11218500149370 := by decide
theorem cert_e2422407127162 : check e2422407127162 [[],[]] .chain = true := by decide
def e2422407127402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422407127402 : Closed e2422407127402 ∧ code e2422407127402 = 11218500149610 := by decide
theorem cert_e2422407127402 : check e2422407127402 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407127438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422407127438 : Closed e2422407127438 ∧ code e2422407127438 = 11218500149646 := by decide
theorem cert_e2422407127438 : check e2422407127438 [[],[]] .chain = true := by decide
def e2422407127450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407127450 : Closed e2422407127450 ∧ code e2422407127450 = 11218500149658 := by decide
theorem cert_e2422407127450 : check e2422407127450 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407127494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422407127494 : Closed e2422407127494 ∧ code e2422407127494 = 11218500149702 := by decide
theorem cert_e2422407127494 : check e2422407127494 [[],[]] .chain = true := by decide
def e2422407127518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407127518 : Closed e2422407127518 ∧ code e2422407127518 = 11218500149726 := by decide
theorem cert_e2422407127518 : check e2422407127518 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407127522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407127522 : Closed e2422407127522 ∧ code e2422407127522 = 11218500149730 := by decide
theorem cert_e2422407127522 : check e2422407127522 [[],[]] .chain = true := by decide
def e2422407127534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422407127534 : Closed e2422407127534 ∧ code e2422407127534 = 11218500149742 := by decide
theorem cert_e2422407127534 : check e2422407127534 [[],[]] .chain = true := by decide
def e2422407127542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407127542 : Closed e2422407127542 ∧ code e2422407127542 = 11218500149750 := by decide
theorem cert_e2422407127542 : check e2422407127542 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407128458 : Closed e2422407128458 ∧ code e2422407128458 = 11218500150666 := by decide
theorem cert_e2422407128458 : check e2422407128458 [[],[]] .chain = true := by decide
def e2422407128482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407128482 : Closed e2422407128482 ∧ code e2422407128482 = 11218500150690 := by decide
theorem cert_e2422407128482 : check e2422407128482 [[],[]] .chain = true := by decide
def e2422407128494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407128494 : Closed e2422407128494 ∧ code e2422407128494 = 11218500150702 := by decide
theorem cert_e2422407128494 : check e2422407128494 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422407128502 : Closed e2422407128502 ∧ code e2422407128502 = 11218500150710 := by decide
theorem cert_e2422407128502 : check e2422407128502 [[],[]] .chain = true := by decide
def e2422407128506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407128506 : Closed e2422407128506 ∧ code e2422407128506 = 11218500150714 := by decide
theorem cert_e2422407128506 : check e2422407128506 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422407128534 : Closed e2422407128534 ∧ code e2422407128534 = 11218500150742 := by decide
theorem cert_e2422407128534 : check e2422407128534 [[],[]] .chain = true := by decide
def e2422407128538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422407128538 : Closed e2422407128538 ∧ code e2422407128538 = 11218500150746 := by decide
theorem cert_e2422407128538 : check e2422407128538 [[],[]] .chain = true := by decide
def e2422407128554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407128554 : Closed e2422407128554 ∧ code e2422407128554 = 11218500150762 := by decide
theorem cert_e2422407128554 : check e2422407128554 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407128578 : Closed e2422407128578 ∧ code e2422407128578 = 11218500150786 := by decide
theorem cert_e2422407128578 : check e2422407128578 [[],[]] .chain = true := by decide
def e2422407128590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407128590 : Closed e2422407128590 ∧ code e2422407128590 = 11218500150798 := by decide
theorem cert_e2422407128590 : check e2422407128590 [[],[]] .chain = true := by decide
def e2422407128602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407128602 : Closed e2422407128602 ∧ code e2422407128602 = 11218500150810 := by decide
theorem cert_e2422407128602 : check e2422407128602 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407128674 : Closed e2422407128674 ∧ code e2422407128674 = 11218500150882 := by decide
theorem cert_e2422407128674 : check e2422407128674 [[],[]] .chain = true := by decide
def e2422407128686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407128686 : Closed e2422407128686 ∧ code e2422407128686 = 11218500150894 := by decide
theorem cert_e2422407128686 : check e2422407128686 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407128694 : Closed e2422407128694 ∧ code e2422407128694 = 11218500150902 := by decide
theorem cert_e2422407128694 : check e2422407128694 [[],[]] .chain = true := by decide
def e2422407128698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407128698 : Closed e2422407128698 ∧ code e2422407128698 = 11218500150906 := by decide
theorem cert_e2422407128698 : check e2422407128698 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407128838 : Closed e2422407128838 ∧ code e2422407128838 = 11218500151046 := by decide
theorem cert_e2422407128838 : check e2422407128838 [[],[]] .chain = true := by decide
def e2422407128862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407128862 : Closed e2422407128862 ∧ code e2422407128862 = 11218500151070 := by decide
theorem cert_e2422407128862 : check e2422407128862 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407128886 : Closed e2422407128886 ∧ code e2422407128886 = 11218500151094 := by decide
theorem cert_e2422407128886 : check e2422407128886 [[],[]] .chain = true := by decide
def e2422407128890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407128890 : Closed e2422407128890 ∧ code e2422407128890 = 11218500151098 := by decide
theorem cert_e2422407128890 : check e2422407128890 [[],[]] .chain = true := by decide
def e2422407128962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407128962 : Closed e2422407128962 ∧ code e2422407128962 = 11218500151170 := by decide
theorem cert_e2422407128962 : check e2422407128962 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407128974 : Closed e2422407128974 ∧ code e2422407128974 = 11218500151182 := by decide
theorem cert_e2422407128974 : check e2422407128974 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407128986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407128986 : Closed e2422407128986 ∧ code e2422407128986 = 11218500151194 := by decide
theorem cert_e2422407128986 : check e2422407128986 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407131374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407131374 : Closed e2422407131374 ∧ code e2422407131374 = 11218500153582 := by decide
def e2422407131382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407131382 : Closed e2422407131382 ∧ code e2422407131382 = 11218500153590 := by decide
theorem cert_e2422407131382 : check e2422407131382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2422407131862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407131862 : Closed e2422407131862 ∧ code e2422407131862 = 11218500154070 := by decide
end Blc.Floor43
