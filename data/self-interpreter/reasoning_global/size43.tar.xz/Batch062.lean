import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756127817846 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756127817846 : Closed e756127817846 ∧ code e756127817846 = 9552220840054 := by decide
theorem cert_e756127817846 : check e756127817846 [] .sourceHead = true := by decide
def e756127818090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756127818090 : Closed e756127818090 ∧ code e756127818090 = 9552220840298 := by decide
theorem cert_e756127818090 : check e756127818090 [] .sourceHead = true := by decide
def e756127818138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756127818138 : Closed e756127818138 ∧ code e756127818138 = 9552220840346 := by decide
theorem cert_e756127818138 : check e756127818138 [] .sourceHead = true := by decide
def e756127819290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756127819290 : Closed e756127819290 ∧ code e756127819290 = 9552220841498 := by decide
theorem cert_e756127819290 : check e756127819290 [] .sourceHead = true := by decide
def e756127833626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127833626 : Closed e756127833626 ∧ code e756127833626 = 9552220855834 := by decide
theorem cert_e756127833626 : check e756127833626 [] .sourceHead = true := by decide
def e756127854790 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756127854790 : Closed e756127854790 ∧ code e756127854790 = 9552220876998 := by decide
theorem cert_e756127854790 : check e756127854790 [] .sourceHead = true := by decide
def e756127862298 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127862298 : Closed e756127862298 ∧ code e756127862298 = 9552220884506 := by decide
theorem cert_e756127862298 : check e756127862298 [] .sourceHead = true := by decide
def e756127865370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127865370 : Closed e756127865370 ∧ code e756127865370 = 9552220887578 := by decide
theorem cert_e756127865370 : check e756127865370 [] .sourceHead = true := by decide
def e756127866906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756127866906 : Closed e756127866906 ∧ code e756127866906 = 9552220889114 := by decide
theorem cert_e756127866906 : check e756127866906 [] .sourceHead = true := by decide
def e756127866998 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756127866998 : Closed e756127866998 ∧ code e756127866998 = 9552220889206 := by decide
theorem cert_e756127866998 : check e756127866998 [] .sourceHead = true := by decide
def e756127867242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756127867242 : Closed e756127867242 ∧ code e756127867242 = 9552220889450 := by decide
theorem cert_e756127867242 : check e756127867242 [] .sourceHead = true := by decide
def e756127867290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756127867290 : Closed e756127867290 ∧ code e756127867290 = 9552220889498 := by decide
theorem cert_e756127867290 : check e756127867290 [] .sourceHead = true := by decide
def e756127868442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756127868442 : Closed e756127868442 ∧ code e756127868442 = 9552220890650 := by decide
theorem cert_e756127868442 : check e756127868442 [] .sourceHead = true := by decide
def e756127871174 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756127871174 : Closed e756127871174 ∧ code e756127871174 = 9552220893382 := by decide
theorem cert_e756127871174 : check e756127871174 [] .sourceHead = true := by decide
def e756127873050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756127873050 : Closed e756127873050 ∧ code e756127873050 = 9552220895258 := by decide
theorem cert_e756127873050 : check e756127873050 [] .sourceHead = true := by decide
def e756127921690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127921690 : Closed e756127921690 ∧ code e756127921690 = 9552220943898 := by decide
theorem cert_e756127921690 : check e756127921690 [] .sourceHead = true := by decide
def e756127946266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127946266 : Closed e756127946266 ∧ code e756127946266 = 9552220968474 := by decide
theorem cert_e756127946266 : check e756127946266 [] .sourceHead = true := by decide
def e756127947290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127947290 : Closed e756127947290 ∧ code e756127947290 = 9552220969498 := by decide
theorem cert_e756127947290 : check e756127947290 [] .sourceHead = true := by decide
def e756127951386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127951386 : Closed e756127951386 ∧ code e756127951386 = 9552220973594 := by decide
theorem cert_e756127951386 : check e756127951386 [] .sourceHead = true := by decide
def e756127970842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127970842 : Closed e756127970842 ∧ code e756127970842 = 9552220993050 := by decide
theorem cert_e756127970842 : check e756127970842 [] .sourceHead = true := by decide
def e756127971866 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127971866 : Closed e756127971866 ∧ code e756127971866 = 9552220994074 := by decide
theorem cert_e756127971866 : check e756127971866 [] .sourceHead = true := by decide
def e756127981594 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756127981594 : Closed e756127981594 ∧ code e756127981594 = 9552221003802 := by decide
theorem cert_e756127981594 : check e756127981594 [] .sourceHead = true := by decide
def e756127981686 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756127981686 : Closed e756127981686 ∧ code e756127981686 = 9552221003894 := by decide
theorem cert_e756127981686 : check e756127981686 [] .sourceHead = true := by decide
def e756127981930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756127981930 : Closed e756127981930 ∧ code e756127981930 = 9552221004138 := by decide
theorem cert_e756127981930 : check e756127981930 [] .sourceHead = true := by decide
def e756127981978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756127981978 : Closed e756127981978 ∧ code e756127981978 = 9552221004186 := by decide
theorem cert_e756127981978 : check e756127981978 [] .sourceHead = true := by decide
def e756127983130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756127983130 : Closed e756127983130 ∧ code e756127983130 = 9552221005338 := by decide
theorem cert_e756127983130 : check e756127983130 [] .sourceHead = true := by decide
def e756127993370 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127993370 : Closed e756127993370 ∧ code e756127993370 = 9552221015578 := by decide
theorem cert_e756127993370 : check e756127993370 [] .sourceHead = true := by decide
def e756127996442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756127996442 : Closed e756127996442 ∧ code e756127996442 = 9552221018650 := by decide
theorem cert_e756127996442 : check e756127996442 [] .sourceHead = true := by decide
def e756127997978 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756127997978 : Closed e756127997978 ∧ code e756127997978 = 9552221020186 := by decide
theorem cert_e756127997978 : check e756127997978 [] .sourceHead = true := by decide
def e756127998070 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756127998070 : Closed e756127998070 ∧ code e756127998070 = 9552221020278 := by decide
theorem cert_e756127998070 : check e756127998070 [] .sourceHead = true := by decide
def e756127998314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756127998314 : Closed e756127998314 ∧ code e756127998314 = 9552221020522 := by decide
theorem cert_e756127998314 : check e756127998314 [] .sourceHead = true := by decide
def e756127998362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756127998362 : Closed e756127998362 ∧ code e756127998362 = 9552221020570 := by decide
theorem cert_e756127998362 : check e756127998362 [] .sourceHead = true := by decide
def e756127999514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756127999514 : Closed e756127999514 ∧ code e756127999514 = 9552221021722 := by decide
theorem cert_e756127999514 : check e756127999514 [] .sourceHead = true := by decide
def e756128002246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756128002246 : Closed e756128002246 ∧ code e756128002246 = 9552221024454 := by decide
theorem cert_e756128002246 : check e756128002246 [] .sourceHead = true := by decide
def e756128004122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756128004122 : Closed e756128004122 ∧ code e756128004122 = 9552221026330 := by decide
theorem cert_e756128004122 : check e756128004122 [] .sourceHead = true := by decide
def e756128012314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756128012314 : Closed e756128012314 ∧ code e756128012314 = 9552221034522 := by decide
theorem cert_e756128012314 : check e756128012314 [] .sourceHead = true := by decide
def e756128407066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128407066 : Closed e756128407066 ∧ code e756128407066 = 9552221429274 := by decide
theorem cert_e756128407066 : check e756128407066 [] .sourceHead = true := by decide
def e756128411162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128411162 : Closed e756128411162 ∧ code e756128411162 = 9552221433370 := by decide
theorem cert_e756128411162 : check e756128411162 [] .sourceHead = true := by decide
def e756128902682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128902682 : Closed e756128902682 ∧ code e756128902682 = 9552221924890 := by decide
theorem cert_e756128902682 : check e756128902682 [] .sourceHead = true := by decide
def e756128904730 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128904730 : Closed e756128904730 ∧ code e756128904730 = 9552221926938 := by decide
theorem cert_e756128904730 : check e756128904730 [] .sourceHead = true := by decide
def e756128919066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128919066 : Closed e756128919066 ∧ code e756128919066 = 9552221941274 := by decide
theorem cert_e756128919066 : check e756128919066 [] .sourceHead = true := by decide
def e756128922138 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128922138 : Closed e756128922138 ∧ code e756128922138 = 9552221944346 := by decide
theorem cert_e756128922138 : check e756128922138 [] .sourceHead = true := by decide
def e756128929306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128929306 : Closed e756128929306 ∧ code e756128929306 = 9552221951514 := by decide
theorem cert_e756128929306 : check e756128929306 [] .sourceHead = true := by decide
def e756128930330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756128930330 : Closed e756128930330 ∧ code e756128930330 = 9552221952538 := by decide
theorem cert_e756128930330 : check e756128930330 [] .sourceHead = true := by decide
def e756129000986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756129000986 : Closed e756129000986 ∧ code e756129000986 = 9552222023194 := by decide
theorem cert_e756129000986 : check e756129000986 [] .sourceHead = true := by decide
def e756129003034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756129003034 : Closed e756129003034 ∧ code e756129003034 = 9552222025242 := by decide
theorem cert_e756129003034 : check e756129003034 [] .sourceHead = true := by decide
def e756129099290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756129099290 : Closed e756129099290 ∧ code e756129099290 = 9552222121498 := by decide
theorem cert_e756129099290 : check e756129099290 [] .sourceHead = true := by decide
def e756129102362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756129102362 : Closed e756129102362 ∧ code e756129102362 = 9552222124570 := by decide
theorem cert_e756129102362 : check e756129102362 [] .sourceHead = true := by decide
def e756129128474 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756129128474 : Closed e756129128474 ∧ code e756129128474 = 9552222150682 := by decide
theorem cert_e756129128474 : check e756129128474 [] .sourceHead = true := by decide
def e756129128566 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756129128566 : Closed e756129128566 ∧ code e756129128566 = 9552222150774 := by decide
theorem cert_e756129128566 : check e756129128566 [] .sourceHead = true := by decide
def e756129128810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756129128810 : Closed e756129128810 ∧ code e756129128810 = 9552222151018 := by decide
theorem cert_e756129128810 : check e756129128810 [] .sourceHead = true := by decide
def e756129128858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756129128858 : Closed e756129128858 ∧ code e756129128858 = 9552222151066 := by decide
theorem cert_e756129128858 : check e756129128858 [] .sourceHead = true := by decide
def e756129130010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756129130010 : Closed e756129130010 ∧ code e756129130010 = 9552222152218 := by decide
theorem cert_e756129130010 : check e756129130010 [] .sourceHead = true := by decide
def e756129150490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756129150490 : Closed e756129150490 ∧ code e756129150490 = 9552222172698 := by decide
theorem cert_e756129150490 : check e756129150490 [] .sourceHead = true := by decide
def e756129151514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756129151514 : Closed e756129151514 ∧ code e756129151514 = 9552222173722 := by decide
theorem cert_e756129151514 : check e756129151514 [] .sourceHead = true := by decide
def e756129161242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756129161242 : Closed e756129161242 ∧ code e756129161242 = 9552222183450 := by decide
theorem cert_e756129161242 : check e756129161242 [] .sourceHead = true := by decide
def e756129161334 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756129161334 : Closed e756129161334 ∧ code e756129161334 = 9552222183542 := by decide
theorem cert_e756129161334 : check e756129161334 [] .sourceHead = true := by decide
def e756129161578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756129161578 : Closed e756129161578 ∧ code e756129161578 = 9552222183786 := by decide
theorem cert_e756129161578 : check e756129161578 [] .sourceHead = true := by decide
def e756129161626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756129161626 : Closed e756129161626 ∧ code e756129161626 = 9552222183834 := by decide
theorem cert_e756129161626 : check e756129161626 [] .sourceHead = true := by decide
def e756129162778 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756129162778 : Closed e756129162778 ∧ code e756129162778 = 9552222184986 := by decide
theorem cert_e756129162778 : check e756129162778 [] .sourceHead = true := by decide
def e756130373146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130373146 : Closed e756130373146 ∧ code e756130373146 = 9552223395354 := by decide
theorem cert_e756130373146 : check e756130373146 [] .sourceHead = true := by decide
def e756130379290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130379290 : Closed e756130379290 ∧ code e756130379290 = 9552223401498 := by decide
theorem cert_e756130379290 : check e756130379290 [] .sourceHead = true := by decide
def e756130623002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130623002 : Closed e756130623002 ∧ code e756130623002 = 9552223645210 := by decide
theorem cert_e756130623002 : check e756130623002 [] .sourceHead = true := by decide
def e756130626074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130626074 : Closed e756130626074 ∧ code e756130626074 = 9552223648282 := by decide
theorem cert_e756130626074 : check e756130626074 [] .sourceHead = true := by decide
def e756130638362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130638362 : Closed e756130638362 ∧ code e756130638362 = 9552223660570 := by decide
theorem cert_e756130638362 : check e756130638362 [] .sourceHead = true := by decide
def e756130672154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130672154 : Closed e756130672154 ∧ code e756130672154 = 9552223694362 := by decide
theorem cert_e756130672154 : check e756130672154 [] .sourceHead = true := by decide
def e756130675226 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130675226 : Closed e756130675226 ∧ code e756130675226 = 9552223697434 := by decide
theorem cert_e756130675226 : check e756130675226 [] .sourceHead = true := by decide
def e756130701338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756130701338 : Closed e756130701338 ∧ code e756130701338 = 9552223723546 := by decide
theorem cert_e756130701338 : check e756130701338 [] .sourceHead = true := by decide
def e756130701430 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756130701430 : Closed e756130701430 ∧ code e756130701430 = 9552223723638 := by decide
theorem cert_e756130701430 : check e756130701430 [] .sourceHead = true := by decide
def e756130701674 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756130701674 : Closed e756130701674 ∧ code e756130701674 = 9552223723882 := by decide
theorem cert_e756130701674 : check e756130701674 [] .sourceHead = true := by decide
def e756130701722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756130701722 : Closed e756130701722 ∧ code e756130701722 = 9552223723930 := by decide
theorem cert_e756130701722 : check e756130701722 [] .sourceHead = true := by decide
def e756130702874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756130702874 : Closed e756130702874 ∧ code e756130702874 = 9552223725082 := by decide
theorem cert_e756130702874 : check e756130702874 [] .sourceHead = true := by decide
def e756130717210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130717210 : Closed e756130717210 ∧ code e756130717210 = 9552223739418 := by decide
theorem cert_e756130717210 : check e756130717210 [] .sourceHead = true := by decide
def e756130738374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756130738374 : Closed e756130738374 ∧ code e756130738374 = 9552223760582 := by decide
theorem cert_e756130738374 : check e756130738374 [] .sourceHead = true := by decide
def e756130745882 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130745882 : Closed e756130745882 ∧ code e756130745882 = 9552223768090 := by decide
theorem cert_e756130745882 : check e756130745882 [] .sourceHead = true := by decide
def e756130748954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756130748954 : Closed e756130748954 ∧ code e756130748954 = 9552223771162 := by decide
theorem cert_e756130748954 : check e756130748954 [] .sourceHead = true := by decide
def e756130750490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756130750490 : Closed e756130750490 ∧ code e756130750490 = 9552223772698 := by decide
theorem cert_e756130750490 : check e756130750490 [] .sourceHead = true := by decide
def e756130750582 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756130750582 : Closed e756130750582 ∧ code e756130750582 = 9552223772790 := by decide
theorem cert_e756130750582 : check e756130750582 [] .sourceHead = true := by decide
def e756130750826 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756130750826 : Closed e756130750826 ∧ code e756130750826 = 9552223773034 := by decide
theorem cert_e756130750826 : check e756130750826 [] .sourceHead = true := by decide
def e756130750874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756130750874 : Closed e756130750874 ∧ code e756130750874 = 9552223773082 := by decide
theorem cert_e756130750874 : check e756130750874 [] .sourceHead = true := by decide
def e756130752026 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756130752026 : Closed e756130752026 ∧ code e756130752026 = 9552223774234 := by decide
theorem cert_e756130752026 : check e756130752026 [] .sourceHead = true := by decide
def e756130754758 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756130754758 : Closed e756130754758 ∧ code e756130754758 = 9552223776966 := by decide
theorem cert_e756130754758 : check e756130754758 [] .sourceHead = true := by decide
def e756130756634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756130756634 : Closed e756130756634 ∧ code e756130756634 = 9552223778842 := by decide
theorem cert_e756130756634 : check e756130756634 [] .sourceHead = true := by decide
def e756131360282 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131360282 : Closed e756131360282 ∧ code e756131360282 = 9552224382490 := by decide
theorem cert_e756131360282 : check e756131360282 [] .sourceHead = true := by decide
def e756131362330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131362330 : Closed e756131362330 ∧ code e756131362330 = 9552224384538 := by decide
theorem cert_e756131362330 : check e756131362330 [] .sourceHead = true := by decide
def e756131485210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131485210 : Closed e756131485210 ∧ code e756131485210 = 9552224507418 := by decide
theorem cert_e756131485210 : check e756131485210 [] .sourceHead = true := by decide
def e756131486234 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131486234 : Closed e756131486234 ∧ code e756131486234 = 9552224508442 := by decide
theorem cert_e756131486234 : check e756131486234 [] .sourceHead = true := by decide
def e756131490330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131490330 : Closed e756131490330 ∧ code e756131490330 = 9552224512538 := by decide
theorem cert_e756131490330 : check e756131490330 [] .sourceHead = true := by decide
def e756131509786 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131509786 : Closed e756131509786 ∧ code e756131509786 = 9552224531994 := by decide
theorem cert_e756131509786 : check e756131509786 [] .sourceHead = true := by decide
def e756131510810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131510810 : Closed e756131510810 ∧ code e756131510810 = 9552224533018 := by decide
theorem cert_e756131510810 : check e756131510810 [] .sourceHead = true := by decide
def e756131520538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756131520538 : Closed e756131520538 ∧ code e756131520538 = 9552224542746 := by decide
theorem cert_e756131520538 : check e756131520538 [] .sourceHead = true := by decide
def e756131520630 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756131520630 : Closed e756131520630 ∧ code e756131520630 = 9552224542838 := by decide
theorem cert_e756131520630 : check e756131520630 [] .sourceHead = true := by decide
def e756131520874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756131520874 : Closed e756131520874 ∧ code e756131520874 = 9552224543082 := by decide
theorem cert_e756131520874 : check e756131520874 [] .sourceHead = true := by decide
def e756131520922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756131520922 : Closed e756131520922 ∧ code e756131520922 = 9552224543130 := by decide
theorem cert_e756131520922 : check e756131520922 [] .sourceHead = true := by decide
def e756131522074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756131522074 : Closed e756131522074 ∧ code e756131522074 = 9552224544282 := by decide
theorem cert_e756131522074 : check e756131522074 [] .sourceHead = true := by decide
def e756131532314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131532314 : Closed e756131532314 ∧ code e756131532314 = 9552224554522 := by decide
theorem cert_e756131532314 : check e756131532314 [] .sourceHead = true := by decide
def e756131535386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756131535386 : Closed e756131535386 ∧ code e756131535386 = 9552224557594 := by decide
theorem cert_e756131535386 : check e756131535386 [] .sourceHead = true := by decide
def e756131536922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756131536922 : Closed e756131536922 ∧ code e756131536922 = 9552224559130 := by decide
theorem cert_e756131536922 : check e756131536922 [] .sourceHead = true := by decide
def e756131537014 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756131537014 : Closed e756131537014 ∧ code e756131537014 = 9552224559222 := by decide
theorem cert_e756131537014 : check e756131537014 [] .sourceHead = true := by decide
def e756131537258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756131537258 : Closed e756131537258 ∧ code e756131537258 = 9552224559466 := by decide
theorem cert_e756131537258 : check e756131537258 [] .sourceHead = true := by decide
def e756131537306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756131537306 : Closed e756131537306 ∧ code e756131537306 = 9552224559514 := by decide
theorem cert_e756131537306 : check e756131537306 [] .sourceHead = true := by decide
def e756131538458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756131538458 : Closed e756131538458 ∧ code e756131538458 = 9552224560666 := by decide
theorem cert_e756131538458 : check e756131538458 [] .sourceHead = true := by decide
def e756131541190 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756131541190 : Closed e756131541190 ∧ code e756131541190 = 9552224563398 := by decide
theorem cert_e756131541190 : check e756131541190 [] .sourceHead = true := by decide
def e756131543066 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756131543066 : Closed e756131543066 ∧ code e756131543066 = 9552224565274 := by decide
theorem cert_e756131543066 : check e756131543066 [] .sourceHead = true := by decide
def e756131551258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756131551258 : Closed e756131551258 ∧ code e756131551258 = 9552224573466 := by decide
theorem cert_e756131551258 : check e756131551258 [] .sourceHead = true := by decide
def e756132392302 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e756132392302 : Closed e756132392302 ∧ code e756132392302 = 9552225414510 := by decide
theorem cert_e756132392302 : check e756132392302 [] .sourceHead = true := by decide
def e756132392310 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e756132392310 : Closed e756132392310 ∧ code e756132392310 = 9552225414518 := by decide
theorem cert_e756132392310 : check e756132392310 [] .sourceHead = true := by decide
def e756132392366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e756132392366 : Closed e756132392366 ∧ code e756132392366 = 9552225414574 := by decide
theorem cert_e756132392366 : check e756132392366 [] .sourceHead = true := by decide
def e756132392378 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e756132392378 : Closed e756132392378 ∧ code e756132392378 = 9552225414586 := by decide
theorem cert_e756132392378 : check e756132392378 [] .sourceHead = true := by decide
def e756132392406 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e756132392406 : Closed e756132392406 ∧ code e756132392406 = 9552225414614 := by decide
theorem cert_e756132392406 : check e756132392406 [] .sourceHead = true := by decide
def e756132392410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e756132392410 : Closed e756132392410 ∧ code e756132392410 = 9552225414618 := by decide
theorem cert_e756132392410 : check e756132392410 [] .sourceHead = true := by decide
def e756132392622 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e756132392622 : Closed e756132392622 ∧ code e756132392622 = 9552225414830 := by decide
theorem cert_e756132392622 : check e756132392622 [] .sourceHead = true := by decide
def e756132392634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e756132392634 : Closed e756132392634 ∧ code e756132392634 = 9552225414842 := by decide
theorem cert_e756132392634 : check e756132392634 [] .sourceHead = true := by decide
def e756132392682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e756132392682 : Closed e756132392682 ∧ code e756132392682 = 9552225414890 := by decide
theorem cert_e756132392682 : check e756132392682 [] .sourceHead = true := by decide
def e756132392790 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e756132392790 : Closed e756132392790 ∧ code e756132392790 = 9552225414998 := by decide
theorem cert_e756132392790 : check e756132392790 [] .sourceHead = true := by decide
def e756132392794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e756132392794 : Closed e756132392794 ∧ code e756132392794 = 9552225415002 := by decide
theorem cert_e756132392794 : check e756132392794 [] .sourceHead = true := by decide
def e756132392810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e756132392810 : Closed e756132392810 ∧ code e756132392810 = 9552225415018 := by decide
theorem cert_e756132392810 : check e756132392810 [] .sourceHead = true := by decide
def e756132393838 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e756132393838 : Closed e756132393838 ∧ code e756132393838 = 9552225416046 := by decide
theorem cert_e756132393838 : check e756132393838 [] .sourceHead = true := by decide
def e756132393846 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e756132393846 : Closed e756132393846 ∧ code e756132393846 = 9552225416054 := by decide
theorem cert_e756132393846 : check e756132393846 [] .sourceHead = true := by decide
def e756132393902 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e756132393902 : Closed e756132393902 ∧ code e756132393902 = 9552225416110 := by decide
theorem cert_e756132393902 : check e756132393902 [] .sourceHead = true := by decide
def e756132393914 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e756132393914 : Closed e756132393914 ∧ code e756132393914 = 9552225416122 := by decide
theorem cert_e756132393914 : check e756132393914 [] .sourceHead = true := by decide
def e756132393942 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e756132393942 : Closed e756132393942 ∧ code e756132393942 = 9552225416150 := by decide
theorem cert_e756132393942 : check e756132393942 [] .sourceHead = true := by decide
def e756132393946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e756132393946 : Closed e756132393946 ∧ code e756132393946 = 9552225416154 := by decide
theorem cert_e756132393946 : check e756132393946 [] .sourceHead = true := by decide
def e756132394222 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e756132394222 : Closed e756132394222 ∧ code e756132394222 = 9552225416430 := by decide
theorem cert_e756132394222 : check e756132394222 [] .sourceHead = true := by decide
def e756132394230 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e756132394230 : Closed e756132394230 ∧ code e756132394230 = 9552225416438 := by decide
theorem cert_e756132394230 : check e756132394230 [] .sourceHead = true := by decide
def e756132394606 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e756132394606 : Closed e756132394606 ∧ code e756132394606 = 9552225416814 := by decide
theorem cert_e756132394606 : check e756132394606 [] .sourceHead = true := by decide
def e756132394618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e756132394618 : Closed e756132394618 ∧ code e756132394618 = 9552225416826 := by decide
theorem cert_e756132394618 : check e756132394618 [] .sourceHead = true := by decide
def e756132394806 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e756132394806 : Closed e756132394806 ∧ code e756132394806 = 9552225417014 := by decide
theorem cert_e756132394806 : check e756132394806 [] .sourceHead = true := by decide
def e756132394810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e756132394810 : Closed e756132394810 ∧ code e756132394810 = 9552225417018 := by decide
theorem cert_e756132394810 : check e756132394810 [] .sourceHead = true := by decide
def e756132395438 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e756132395438 : Closed e756132395438 ∧ code e756132395438 = 9552225417646 := by decide
theorem cert_e756132395438 : check e756132395438 [] .sourceHead = true := by decide
def e756132395450 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e756132395450 : Closed e756132395450 ∧ code e756132395450 = 9552225417658 := by decide
theorem cert_e756132395450 : check e756132395450 [] .sourceHead = true := by decide
def e756132395498 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e756132395498 : Closed e756132395498 ∧ code e756132395498 = 9552225417706 := by decide
theorem cert_e756132395498 : check e756132395498 [] .sourceHead = true := by decide
def e756132395630 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e756132395630 : Closed e756132395630 ∧ code e756132395630 = 9552225417838 := by decide
theorem cert_e756132395630 : check e756132395630 [] .sourceHead = true := by decide
def e756132395642 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e756132395642 : Closed e756132395642 ∧ code e756132395642 = 9552225417850 := by decide
theorem cert_e756132395642 : check e756132395642 [] .sourceHead = true := by decide
def e756132395930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e756132395930 : Closed e756132395930 ∧ code e756132395930 = 9552225418138 := by decide
theorem cert_e756132395930 : check e756132395930 [] .sourceHead = true := by decide
def e756132396246 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e756132396246 : Closed e756132396246 ∧ code e756132396246 = 9552225418454 := by decide
theorem cert_e756132396246 : check e756132396246 [] .sourceHead = true := by decide
def e756132396250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e756132396250 : Closed e756132396250 ∧ code e756132396250 = 9552225418458 := by decide
theorem cert_e756132396250 : check e756132396250 [] .sourceHead = true := by decide
def e756132396266 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e756132396266 : Closed e756132396266 ∧ code e756132396266 = 9552225418474 := by decide
theorem cert_e756132396266 : check e756132396266 [] .sourceHead = true := by decide
def e756132396342 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e756132396342 : Closed e756132396342 ∧ code e756132396342 = 9552225418550 := by decide
theorem cert_e756132396342 : check e756132396342 [] .sourceHead = true := by decide
def e756132396346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e756132396346 : Closed e756132396346 ∧ code e756132396346 = 9552225418554 := by decide
theorem cert_e756132396346 : check e756132396346 [] .sourceHead = true := by decide
def e756132396442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e756132396442 : Closed e756132396442 ∧ code e756132396442 = 9552225418650 := by decide
theorem cert_e756132396442 : check e756132396442 [] .sourceHead = true := by decide
def e756132399982 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e756132399982 : Closed e756132399982 ∧ code e756132399982 = 9552225422190 := by decide
theorem cert_e756132399982 : check e756132399982 [] .sourceHead = true := by decide
def e756132399990 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e756132399990 : Closed e756132399990 ∧ code e756132399990 = 9552225422198 := by decide
theorem cert_e756132399990 : check e756132399990 [] .sourceHead = true := by decide
def e756132400046 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e756132400046 : Closed e756132400046 ∧ code e756132400046 = 9552225422254 := by decide
theorem cert_e756132400046 : check e756132400046 [] .sourceHead = true := by decide
def e756132400058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e756132400058 : Closed e756132400058 ∧ code e756132400058 = 9552225422266 := by decide
theorem cert_e756132400058 : check e756132400058 [] .sourceHead = true := by decide
def e756132400086 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e756132400086 : Closed e756132400086 ∧ code e756132400086 = 9552225422294 := by decide
theorem cert_e756132400086 : check e756132400086 [] .sourceHead = true := by decide
def e756132400090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e756132400090 : Closed e756132400090 ∧ code e756132400090 = 9552225422298 := by decide
theorem cert_e756132400090 : check e756132400090 [] .sourceHead = true := by decide
def e756132400366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e756132400366 : Closed e756132400366 ∧ code e756132400366 = 9552225422574 := by decide
theorem cert_e756132400366 : check e756132400366 [] .sourceHead = true := by decide
def e756132400374 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e756132400374 : Closed e756132400374 ∧ code e756132400374 = 9552225422582 := by decide
theorem cert_e756132400374 : check e756132400374 [] .sourceHead = true := by decide
def e756132400750 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e756132400750 : Closed e756132400750 ∧ code e756132400750 = 9552225422958 := by decide
theorem cert_e756132400750 : check e756132400750 [] .sourceHead = true := by decide
def e756132400762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e756132400762 : Closed e756132400762 ∧ code e756132400762 = 9552225422970 := by decide
theorem cert_e756132400762 : check e756132400762 [] .sourceHead = true := by decide
def e756132400950 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e756132400950 : Closed e756132400950 ∧ code e756132400950 = 9552225423158 := by decide
theorem cert_e756132400950 : check e756132400950 [] .sourceHead = true := by decide
def e756132400954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e756132400954 : Closed e756132400954 ∧ code e756132400954 = 9552225423162 := by decide
theorem cert_e756132400954 : check e756132400954 [] .sourceHead = true := by decide
def e756132406702 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e756132406702 : Closed e756132406702 ∧ code e756132406702 = 9552225428910 := by decide
theorem cert_e756132406702 : check e756132406702 [] .sourceHead = true := by decide
def e756132406714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e756132406714 : Closed e756132406714 ∧ code e756132406714 = 9552225428922 := by decide
theorem cert_e756132406714 : check e756132406714 [] .sourceHead = true := by decide
def e756132406762 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e756132406762 : Closed e756132406762 ∧ code e756132406762 = 9552225428970 := by decide
theorem cert_e756132406762 : check e756132406762 [] .sourceHead = true := by decide
def e756132406894 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e756132406894 : Closed e756132406894 ∧ code e756132406894 = 9552225429102 := by decide
theorem cert_e756132406894 : check e756132406894 [] .sourceHead = true := by decide
def e756132406906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e756132406906 : Closed e756132406906 ∧ code e756132406906 = 9552225429114 := by decide
theorem cert_e756132406906 : check e756132406906 [] .sourceHead = true := by decide
def e756132407194 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e756132407194 : Closed e756132407194 ∧ code e756132407194 = 9552225429402 := by decide
theorem cert_e756132407194 : check e756132407194 [] .sourceHead = true := by decide
def e756132410070 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e756132410070 : Closed e756132410070 ∧ code e756132410070 = 9552225432278 := by decide
theorem cert_e756132410070 : check e756132410070 [] .sourceHead = true := by decide
end Blc.Floor43
