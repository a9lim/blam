import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418067533338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067533338 : Closed e2418067533338 ∧ code e2418067533338 = 11214160555546 := by decide
theorem cert_e2418067533338 : check e2418067533338 [[],[],[.left]] .chain = true := by decide
def e2418067536410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067536410 : Closed e2418067536410 ∧ code e2418067536410 = 11214160558618 := by decide
theorem cert_e2418067536410 : check e2418067536410 [[],[],[.left]] .chain = true := by decide
def e2418067584538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067584538 : Closed e2418067584538 ∧ code e2418067584538 = 11214160606746 := by decide
theorem cert_e2418067584538 : check e2418067584538 [[],[],[.left]] .chain = true := by decide
def e2418067585562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418067585562 : Closed e2418067585562 ∧ code e2418067585562 = 11214160607770 := by decide
theorem cert_e2418067585562 : check e2418067585562 [[],[],[.left]] .chain = true := by decide
def e2418069583898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069583898 : Closed e2418069583898 ∧ code e2418069583898 = 11214162606106 := by decide
theorem cert_e2418069583898 : check e2418069583898 [[],[]] .smaller = true := by decide
def e2418069585434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069585434 : Closed e2418069585434 ∧ code e2418069585434 = 11214162607642 := by decide
theorem cert_e2418069585434 : check e2418069585434 [[]] .width = true := by decide
def e2418069592090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069592090 : Closed e2418069592090 ∧ code e2418069592090 = 11214162614298 := by decide
theorem cert_e2418069592090 : check e2418069592090 [[],[]] .smaller = true := by decide
def e2418069593626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069593626 : Closed e2418069593626 ∧ code e2418069593626 = 11214162615834 := by decide
theorem cert_e2418069593626 : check e2418069593626 [[],[],[.left]] .chain = true := by decide
def e2418069597722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069597722 : Closed e2418069597722 ∧ code e2418069597722 = 11214162619930 := by decide
theorem cert_e2418069597722 : check e2418069597722 [[],[],[.left]] .chain = true := by decide
def e2418069599770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069599770 : Closed e2418069599770 ∧ code e2418069599770 = 11214162621978 := by decide
theorem cert_e2418069599770 : check e2418069599770 [[]] .width = true := by decide
def e2418069649434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069649434 : Closed e2418069649434 ∧ code e2418069649434 = 11214162671642 := by decide
theorem cert_e2418069649434 : check e2418069649434 [[],[]] .smaller = true := by decide
def e2418069650970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069650970 : Closed e2418069650970 ∧ code e2418069650970 = 11214162673178 := by decide
theorem cert_e2418069650970 : check e2418069650970 [[]] .width = true := by decide
def e2418069661722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069661722 : Closed e2418069661722 ∧ code e2418069661722 = 11214162683930 := by decide
theorem cert_e2418069661722 : check e2418069661722 [[],[]] .smaller = true := by decide
def e2418069666330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069666330 : Closed e2418069666330 ∧ code e2418069666330 = 11214162688538 := by decide
theorem cert_e2418069666330 : check e2418069666330 [[]] .width = true := by decide
def e2418069690394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069690394 : Closed e2418069690394 ∧ code e2418069690394 = 11214162712602 := by decide
theorem cert_e2418069690394 : check e2418069690394 [[],[]] .smaller = true := by decide
def e2418069691930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069691930 : Closed e2418069691930 ∧ code e2418069691930 = 11214162714138 := by decide
theorem cert_e2418069691930 : check e2418069691930 [[],[],[.left]] .chain = true := by decide
def e2418069694490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069694490 : Closed e2418069694490 ∧ code e2418069694490 = 11214162716698 := by decide
theorem cert_e2418069694490 : check e2418069694490 [[],[]] .smaller = true := by decide
def e2418069699098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069699098 : Closed e2418069699098 ∧ code e2418069699098 = 11214162721306 := by decide
theorem cert_e2418069699098 : check e2418069699098 [[],[],[.left]] .chain = true := by decide
def e2418069712410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069712410 : Closed e2418069712410 ∧ code e2418069712410 = 11214162734618 := by decide
theorem cert_e2418069712410 : check e2418069712410 [[],[],[.left]] .chain = true := by decide
def e2418069715482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069715482 : Closed e2418069715482 ∧ code e2418069715482 = 11214162737690 := by decide
theorem cert_e2418069715482 : check e2418069715482 [[],[],[.left]] .chain = true := by decide
def e2418069722650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069722650 : Closed e2418069722650 ∧ code e2418069722650 = 11214162744858 := by decide
theorem cert_e2418069722650 : check e2418069722650 [[]] .width = true := by decide
def e2418069723674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069723674 : Closed e2418069723674 ∧ code e2418069723674 = 11214162745882 := by decide
theorem cert_e2418069723674 : check e2418069723674 [[]] .width = true := by decide
def e2418069977114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069977114 : Closed e2418069977114 ∧ code e2418069977114 = 11214162999322 := by decide
theorem cert_e2418069977114 : check e2418069977114 [[],[]] .smaller = true := by decide
def e2418069978650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069978650 : Closed e2418069978650 ∧ code e2418069978650 = 11214163000858 := by decide
theorem cert_e2418069978650 : check e2418069978650 [[]] .width = true := by decide
def e2418069985306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418069985306 : Closed e2418069985306 ∧ code e2418069985306 = 11214163007514 := by decide
theorem cert_e2418069985306 : check e2418069985306 [[],[]] .smaller = true := by decide
def e2418069986842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069986842 : Closed e2418069986842 ∧ code e2418069986842 = 11214163009050 := by decide
theorem cert_e2418069986842 : check e2418069986842 [[],[],[.left]] .chain = true := by decide
def e2418069990938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069990938 : Closed e2418069990938 ∧ code e2418069990938 = 11214163013146 := by decide
theorem cert_e2418069990938 : check e2418069990938 [[],[],[.left]] .chain = true := by decide
def e2418069992986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418069992986 : Closed e2418069992986 ∧ code e2418069992986 = 11214163015194 := by decide
theorem cert_e2418069992986 : check e2418069992986 [[]] .width = true := by decide
def e2418070370330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418070370330 : Closed e2418070370330 ∧ code e2418070370330 = 11214163392538 := by decide
theorem cert_e2418070370330 : check e2418070370330 [[],[]] .smaller = true := by decide
def e2418070371866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070371866 : Closed e2418070371866 ∧ code e2418070371866 = 11214163394074 := by decide
theorem cert_e2418070371866 : check e2418070371866 [[]] .width = true := by decide
def e2418070382618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418070382618 : Closed e2418070382618 ∧ code e2418070382618 = 11214163404826 := by decide
theorem cert_e2418070382618 : check e2418070382618 [[],[]] .smaller = true := by decide
def e2418070387226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070387226 : Closed e2418070387226 ∧ code e2418070387226 = 11214163409434 := by decide
theorem cert_e2418070387226 : check e2418070387226 [[]] .width = true := by decide
def e2418070575130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418070575130 : Closed e2418070575130 ∧ code e2418070575130 = 11214163597338 := by decide
theorem cert_e2418070575130 : check e2418070575130 [[],[]] .smaller = true := by decide
def e2418070576666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070576666 : Closed e2418070576666 ∧ code e2418070576666 = 11214163598874 := by decide
theorem cert_e2418070576666 : check e2418070576666 [[],[],[.left]] .chain = true := by decide
def e2418070579226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418070579226 : Closed e2418070579226 ∧ code e2418070579226 = 11214163601434 := by decide
theorem cert_e2418070579226 : check e2418070579226 [[],[]] .smaller = true := by decide
def e2418070583834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070583834 : Closed e2418070583834 ∧ code e2418070583834 = 11214163606042 := by decide
theorem cert_e2418070583834 : check e2418070583834 [[],[],[.left]] .chain = true := by decide
def e2418070679066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070679066 : Closed e2418070679066 ∧ code e2418070679066 = 11214163701274 := by decide
theorem cert_e2418070679066 : check e2418070679066 [[],[],[.left]] .chain = true := by decide
def e2418070682138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070682138 : Closed e2418070682138 ∧ code e2418070682138 = 11214163704346 := by decide
theorem cert_e2418070682138 : check e2418070682138 [[],[],[.left]] .chain = true := by decide
def e2418070730266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070730266 : Closed e2418070730266 ∧ code e2418070730266 = 11214163752474 := by decide
theorem cert_e2418070730266 : check e2418070730266 [[]] .width = true := by decide
def e2418070731290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418070731290 : Closed e2418070731290 ∧ code e2418070731290 = 11214163753498 := by decide
theorem cert_e2418070731290 : check e2418070731290 [[]] .width = true := by decide
def e2418077953562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418077953562 : Closed e2418077953562 ∧ code e2418077953562 = 11214170975770 := by decide
theorem cert_e2418077953562 : check e2418077953562 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418077955610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418077955610 : Closed e2418077955610 ∧ code e2418077955610 = 11214170977818 := by decide
theorem cert_e2418077955610 : check e2418077955610 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418077969946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418077969946 : Closed e2418077969946 ∧ code e2418077969946 = 11214170992154 := by decide
theorem cert_e2418077969946 : check e2418077969946 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418077973018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418077973018 : Closed e2418077973018 ∧ code e2418077973018 = 11214170995226 := by decide
theorem cert_e2418077973018 : check e2418077973018 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418077980186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418077980186 : Closed e2418077980186 ∧ code e2418077980186 = 11214171002394 := by decide
theorem cert_e2418077980186 : check e2418077980186 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418077981210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418077981210 : Closed e2418077981210 ∧ code e2418077981210 = 11214171003418 := by decide
theorem cert_e2418077981210 : check e2418077981210 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078035482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078035482 : Closed e2418078035482 ∧ code e2418078035482 = 11214171057690 := by decide
theorem cert_e2418078035482 : check e2418078035482 [[],[],[.left],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2418078038554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078038554 : Closed e2418078038554 ∧ code e2418078038554 = 11214171060762 := by decide
theorem cert_e2418078038554 : check e2418078038554 [[],[],[.left],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2418078050842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078050842 : Closed e2418078050842 ∧ code e2418078050842 = 11214171073050 := by decide
theorem cert_e2418078050842 : check e2418078050842 [[],[],[.left],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2418078078490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078078490 : Closed e2418078078490 ∧ code e2418078078490 = 11214171100698 := by decide
theorem cert_e2418078078490 : check e2418078078490 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078079514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078079514 : Closed e2418078079514 ∧ code e2418078079514 = 11214171101722 := by decide
theorem cert_e2418078079514 : check e2418078079514 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078083610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078083610 : Closed e2418078083610 ∧ code e2418078083610 = 11214171105818 := by decide
theorem cert_e2418078083610 : check e2418078083610 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2418078244378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078244378 : Closed e2418078244378 ∧ code e2418078244378 = 11214171266586 := by decide
theorem cert_e2418078244378 : check e2418078244378 [[]] .width = true := by decide
def e2418078250522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078250522 : Closed e2418078250522 ∧ code e2418078250522 = 11214171272730 := by decide
theorem cert_e2418078250522 : check e2418078250522 [[]] .width = true := by decide
def e2418078346778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078346778 : Closed e2418078346778 ∧ code e2418078346778 = 11214171368986 := by decide
theorem cert_e2418078346778 : check e2418078346778 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078348826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078348826 : Closed e2418078348826 ∧ code e2418078348826 = 11214171371034 := by decide
theorem cert_e2418078348826 : check e2418078348826 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078363162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078363162 : Closed e2418078363162 ∧ code e2418078363162 = 11214171385370 := by decide
theorem cert_e2418078363162 : check e2418078363162 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078366234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078366234 : Closed e2418078366234 ∧ code e2418078366234 = 11214171388442 := by decide
theorem cert_e2418078366234 : check e2418078366234 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078373402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078373402 : Closed e2418078373402 ∧ code e2418078373402 = 11214171395610 := by decide
theorem cert_e2418078373402 : check e2418078373402 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078374426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078374426 : Closed e2418078374426 ∧ code e2418078374426 = 11214171396634 := by decide
theorem cert_e2418078374426 : check e2418078374426 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078445082 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078445082 : Closed e2418078445082 ∧ code e2418078445082 = 11214171467290 := by decide
theorem cert_e2418078445082 : check e2418078445082 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078447130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078447130 : Closed e2418078447130 ∧ code e2418078447130 = 11214171469338 := by decide
theorem cert_e2418078447130 : check e2418078447130 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078531098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078531098 : Closed e2418078531098 ∧ code e2418078531098 = 11214171553306 := by decide
theorem cert_e2418078531098 : check e2418078531098 [[]] .width = true := by decide
def e2418078543386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078543386 : Closed e2418078543386 ∧ code e2418078543386 = 11214171565594 := by decide
theorem cert_e2418078543386 : check e2418078543386 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078546458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078546458 : Closed e2418078546458 ∧ code e2418078546458 = 11214171568666 := by decide
theorem cert_e2418078546458 : check e2418078546458 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078572570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418078572570 : Closed e2418078572570 ∧ code e2418078572570 = 11214171594778 := by decide
theorem cert_e2418078572570 : check e2418078572570 [[],[]] .smaller = true := by decide
def e2418078572662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418078572662 : Closed e2418078572662 ∧ code e2418078572662 = 11214171594870 := by decide
theorem cert_e2418078572662 : check e2418078572662 [[],[],[.under,.left]] .chain = true := by decide
def e2418078572906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418078572906 : Closed e2418078572906 ∧ code e2418078572906 = 11214171595114 := by decide
theorem cert_e2418078572906 : check e2418078572906 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .chain = true := by decide
def e2418078572954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418078572954 : Closed e2418078572954 ∧ code e2418078572954 = 11214171595162 := by decide
theorem cert_e2418078572954 : check e2418078572954 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078576838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418078576838 : Closed e2418078576838 ∧ code e2418078576838 = 11214171599046 := by decide
theorem cert_e2418078576838 : check e2418078576838 [[]] .width = true := by decide
def e2418078594586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078594586 : Closed e2418078594586 ∧ code e2418078594586 = 11214171616794 := by decide
theorem cert_e2418078594586 : check e2418078594586 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078595610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078595610 : Closed e2418078595610 ∧ code e2418078595610 = 11214171617818 := by decide
theorem cert_e2418078595610 : check e2418078595610 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078605338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418078605338 : Closed e2418078605338 ∧ code e2418078605338 = 11214171627546 := by decide
theorem cert_e2418078605338 : check e2418078605338 [[],[]] .smaller = true := by decide
def e2418078605430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418078605430 : Closed e2418078605430 ∧ code e2418078605430 = 11214171627638 := by decide
theorem cert_e2418078605430 : check e2418078605430 [[],[],[.under,.left]] .chain = true := by decide
def e2418078605674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418078605674 : Closed e2418078605674 ∧ code e2418078605674 = 11214171627882 := by decide
theorem cert_e2418078605674 : check e2418078605674 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .chain = true := by decide
def e2418078605722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418078605722 : Closed e2418078605722 ∧ code e2418078605722 = 11214171627930 := by decide
theorem cert_e2418078605722 : check e2418078605722 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418078611482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418078611482 : Closed e2418078611482 ∧ code e2418078611482 = 11214171633690 := by decide
theorem cert_e2418078611482 : check e2418078611482 [[]] .width = true := by decide
def e2418078617114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078617114 : Closed e2418078617114 ∧ code e2418078617114 = 11214171639322 := by decide
theorem cert_e2418078617114 : check e2418078617114 [[]] .width = true := by decide
def e2418078625990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418078625990 : Closed e2418078625990 ∧ code e2418078625990 = 11214171648198 := by decide
theorem cert_e2418078625990 : check e2418078625990 [[]] .width = true := by decide
def e2418078627866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418078627866 : Closed e2418078627866 ∧ code e2418078627866 = 11214171650074 := by decide
theorem cert_e2418078627866 : check e2418078627866 [[]] .width = true := by decide
def e2418078703130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078703130 : Closed e2418078703130 ∧ code e2418078703130 = 11214171725338 := by decide
theorem cert_e2418078703130 : check e2418078703130 [[]] .width = true := by decide
def e2418078710298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078710298 : Closed e2418078710298 ∧ code e2418078710298 = 11214171732506 := by decide
theorem cert_e2418078710298 : check e2418078710298 [[]] .width = true := by decide
def e2418078756378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078756378 : Closed e2418078756378 ∧ code e2418078756378 = 11214171778586 := by decide
theorem cert_e2418078756378 : check e2418078756378 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078759450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078759450 : Closed e2418078759450 ∧ code e2418078759450 = 11214171781658 := by decide
theorem cert_e2418078759450 : check e2418078759450 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078771738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078771738 : Closed e2418078771738 ∧ code e2418078771738 = 11214171793946 := by decide
theorem cert_e2418078771738 : check e2418078771738 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2418078793242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078793242 : Closed e2418078793242 ∧ code e2418078793242 = 11214171815450 := by decide
theorem cert_e2418078793242 : check e2418078793242 [[]] .width = true := by decide
def e2418078805530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078805530 : Closed e2418078805530 ∧ code e2418078805530 = 11214171827738 := by decide
theorem cert_e2418078805530 : check e2418078805530 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078808602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078808602 : Closed e2418078808602 ∧ code e2418078808602 = 11214171830810 := by decide
theorem cert_e2418078808602 : check e2418078808602 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078834714 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418078834714 : Closed e2418078834714 ∧ code e2418078834714 = 11214171856922 := by decide
theorem cert_e2418078834714 : check e2418078834714 [[],[]] .smaller = true := by decide
def e2418078834806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418078834806 : Closed e2418078834806 ∧ code e2418078834806 = 11214171857014 := by decide
theorem cert_e2418078834806 : check e2418078834806 [[],[],[.under,.left]] .chain = true := by decide
def e2418078835050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418078835050 : Closed e2418078835050 ∧ code e2418078835050 = 11214171857258 := by decide
theorem cert_e2418078835050 : check e2418078835050 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418078835098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418078835098 : Closed e2418078835098 ∧ code e2418078835098 = 11214171857306 := by decide
theorem cert_e2418078835098 : check e2418078835098 [[],[],[.left],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2418078838982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418078838982 : Closed e2418078838982 ∧ code e2418078838982 = 11214171861190 := by decide
theorem cert_e2418078838982 : check e2418078838982 [[]] .width = true := by decide
def e2418078882330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078882330 : Closed e2418078882330 ∧ code e2418078882330 = 11214171904538 := by decide
theorem cert_e2418078882330 : check e2418078882330 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2418078883866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418078883866 : Closed e2418078883866 ∧ code e2418078883866 = 11214171906074 := by decide
theorem cert_e2418078883866 : check e2418078883866 [[],[]] .smaller = true := by decide
def e2418078883958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418078883958 : Closed e2418078883958 ∧ code e2418078883958 = 11214171906166 := by decide
theorem cert_e2418078883958 : check e2418078883958 [[],[],[.under,.left]] .chain = true := by decide
def e2418078884202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418078884202 : Closed e2418078884202 ∧ code e2418078884202 = 11214171906410 := by decide
theorem cert_e2418078884202 : check e2418078884202 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2418078884250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418078884250 : Closed e2418078884250 ∧ code e2418078884250 = 11214171906458 := by decide
theorem cert_e2418078884250 : check e2418078884250 [[],[],[.left],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2418078893594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078893594 : Closed e2418078893594 ∧ code e2418078893594 = 11214171915802 := by decide
theorem cert_e2418078893594 : check e2418078893594 [[]] .width = true := by decide
def e2418078896326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418078896326 : Closed e2418078896326 ∧ code e2418078896326 = 11214171918534 := by decide
theorem cert_e2418078896326 : check e2418078896326 [[]] .width = true := by decide
def e2418078963226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078963226 : Closed e2418078963226 ∧ code e2418078963226 = 11214171985434 := by decide
theorem cert_e2418078963226 : check e2418078963226 [[],[],[.left],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078964250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078964250 : Closed e2418078964250 ∧ code e2418078964250 = 11214171986458 := by decide
theorem cert_e2418078964250 : check e2418078964250 [[],[],[.left],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418078968346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078968346 : Closed e2418078968346 ∧ code e2418078968346 = 11214171990554 := by decide
theorem cert_e2418078968346 : check e2418078968346 [[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418078987802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078987802 : Closed e2418078987802 ∧ code e2418078987802 = 11214172010010 := by decide
theorem cert_e2418078987802 : checkPay e2418078987802 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418078988826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418078988826 : Closed e2418078988826 ∧ code e2418078988826 = 11214172011034 := by decide
theorem cert_e2418078988826 : checkPay e2418078988826 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418078998554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418078998554 : Closed e2418078998554 ∧ code e2418078998554 = 11214172020762 := by decide
theorem cert_e2418078998554 : check e2418078998554 [[],[]] .smaller = true := by decide
def e2418078998646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418078998646 : Closed e2418078998646 ∧ code e2418078998646 = 11214172020854 := by decide
theorem cert_e2418078998646 : check e2418078998646 [[],[],[.under,.left]] .chain = true := by decide
def e2418078998890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418078998890 : Closed e2418078998890 ∧ code e2418078998890 = 11214172021098 := by decide
theorem cert_e2418078998890 : check e2418078998890 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2418078998938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418078998938 : Closed e2418078998938 ∧ code e2418078998938 = 11214172021146 := by decide
theorem cert_e2418078998938 : check e2418078998938 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418079004698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418079004698 : Closed e2418079004698 ∧ code e2418079004698 = 11214172026906 := by decide
theorem cert_e2418079004698 : check e2418079004698 [[]] .width = true := by decide
def e2418079013402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079013402 : Closed e2418079013402 ∧ code e2418079013402 = 11214172035610 := by decide
theorem cert_e2418079013402 : check e2418079013402 [[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2418079014938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418079014938 : Closed e2418079014938 ∧ code e2418079014938 = 11214172037146 := by decide
theorem cert_e2418079014938 : check e2418079014938 [[],[]] .smaller = true := by decide
def e2418079015030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418079015030 : Closed e2418079015030 ∧ code e2418079015030 = 11214172037238 := by decide
theorem cert_e2418079015030 : check e2418079015030 [[],[],[.under,.left]] .chain = true := by decide
def e2418079015274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418079015274 : Closed e2418079015274 ∧ code e2418079015274 = 11214172037482 := by decide
theorem cert_e2418079015274 : check e2418079015274 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418079015322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418079015322 : Closed e2418079015322 ∧ code e2418079015322 = 11214172037530 := by decide
theorem cert_e2418079015322 : check e2418079015322 [[],[],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418079033370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418079033370 : Closed e2418079033370 ∧ code e2418079033370 = 11214172055578 := by decide
theorem cert_e2418079033370 : check e2418079033370 [[]] .width = true := by decide
def e2418079053338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079053338 : Closed e2418079053338 ∧ code e2418079053338 = 11214172075546 := by decide
theorem cert_e2418079053338 : check e2418079053338 [[]] .width = true := by decide
def e2418079054362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079054362 : Closed e2418079054362 ∧ code e2418079054362 = 11214172076570 := by decide
theorem cert_e2418079054362 : check e2418079054362 [[]] .width = true := by decide
def e2418079075866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079075866 : Closed e2418079075866 ∧ code e2418079075866 = 11214172098074 := by decide
theorem cert_e2418079075866 : check e2418079075866 [[]] .width = true := by decide
def e2418079084742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418079084742 : Closed e2418079084742 ∧ code e2418079084742 = 11214172106950 := by decide
theorem cert_e2418079084742 : check e2418079084742 [[]] .width = true := by decide
def e2418079086618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418079086618 : Closed e2418079086618 ∧ code e2418079086618 = 11214172108826 := by decide
theorem cert_e2418079086618 : check e2418079086618 [[]] .width = true := by decide
def e2418079090202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079090202 : Closed e2418079090202 ∧ code e2418079090202 = 11214172112410 := by decide
theorem cert_e2418079090202 : check e2418079090202 [[]] .width = true := by decide
def e2418079092934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418079092934 : Closed e2418079092934 ∧ code e2418079092934 = 11214172115142 := by decide
theorem cert_e2418079092934 : check e2418079092934 [[]] .width = true := by decide
def e2418079098906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418079098906 : Closed e2418079098906 ∧ code e2418079098906 = 11214172121114 := by decide
theorem cert_e2418079098906 : check e2418079098906 [[]] .width = true := by decide
def e2418079424026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079424026 : Closed e2418079424026 ∧ code e2418079424026 = 11214172446234 := by decide
theorem cert_e2418079424026 : check e2418079424026 [[],[],[.left]] .chain = true := by decide
def e2418079428122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079428122 : Closed e2418079428122 ∧ code e2418079428122 = 11214172450330 := by decide
theorem cert_e2418079428122 : check e2418079428122 [[],[],[.left]] .chain = true := by decide
def e2418079919642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079919642 : Closed e2418079919642 ∧ code e2418079919642 = 11214172941850 := by decide
theorem cert_e2418079919642 : check e2418079919642 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418079921690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079921690 : Closed e2418079921690 ∧ code e2418079921690 = 11214172943898 := by decide
theorem cert_e2418079921690 : check e2418079921690 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418079936026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079936026 : Closed e2418079936026 ∧ code e2418079936026 = 11214172958234 := by decide
theorem cert_e2418079936026 : check e2418079936026 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418079939098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079939098 : Closed e2418079939098 ∧ code e2418079939098 = 11214172961306 := by decide
theorem cert_e2418079939098 : check e2418079939098 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418079946266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079946266 : Closed e2418079946266 ∧ code e2418079946266 = 11214172968474 := by decide
theorem cert_e2418079946266 : check e2418079946266 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418079947290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418079947290 : Closed e2418079947290 ∧ code e2418079947290 = 11214172969498 := by decide
theorem cert_e2418079947290 : check e2418079947290 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080017946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080017946 : Closed e2418080017946 ∧ code e2418080017946 = 11214173040154 := by decide
theorem cert_e2418080017946 : check e2418080017946 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080019994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080019994 : Closed e2418080019994 ∧ code e2418080019994 = 11214173042202 := by decide
theorem cert_e2418080019994 : check e2418080019994 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080103962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080103962 : Closed e2418080103962 ∧ code e2418080103962 = 11214173126170 := by decide
theorem cert_e2418080103962 : check e2418080103962 [[]] .width = true := by decide
def e2418080116250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080116250 : Closed e2418080116250 ∧ code e2418080116250 = 11214173138458 := by decide
theorem cert_e2418080116250 : check e2418080116250 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080119322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080119322 : Closed e2418080119322 ∧ code e2418080119322 = 11214173141530 := by decide
theorem cert_e2418080119322 : check e2418080119322 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080145434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418080145434 : Closed e2418080145434 ∧ code e2418080145434 = 11214173167642 := by decide
theorem cert_e2418080145434 : check e2418080145434 [[],[]] .smaller = true := by decide
def e2418080145526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418080145526 : Closed e2418080145526 ∧ code e2418080145526 = 11214173167734 := by decide
theorem cert_e2418080145526 : check e2418080145526 [[],[],[.under,.left]] .chain = true := by decide
def e2418080145770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418080145770 : Closed e2418080145770 ∧ code e2418080145770 = 11214173167978 := by decide
theorem cert_e2418080145770 : check e2418080145770 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2418080145818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418080145818 : Closed e2418080145818 ∧ code e2418080145818 = 11214173168026 := by decide
theorem cert_e2418080145818 : check e2418080145818 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080149702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418080149702 : Closed e2418080149702 ∧ code e2418080149702 = 11214173171910 := by decide
theorem cert_e2418080149702 : check e2418080149702 [[]] .width = true := by decide
def e2418080167450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080167450 : Closed e2418080167450 ∧ code e2418080167450 = 11214173189658 := by decide
theorem cert_e2418080167450 : check e2418080167450 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080168474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080168474 : Closed e2418080168474 ∧ code e2418080168474 = 11214173190682 := by decide
theorem cert_e2418080168474 : check e2418080168474 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080178202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418080178202 : Closed e2418080178202 ∧ code e2418080178202 = 11214173200410 := by decide
theorem cert_e2418080178202 : check e2418080178202 [[],[]] .smaller = true := by decide
def e2418080178294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418080178294 : Closed e2418080178294 ∧ code e2418080178294 = 11214173200502 := by decide
theorem cert_e2418080178294 : check e2418080178294 [[],[],[.under,.left]] .chain = true := by decide
def e2418080178538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418080178538 : Closed e2418080178538 ∧ code e2418080178538 = 11214173200746 := by decide
theorem cert_e2418080178538 : check e2418080178538 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2418080178586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418080178586 : Closed e2418080178586 ∧ code e2418080178586 = 11214173200794 := by decide
theorem cert_e2418080178586 : check e2418080178586 [[],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2418080184346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418080184346 : Closed e2418080184346 ∧ code e2418080184346 = 11214173206554 := by decide
theorem cert_e2418080184346 : check e2418080184346 [[]] .width = true := by decide
def e2418080189978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418080189978 : Closed e2418080189978 ∧ code e2418080189978 = 11214173212186 := by decide
theorem cert_e2418080189978 : check e2418080189978 [[]] .width = true := by decide
def e2418080198854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418080198854 : Closed e2418080198854 ∧ code e2418080198854 = 11214173221062 := by decide
theorem cert_e2418080198854 : check e2418080198854 [[]] .width = true := by decide
def e2418080200730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418080200730 : Closed e2418080200730 ∧ code e2418080200730 = 11214173222938 := by decide
theorem cert_e2418080200730 : check e2418080200730 [[]] .width = true := by decide
def e2418081390106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081390106 : Closed e2418081390106 ∧ code e2418081390106 = 11214174412314 := by decide
theorem cert_e2418081390106 : check e2418081390106 [[],[],[.left]] .chain = true := by decide
def e2418081396250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081396250 : Closed e2418081396250 ∧ code e2418081396250 = 11214174418458 := by decide
theorem cert_e2418081396250 : check e2418081396250 [[],[],[.left]] .chain = true := by decide
def e2418081639962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081639962 : Closed e2418081639962 ∧ code e2418081639962 = 11214174662170 := by decide
theorem cert_e2418081639962 : check e2418081639962 [[],[],[.left],[.left],[],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418081643034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081643034 : Closed e2418081643034 ∧ code e2418081643034 = 11214174665242 := by decide
theorem cert_e2418081643034 : check e2418081643034 [[],[],[.left],[.left],[],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418081655322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081655322 : Closed e2418081655322 ∧ code e2418081655322 = 11214174677530 := by decide
theorem cert_e2418081655322 : check e2418081655322 [[],[],[.left],[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2418081676826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081676826 : Closed e2418081676826 ∧ code e2418081676826 = 11214174699034 := by decide
theorem cert_e2418081676826 : check e2418081676826 [[]] .width = true := by decide
def e2418081689114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081689114 : Closed e2418081689114 ∧ code e2418081689114 = 11214174711322 := by decide
theorem cert_e2418081689114 : checkPay e2418081689114 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418081692186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081692186 : Closed e2418081692186 ∧ code e2418081692186 = 11214174714394 := by decide
theorem cert_e2418081692186 : checkPay e2418081692186 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
end Blc.Floor43
