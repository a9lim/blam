import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2248523866474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248523866474 : Closed e2248523866474 ∧ code e2248523866474 = 11044616888682 := by decide
theorem cert_e2248523866474 : check e2248523866474 [[]] .width = true := by decide
def e2248523866522 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248523866522 : Closed e2248523866522 ∧ code e2248523866522 = 11044616888730 := by decide
theorem cert_e2248523866522 : check e2248523866522 [[]] .width = true := by decide
def e2248524019226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248524019226 : Closed e2248524019226 ∧ code e2248524019226 = 11044617041434 := by decide
theorem cert_e2248524019226 : check e2248524019226 [[]] .width = true := by decide
def e2248524027418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248524027418 : Closed e2248524027418 ∧ code e2248524027418 = 11044617049626 := by decide
theorem cert_e2248524027418 : check e2248524027418 [[]] .width = true := by decide
def e2248524107974 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248524107974 : Closed e2248524107974 ∧ code e2248524107974 = 11044617130182 := by decide
theorem cert_e2248524107974 : check e2248524107974 [[]] .width = true := by decide
def e2248524117530 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248524117530 : Closed e2248524117530 ∧ code e2248524117530 = 11044617139738 := by decide
theorem cert_e2248524117530 : check e2248524117530 [[]] .width = true := by decide
def e2248524118554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248524118554 : Closed e2248524118554 ∧ code e2248524118554 = 11044617140762 := by decide
theorem cert_e2248524118554 : check e2248524118554 [[]] .width = true := by decide
def e2248524120262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248524120262 : Closed e2248524120262 ∧ code e2248524120262 = 11044617142470 := by decide
theorem cert_e2248524120262 : check e2248524120262 [[]] .width = true := by decide
def e2248524128282 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248524128282 : Closed e2248524128282 ∧ code e2248524128282 = 11044617150490 := by decide
theorem cert_e2248524128282 : check e2248524128282 [[]] .width = true := by decide
def e2248524128374 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248524128374 : Closed e2248524128374 ∧ code e2248524128374 = 11044617150582 := by decide
theorem cert_e2248524128374 : check e2248524128374 [[]] .width = true := by decide
def e2248524128618 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248524128618 : Closed e2248524128618 ∧ code e2248524128618 = 11044617150826 := by decide
theorem cert_e2248524128618 : check e2248524128618 [[]] .width = true := by decide
def e2248524128666 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248524128666 : Closed e2248524128666 ∧ code e2248524128666 = 11044617150874 := by decide
theorem cert_e2248524128666 : check e2248524128666 [[]] .width = true := by decide
def e2248533800474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248533800474 : Closed e2248533800474 ∧ code e2248533800474 = 11044626822682 := by decide
theorem cert_e2248533800474 : check e2248533800474 [[]] .width = true := by decide
def e2248533849626 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248533849626 : Closed e2248533849626 ∧ code e2248533849626 = 11044626871834 := by decide
theorem cert_e2248533849626 : check e2248533849626 [[]] .width = true := by decide
def e2248535799322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248535799322 : Closed e2248535799322 ∧ code e2248535799322 = 11044628821530 := by decide
theorem cert_e2248535799322 : check e2248535799322 [[]] .width = true := by decide
def e2248535823898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248535823898 : Closed e2248535823898 ∧ code e2248535823898 = 11044628846106 := by decide
theorem cert_e2248535823898 : check e2248535823898 [[]] .width = true := by decide
def e2248535922202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248535922202 : Closed e2248535922202 ∧ code e2248535922202 = 11044628944410 := by decide
theorem cert_e2248535922202 : check e2248535922202 [[]] .width = true := by decide
def e2248536192538 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248536192538 : Closed e2248536192538 ∧ code e2248536192538 = 11044629214746 := by decide
theorem cert_e2248536192538 : check e2248536192538 [[]] .width = true := by decide
def e2248536217114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248536217114 : Closed e2248536217114 ∧ code e2248536217114 = 11044629239322 := by decide
theorem cert_e2248536217114 : check e2248536217114 [[]] .width = true := by decide
def e2248536428742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248536428742 : Closed e2248536428742 ∧ code e2248536428742 = 11044629450950 := by decide
theorem cert_e2248536428742 : check e2248536428742 [[]] .width = true := by decide
def e2248536438298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248536438298 : Closed e2248536438298 ∧ code e2248536438298 = 11044629460506 := by decide
theorem cert_e2248536438298 : check e2248536438298 [[]] .width = true := by decide
def e2248536439322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248536439322 : Closed e2248536439322 ∧ code e2248536439322 = 11044629461530 := by decide
theorem cert_e2248536439322 : check e2248536439322 [[]] .width = true := by decide
def e2248536441030 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248536441030 : Closed e2248536441030 ∧ code e2248536441030 = 11044629463238 := by decide
theorem cert_e2248536441030 : check e2248536441030 [[]] .width = true := by decide
def e2248536449050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248536449050 : Closed e2248536449050 ∧ code e2248536449050 = 11044629471258 := by decide
theorem cert_e2248536449050 : check e2248536449050 [[]] .width = true := by decide
def e2248536449142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248536449142 : Closed e2248536449142 ∧ code e2248536449142 = 11044629471350 := by decide
theorem cert_e2248536449142 : check e2248536449142 [[]] .width = true := by decide
def e2248536449386 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248536449386 : Closed e2248536449386 ∧ code e2248536449386 = 11044629471594 := by decide
theorem cert_e2248536449386 : check e2248536449386 [[]] .width = true := by decide
def e2248536449434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248536449434 : Closed e2248536449434 ∧ code e2248536449434 = 11044629471642 := by decide
theorem cert_e2248536449434 : check e2248536449434 [[]] .width = true := by decide
def e2248536806938 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248536806938 : Closed e2248536806938 ∧ code e2248536806938 = 11044629829146 := by decide
theorem cert_e2248536806938 : check e2248536806938 [[]] .width = true := by decide
def e2248536821958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248536821958 : Closed e2248536821958 ∧ code e2248536821958 = 11044629844166 := by decide
theorem cert_e2248536821958 : check e2248536821958 [[]] .width = true := by decide
def e2248536831514 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248536831514 : Closed e2248536831514 ∧ code e2248536831514 = 11044629853722 := by decide
theorem cert_e2248536831514 : check e2248536831514 [[]] .width = true := by decide
def e2248536832538 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248536832538 : Closed e2248536832538 ∧ code e2248536832538 = 11044629854746 := by decide
theorem cert_e2248536832538 : check e2248536832538 [[]] .width = true := by decide
def e2248536834246 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248536834246 : Closed e2248536834246 ∧ code e2248536834246 = 11044629856454 := by decide
theorem cert_e2248536834246 : check e2248536834246 [[]] .width = true := by decide
def e2248536842266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248536842266 : Closed e2248536842266 ∧ code e2248536842266 = 11044629864474 := by decide
theorem cert_e2248536842266 : check e2248536842266 [[]] .width = true := by decide
def e2248536842358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248536842358 : Closed e2248536842358 ∧ code e2248536842358 = 11044629864566 := by decide
theorem cert_e2248536842358 : check e2248536842358 [[]] .width = true := by decide
def e2248536842602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248536842602 : Closed e2248536842602 ∧ code e2248536842602 = 11044629864810 := by decide
theorem cert_e2248536842602 : check e2248536842602 [[]] .width = true := by decide
def e2248536842650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248536842650 : Closed e2248536842650 ∧ code e2248536842650 = 11044629864858 := by decide
theorem cert_e2248536842650 : check e2248536842650 [[]] .width = true := by decide
def e2248541697562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248541697562 : Closed e2248541697562 ∧ code e2248541697562 = 11044634719770 := by decide
theorem cert_e2248541697562 : check e2248541697562 [[]] .width = true := by decide
def e2248541713946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248541713946 : Closed e2248541713946 ∧ code e2248541713946 = 11044634736154 := by decide
theorem cert_e2248541713946 : check e2248541713946 [[]] .width = true := by decide
def e2248542696986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248542696986 : Closed e2248542696986 ∧ code e2248542696986 = 11044635719194 := by decide
private def t_e2248542696986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248542696986 : ¬ IsSelfInterpreter e2248542696986 :=
  wSource (t := t_e2248542696986) (replay_sound (ps := []) (t := e2248542696986) (by decide)) (by decide)
def e2248542705178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248542705178 : Closed e2248542705178 ∧ code e2248542705178 = 11044635727386 := by decide
theorem cert_e2248542705178 : check e2248542705178 [[]] .width = true := by decide
def e2248542737946 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248542737946 : Closed e2248542737946 ∧ code e2248542737946 = 11044635760154 := by decide
theorem cert_e2248542737946 : check e2248542737946 [[]] .width = true := by decide
def e2248542893594 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248542893594 : Closed e2248542893594 ∧ code e2248542893594 = 11044635915802 := by decide
theorem cert_e2248542893594 : check e2248542893594 [[]] .width = true := by decide
def e2248542901786 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248542901786 : Closed e2248542901786 ∧ code e2248542901786 = 11044635923994 := by decide
theorem cert_e2248542901786 : check e2248542901786 [[]] .width = true := by decide
def e2248542982342 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248542982342 : Closed e2248542982342 ∧ code e2248542982342 = 11044636004550 := by decide
theorem cert_e2248542982342 : check e2248542982342 [[]] .width = true := by decide
def e2248542991898 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248542991898 : Closed e2248542991898 ∧ code e2248542991898 = 11044636014106 := by decide
theorem cert_e2248542991898 : check e2248542991898 [[]] .width = true := by decide
def e2248542992922 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248542992922 : Closed e2248542992922 ∧ code e2248542992922 = 11044636015130 := by decide
theorem cert_e2248542992922 : check e2248542992922 [[]] .width = true := by decide
def e2248542994630 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248542994630 : Closed e2248542994630 ∧ code e2248542994630 = 11044636016838 := by decide
theorem cert_e2248542994630 : check e2248542994630 [[]] .width = true := by decide
def e2248543002650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248543002650 : Closed e2248543002650 ∧ code e2248543002650 = 11044636024858 := by decide
theorem cert_e2248543002650 : check e2248543002650 [[]] .width = true := by decide
def e2248543002742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248543002742 : Closed e2248543002742 ∧ code e2248543002742 = 11044636024950 := by decide
theorem cert_e2248543002742 : check e2248543002742 [[]] .width = true := by decide
def e2248543002986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248543002986 : Closed e2248543002986 ∧ code e2248543002986 = 11044636025194 := by decide
theorem cert_e2248543002986 : check e2248543002986 [[]] .width = true := by decide
def e2248543003034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248543003034 : Closed e2248543003034 ∧ code e2248543003034 = 11044636025242 := by decide
theorem cert_e2248543003034 : check e2248543003034 [[]] .width = true := by decide
def e2248543098394 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248543098394 : Closed e2248543098394 ∧ code e2248543098394 = 11044636120602 := by decide
theorem cert_e2248543098394 : check e2248543098394 [[]] .width = true := by decide
def e2248543113414 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248543113414 : Closed e2248543113414 ∧ code e2248543113414 = 11044636135622 := by decide
theorem cert_e2248543113414 : check e2248543113414 [[]] .width = true := by decide
def e2248543122970 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248543122970 : Closed e2248543122970 ∧ code e2248543122970 = 11044636145178 := by decide
theorem cert_e2248543122970 : check e2248543122970 [[]] .width = true := by decide
def e2248543123994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248543123994 : Closed e2248543123994 ∧ code e2248543123994 = 11044636146202 := by decide
theorem cert_e2248543123994 : check e2248543123994 [[]] .width = true := by decide
def e2248543125702 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248543125702 : Closed e2248543125702 ∧ code e2248543125702 = 11044636147910 := by decide
theorem cert_e2248543125702 : check e2248543125702 [[]] .width = true := by decide
def e2248543133722 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2248543133722 : Closed e2248543133722 ∧ code e2248543133722 = 11044636155930 := by decide
theorem cert_e2248543133722 : check e2248543133722 [[]] .width = true := by decide
def e2248543133814 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2248543133814 : Closed e2248543133814 ∧ code e2248543133814 = 11044636156022 := by decide
theorem cert_e2248543133814 : check e2248543133814 [[]] .width = true := by decide
def e2248543134058 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2248543134058 : Closed e2248543134058 ∧ code e2248543134058 = 11044636156266 := by decide
theorem cert_e2248543134058 : check e2248543134058 [[]] .width = true := by decide
def e2248543134106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2248543134106 : Closed e2248543134106 ∧ code e2248543134106 = 11044636156314 := by decide
theorem cert_e2248543134106 : check e2248543134106 [[]] .width = true := by decide
def e2248555589830 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248555589830 : Closed e2248555589830 ∧ code e2248555589830 = 11044648612038 := by decide
theorem cert_e2248555589830 : check e2248555589830 [[]] .width = true := by decide
def e2248555606214 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248555606214 : Closed e2248555606214 ∧ code e2248555606214 = 11044648628422 := by decide
theorem cert_e2248555606214 : check e2248555606214 [[]] .width = true := by decide
def e2248555720902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248555720902 : Closed e2248555720902 ∧ code e2248555720902 = 11044648743110 := by decide
theorem cert_e2248555720902 : check e2248555720902 [[]] .width = true := by decide
def e2248555745478 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248555745478 : Closed e2248555745478 ∧ code e2248555745478 = 11044648767686 := by decide
theorem cert_e2248555745478 : check e2248555745478 [[]] .width = true := by decide
def e2248555802822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248555802822 : Closed e2248555802822 ∧ code e2248555802822 = 11044648825030 := by decide
theorem cert_e2248555802822 : check e2248555802822 [[]] .width = true := by decide
def e2248555811014 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248555811014 : Closed e2248555811014 ∧ code e2248555811014 = 11044648833222 := by decide
theorem cert_e2248555811014 : check e2248555811014 [[]] .width = true := by decide
def e2248556376262 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248556376262 : Closed e2248556376262 ∧ code e2248556376262 = 11044649398470 := by decide
theorem cert_e2248556376262 : check e2248556376262 [[]] .width = true := by decide
def e2248556392646 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248556392646 : Closed e2248556392646 ∧ code e2248556392646 = 11044649414854 := by decide
theorem cert_e2248556392646 : check e2248556392646 [[]] .width = true := by decide
def e2248557162694 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248557162694 : Closed e2248557162694 ∧ code e2248557162694 = 11044650184902 := by decide
theorem cert_e2248557162694 : check e2248557162694 [[]] .width = true := by decide
def e2248557187270 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248557187270 : Closed e2248557187270 ∧ code e2248557187270 = 11044650209478 := by decide
theorem cert_e2248557187270 : check e2248557187270 [[]] .width = true := by decide
def e2248557572294 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248557572294 : Closed e2248557572294 ∧ code e2248557572294 = 11044650594502 := by decide
theorem cert_e2248557572294 : check e2248557572294 [[]] .width = true := by decide
def e2248557580486 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2248557580486 : Closed e2248557580486 ∧ code e2248557580486 = 11044650602694 := by decide
theorem cert_e2248557580486 : check e2248557580486 [[]] .width = true := by decide
def e2248599973230 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2248599973230 : Closed e2248599973230 ∧ code e2248599973230 = 11044692995438 := by decide
theorem cert_e2248599973230 : check e2248599973230 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973238 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2248599973238 : Closed e2248599973238 ∧ code e2248599973238 = 11044692995446 := by decide
theorem cert_e2248599973238 : check e2248599973238 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973294 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2248599973294 : Closed e2248599973294 ∧ code e2248599973294 = 11044692995502 := by decide
theorem cert_e2248599973294 : check e2248599973294 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2248599973306 : Closed e2248599973306 ∧ code e2248599973306 = 11044692995514 := by decide
theorem cert_e2248599973306 : check e2248599973306 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973334 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2248599973334 : Closed e2248599973334 ∧ code e2248599973334 = 11044692995542 := by decide
theorem cert_e2248599973334 : check e2248599973334 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973338 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2248599973338 : Closed e2248599973338 ∧ code e2248599973338 = 11044692995546 := by decide
theorem cert_e2248599973338 : check e2248599973338 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973550 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2248599973550 : Closed e2248599973550 ∧ code e2248599973550 = 11044692995758 := by decide
theorem cert_e2248599973550 : check e2248599973550 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973562 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2248599973562 : Closed e2248599973562 ∧ code e2248599973562 = 11044692995770 := by decide
theorem cert_e2248599973562 : check e2248599973562 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973610 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2248599973610 : Closed e2248599973610 ∧ code e2248599973610 = 11044692995818 := by decide
theorem cert_e2248599973610 : check e2248599973610 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973718 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2248599973718 : Closed e2248599973718 ∧ code e2248599973718 = 11044692995926 := by decide
theorem cert_e2248599973718 : check e2248599973718 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973722 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2248599973722 : Closed e2248599973722 ∧ code e2248599973722 = 11044692995930 := by decide
theorem cert_e2248599973722 : check e2248599973722 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599973738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2248599973738 : Closed e2248599973738 ∧ code e2248599973738 = 11044692995946 := by decide
theorem cert_e2248599973738 : check e2248599973738 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599974766 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2248599974766 : Closed e2248599974766 ∧ code e2248599974766 = 11044692996974 := by decide
theorem cert_e2248599974766 : check e2248599974766 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599974774 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2248599974774 : Closed e2248599974774 ∧ code e2248599974774 = 11044692996982 := by decide
theorem cert_e2248599974774 : check e2248599974774 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599974830 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2248599974830 : Closed e2248599974830 ∧ code e2248599974830 = 11044692997038 := by decide
theorem cert_e2248599974830 : check e2248599974830 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599974842 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2248599974842 : Closed e2248599974842 ∧ code e2248599974842 = 11044692997050 := by decide
theorem cert_e2248599974842 : check e2248599974842 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599974870 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2248599974870 : Closed e2248599974870 ∧ code e2248599974870 = 11044692997078 := by decide
theorem cert_e2248599974870 : check e2248599974870 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599974874 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2248599974874 : Closed e2248599974874 ∧ code e2248599974874 = 11044692997082 := by decide
theorem cert_e2248599974874 : check e2248599974874 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599975150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2248599975150 : Closed e2248599975150 ∧ code e2248599975150 = 11044692997358 := by decide
theorem cert_e2248599975150 : check e2248599975150 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599975158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2248599975158 : Closed e2248599975158 ∧ code e2248599975158 = 11044692997366 := by decide
theorem cert_e2248599975158 : check e2248599975158 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599975534 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2248599975534 : Closed e2248599975534 ∧ code e2248599975534 = 11044692997742 := by decide
theorem cert_e2248599975534 : check e2248599975534 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599975546 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2248599975546 : Closed e2248599975546 ∧ code e2248599975546 = 11044692997754 := by decide
theorem cert_e2248599975546 : check e2248599975546 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599975734 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2248599975734 : Closed e2248599975734 ∧ code e2248599975734 = 11044692997942 := by decide
theorem cert_e2248599975734 : check e2248599975734 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599975738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2248599975738 : Closed e2248599975738 ∧ code e2248599975738 = 11044692997946 := by decide
theorem cert_e2248599975738 : check e2248599975738 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599976366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2248599976366 : Closed e2248599976366 ∧ code e2248599976366 = 11044692998574 := by decide
theorem cert_e2248599976366 : check e2248599976366 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599976378 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2248599976378 : Closed e2248599976378 ∧ code e2248599976378 = 11044692998586 := by decide
theorem cert_e2248599976378 : check e2248599976378 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599976426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2248599976426 : Closed e2248599976426 ∧ code e2248599976426 = 11044692998634 := by decide
theorem cert_e2248599976426 : check e2248599976426 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599976558 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2248599976558 : Closed e2248599976558 ∧ code e2248599976558 = 11044692998766 := by decide
theorem cert_e2248599976558 : check e2248599976558 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599976570 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2248599976570 : Closed e2248599976570 ∧ code e2248599976570 = 11044692998778 := by decide
theorem cert_e2248599976570 : check e2248599976570 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599976858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2248599976858 : Closed e2248599976858 ∧ code e2248599976858 = 11044692999066 := by decide
theorem cert_e2248599976858 : check e2248599976858 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599977174 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2248599977174 : Closed e2248599977174 ∧ code e2248599977174 = 11044692999382 := by decide
theorem cert_e2248599977174 : check e2248599977174 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599977178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2248599977178 : Closed e2248599977178 ∧ code e2248599977178 = 11044692999386 := by decide
theorem cert_e2248599977178 : check e2248599977178 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599977194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2248599977194 : Closed e2248599977194 ∧ code e2248599977194 = 11044692999402 := by decide
theorem cert_e2248599977194 : check e2248599977194 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599977270 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2248599977270 : Closed e2248599977270 ∧ code e2248599977270 = 11044692999478 := by decide
theorem cert_e2248599977270 : check e2248599977270 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599977274 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2248599977274 : Closed e2248599977274 ∧ code e2248599977274 = 11044692999482 := by decide
theorem cert_e2248599977274 : check e2248599977274 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599977370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2248599977370 : Closed e2248599977370 ∧ code e2248599977370 = 11044692999578 := by decide
theorem cert_e2248599977370 : check e2248599977370 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599980910 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2248599980910 : Closed e2248599980910 ∧ code e2248599980910 = 11044693003118 := by decide
theorem cert_e2248599980910 : check e2248599980910 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599980918 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2248599980918 : Closed e2248599980918 ∧ code e2248599980918 = 11044693003126 := by decide
theorem cert_e2248599980918 : check e2248599980918 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599980974 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2248599980974 : Closed e2248599980974 ∧ code e2248599980974 = 11044693003182 := by decide
theorem cert_e2248599980974 : check e2248599980974 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599980986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2248599980986 : Closed e2248599980986 ∧ code e2248599980986 = 11044693003194 := by decide
theorem cert_e2248599980986 : check e2248599980986 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981014 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2248599981014 : Closed e2248599981014 ∧ code e2248599981014 = 11044693003222 := by decide
theorem cert_e2248599981014 : check e2248599981014 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2248599981018 : Closed e2248599981018 ∧ code e2248599981018 = 11044693003226 := by decide
theorem cert_e2248599981018 : check e2248599981018 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981294 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2248599981294 : Closed e2248599981294 ∧ code e2248599981294 = 11044693003502 := by decide
theorem cert_e2248599981294 : check e2248599981294 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981302 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2248599981302 : Closed e2248599981302 ∧ code e2248599981302 = 11044693003510 := by decide
theorem cert_e2248599981302 : check e2248599981302 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2248599981678 : Closed e2248599981678 ∧ code e2248599981678 = 11044693003886 := by decide
theorem cert_e2248599981678 : check e2248599981678 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981690 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2248599981690 : Closed e2248599981690 ∧ code e2248599981690 = 11044693003898 := by decide
theorem cert_e2248599981690 : check e2248599981690 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981878 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2248599981878 : Closed e2248599981878 ∧ code e2248599981878 = 11044693004086 := by decide
theorem cert_e2248599981878 : check e2248599981878 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599981882 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2248599981882 : Closed e2248599981882 ∧ code e2248599981882 = 11044693004090 := by decide
theorem cert_e2248599981882 : check e2248599981882 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599987630 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2248599987630 : Closed e2248599987630 ∧ code e2248599987630 = 11044693009838 := by decide
theorem cert_e2248599987630 : check e2248599987630 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599987642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2248599987642 : Closed e2248599987642 ∧ code e2248599987642 = 11044693009850 := by decide
theorem cert_e2248599987642 : check e2248599987642 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599987690 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2248599987690 : Closed e2248599987690 ∧ code e2248599987690 = 11044693009898 := by decide
theorem cert_e2248599987690 : check e2248599987690 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599987822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2248599987822 : Closed e2248599987822 ∧ code e2248599987822 = 11044693010030 := by decide
theorem cert_e2248599987822 : check e2248599987822 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599987834 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2248599987834 : Closed e2248599987834 ∧ code e2248599987834 = 11044693010042 := by decide
theorem cert_e2248599987834 : check e2248599987834 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599988122 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2248599988122 : Closed e2248599988122 ∧ code e2248599988122 = 11044693010330 := by decide
theorem cert_e2248599988122 : check e2248599988122 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599990998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2248599990998 : Closed e2248599990998 ∧ code e2248599990998 = 11044693013206 := by decide
theorem cert_e2248599990998 : check e2248599990998 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599991002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2248599991002 : Closed e2248599991002 ∧ code e2248599991002 = 11044693013210 := by decide
theorem cert_e2248599991002 : check e2248599991002 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599991018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2248599991018 : Closed e2248599991018 ∧ code e2248599991018 = 11044693013226 := by decide
theorem cert_e2248599991018 : check e2248599991018 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599991094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2248599991094 : Closed e2248599991094 ∧ code e2248599991094 = 11044693013302 := by decide
theorem cert_e2248599991094 : check e2248599991094 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599991098 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2248599991098 : Closed e2248599991098 ∧ code e2248599991098 = 11044693013306 := by decide
theorem cert_e2248599991098 : check e2248599991098 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248599991194 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2248599991194 : Closed e2248599991194 ∧ code e2248599991194 = 11044693013402 := by decide
theorem cert_e2248599991194 : check e2248599991194 [[],[.under,.left],[.under]] .smaller = true := by decide
def e2248600128366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2248600128366 : Closed e2248600128366 ∧ code e2248600128366 = 11044693150574 := by decide
theorem cert_e2248600128366 : check e2248600128366 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600128374 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2248600128374 : Closed e2248600128374 ∧ code e2248600128374 = 11044693150582 := by decide
theorem cert_e2248600128374 : check e2248600128374 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600128430 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2248600128430 : Closed e2248600128430 ∧ code e2248600128430 = 11044693150638 := by decide
theorem cert_e2248600128430 : check e2248600128430 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600128442 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2248600128442 : Closed e2248600128442 ∧ code e2248600128442 = 11044693150650 := by decide
theorem cert_e2248600128442 : check e2248600128442 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600128470 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2248600128470 : Closed e2248600128470 ∧ code e2248600128470 = 11044693150678 := by decide
theorem cert_e2248600128470 : check e2248600128470 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600128474 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2248600128474 : Closed e2248600128474 ∧ code e2248600128474 = 11044693150682 := by decide
theorem cert_e2248600128474 : check e2248600128474 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600128750 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2248600128750 : Closed e2248600128750 ∧ code e2248600128750 = 11044693150958 := by decide
theorem cert_e2248600128750 : check e2248600128750 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600128758 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2248600128758 : Closed e2248600128758 ∧ code e2248600128758 = 11044693150966 := by decide
theorem cert_e2248600128758 : check e2248600128758 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600129134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2248600129134 : Closed e2248600129134 ∧ code e2248600129134 = 11044693151342 := by decide
theorem cert_e2248600129134 : check e2248600129134 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600129146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2248600129146 : Closed e2248600129146 ∧ code e2248600129146 = 11044693151354 := by decide
theorem cert_e2248600129146 : check e2248600129146 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600129334 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2248600129334 : Closed e2248600129334 ∧ code e2248600129334 = 11044693151542 := by decide
theorem cert_e2248600129334 : check e2248600129334 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600129338 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2248600129338 : Closed e2248600129338 ∧ code e2248600129338 = 11044693151546 := by decide
theorem cert_e2248600129338 : check e2248600129338 [[],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2248600718190 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2248600718190 : Closed e2248600718190 ∧ code e2248600718190 = 11044693740398 := by decide
theorem cert_e2248600718190 : check e2248600718190 [[],[.under,.left]] .chain = true := by decide
def e2248600718198 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2248600718198 : Closed e2248600718198 ∧ code e2248600718198 = 11044693740406 := by decide
theorem cert_e2248600718198 : check e2248600718198 [[],[.under,.left]] .chain = true := by decide
def e2248600718254 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2248600718254 : Closed e2248600718254 ∧ code e2248600718254 = 11044693740462 := by decide
theorem cert_e2248600718254 : check e2248600718254 [[],[.under,.left]] .chain = true := by decide
def e2248600718266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2248600718266 : Closed e2248600718266 ∧ code e2248600718266 = 11044693740474 := by decide
theorem cert_e2248600718266 : check e2248600718266 [[],[.under,.left]] .chain = true := by decide
def e2248600718294 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2248600718294 : Closed e2248600718294 ∧ code e2248600718294 = 11044693740502 := by decide
theorem cert_e2248600718294 : check e2248600718294 [[],[.under,.left]] .chain = true := by decide
def e2248600718298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2248600718298 : Closed e2248600718298 ∧ code e2248600718298 = 11044693740506 := by decide
theorem cert_e2248600718298 : check e2248600718298 [[],[.under,.left]] .chain = true := by decide
def e2248600718574 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2248600718574 : Closed e2248600718574 ∧ code e2248600718574 = 11044693740782 := by decide
theorem cert_e2248600718574 : check e2248600718574 [[],[.under,.left]] .chain = true := by decide
def e2248600718582 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2248600718582 : Closed e2248600718582 ∧ code e2248600718582 = 11044693740790 := by decide
theorem cert_e2248600718582 : check e2248600718582 [[],[.under,.left]] .chain = true := by decide
def e2248600718958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2248600718958 : Closed e2248600718958 ∧ code e2248600718958 = 11044693741166 := by decide
theorem cert_e2248600718958 : check e2248600718958 [[],[.under,.left]] .chain = true := by decide
def e2248600718970 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2248600718970 : Closed e2248600718970 ∧ code e2248600718970 = 11044693741178 := by decide
theorem cert_e2248600718970 : check e2248600718970 [[],[.under,.left]] .chain = true := by decide
def e2248600719158 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2248600719158 : Closed e2248600719158 ∧ code e2248600719158 = 11044693741366 := by decide
theorem cert_e2248600719158 : check e2248600719158 [[],[.under,.left]] .chain = true := by decide
def e2248600719162 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2248600719162 : Closed e2248600719162 ∧ code e2248600719162 = 11044693741370 := by decide
theorem cert_e2248600719162 : check e2248600719162 [[],[.under,.left]] .chain = true := by decide
def e2248824026650 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824026650 : Closed e2248824026650 ∧ code e2248824026650 = 11044917048858 := by decide
theorem cert_e2248824026650 : check e2248824026650 [[]] .width = true := by decide
def e2248824043034 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824043034 : Closed e2248824043034 ∧ code e2248824043034 = 11044917065242 := by decide
theorem cert_e2248824043034 : check e2248824043034 [[]] .width = true := by decide
def e2248824157722 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824157722 : Closed e2248824157722 ∧ code e2248824157722 = 11044917179930 := by decide
theorem cert_e2248824157722 : check e2248824157722 [[]] .width = true := by decide
def e2248824182298 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824182298 : Closed e2248824182298 ∧ code e2248824182298 = 11044917204506 := by decide
theorem cert_e2248824182298 : check e2248824182298 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2248542696986
