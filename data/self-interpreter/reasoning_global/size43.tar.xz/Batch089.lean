import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e827000302810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e827000302810 : Closed e827000302810 ∧ code e827000302810 = 9623093325018 := by decide
theorem cert_e827000302810 : check e827000302810 [] .sourceHead = true := by decide
def e827000302826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e827000302826 : Closed e827000302826 ∧ code e827000302826 = 9623093325034 := by decide
theorem cert_e827000302826 : check e827000302826 [] .sourceHead = true := by decide
def e827000302902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e827000302902 : Closed e827000302902 ∧ code e827000302902 = 9623093325110 := by decide
theorem cert_e827000302902 : check e827000302902 [] .sourceHead = true := by decide
def e827000302906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e827000302906 : Closed e827000302906 ∧ code e827000302906 = 9623093325114 := by decide
theorem cert_e827000302906 : check e827000302906 [] .sourceHead = true := by decide
def e827000303002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000303002 : Closed e827000303002 ∧ code e827000303002 = 9623093325210 := by decide
theorem cert_e827000303002 : check e827000303002 [] .sourceHead = true := by decide
def e827000303210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e827000303210 : Closed e827000303210 ∧ code e827000303210 = 9623093325418 := by decide
theorem cert_e827000303210 : check e827000303210 [] .sourceHead = true := by decide
def e827000303258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827000303258 : Closed e827000303258 ∧ code e827000303258 = 9623093325466 := by decide
theorem cert_e827000303258 : check e827000303258 [] .sourceHead = true := by decide
def e827000303854 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e827000303854 : Closed e827000303854 ∧ code e827000303854 = 9623093326062 := by decide
theorem cert_e827000303854 : check e827000303854 [] .sourceHead = true := by decide
def e827000303862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e827000303862 : Closed e827000303862 ∧ code e827000303862 = 9623093326070 := by decide
theorem cert_e827000303862 : check e827000303862 [] .sourceHead = true := by decide
def e827000304342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e827000304342 : Closed e827000304342 ∧ code e827000304342 = 9623093326550 := by decide
theorem cert_e827000304342 : check e827000304342 [] .sourceHead = true := by decide
def e827000304346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e827000304346 : Closed e827000304346 ∧ code e827000304346 = 9623093326554 := by decide
theorem cert_e827000304346 : check e827000304346 [] .sourceHead = true := by decide
def e827000304362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e827000304362 : Closed e827000304362 ∧ code e827000304362 = 9623093326570 := by decide
theorem cert_e827000304362 : check e827000304362 [] .sourceHead = true := by decide
def e827000304438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e827000304438 : Closed e827000304438 ∧ code e827000304438 = 9623093326646 := by decide
theorem cert_e827000304438 : check e827000304438 [] .sourceHead = true := by decide
def e827000304442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e827000304442 : Closed e827000304442 ∧ code e827000304442 = 9623093326650 := by decide
theorem cert_e827000304442 : check e827000304442 [] .sourceHead = true := by decide
def e827000304538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827000304538 : Closed e827000304538 ∧ code e827000304538 = 9623093326746 := by decide
theorem cert_e827000304538 : check e827000304538 [] .sourceHead = true := by decide
def e827000305782 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e827000305782 : Closed e827000305782 ∧ code e827000305782 = 9623093327990 := by decide
theorem cert_e827000305782 : check e827000305782 [] .sourceHead = true := by decide
def e827000306026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e827000306026 : Closed e827000306026 ∧ code e827000306026 = 9623093328234 := by decide
theorem cert_e827000306026 : check e827000306026 [] .sourceHead = true := by decide
def e827000306074 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827000306074 : Closed e827000306074 ∧ code e827000306074 = 9623093328282 := by decide
theorem cert_e827000306074 : check e827000306074 [] .sourceHead = true := by decide
def e827002498414 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e827002498414 : Closed e827002498414 ∧ code e827002498414 = 9623095520622 := by decide
theorem cert_e827002498414 : check e827002498414 [] .sourceHead = true := by decide
def e827002498422 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e827002498422 : Closed e827002498422 ∧ code e827002498422 = 9623095520630 := by decide
theorem cert_e827002498422 : check e827002498422 [] .sourceHead = true := by decide
def e827002498478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e827002498478 : Closed e827002498478 ∧ code e827002498478 = 9623095520686 := by decide
theorem cert_e827002498478 : check e827002498478 [] .sourceHead = true := by decide
def e827002498490 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e827002498490 : Closed e827002498490 ∧ code e827002498490 = 9623095520698 := by decide
theorem cert_e827002498490 : check e827002498490 [] .sourceHead = true := by decide
def e827002498518 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e827002498518 : Closed e827002498518 ∧ code e827002498518 = 9623095520726 := by decide
theorem cert_e827002498518 : check e827002498518 [] .sourceHead = true := by decide
def e827002498522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e827002498522 : Closed e827002498522 ∧ code e827002498522 = 9623095520730 := by decide
theorem cert_e827002498522 : check e827002498522 [] .sourceHead = true := by decide
def e827002498734 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e827002498734 : Closed e827002498734 ∧ code e827002498734 = 9623095520942 := by decide
theorem cert_e827002498734 : check e827002498734 [] .sourceHead = true := by decide
def e827002498746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e827002498746 : Closed e827002498746 ∧ code e827002498746 = 9623095520954 := by decide
theorem cert_e827002498746 : check e827002498746 [] .sourceHead = true := by decide
def e827002498794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e827002498794 : Closed e827002498794 ∧ code e827002498794 = 9623095521002 := by decide
theorem cert_e827002498794 : check e827002498794 [] .sourceHead = true := by decide
def e827002498902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e827002498902 : Closed e827002498902 ∧ code e827002498902 = 9623095521110 := by decide
theorem cert_e827002498902 : check e827002498902 [] .sourceHead = true := by decide
def e827002498906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e827002498906 : Closed e827002498906 ∧ code e827002498906 = 9623095521114 := by decide
theorem cert_e827002498906 : check e827002498906 [] .sourceHead = true := by decide
def e827002498922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e827002498922 : Closed e827002498922 ∧ code e827002498922 = 9623095521130 := by decide
theorem cert_e827002498922 : check e827002498922 [] .sourceHead = true := by decide
def e827002499950 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e827002499950 : Closed e827002499950 ∧ code e827002499950 = 9623095522158 := by decide
theorem cert_e827002499950 : check e827002499950 [] .sourceHead = true := by decide
def e827002499958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e827002499958 : Closed e827002499958 ∧ code e827002499958 = 9623095522166 := by decide
theorem cert_e827002499958 : check e827002499958 [] .sourceHead = true := by decide
def e827002500014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e827002500014 : Closed e827002500014 ∧ code e827002500014 = 9623095522222 := by decide
theorem cert_e827002500014 : check e827002500014 [] .sourceHead = true := by decide
def e827002500026 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e827002500026 : Closed e827002500026 ∧ code e827002500026 = 9623095522234 := by decide
theorem cert_e827002500026 : check e827002500026 [] .sourceHead = true := by decide
def e827002500054 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e827002500054 : Closed e827002500054 ∧ code e827002500054 = 9623095522262 := by decide
theorem cert_e827002500054 : check e827002500054 [] .sourceHead = true := by decide
def e827002500058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e827002500058 : Closed e827002500058 ∧ code e827002500058 = 9623095522266 := by decide
theorem cert_e827002500058 : check e827002500058 [] .sourceHead = true := by decide
def e827002500334 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e827002500334 : Closed e827002500334 ∧ code e827002500334 = 9623095522542 := by decide
theorem cert_e827002500334 : check e827002500334 [] .sourceHead = true := by decide
def e827002500342 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e827002500342 : Closed e827002500342 ∧ code e827002500342 = 9623095522550 := by decide
theorem cert_e827002500342 : check e827002500342 [] .sourceHead = true := by decide
def e827002500718 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e827002500718 : Closed e827002500718 ∧ code e827002500718 = 9623095522926 := by decide
theorem cert_e827002500718 : check e827002500718 [] .sourceHead = true := by decide
def e827002500730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e827002500730 : Closed e827002500730 ∧ code e827002500730 = 9623095522938 := by decide
theorem cert_e827002500730 : check e827002500730 [] .sourceHead = true := by decide
def e827002500918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e827002500918 : Closed e827002500918 ∧ code e827002500918 = 9623095523126 := by decide
theorem cert_e827002500918 : check e827002500918 [] .sourceHead = true := by decide
def e827002500922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e827002500922 : Closed e827002500922 ∧ code e827002500922 = 9623095523130 := by decide
theorem cert_e827002500922 : check e827002500922 [] .sourceHead = true := by decide
def e827002501550 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e827002501550 : Closed e827002501550 ∧ code e827002501550 = 9623095523758 := by decide
theorem cert_e827002501550 : check e827002501550 [] .sourceHead = true := by decide
def e827002501562 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e827002501562 : Closed e827002501562 ∧ code e827002501562 = 9623095523770 := by decide
theorem cert_e827002501562 : check e827002501562 [] .sourceHead = true := by decide
def e827002501610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e827002501610 : Closed e827002501610 ∧ code e827002501610 = 9623095523818 := by decide
theorem cert_e827002501610 : check e827002501610 [] .sourceHead = true := by decide
def e827002501742 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e827002501742 : Closed e827002501742 ∧ code e827002501742 = 9623095523950 := by decide
theorem cert_e827002501742 : check e827002501742 [] .sourceHead = true := by decide
def e827002501754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e827002501754 : Closed e827002501754 ∧ code e827002501754 = 9623095523962 := by decide
theorem cert_e827002501754 : check e827002501754 [] .sourceHead = true := by decide
def e827002502042 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827002502042 : Closed e827002502042 ∧ code e827002502042 = 9623095524250 := by decide
theorem cert_e827002502042 : check e827002502042 [] .sourceHead = true := by decide
def e827002502358 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e827002502358 : Closed e827002502358 ∧ code e827002502358 = 9623095524566 := by decide
theorem cert_e827002502358 : check e827002502358 [] .sourceHead = true := by decide
def e827002502362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e827002502362 : Closed e827002502362 ∧ code e827002502362 = 9623095524570 := by decide
theorem cert_e827002502362 : check e827002502362 [] .sourceHead = true := by decide
def e827002502378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e827002502378 : Closed e827002502378 ∧ code e827002502378 = 9623095524586 := by decide
theorem cert_e827002502378 : check e827002502378 [] .sourceHead = true := by decide
def e827002502454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e827002502454 : Closed e827002502454 ∧ code e827002502454 = 9623095524662 := by decide
theorem cert_e827002502454 : check e827002502454 [] .sourceHead = true := by decide
def e827002502458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e827002502458 : Closed e827002502458 ∧ code e827002502458 = 9623095524666 := by decide
theorem cert_e827002502458 : check e827002502458 [] .sourceHead = true := by decide
def e827002502554 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e827002502554 : Closed e827002502554 ∧ code e827002502554 = 9623095524762 := by decide
theorem cert_e827002502554 : check e827002502554 [] .sourceHead = true := by decide
def e827002506094 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e827002506094 : Closed e827002506094 ∧ code e827002506094 = 9623095528302 := by decide
theorem cert_e827002506094 : check e827002506094 [] .sourceHead = true := by decide
def e827002506102 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e827002506102 : Closed e827002506102 ∧ code e827002506102 = 9623095528310 := by decide
theorem cert_e827002506102 : check e827002506102 [] .sourceHead = true := by decide
def e827002506158 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e827002506158 : Closed e827002506158 ∧ code e827002506158 = 9623095528366 := by decide
theorem cert_e827002506158 : check e827002506158 [] .sourceHead = true := by decide
def e827002506170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e827002506170 : Closed e827002506170 ∧ code e827002506170 = 9623095528378 := by decide
theorem cert_e827002506170 : check e827002506170 [] .sourceHead = true := by decide
def e827002506198 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e827002506198 : Closed e827002506198 ∧ code e827002506198 = 9623095528406 := by decide
theorem cert_e827002506198 : check e827002506198 [] .sourceHead = true := by decide
def e827002506202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e827002506202 : Closed e827002506202 ∧ code e827002506202 = 9623095528410 := by decide
theorem cert_e827002506202 : check e827002506202 [] .sourceHead = true := by decide
def e827002506478 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e827002506478 : Closed e827002506478 ∧ code e827002506478 = 9623095528686 := by decide
theorem cert_e827002506478 : check e827002506478 [] .sourceHead = true := by decide
def e827002506486 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e827002506486 : Closed e827002506486 ∧ code e827002506486 = 9623095528694 := by decide
theorem cert_e827002506486 : check e827002506486 [] .sourceHead = true := by decide
def e827002506862 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e827002506862 : Closed e827002506862 ∧ code e827002506862 = 9623095529070 := by decide
theorem cert_e827002506862 : check e827002506862 [] .sourceHead = true := by decide
def e827002506874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e827002506874 : Closed e827002506874 ∧ code e827002506874 = 9623095529082 := by decide
theorem cert_e827002506874 : check e827002506874 [] .sourceHead = true := by decide
def e827002507062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e827002507062 : Closed e827002507062 ∧ code e827002507062 = 9623095529270 := by decide
theorem cert_e827002507062 : check e827002507062 [] .sourceHead = true := by decide
def e827002507066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e827002507066 : Closed e827002507066 ∧ code e827002507066 = 9623095529274 := by decide
theorem cert_e827002507066 : check e827002507066 [] .sourceHead = true := by decide
def e827002512814 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e827002512814 : Closed e827002512814 ∧ code e827002512814 = 9623095535022 := by decide
theorem cert_e827002512814 : check e827002512814 [] .sourceHead = true := by decide
def e827002512826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e827002512826 : Closed e827002512826 ∧ code e827002512826 = 9623095535034 := by decide
theorem cert_e827002512826 : check e827002512826 [] .sourceHead = true := by decide
def e827002512874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e827002512874 : Closed e827002512874 ∧ code e827002512874 = 9623095535082 := by decide
theorem cert_e827002512874 : check e827002512874 [] .sourceHead = true := by decide
def e827002513006 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e827002513006 : Closed e827002513006 ∧ code e827002513006 = 9623095535214 := by decide
theorem cert_e827002513006 : check e827002513006 [] .sourceHead = true := by decide
def e827002513018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e827002513018 : Closed e827002513018 ∧ code e827002513018 = 9623095535226 := by decide
theorem cert_e827002513018 : check e827002513018 [] .sourceHead = true := by decide
def e827002513306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827002513306 : Closed e827002513306 ∧ code e827002513306 = 9623095535514 := by decide
theorem cert_e827002513306 : check e827002513306 [] .sourceHead = true := by decide
def e827002516182 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e827002516182 : Closed e827002516182 ∧ code e827002516182 = 9623095538390 := by decide
theorem cert_e827002516182 : check e827002516182 [] .sourceHead = true := by decide
def e827002516186 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e827002516186 : Closed e827002516186 ∧ code e827002516186 = 9623095538394 := by decide
theorem cert_e827002516186 : check e827002516186 [] .sourceHead = true := by decide
def e827002516202 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e827002516202 : Closed e827002516202 ∧ code e827002516202 = 9623095538410 := by decide
theorem cert_e827002516202 : check e827002516202 [] .sourceHead = true := by decide
def e827002516278 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e827002516278 : Closed e827002516278 ∧ code e827002516278 = 9623095538486 := by decide
theorem cert_e827002516278 : check e827002516278 [] .sourceHead = true := by decide
def e827002516282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e827002516282 : Closed e827002516282 ∧ code e827002516282 = 9623095538490 := by decide
theorem cert_e827002516282 : check e827002516282 [] .sourceHead = true := by decide
def e827002516378 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e827002516378 : Closed e827002516378 ∧ code e827002516378 = 9623095538586 := by decide
theorem cert_e827002516378 : check e827002516378 [] .sourceHead = true := by decide
def e827021766170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827021766170 : Closed e827021766170 ∧ code e827021766170 = 9623114788378 := by decide
theorem cert_e827021766170 : check e827021766170 [] .sourceHead = true := by decide
def e827021769242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827021769242 : Closed e827021769242 ∧ code e827021769242 = 9623114791450 := by decide
theorem cert_e827021769242 : check e827021769242 [] .sourceHead = true := by decide
def e827021781530 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827021781530 : Closed e827021781530 ∧ code e827021781530 = 9623114803738 := by decide
theorem cert_e827021781530 : check e827021781530 [] .sourceHead = true := by decide
def e827021830682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827021830682 : Closed e827021830682 ∧ code e827021830682 = 9623114852890 := by decide
theorem cert_e827021830682 : check e827021830682 [] .sourceHead = true := by decide
def e827021962778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827021962778 : Closed e827021962778 ∧ code e827021962778 = 9623114984986 := by decide
theorem cert_e827021962778 : check e827021962778 [] .sourceHead = true := by decide
def e827021965850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827021965850 : Closed e827021965850 ∧ code e827021965850 = 9623114988058 := by decide
theorem cert_e827021965850 : check e827021965850 [] .sourceHead = true := by decide
def e827021978138 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827021978138 : Closed e827021978138 ∧ code e827021978138 = 9623115000346 := by decide
theorem cert_e827021978138 : check e827021978138 [] .sourceHead = true := by decide
def e827022011930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022011930 : Closed e827022011930 ∧ code e827022011930 = 9623115034138 := by decide
theorem cert_e827022011930 : check e827022011930 [] .sourceHead = true := by decide
def e827022015002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022015002 : Closed e827022015002 ∧ code e827022015002 = 9623115037210 := by decide
theorem cert_e827022015002 : check e827022015002 [] .sourceHead = true := by decide
def e827022041114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827022041114 : Closed e827022041114 ∧ code e827022041114 = 9623115063322 := by decide
theorem cert_e827022041114 : check e827022041114 [] .sourceHead = true := by decide
def e827022041206 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827022041206 : Closed e827022041206 ∧ code e827022041206 = 9623115063414 := by decide
theorem cert_e827022041206 : check e827022041206 [] .sourceHead = true := by decide
def e827022041450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827022041450 : Closed e827022041450 ∧ code e827022041450 = 9623115063658 := by decide
theorem cert_e827022041450 : check e827022041450 [] .sourceHead = true := by decide
def e827022041498 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827022041498 : Closed e827022041498 ∧ code e827022041498 = 9623115063706 := by decide
theorem cert_e827022041498 : check e827022041498 [] .sourceHead = true := by decide
def e827022042650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827022042650 : Closed e827022042650 ∧ code e827022042650 = 9623115064858 := by decide
theorem cert_e827022042650 : check e827022042650 [] .sourceHead = true := by decide
def e827022088730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022088730 : Closed e827022088730 ∧ code e827022088730 = 9623115110938 := by decide
theorem cert_e827022088730 : check e827022088730 [] .sourceHead = true := by decide
def e827022090266 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827022090266 : Closed e827022090266 ∧ code e827022090266 = 9623115112474 := by decide
theorem cert_e827022090266 : check e827022090266 [] .sourceHead = true := by decide
def e827022090358 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827022090358 : Closed e827022090358 ∧ code e827022090358 = 9623115112566 := by decide
theorem cert_e827022090358 : check e827022090358 [] .sourceHead = true := by decide
def e827022090602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827022090602 : Closed e827022090602 ∧ code e827022090602 = 9623115112810 := by decide
theorem cert_e827022090602 : check e827022090602 [] .sourceHead = true := by decide
def e827022090650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827022090650 : Closed e827022090650 ∧ code e827022090650 = 9623115112858 := by decide
theorem cert_e827022090650 : check e827022090650 [] .sourceHead = true := by decide
def e827022091802 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827022091802 : Closed e827022091802 ∧ code e827022091802 = 9623115114010 := by decide
theorem cert_e827022091802 : check e827022091802 [] .sourceHead = true := by decide
def e827022273050 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022273050 : Closed e827022273050 ∧ code e827022273050 = 9623115295258 := by decide
theorem cert_e827022273050 : check e827022273050 [] .sourceHead = true := by decide
def e827022285338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022285338 : Closed e827022285338 ∧ code e827022285338 = 9623115307546 := by decide
theorem cert_e827022285338 : check e827022285338 [] .sourceHead = true := by decide
def e827022286874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827022286874 : Closed e827022286874 ∧ code e827022286874 = 9623115309082 := by decide
theorem cert_e827022286874 : check e827022286874 [] .sourceHead = true := by decide
def e827022286966 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827022286966 : Closed e827022286966 ∧ code e827022286966 = 9623115309174 := by decide
theorem cert_e827022286966 : check e827022286966 [] .sourceHead = true := by decide
def e827022287210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827022287210 : Closed e827022287210 ∧ code e827022287210 = 9623115309418 := by decide
theorem cert_e827022287210 : check e827022287210 [] .sourceHead = true := by decide
def e827022287258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827022287258 : Closed e827022287258 ∧ code e827022287258 = 9623115309466 := by decide
theorem cert_e827022287258 : check e827022287258 [] .sourceHead = true := by decide
def e827022288410 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827022288410 : Closed e827022288410 ∧ code e827022288410 = 9623115310618 := by decide
theorem cert_e827022288410 : check e827022288410 [] .sourceHead = true := by decide
def e827022749210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022749210 : Closed e827022749210 ∧ code e827022749210 = 9623115771418 := by decide
theorem cert_e827022749210 : check e827022749210 [] .sourceHead = true := by decide
def e827022752282 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022752282 : Closed e827022752282 ∧ code e827022752282 = 9623115774490 := by decide
theorem cert_e827022752282 : check e827022752282 [] .sourceHead = true := by decide
def e827022764570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022764570 : Closed e827022764570 ∧ code e827022764570 = 9623115786778 := by decide
theorem cert_e827022764570 : check e827022764570 [] .sourceHead = true := by decide
def e827022798362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022798362 : Closed e827022798362 ∧ code e827022798362 = 9623115820570 := by decide
theorem cert_e827022798362 : check e827022798362 [] .sourceHead = true := by decide
def e827022801434 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022801434 : Closed e827022801434 ∧ code e827022801434 = 9623115823642 := by decide
theorem cert_e827022801434 : check e827022801434 [] .sourceHead = true := by decide
def e827022827546 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827022827546 : Closed e827022827546 ∧ code e827022827546 = 9623115849754 := by decide
theorem cert_e827022827546 : check e827022827546 [] .sourceHead = true := by decide
def e827022827638 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827022827638 : Closed e827022827638 ∧ code e827022827638 = 9623115849846 := by decide
theorem cert_e827022827638 : check e827022827638 [] .sourceHead = true := by decide
def e827022827882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827022827882 : Closed e827022827882 ∧ code e827022827882 = 9623115850090 := by decide
theorem cert_e827022827882 : check e827022827882 [] .sourceHead = true := by decide
def e827022827930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827022827930 : Closed e827022827930 ∧ code e827022827930 = 9623115850138 := by decide
theorem cert_e827022827930 : check e827022827930 [] .sourceHead = true := by decide
def e827022829082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827022829082 : Closed e827022829082 ∧ code e827022829082 = 9623115851290 := by decide
theorem cert_e827022829082 : check e827022829082 [] .sourceHead = true := by decide
def e827022875162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827022875162 : Closed e827022875162 ∧ code e827022875162 = 9623115897370 := by decide
theorem cert_e827022875162 : check e827022875162 [] .sourceHead = true := by decide
def e827022876698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827022876698 : Closed e827022876698 ∧ code e827022876698 = 9623115898906 := by decide
theorem cert_e827022876698 : check e827022876698 [] .sourceHead = true := by decide
def e827022876790 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827022876790 : Closed e827022876790 ∧ code e827022876790 = 9623115898998 := by decide
theorem cert_e827022876790 : check e827022876790 [] .sourceHead = true := by decide
def e827022877034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827022877034 : Closed e827022877034 ∧ code e827022877034 = 9623115899242 := by decide
theorem cert_e827022877034 : check e827022877034 [] .sourceHead = true := by decide
def e827022877082 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827022877082 : Closed e827022877082 ∧ code e827022877082 = 9623115899290 := by decide
theorem cert_e827022877082 : check e827022877082 [] .sourceHead = true := by decide
def e827022878234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827022878234 : Closed e827022878234 ∧ code e827022878234 = 9623115900442 := by decide
theorem cert_e827022878234 : check e827022878234 [] .sourceHead = true := by decide
def e827024042522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827024042522 : Closed e827024042522 ∧ code e827024042522 = 9623117064730 := by decide
theorem cert_e827024042522 : check e827024042522 [] .sourceHead = true := by decide
def e827024054810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827024054810 : Closed e827024054810 ∧ code e827024054810 = 9623117077018 := by decide
theorem cert_e827024054810 : check e827024054810 [] .sourceHead = true := by decide
def e827024056346 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827024056346 : Closed e827024056346 ∧ code e827024056346 = 9623117078554 := by decide
theorem cert_e827024056346 : check e827024056346 [] .sourceHead = true := by decide
def e827024056438 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827024056438 : Closed e827024056438 ∧ code e827024056438 = 9623117078646 := by decide
theorem cert_e827024056438 : check e827024056438 [] .sourceHead = true := by decide
def e827024056682 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827024056682 : Closed e827024056682 ∧ code e827024056682 = 9623117078890 := by decide
theorem cert_e827024056682 : check e827024056682 [] .sourceHead = true := by decide
def e827024056730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827024056730 : Closed e827024056730 ∧ code e827024056730 = 9623117078938 := by decide
theorem cert_e827024056730 : check e827024056730 [] .sourceHead = true := by decide
def e827024057882 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827024057882 : Closed e827024057882 ∧ code e827024057882 = 9623117080090 := by decide
theorem cert_e827024057882 : check e827024057882 [] .sourceHead = true := by decide
def e827035702810 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035702810 : Closed e827035702810 ∧ code e827035702810 = 9623128725018 := by decide
theorem cert_e827035702810 : check e827035702810 [] .sourceHead = true := by decide
def e827035703834 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035703834 : Closed e827035703834 ∧ code e827035703834 = 9623128726042 := by decide
theorem cert_e827035703834 : check e827035703834 [] .sourceHead = true := by decide
def e827035707930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035707930 : Closed e827035707930 ∧ code e827035707930 = 9623128730138 := by decide
theorem cert_e827035707930 : check e827035707930 [] .sourceHead = true := by decide
def e827035724314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035724314 : Closed e827035724314 ∧ code e827035724314 = 9623128746522 := by decide
theorem cert_e827035724314 : check e827035724314 [] .sourceHead = true := by decide
def e827035801114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035801114 : Closed e827035801114 ∧ code e827035801114 = 9623128823322 := by decide
theorem cert_e827035801114 : check e827035801114 [] .sourceHead = true := by decide
def e827035802138 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035802138 : Closed e827035802138 ∧ code e827035802138 = 9623128824346 := by decide
theorem cert_e827035802138 : check e827035802138 [] .sourceHead = true := by decide
def e827035806234 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035806234 : Closed e827035806234 ∧ code e827035806234 = 9623128828442 := by decide
theorem cert_e827035806234 : check e827035806234 [] .sourceHead = true := by decide
def e827035825690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035825690 : Closed e827035825690 ∧ code e827035825690 = 9623128847898 := by decide
theorem cert_e827035825690 : check e827035825690 [] .sourceHead = true := by decide
def e827035826714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035826714 : Closed e827035826714 ∧ code e827035826714 = 9623128848922 := by decide
theorem cert_e827035826714 : check e827035826714 [] .sourceHead = true := by decide
def e827035836442 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827035836442 : Closed e827035836442 ∧ code e827035836442 = 9623128858650 := by decide
theorem cert_e827035836442 : check e827035836442 [] .sourceHead = true := by decide
def e827035836534 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827035836534 : Closed e827035836534 ∧ code e827035836534 = 9623128858742 := by decide
theorem cert_e827035836534 : check e827035836534 [] .sourceHead = true := by decide
def e827035836778 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827035836778 : Closed e827035836778 ∧ code e827035836778 = 9623128858986 := by decide
theorem cert_e827035836778 : check e827035836778 [] .sourceHead = true := by decide
def e827035836826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827035836826 : Closed e827035836826 ∧ code e827035836826 = 9623128859034 := by decide
theorem cert_e827035836826 : check e827035836826 [] .sourceHead = true := by decide
def e827035837978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827035837978 : Closed e827035837978 ∧ code e827035837978 = 9623128860186 := by decide
theorem cert_e827035837978 : check e827035837978 [] .sourceHead = true := by decide
def e827035851290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035851290 : Closed e827035851290 ∧ code e827035851290 = 9623128873498 := by decide
theorem cert_e827035851290 : check e827035851290 [] .sourceHead = true := by decide
def e827035852826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827035852826 : Closed e827035852826 ∧ code e827035852826 = 9623128875034 := by decide
theorem cert_e827035852826 : check e827035852826 [] .sourceHead = true := by decide
def e827035852918 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827035852918 : Closed e827035852918 ∧ code e827035852918 = 9623128875126 := by decide
theorem cert_e827035852918 : check e827035852918 [] .sourceHead = true := by decide
def e827035853162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827035853162 : Closed e827035853162 ∧ code e827035853162 = 9623128875370 := by decide
theorem cert_e827035853162 : check e827035853162 [] .sourceHead = true := by decide
def e827035853210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827035853210 : Closed e827035853210 ∧ code e827035853210 = 9623128875418 := by decide
theorem cert_e827035853210 : check e827035853210 [] .sourceHead = true := by decide
def e827035854362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827035854362 : Closed e827035854362 ∧ code e827035854362 = 9623128876570 := by decide
theorem cert_e827035854362 : check e827035854362 [] .sourceHead = true := by decide
def e827035904538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035904538 : Closed e827035904538 ∧ code e827035904538 = 9623128926746 := by decide
theorem cert_e827035904538 : check e827035904538 [] .sourceHead = true := by decide
def e827035916826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827035916826 : Closed e827035916826 ∧ code e827035916826 = 9623128939034 := by decide
theorem cert_e827035916826 : check e827035916826 [] .sourceHead = true := by decide
def e827035918362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e827035918362 : Closed e827035918362 ∧ code e827035918362 = 9623128940570 := by decide
theorem cert_e827035918362 : check e827035918362 [] .sourceHead = true := by decide
def e827035918454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e827035918454 : Closed e827035918454 ∧ code e827035918454 = 9623128940662 := by decide
theorem cert_e827035918454 : check e827035918454 [] .sourceHead = true := by decide
def e827035918698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e827035918698 : Closed e827035918698 ∧ code e827035918698 = 9623128940906 := by decide
theorem cert_e827035918698 : check e827035918698 [] .sourceHead = true := by decide
def e827035918746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e827035918746 : Closed e827035918746 ∧ code e827035918746 = 9623128940954 := by decide
theorem cert_e827035918746 : check e827035918746 [] .sourceHead = true := by decide
def e827035919898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e827035919898 : Closed e827035919898 ∧ code e827035919898 = 9623128942106 := by decide
theorem cert_e827035919898 : check e827035919898 [] .sourceHead = true := by decide
def e827036194330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036194330 : Closed e827036194330 ∧ code e827036194330 = 9623129216538 := by decide
theorem cert_e827036194330 : check e827036194330 [] .sourceHead = true := by decide
def e827036195354 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036195354 : Closed e827036195354 ∧ code e827036195354 = 9623129217562 := by decide
theorem cert_e827036195354 : check e827036195354 [] .sourceHead = true := by decide
def e827036199450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036199450 : Closed e827036199450 ∧ code e827036199450 = 9623129221658 := by decide
theorem cert_e827036199450 : check e827036199450 [] .sourceHead = true := by decide
def e827036218906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036218906 : Closed e827036218906 ∧ code e827036218906 = 9623129241114 := by decide
theorem cert_e827036218906 : check e827036218906 [] .sourceHead = true := by decide
def e827036219930 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e827036219930 : Closed e827036219930 ∧ code e827036219930 = 9623129242138 := by decide
theorem cert_e827036219930 : check e827036219930 [] .sourceHead = true := by decide
end Blc.Floor43
