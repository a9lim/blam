import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2210556207514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210556207514 : Closed e2210556207514 ∧ code e2210556207514 = 11006649229722 := by decide
theorem cert_e2210556207514 : check e2210556207514 [[]] .width = true := by decide
def e2210556256282 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210556256282 : Closed e2210556256282 ∧ code e2210556256282 = 11006649278490 := by decide
theorem cert_e2210556256282 : check e2210556256282 [[]] .width = true := by decide
def e2210556256374 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210556256374 : Closed e2210556256374 ∧ code e2210556256374 = 11006649278582 := by decide
theorem cert_e2210556256374 : check e2210556256374 [[]] .width = true := by decide
def e2210556256618 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210556256618 : Closed e2210556256618 ∧ code e2210556256618 = 11006649278826 := by decide
theorem cert_e2210556256618 : check e2210556256618 [[]] .width = true := by decide
def e2210556256666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210556256666 : Closed e2210556256666 ∧ code e2210556256666 = 11006649278874 := by decide
theorem cert_e2210556256666 : check e2210556256666 [[]] .width = true := by decide
def e2210556262426 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210556262426 : Closed e2210556262426 ∧ code e2210556262426 = 11006649284634 := by decide
theorem cert_e2210556262426 : check e2210556262426 [[]] .width = true := by decide
def e2210556452890 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210556452890 : Closed e2210556452890 ∧ code e2210556452890 = 11006649475098 := by decide
theorem cert_e2210556452890 : check e2210556452890 [[]] .width = true := by decide
def e2210556452982 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210556452982 : Closed e2210556452982 ∧ code e2210556452982 = 11006649475190 := by decide
theorem cert_e2210556452982 : check e2210556452982 [[]] .width = true := by decide
def e2210556453226 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210556453226 : Closed e2210556453226 ∧ code e2210556453226 = 11006649475434 := by decide
theorem cert_e2210556453226 : check e2210556453226 [[]] .width = true := by decide
def e2210556453274 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210556453274 : Closed e2210556453274 ∧ code e2210556453274 = 11006649475482 := by decide
theorem cert_e2210556453274 : check e2210556453274 [[]] .width = true := by decide
def e2210556459034 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210556459034 : Closed e2210556459034 ∧ code e2210556459034 = 11006649481242 := by decide
theorem cert_e2210556459034 : check e2210556459034 [[]] .width = true := by decide
def e2210556471322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210556471322 : Closed e2210556471322 ∧ code e2210556471322 = 11006649493530 := by decide
theorem cert_e2210556471322 : check e2210556471322 [[]] .width = true := by decide
def e2210556895258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210556895258 : Closed e2210556895258 ∧ code e2210556895258 = 11006649917466 := by decide
theorem cert_e2210556895258 : check e2210556895258 [[]] .width = true := by decide
def e2210556895350 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210556895350 : Closed e2210556895350 ∧ code e2210556895350 = 11006649917558 := by decide
private def t_e2210556895350 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210556895350 : ¬ IsSelfInterpreter e2210556895350 :=
  wSource (t := t_e2210556895350) (replay_sound (ps := []) (t := e2210556895350) (by decide)) (by decide)
def e2210556895594 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210556895594 : Closed e2210556895594 ∧ code e2210556895594 = 11006649917802 := by decide
private def t_e2210556895594 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210556895594 : ¬ IsSelfInterpreter e2210556895594 :=
  wSource (t := t_e2210556895594) (replay_sound (ps := []) (t := e2210556895594) (by decide)) (by decide)
def e2210556895642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210556895642 : Closed e2210556895642 ∧ code e2210556895642 = 11006649917850 := by decide
private def t_e2210556895642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210556895642 : ¬ IsSelfInterpreter e2210556895642 :=
  wSource (t := t_e2210556895642) (replay_sound (ps := []) (t := e2210556895642) (by decide)) (by decide)
def e2210556911642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210556911642 : Closed e2210556911642 ∧ code e2210556911642 = 11006649933850 := by decide
theorem cert_e2210556911642 : check e2210556911642 [[]] .width = true := by decide
def e2210556911734 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210556911734 : Closed e2210556911734 ∧ code e2210556911734 = 11006649933942 := by decide
private def t_e2210556911734 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210556911734 : ¬ IsSelfInterpreter e2210556911734 :=
  wSource (t := t_e2210556911734) (replay_sound (ps := []) (t := e2210556911734) (by decide)) (by decide)
def e2210556911978 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210556911978 : Closed e2210556911978 ∧ code e2210556911978 = 11006649934186 := by decide
private def t_e2210556911978 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210556911978 : ¬ IsSelfInterpreter e2210556911978 :=
  wSource (t := t_e2210556911978) (replay_sound (ps := []) (t := e2210556911978) (by decide)) (by decide)
def e2210556912026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210556912026 : Closed e2210556912026 ∧ code e2210556912026 = 11006649934234 := by decide
private def t_e2210556912026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210556912026 : ¬ IsSelfInterpreter e2210556912026 :=
  wSource (t := t_e2210556912026) (replay_sound (ps := []) (t := e2210556912026) (by decide)) (by decide)
def e2210556917786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210556917786 : Closed e2210556917786 ∧ code e2210556917786 = 11006649939994 := by decide
theorem cert_e2210556917786 : check e2210556917786 [[]] .width = true := by decide
def e2210556925978 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210556925978 : Closed e2210556925978 ∧ code e2210556925978 = 11006649948186 := by decide
theorem cert_e2210556925978 : check e2210556925978 [[]] .width = true := by decide
def e2210556977178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210556977178 : Closed e2210556977178 ∧ code e2210556977178 = 11006649999386 := by decide
theorem cert_e2210556977178 : check e2210556977178 [[]] .width = true := by decide
def e2210556977270 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210556977270 : Closed e2210556977270 ∧ code e2210556977270 = 11006649999478 := by decide
private def t_e2210556977270 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2210556977270 : ¬ IsSelfInterpreter e2210556977270 :=
  wSource (t := t_e2210556977270) (replay_sound (ps := []) (t := e2210556977270) (by decide)) (by decide)
def e2210556977514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210556977514 : Closed e2210556977514 ∧ code e2210556977514 = 11006649999722 := by decide
private def t_e2210556977514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2210556977514 : ¬ IsSelfInterpreter e2210556977514 :=
  wSource (t := t_e2210556977514) (replay_sound (ps := []) (t := e2210556977514) (by decide)) (by decide)
def e2210556977562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210556977562 : Closed e2210556977562 ∧ code e2210556977562 = 11006649999770 := by decide
private def t_e2210556977562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2210556977562 : ¬ IsSelfInterpreter e2210556977562 :=
  wSource (t := t_e2210556977562) (replay_sound (ps := []) (t := e2210556977562) (by decide)) (by decide)
def e2210556983322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210556983322 : Closed e2210556983322 ∧ code e2210556983322 = 11006650005530 := by decide
theorem cert_e2210556983322 : check e2210556983322 [[]] .width = true := by decide
def e2210556995610 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210556995610 : Closed e2210556995610 ∧ code e2210556995610 = 11006650017818 := by decide
theorem cert_e2210556995610 : check e2210556995610 [[]] .width = true := by decide
def e2210557024282 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210557024282 : Closed e2210557024282 ∧ code e2210557024282 = 11006650046490 := by decide
theorem cert_e2210557024282 : check e2210557024282 [[]] .width = true := by decide
def e2210557028378 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210557028378 : Closed e2210557028378 ∧ code e2210557028378 = 11006650050586 := by decide
theorem cert_e2210557028378 : check e2210557028378 [[]] .width = true := by decide
def e2210597290182 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210597290182 : Closed e2210597290182 ∧ code e2210597290182 = 11006690312390 := by decide
theorem cert_e2210597290182 : check e2210597290182 [[]] .width = true := by decide
def e2210598338758 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210598338758 : Closed e2210598338758 ∧ code e2210598338758 = 11006691360966 := by decide
theorem cert_e2210598338758 : check e2210598338758 [[]] .width = true := by decide
def e2210598404294 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210598404294 : Closed e2210598404294 ∧ code e2210598404294 = 11006691426502 := by decide
theorem cert_e2210598404294 : check e2210598404294 [[]] .width = true := by decide
def e2210623578138 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210623578138 : Closed e2210623578138 ∧ code e2210623578138 = 11006716600346 := by decide
theorem cert_e2210623578138 : check e2210623578138 [[]] .width = true := by decide
def e2210623578230 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210623578230 : Closed e2210623578230 ∧ code e2210623578230 = 11006716600438 := by decide
theorem cert_e2210623578230 : check e2210623578230 [[]] .width = true := by decide
def e2210623578474 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210623578474 : Closed e2210623578474 ∧ code e2210623578474 = 11006716600682 := by decide
theorem cert_e2210623578474 : check e2210623578474 [[]] .width = true := by decide
def e2210623578522 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210623578522 : Closed e2210623578522 ∧ code e2210623578522 = 11006716600730 := by decide
theorem cert_e2210623578522 : check e2210623578522 [[]] .width = true := by decide
def e2210624102426 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210624102426 : Closed e2210624102426 ∧ code e2210624102426 = 11006717124634 := by decide
theorem cert_e2210624102426 : check e2210624102426 [[]] .width = true := by decide
def e2210624102518 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210624102518 : Closed e2210624102518 ∧ code e2210624102518 = 11006717124726 := by decide
theorem cert_e2210624102518 : check e2210624102518 [[]] .width = true := by decide
def e2210624102762 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210624102762 : Closed e2210624102762 ∧ code e2210624102762 = 11006717124970 := by decide
theorem cert_e2210624102762 : check e2210624102762 [[]] .width = true := by decide
def e2210624102810 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210624102810 : Closed e2210624102810 ∧ code e2210624102810 = 11006717125018 := by decide
theorem cert_e2210624102810 : check e2210624102810 [[]] .width = true := by decide
def e2210624135194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210624135194 : Closed e2210624135194 ∧ code e2210624135194 = 11006717157402 := by decide
theorem cert_e2210624135194 : check e2210624135194 [[]] .width = true := by decide
def e2210624135286 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210624135286 : Closed e2210624135286 ∧ code e2210624135286 = 11006717157494 := by decide
theorem cert_e2210624135286 : check e2210624135286 [[]] .width = true := by decide
def e2210624135530 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210624135530 : Closed e2210624135530 ∧ code e2210624135530 = 11006717157738 := by decide
theorem cert_e2210624135530 : check e2210624135530 [[]] .width = true := by decide
def e2210624135578 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210624135578 : Closed e2210624135578 ∧ code e2210624135578 = 11006717157786 := by decide
theorem cert_e2210624135578 : check e2210624135578 [[]] .width = true := by decide
def e2210627772442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210627772442 : Closed e2210627772442 ∧ code e2210627772442 = 11006720794650 := by decide
theorem cert_e2210627772442 : check e2210627772442 [[]] .width = true := by decide
def e2210627772534 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210627772534 : Closed e2210627772534 ∧ code e2210627772534 = 11006720794742 := by decide
theorem cert_e2210627772534 : check e2210627772534 [[]] .width = true := by decide
def e2210627772778 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210627772778 : Closed e2210627772778 ∧ code e2210627772778 = 11006720794986 := by decide
theorem cert_e2210627772778 : check e2210627772778 [[]] .width = true := by decide
def e2210627772826 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210627772826 : Closed e2210627772826 ∧ code e2210627772826 = 11006720795034 := by decide
theorem cert_e2210627772826 : check e2210627772826 [[]] .width = true := by decide
def e2210628558874 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210628558874 : Closed e2210628558874 ∧ code e2210628558874 = 11006721581082 := by decide
theorem cert_e2210628558874 : check e2210628558874 [[]] .width = true := by decide
def e2210628558966 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210628558966 : Closed e2210628558966 ∧ code e2210628558966 = 11006721581174 := by decide
theorem cert_e2210628558966 : check e2210628558966 [[]] .width = true := by decide
def e2210628559210 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210628559210 : Closed e2210628559210 ∧ code e2210628559210 = 11006721581418 := by decide
theorem cert_e2210628559210 : check e2210628559210 [[]] .width = true := by decide
def e2210628559258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210628559258 : Closed e2210628559258 ∧ code e2210628559258 = 11006721581466 := by decide
theorem cert_e2210628559258 : check e2210628559258 [[]] .width = true := by decide
def e2210628608026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210628608026 : Closed e2210628608026 ∧ code e2210628608026 = 11006721630234 := by decide
theorem cert_e2210628608026 : check e2210628608026 [[]] .width = true := by decide
def e2210628608118 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210628608118 : Closed e2210628608118 ∧ code e2210628608118 = 11006721630326 := by decide
theorem cert_e2210628608118 : check e2210628608118 [[]] .width = true := by decide
def e2210628608362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210628608362 : Closed e2210628608362 ∧ code e2210628608362 = 11006721630570 := by decide
theorem cert_e2210628608362 : check e2210628608362 [[]] .width = true := by decide
def e2210628608410 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210628608410 : Closed e2210628608410 ∧ code e2210628608410 = 11006721630618 := by decide
theorem cert_e2210628608410 : check e2210628608410 [[]] .width = true := by decide
def e2210628614170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210628614170 : Closed e2210628614170 ∧ code e2210628614170 = 11006721636378 := by decide
theorem cert_e2210628614170 : check e2210628614170 [[]] .width = true := by decide
def e2210630393882 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210630393882 : Closed e2210630393882 ∧ code e2210630393882 = 11006723416090 := by decide
theorem cert_e2210630393882 : check e2210630393882 [[]] .width = true := by decide
def e2210630393974 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210630393974 : Closed e2210630393974 ∧ code e2210630393974 = 11006723416182 := by decide
theorem cert_e2210630393974 : check e2210630393974 [[]] .width = true := by decide
def e2210630394218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210630394218 : Closed e2210630394218 ∧ code e2210630394218 = 11006723416426 := by decide
theorem cert_e2210630394218 : check e2210630394218 [[]] .width = true := by decide
def e2210630394266 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210630394266 : Closed e2210630394266 ∧ code e2210630394266 = 11006723416474 := by decide
theorem cert_e2210630394266 : check e2210630394266 [[]] .width = true := by decide
def e2210630426650 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210630426650 : Closed e2210630426650 ∧ code e2210630426650 = 11006723448858 := by decide
theorem cert_e2210630426650 : check e2210630426650 [[]] .width = true := by decide
def e2210630426742 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210630426742 : Closed e2210630426742 ∧ code e2210630426742 = 11006723448950 := by decide
theorem cert_e2210630426742 : check e2210630426742 [[]] .width = true := by decide
def e2210630426986 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210630426986 : Closed e2210630426986 ∧ code e2210630426986 = 11006723449194 := by decide
theorem cert_e2210630426986 : check e2210630426986 [[]] .width = true := by decide
def e2210630427034 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210630427034 : Closed e2210630427034 ∧ code e2210630427034 = 11006723449242 := by decide
theorem cert_e2210630427034 : check e2210630427034 [[]] .width = true := by decide
def e2210630656026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210630656026 : Closed e2210630656026 ∧ code e2210630656026 = 11006723678234 := by decide
theorem cert_e2210630656026 : check e2210630656026 [[]] .width = true := by decide
def e2210630656118 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210630656118 : Closed e2210630656118 ∧ code e2210630656118 = 11006723678326 := by decide
theorem cert_e2210630656118 : check e2210630656118 [[]] .width = true := by decide
def e2210630656362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210630656362 : Closed e2210630656362 ∧ code e2210630656362 = 11006723678570 := by decide
theorem cert_e2210630656362 : check e2210630656362 [[]] .width = true := by decide
def e2210630656410 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210630656410 : Closed e2210630656410 ∧ code e2210630656410 = 11006723678618 := by decide
theorem cert_e2210630656410 : check e2210630656410 [[]] .width = true := by decide
def e2210630705178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210630705178 : Closed e2210630705178 ∧ code e2210630705178 = 11006723727386 := by decide
theorem cert_e2210630705178 : check e2210630705178 [[]] .width = true := by decide
def e2210630705270 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210630705270 : Closed e2210630705270 ∧ code e2210630705270 = 11006723727478 := by decide
theorem cert_e2210630705270 : check e2210630705270 [[]] .width = true := by decide
def e2210630705514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210630705514 : Closed e2210630705514 ∧ code e2210630705514 = 11006723727722 := by decide
theorem cert_e2210630705514 : check e2210630705514 [[]] .width = true := by decide
def e2210630705562 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210630705562 : Closed e2210630705562 ∧ code e2210630705562 = 11006723727770 := by decide
theorem cert_e2210630705562 : check e2210630705562 [[]] .width = true := by decide
def e2210630711322 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210630711322 : Closed e2210630711322 ∧ code e2210630711322 = 11006723733530 := by decide
theorem cert_e2210630711322 : check e2210630711322 [[]] .width = true := by decide
def e2210630819866 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210630819866 : Closed e2210630819866 ∧ code e2210630819866 = 11006723842074 := by decide
theorem cert_e2210630819866 : check e2210630819866 [[]] .width = true := by decide
def e2210630819958 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210630819958 : Closed e2210630819958 ∧ code e2210630819958 = 11006723842166 := by decide
theorem cert_e2210630819958 : check e2210630819958 [[]] .width = true := by decide
def e2210630820202 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210630820202 : Closed e2210630820202 ∧ code e2210630820202 = 11006723842410 := by decide
theorem cert_e2210630820202 : check e2210630820202 [[]] .width = true := by decide
def e2210630820250 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210630820250 : Closed e2210630820250 ∧ code e2210630820250 = 11006723842458 := by decide
theorem cert_e2210630820250 : check e2210630820250 [[]] .width = true := by decide
def e2210630836250 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210630836250 : Closed e2210630836250 ∧ code e2210630836250 = 11006723858458 := by decide
theorem cert_e2210630836250 : check e2210630836250 [[]] .width = true := by decide
def e2210630836342 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210630836342 : Closed e2210630836342 ∧ code e2210630836342 = 11006723858550 := by decide
theorem cert_e2210630836342 : check e2210630836342 [[]] .width = true := by decide
def e2210630836586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210630836586 : Closed e2210630836586 ∧ code e2210630836586 = 11006723858794 := by decide
theorem cert_e2210630836586 : check e2210630836586 [[]] .width = true := by decide
def e2210630836634 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210630836634 : Closed e2210630836634 ∧ code e2210630836634 = 11006723858842 := by decide
theorem cert_e2210630836634 : check e2210630836634 [[]] .width = true := by decide
def e2210630842394 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210630842394 : Closed e2210630842394 ∧ code e2210630842394 = 11006723864602 := by decide
theorem cert_e2210630842394 : check e2210630842394 [[]] .width = true := by decide
def e2210630850586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2)) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210630850586 : Closed e2210630850586 ∧ code e2210630850586 = 11006723872794 := by decide
theorem cert_e2210630850586 : check e2210630850586 [[]] .width = true := by decide
def e2210648743962 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210648743962 : Closed e2210648743962 ∧ code e2210648743962 = 11006741766170 := by decide
theorem cert_e2210648743962 : check e2210648743962 [[]] .width = true := by decide
def e2210648744054 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210648744054 : Closed e2210648744054 ∧ code e2210648744054 = 11006741766262 := by decide
theorem cert_e2210648744054 : check e2210648744054 [[]] .width = true := by decide
def e2210648744298 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210648744298 : Closed e2210648744298 ∧ code e2210648744298 = 11006741766506 := by decide
theorem cert_e2210648744298 : check e2210648744298 [[]] .width = true := by decide
def e2210648744346 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210648744346 : Closed e2210648744346 ∧ code e2210648744346 = 11006741766554 := by decide
theorem cert_e2210648744346 : check e2210648744346 [[]] .width = true := by decide
def e2210649268250 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210649268250 : Closed e2210649268250 ∧ code e2210649268250 = 11006742290458 := by decide
theorem cert_e2210649268250 : check e2210649268250 [[]] .width = true := by decide
def e2210649268342 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210649268342 : Closed e2210649268342 ∧ code e2210649268342 = 11006742290550 := by decide
theorem cert_e2210649268342 : check e2210649268342 [[]] .width = true := by decide
def e2210649268586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210649268586 : Closed e2210649268586 ∧ code e2210649268586 = 11006742290794 := by decide
theorem cert_e2210649268586 : check e2210649268586 [[]] .width = true := by decide
def e2210649268634 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210649268634 : Closed e2210649268634 ∧ code e2210649268634 = 11006742290842 := by decide
theorem cert_e2210649268634 : check e2210649268634 [[]] .width = true := by decide
def e2210649301018 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210649301018 : Closed e2210649301018 ∧ code e2210649301018 = 11006742323226 := by decide
theorem cert_e2210649301018 : check e2210649301018 [[]] .width = true := by decide
def e2210649301110 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210649301110 : Closed e2210649301110 ∧ code e2210649301110 = 11006742323318 := by decide
theorem cert_e2210649301110 : check e2210649301110 [[]] .width = true := by decide
def e2210649301354 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210649301354 : Closed e2210649301354 ∧ code e2210649301354 = 11006742323562 := by decide
theorem cert_e2210649301354 : check e2210649301354 [[]] .width = true := by decide
def e2210649301402 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210649301402 : Closed e2210649301402 ∧ code e2210649301402 = 11006742323610 := by decide
theorem cert_e2210649301402 : check e2210649301402 [[]] .width = true := by decide
def e2210660278298 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210660278298 : Closed e2210660278298 ∧ code e2210660278298 = 11006753300506 := by decide
theorem cert_e2210660278298 : check e2210660278298 [[]] .width = true := by decide
def e2210660278390 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210660278390 : Closed e2210660278390 ∧ code e2210660278390 = 11006753300598 := by decide
theorem cert_e2210660278390 : check e2210660278390 [[]] .width = true := by decide
def e2210660278634 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210660278634 : Closed e2210660278634 ∧ code e2210660278634 = 11006753300842 := by decide
theorem cert_e2210660278634 : check e2210660278634 [[]] .width = true := by decide
def e2210660278682 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210660278682 : Closed e2210660278682 ∧ code e2210660278682 = 11006753300890 := by decide
theorem cert_e2210660278682 : check e2210660278682 [[]] .width = true := by decide
def e2210663424026 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210663424026 : Closed e2210663424026 ∧ code e2210663424026 = 11006756446234 := by decide
theorem cert_e2210663424026 : check e2210663424026 [[]] .width = true := by decide
def e2210663424118 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210663424118 : Closed e2210663424118 ∧ code e2210663424118 = 11006756446326 := by decide
theorem cert_e2210663424118 : check e2210663424118 [[]] .width = true := by decide
def e2210663424362 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210663424362 : Closed e2210663424362 ∧ code e2210663424362 = 11006756446570 := by decide
theorem cert_e2210663424362 : check e2210663424362 [[]] .width = true := by decide
def e2210663424410 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210663424410 : Closed e2210663424410 ∧ code e2210663424410 = 11006756446618 := by decide
theorem cert_e2210663424410 : check e2210663424410 [[]] .width = true := by decide
def e2210663456794 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210663456794 : Closed e2210663456794 ∧ code e2210663456794 = 11006756479002 := by decide
theorem cert_e2210663456794 : check e2210663456794 [[]] .width = true := by decide
def e2210663456886 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210663456886 : Closed e2210663456886 ∧ code e2210663456886 = 11006756479094 := by decide
theorem cert_e2210663456886 : check e2210663456886 [[]] .width = true := by decide
def e2210663457130 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210663457130 : Closed e2210663457130 ∧ code e2210663457130 = 11006756479338 := by decide
theorem cert_e2210663457130 : check e2210663457130 [[]] .width = true := by decide
def e2210663457178 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210663457178 : Closed e2210663457178 ∧ code e2210663457178 = 11006756479386 := by decide
theorem cert_e2210663457178 : check e2210663457178 [[]] .width = true := by decide
def e2210670690502 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210670690502 : Closed e2210670690502 ∧ code e2210670690502 = 11006763712710 := by decide
theorem cert_e2210670690502 : check e2210670690502 [[]] .width = true := by decide
def e2210673909786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210673909786 : Closed e2210673909786 ∧ code e2210673909786 = 11006766931994 := by decide
theorem cert_e2210673909786 : check e2210673909786 [[]] .width = true := by decide
def e2210673909878 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210673909878 : Closed e2210673909878 ∧ code e2210673909878 = 11006766932086 := by decide
theorem cert_e2210673909878 : check e2210673909878 [[]] .width = true := by decide
def e2210673910122 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210673910122 : Closed e2210673910122 ∧ code e2210673910122 = 11006766932330 := by decide
theorem cert_e2210673910122 : check e2210673910122 [[]] .width = true := by decide
def e2210673910170 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210673910170 : Closed e2210673910170 ∧ code e2210673910170 = 11006766932378 := by decide
theorem cert_e2210673910170 : check e2210673910170 [[]] .width = true := by decide
def e2210674696218 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210674696218 : Closed e2210674696218 ∧ code e2210674696218 = 11006767718426 := by decide
theorem cert_e2210674696218 : check e2210674696218 [[]] .width = true := by decide
def e2210674696310 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210674696310 : Closed e2210674696310 ∧ code e2210674696310 = 11006767718518 := by decide
theorem cert_e2210674696310 : check e2210674696310 [[]] .width = true := by decide
def e2210674696554 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210674696554 : Closed e2210674696554 ∧ code e2210674696554 = 11006767718762 := by decide
theorem cert_e2210674696554 : check e2210674696554 [[]] .width = true := by decide
def e2210674696602 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210674696602 : Closed e2210674696602 ∧ code e2210674696602 = 11006767718810 := by decide
theorem cert_e2210674696602 : check e2210674696602 [[]] .width = true := by decide
def e2210674745370 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210674745370 : Closed e2210674745370 ∧ code e2210674745370 = 11006767767578 := by decide
theorem cert_e2210674745370 : check e2210674745370 [[]] .width = true := by decide
def e2210674745462 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210674745462 : Closed e2210674745462 ∧ code e2210674745462 = 11006767767670 := by decide
theorem cert_e2210674745462 : check e2210674745462 [[]] .width = true := by decide
def e2210674745706 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210674745706 : Closed e2210674745706 ∧ code e2210674745706 = 11006767767914 := by decide
theorem cert_e2210674745706 : check e2210674745706 [[]] .width = true := by decide
def e2210674745754 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210674745754 : Closed e2210674745754 ∧ code e2210674745754 = 11006767767962 := by decide
theorem cert_e2210674745754 : check e2210674745754 [[]] .width = true := by decide
def e2210674751514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210674751514 : Closed e2210674751514 ∧ code e2210674751514 = 11006767773722 := by decide
theorem cert_e2210674751514 : check e2210674751514 [[]] .width = true := by decide
def e2210677055514 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210677055514 : Closed e2210677055514 ∧ code e2210677055514 = 11006770077722 := by decide
theorem cert_e2210677055514 : check e2210677055514 [[]] .width = true := by decide
def e2210677055606 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210677055606 : Closed e2210677055606 ∧ code e2210677055606 = 11006770077814 := by decide
theorem cert_e2210677055606 : check e2210677055606 [[]] .width = true := by decide
def e2210677055850 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210677055850 : Closed e2210677055850 ∧ code e2210677055850 = 11006770078058 := by decide
theorem cert_e2210677055850 : check e2210677055850 [[]] .width = true := by decide
def e2210677055898 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210677055898 : Closed e2210677055898 ∧ code e2210677055898 = 11006770078106 := by decide
theorem cert_e2210677055898 : check e2210677055898 [[]] .width = true := by decide
def e2210681569478 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2210681569478 : Closed e2210681569478 ∧ code e2210681569478 = 11006774591686 := by decide
theorem cert_e2210681569478 : check e2210681569478 [[]] .width = true := by decide
def e2210681774106 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210681774106 : Closed e2210681774106 ∧ code e2210681774106 = 11006774796314 := by decide
theorem cert_e2210681774106 : check e2210681774106 [[]] .width = true := by decide
def e2210681774198 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210681774198 : Closed e2210681774198 ∧ code e2210681774198 = 11006774796406 := by decide
theorem cert_e2210681774198 : check e2210681774198 [[]] .width = true := by decide
def e2210681774442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210681774442 : Closed e2210681774442 ∧ code e2210681774442 = 11006774796650 := by decide
theorem cert_e2210681774442 : check e2210681774442 [[]] .width = true := by decide
def e2210681774490 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210681774490 : Closed e2210681774490 ∧ code e2210681774490 = 11006774796698 := by decide
theorem cert_e2210681774490 : check e2210681774490 [[]] .width = true := by decide
def e2210681823258 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2210681823258 : Closed e2210681823258 ∧ code e2210681823258 = 11006774845466 := by decide
theorem cert_e2210681823258 : check e2210681823258 [[]] .width = true := by decide
def e2210681823350 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2210681823350 : Closed e2210681823350 ∧ code e2210681823350 = 11006774845558 := by decide
theorem cert_e2210681823350 : check e2210681823350 [[]] .width = true := by decide
def e2210681823594 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2210681823594 : Closed e2210681823594 ∧ code e2210681823594 = 11006774845802 := by decide
theorem cert_e2210681823594 : check e2210681823594 [[]] .width = true := by decide
def e2210681823642 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2210681823642 : Closed e2210681823642 ∧ code e2210681823642 = 11006774845850 := by decide
theorem cert_e2210681823642 : check e2210681823642 [[]] .width = true := by decide
def e2210681829402 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2210681829402 : Closed e2210681829402 ∧ code e2210681829402 = 11006774851610 := by decide
theorem cert_e2210681829402 : check e2210681829402 [[]] .width = true := by decide
def e2210682241050 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2210682241050 : Closed e2210682241050 ∧ code e2210682241050 = 11006775263258 := by decide
theorem cert_e2210682241050 : check e2210682241050 [[]] .width = true := by decide
def e2210682241142 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2210682241142 : Closed e2210682241142 ∧ code e2210682241142 = 11006775263350 := by decide
theorem cert_e2210682241142 : check e2210682241142 [[]] .width = true := by decide
def e2210682241386 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2210682241386 : Closed e2210682241386 ∧ code e2210682241386 = 11006775263594 := by decide
theorem cert_e2210682241386 : check e2210682241386 [[]] .width = true := by decide
def e2210682241434 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2210682241434 : Closed e2210682241434 ∧ code e2210682241434 = 11006775263642 := by decide
theorem cert_e2210682241434 : check e2210682241434 [[]] .width = true := by decide
def e2210682241518 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.var 2))))))
theorem wire_e2210682241518 : Closed e2210682241518 ∧ code e2210682241518 = 11006775263726 := by decide
theorem cert_e2210682241518 : check e2210682241518 [[]] .width = true := by decide
def e2210682242442 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2210682242442 : Closed e2210682242442 ∧ code e2210682242442 = 11006775264650 := by decide
theorem cert_e2210682242442 : check e2210682242442 [[]] .width = true := by decide
def e2210682242466 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2210682242466 : Closed e2210682242466 ∧ code e2210682242466 = 11006775264674 := by decide
theorem cert_e2210682242466 : check e2210682242466 [[]] .width = true := by decide
def e2210682242486 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))
theorem wire_e2210682242486 : Closed e2210682242486 ∧ code e2210682242486 = 11006775264694 := by decide
theorem cert_e2210682242486 : check e2210682242486 [[]] .width = true := by decide
def e2210682242518 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))
theorem wire_e2210682242518 : Closed e2210682242518 ∧ code e2210682242518 = 11006775264726 := by decide
theorem cert_e2210682242518 : check e2210682242518 [[]] .width = true := by decide
def e2210682242522 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))
theorem wire_e2210682242522 : Closed e2210682242522 ∧ code e2210682242522 = 11006775264730 := by decide
theorem cert_e2210682242522 : check e2210682242522 [[]] .width = true := by decide
def e2210682242574 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2210682242574 : Closed e2210682242574 ∧ code e2210682242574 = 11006775264782 := by decide
theorem cert_e2210682242574 : check e2210682242574 [[]] .width = true := by decide
def e2210682242586 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210682242586 : Closed e2210682242586 ∧ code e2210682242586 = 11006775264794 := by decide
theorem cert_e2210682242586 : check e2210682242586 [[]] .width = true := by decide
def e2210682242658 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2210682242658 : Closed e2210682242658 ∧ code e2210682242658 = 11006775264866 := by decide
theorem cert_e2210682242658 : check e2210682242658 [[]] .width = true := by decide
def e2210682242678 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))
theorem wire_e2210682242678 : Closed e2210682242678 ∧ code e2210682242678 = 11006775264886 := by decide
theorem cert_e2210682242678 : check e2210682242678 [[]] .width = true := by decide
def e2210682242870 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))
theorem wire_e2210682242870 : Closed e2210682242870 ∧ code e2210682242870 = 11006775265078 := by decide
theorem cert_e2210682242870 : check e2210682242870 [[]] .width = true := by decide
def e2210682242874 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))
theorem wire_e2210682242874 : Closed e2210682242874 ∧ code e2210682242874 = 11006775265082 := by decide
theorem cert_e2210682242874 : check e2210682242874 [[]] .width = true := by decide
def e2210682246570 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))
theorem wire_e2210682246570 : Closed e2210682246570 ∧ code e2210682246570 = 11006775268778 := by decide
theorem cert_e2210682246570 : check e2210682246570 [[]] .width = true := by decide
def e2210682246666 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))
theorem wire_e2210682246666 : Closed e2210682246666 ∧ code e2210682246666 = 11006775268874 := by decide
theorem cert_e2210682246666 : check e2210682246666 [[]] .width = true := by decide
def e2210682246762 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))
theorem wire_e2210682246762 : Closed e2210682246762 ∧ code e2210682246762 = 11006775268970 := by decide
theorem cert_e2210682246762 : check e2210682246762 [[]] .width = true := by decide
def e2210682246786 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))
theorem wire_e2210682246786 : Closed e2210682246786 ∧ code e2210682246786 = 11006775268994 := by decide
theorem cert_e2210682246786 : check e2210682246786 [[]] .width = true := by decide
def e2210682246810 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))
theorem wire_e2210682246810 : Closed e2210682246810 ∧ code e2210682246810 = 11006775269018 := by decide
theorem cert_e2210682246810 : check e2210682246810 [[]] .width = true := by decide
def e2210682247194 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2210682247194 : Closed e2210682247194 ∧ code e2210682247194 = 11006775269402 := by decide
theorem cert_e2210682247194 : check e2210682247194 [[]] .width = true := by decide
def e2210682247286 : Term := (.app (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2210682247286 : Closed e2210682247286 ∧ code e2210682247286 = 11006775269494 := by decide
theorem cert_e2210682247286 : check e2210682247286 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2210556895350
#print axioms Blc.Floor43.cert_e2210556895594
#print axioms Blc.Floor43.cert_e2210556895642
#print axioms Blc.Floor43.cert_e2210556911734
#print axioms Blc.Floor43.cert_e2210556911978
#print axioms Blc.Floor43.cert_e2210556912026
#print axioms Blc.Floor43.cert_e2210556977270
#print axioms Blc.Floor43.cert_e2210556977514
#print axioms Blc.Floor43.cert_e2210556977562
