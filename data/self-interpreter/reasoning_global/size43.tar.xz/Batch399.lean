import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372932206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372932206 : Closed e2422372932206 ∧ code e2422372932206 = 11218465954414 := by decide
theorem cert_e2422372932206 : check e2422372932206 [[],[]] .smaller = true := by decide
def e2422372932218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372932218 : Closed e2422372932218 ∧ code e2422372932218 = 11218465954426 := by decide
theorem cert_e2422372932218 : check e2422372932218 [[],[]] .smaller = true := by decide
def e2422372932382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422372932382 : Closed e2422372932382 ∧ code e2422372932382 = 11218465954590 := by decide
theorem cert_e2422372932382 : check e2422372932382 [[],[]] .smaller = true := by decide
def e2422372932482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372932482 : Closed e2422372932482 ∧ code e2422372932482 = 11218465954690 := by decide
theorem cert_e2422372932482 : check e2422372932482 [[],[]] .smaller = true := by decide
def e2422372932494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422372932494 : Closed e2422372932494 ∧ code e2422372932494 = 11218465954702 := by decide
theorem cert_e2422372932494 : check e2422372932494 [[],[]] .smaller = true := by decide
def e2422372932506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372932506 : Closed e2422372932506 ∧ code e2422372932506 = 11218465954714 := by decide
theorem cert_e2422372932506 : check e2422372932506 [[],[]] .smaller = true := by decide
def e2422372932550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422372932550 : Closed e2422372932550 ∧ code e2422372932550 = 11218465954758 := by decide
theorem cert_e2422372932550 : check e2422372932550 [[],[]] .three = true := by decide
def e2422372932574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))) (.var 3)))))))
theorem wire_e2422372932574 : Closed e2422372932574 ∧ code e2422372932574 = 11218465954782 := by decide
theorem cert_e2422372932574 : check e2422372932574 [[],[]] .three = true := by decide
def e2422372932702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422372932702 : Closed e2422372932702 ∧ code e2422372932702 = 11218465954910 := by decide
theorem cert_e2422372932702 : check e2422372932702 [[],[]] .three = true := by decide
def e2422372932718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2422372932718 : Closed e2422372932718 ∧ code e2422372932718 = 11218465954926 := by decide
theorem cert_e2422372932718 : check e2422372932718 [[],[]] .smaller = true := by decide
def e2422372932730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422372932730 : Closed e2422372932730 ∧ code e2422372932730 = 11218465954938 := by decide
theorem cert_e2422372932730 : check e2422372932730 [[],[]] .smaller = true := by decide
def e2422372932894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2422372932894 : Closed e2422372932894 ∧ code e2422372932894 = 11218465955102 := by decide
theorem cert_e2422372932894 : check e2422372932894 [[],[]] .smaller = true := by decide
def e2422372933062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422372933062 : Closed e2422372933062 ∧ code e2422372933062 = 11218465955270 := by decide
theorem cert_e2422372933062 : check e2422372933062 [[],[]] .smaller = true := by decide
def e2422372933086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e2422372933086 : Closed e2422372933086 ∧ code e2422372933086 = 11218465955294 := by decide
theorem cert_e2422372933086 : check e2422372933086 [[],[]] .three = true := by decide
def e2422372933090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422372933090 : Closed e2422372933090 ∧ code e2422372933090 = 11218465955298 := by decide
theorem cert_e2422372933090 : check e2422372933090 [[],[]] .three = true := by decide
def e2422372933102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e2422372933102 : Closed e2422372933102 ∧ code e2422372933102 = 11218465955310 := by decide
theorem cert_e2422372933102 : check e2422372933102 [[],[]] .three = true := by decide
def e2422372933130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422372933130 : Closed e2422372933130 ∧ code e2422372933130 = 11218465955338 := by decide
theorem cert_e2422372933130 : check e2422372933130 [[],[]] .smaller = true := by decide
def e2422372933166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372933166 : Closed e2422372933166 ∧ code e2422372933166 = 11218465955374 := by decide
theorem cert_e2422372933166 : check e2422372933166 [[],[]] .smaller = true := by decide
def e2422372933174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422372933174 : Closed e2422372933174 ∧ code e2422372933174 = 11218465955382 := by decide
theorem cert_e2422372933174 : check e2422372933174 [[],[]] .smaller = true := by decide
def e2422372933178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422372933178 : Closed e2422372933178 ∧ code e2422372933178 = 11218465955386 := by decide
theorem cert_e2422372933178 : check e2422372933178 [[],[]] .smaller = true := by decide
def e2422372933226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422372933226 : Closed e2422372933226 ∧ code e2422372933226 = 11218465955434 := by decide
theorem cert_e2422372933226 : check e2422372933226 [[],[]] .smaller = true := by decide
def e2422372933250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372933250 : Closed e2422372933250 ∧ code e2422372933250 = 11218465955458 := by decide
theorem cert_e2422372933250 : check e2422372933250 [[],[]] .smaller = true := by decide
def e2422372933262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422372933262 : Closed e2422372933262 ∧ code e2422372933262 = 11218465955470 := by decide
theorem cert_e2422372933262 : check e2422372933262 [[],[]] .smaller = true := by decide
def e2422372933274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372933274 : Closed e2422372933274 ∧ code e2422372933274 = 11218465955482 := by decide
theorem cert_e2422372933274 : check e2422372933274 [[],[]] .smaller = true := by decide
def e2422372933318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422372933318 : Closed e2422372933318 ∧ code e2422372933318 = 11218465955526 := by decide
theorem cert_e2422372933318 : check e2422372933318 [[],[]] .smaller = true := by decide
def e2422372933342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e2422372933342 : Closed e2422372933342 ∧ code e2422372933342 = 11218465955550 := by decide
theorem cert_e2422372933342 : check e2422372933342 [[],[]] .three = true := by decide
def e2422372933346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422372933346 : Closed e2422372933346 ∧ code e2422372933346 = 11218465955554 := by decide
theorem cert_e2422372933346 : check e2422372933346 [[],[]] .smaller = true := by decide
def e2422372933358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 2)))))))
theorem wire_e2422372933358 : Closed e2422372933358 ∧ code e2422372933358 = 11218465955566 := by decide
theorem cert_e2422372933358 : check e2422372933358 [[],[]] .smaller = true := by decide
def e2422372933366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e2422372933366 : Closed e2422372933366 ∧ code e2422372933366 = 11218465955574 := by decide
theorem cert_e2422372933366 : check e2422372933366 [[],[]] .three = true := by decide
def e2422372933398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372933398 : Closed e2422372933398 ∧ code e2422372933398 = 11218465955606 := by decide
theorem cert_e2422372933398 : check e2422372933398 [[],[]] .three = true := by decide
def e2422372933402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422372933402 : Closed e2422372933402 ∧ code e2422372933402 = 11218465955610 := by decide
theorem cert_e2422372933402 : check e2422372933402 [[],[]] .three = true := by decide
def e2422372933446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422372933446 : Closed e2422372933446 ∧ code e2422372933446 = 11218465955654 := by decide
theorem cert_e2422372933446 : check e2422372933446 [[],[]] .three = true := by decide
def e2422372933470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))) (.var 3)))))))
theorem wire_e2422372933470 : Closed e2422372933470 ∧ code e2422372933470 = 11218465955678 := by decide
theorem cert_e2422372933470 : check e2422372933470 [[],[]] .three = true := by decide
def e2422372933474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422372933474 : Closed e2422372933474 ∧ code e2422372933474 = 11218465955682 := by decide
theorem cert_e2422372933474 : check e2422372933474 [[],[]] .three = true := by decide
def e2422372933486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e2422372933486 : Closed e2422372933486 ∧ code e2422372933486 = 11218465955694 := by decide
theorem cert_e2422372933486 : check e2422372933486 [[],[]] .three = true := by decide
def e2422372933494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e2422372933494 : Closed e2422372933494 ∧ code e2422372933494 = 11218465955702 := by decide
theorem cert_e2422372933494 : check e2422372933494 [[],[]] .three = true := by decide
def e2422372933498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3))) (.var 0)))))))
theorem wire_e2422372933498 : Closed e2422372933498 ∧ code e2422372933498 = 11218465955706 := by decide
theorem cert_e2422372933498 : check e2422372933498 [[],[]] .three = true := by decide
def e2422372934078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422372934078 : Closed e2422372934078 ∧ code e2422372934078 = 11218465956286 := by decide
theorem cert_e2422372934078 : check e2422372934078 [[],[]] .three = true := by decide
def e2422372934110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422372934110 : Closed e2422372934110 ∧ code e2422372934110 = 11218465956318 := by decide
theorem cert_e2422372934110 : check e2422372934110 [[],[]] .smaller = true := by decide
def e2422372934134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422372934134 : Closed e2422372934134 ∧ code e2422372934134 = 11218465956342 := by decide
theorem cert_e2422372934134 : check e2422372934134 [[],[]] .smaller = true := by decide
def e2422372934138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422372934138 : Closed e2422372934138 ∧ code e2422372934138 = 11218465956346 := by decide
theorem cert_e2422372934138 : check e2422372934138 [[],[]] .three = true := by decide
def e2422372935086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422372935086 : Closed e2422372935086 ∧ code e2422372935086 = 11218465957294 := by decide
theorem cert_e2422372935086 : check e2422372935086 [[],[]] .smaller = true := by decide
def e2422372935098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422372935098 : Closed e2422372935098 ∧ code e2422372935098 = 11218465957306 := by decide
theorem cert_e2422372935098 : check e2422372935098 [[],[]] .smaller = true := by decide
def e2422372935146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422372935146 : Closed e2422372935146 ∧ code e2422372935146 = 11218465957354 := by decide
theorem cert_e2422372935146 : check e2422372935146 [[],[]] .smaller = true := by decide
def e2422372935230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422372935230 : Closed e2422372935230 ∧ code e2422372935230 = 11218465957438 := by decide
theorem cert_e2422372935230 : check e2422372935230 [[],[]] .three = true := by decide
def e2422372935278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422372935278 : Closed e2422372935278 ∧ code e2422372935278 = 11218465957486 := by decide
theorem cert_e2422372935278 : check e2422372935278 [[],[]] .smaller = true := by decide
def e2422372935290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422372935290 : Closed e2422372935290 ∧ code e2422372935290 = 11218465957498 := by decide
theorem cert_e2422372935290 : check e2422372935290 [[],[]] .smaller = true := by decide
def e2422372935454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422372935454 : Closed e2422372935454 ∧ code e2422372935454 = 11218465957662 := by decide
theorem cert_e2422372935454 : check e2422372935454 [[],[]] .smaller = true := by decide
def e2422372935554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e2422372935554 : Closed e2422372935554 ∧ code e2422372935554 = 11218465957762 := by decide
theorem cert_e2422372935554 : check e2422372935554 [[],[]] .smaller = true := by decide
def e2422372935566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422372935566 : Closed e2422372935566 ∧ code e2422372935566 = 11218465957774 := by decide
theorem cert_e2422372935566 : check e2422372935566 [[],[]] .smaller = true := by decide
def e2422372935578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372935578 : Closed e2422372935578 ∧ code e2422372935578 = 11218465957786 := by decide
theorem cert_e2422372935578 : check e2422372935578 [[],[]] .smaller = true := by decide
def e2422372935622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422372935622 : Closed e2422372935622 ∧ code e2422372935622 = 11218465957830 := by decide
theorem cert_e2422372935622 : check e2422372935622 [[],[]] .three = true := by decide
def e2422372935646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 3) (.var 3))))))))
theorem wire_e2422372935646 : Closed e2422372935646 ∧ code e2422372935646 = 11218465957854 := by decide
theorem cert_e2422372935646 : check e2422372935646 [[],[]] .three = true := by decide
def e2422372937854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 5)))))))))
theorem wire_e2422372937854 : Closed e2422372937854 ∧ code e2422372937854 = 11218465960062 := by decide
theorem cert_e2422372937854 : check e2422372937854 [[],[]] .three = true := by decide
def e2422372937950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422372937950 : Closed e2422372937950 ∧ code e2422372937950 = 11218465960158 := by decide
theorem cert_e2422372937950 : check e2422372937950 [[],[]] .smaller = true := by decide
def e2422372937978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422372937978 : Closed e2422372937978 ∧ code e2422372937978 = 11218465960186 := by decide
theorem cert_e2422372937978 : check e2422372937978 [[],[]] .smaller = true := by decide
def e2422372938526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422372938526 : Closed e2422372938526 ∧ code e2422372938526 = 11218465960734 := by decide
theorem cert_e2422372938526 : check e2422372938526 [[],[]] .smaller = true := by decide
def e2422372938694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422372938694 : Closed e2422372938694 ∧ code e2422372938694 = 11218465960902 := by decide
theorem cert_e2422372938694 : check e2422372938694 [[],[]] .smaller = true := by decide
def e2422372938718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e2422372938718 : Closed e2422372938718 ∧ code e2422372938718 = 11218465960926 := by decide
theorem cert_e2422372938718 : check e2422372938718 [[],[]] .three = true := by decide
def e2422372938722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422372938722 : Closed e2422372938722 ∧ code e2422372938722 = 11218465960930 := by decide
theorem cert_e2422372938722 : check e2422372938722 [[],[]] .three = true := by decide
def e2422372938734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e2422372938734 : Closed e2422372938734 ∧ code e2422372938734 = 11218465960942 := by decide
theorem cert_e2422372938734 : check e2422372938734 [[],[]] .three = true := by decide
def e2422372939802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422372939802 : Closed e2422372939802 ∧ code e2422372939802 = 11218465962010 := by decide
theorem cert_e2422372939802 : check e2422372939802 [[],[]] .smaller = true := by decide
def e2422372939838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422372939838 : Closed e2422372939838 ∧ code e2422372939838 = 11218465962046 := by decide
theorem cert_e2422372939838 : check e2422372939838 [[],[]] .smaller = true := by decide
def e2422372939886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422372939886 : Closed e2422372939886 ∧ code e2422372939886 = 11218465962094 := by decide
theorem cert_e2422372939886 : check e2422372939886 [[],[]] .smaller = true := by decide
def e2422372939894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422372939894 : Closed e2422372939894 ∧ code e2422372939894 = 11218465962102 := by decide
theorem cert_e2422372939894 : check e2422372939894 [[],[]] .smaller = true := by decide
def e2422372939898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422372939898 : Closed e2422372939898 ∧ code e2422372939898 = 11218465962106 := by decide
theorem cert_e2422372939898 : check e2422372939898 [[],[]] .smaller = true := by decide
def e2422372940138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422372940138 : Closed e2422372940138 ∧ code e2422372940138 = 11218465962346 := by decide
theorem cert_e2422372940138 : check e2422372940138 [[],[]] .smaller = true := by decide
def e2422372940162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422372940162 : Closed e2422372940162 ∧ code e2422372940162 = 11218465962370 := by decide
theorem cert_e2422372940162 : check e2422372940162 [[],[]] .smaller = true := by decide
def e2422372940174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422372940174 : Closed e2422372940174 ∧ code e2422372940174 = 11218465962382 := by decide
theorem cert_e2422372940174 : check e2422372940174 [[],[]] .smaller = true := by decide
def e2422372940186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372940186 : Closed e2422372940186 ∧ code e2422372940186 = 11218465962394 := by decide
theorem cert_e2422372940186 : check e2422372940186 [[],[]] .smaller = true := by decide
def e2422372940230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422372940230 : Closed e2422372940230 ∧ code e2422372940230 = 11218465962438 := by decide
theorem cert_e2422372940230 : check e2422372940230 [[],[]] .smaller = true := by decide
def e2422372940254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372940254 : Closed e2422372940254 ∧ code e2422372940254 = 11218465962462 := by decide
theorem cert_e2422372940254 : check e2422372940254 [[],[]] .three = true := by decide
def e2422372940258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422372940258 : Closed e2422372940258 ∧ code e2422372940258 = 11218465962466 := by decide
theorem cert_e2422372940258 : check e2422372940258 [[],[]] .smaller = true := by decide
def e2422372940270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372940270 : Closed e2422372940270 ∧ code e2422372940270 = 11218465962478 := by decide
theorem cert_e2422372940270 : check e2422372940270 [[],[]] .smaller = true := by decide
def e2422372940278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372940278 : Closed e2422372940278 ∧ code e2422372940278 = 11218465962486 := by decide
theorem cert_e2422372940278 : check e2422372940278 [[],[]] .three = true := by decide
def e2422372940830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422372940830 : Closed e2422372940830 ∧ code e2422372940830 = 11218465963038 := by decide
theorem cert_e2422372940830 : check e2422372940830 [[],[]] .three = true := by decide
def e2422372940854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422372940854 : Closed e2422372940854 ∧ code e2422372940854 = 11218465963062 := by decide
theorem cert_e2422372940854 : check e2422372940854 [[],[]] .three = true := by decide
def e2422372940858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422372940858 : Closed e2422372940858 ∧ code e2422372940858 = 11218465963066 := by decide
theorem cert_e2422372940858 : check e2422372940858 [[],[]] .three = true := by decide
def e2422372940998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422372940998 : Closed e2422372940998 ∧ code e2422372940998 = 11218465963206 := by decide
theorem cert_e2422372940998 : check e2422372940998 [[],[]] .three = true := by decide
def e2422372941022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372941022 : Closed e2422372941022 ∧ code e2422372941022 = 11218465963230 := by decide
theorem cert_e2422372941022 : check e2422372941022 [[],[]] .three = true := by decide
def e2422372941026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422372941026 : Closed e2422372941026 ∧ code e2422372941026 = 11218465963234 := by decide
theorem cert_e2422372941026 : check e2422372941026 [[],[]] .three = true := by decide
def e2422372941038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372941038 : Closed e2422372941038 ∧ code e2422372941038 = 11218465963246 := by decide
theorem cert_e2422372941038 : check e2422372941038 [[],[]] .three = true := by decide
def e2422372941046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372941046 : Closed e2422372941046 ∧ code e2422372941046 = 11218465963254 := by decide
theorem cert_e2422372941046 : check e2422372941046 [[],[]] .three = true := by decide
def e2422372941050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372941050 : Closed e2422372941050 ∧ code e2422372941050 = 11218465963258 := by decide
theorem cert_e2422372941050 : check e2422372941050 [[],[]] .three = true := by decide
def e2422372942038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)))))))
theorem wire_e2422372942038 : Closed e2422372942038 ∧ code e2422372942038 = 11218465964246 := by decide
theorem cert_e2422372942038 : check e2422372942038 [[],[]] .smaller = true := by decide
def e2422372942134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372942134 : Closed e2422372942134 ∧ code e2422372942134 = 11218465964342 := by decide
theorem cert_e2422372942134 : check e2422372942134 [[],[]] .smaller = true := by decide
def e2422372942138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372942138 : Closed e2422372942138 ∧ code e2422372942138 = 11218465964346 := by decide
theorem cert_e2422372942138 : check e2422372942138 [[],[]] .smaller = true := by decide
def e2422372942302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2422372942302 : Closed e2422372942302 ∧ code e2422372942302 = 11218465964510 := by decide
theorem cert_e2422372942302 : check e2422372942302 [[],[]] .three = true := by decide
def e2422372942318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2422372942318 : Closed e2422372942318 ∧ code e2422372942318 = 11218465964526 := by decide
theorem cert_e2422372942318 : check e2422372942318 [[],[]] .smaller = true := by decide
def e2422372942326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2422372942326 : Closed e2422372942326 ∧ code e2422372942326 = 11218465964534 := by decide
theorem cert_e2422372942326 : check e2422372942326 [[],[]] .smaller = true := by decide
def e2422372942330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 5)))) (.var 0)))))))
theorem wire_e2422372942330 : Closed e2422372942330 ∧ code e2422372942330 = 11218465964538 := by decide
theorem cert_e2422372942330 : check e2422372942330 [[],[]] .three = true := by decide
def e2422372942686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e2422372942686 : Closed e2422372942686 ∧ code e2422372942686 = 11218465964894 := by decide
theorem cert_e2422372942686 : check e2422372942686 [[],[]] .three = true := by decide
def e2422372942710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2422372942710 : Closed e2422372942710 ∧ code e2422372942710 = 11218465964918 := by decide
theorem cert_e2422372942710 : check e2422372942710 [[],[]] .smaller = true := by decide
def e2422372942774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e2422372942774 : Closed e2422372942774 ∧ code e2422372942774 = 11218465964982 := by decide
theorem cert_e2422372942774 : check e2422372942774 [[],[]] .smaller = true := by decide
def e2422372942778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2422372942778 : Closed e2422372942778 ∧ code e2422372942778 = 11218465964986 := by decide
theorem cert_e2422372942778 : check e2422372942778 [[],[]] .smaller = true := by decide
def e2422372942806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2422372942806 : Closed e2422372942806 ∧ code e2422372942806 = 11218465965014 := by decide
theorem cert_e2422372942806 : check e2422372942806 [[],[]] .smaller = true := by decide
def e2422372942810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2422372942810 : Closed e2422372942810 ∧ code e2422372942810 = 11218465965018 := by decide
theorem cert_e2422372942810 : check e2422372942810 [[],[]] .smaller = true := by decide
def e2422372943070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372943070 : Closed e2422372943070 ∧ code e2422372943070 = 11218465965278 := by decide
theorem cert_e2422372943070 : check e2422372943070 [[],[]] .three = true := by decide
def e2422372943086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372943086 : Closed e2422372943086 ∧ code e2422372943086 = 11218465965294 := by decide
theorem cert_e2422372943086 : check e2422372943086 [[],[]] .smaller = true := by decide
def e2422372943094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372943094 : Closed e2422372943094 ∧ code e2422372943094 = 11218465965302 := by decide
theorem cert_e2422372943094 : check e2422372943094 [[],[]] .smaller = true := by decide
def e2422372943098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372943098 : Closed e2422372943098 ∧ code e2422372943098 = 11218465965306 := by decide
theorem cert_e2422372943098 : check e2422372943098 [[],[]] .three = true := by decide
def e2422372943422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 4))))))))
theorem wire_e2422372943422 : Closed e2422372943422 ∧ code e2422372943422 = 11218465965630 := by decide
theorem cert_e2422372943422 : check e2422372943422 [[],[]] .three = true := by decide
def e2422372943478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372943478 : Closed e2422372943478 ∧ code e2422372943478 = 11218465965686 := by decide
theorem cert_e2422372943478 : check e2422372943478 [[],[]] .smaller = true := by decide
def e2422372943646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 3))))))))
theorem wire_e2422372943646 : Closed e2422372943646 ∧ code e2422372943646 = 11218465965854 := by decide
theorem cert_e2422372943646 : check e2422372943646 [[],[]] .smaller = true := by decide
def e2422372943670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372943670 : Closed e2422372943670 ∧ code e2422372943670 = 11218465965878 := by decide
theorem cert_e2422372943670 : check e2422372943670 [[],[]] .smaller = true := by decide
def e2422372943674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372943674 : Closed e2422372943674 ∧ code e2422372943674 = 11218465965882 := by decide
theorem cert_e2422372943674 : check e2422372943674 [[],[]] .smaller = true := by decide
def e2422372943758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 3))) (.lam (.var 2))))))))
theorem wire_e2422372943758 : Closed e2422372943758 ∧ code e2422372943758 = 11218465965966 := by decide
theorem cert_e2422372943758 : check e2422372943758 [[],[]] .smaller = true := by decide
def e2422372943814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 4))) (.lam (.var 1))))))))
theorem wire_e2422372943814 : Closed e2422372943814 ∧ code e2422372943814 = 11218465966022 := by decide
theorem cert_e2422372943814 : check e2422372943814 [[],[]] .three = true := by decide
def e2422372943838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 4))) (.var 3)))))))
theorem wire_e2422372943838 : Closed e2422372943838 ∧ code e2422372943838 = 11218465966046 := by decide
theorem cert_e2422372943838 : check e2422372943838 [[],[]] .three = true := by decide
def e2422372944726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2422372944726 : Closed e2422372944726 ∧ code e2422372944726 = 11218465966934 := by decide
theorem cert_e2422372944726 : check e2422372944726 [[],[]] .smaller = true := by decide
def e2422372944730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2422372944730 : Closed e2422372944730 ∧ code e2422372944730 = 11218465966938 := by decide
theorem cert_e2422372944730 : check e2422372944730 [[],[]] .smaller = true := by decide
def e2422372944746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2422372944746 : Closed e2422372944746 ∧ code e2422372944746 = 11218465966954 := by decide
theorem cert_e2422372944746 : check e2422372944746 [[],[]] .smaller = true := by decide
def e2422372944810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422372944810 : Closed e2422372944810 ∧ code e2422372944810 = 11218465967018 := by decide
theorem cert_e2422372944810 : check e2422372944810 [[],[]] .smaller = true := by decide
def e2422372944918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422372944918 : Closed e2422372944918 ∧ code e2422372944918 = 11218465967126 := by decide
theorem cert_e2422372944918 : check e2422372944918 [[],[]] .smaller = true := by decide
def e2422372944990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422372944990 : Closed e2422372944990 ∧ code e2422372944990 = 11218465967198 := by decide
theorem cert_e2422372944990 : check e2422372944990 [[],[]] .three = true := by decide
def e2422372945014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422372945014 : Closed e2422372945014 ∧ code e2422372945014 = 11218465967222 := by decide
theorem cert_e2422372945014 : check e2422372945014 [[],[]] .smaller = true := by decide
def e2422372945110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2422372945110 : Closed e2422372945110 ∧ code e2422372945110 = 11218465967318 := by decide
theorem cert_e2422372945110 : check e2422372945110 [[],[]] .smaller = true := by decide
def e2422372945114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422372945114 : Closed e2422372945114 ∧ code e2422372945114 = 11218465967322 := by decide
theorem cert_e2422372945114 : check e2422372945114 [[],[]] .smaller = true := by decide
def e2422372945130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422372945130 : Closed e2422372945130 ∧ code e2422372945130 = 11218465967338 := by decide
theorem cert_e2422372945130 : check e2422372945130 [[],[]] .smaller = true := by decide
def e2422372945206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372945206 : Closed e2422372945206 ∧ code e2422372945206 = 11218465967414 := by decide
theorem cert_e2422372945206 : check e2422372945206 [[],[]] .smaller = true := by decide
def e2422372945210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372945210 : Closed e2422372945210 ∧ code e2422372945210 = 11218465967418 := by decide
theorem cert_e2422372945210 : check e2422372945210 [[],[]] .smaller = true := by decide
def e2422372945282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372945282 : Closed e2422372945282 ∧ code e2422372945282 = 11218465967490 := by decide
theorem cert_e2422372945282 : check e2422372945282 [[],[]] .smaller = true := by decide
def e2422372945294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422372945294 : Closed e2422372945294 ∧ code e2422372945294 = 11218465967502 := by decide
theorem cert_e2422372945294 : check e2422372945294 [[],[]] .smaller = true := by decide
def e2422372945306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372945306 : Closed e2422372945306 ∧ code e2422372945306 = 11218465967514 := by decide
theorem cert_e2422372945306 : check e2422372945306 [[],[]] .smaller = true := by decide
def e2422372945374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2422372945374 : Closed e2422372945374 ∧ code e2422372945374 = 11218465967582 := by decide
theorem cert_e2422372945374 : check e2422372945374 [[],[]] .three = true := by decide
def e2422372945378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422372945378 : Closed e2422372945378 ∧ code e2422372945378 = 11218465967586 := by decide
theorem cert_e2422372945378 : check e2422372945378 [[],[]] .three = true := by decide
def e2422372945390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2422372945390 : Closed e2422372945390 ∧ code e2422372945390 = 11218465967598 := by decide
theorem cert_e2422372945390 : check e2422372945390 [[],[]] .three = true := by decide
def e2422372945418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422372945418 : Closed e2422372945418 ∧ code e2422372945418 = 11218465967626 := by decide
theorem cert_e2422372945418 : check e2422372945418 [[],[]] .smaller = true := by decide
def e2422372945454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372945454 : Closed e2422372945454 ∧ code e2422372945454 = 11218465967662 := by decide
theorem cert_e2422372945454 : check e2422372945454 [[],[]] .smaller = true := by decide
def e2422372945462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422372945462 : Closed e2422372945462 ∧ code e2422372945462 = 11218465967670 := by decide
theorem cert_e2422372945462 : check e2422372945462 [[],[]] .smaller = true := by decide
def e2422372945466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422372945466 : Closed e2422372945466 ∧ code e2422372945466 = 11218465967674 := by decide
theorem cert_e2422372945466 : check e2422372945466 [[],[]] .smaller = true := by decide
def e2422372945514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422372945514 : Closed e2422372945514 ∧ code e2422372945514 = 11218465967722 := by decide
theorem cert_e2422372945514 : check e2422372945514 [[],[]] .smaller = true := by decide
def e2422372945538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372945538 : Closed e2422372945538 ∧ code e2422372945538 = 11218465967746 := by decide
theorem cert_e2422372945538 : check e2422372945538 [[],[]] .smaller = true := by decide
def e2422372945550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422372945550 : Closed e2422372945550 ∧ code e2422372945550 = 11218465967758 := by decide
theorem cert_e2422372945550 : check e2422372945550 [[],[]] .smaller = true := by decide
def e2422372945562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372945562 : Closed e2422372945562 ∧ code e2422372945562 = 11218465967770 := by decide
theorem cert_e2422372945562 : check e2422372945562 [[],[]] .smaller = true := by decide
def e2422372945606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422372945606 : Closed e2422372945606 ∧ code e2422372945606 = 11218465967814 := by decide
theorem cert_e2422372945606 : check e2422372945606 [[],[]] .smaller = true := by decide
def e2422372945630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2422372945630 : Closed e2422372945630 ∧ code e2422372945630 = 11218465967838 := by decide
theorem cert_e2422372945630 : check e2422372945630 [[],[]] .three = true := by decide
def e2422372945634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422372945634 : Closed e2422372945634 ∧ code e2422372945634 = 11218465967842 := by decide
theorem cert_e2422372945634 : check e2422372945634 [[],[]] .smaller = true := by decide
def e2422372945646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 2)))))))
theorem wire_e2422372945646 : Closed e2422372945646 ∧ code e2422372945646 = 11218465967854 := by decide
theorem cert_e2422372945646 : check e2422372945646 [[],[]] .smaller = true := by decide
def e2422372945654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2422372945654 : Closed e2422372945654 ∧ code e2422372945654 = 11218465967862 := by decide
theorem cert_e2422372945654 : check e2422372945654 [[],[]] .three = true := by decide
def e2422372945686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372945686 : Closed e2422372945686 ∧ code e2422372945686 = 11218465967894 := by decide
theorem cert_e2422372945686 : check e2422372945686 [[],[]] .smaller = true := by decide
def e2422372945758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2422372945758 : Closed e2422372945758 ∧ code e2422372945758 = 11218465967966 := by decide
theorem cert_e2422372945758 : check e2422372945758 [[],[]] .three = true := by decide
def e2422372945762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422372945762 : Closed e2422372945762 ∧ code e2422372945762 = 11218465967970 := by decide
theorem cert_e2422372945762 : check e2422372945762 [[],[]] .smaller = true := by decide
def e2422372945774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 2)))))))
theorem wire_e2422372945774 : Closed e2422372945774 ∧ code e2422372945774 = 11218465967982 := by decide
theorem cert_e2422372945774 : check e2422372945774 [[],[]] .smaller = true := by decide
def e2422372945782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 2))) (.var 1)))))))
theorem wire_e2422372945782 : Closed e2422372945782 ∧ code e2422372945782 = 11218465967990 := by decide
theorem cert_e2422372945782 : check e2422372945782 [[],[]] .smaller = true := by decide
def e2422372945786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2422372945786 : Closed e2422372945786 ∧ code e2422372945786 = 11218465967994 := by decide
theorem cert_e2422372945786 : check e2422372945786 [[],[]] .three = true := by decide
def e2422372945802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372945802 : Closed e2422372945802 ∧ code e2422372945802 = 11218465968010 := by decide
theorem cert_e2422372945802 : check e2422372945802 [[],[]] .three = true := by decide
def e2422372945826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422372945826 : Closed e2422372945826 ∧ code e2422372945826 = 11218465968034 := by decide
theorem cert_e2422372945826 : check e2422372945826 [[],[]] .three = true := by decide
def e2422372945838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2422372945838 : Closed e2422372945838 ∧ code e2422372945838 = 11218465968046 := by decide
theorem cert_e2422372945838 : check e2422372945838 [[],[]] .three = true := by decide
def e2422372945846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2422372945846 : Closed e2422372945846 ∧ code e2422372945846 = 11218465968054 := by decide
theorem cert_e2422372945846 : check e2422372945846 [[],[]] .three = true := by decide
def e2422372945850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2422372945850 : Closed e2422372945850 ∧ code e2422372945850 = 11218465968058 := by decide
theorem cert_e2422372945850 : check e2422372945850 [[],[]] .three = true := by decide
def e2422372946046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 5)))))))))
theorem wire_e2422372946046 : Closed e2422372946046 ∧ code e2422372946046 = 11218465968254 := by decide
theorem cert_e2422372946046 : check e2422372946046 [[],[]] .three = true := by decide
def e2422372946158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422372946158 : Closed e2422372946158 ∧ code e2422372946158 = 11218465968366 := by decide
theorem cert_e2422372946158 : check e2422372946158 [[],[]] .smaller = true := by decide
def e2422372946166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422372946166 : Closed e2422372946166 ∧ code e2422372946166 = 11218465968374 := by decide
theorem cert_e2422372946166 : check e2422372946166 [[],[]] .smaller = true := by decide
def e2422372946646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422372946646 : Closed e2422372946646 ∧ code e2422372946646 = 11218465968854 := by decide
theorem cert_e2422372946646 : check e2422372946646 [[],[]] .smaller = true := by decide
def e2422372946650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422372946650 : Closed e2422372946650 ∧ code e2422372946650 = 11218465968858 := by decide
theorem cert_e2422372946650 : check e2422372946650 [[],[]] .smaller = true := by decide
def e2422372946666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422372946666 : Closed e2422372946666 ∧ code e2422372946666 = 11218465968874 := by decide
theorem cert_e2422372946666 : check e2422372946666 [[],[]] .smaller = true := by decide
def e2422372946742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422372946742 : Closed e2422372946742 ∧ code e2422372946742 = 11218465968950 := by decide
theorem cert_e2422372946742 : check e2422372946742 [[],[]] .smaller = true := by decide
def e2422372946746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422372946746 : Closed e2422372946746 ∧ code e2422372946746 = 11218465968954 := by decide
theorem cert_e2422372946746 : check e2422372946746 [[],[]] .smaller = true := by decide
def e2422372946818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e2422372946818 : Closed e2422372946818 ∧ code e2422372946818 = 11218465969026 := by decide
theorem cert_e2422372946818 : check e2422372946818 [[],[]] .smaller = true := by decide
end Blc.Floor43
