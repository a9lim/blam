import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262377782190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2262377782190 : Closed e2262377782190 ∧ code e2262377782190 = 11058470804398 := by decide
theorem cert_e2262377782190 : check e2262377782190 [[],[.under]] .three = true := by decide
def e2262377782198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2262377782198 : Closed e2262377782198 ∧ code e2262377782198 = 11058470804406 := by decide
theorem cert_e2262377782198 : check e2262377782198 [[],[.under]] .three = true := by decide
def e2262377782202 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2262377782202 : Closed e2262377782202 ∧ code e2262377782202 = 11058470804410 := by decide
theorem cert_e2262377782202 : check e2262377782202 [[],[.under]] .three = true := by decide
def e2262377782638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2262377782638 : Closed e2262377782638 ∧ code e2262377782638 = 11058470804846 := by decide
theorem cert_e2262377782638 : check e2262377782638 [[],[.under]] .three = true := by decide
def e2262377782646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2262377782646 : Closed e2262377782646 ∧ code e2262377782646 = 11058470804854 := by decide
theorem cert_e2262377782646 : check e2262377782646 [[],[.under]] .three = true := by decide
def e2262377782702 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2262377782702 : Closed e2262377782702 ∧ code e2262377782702 = 11058470804910 := by decide
theorem cert_e2262377782702 : check e2262377782702 [[],[.under]] .three = true := by decide
def e2262377782714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2262377782714 : Closed e2262377782714 ∧ code e2262377782714 = 11058470804922 := by decide
theorem cert_e2262377782714 : check e2262377782714 [[],[.under]] .three = true := by decide
def e2262377782742 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2262377782742 : Closed e2262377782742 ∧ code e2262377782742 = 11058470804950 := by decide
theorem cert_e2262377782742 : check e2262377782742 [[],[.under]] .three = true := by decide
def e2262377782746 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2262377782746 : Closed e2262377782746 ∧ code e2262377782746 = 11058470804954 := by decide
theorem cert_e2262377782746 : check e2262377782746 [[],[.under]] .three = true := by decide
def e2262377782826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2262377782826 : Closed e2262377782826 ∧ code e2262377782826 = 11058470805034 := by decide
theorem cert_e2262377782826 : check e2262377782826 [[],[.under]] .three = true := by decide
def e2262377782922 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377782922 : Closed e2262377782922 ∧ code e2262377782922 = 11058470805130 := by decide
theorem cert_e2262377782922 : check e2262377782922 [[],[.under]] .three = true := by decide
def e2262377782946 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377782946 : Closed e2262377782946 ∧ code e2262377782946 = 11058470805154 := by decide
theorem cert_e2262377782946 : check e2262377782946 [[],[.under]] .three = true := by decide
def e2262377782958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2262377782958 : Closed e2262377782958 ∧ code e2262377782958 = 11058470805166 := by decide
theorem cert_e2262377782958 : check e2262377782958 [[],[.under]] .three = true := by decide
def e2262377782966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2262377782966 : Closed e2262377782966 ∧ code e2262377782966 = 11058470805174 := by decide
theorem cert_e2262377782966 : check e2262377782966 [[],[.under]] .three = true := by decide
def e2262377782970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2262377782970 : Closed e2262377782970 ∧ code e2262377782970 = 11058470805178 := by decide
theorem cert_e2262377782970 : check e2262377782970 [[],[.under]] .three = true := by decide
def e2262377782998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2262377782998 : Closed e2262377782998 ∧ code e2262377782998 = 11058470805206 := by decide
theorem cert_e2262377782998 : check e2262377782998 [[],[.under]] .three = true := by decide
def e2262377783002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2262377783002 : Closed e2262377783002 ∧ code e2262377783002 = 11058470805210 := by decide
theorem cert_e2262377783002 : check e2262377783002 [[],[.under]] .three = true := by decide
def e2262377783018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2262377783018 : Closed e2262377783018 ∧ code e2262377783018 = 11058470805226 := by decide
theorem cert_e2262377783018 : check e2262377783018 [[],[.under]] .three = true := by decide
def e2262377783534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2262377783534 : Closed e2262377783534 ∧ code e2262377783534 = 11058470805742 := by decide
theorem cert_e2262377783534 : check e2262377783534 [[],[.under]] .three = true := by decide
def e2262377783546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2262377783546 : Closed e2262377783546 ∧ code e2262377783546 = 11058470805754 := by decide
theorem cert_e2262377783546 : check e2262377783546 [[],[.under]] .three = true := by decide
def e2262377783726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2262377783726 : Closed e2262377783726 ∧ code e2262377783726 = 11058470805934 := by decide
theorem cert_e2262377783726 : check e2262377783726 [[],[.under]] .three = true := by decide
def e2262377783918 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377783918 : Closed e2262377783918 ∧ code e2262377783918 = 11058470806126 := by decide
theorem cert_e2262377783918 : check e2262377783918 [[],[.under]] .three = true := by decide
def e2262377783930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377783930 : Closed e2262377783930 ∧ code e2262377783930 = 11058470806138 := by decide
theorem cert_e2262377783930 : check e2262377783930 [[],[.under]] .three = true := by decide
def e2262377784094 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2262377784094 : Closed e2262377784094 ∧ code e2262377784094 = 11058470806302 := by decide
theorem cert_e2262377784094 : check e2262377784094 [[],[.under]] .three = true := by decide
def e2262377784262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2262377784262 : Closed e2262377784262 ∧ code e2262377784262 = 11058470806470 := by decide
theorem cert_e2262377784262 : check e2262377784262 [[],[.under]] .three = true := by decide
def e2262377784878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2262377784878 : Closed e2262377784878 ∧ code e2262377784878 = 11058470807086 := by decide
theorem cert_e2262377784878 : check e2262377784878 [[],[.under]] .three = true := by decide
def e2262377785058 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2262377785058 : Closed e2262377785058 ∧ code e2262377785058 = 11058470807266 := by decide
theorem cert_e2262377785058 : check e2262377785058 [[],[.under]] .three = true := by decide
def e2262377785070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2262377785070 : Closed e2262377785070 ∧ code e2262377785070 = 11058470807278 := by decide
theorem cert_e2262377785070 : check e2262377785070 [[],[.under]] .three = true := by decide
def e2262377785198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2262377785198 : Closed e2262377785198 ∧ code e2262377785198 = 11058470807406 := by decide
theorem cert_e2262377785198 : check e2262377785198 [[],[.under]] .three = true := by decide
def e2262377785206 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2262377785206 : Closed e2262377785206 ∧ code e2262377785206 = 11058470807414 := by decide
theorem cert_e2262377785206 : check e2262377785206 [[],[.under]] .three = true := by decide
def e2262377785226 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262377785226 : Closed e2262377785226 ∧ code e2262377785226 = 11058470807434 := by decide
theorem cert_e2262377785226 : check e2262377785226 [[],[.under]] .three = true := by decide
def e2262377785250 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262377785250 : Closed e2262377785250 ∧ code e2262377785250 = 11058470807458 := by decide
theorem cert_e2262377785250 : check e2262377785250 [[],[.under]] .three = true := by decide
def e2262377785262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2262377785262 : Closed e2262377785262 ∧ code e2262377785262 = 11058470807470 := by decide
theorem cert_e2262377785262 : check e2262377785262 [[],[.under]] .three = true := by decide
def e2262377785270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2262377785270 : Closed e2262377785270 ∧ code e2262377785270 = 11058470807478 := by decide
theorem cert_e2262377785270 : check e2262377785270 [[],[.under]] .three = true := by decide
def e2262377785274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2262377785274 : Closed e2262377785274 ∧ code e2262377785274 = 11058470807482 := by decide
theorem cert_e2262377785274 : check e2262377785274 [[],[.under]] .three = true := by decide
def e2262377785406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2262377785406 : Closed e2262377785406 ∧ code e2262377785406 = 11058470807614 := by decide
theorem cert_e2262377785406 : check e2262377785406 [[],[.under]] .three = true := by decide
def e2262377785826 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2262377785826 : Closed e2262377785826 ∧ code e2262377785826 = 11058470808034 := by decide
theorem cert_e2262377785826 : check e2262377785826 [[],[.under]] .three = true := by decide
def e2262377785838 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2262377785838 : Closed e2262377785838 ∧ code e2262377785838 = 11058470808046 := by decide
theorem cert_e2262377785838 : check e2262377785838 [[],[.under]] .three = true := by decide
def e2262377786606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377786606 : Closed e2262377786606 ∧ code e2262377786606 = 11058470808814 := by decide
theorem cert_e2262377786606 : check e2262377786606 [[],[.under]] .three = true := by decide
def e2262377786614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377786614 : Closed e2262377786614 ∧ code e2262377786614 = 11058470808822 := by decide
theorem cert_e2262377786614 : check e2262377786614 [[],[.under]] .three = true := by decide
def e2262377786894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377786894 : Closed e2262377786894 ∧ code e2262377786894 = 11058470809102 := by decide
theorem cert_e2262377786894 : check e2262377786894 [[],[.under]] .three = true := by decide
def e2262377786906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377786906 : Closed e2262377786906 ∧ code e2262377786906 = 11058470809114 := by decide
theorem cert_e2262377786906 : check e2262377786906 [[],[.under]] .three = true := by decide
def e2262377786978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377786978 : Closed e2262377786978 ∧ code e2262377786978 = 11058470809186 := by decide
theorem cert_e2262377786978 : check e2262377786978 [[],[.under]] .three = true := by decide
def e2262377786990 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377786990 : Closed e2262377786990 ∧ code e2262377786990 = 11058470809198 := by decide
theorem cert_e2262377786990 : check e2262377786990 [[],[.under]] .three = true := by decide
def e2262377786998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377786998 : Closed e2262377786998 ∧ code e2262377786998 = 11058470809206 := by decide
theorem cert_e2262377786998 : check e2262377786998 [[],[.under]] .three = true := by decide
def e2262377787002 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377787002 : Closed e2262377787002 ∧ code e2262377787002 = 11058470809210 := by decide
theorem cert_e2262377787002 : check e2262377787002 [[],[.under]] .three = true := by decide
def e2262377788270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2262377788270 : Closed e2262377788270 ∧ code e2262377788270 = 11058470810478 := by decide
theorem cert_e2262377788270 : check e2262377788270 [[],[.under]] .three = true := by decide
def e2262377788278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2262377788278 : Closed e2262377788278 ∧ code e2262377788278 = 11058470810486 := by decide
theorem cert_e2262377788278 : check e2262377788278 [[],[.under]] .three = true := by decide
def e2262377788334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2262377788334 : Closed e2262377788334 ∧ code e2262377788334 = 11058470810542 := by decide
theorem cert_e2262377788334 : check e2262377788334 [[],[.under]] .three = true := by decide
def e2262377788346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2262377788346 : Closed e2262377788346 ∧ code e2262377788346 = 11058470810554 := by decide
theorem cert_e2262377788346 : check e2262377788346 [[],[.under]] .three = true := by decide
def e2262377788374 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2262377788374 : Closed e2262377788374 ∧ code e2262377788374 = 11058470810582 := by decide
theorem cert_e2262377788374 : check e2262377788374 [[],[.under]] .three = true := by decide
def e2262377788378 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2262377788378 : Closed e2262377788378 ∧ code e2262377788378 = 11058470810586 := by decide
theorem cert_e2262377788378 : check e2262377788378 [[],[.under]] .three = true := by decide
def e2262377788654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377788654 : Closed e2262377788654 ∧ code e2262377788654 = 11058470810862 := by decide
theorem cert_e2262377788654 : check e2262377788654 [[],[.under]] .three = true := by decide
def e2262377788662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377788662 : Closed e2262377788662 ∧ code e2262377788662 = 11058470810870 := by decide
theorem cert_e2262377788662 : check e2262377788662 [[],[.under]] .three = true := by decide
def e2262377789038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377789038 : Closed e2262377789038 ∧ code e2262377789038 = 11058470811246 := by decide
theorem cert_e2262377789038 : check e2262377789038 [[],[.under]] .three = true := by decide
def e2262377789050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377789050 : Closed e2262377789050 ∧ code e2262377789050 = 11058470811258 := by decide
theorem cert_e2262377789050 : check e2262377789050 [[],[.under]] .three = true := by decide
def e2262377789238 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377789238 : Closed e2262377789238 ∧ code e2262377789238 = 11058470811446 := by decide
theorem cert_e2262377789238 : check e2262377789238 [[],[.under]] .three = true := by decide
def e2262377789242 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377789242 : Closed e2262377789242 ∧ code e2262377789242 = 11058470811450 := by decide
theorem cert_e2262377789242 : check e2262377789242 [[],[.under]] .three = true := by decide
def e2262377789498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2262377789498 : Closed e2262377789498 ∧ code e2262377789498 = 11058470811706 := by decide
theorem cert_e2262377789498 : check e2262377789498 [[],[.under]] .three = true := by decide
def e2262377789546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2262377789546 : Closed e2262377789546 ∧ code e2262377789546 = 11058470811754 := by decide
theorem cert_e2262377789546 : check e2262377789546 [[],[.under]] .three = true := by decide
def e2262377789594 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2262377789594 : Closed e2262377789594 ∧ code e2262377789594 = 11058470811802 := by decide
theorem cert_e2262377789594 : check e2262377789594 [[],[.under]] .three = true := by decide
def e2262377789638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2262377789638 : Closed e2262377789638 ∧ code e2262377789638 = 11058470811846 := by decide
theorem cert_e2262377789638 : check e2262377789638 [[],[.under]] .three = true := by decide
def e2262377789834 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262377789834 : Closed e2262377789834 ∧ code e2262377789834 = 11058470812042 := by decide
theorem cert_e2262377789834 : check e2262377789834 [[],[.under]] .three = true := by decide
def e2262377789858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262377789858 : Closed e2262377789858 ∧ code e2262377789858 = 11058470812066 := by decide
theorem cert_e2262377789858 : check e2262377789858 [[],[.under]] .three = true := by decide
def e2262377789870 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2262377789870 : Closed e2262377789870 ∧ code e2262377789870 = 11058470812078 := by decide
theorem cert_e2262377789870 : check e2262377789870 [[],[.under]] .three = true := by decide
def e2262377789878 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2262377789878 : Closed e2262377789878 ∧ code e2262377789878 = 11058470812086 := by decide
theorem cert_e2262377789878 : check e2262377789878 [[],[.under]] .three = true := by decide
def e2262377789882 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2262377789882 : Closed e2262377789882 ∧ code e2262377789882 = 11058470812090 := by decide
theorem cert_e2262377789882 : check e2262377789882 [[],[.under]] .three = true := by decide
def e2262377789910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2262377789910 : Closed e2262377789910 ∧ code e2262377789910 = 11058470812118 := by decide
theorem cert_e2262377789910 : check e2262377789910 [[],[.under]] .three = true := by decide
def e2262377789914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2262377789914 : Closed e2262377789914 ∧ code e2262377789914 = 11058470812122 := by decide
theorem cert_e2262377789914 : check e2262377789914 [[],[.under]] .three = true := by decide
def e2262377789930 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2262377789930 : Closed e2262377789930 ∧ code e2262377789930 = 11058470812138 := by decide
theorem cert_e2262377789930 : check e2262377789930 [[],[.under]] .three = true := by decide
def e2262377789966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377789966 : Closed e2262377789966 ∧ code e2262377789966 = 11058470812174 := by decide
theorem cert_e2262377789966 : check e2262377789966 [[],[.under]] .three = true := by decide
def e2262377789978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377789978 : Closed e2262377789978 ∧ code e2262377789978 = 11058470812186 := by decide
theorem cert_e2262377789978 : check e2262377789978 [[],[.under]] .three = true := by decide
def e2262377790050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377790050 : Closed e2262377790050 ∧ code e2262377790050 = 11058470812258 := by decide
theorem cert_e2262377790050 : check e2262377790050 [[],[.under]] .three = true := by decide
def e2262377790062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377790062 : Closed e2262377790062 ∧ code e2262377790062 = 11058470812270 := by decide
theorem cert_e2262377790062 : check e2262377790062 [[],[.under]] .three = true := by decide
def e2262377790070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377790070 : Closed e2262377790070 ∧ code e2262377790070 = 11058470812278 := by decide
theorem cert_e2262377790070 : check e2262377790070 [[],[.under]] .three = true := by decide
def e2262377790074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377790074 : Closed e2262377790074 ∧ code e2262377790074 = 11058470812282 := by decide
theorem cert_e2262377790074 : check e2262377790074 [[],[.under]] .three = true := by decide
def e2262377790262 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377790262 : Closed e2262377790262 ∧ code e2262377790262 = 11058470812470 := by decide
theorem cert_e2262377790262 : check e2262377790262 [[],[.under]] .three = true := by decide
def e2262377790266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377790266 : Closed e2262377790266 ∧ code e2262377790266 = 11058470812474 := by decide
theorem cert_e2262377790266 : check e2262377790266 [[],[.under]] .three = true := by decide
def e2262377790362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2262377790362 : Closed e2262377790362 ∧ code e2262377790362 = 11058470812570 := by decide
theorem cert_e2262377790362 : check e2262377790362 [[],[.under]] .three = true := by decide
def e2262377793502 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2262377793502 : Closed e2262377793502 ∧ code e2262377793502 = 11058470815710 := by decide
theorem cert_e2262377793502 : check e2262377793502 [[],[.under]] .three = true := by decide
def e2262377797166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2262377797166 : Closed e2262377797166 ∧ code e2262377797166 = 11058470819374 := by decide
theorem cert_e2262377797166 : check e2262377797166 [[],[.under]] .three = true := by decide
def e2262377797346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2262377797346 : Closed e2262377797346 ∧ code e2262377797346 = 11058470819554 := by decide
theorem cert_e2262377797346 : check e2262377797346 [[],[.under]] .three = true := by decide
def e2262377797358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2262377797358 : Closed e2262377797358 ∧ code e2262377797358 = 11058470819566 := by decide
theorem cert_e2262377797358 : check e2262377797358 [[],[.under]] .three = true := by decide
def e2262377797486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2262377797486 : Closed e2262377797486 ∧ code e2262377797486 = 11058470819694 := by decide
theorem cert_e2262377797486 : check e2262377797486 [[],[.under]] .three = true := by decide
def e2262377797494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2262377797494 : Closed e2262377797494 ∧ code e2262377797494 = 11058470819702 := by decide
theorem cert_e2262377797494 : check e2262377797494 [[],[.under]] .three = true := by decide
def e2262377797514 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262377797514 : Closed e2262377797514 ∧ code e2262377797514 = 11058470819722 := by decide
theorem cert_e2262377797514 : check e2262377797514 [[],[.under]] .three = true := by decide
def e2262377797538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262377797538 : Closed e2262377797538 ∧ code e2262377797538 = 11058470819746 := by decide
theorem cert_e2262377797538 : check e2262377797538 [[],[.under]] .three = true := by decide
def e2262377797550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2262377797550 : Closed e2262377797550 ∧ code e2262377797550 = 11058470819758 := by decide
theorem cert_e2262377797550 : check e2262377797550 [[],[.under]] .three = true := by decide
def e2262377797558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2262377797558 : Closed e2262377797558 ∧ code e2262377797558 = 11058470819766 := by decide
theorem cert_e2262377797558 : check e2262377797558 [[],[.under]] .three = true := by decide
def e2262377797562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2262377797562 : Closed e2262377797562 ∧ code e2262377797562 = 11058470819770 := by decide
theorem cert_e2262377797562 : check e2262377797562 [[],[.under]] .three = true := by decide
def e2262377797694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2262377797694 : Closed e2262377797694 ∧ code e2262377797694 = 11058470819902 := by decide
theorem cert_e2262377797694 : check e2262377797694 [[],[.under]] .three = true := by decide
def e2262377798114 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2262377798114 : Closed e2262377798114 ∧ code e2262377798114 = 11058470820322 := by decide
theorem cert_e2262377798114 : check e2262377798114 [[],[.under]] .three = true := by decide
def e2262377798126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262377798126 : Closed e2262377798126 ∧ code e2262377798126 = 11058470820334 := by decide
theorem cert_e2262377798126 : check e2262377798126 [[],[.under]] .three = true := by decide
def e2262377798894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377798894 : Closed e2262377798894 ∧ code e2262377798894 = 11058470821102 := by decide
theorem cert_e2262377798894 : check e2262377798894 [[],[.under]] .three = true := by decide
def e2262377798902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377798902 : Closed e2262377798902 ∧ code e2262377798902 = 11058470821110 := by decide
theorem cert_e2262377798902 : check e2262377798902 [[],[.under]] .three = true := by decide
def e2262377799182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2262377799182 : Closed e2262377799182 ∧ code e2262377799182 = 11058470821390 := by decide
theorem cert_e2262377799182 : check e2262377799182 [[],[.under]] .three = true := by decide
def e2262377799194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2262377799194 : Closed e2262377799194 ∧ code e2262377799194 = 11058470821402 := by decide
theorem cert_e2262377799194 : check e2262377799194 [[],[.under]] .three = true := by decide
def e2262377799266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262377799266 : Closed e2262377799266 ∧ code e2262377799266 = 11058470821474 := by decide
theorem cert_e2262377799266 : check e2262377799266 [[],[.under]] .three = true := by decide
def e2262377799278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377799278 : Closed e2262377799278 ∧ code e2262377799278 = 11058470821486 := by decide
theorem cert_e2262377799278 : check e2262377799278 [[],[.under]] .three = true := by decide
def e2262377799286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262377799286 : Closed e2262377799286 ∧ code e2262377799286 = 11058470821494 := by decide
theorem cert_e2262377799286 : check e2262377799286 [[],[.under]] .three = true := by decide
def e2262377799290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377799290 : Closed e2262377799290 ∧ code e2262377799290 = 11058470821498 := by decide
theorem cert_e2262377799290 : check e2262377799290 [[],[.under]] .three = true := by decide
def e2262377810798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262377810798 : Closed e2262377810798 ∧ code e2262377810798 = 11058470833006 := by decide
theorem cert_e2262377810798 : check e2262377810798 [[],[.under]] .three = true := by decide
def e2262377810806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262377810806 : Closed e2262377810806 ∧ code e2262377810806 = 11058470833014 := by decide
theorem cert_e2262377810806 : check e2262377810806 [[],[.under]] .three = true := by decide
def e2262377810862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262377810862 : Closed e2262377810862 ∧ code e2262377810862 = 11058470833070 := by decide
theorem cert_e2262377810862 : check e2262377810862 [[],[.under]] .three = true := by decide
def e2262377810874 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262377810874 : Closed e2262377810874 ∧ code e2262377810874 = 11058470833082 := by decide
theorem cert_e2262377810874 : check e2262377810874 [[],[.under]] .three = true := by decide
def e2262377810902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262377810902 : Closed e2262377810902 ∧ code e2262377810902 = 11058470833110 := by decide
theorem cert_e2262377810902 : check e2262377810902 [[],[.under]] .three = true := by decide
def e2262377810906 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262377810906 : Closed e2262377810906 ∧ code e2262377810906 = 11058470833114 := by decide
theorem cert_e2262377810906 : check e2262377810906 [[],[.under]] .three = true := by decide
def e2262377811182 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377811182 : Closed e2262377811182 ∧ code e2262377811182 = 11058470833390 := by decide
theorem cert_e2262377811182 : check e2262377811182 [[],[.under]] .three = true := by decide
def e2262377811190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377811190 : Closed e2262377811190 ∧ code e2262377811190 = 11058470833398 := by decide
theorem cert_e2262377811190 : check e2262377811190 [[],[.under]] .three = true := by decide
def e2262377811566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377811566 : Closed e2262377811566 ∧ code e2262377811566 = 11058470833774 := by decide
theorem cert_e2262377811566 : check e2262377811566 [[],[.under]] .three = true := by decide
def e2262377811578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377811578 : Closed e2262377811578 ∧ code e2262377811578 = 11058470833786 := by decide
theorem cert_e2262377811578 : check e2262377811578 [[],[.under]] .three = true := by decide
def e2262377811766 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262377811766 : Closed e2262377811766 ∧ code e2262377811766 = 11058470833974 := by decide
theorem cert_e2262377811766 : check e2262377811766 [[],[.under]] .three = true := by decide
def e2262377811770 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262377811770 : Closed e2262377811770 ∧ code e2262377811770 = 11058470833978 := by decide
theorem cert_e2262377811770 : check e2262377811770 [[],[.under]] .three = true := by decide
def e2262377816542 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2262377816542 : Closed e2262377816542 ∧ code e2262377816542 = 11058470838750 := by decide
theorem cert_e2262377816542 : check e2262377816542 [[],[.under]] .three = true := by decide
def e2262377816566 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2262377816566 : Closed e2262377816566 ∧ code e2262377816566 = 11058470838774 := by decide
theorem cert_e2262377816566 : check e2262377816566 [[],[.under]] .three = true := by decide
def e2262377817482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262377817482 : Closed e2262377817482 ∧ code e2262377817482 = 11058470839690 := by decide
theorem cert_e2262377817482 : check e2262377817482 [[],[.under]] .three = true := by decide
def e2262377817506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262377817506 : Closed e2262377817506 ∧ code e2262377817506 = 11058470839714 := by decide
theorem cert_e2262377817506 : check e2262377817506 [[],[.under]] .three = true := by decide
def e2262377817518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2262377817518 : Closed e2262377817518 ∧ code e2262377817518 = 11058470839726 := by decide
theorem cert_e2262377817518 : check e2262377817518 [[],[.under]] .three = true := by decide
def e2262377817526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2262377817526 : Closed e2262377817526 ∧ code e2262377817526 = 11058470839734 := by decide
theorem cert_e2262377817526 : check e2262377817526 [[],[.under]] .three = true := by decide
def e2262377817530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2262377817530 : Closed e2262377817530 ∧ code e2262377817530 = 11058470839738 := by decide
theorem cert_e2262377817530 : check e2262377817530 [[],[.under]] .three = true := by decide
def e2262377817558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2262377817558 : Closed e2262377817558 ∧ code e2262377817558 = 11058470839766 := by decide
theorem cert_e2262377817558 : check e2262377817558 [[],[.under]] .three = true := by decide
def e2262377817562 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2262377817562 : Closed e2262377817562 ∧ code e2262377817562 = 11058470839770 := by decide
theorem cert_e2262377817562 : check e2262377817562 [[],[.under]] .three = true := by decide
def e2262377817578 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2262377817578 : Closed e2262377817578 ∧ code e2262377817578 = 11058470839786 := by decide
theorem cert_e2262377817578 : check e2262377817578 [[],[.under]] .three = true := by decide
def e2262377817614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2262377817614 : Closed e2262377817614 ∧ code e2262377817614 = 11058470839822 := by decide
theorem cert_e2262377817614 : check e2262377817614 [[],[.under]] .three = true := by decide
def e2262377817626 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2262377817626 : Closed e2262377817626 ∧ code e2262377817626 = 11058470839834 := by decide
theorem cert_e2262377817626 : check e2262377817626 [[],[.under]] .three = true := by decide
def e2262377817698 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262377817698 : Closed e2262377817698 ∧ code e2262377817698 = 11058470839906 := by decide
theorem cert_e2262377817698 : check e2262377817698 [[],[.under]] .three = true := by decide
def e2262377817710 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377817710 : Closed e2262377817710 ∧ code e2262377817710 = 11058470839918 := by decide
theorem cert_e2262377817710 : check e2262377817710 [[],[.under]] .three = true := by decide
def e2262377817718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262377817718 : Closed e2262377817718 ∧ code e2262377817718 = 11058470839926 := by decide
theorem cert_e2262377817718 : check e2262377817718 [[],[.under]] .three = true := by decide
def e2262377817722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377817722 : Closed e2262377817722 ∧ code e2262377817722 = 11058470839930 := by decide
theorem cert_e2262377817722 : check e2262377817722 [[],[.under]] .three = true := by decide
def e2262377817910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262377817910 : Closed e2262377817910 ∧ code e2262377817910 = 11058470840118 := by decide
theorem cert_e2262377817910 : check e2262377817910 [[],[.under]] .three = true := by decide
def e2262377817914 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262377817914 : Closed e2262377817914 ∧ code e2262377817914 = 11058470840122 := by decide
theorem cert_e2262377817914 : check e2262377817914 [[],[.under]] .three = true := by decide
def e2262377818010 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377818010 : Closed e2262377818010 ∧ code e2262377818010 = 11058470840218 := by decide
theorem cert_e2262377818010 : check e2262377818010 [[],[.under]] .three = true := by decide
def e2262377967070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2262377967070 : Closed e2262377967070 ∧ code e2262377967070 = 11058470989278 := by decide
theorem cert_e2262377967070 : check e2262377967070 [[],[.under]] .three = true := by decide
def e2262377967086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2262377967086 : Closed e2262377967086 ∧ code e2262377967086 = 11058470989294 := by decide
private def t_e2262377967086 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem cert_e2262377967086 : ¬ IsSelfInterpreter e2262377967086 :=
  wSource (t := t_e2262377967086) (replay_sound (ps := []) (t := e2262377967086) (by decide)) (by decide)
def e2262377967342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2262377967342 : Closed e2262377967342 ∧ code e2262377967342 = 11058470989550 := by decide
theorem cert_e2262377967342 : check e2262377967342 [[],[.under]] .three = true := by decide
def e2262377967454 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2262377967454 : Closed e2262377967454 ∧ code e2262377967454 = 11058470989662 := by decide
theorem cert_e2262377967454 : check e2262377967454 [[],[.under]] .three = true := by decide
def e2262377967470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2262377967470 : Closed e2262377967470 ∧ code e2262377967470 = 11058470989678 := by decide
theorem cert_e2262377967470 : check e2262377967470 [[],[.under]] .three = true := by decide
def e2262377967478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2262377967478 : Closed e2262377967478 ∧ code e2262377967478 = 11058470989686 := by decide
theorem cert_e2262377967478 : check e2262377967478 [[],[.under]] .three = true := by decide
def e2262377967482 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2262377967482 : Closed e2262377967482 ∧ code e2262377967482 = 11058470989690 := by decide
theorem cert_e2262377967482 : check e2262377967482 [[],[.under]] .three = true := by decide
def e2262377967534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2262377967534 : Closed e2262377967534 ∧ code e2262377967534 = 11058470989742 := by decide
private def t_e2262377967534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem cert_e2262377967534 : ¬ IsSelfInterpreter e2262377967534 :=
  wSource (t := t_e2262377967534) (replay_sound (ps := []) (t := e2262377967534) (by decide)) (by decide)
def e2262377967546 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2262377967546 : Closed e2262377967546 ∧ code e2262377967546 = 11058470989754 := by decide
theorem cert_e2262377967546 : check e2262377967546 [[],[.under]] .three = true := by decide
def e2262377968606 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262377968606 : Closed e2262377968606 ∧ code e2262377968606 = 11058470990814 := by decide
theorem cert_e2262377968606 : check e2262377968606 [[],[.under]] .three = true := by decide
def e2262377968622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262377968622 : Closed e2262377968622 ∧ code e2262377968622 = 11058470990830 := by decide
theorem cert_e2262377968622 : check e2262377968622 [[],[.under]] .three = true := by decide
def e2262377970158 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262377970158 : Closed e2262377970158 ∧ code e2262377970158 = 11058470992366 := by decide
theorem cert_e2262377970158 : check e2262377970158 [[],[.under]] .three = true := by decide
def e2262377970910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2262377970910 : Closed e2262377970910 ∧ code e2262377970910 = 11058470993118 := by decide
theorem cert_e2262377970910 : check e2262377970910 [[],[.under]] .three = true := by decide
def e2262377970926 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377970926 : Closed e2262377970926 ∧ code e2262377970926 = 11058470993134 := by decide
theorem cert_e2262377970926 : check e2262377970926 [[],[.under]] .three = true := by decide
def e2262377970934 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377970934 : Closed e2262377970934 ∧ code e2262377970934 = 11058470993142 := by decide
theorem cert_e2262377970934 : check e2262377970934 [[],[.under]] .three = true := by decide
def e2262377970938 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2262377970938 : Closed e2262377970938 ∧ code e2262377970938 = 11058470993146 := by decide
theorem cert_e2262377970938 : check e2262377970938 [[],[.under]] .three = true := by decide
def e2262377971310 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377971310 : Closed e2262377971310 ∧ code e2262377971310 = 11058470993518 := by decide
theorem cert_e2262377971310 : check e2262377971310 [[],[.under]] .three = true := by decide
def e2262377971322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377971322 : Closed e2262377971322 ∧ code e2262377971322 = 11058470993530 := by decide
theorem cert_e2262377971322 : check e2262377971322 [[],[.under]] .three = true := by decide
def e2262377999446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2262377999446 : Closed e2262377999446 ∧ code e2262377999446 = 11058471021654 := by decide
theorem cert_e2262377999446 : check e2262377999446 [[],[.under]] .three = true := by decide
def e2262377999450 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2262377999450 : Closed e2262377999450 ∧ code e2262377999450 = 11058471021658 := by decide
theorem cert_e2262377999450 : check e2262377999450 [[],[.under]] .three = true := by decide
def e2262377999638 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2262377999638 : Closed e2262377999638 ∧ code e2262377999638 = 11058471021846 := by decide
theorem cert_e2262377999638 : check e2262377999638 [[],[.under]] .three = true := by decide
def e2262377999714 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2262377999714 : Closed e2262377999714 ∧ code e2262377999714 = 11058471021922 := by decide
theorem cert_e2262377999714 : check e2262377999714 [[],[.under]] .three = true := by decide
def e2262377999726 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2262377999726 : Closed e2262377999726 ∧ code e2262377999726 = 11058471021934 := by decide
theorem cert_e2262377999726 : check e2262377999726 [[],[.under]] .three = true := by decide
def e2262377999734 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2262377999734 : Closed e2262377999734 ∧ code e2262377999734 = 11058471021942 := by decide
theorem cert_e2262377999734 : check e2262377999734 [[],[.under]] .three = true := by decide
def e2262377999754 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377999754 : Closed e2262377999754 ∧ code e2262377999754 = 11058471021962 := by decide
theorem cert_e2262377999754 : check e2262377999754 [[],[.under]] .three = true := by decide
def e2262377999778 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377999778 : Closed e2262377999778 ∧ code e2262377999778 = 11058471021986 := by decide
theorem cert_e2262377999778 : check e2262377999778 [[],[.under]] .three = true := by decide
def e2262377999790 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2262377999790 : Closed e2262377999790 ∧ code e2262377999790 = 11058471021998 := by decide
theorem cert_e2262377999790 : check e2262377999790 [[],[.under]] .three = true := by decide
def e2262377999798 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)))))))
theorem wire_e2262377999798 : Closed e2262377999798 ∧ code e2262377999798 = 11058471022006 := by decide
theorem cert_e2262377999798 : check e2262377999798 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2262377967086
#print axioms Blc.Floor43.cert_e2262377967534
