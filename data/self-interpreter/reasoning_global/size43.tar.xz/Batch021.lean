import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605188155166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605188155166 : Closed e605188155166 ∧ code e605188155166 = 9401281177374 := by decide
theorem cert_e605188155166 : check e605188155166 [[.under],[.under]] .three = true := by decide
def e605188155278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605188155278 : Closed e605188155278 ∧ code e605188155278 = 9401281177486 := by decide
theorem cert_e605188155278 : check e605188155278 [[.under],[.under]] .three = true := by decide
def e605188158238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605188158238 : Closed e605188158238 ∧ code e605188158238 = 9401281180446 := by decide
theorem cert_e605188158238 : check e605188158238 [[.under],[.under]] .three = true := by decide
def e605188158406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605188158406 : Closed e605188158406 ∧ code e605188158406 = 9401281180614 := by decide
theorem cert_e605188158406 : check e605188158406 [[.under],[.under]] .three = true := by decide
def e605188159886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605188159886 : Closed e605188159886 ∧ code e605188159886 = 9401281182094 := by decide
theorem cert_e605188159886 : check e605188159886 [[.under],[.under]] .three = true := by decide
def e605188159942 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605188159942 : Closed e605188159942 ∧ code e605188159942 = 9401281182150 := by decide
theorem cert_e605188159942 : check e605188159942 [[.under],[.under]] .three = true := by decide
def e605188197230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e605188197230 : Closed e605188197230 ∧ code e605188197230 = 9401281219438 := by decide
theorem cert_e605188197230 : check e605188197230 [[.under],[.under]] .smaller = true := by decide
def e605188197238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e605188197238 : Closed e605188197238 ∧ code e605188197238 = 9401281219446 := by decide
theorem cert_e605188197238 : check e605188197238 [[.under],[.under]] .smaller = true := by decide
def e605188197294 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e605188197294 : Closed e605188197294 ∧ code e605188197294 = 9401281219502 := by decide
theorem cert_e605188197294 : check e605188197294 [[.under],[.under]] .smaller = true := by decide
def e605188197306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e605188197306 : Closed e605188197306 ∧ code e605188197306 = 9401281219514 := by decide
theorem cert_e605188197306 : check e605188197306 [[.under],[.under]] .smaller = true := by decide
def e605188197334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e605188197334 : Closed e605188197334 ∧ code e605188197334 = 9401281219542 := by decide
theorem cert_e605188197334 : check e605188197334 [[.under],[.under]] .smaller = true := by decide
def e605188197338 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e605188197338 : Closed e605188197338 ∧ code e605188197338 = 9401281219546 := by decide
theorem cert_e605188197338 : check e605188197338 [[.under],[.under]] .smaller = true := by decide
def e605188197614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e605188197614 : Closed e605188197614 ∧ code e605188197614 = 9401281219822 := by decide
theorem cert_e605188197614 : check e605188197614 [[.under],[.under]] .smaller = true := by decide
def e605188197622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e605188197622 : Closed e605188197622 ∧ code e605188197622 = 9401281219830 := by decide
theorem cert_e605188197622 : check e605188197622 [[.under],[.under]] .smaller = true := by decide
def e605188197998 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e605188197998 : Closed e605188197998 ∧ code e605188197998 = 9401281220206 := by decide
theorem cert_e605188197998 : check e605188197998 [[.under],[.under]] .smaller = true := by decide
def e605188198010 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e605188198010 : Closed e605188198010 ∧ code e605188198010 = 9401281220218 := by decide
theorem cert_e605188198010 : check e605188198010 [[.under],[.under]] .smaller = true := by decide
def e605188198198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e605188198198 : Closed e605188198198 ∧ code e605188198198 = 9401281220406 := by decide
theorem cert_e605188198198 : check e605188198198 [[.under],[.under]] .smaller = true := by decide
def e605188198202 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e605188198202 : Closed e605188198202 ∧ code e605188198202 = 9401281220410 := by decide
theorem cert_e605188198202 : check e605188198202 [[.under],[.under]] .smaller = true := by decide
def e605188205678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605188205678 : Closed e605188205678 ∧ code e605188205678 = 9401281227886 := by decide
theorem cert_e605188205678 : check e605188205678 [[.under],[.under]] .three = true := by decide
def e605188205690 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605188205690 : Closed e605188205690 ∧ code e605188205690 = 9401281227898 := by decide
theorem cert_e605188205690 : check e605188205690 [[.under],[.under]] .three = true := by decide
def e605188205854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605188205854 : Closed e605188205854 ∧ code e605188205854 = 9401281228062 := by decide
theorem cert_e605188205854 : check e605188205854 [[.under],[.under]] .three = true := by decide
def e605188206022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605188206022 : Closed e605188206022 ∧ code e605188206022 = 9401281228230 := by decide
theorem cert_e605188206022 : check e605188206022 [[.under],[.under]] .three = true := by decide
def e605188206362 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605188206362 : Closed e605188206362 ∧ code e605188206362 = 9401281228570 := by decide
theorem cert_e605188206362 : check e605188206362 [[.under],[.under]] .three = true := by decide
def e605188206406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605188206406 : Closed e605188206406 ∧ code e605188206406 = 9401281228614 := by decide
theorem cert_e605188206406 : check e605188206406 [[.under],[.under]] .three = true := by decide
def e605188207390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605188207390 : Closed e605188207390 ∧ code e605188207390 = 9401281229598 := by decide
theorem cert_e605188207390 : check e605188207390 [[.under],[.under]] .three = true := by decide
def e605188207558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605188207558 : Closed e605188207558 ∧ code e605188207558 = 9401281229766 := by decide
theorem cert_e605188207558 : check e605188207558 [[.under],[.under]] .three = true := by decide
def e605188209862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605188209862 : Closed e605188209862 ∧ code e605188209862 = 9401281232070 := by decide
theorem cert_e605188209862 : check e605188209862 [[.under],[.under]] .three = true := by decide
def e605188232758 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605188232758 : Closed e605188232758 ∧ code e605188232758 = 9401281254966 := by decide
theorem cert_e605188232758 : check e605188232758 [[.under],[.under]] .three = true := by decide
def e605188232762 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605188232762 : Closed e605188232762 ∧ code e605188232762 = 9401281254970 := by decide
theorem cert_e605188232762 : check e605188232762 [[.under],[.under]] .three = true := by decide
def e605188232846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605188232846 : Closed e605188232846 ∧ code e605188232846 = 9401281255054 := by decide
theorem cert_e605188232846 : check e605188232846 [[.under],[.under]] .three = true := by decide
def e605188232902 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605188232902 : Closed e605188232902 ∧ code e605188232902 = 9401281255110 := by decide
theorem cert_e605188232902 : check e605188232902 [[.under],[.under]] .three = true := by decide
def e605188232986 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605188232986 : Closed e605188232986 ∧ code e605188232986 = 9401281255194 := by decide
theorem cert_e605188232986 : check e605188232986 [[.under],[.under]] .three = true := by decide
def e605188233030 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605188233030 : Closed e605188233030 ∧ code e605188233030 = 9401281255238 := by decide
theorem cert_e605188233030 : check e605188233030 [[.under],[.under]] .three = true := by decide
def e605188233614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605188233614 : Closed e605188233614 ∧ code e605188233614 = 9401281255822 := by decide
theorem cert_e605188233614 : check e605188233614 [[.under],[.under]] .three = true := by decide
def e605188233670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605188233670 : Closed e605188233670 ∧ code e605188233670 = 9401281255878 := by decide
theorem cert_e605188233670 : check e605188233670 [[.under],[.under]] .three = true := by decide
def e605188234438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e605188234438 : Closed e605188234438 ∧ code e605188234438 = 9401281256646 := by decide
theorem cert_e605188234438 : check e605188234438 [[.under],[.under]] .three = true := by decide
def e605189331182 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605189331182 : Closed e605189331182 ∧ code e605189331182 = 9401282353390 := by decide
theorem cert_e605189331182 : check e605189331182 [[.under],[.under]] .chain = true := by decide
def e605189331190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605189331190 : Closed e605189331190 ∧ code e605189331190 = 9401282353398 := by decide
theorem cert_e605189331190 : check e605189331190 [[.under],[.under]] .chain = true := by decide
def e605189331742 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605189331742 : Closed e605189331742 ∧ code e605189331742 = 9401282353950 := by decide
theorem cert_e605189331742 : check e605189331742 [[.under],[.under]] .chain = true := by decide
def e605189331854 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605189331854 : Closed e605189331854 ∧ code e605189331854 = 9401282354062 := by decide
theorem cert_e605189331854 : check e605189331854 [[.under],[.under]] .chain = true := by decide
def e605189332078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605189332078 : Closed e605189332078 ∧ code e605189332078 = 9401282354286 := by decide
theorem cert_e605189332078 : check e605189332078 [[.under],[.under]] .chain = true := by decide
def e605189332090 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605189332090 : Closed e605189332090 ∧ code e605189332090 = 9401282354298 := by decide
theorem cert_e605189332090 : check e605189332090 [[.under],[.under]] .chain = true := by decide
def e605189332254 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605189332254 : Closed e605189332254 ∧ code e605189332254 = 9401282354462 := by decide
theorem cert_e605189332254 : check e605189332254 [[.under],[.under]] .chain = true := by decide
def e605189332422 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605189332422 : Closed e605189332422 ∧ code e605189332422 = 9401282354630 := by decide
theorem cert_e605189332422 : check e605189332422 [[.under],[.under]] .chain = true := by decide
def e605189332534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605189332534 : Closed e605189332534 ∧ code e605189332534 = 9401282354742 := by decide
theorem cert_e605189332534 : check e605189332534 [[.under],[.under]] .chain = true := by decide
def e605189332538 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605189332538 : Closed e605189332538 ∧ code e605189332538 = 9401282354746 := by decide
theorem cert_e605189332538 : check e605189332538 [[.under],[.under]] .chain = true := by decide
def e605189332622 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605189332622 : Closed e605189332622 ∧ code e605189332622 = 9401282354830 := by decide
theorem cert_e605189332622 : check e605189332622 [[.under],[.under]] .chain = true := by decide
def e605189332678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605189332678 : Closed e605189332678 ∧ code e605189332678 = 9401282354886 := by decide
theorem cert_e605189332678 : check e605189332678 [[.under],[.under]] .chain = true := by decide
def e605189334814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605189334814 : Closed e605189334814 ∧ code e605189334814 = 9401282357022 := by decide
theorem cert_e605189334814 : check e605189334814 [[.under],[.under]] .chain = true := by decide
def e605189334926 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605189334926 : Closed e605189334926 ∧ code e605189334926 = 9401282357134 := by decide
theorem cert_e605189334926 : check e605189334926 [[.under],[.under]] .chain = true := by decide
def e605189337886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605189337886 : Closed e605189337886 ∧ code e605189337886 = 9401282360094 := by decide
theorem cert_e605189337886 : check e605189337886 [[.under],[.under]] .chain = true := by decide
def e605189338054 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605189338054 : Closed e605189338054 ∧ code e605189338054 = 9401282360262 := by decide
theorem cert_e605189338054 : check e605189338054 [[.under],[.under]] .chain = true := by decide
def e605189339534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605189339534 : Closed e605189339534 ∧ code e605189339534 = 9401282361742 := by decide
theorem cert_e605189339534 : check e605189339534 [[.under],[.under]] .chain = true := by decide
def e605189339590 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605189339590 : Closed e605189339590 ∧ code e605189339590 = 9401282361798 := by decide
theorem cert_e605189339590 : check e605189339590 [[.under],[.under]] .chain = true := by decide
def e605194032862 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e605194032862 : Closed e605194032862 ∧ code e605194032862 = 9401287055070 := by decide
theorem cert_e605194032862 : check e605194032862 [[.under],[.under]] .sourceHead = true := by decide
def e605194032886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e605194032886 : Closed e605194032886 ∧ code e605194032886 = 9401287055094 := by decide
theorem cert_e605194032886 : check e605194032886 [[.under],[.under]] .sourceHead = true := by decide
def e605194032990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e605194032990 : Closed e605194032990 ∧ code e605194032990 = 9401287055198 := by decide
theorem cert_e605194032990 : check e605194032990 [[.under],[.under]] .sourceHead = true := by decide
def e605194033018 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e605194033018 : Closed e605194033018 ∧ code e605194033018 = 9401287055226 := by decide
theorem cert_e605194033018 : check e605194033018 [[.under],[.under]] .sourceHead = true := by decide
def e605194033110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e605194033110 : Closed e605194033110 ∧ code e605194033110 = 9401287055318 := by decide
theorem cert_e605194033110 : check e605194033110 [[.under],[.under]] .sourceHead = true := by decide
def e605194033114 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e605194033114 : Closed e605194033114 ∧ code e605194033114 = 9401287055322 := by decide
theorem cert_e605194033114 : check e605194033114 [[.under],[.under]] .sourceHead = true := by decide
def e605194033630 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e605194033630 : Closed e605194033630 ∧ code e605194033630 = 9401287055838 := by decide
theorem cert_e605194033630 : check e605194033630 [[.under],[.under]] .sourceHead = true := by decide
def e605194033654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e605194033654 : Closed e605194033654 ∧ code e605194033654 = 9401287055862 := by decide
theorem cert_e605194033654 : check e605194033654 [[.under],[.under]] .sourceHead = true := by decide
def e605194034398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e605194034398 : Closed e605194034398 ∧ code e605194034398 = 9401287056606 := by decide
theorem cert_e605194034398 : check e605194034398 [[.under],[.under]] .sourceHead = true := by decide
def e605194034426 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e605194034426 : Closed e605194034426 ∧ code e605194034426 = 9401287056634 := by decide
theorem cert_e605194034426 : check e605194034426 [[.under],[.under]] .sourceHead = true := by decide
def e605194034998 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e605194034998 : Closed e605194034998 ∧ code e605194034998 = 9401287057206 := by decide
theorem cert_e605194034998 : check e605194034998 [[.under],[.under]] .sourceHead = true := by decide
def e605194035002 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e605194035002 : Closed e605194035002 ∧ code e605194035002 = 9401287057210 := by decide
theorem cert_e605194035002 : check e605194035002 [[.under],[.under]] .sourceHead = true := by decide
def e605194049774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605194049774 : Closed e605194049774 ∧ code e605194049774 = 9401287071982 := by decide
theorem cert_e605194049774 : check e605194049774 [[.under],[.under]] .sourceHead = true := by decide
def e605194049782 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605194049782 : Closed e605194049782 ∧ code e605194049782 = 9401287071990 := by decide
theorem cert_e605194049782 : check e605194049782 [[.under],[.under]] .sourceHead = true := by decide
def e605194050334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605194050334 : Closed e605194050334 ∧ code e605194050334 = 9401287072542 := by decide
theorem cert_e605194050334 : check e605194050334 [[.under],[.under]] .sourceHead = true := by decide
def e605194050446 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605194050446 : Closed e605194050446 ∧ code e605194050446 = 9401287072654 := by decide
theorem cert_e605194050446 : check e605194050446 [[.under],[.under]] .sourceHead = true := by decide
def e605194050670 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605194050670 : Closed e605194050670 ∧ code e605194050670 = 9401287072878 := by decide
theorem cert_e605194050670 : check e605194050670 [[.under],[.under]] .sourceHead = true := by decide
def e605194050682 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605194050682 : Closed e605194050682 ∧ code e605194050682 = 9401287072890 := by decide
theorem cert_e605194050682 : check e605194050682 [[.under],[.under]] .sourceHead = true := by decide
def e605194050846 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605194050846 : Closed e605194050846 ∧ code e605194050846 = 9401287073054 := by decide
theorem cert_e605194050846 : check e605194050846 [[.under],[.under]] .sourceHead = true := by decide
def e605194051014 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605194051014 : Closed e605194051014 ∧ code e605194051014 = 9401287073222 := by decide
theorem cert_e605194051014 : check e605194051014 [[.under],[.under]] .sourceHead = true := by decide
def e605194051126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605194051126 : Closed e605194051126 ∧ code e605194051126 = 9401287073334 := by decide
theorem cert_e605194051126 : check e605194051126 [[.under],[.under]] .sourceHead = true := by decide
def e605194051130 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605194051130 : Closed e605194051130 ∧ code e605194051130 = 9401287073338 := by decide
theorem cert_e605194051130 : check e605194051130 [[.under],[.under]] .sourceHead = true := by decide
def e605194051214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605194051214 : Closed e605194051214 ∧ code e605194051214 = 9401287073422 := by decide
theorem cert_e605194051214 : check e605194051214 [[.under],[.under]] .sourceHead = true := by decide
def e605194051270 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605194051270 : Closed e605194051270 ∧ code e605194051270 = 9401287073478 := by decide
theorem cert_e605194051270 : check e605194051270 [[.under],[.under]] .sourceHead = true := by decide
def e605194053406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e605194053406 : Closed e605194053406 ∧ code e605194053406 = 9401287075614 := by decide
theorem cert_e605194053406 : check e605194053406 [[.under],[.under]] .sourceHead = true := by decide
def e605194053518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e605194053518 : Closed e605194053518 ∧ code e605194053518 = 9401287075726 := by decide
theorem cert_e605194053518 : check e605194053518 [[.under],[.under]] .sourceHead = true := by decide
def e605194056478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e605194056478 : Closed e605194056478 ∧ code e605194056478 = 9401287078686 := by decide
theorem cert_e605194056478 : check e605194056478 [[.under],[.under]] .sourceHead = true := by decide
def e605194056646 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e605194056646 : Closed e605194056646 ∧ code e605194056646 = 9401287078854 := by decide
theorem cert_e605194056646 : check e605194056646 [[.under],[.under]] .sourceHead = true := by decide
def e605194058126 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e605194058126 : Closed e605194058126 ∧ code e605194058126 = 9401287080334 := by decide
theorem cert_e605194058126 : check e605194058126 [[.under],[.under]] .sourceHead = true := by decide
def e605194058182 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e605194058182 : Closed e605194058182 ∧ code e605194058182 = 9401287080390 := by decide
theorem cert_e605194058182 : check e605194058182 [[.under],[.under]] .sourceHead = true := by decide
def e605601623518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e605601623518 : Closed e605601623518 ∧ code e605601623518 = 9401694645726 := by decide
theorem cert_e605601623518 : check e605601623518 [[.under],[.under]] .three = true := by decide
def e605601623534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e605601623534 : Closed e605601623534 ∧ code e605601623534 = 9401694645742 := by decide
theorem cert_e605601623534 : check e605601623534 [[.under],[.under]] .three = true := by decide
def e605601623774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e605601623774 : Closed e605601623774 ∧ code e605601623774 = 9401694645982 := by decide
theorem cert_e605601623774 : check e605601623774 [[.under],[.under]] .three = true := by decide
def e605601623798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e605601623798 : Closed e605601623798 ∧ code e605601623798 = 9401694646006 := by decide
theorem cert_e605601623798 : check e605601623798 [[.under],[.under]] .three = true := by decide
def e605601623918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e605601623918 : Closed e605601623918 ∧ code e605601623918 = 9401694646126 := by decide
theorem cert_e605601623918 : check e605601623918 [[.under],[.under]] .three = true := by decide
def e605601623926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e605601623926 : Closed e605601623926 ∧ code e605601623926 = 9401694646134 := by decide
theorem cert_e605601623926 : check e605601623926 [[.under],[.under]] .three = true := by decide
def e605601625822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e605601625822 : Closed e605601625822 ∧ code e605601625822 = 9401694648030 := by decide
theorem cert_e605601625822 : check e605601625822 [[.under],[.under]] .three = true := by decide
def e605601625846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e605601625846 : Closed e605601625846 ∧ code e605601625846 = 9401694648054 := by decide
theorem cert_e605601625846 : check e605601625846 [[.under],[.under]] .three = true := by decide
def e605601626038 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e605601626038 : Closed e605601626038 ∧ code e605601626038 = 9401694648246 := by decide
theorem cert_e605601626038 : check e605601626038 [[.under],[.under]] .three = true := by decide
def e605601626990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e605601626990 : Closed e605601626990 ∧ code e605601626990 = 9401694649198 := by decide
theorem cert_e605601626990 : check e605601626990 [[.under],[.under]] .three = true := by decide
def e605601626998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e605601626998 : Closed e605601626998 ∧ code e605601626998 = 9401694649206 := by decide
theorem cert_e605601626998 : check e605601626998 [[.under],[.under]] .three = true := by decide
def e605601627062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e605601627062 : Closed e605601627062 ∧ code e605601627062 = 9401694649270 := by decide
theorem cert_e605601627062 : check e605601627062 [[.under],[.under]] .three = true := by decide
def e605601639902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e605601639902 : Closed e605601639902 ∧ code e605601639902 = 9401694662110 := by decide
theorem cert_e605601639902 : check e605601639902 [[.under],[.under]] .three = true := by decide
def e605601639918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e605601639918 : Closed e605601639918 ∧ code e605601639918 = 9401694662126 := by decide
theorem cert_e605601639918 : check e605601639918 [[.under],[.under]] .three = true := by decide
def e605601640158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e605601640158 : Closed e605601640158 ∧ code e605601640158 = 9401694662366 := by decide
theorem cert_e605601640158 : check e605601640158 [[.under],[.under]] .three = true := by decide
def e605601640182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e605601640182 : Closed e605601640182 ∧ code e605601640182 = 9401694662390 := by decide
theorem cert_e605601640182 : check e605601640182 [[.under],[.under]] .three = true := by decide
def e605601640302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e605601640302 : Closed e605601640302 ∧ code e605601640302 = 9401694662510 := by decide
theorem cert_e605601640302 : check e605601640302 [[.under],[.under]] .three = true := by decide
def e605601640310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e605601640310 : Closed e605601640310 ∧ code e605601640310 = 9401694662518 := by decide
theorem cert_e605601640310 : check e605601640310 [[.under],[.under]] .three = true := by decide
def e605601641950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e605601641950 : Closed e605601641950 ∧ code e605601641950 = 9401694664158 := by decide
theorem cert_e605601641950 : check e605601641950 [[.under],[.under]] .three = true := by decide
def e605601641966 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e605601641966 : Closed e605601641966 ∧ code e605601641966 = 9401694664174 := by decide
theorem cert_e605601641966 : check e605601641966 [[.under],[.under]] .three = true := by decide
def e605601642334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e605601642334 : Closed e605601642334 ∧ code e605601642334 = 9401694664542 := by decide
theorem cert_e605601642334 : check e605601642334 [[.under],[.under]] .three = true := by decide
def e605601642362 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e605601642362 : Closed e605601642362 ∧ code e605601642362 = 9401694664570 := by decide
theorem cert_e605601642362 : check e605601642362 [[.under],[.under]] .three = true := by decide
def e605601642414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e605601642414 : Closed e605601642414 ∧ code e605601642414 = 9401694664622 := by decide
theorem cert_e605601642414 : check e605601642414 [[.under],[.under]] .three = true := by decide
def e605601642426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e605601642426 : Closed e605601642426 ∧ code e605601642426 = 9401694664634 := by decide
theorem cert_e605601642426 : check e605601642426 [[.under],[.under]] .three = true := by decide
def e605601643230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e605601643230 : Closed e605601643230 ∧ code e605601643230 = 9401694665438 := by decide
theorem cert_e605601643230 : check e605601643230 [[.under],[.under]] .three = true := by decide
def e605601643254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e605601643254 : Closed e605601643254 ∧ code e605601643254 = 9401694665462 := by decide
theorem cert_e605601643254 : check e605601643254 [[.under],[.under]] .three = true := by decide
def e605601643358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e605601643358 : Closed e605601643358 ∧ code e605601643358 = 9401694665566 := by decide
theorem cert_e605601643358 : check e605601643358 [[.under],[.under]] .three = true := by decide
def e605601643386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e605601643386 : Closed e605601643386 ∧ code e605601643386 = 9401694665594 := by decide
theorem cert_e605601643386 : check e605601643386 [[.under],[.under]] .three = true := by decide
def e605601643478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e605601643478 : Closed e605601643478 ∧ code e605601643478 = 9401694665686 := by decide
theorem cert_e605601643478 : check e605601643478 [[.under],[.under]] .three = true := by decide
def e605601643482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e605601643482 : Closed e605601643482 ∧ code e605601643482 = 9401694665690 := by decide
theorem cert_e605601643482 : check e605601643482 [[.under],[.under]] .three = true := by decide
def e605601643886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605601643886 : Closed e605601643886 ∧ code e605601643886 = 9401694666094 := by decide
theorem cert_e605601643886 : check e605601643886 [[.under],[.under]] .three = true := by decide
def e605601643894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605601643894 : Closed e605601643894 ∧ code e605601643894 = 9401694666102 := by decide
theorem cert_e605601643894 : check e605601643894 [[.under],[.under]] .three = true := by decide
def e605601643950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605601643950 : Closed e605601643950 ∧ code e605601643950 = 9401694666158 := by decide
theorem cert_e605601643950 : check e605601643950 [[.under],[.under]] .three = true := by decide
def e605601643962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605601643962 : Closed e605601643962 ∧ code e605601643962 = 9401694666170 := by decide
theorem cert_e605601643962 : check e605601643962 [[.under],[.under]] .three = true := by decide
def e605601643990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605601643990 : Closed e605601643990 ∧ code e605601643990 = 9401694666198 := by decide
theorem cert_e605601643990 : check e605601643990 [[.under],[.under]] .three = true := by decide
def e605601643994 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605601643994 : Closed e605601643994 ∧ code e605601643994 = 9401694666202 := by decide
theorem cert_e605601643994 : check e605601643994 [[.under],[.under]] .three = true := by decide
def e605601650398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e605601650398 : Closed e605601650398 ∧ code e605601650398 = 9401694672606 := by decide
theorem cert_e605601650398 : check e605601650398 [[.under],[.under]] .three = true := by decide
def e605601650422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e605601650422 : Closed e605601650422 ∧ code e605601650422 = 9401694672630 := by decide
theorem cert_e605601650422 : check e605601650422 [[.under],[.under]] .three = true := by decide
def e605601650614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e605601650614 : Closed e605601650614 ∧ code e605601650614 = 9401694672822 := by decide
theorem cert_e605601650614 : check e605601650614 [[.under],[.under]] .three = true := by decide
def e605601651422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e605601651422 : Closed e605601651422 ∧ code e605601651422 = 9401694673630 := by decide
theorem cert_e605601651422 : check e605601651422 [[.under],[.under]] .three = true := by decide
def e605601651446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e605601651446 : Closed e605601651446 ∧ code e605601651446 = 9401694673654 := by decide
theorem cert_e605601651446 : check e605601651446 [[.under],[.under]] .three = true := by decide
def e605601651550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e605601651550 : Closed e605601651550 ∧ code e605601651550 = 9401694673758 := by decide
theorem cert_e605601651550 : check e605601651550 [[.under],[.under]] .three = true := by decide
def e605601651578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e605601651578 : Closed e605601651578 ∧ code e605601651578 = 9401694673786 := by decide
theorem cert_e605601651578 : check e605601651578 [[.under],[.under]] .three = true := by decide
def e605601651670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e605601651670 : Closed e605601651670 ∧ code e605601651670 = 9401694673878 := by decide
theorem cert_e605601651670 : check e605601651670 [[.under],[.under]] .three = true := by decide
def e605601651674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e605601651674 : Closed e605601651674 ∧ code e605601651674 = 9401694673882 := by decide
theorem cert_e605601651674 : check e605601651674 [[.under],[.under]] .three = true := by decide
def e605601652406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e605601652406 : Closed e605601652406 ∧ code e605601652406 = 9401694674614 := by decide
theorem cert_e605601652406 : check e605601652406 [[.under],[.under]] .three = true := by decide
def e605601652438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e605601652438 : Closed e605601652438 ∧ code e605601652438 = 9401694674646 := by decide
theorem cert_e605601652438 : check e605601652438 [[.under],[.under]] .three = true := by decide
def e605601652442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e605601652442 : Closed e605601652442 ∧ code e605601652442 = 9401694674650 := by decide
theorem cert_e605601652442 : check e605601652442 [[.under],[.under]] .three = true := by decide
def e605601655662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e605601655662 : Closed e605601655662 ∧ code e605601655662 = 9401694677870 := by decide
theorem cert_e605601655662 : check e605601655662 [[.under],[.under]] .three = true := by decide
def e605601655670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e605601655670 : Closed e605601655670 ∧ code e605601655670 = 9401694677878 := by decide
theorem cert_e605601655670 : check e605601655670 [[.under],[.under]] .three = true := by decide
def e605601655734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e605601655734 : Closed e605601655734 ∧ code e605601655734 = 9401694677942 := by decide
theorem cert_e605601655734 : check e605601655734 [[.under],[.under]] .three = true := by decide
def e605601656174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e605601656174 : Closed e605601656174 ∧ code e605601656174 = 9401694678382 := by decide
theorem cert_e605601656174 : check e605601656174 [[.under],[.under]] .three = true := by decide
def e605601656182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e605601656182 : Closed e605601656182 ∧ code e605601656182 = 9401694678390 := by decide
theorem cert_e605601656182 : check e605601656182 [[.under],[.under]] .three = true := by decide
def e605601656238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e605601656238 : Closed e605601656238 ∧ code e605601656238 = 9401694678446 := by decide
theorem cert_e605601656238 : check e605601656238 [[.under],[.under]] .three = true := by decide
def e605601656250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e605601656250 : Closed e605601656250 ∧ code e605601656250 = 9401694678458 := by decide
theorem cert_e605601656250 : check e605601656250 [[.under],[.under]] .three = true := by decide
def e605601656278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e605601656278 : Closed e605601656278 ∧ code e605601656278 = 9401694678486 := by decide
theorem cert_e605601656278 : check e605601656278 [[.under],[.under]] .three = true := by decide
def e605601656282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e605601656282 : Closed e605601656282 ∧ code e605601656282 = 9401694678490 := by decide
theorem cert_e605601656282 : check e605601656282 [[.under],[.under]] .three = true := by decide
def e605601656502 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e605601656502 : Closed e605601656502 ∧ code e605601656502 = 9401694678710 := by decide
theorem cert_e605601656502 : check e605601656502 [[.under],[.under]] .three = true := by decide
def e605601656534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e605601656534 : Closed e605601656534 ∧ code e605601656534 = 9401694678742 := by decide
theorem cert_e605601656534 : check e605601656534 [[.under],[.under]] .three = true := by decide
def e605601656538 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e605601656538 : Closed e605601656538 ∧ code e605601656538 = 9401694678746 := by decide
theorem cert_e605601656538 : check e605601656538 [[.under],[.under]] .three = true := by decide
def e605601721822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e605601721822 : Closed e605601721822 ∧ code e605601721822 = 9401694744030 := by decide
theorem cert_e605601721822 : check e605601721822 [[.under],[.under]] .three = true := by decide
def e605601721838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e605601721838 : Closed e605601721838 ∧ code e605601721838 = 9401694744046 := by decide
theorem cert_e605601721838 : check e605601721838 [[.under],[.under]] .three = true := by decide
def e605601722078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e605601722078 : Closed e605601722078 ∧ code e605601722078 = 9401694744286 := by decide
theorem cert_e605601722078 : check e605601722078 [[.under],[.under]] .three = true := by decide
def e605601722102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e605601722102 : Closed e605601722102 ∧ code e605601722102 = 9401694744310 := by decide
theorem cert_e605601722102 : check e605601722102 [[.under],[.under]] .three = true := by decide
def e605601722222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e605601722222 : Closed e605601722222 ∧ code e605601722222 = 9401694744430 := by decide
theorem cert_e605601722222 : check e605601722222 [[.under],[.under]] .three = true := by decide
def e605601722230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e605601722230 : Closed e605601722230 ∧ code e605601722230 = 9401694744438 := by decide
theorem cert_e605601722230 : check e605601722230 [[.under],[.under]] .three = true := by decide
def e605601724126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e605601724126 : Closed e605601724126 ∧ code e605601724126 = 9401694746334 := by decide
theorem cert_e605601724126 : check e605601724126 [[.under],[.under]] .three = true := by decide
def e605601724150 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e605601724150 : Closed e605601724150 ∧ code e605601724150 = 9401694746358 := by decide
theorem cert_e605601724150 : check e605601724150 [[.under],[.under]] .three = true := by decide
def e605601724342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e605601724342 : Closed e605601724342 ∧ code e605601724342 = 9401694746550 := by decide
theorem cert_e605601724342 : check e605601724342 [[.under],[.under]] .three = true := by decide
def e605601725294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605601725294 : Closed e605601725294 ∧ code e605601725294 = 9401694747502 := by decide
theorem cert_e605601725294 : check e605601725294 [[.under],[.under]] .three = true := by decide
def e605601725302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605601725302 : Closed e605601725302 ∧ code e605601725302 = 9401694747510 := by decide
theorem cert_e605601725302 : check e605601725302 [[.under],[.under]] .three = true := by decide
def e605601725366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e605601725366 : Closed e605601725366 ∧ code e605601725366 = 9401694747574 := by decide
theorem cert_e605601725366 : check e605601725366 [[.under],[.under]] .three = true := by decide
def e605601766878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e605601766878 : Closed e605601766878 ∧ code e605601766878 = 9401694789086 := by decide
theorem cert_e605601766878 : check e605601766878 [[.under],[.under]] .three = true := by decide
def e605601766894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e605601766894 : Closed e605601766894 ∧ code e605601766894 = 9401694789102 := by decide
theorem cert_e605601766894 : check e605601766894 [[.under],[.under]] .three = true := by decide
def e605601767134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e605601767134 : Closed e605601767134 ∧ code e605601767134 = 9401694789342 := by decide
theorem cert_e605601767134 : check e605601767134 [[.under],[.under]] .three = true := by decide
def e605601767158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e605601767158 : Closed e605601767158 ∧ code e605601767158 = 9401694789366 := by decide
theorem cert_e605601767158 : check e605601767158 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
