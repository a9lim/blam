import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605601767278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e605601767278 : Closed e605601767278 ∧ code e605601767278 = 9401694789486 := by decide
theorem cert_e605601767278 : check e605601767278 [[.under],[.under]] .three = true := by decide
def e605601767286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e605601767286 : Closed e605601767286 ∧ code e605601767286 = 9401694789494 := by decide
theorem cert_e605601767286 : check e605601767286 [[.under],[.under]] .three = true := by decide
def e605601772510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e605601772510 : Closed e605601772510 ∧ code e605601772510 = 9401694794718 := by decide
theorem cert_e605601772510 : check e605601772510 [[.under],[.under]] .three = true := by decide
def e605601772526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e605601772526 : Closed e605601772526 ∧ code e605601772526 = 9401694794734 := by decide
theorem cert_e605601772526 : check e605601772526 [[.under],[.under]] .three = true := by decide
def e605601774046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e605601774046 : Closed e605601774046 ∧ code e605601774046 = 9401694796254 := by decide
theorem cert_e605601774046 : check e605601774046 [[.under],[.under]] .three = true := by decide
def e605601774070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e605601774070 : Closed e605601774070 ∧ code e605601774070 = 9401694796278 := by decide
theorem cert_e605601774070 : check e605601774070 [[.under],[.under]] .three = true := by decide
def e605601774830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e605601774830 : Closed e605601774830 ∧ code e605601774830 = 9401694797038 := by decide
theorem cert_e605601774830 : check e605601774830 [[.under],[.under]] .three = true := by decide
def e605601774838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e605601774838 : Closed e605601774838 ∧ code e605601774838 = 9401694797046 := by decide
theorem cert_e605601774838 : check e605601774838 [[.under],[.under]] .three = true := by decide
def e605601779422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e605601779422 : Closed e605601779422 ∧ code e605601779422 = 9401694801630 := by decide
theorem cert_e605601779422 : check e605601779422 [[.under],[.under]] .three = true := by decide
def e605601779446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e605601779446 : Closed e605601779446 ∧ code e605601779446 = 9401694801654 := by decide
theorem cert_e605601779446 : check e605601779446 [[.under],[.under]] .three = true := by decide
def e605601779638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e605601779638 : Closed e605601779638 ∧ code e605601779638 = 9401694801846 := by decide
theorem cert_e605601779638 : check e605601779638 [[.under],[.under]] .three = true := by decide
def e605601782238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e605601782238 : Closed e605601782238 ∧ code e605601782238 = 9401694804446 := by decide
theorem cert_e605601782238 : check e605601782238 [[.under],[.under]] .three = true := by decide
def e605601782262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e605601782262 : Closed e605601782262 ∧ code e605601782262 = 9401694804470 := by decide
theorem cert_e605601782262 : check e605601782262 [[.under],[.under]] .three = true := by decide
def e605601783414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e605601783414 : Closed e605601783414 ∧ code e605601783414 = 9401694805622 := by decide
theorem cert_e605601783414 : check e605601783414 [[.under],[.under]] .three = true := by decide
def e605601785710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e605601785710 : Closed e605601785710 ∧ code e605601785710 = 9401694807918 := by decide
theorem cert_e605601785710 : check e605601785710 [[.under],[.under]] .three = true := by decide
def e605601785718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e605601785718 : Closed e605601785718 ∧ code e605601785718 = 9401694807926 := by decide
theorem cert_e605601785718 : check e605601785718 [[.under],[.under]] .three = true := by decide
def e605601785782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e605601785782 : Closed e605601785782 ∧ code e605601785782 = 9401694807990 := by decide
theorem cert_e605601785782 : check e605601785782 [[.under],[.under]] .three = true := by decide
def e605601787118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e605601787118 : Closed e605601787118 ∧ code e605601787118 = 9401694809326 := by decide
theorem cert_e605601787118 : check e605601787118 [[.under],[.under]] .three = true := by decide
def e605601787126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e605601787126 : Closed e605601787126 ∧ code e605601787126 = 9401694809334 := by decide
theorem cert_e605601787126 : check e605601787126 [[.under],[.under]] .three = true := by decide
def e605601787510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e605601787510 : Closed e605601787510 ∧ code e605601787510 = 9401694809718 := by decide
theorem cert_e605601787510 : check e605601787510 [[.under],[.under]] .three = true := by decide
def e605601820126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 3)))))))
theorem wire_e605601820126 : Closed e605601820126 ∧ code e605601820126 = 9401694842334 := by decide
theorem cert_e605601820126 : check e605601820126 [[.under],[.under]] .three = true := by decide
def e605601820142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3)) (.var 2)))))))
theorem wire_e605601820142 : Closed e605601820142 ∧ code e605601820142 = 9401694842350 := by decide
theorem cert_e605601820142 : check e605601820142 [[.under],[.under]] .three = true := by decide
def e605601820382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 3)))))))
theorem wire_e605601820382 : Closed e605601820382 ∧ code e605601820382 = 9401694842590 := by decide
theorem cert_e605601820382 : check e605601820382 [[.under],[.under]] .three = true := by decide
def e605601820406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3)) (.var 1)))))))
theorem wire_e605601820406 : Closed e605601820406 ∧ code e605601820406 = 9401694842614 := by decide
theorem cert_e605601820406 : check e605601820406 [[.under],[.under]] .three = true := by decide
def e605601820526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1)) (.var 2)))))))
theorem wire_e605601820526 : Closed e605601820526 ∧ code e605601820526 = 9401694842734 := by decide
theorem cert_e605601820526 : check e605601820526 [[.under],[.under]] .three = true := by decide
def e605601820534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2)) (.var 1)))))))
theorem wire_e605601820534 : Closed e605601820534 ∧ code e605601820534 = 9401694842742 := by decide
theorem cert_e605601820534 : check e605601820534 [[.under],[.under]] .three = true := by decide
def e605601822174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 3)))))))
theorem wire_e605601822174 : Closed e605601822174 ∧ code e605601822174 = 9401694844382 := by decide
theorem cert_e605601822174 : check e605601822174 [[.under],[.under]] .three = true := by decide
def e605601822190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3)) (.var 2)))))))
theorem wire_e605601822190 : Closed e605601822190 ∧ code e605601822190 = 9401694844398 := by decide
theorem cert_e605601822190 : check e605601822190 [[.under],[.under]] .three = true := by decide
def e605601822558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 3)))))))
theorem wire_e605601822558 : Closed e605601822558 ∧ code e605601822558 = 9401694844766 := by decide
theorem cert_e605601822558 : check e605601822558 [[.under],[.under]] .three = true := by decide
def e605601822586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 3)) (.var 0)))))))
theorem wire_e605601822586 : Closed e605601822586 ∧ code e605601822586 = 9401694844794 := by decide
theorem cert_e605601822586 : check e605601822586 [[.under],[.under]] .three = true := by decide
def e605601822638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0)) (.var 2)))))))
theorem wire_e605601822638 : Closed e605601822638 ∧ code e605601822638 = 9401694844846 := by decide
theorem cert_e605601822638 : check e605601822638 [[.under],[.under]] .three = true := by decide
def e605601822650 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 2)) (.var 0)))))))
theorem wire_e605601822650 : Closed e605601822650 ∧ code e605601822650 = 9401694844858 := by decide
theorem cert_e605601822650 : check e605601822650 [[.under],[.under]] .three = true := by decide
def e605601823454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e605601823454 : Closed e605601823454 ∧ code e605601823454 = 9401694845662 := by decide
theorem cert_e605601823454 : check e605601823454 [[.under],[.under]] .three = true := by decide
def e605601823478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e605601823478 : Closed e605601823478 ∧ code e605601823478 = 9401694845686 := by decide
theorem cert_e605601823478 : check e605601823478 [[.under],[.under]] .three = true := by decide
def e605601823582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e605601823582 : Closed e605601823582 ∧ code e605601823582 = 9401694845790 := by decide
theorem cert_e605601823582 : check e605601823582 [[.under],[.under]] .three = true := by decide
def e605601823610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e605601823610 : Closed e605601823610 ∧ code e605601823610 = 9401694845818 := by decide
theorem cert_e605601823610 : check e605601823610 [[.under],[.under]] .three = true := by decide
def e605601823702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605601823702 : Closed e605601823702 ∧ code e605601823702 = 9401694845910 := by decide
theorem cert_e605601823702 : check e605601823702 [[.under],[.under]] .three = true := by decide
def e605601823706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605601823706 : Closed e605601823706 ∧ code e605601823706 = 9401694845914 := by decide
theorem cert_e605601823706 : check e605601823706 [[.under],[.under]] .three = true := by decide
def e605601824110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605601824110 : Closed e605601824110 ∧ code e605601824110 = 9401694846318 := by decide
theorem cert_e605601824110 : check e605601824110 [[.under],[.under]] .three = true := by decide
def e605601824118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605601824118 : Closed e605601824118 ∧ code e605601824118 = 9401694846326 := by decide
theorem cert_e605601824118 : check e605601824118 [[.under],[.under]] .three = true := by decide
def e605601824174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605601824174 : Closed e605601824174 ∧ code e605601824174 = 9401694846382 := by decide
theorem cert_e605601824174 : check e605601824174 [[.under],[.under]] .three = true := by decide
def e605601824186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605601824186 : Closed e605601824186 ∧ code e605601824186 = 9401694846394 := by decide
theorem cert_e605601824186 : check e605601824186 [[.under],[.under]] .three = true := by decide
def e605601824214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605601824214 : Closed e605601824214 ∧ code e605601824214 = 9401694846422 := by decide
theorem cert_e605601824214 : check e605601824214 [[.under],[.under]] .three = true := by decide
def e605601824218 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605601824218 : Closed e605601824218 ∧ code e605601824218 = 9401694846426 := by decide
theorem cert_e605601824218 : check e605601824218 [[.under],[.under]] .three = true := by decide
def e605601832414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 3)))))))
theorem wire_e605601832414 : Closed e605601832414 ∧ code e605601832414 = 9401694854622 := by decide
theorem cert_e605601832414 : check e605601832414 [[.under],[.under]] .three = true := by decide
def e605601832430 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3))) (.var 2)))))))
theorem wire_e605601832430 : Closed e605601832430 ∧ code e605601832430 = 9401694854638 := by decide
theorem cert_e605601832430 : check e605601832430 [[.under],[.under]] .three = true := by decide
def e605601832670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 3)))))))
theorem wire_e605601832670 : Closed e605601832670 ∧ code e605601832670 = 9401694854878 := by decide
theorem cert_e605601832670 : check e605601832670 [[.under],[.under]] .three = true := by decide
def e605601832694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3))) (.var 1)))))))
theorem wire_e605601832694 : Closed e605601832694 ∧ code e605601832694 = 9401694854902 := by decide
theorem cert_e605601832694 : check e605601832694 [[.under],[.under]] .three = true := by decide
def e605601832814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1))) (.var 2)))))))
theorem wire_e605601832814 : Closed e605601832814 ∧ code e605601832814 = 9401694855022 := by decide
theorem cert_e605601832814 : check e605601832814 [[.under],[.under]] .three = true := by decide
def e605601832822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2))) (.var 1)))))))
theorem wire_e605601832822 : Closed e605601832822 ∧ code e605601832822 = 9401694855030 := by decide
theorem cert_e605601832822 : check e605601832822 [[.under],[.under]] .three = true := by decide
def e605601838046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 3))))))))
theorem wire_e605601838046 : Closed e605601838046 ∧ code e605601838046 = 9401694860254 := by decide
theorem cert_e605601838046 : check e605601838046 [[.under],[.under]] .three = true := by decide
def e605601838062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 3) (.var 2))))))))
theorem wire_e605601838062 : Closed e605601838062 ∧ code e605601838062 = 9401694860270 := by decide
theorem cert_e605601838062 : check e605601838062 [[.under],[.under]] .three = true := by decide
def e605601839582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e605601839582 : Closed e605601839582 ∧ code e605601839582 = 9401694861790 := by decide
theorem cert_e605601839582 : check e605601839582 [[.under],[.under]] .three = true := by decide
def e605601839606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e605601839606 : Closed e605601839606 ∧ code e605601839606 = 9401694861814 := by decide
theorem cert_e605601839606 : check e605601839606 [[.under],[.under]] .three = true := by decide
def e605601840366 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e605601840366 : Closed e605601840366 ∧ code e605601840366 = 9401694862574 := by decide
theorem cert_e605601840366 : check e605601840366 [[.under],[.under]] .three = true := by decide
def e605601840374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e605601840374 : Closed e605601840374 ∧ code e605601840374 = 9401694862582 := by decide
theorem cert_e605601840374 : check e605601840374 [[.under],[.under]] .three = true := by decide
def e605601844702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e605601844702 : Closed e605601844702 ∧ code e605601844702 = 9401694866910 := by decide
theorem cert_e605601844702 : check e605601844702 [[.under],[.under]] .three = true := by decide
def e605601844718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e605601844718 : Closed e605601844718 ∧ code e605601844718 = 9401694866926 := by decide
theorem cert_e605601844718 : check e605601844718 [[.under],[.under]] .three = true := by decide
def e605601845086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e605601845086 : Closed e605601845086 ∧ code e605601845086 = 9401694867294 := by decide
theorem cert_e605601845086 : check e605601845086 [[.under],[.under]] .three = true := by decide
def e605601845114 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e605601845114 : Closed e605601845114 ∧ code e605601845114 = 9401694867322 := by decide
theorem cert_e605601845114 : check e605601845114 [[.under],[.under]] .three = true := by decide
def e605601845166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e605601845166 : Closed e605601845166 ∧ code e605601845166 = 9401694867374 := by decide
theorem cert_e605601845166 : check e605601845166 [[.under],[.under]] .three = true := by decide
def e605601845178 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e605601845178 : Closed e605601845178 ∧ code e605601845178 = 9401694867386 := by decide
theorem cert_e605601845178 : check e605601845178 [[.under],[.under]] .three = true := by decide
def e605601846238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e605601846238 : Closed e605601846238 ∧ code e605601846238 = 9401694868446 := by decide
theorem cert_e605601846238 : check e605601846238 [[.under],[.under]] .three = true := by decide
def e605601846254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e605601846254 : Closed e605601846254 ∧ code e605601846254 = 9401694868462 := by decide
theorem cert_e605601846254 : check e605601846254 [[.under],[.under]] .three = true := by decide
def e605601848542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e605601848542 : Closed e605601848542 ∧ code e605601848542 = 9401694870750 := by decide
theorem cert_e605601848542 : check e605601848542 [[.under],[.under]] .three = true := by decide
def e605601848570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e605601848570 : Closed e605601848570 ∧ code e605601848570 = 9401694870778 := by decide
theorem cert_e605601848570 : check e605601848570 [[.under],[.under]] .three = true := by decide
def e605601848942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e605601848942 : Closed e605601848942 ∧ code e605601848942 = 9401694871150 := by decide
theorem cert_e605601848942 : check e605601848942 [[.under],[.under]] .three = true := by decide
def e605601848954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e605601848954 : Closed e605601848954 ∧ code e605601848954 = 9401694871162 := by decide
theorem cert_e605601848954 : check e605601848954 [[.under],[.under]] .three = true := by decide
def e605601851102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e605601851102 : Closed e605601851102 ∧ code e605601851102 = 9401694873310 := by decide
theorem cert_e605601851102 : check e605601851102 [[.under],[.under]] .three = true := by decide
def e605601851126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e605601851126 : Closed e605601851126 ∧ code e605601851126 = 9401694873334 := by decide
theorem cert_e605601851126 : check e605601851126 [[.under],[.under]] .three = true := by decide
def e605601851230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e605601851230 : Closed e605601851230 ∧ code e605601851230 = 9401694873438 := by decide
theorem cert_e605601851230 : check e605601851230 [[.under],[.under]] .three = true := by decide
def e605601851258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e605601851258 : Closed e605601851258 ∧ code e605601851258 = 9401694873466 := by decide
theorem cert_e605601851258 : check e605601851258 [[.under],[.under]] .three = true := by decide
def e605601851350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e605601851350 : Closed e605601851350 ∧ code e605601851350 = 9401694873558 := by decide
theorem cert_e605601851350 : check e605601851350 [[.under],[.under]] .three = true := by decide
def e605601851354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e605601851354 : Closed e605601851354 ∧ code e605601851354 = 9401694873562 := by decide
theorem cert_e605601851354 : check e605601851354 [[.under],[.under]] .three = true := by decide
def e605601851870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e605601851870 : Closed e605601851870 ∧ code e605601851870 = 9401694874078 := by decide
theorem cert_e605601851870 : check e605601851870 [[.under],[.under]] .three = true := by decide
def e605601851894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e605601851894 : Closed e605601851894 ∧ code e605601851894 = 9401694874102 := by decide
theorem cert_e605601851894 : check e605601851894 [[.under],[.under]] .three = true := by decide
def e605601852638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e605601852638 : Closed e605601852638 ∧ code e605601852638 = 9401694874846 := by decide
theorem cert_e605601852638 : check e605601852638 [[.under],[.under]] .three = true := by decide
def e605601852666 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e605601852666 : Closed e605601852666 ∧ code e605601852666 = 9401694874874 := by decide
theorem cert_e605601852666 : check e605601852666 [[.under],[.under]] .three = true := by decide
def e605601853238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e605601853238 : Closed e605601853238 ∧ code e605601853238 = 9401694875446 := by decide
theorem cert_e605601853238 : check e605601853238 [[.under],[.under]] .three = true := by decide
def e605601853242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e605601853242 : Closed e605601853242 ∧ code e605601853242 = 9401694875450 := by decide
theorem cert_e605601853242 : check e605601853242 [[.under],[.under]] .three = true := by decide
def e605601854318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605601854318 : Closed e605601854318 ∧ code e605601854318 = 9401694876526 := by decide
theorem cert_e605601854318 : check e605601854318 [[.under],[.under]] .three = true := by decide
def e605601854326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605601854326 : Closed e605601854326 ∧ code e605601854326 = 9401694876534 := by decide
theorem cert_e605601854326 : check e605601854326 [[.under],[.under]] .three = true := by decide
def e605601854382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605601854382 : Closed e605601854382 ∧ code e605601854382 = 9401694876590 := by decide
theorem cert_e605601854382 : check e605601854382 [[.under],[.under]] .three = true := by decide
def e605601854394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605601854394 : Closed e605601854394 ∧ code e605601854394 = 9401694876602 := by decide
theorem cert_e605601854394 : check e605601854394 [[.under],[.under]] .three = true := by decide
def e605601854422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605601854422 : Closed e605601854422 ∧ code e605601854422 = 9401694876630 := by decide
theorem cert_e605601854422 : check e605601854422 [[.under],[.under]] .three = true := by decide
def e605601854426 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605601854426 : Closed e605601854426 ∧ code e605601854426 = 9401694876634 := by decide
theorem cert_e605601854426 : check e605601854426 [[.under],[.under]] .three = true := by decide
def e605601854702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605601854702 : Closed e605601854702 ∧ code e605601854702 = 9401694876910 := by decide
theorem cert_e605601854702 : check e605601854702 [[.under],[.under]] .three = true := by decide
def e605601854710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605601854710 : Closed e605601854710 ∧ code e605601854710 = 9401694876918 := by decide
theorem cert_e605601854710 : check e605601854710 [[.under],[.under]] .three = true := by decide
def e605601855086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605601855086 : Closed e605601855086 ∧ code e605601855086 = 9401694877294 := by decide
theorem cert_e605601855086 : check e605601855086 [[.under],[.under]] .three = true := by decide
def e605601855098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605601855098 : Closed e605601855098 ∧ code e605601855098 = 9401694877306 := by decide
theorem cert_e605601855098 : check e605601855098 [[.under],[.under]] .three = true := by decide
def e605601855286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605601855286 : Closed e605601855286 ∧ code e605601855286 = 9401694877494 := by decide
theorem cert_e605601855286 : check e605601855286 [[.under],[.under]] .three = true := by decide
def e605601855290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605601855290 : Closed e605601855290 ∧ code e605601855290 = 9401694877498 := by decide
theorem cert_e605601855290 : check e605601855290 [[.under],[.under]] .three = true := by decide
def e605601871582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 3)))))))
theorem wire_e605601871582 : Closed e605601871582 ∧ code e605601871582 = 9401694893790 := by decide
theorem cert_e605601871582 : check e605601871582 [[.under],[.under]] .three = true := by decide
def e605601871606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 3)) (.var 1)))))))
theorem wire_e605601871606 : Closed e605601871606 ∧ code e605601871606 = 9401694893814 := by decide
theorem cert_e605601871606 : check e605601871606 [[.under],[.under]] .three = true := by decide
def e605601871798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e605601871798 : Closed e605601871798 ∧ code e605601871798 = 9401694894006 := by decide
theorem cert_e605601871798 : check e605601871798 [[.under],[.under]] .three = true := by decide
def e605601872606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e605601872606 : Closed e605601872606 ∧ code e605601872606 = 9401694894814 := by decide
theorem cert_e605601872606 : check e605601872606 [[.under],[.under]] .three = true := by decide
def e605601872630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e605601872630 : Closed e605601872630 ∧ code e605601872630 = 9401694894838 := by decide
theorem cert_e605601872630 : check e605601872630 [[.under],[.under]] .three = true := by decide
def e605601872734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e605601872734 : Closed e605601872734 ∧ code e605601872734 = 9401694894942 := by decide
theorem cert_e605601872734 : check e605601872734 [[.under],[.under]] .three = true := by decide
def e605601872762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e605601872762 : Closed e605601872762 ∧ code e605601872762 = 9401694894970 := by decide
theorem cert_e605601872762 : check e605601872762 [[.under],[.under]] .three = true := by decide
def e605601872854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e605601872854 : Closed e605601872854 ∧ code e605601872854 = 9401694895062 := by decide
theorem cert_e605601872854 : check e605601872854 [[.under],[.under]] .three = true := by decide
def e605601872858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e605601872858 : Closed e605601872858 ∧ code e605601872858 = 9401694895066 := by decide
theorem cert_e605601872858 : check e605601872858 [[.under],[.under]] .three = true := by decide
def e605601873590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e605601873590 : Closed e605601873590 ∧ code e605601873590 = 9401694895798 := by decide
theorem cert_e605601873590 : check e605601873590 [[.under],[.under]] .three = true := by decide
def e605601873622 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605601873622 : Closed e605601873622 ∧ code e605601873622 = 9401694895830 := by decide
theorem cert_e605601873622 : check e605601873622 [[.under],[.under]] .three = true := by decide
def e605601873626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605601873626 : Closed e605601873626 ∧ code e605601873626 = 9401694895834 := by decide
theorem cert_e605601873626 : check e605601873626 [[.under],[.under]] .three = true := by decide
def e605601877726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e605601877726 : Closed e605601877726 ∧ code e605601877726 = 9401694899934 := by decide
theorem cert_e605601877726 : check e605601877726 [[.under],[.under]] .three = true := by decide
def e605601877750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e605601877750 : Closed e605601877750 ∧ code e605601877750 = 9401694899958 := by decide
theorem cert_e605601877750 : check e605601877750 [[.under],[.under]] .three = true := by decide
def e605601877942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e605601877942 : Closed e605601877942 ∧ code e605601877942 = 9401694900150 := by decide
theorem cert_e605601877942 : check e605601877942 [[.under],[.under]] .three = true := by decide
def e605601880542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e605601880542 : Closed e605601880542 ∧ code e605601880542 = 9401694902750 := by decide
theorem cert_e605601880542 : check e605601880542 [[.under],[.under]] .three = true := by decide
def e605601880566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e605601880566 : Closed e605601880566 ∧ code e605601880566 = 9401694902774 := by decide
theorem cert_e605601880566 : check e605601880566 [[.under],[.under]] .three = true := by decide
def e605601881718 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e605601881718 : Closed e605601881718 ∧ code e605601881718 = 9401694903926 := by decide
theorem cert_e605601881718 : check e605601881718 [[.under],[.under]] .three = true := by decide
def e605601883870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e605601883870 : Closed e605601883870 ∧ code e605601883870 = 9401694906078 := by decide
theorem cert_e605601883870 : check e605601883870 [[.under],[.under]] .three = true := by decide
def e605601883894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e605601883894 : Closed e605601883894 ∧ code e605601883894 = 9401694906102 := by decide
theorem cert_e605601883894 : check e605601883894 [[.under],[.under]] .three = true := by decide
def e605601883998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e605601883998 : Closed e605601883998 ∧ code e605601883998 = 9401694906206 := by decide
theorem cert_e605601883998 : check e605601883998 [[.under],[.under]] .three = true := by decide
def e605601884026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e605601884026 : Closed e605601884026 ∧ code e605601884026 = 9401694906234 := by decide
theorem cert_e605601884026 : check e605601884026 [[.under],[.under]] .three = true := by decide
def e605601884118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e605601884118 : Closed e605601884118 ∧ code e605601884118 = 9401694906326 := by decide
theorem cert_e605601884118 : check e605601884118 [[.under],[.under]] .three = true := by decide
def e605601884122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e605601884122 : Closed e605601884122 ∧ code e605601884122 = 9401694906330 := by decide
theorem cert_e605601884122 : check e605601884122 [[.under],[.under]] .three = true := by decide
def e605601884638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e605601884638 : Closed e605601884638 ∧ code e605601884638 = 9401694906846 := by decide
theorem cert_e605601884638 : check e605601884638 [[.under],[.under]] .three = true := by decide
def e605601884662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e605601884662 : Closed e605601884662 ∧ code e605601884662 = 9401694906870 := by decide
theorem cert_e605601884662 : check e605601884662 [[.under],[.under]] .three = true := by decide
def e605601885406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e605601885406 : Closed e605601885406 ∧ code e605601885406 = 9401694907614 := by decide
theorem cert_e605601885406 : check e605601885406 [[.under],[.under]] .three = true := by decide
def e605601885434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e605601885434 : Closed e605601885434 ∧ code e605601885434 = 9401694907642 := by decide
theorem cert_e605601885434 : check e605601885434 [[.under],[.under]] .three = true := by decide
def e605601886006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e605601886006 : Closed e605601886006 ∧ code e605601886006 = 9401694908214 := by decide
theorem cert_e605601886006 : check e605601886006 [[.under],[.under]] .three = true := by decide
def e605601886010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e605601886010 : Closed e605601886010 ∧ code e605601886010 = 9401694908218 := by decide
theorem cert_e605601886010 : check e605601886010 [[.under],[.under]] .three = true := by decide
def e605601888694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e605601888694 : Closed e605601888694 ∧ code e605601888694 = 9401694910902 := by decide
theorem cert_e605601888694 : check e605601888694 [[.under],[.under]] .three = true := by decide
def e605601888726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e605601888726 : Closed e605601888726 ∧ code e605601888726 = 9401694910934 := by decide
theorem cert_e605601888726 : check e605601888726 [[.under],[.under]] .three = true := by decide
def e605601888730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e605601888730 : Closed e605601888730 ∧ code e605601888730 = 9401694910938 := by decide
theorem cert_e605601888730 : check e605601888730 [[.under],[.under]] .three = true := by decide
def e605601888886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e605601888886 : Closed e605601888886 ∧ code e605601888886 = 9401694911094 := by decide
theorem cert_e605601888886 : check e605601888886 [[.under],[.under]] .three = true := by decide
def e605601889078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e605601889078 : Closed e605601889078 ∧ code e605601889078 = 9401694911286 := by decide
theorem cert_e605601889078 : check e605601889078 [[.under],[.under]] .three = true := by decide
def e605601889082 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e605601889082 : Closed e605601889082 ∧ code e605601889082 = 9401694911290 := by decide
theorem cert_e605601889082 : check e605601889082 [[.under],[.under]] .three = true := by decide
def e605601897326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e605601897326 : Closed e605601897326 ∧ code e605601897326 = 9401694919534 := by decide
theorem cert_e605601897326 : check e605601897326 [[.under],[.under]] .three = true := by decide
def e605601897334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e605601897334 : Closed e605601897334 ∧ code e605601897334 = 9401694919542 := by decide
theorem cert_e605601897334 : check e605601897334 [[.under],[.under]] .three = true := by decide
def e605601897398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)))))))
theorem wire_e605601897398 : Closed e605601897398 ∧ code e605601897398 = 9401694919606 := by decide
theorem cert_e605601897398 : check e605601897398 [[.under],[.under]] .three = true := by decide
def e605601897838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e605601897838 : Closed e605601897838 ∧ code e605601897838 = 9401694920046 := by decide
theorem cert_e605601897838 : check e605601897838 [[.under],[.under]] .three = true := by decide
def e605601897846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e605601897846 : Closed e605601897846 ∧ code e605601897846 = 9401694920054 := by decide
theorem cert_e605601897846 : check e605601897846 [[.under],[.under]] .three = true := by decide
def e605601897902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e605601897902 : Closed e605601897902 ∧ code e605601897902 = 9401694920110 := by decide
theorem cert_e605601897902 : check e605601897902 [[.under],[.under]] .three = true := by decide
def e605601897914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e605601897914 : Closed e605601897914 ∧ code e605601897914 = 9401694920122 := by decide
theorem cert_e605601897914 : check e605601897914 [[.under],[.under]] .three = true := by decide
def e605601897942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e605601897942 : Closed e605601897942 ∧ code e605601897942 = 9401694920150 := by decide
theorem cert_e605601897942 : check e605601897942 [[.under],[.under]] .three = true := by decide
def e605601897946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e605601897946 : Closed e605601897946 ∧ code e605601897946 = 9401694920154 := by decide
theorem cert_e605601897946 : check e605601897946 [[.under],[.under]] .three = true := by decide
def e605601898166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e605601898166 : Closed e605601898166 ∧ code e605601898166 = 9401694920374 := by decide
theorem cert_e605601898166 : check e605601898166 [[.under],[.under]] .three = true := by decide
def e605601898198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e605601898198 : Closed e605601898198 ∧ code e605601898198 = 9401694920406 := by decide
theorem cert_e605601898198 : check e605601898198 [[.under],[.under]] .three = true := by decide
def e605601898202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e605601898202 : Closed e605601898202 ∧ code e605601898202 = 9401694920410 := by decide
theorem cert_e605601898202 : check e605601898202 [[.under],[.under]] .three = true := by decide
def e605601900398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e605601900398 : Closed e605601900398 ∧ code e605601900398 = 9401694922606 := by decide
theorem cert_e605601900398 : check e605601900398 [[.under],[.under]] .three = true := by decide
def e605601900406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e605601900406 : Closed e605601900406 ∧ code e605601900406 = 9401694922614 := by decide
theorem cert_e605601900406 : check e605601900406 [[.under],[.under]] .three = true := by decide
def e605601900470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e605601900470 : Closed e605601900470 ∧ code e605601900470 = 9401694922678 := by decide
theorem cert_e605601900470 : check e605601900470 [[.under],[.under]] .three = true := by decide
def e605601901806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e605601901806 : Closed e605601901806 ∧ code e605601901806 = 9401694924014 := by decide
theorem cert_e605601901806 : check e605601901806 [[.under],[.under]] .three = true := by decide
def e605601901814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e605601901814 : Closed e605601901814 ∧ code e605601901814 = 9401694924022 := by decide
theorem cert_e605601901814 : check e605601901814 [[.under],[.under]] .three = true := by decide
def e605601902198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e605601902198 : Closed e605601902198 ∧ code e605601902198 = 9401694924406 := by decide
theorem cert_e605601902198 : check e605601902198 [[.under],[.under]] .three = true := by decide
def e605601903470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e605601903470 : Closed e605601903470 ∧ code e605601903470 = 9401694925678 := by decide
theorem cert_e605601903470 : check e605601903470 [[.under],[.under]] .three = true := by decide
def e605601903478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e605601903478 : Closed e605601903478 ∧ code e605601903478 = 9401694925686 := by decide
theorem cert_e605601903478 : check e605601903478 [[.under],[.under]] .three = true := by decide
def e605601903534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e605601903534 : Closed e605601903534 ∧ code e605601903534 = 9401694925742 := by decide
theorem cert_e605601903534 : check e605601903534 [[.under],[.under]] .three = true := by decide
def e605601903546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e605601903546 : Closed e605601903546 ∧ code e605601903546 = 9401694925754 := by decide
theorem cert_e605601903546 : check e605601903546 [[.under],[.under]] .three = true := by decide
def e605601903574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e605601903574 : Closed e605601903574 ∧ code e605601903574 = 9401694925782 := by decide
theorem cert_e605601903574 : check e605601903574 [[.under],[.under]] .three = true := by decide
def e605601903578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e605601903578 : Closed e605601903578 ∧ code e605601903578 = 9401694925786 := by decide
theorem cert_e605601903578 : check e605601903578 [[.under],[.under]] .three = true := by decide
def e605601903854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e605601903854 : Closed e605601903854 ∧ code e605601903854 = 9401694926062 := by decide
theorem cert_e605601903854 : check e605601903854 [[.under],[.under]] .three = true := by decide
def e605601903862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e605601903862 : Closed e605601903862 ∧ code e605601903862 = 9401694926070 := by decide
theorem cert_e605601903862 : check e605601903862 [[.under],[.under]] .three = true := by decide
def e605601904238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e605601904238 : Closed e605601904238 ∧ code e605601904238 = 9401694926446 := by decide
theorem cert_e605601904238 : check e605601904238 [[.under],[.under]] .three = true := by decide
def e605601904250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e605601904250 : Closed e605601904250 ∧ code e605601904250 = 9401694926458 := by decide
theorem cert_e605601904250 : check e605601904250 [[.under],[.under]] .three = true := by decide
def e605601904438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e605601904438 : Closed e605601904438 ∧ code e605601904438 = 9401694926646 := by decide
theorem cert_e605601904438 : check e605601904438 [[.under],[.under]] .three = true := by decide
def e605601904442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e605601904442 : Closed e605601904442 ∧ code e605601904442 = 9401694926650 := by decide
theorem cert_e605601904442 : check e605601904442 [[.under],[.under]] .three = true := by decide
def e605601905078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e605601905078 : Closed e605601905078 ∧ code e605601905078 = 9401694927286 := by decide
theorem cert_e605601905078 : check e605601905078 [[.under],[.under]] .three = true := by decide
def e605601905110 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e605601905110 : Closed e605601905110 ∧ code e605601905110 = 9401694927318 := by decide
theorem cert_e605601905110 : check e605601905110 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
