import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392308727322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308727322 : Closed e2392308727322 ∧ code e2392308727322 = 11188401749530 := by decide
private def t_e2392308727322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308727322 : ¬ IsSelfInterpreter e2392308727322 :=
  wSource (t := t_e2392308727322) (replay_sound (ps := []) (t := e2392308727322) (by decide)) (by decide)
def e2392308739610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308739610 : Closed e2392308739610 ∧ code e2392308739610 = 11188401761818 := by decide
private def t_e2392308739610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308739610 : ¬ IsSelfInterpreter e2392308739610 :=
  wSource (t := t_e2392308739610) (replay_sound (ps := []) (t := e2392308739610) (by decide)) (by decide)
def e2392308742682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308742682 : Closed e2392308742682 ∧ code e2392308742682 = 11188401764890 := by decide
private def t_e2392308742682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308742682 : ¬ IsSelfInterpreter e2392308742682 :=
  wSource (t := t_e2392308742682) (replay_sound (ps := []) (t := e2392308742682) (by decide)) (by decide)
def e2392308768794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392308768794 : Closed e2392308768794 ∧ code e2392308768794 = 11188401791002 := by decide
theorem cert_e2392308768794 : check e2392308768794 [[],[.left]] .smaller = true := by decide
def e2392308768886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392308768886 : Closed e2392308768886 ∧ code e2392308768886 = 11188401791094 := by decide
private def t_e2392308768886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392308768886 : ¬ IsSelfInterpreter e2392308768886 :=
  wSource (t := t_e2392308768886) (replay_sound (ps := []) (t := e2392308768886) (by decide)) (by decide)
def e2392308769130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392308769130 : Closed e2392308769130 ∧ code e2392308769130 = 11188401791338 := by decide
private def t_e2392308769130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392308769130 : ¬ IsSelfInterpreter e2392308769130 :=
  wSource (t := t_e2392308769130) (replay_sound (ps := []) (t := e2392308769130) (by decide)) (by decide)
def e2392308769178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392308769178 : Closed e2392308769178 ∧ code e2392308769178 = 11188401791386 := by decide
private def t_e2392308769178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392308769178 : ¬ IsSelfInterpreter e2392308769178 :=
  wSource (t := t_e2392308769178) (replay_sound (ps := []) (t := e2392308769178) (by decide)) (by decide)
def e2392308773062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392308773062 : Closed e2392308773062 ∧ code e2392308773062 = 11188401795270 := by decide
theorem cert_e2392308773062 : check e2392308773062 [[]] .width = true := by decide
def e2392308790810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308790810 : Closed e2392308790810 ∧ code e2392308790810 = 11188401813018 := by decide
private def t_e2392308790810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308790810 : ¬ IsSelfInterpreter e2392308790810 :=
  wSource (t := t_e2392308790810) (replay_sound (ps := []) (t := e2392308790810) (by decide)) (by decide)
def e2392308791834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308791834 : Closed e2392308791834 ∧ code e2392308791834 = 11188401814042 := by decide
private def t_e2392308791834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308791834 : ¬ IsSelfInterpreter e2392308791834 :=
  wSource (t := t_e2392308791834) (replay_sound (ps := []) (t := e2392308791834) (by decide)) (by decide)
def e2392308801562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392308801562 : Closed e2392308801562 ∧ code e2392308801562 = 11188401823770 := by decide
theorem cert_e2392308801562 : check e2392308801562 [[],[.left]] .smaller = true := by decide
def e2392308801654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392308801654 : Closed e2392308801654 ∧ code e2392308801654 = 11188401823862 := by decide
private def t_e2392308801654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392308801654 : ¬ IsSelfInterpreter e2392308801654 :=
  wSource (t := t_e2392308801654) (replay_sound (ps := []) (t := e2392308801654) (by decide)) (by decide)
def e2392308801898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392308801898 : Closed e2392308801898 ∧ code e2392308801898 = 11188401824106 := by decide
private def t_e2392308801898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392308801898 : ¬ IsSelfInterpreter e2392308801898 :=
  wSource (t := t_e2392308801898) (replay_sound (ps := []) (t := e2392308801898) (by decide)) (by decide)
def e2392308801946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392308801946 : Closed e2392308801946 ∧ code e2392308801946 = 11188401824154 := by decide
private def t_e2392308801946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392308801946 : ¬ IsSelfInterpreter e2392308801946 :=
  wSource (t := t_e2392308801946) (replay_sound (ps := []) (t := e2392308801946) (by decide)) (by decide)
def e2392308807706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392308807706 : Closed e2392308807706 ∧ code e2392308807706 = 11188401829914 := by decide
theorem cert_e2392308807706 : check e2392308807706 [[]] .width = true := by decide
def e2392308813338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308813338 : Closed e2392308813338 ∧ code e2392308813338 = 11188401835546 := by decide
private def t_e2392308813338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308813338 : ¬ IsSelfInterpreter e2392308813338 :=
  wSource (t := t_e2392308813338) (replay_sound (ps := []) (t := e2392308813338) (by decide)) (by decide)
def e2392308822214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392308822214 : Closed e2392308822214 ∧ code e2392308822214 = 11188401844422 := by decide
theorem cert_e2392308822214 : check e2392308822214 [[]] .width = true := by decide
def e2392308824090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392308824090 : Closed e2392308824090 ∧ code e2392308824090 = 11188401846298 := by decide
theorem cert_e2392308824090 : check e2392308824090 [[]] .width = true := by decide
def e2392308899354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308899354 : Closed e2392308899354 ∧ code e2392308899354 = 11188401921562 := by decide
private def t_e2392308899354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308899354 : ¬ IsSelfInterpreter e2392308899354 :=
  wSource (t := t_e2392308899354) (replay_sound (ps := []) (t := e2392308899354) (by decide)) (by decide)
def e2392308906522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308906522 : Closed e2392308906522 ∧ code e2392308906522 = 11188401928730 := by decide
private def t_e2392308906522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308906522 : ¬ IsSelfInterpreter e2392308906522 :=
  wSource (t := t_e2392308906522) (replay_sound (ps := []) (t := e2392308906522) (by decide)) (by decide)
def e2392308952602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308952602 : Closed e2392308952602 ∧ code e2392308952602 = 11188401974810 := by decide
private def t_e2392308952602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308952602 : ¬ IsSelfInterpreter e2392308952602 :=
  wSource (t := t_e2392308952602) (replay_sound (ps := []) (t := e2392308952602) (by decide)) (by decide)
def e2392308955674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308955674 : Closed e2392308955674 ∧ code e2392308955674 = 11188401977882 := by decide
private def t_e2392308955674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308955674 : ¬ IsSelfInterpreter e2392308955674 :=
  wSource (t := t_e2392308955674) (replay_sound (ps := []) (t := e2392308955674) (by decide)) (by decide)
def e2392308967962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308967962 : Closed e2392308967962 ∧ code e2392308967962 = 11188401990170 := by decide
private def t_e2392308967962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308967962 : ¬ IsSelfInterpreter e2392308967962 :=
  wSource (t := t_e2392308967962) (replay_sound (ps := []) (t := e2392308967962) (by decide)) (by decide)
def e2392308989466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308989466 : Closed e2392308989466 ∧ code e2392308989466 = 11188402011674 := by decide
private def t_e2392308989466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308989466 : ¬ IsSelfInterpreter e2392308989466 :=
  wSource (t := t_e2392308989466) (replay_sound (ps := []) (t := e2392308989466) (by decide)) (by decide)
def e2392309001754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309001754 : Closed e2392309001754 ∧ code e2392309001754 = 11188402023962 := by decide
private def t_e2392309001754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309001754 : ¬ IsSelfInterpreter e2392309001754 :=
  wSource (t := t_e2392309001754) (replay_sound (ps := []) (t := e2392309001754) (by decide)) (by decide)
def e2392309004826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309004826 : Closed e2392309004826 ∧ code e2392309004826 = 11188402027034 := by decide
private def t_e2392309004826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309004826 : ¬ IsSelfInterpreter e2392309004826 :=
  wSource (t := t_e2392309004826) (replay_sound (ps := []) (t := e2392309004826) (by decide)) (by decide)
def e2392309030938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392309030938 : Closed e2392309030938 ∧ code e2392309030938 = 11188402053146 := by decide
theorem cert_e2392309030938 : check e2392309030938 [[],[.left]] .smaller = true := by decide
def e2392309031030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392309031030 : Closed e2392309031030 ∧ code e2392309031030 = 11188402053238 := by decide
private def t_e2392309031030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392309031030 : ¬ IsSelfInterpreter e2392309031030 :=
  wSource (t := t_e2392309031030) (replay_sound (ps := []) (t := e2392309031030) (by decide)) (by decide)
def e2392309031274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392309031274 : Closed e2392309031274 ∧ code e2392309031274 = 11188402053482 := by decide
private def t_e2392309031274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392309031274 : ¬ IsSelfInterpreter e2392309031274 :=
  wSource (t := t_e2392309031274) (replay_sound (ps := []) (t := e2392309031274) (by decide)) (by decide)
def e2392309031322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392309031322 : Closed e2392309031322 ∧ code e2392309031322 = 11188402053530 := by decide
private def t_e2392309031322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392309031322 : ¬ IsSelfInterpreter e2392309031322 :=
  wSource (t := t_e2392309031322) (replay_sound (ps := []) (t := e2392309031322) (by decide)) (by decide)
def e2392309035206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392309035206 : Closed e2392309035206 ∧ code e2392309035206 = 11188402057414 := by decide
theorem cert_e2392309035206 : check e2392309035206 [[]] .width = true := by decide
def e2392309078554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309078554 : Closed e2392309078554 ∧ code e2392309078554 = 11188402100762 := by decide
private def t_e2392309078554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309078554 : ¬ IsSelfInterpreter e2392309078554 :=
  wSource (t := t_e2392309078554) (replay_sound (ps := []) (t := e2392309078554) (by decide)) (by decide)
def e2392309080090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392309080090 : Closed e2392309080090 ∧ code e2392309080090 = 11188402102298 := by decide
theorem cert_e2392309080090 : check e2392309080090 [[],[.left]] .smaller = true := by decide
def e2392309080182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392309080182 : Closed e2392309080182 ∧ code e2392309080182 = 11188402102390 := by decide
private def t_e2392309080182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392309080182 : ¬ IsSelfInterpreter e2392309080182 :=
  wSource (t := t_e2392309080182) (replay_sound (ps := []) (t := e2392309080182) (by decide)) (by decide)
def e2392309080426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392309080426 : Closed e2392309080426 ∧ code e2392309080426 = 11188402102634 := by decide
private def t_e2392309080426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392309080426 : ¬ IsSelfInterpreter e2392309080426 :=
  wSource (t := t_e2392309080426) (replay_sound (ps := []) (t := e2392309080426) (by decide)) (by decide)
def e2392309080474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392309080474 : Closed e2392309080474 ∧ code e2392309080474 = 11188402102682 := by decide
private def t_e2392309080474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392309080474 : ¬ IsSelfInterpreter e2392309080474 :=
  wSource (t := t_e2392309080474) (replay_sound (ps := []) (t := e2392309080474) (by decide)) (by decide)
def e2392309089818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309089818 : Closed e2392309089818 ∧ code e2392309089818 = 11188402112026 := by decide
private def t_e2392309089818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309089818 : ¬ IsSelfInterpreter e2392309089818 :=
  wSource (t := t_e2392309089818) (replay_sound (ps := []) (t := e2392309089818) (by decide)) (by decide)
def e2392309092550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392309092550 : Closed e2392309092550 ∧ code e2392309092550 = 11188402114758 := by decide
theorem cert_e2392309092550 : check e2392309092550 [[]] .width = true := by decide
def e2392309159450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309159450 : Closed e2392309159450 ∧ code e2392309159450 = 11188402181658 := by decide
private def t_e2392309159450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309159450 : ¬ IsSelfInterpreter e2392309159450 :=
  wSource (t := t_e2392309159450) (replay_sound (ps := []) (t := e2392309159450) (by decide)) (by decide)
def e2392309160474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309160474 : Closed e2392309160474 ∧ code e2392309160474 = 11188402182682 := by decide
private def t_e2392309160474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309160474 : ¬ IsSelfInterpreter e2392309160474 :=
  wSource (t := t_e2392309160474) (replay_sound (ps := []) (t := e2392309160474) (by decide)) (by decide)
def e2392309164570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309164570 : Closed e2392309164570 ∧ code e2392309164570 = 11188402186778 := by decide
private def t_e2392309164570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309164570 : ¬ IsSelfInterpreter e2392309164570 :=
  wSource (t := t_e2392309164570) (replay_sound (ps := []) (t := e2392309164570) (by decide)) (by decide)
def e2392309184026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309184026 : Closed e2392309184026 ∧ code e2392309184026 = 11188402206234 := by decide
private def t_e2392309184026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309184026 : ¬ IsSelfInterpreter e2392309184026 :=
  wSource (t := t_e2392309184026) (replay_sound (ps := []) (t := e2392309184026) (by decide)) (by decide)
def e2392309185050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309185050 : Closed e2392309185050 ∧ code e2392309185050 = 11188402207258 := by decide
private def t_e2392309185050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309185050 : ¬ IsSelfInterpreter e2392309185050 :=
  wSource (t := t_e2392309185050) (replay_sound (ps := []) (t := e2392309185050) (by decide)) (by decide)
def e2392309194778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392309194778 : Closed e2392309194778 ∧ code e2392309194778 = 11188402216986 := by decide
theorem cert_e2392309194778 : check e2392309194778 [[],[.left]] .smaller = true := by decide
def e2392309194870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392309194870 : Closed e2392309194870 ∧ code e2392309194870 = 11188402217078 := by decide
private def t_e2392309194870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392309194870 : ¬ IsSelfInterpreter e2392309194870 :=
  wSource (t := t_e2392309194870) (replay_sound (ps := []) (t := e2392309194870) (by decide)) (by decide)
def e2392309195114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392309195114 : Closed e2392309195114 ∧ code e2392309195114 = 11188402217322 := by decide
private def t_e2392309195114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392309195114 : ¬ IsSelfInterpreter e2392309195114 :=
  wSource (t := t_e2392309195114) (replay_sound (ps := []) (t := e2392309195114) (by decide)) (by decide)
def e2392309195162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392309195162 : Closed e2392309195162 ∧ code e2392309195162 = 11188402217370 := by decide
private def t_e2392309195162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392309195162 : ¬ IsSelfInterpreter e2392309195162 :=
  wSource (t := t_e2392309195162) (replay_sound (ps := []) (t := e2392309195162) (by decide)) (by decide)
def e2392309200922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392309200922 : Closed e2392309200922 ∧ code e2392309200922 = 11188402223130 := by decide
theorem cert_e2392309200922 : check e2392309200922 [[]] .width = true := by decide
def e2392309209626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309209626 : Closed e2392309209626 ∧ code e2392309209626 = 11188402231834 := by decide
private def t_e2392309209626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309209626 : ¬ IsSelfInterpreter e2392309209626 :=
  wSource (t := t_e2392309209626) (replay_sound (ps := []) (t := e2392309209626) (by decide)) (by decide)
def e2392309211162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392309211162 : Closed e2392309211162 ∧ code e2392309211162 = 11188402233370 := by decide
theorem cert_e2392309211162 : check e2392309211162 [[],[.left]] .smaller = true := by decide
def e2392309211254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392309211254 : Closed e2392309211254 ∧ code e2392309211254 = 11188402233462 := by decide
private def t_e2392309211254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392309211254 : ¬ IsSelfInterpreter e2392309211254 :=
  wSource (t := t_e2392309211254) (replay_sound (ps := []) (t := e2392309211254) (by decide)) (by decide)
def e2392309211498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392309211498 : Closed e2392309211498 ∧ code e2392309211498 = 11188402233706 := by decide
private def t_e2392309211498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392309211498 : ¬ IsSelfInterpreter e2392309211498 :=
  wSource (t := t_e2392309211498) (replay_sound (ps := []) (t := e2392309211498) (by decide)) (by decide)
def e2392309211546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392309211546 : Closed e2392309211546 ∧ code e2392309211546 = 11188402233754 := by decide
private def t_e2392309211546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392309211546 : ¬ IsSelfInterpreter e2392309211546 :=
  wSource (t := t_e2392309211546) (replay_sound (ps := []) (t := e2392309211546) (by decide)) (by decide)
def e2392309229594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392309229594 : Closed e2392309229594 ∧ code e2392309229594 = 11188402251802 := by decide
theorem cert_e2392309229594 : check e2392309229594 [[]] .width = true := by decide
def e2392309249562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309249562 : Closed e2392309249562 ∧ code e2392309249562 = 11188402271770 := by decide
private def t_e2392309249562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309249562 : ¬ IsSelfInterpreter e2392309249562 :=
  wSource (t := t_e2392309249562) (replay_sound (ps := []) (t := e2392309249562) (by decide)) (by decide)
def e2392309250586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309250586 : Closed e2392309250586 ∧ code e2392309250586 = 11188402272794 := by decide
private def t_e2392309250586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309250586 : ¬ IsSelfInterpreter e2392309250586 :=
  wSource (t := t_e2392309250586) (replay_sound (ps := []) (t := e2392309250586) (by decide)) (by decide)
def e2392309272090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309272090 : Closed e2392309272090 ∧ code e2392309272090 = 11188402294298 := by decide
private def t_e2392309272090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309272090 : ¬ IsSelfInterpreter e2392309272090 :=
  wSource (t := t_e2392309272090) (replay_sound (ps := []) (t := e2392309272090) (by decide)) (by decide)
def e2392309280966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392309280966 : Closed e2392309280966 ∧ code e2392309280966 = 11188402303174 := by decide
theorem cert_e2392309280966 : check e2392309280966 [[]] .width = true := by decide
def e2392309282842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392309282842 : Closed e2392309282842 ∧ code e2392309282842 = 11188402305050 := by decide
theorem cert_e2392309282842 : check e2392309282842 [[]] .width = true := by decide
def e2392309286426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309286426 : Closed e2392309286426 ∧ code e2392309286426 = 11188402308634 := by decide
private def t_e2392309286426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309286426 : ¬ IsSelfInterpreter e2392309286426 :=
  wSource (t := t_e2392309286426) (replay_sound (ps := []) (t := e2392309286426) (by decide)) (by decide)
def e2392309289158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392309289158 : Closed e2392309289158 ∧ code e2392309289158 = 11188402311366 := by decide
theorem cert_e2392309289158 : check e2392309289158 [[]] .width = true := by decide
def e2392309295130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392309295130 : Closed e2392309295130 ∧ code e2392309295130 = 11188402317338 := by decide
theorem cert_e2392309295130 : check e2392309295130 [[]] .width = true := by decide
def e2392309620250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309620250 : Closed e2392309620250 ∧ code e2392309620250 = 11188402642458 := by decide
private def t_e2392309620250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309620250 : ¬ IsSelfInterpreter e2392309620250 :=
  wSource (t := t_e2392309620250) (replay_sound (ps := []) (t := e2392309620250) (by decide)) (by decide)
def e2392309624346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392309624346 : Closed e2392309624346 ∧ code e2392309624346 = 11188402646554 := by decide
private def t_e2392309624346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392309624346 : ¬ IsSelfInterpreter e2392309624346 :=
  wSource (t := t_e2392309624346) (replay_sound (ps := []) (t := e2392309624346) (by decide)) (by decide)
def e2392310115866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310115866 : Closed e2392310115866 ∧ code e2392310115866 = 11188403138074 := by decide
private def t_e2392310115866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310115866 : ¬ IsSelfInterpreter e2392310115866 :=
  wSource (t := t_e2392310115866) (replay_sound (ps := []) (t := e2392310115866) (by decide)) (by decide)
def e2392310117914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310117914 : Closed e2392310117914 ∧ code e2392310117914 = 11188403140122 := by decide
private def t_e2392310117914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310117914 : ¬ IsSelfInterpreter e2392310117914 :=
  wSource (t := t_e2392310117914) (replay_sound (ps := []) (t := e2392310117914) (by decide)) (by decide)
def e2392310132250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310132250 : Closed e2392310132250 ∧ code e2392310132250 = 11188403154458 := by decide
private def t_e2392310132250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310132250 : ¬ IsSelfInterpreter e2392310132250 :=
  wSource (t := t_e2392310132250) (replay_sound (ps := []) (t := e2392310132250) (by decide)) (by decide)
def e2392310135322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310135322 : Closed e2392310135322 ∧ code e2392310135322 = 11188403157530 := by decide
private def t_e2392310135322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310135322 : ¬ IsSelfInterpreter e2392310135322 :=
  wSource (t := t_e2392310135322) (replay_sound (ps := []) (t := e2392310135322) (by decide)) (by decide)
def e2392310142490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310142490 : Closed e2392310142490 ∧ code e2392310142490 = 11188403164698 := by decide
private def t_e2392310142490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310142490 : ¬ IsSelfInterpreter e2392310142490 :=
  wSource (t := t_e2392310142490) (replay_sound (ps := []) (t := e2392310142490) (by decide)) (by decide)
def e2392310143514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310143514 : Closed e2392310143514 ∧ code e2392310143514 = 11188403165722 := by decide
private def t_e2392310143514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310143514 : ¬ IsSelfInterpreter e2392310143514 :=
  wSource (t := t_e2392310143514) (replay_sound (ps := []) (t := e2392310143514) (by decide)) (by decide)
def e2392310214170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310214170 : Closed e2392310214170 ∧ code e2392310214170 = 11188403236378 := by decide
private def t_e2392310214170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310214170 : ¬ IsSelfInterpreter e2392310214170 :=
  wSource (t := t_e2392310214170) (replay_sound (ps := []) (t := e2392310214170) (by decide)) (by decide)
def e2392310216218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310216218 : Closed e2392310216218 ∧ code e2392310216218 = 11188403238426 := by decide
private def t_e2392310216218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310216218 : ¬ IsSelfInterpreter e2392310216218 :=
  wSource (t := t_e2392310216218) (replay_sound (ps := []) (t := e2392310216218) (by decide)) (by decide)
def e2392310300186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310300186 : Closed e2392310300186 ∧ code e2392310300186 = 11188403322394 := by decide
private def t_e2392310300186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310300186 : ¬ IsSelfInterpreter e2392310300186 :=
  wSource (t := t_e2392310300186) (replay_sound (ps := []) (t := e2392310300186) (by decide)) (by decide)
def e2392310312474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310312474 : Closed e2392310312474 ∧ code e2392310312474 = 11188403334682 := by decide
private def t_e2392310312474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310312474 : ¬ IsSelfInterpreter e2392310312474 :=
  wSource (t := t_e2392310312474) (replay_sound (ps := []) (t := e2392310312474) (by decide)) (by decide)
def e2392310315546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310315546 : Closed e2392310315546 ∧ code e2392310315546 = 11188403337754 := by decide
private def t_e2392310315546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310315546 : ¬ IsSelfInterpreter e2392310315546 :=
  wSource (t := t_e2392310315546) (replay_sound (ps := []) (t := e2392310315546) (by decide)) (by decide)
def e2392310341658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392310341658 : Closed e2392310341658 ∧ code e2392310341658 = 11188403363866 := by decide
theorem cert_e2392310341658 : check e2392310341658 [[],[.left]] .smaller = true := by decide
def e2392310341750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392310341750 : Closed e2392310341750 ∧ code e2392310341750 = 11188403363958 := by decide
private def t_e2392310341750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392310341750 : ¬ IsSelfInterpreter e2392310341750 :=
  wSource (t := t_e2392310341750) (replay_sound (ps := []) (t := e2392310341750) (by decide)) (by decide)
def e2392310341994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392310341994 : Closed e2392310341994 ∧ code e2392310341994 = 11188403364202 := by decide
private def t_e2392310341994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392310341994 : ¬ IsSelfInterpreter e2392310341994 :=
  wSource (t := t_e2392310341994) (replay_sound (ps := []) (t := e2392310341994) (by decide)) (by decide)
def e2392310342042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392310342042 : Closed e2392310342042 ∧ code e2392310342042 = 11188403364250 := by decide
private def t_e2392310342042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392310342042 : ¬ IsSelfInterpreter e2392310342042 :=
  wSource (t := t_e2392310342042) (replay_sound (ps := []) (t := e2392310342042) (by decide)) (by decide)
def e2392310345926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392310345926 : Closed e2392310345926 ∧ code e2392310345926 = 11188403368134 := by decide
theorem cert_e2392310345926 : check e2392310345926 [[]] .width = true := by decide
def e2392310363674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310363674 : Closed e2392310363674 ∧ code e2392310363674 = 11188403385882 := by decide
private def t_e2392310363674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310363674 : ¬ IsSelfInterpreter e2392310363674 :=
  wSource (t := t_e2392310363674) (replay_sound (ps := []) (t := e2392310363674) (by decide)) (by decide)
def e2392310364698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310364698 : Closed e2392310364698 ∧ code e2392310364698 = 11188403386906 := by decide
private def t_e2392310364698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310364698 : ¬ IsSelfInterpreter e2392310364698 :=
  wSource (t := t_e2392310364698) (replay_sound (ps := []) (t := e2392310364698) (by decide)) (by decide)
def e2392310374426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392310374426 : Closed e2392310374426 ∧ code e2392310374426 = 11188403396634 := by decide
theorem cert_e2392310374426 : check e2392310374426 [[],[.left]] .smaller = true := by decide
def e2392310374518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392310374518 : Closed e2392310374518 ∧ code e2392310374518 = 11188403396726 := by decide
private def t_e2392310374518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392310374518 : ¬ IsSelfInterpreter e2392310374518 :=
  wSource (t := t_e2392310374518) (replay_sound (ps := []) (t := e2392310374518) (by decide)) (by decide)
def e2392310374762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392310374762 : Closed e2392310374762 ∧ code e2392310374762 = 11188403396970 := by decide
private def t_e2392310374762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392310374762 : ¬ IsSelfInterpreter e2392310374762 :=
  wSource (t := t_e2392310374762) (replay_sound (ps := []) (t := e2392310374762) (by decide)) (by decide)
def e2392310374810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392310374810 : Closed e2392310374810 ∧ code e2392310374810 = 11188403397018 := by decide
private def t_e2392310374810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392310374810 : ¬ IsSelfInterpreter e2392310374810 :=
  wSource (t := t_e2392310374810) (replay_sound (ps := []) (t := e2392310374810) (by decide)) (by decide)
def e2392310380570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392310380570 : Closed e2392310380570 ∧ code e2392310380570 = 11188403402778 := by decide
theorem cert_e2392310380570 : check e2392310380570 [[]] .width = true := by decide
def e2392310386202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392310386202 : Closed e2392310386202 ∧ code e2392310386202 = 11188403408410 := by decide
private def t_e2392310386202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392310386202 : ¬ IsSelfInterpreter e2392310386202 :=
  wSource (t := t_e2392310386202) (replay_sound (ps := []) (t := e2392310386202) (by decide)) (by decide)
def e2392310395078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392310395078 : Closed e2392310395078 ∧ code e2392310395078 = 11188403417286 := by decide
theorem cert_e2392310395078 : check e2392310395078 [[]] .width = true := by decide
def e2392310396954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392310396954 : Closed e2392310396954 ∧ code e2392310396954 = 11188403419162 := by decide
theorem cert_e2392310396954 : check e2392310396954 [[]] .width = true := by decide
def e2392311586330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311586330 : Closed e2392311586330 ∧ code e2392311586330 = 11188404608538 := by decide
private def t_e2392311586330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311586330 : ¬ IsSelfInterpreter e2392311586330 :=
  wSource (t := t_e2392311586330) (replay_sound (ps := []) (t := e2392311586330) (by decide)) (by decide)
def e2392311592474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311592474 : Closed e2392311592474 ∧ code e2392311592474 = 11188404614682 := by decide
private def t_e2392311592474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311592474 : ¬ IsSelfInterpreter e2392311592474 :=
  wSource (t := t_e2392311592474) (replay_sound (ps := []) (t := e2392311592474) (by decide)) (by decide)
def e2392311836186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311836186 : Closed e2392311836186 ∧ code e2392311836186 = 11188404858394 := by decide
private def t_e2392311836186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311836186 : ¬ IsSelfInterpreter e2392311836186 :=
  wSource (t := t_e2392311836186) (replay_sound (ps := []) (t := e2392311836186) (by decide)) (by decide)
def e2392311839258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311839258 : Closed e2392311839258 ∧ code e2392311839258 = 11188404861466 := by decide
private def t_e2392311839258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311839258 : ¬ IsSelfInterpreter e2392311839258 :=
  wSource (t := t_e2392311839258) (replay_sound (ps := []) (t := e2392311839258) (by decide)) (by decide)
def e2392311851546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311851546 : Closed e2392311851546 ∧ code e2392311851546 = 11188404873754 := by decide
private def t_e2392311851546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311851546 : ¬ IsSelfInterpreter e2392311851546 :=
  wSource (t := t_e2392311851546) (replay_sound (ps := []) (t := e2392311851546) (by decide)) (by decide)
def e2392311873050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311873050 : Closed e2392311873050 ∧ code e2392311873050 = 11188404895258 := by decide
private def t_e2392311873050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311873050 : ¬ IsSelfInterpreter e2392311873050 :=
  wSource (t := t_e2392311873050) (replay_sound (ps := []) (t := e2392311873050) (by decide)) (by decide)
def e2392311885338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311885338 : Closed e2392311885338 ∧ code e2392311885338 = 11188404907546 := by decide
private def t_e2392311885338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311885338 : ¬ IsSelfInterpreter e2392311885338 :=
  wSource (t := t_e2392311885338) (replay_sound (ps := []) (t := e2392311885338) (by decide)) (by decide)
def e2392311888410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311888410 : Closed e2392311888410 ∧ code e2392311888410 = 11188404910618 := by decide
private def t_e2392311888410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311888410 : ¬ IsSelfInterpreter e2392311888410 :=
  wSource (t := t_e2392311888410) (replay_sound (ps := []) (t := e2392311888410) (by decide)) (by decide)
def e2392311914522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392311914522 : Closed e2392311914522 ∧ code e2392311914522 = 11188404936730 := by decide
theorem cert_e2392311914522 : check e2392311914522 [[],[.left]] .smaller = true := by decide
def e2392311914614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392311914614 : Closed e2392311914614 ∧ code e2392311914614 = 11188404936822 := by decide
private def t_e2392311914614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392311914614 : ¬ IsSelfInterpreter e2392311914614 :=
  wSource (t := t_e2392311914614) (replay_sound (ps := []) (t := e2392311914614) (by decide)) (by decide)
def e2392311914858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392311914858 : Closed e2392311914858 ∧ code e2392311914858 = 11188404937066 := by decide
private def t_e2392311914858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392311914858 : ¬ IsSelfInterpreter e2392311914858 :=
  wSource (t := t_e2392311914858) (replay_sound (ps := []) (t := e2392311914858) (by decide)) (by decide)
def e2392311914906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392311914906 : Closed e2392311914906 ∧ code e2392311914906 = 11188404937114 := by decide
private def t_e2392311914906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392311914906 : ¬ IsSelfInterpreter e2392311914906 :=
  wSource (t := t_e2392311914906) (replay_sound (ps := []) (t := e2392311914906) (by decide)) (by decide)
def e2392311918790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392311918790 : Closed e2392311918790 ∧ code e2392311918790 = 11188404940998 := by decide
theorem cert_e2392311918790 : check e2392311918790 [[]] .width = true := by decide
def e2392311962138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311962138 : Closed e2392311962138 ∧ code e2392311962138 = 11188404984346 := by decide
private def t_e2392311962138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311962138 : ¬ IsSelfInterpreter e2392311962138 :=
  wSource (t := t_e2392311962138) (replay_sound (ps := []) (t := e2392311962138) (by decide)) (by decide)
def e2392311963674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392311963674 : Closed e2392311963674 ∧ code e2392311963674 = 11188404985882 := by decide
theorem cert_e2392311963674 : check e2392311963674 [[],[.left]] .smaller = true := by decide
def e2392311963766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392311963766 : Closed e2392311963766 ∧ code e2392311963766 = 11188404985974 := by decide
private def t_e2392311963766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392311963766 : ¬ IsSelfInterpreter e2392311963766 :=
  wSource (t := t_e2392311963766) (replay_sound (ps := []) (t := e2392311963766) (by decide)) (by decide)
def e2392311964010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392311964010 : Closed e2392311964010 ∧ code e2392311964010 = 11188404986218 := by decide
private def t_e2392311964010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392311964010 : ¬ IsSelfInterpreter e2392311964010 :=
  wSource (t := t_e2392311964010) (replay_sound (ps := []) (t := e2392311964010) (by decide)) (by decide)
def e2392311964058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392311964058 : Closed e2392311964058 ∧ code e2392311964058 = 11188404986266 := by decide
private def t_e2392311964058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392311964058 : ¬ IsSelfInterpreter e2392311964058 :=
  wSource (t := t_e2392311964058) (replay_sound (ps := []) (t := e2392311964058) (by decide)) (by decide)
def e2392311973402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392311973402 : Closed e2392311973402 ∧ code e2392311973402 = 11188404995610 := by decide
private def t_e2392311973402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392311973402 : ¬ IsSelfInterpreter e2392311973402 :=
  wSource (t := t_e2392311973402) (replay_sound (ps := []) (t := e2392311973402) (by decide)) (by decide)
def e2392311976134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392311976134 : Closed e2392311976134 ∧ code e2392311976134 = 11188404998342 := by decide
theorem cert_e2392311976134 : check e2392311976134 [[]] .width = true := by decide
def e2392312573466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312573466 : Closed e2392312573466 ∧ code e2392312573466 = 11188405595674 := by decide
private def t_e2392312573466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312573466 : ¬ IsSelfInterpreter e2392312573466 :=
  wSource (t := t_e2392312573466) (replay_sound (ps := []) (t := e2392312573466) (by decide)) (by decide)
def e2392312575514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312575514 : Closed e2392312575514 ∧ code e2392312575514 = 11188405597722 := by decide
private def t_e2392312575514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312575514 : ¬ IsSelfInterpreter e2392312575514 :=
  wSource (t := t_e2392312575514) (replay_sound (ps := []) (t := e2392312575514) (by decide)) (by decide)
def e2392312698394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312698394 : Closed e2392312698394 ∧ code e2392312698394 = 11188405720602 := by decide
private def t_e2392312698394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312698394 : ¬ IsSelfInterpreter e2392312698394 :=
  wSource (t := t_e2392312698394) (replay_sound (ps := []) (t := e2392312698394) (by decide)) (by decide)
def e2392312699418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312699418 : Closed e2392312699418 ∧ code e2392312699418 = 11188405721626 := by decide
private def t_e2392312699418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312699418 : ¬ IsSelfInterpreter e2392312699418 :=
  wSource (t := t_e2392312699418) (replay_sound (ps := []) (t := e2392312699418) (by decide)) (by decide)
def e2392312703514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312703514 : Closed e2392312703514 ∧ code e2392312703514 = 11188405725722 := by decide
private def t_e2392312703514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312703514 : ¬ IsSelfInterpreter e2392312703514 :=
  wSource (t := t_e2392312703514) (replay_sound (ps := []) (t := e2392312703514) (by decide)) (by decide)
def e2392312722970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312722970 : Closed e2392312722970 ∧ code e2392312722970 = 11188405745178 := by decide
private def t_e2392312722970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312722970 : ¬ IsSelfInterpreter e2392312722970 :=
  wSource (t := t_e2392312722970) (replay_sound (ps := []) (t := e2392312722970) (by decide)) (by decide)
def e2392312723994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312723994 : Closed e2392312723994 ∧ code e2392312723994 = 11188405746202 := by decide
private def t_e2392312723994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312723994 : ¬ IsSelfInterpreter e2392312723994 :=
  wSource (t := t_e2392312723994) (replay_sound (ps := []) (t := e2392312723994) (by decide)) (by decide)
def e2392312733722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392312733722 : Closed e2392312733722 ∧ code e2392312733722 = 11188405755930 := by decide
theorem cert_e2392312733722 : check e2392312733722 [[],[.left]] .smaller = true := by decide
def e2392312733814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392312733814 : Closed e2392312733814 ∧ code e2392312733814 = 11188405756022 := by decide
private def t_e2392312733814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392312733814 : ¬ IsSelfInterpreter e2392312733814 :=
  wSource (t := t_e2392312733814) (replay_sound (ps := []) (t := e2392312733814) (by decide)) (by decide)
def e2392312734058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392312734058 : Closed e2392312734058 ∧ code e2392312734058 = 11188405756266 := by decide
private def t_e2392312734058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392312734058 : ¬ IsSelfInterpreter e2392312734058 :=
  wSource (t := t_e2392312734058) (replay_sound (ps := []) (t := e2392312734058) (by decide)) (by decide)
def e2392312734106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392312734106 : Closed e2392312734106 ∧ code e2392312734106 = 11188405756314 := by decide
private def t_e2392312734106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392312734106 : ¬ IsSelfInterpreter e2392312734106 :=
  wSource (t := t_e2392312734106) (replay_sound (ps := []) (t := e2392312734106) (by decide)) (by decide)
def e2392312739866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392312739866 : Closed e2392312739866 ∧ code e2392312739866 = 11188405762074 := by decide
theorem cert_e2392312739866 : check e2392312739866 [[]] .width = true := by decide
def e2392312748570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392312748570 : Closed e2392312748570 ∧ code e2392312748570 = 11188405770778 := by decide
private def t_e2392312748570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392312748570 : ¬ IsSelfInterpreter e2392312748570 :=
  wSource (t := t_e2392312748570) (replay_sound (ps := []) (t := e2392312748570) (by decide)) (by decide)
def e2392312750106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392312750106 : Closed e2392312750106 ∧ code e2392312750106 = 11188405772314 := by decide
theorem cert_e2392312750106 : check e2392312750106 [[],[.left]] .smaller = true := by decide
def e2392312750198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2392312750198 : Closed e2392312750198 ∧ code e2392312750198 = 11188405772406 := by decide
private def t_e2392312750198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2392312750198 : ¬ IsSelfInterpreter e2392312750198 :=
  wSource (t := t_e2392312750198) (replay_sound (ps := []) (t := e2392312750198) (by decide)) (by decide)
def e2392312750442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2392312750442 : Closed e2392312750442 ∧ code e2392312750442 = 11188405772650 := by decide
private def t_e2392312750442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2392312750442 : ¬ IsSelfInterpreter e2392312750442 :=
  wSource (t := t_e2392312750442) (replay_sound (ps := []) (t := e2392312750442) (by decide)) (by decide)
def e2392312750490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2392312750490 : Closed e2392312750490 ∧ code e2392312750490 = 11188405772698 := by decide
private def t_e2392312750490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2392312750490 : ¬ IsSelfInterpreter e2392312750490 :=
  wSource (t := t_e2392312750490) (replay_sound (ps := []) (t := e2392312750490) (by decide)) (by decide)
def e2392312768538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392312768538 : Closed e2392312768538 ∧ code e2392312768538 = 11188405790746 := by decide
theorem cert_e2392312768538 : check e2392312768538 [[]] .width = true := by decide
def e2392313138714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392313138714 : Closed e2392313138714 ∧ code e2392313138714 = 11188406160922 := by decide
private def t_e2392313138714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392313138714 : ¬ IsSelfInterpreter e2392313138714 :=
  wSource (t := t_e2392313138714) (replay_sound (ps := []) (t := e2392313138714) (by decide)) (by decide)
def e2392313147590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392313147590 : Closed e2392313147590 ∧ code e2392313147590 = 11188406169798 := by decide
theorem cert_e2392313147590 : check e2392313147590 [[]] .width = true := by decide
def e2392313149466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392313149466 : Closed e2392313149466 ∧ code e2392313149466 = 11188406171674 := by decide
theorem cert_e2392313149466 : check e2392313149466 [[]] .width = true := by decide
def e2392313153050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392313153050 : Closed e2392313153050 ∧ code e2392313153050 = 11188406175258 := by decide
private def t_e2392313153050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392313153050 : ¬ IsSelfInterpreter e2392313153050 :=
  wSource (t := t_e2392313153050) (replay_sound (ps := []) (t := e2392313153050) (by decide)) (by decide)
def e2392313155782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392313155782 : Closed e2392313155782 ∧ code e2392313155782 = 11188406177990 := by decide
theorem cert_e2392313155782 : check e2392313155782 [[]] .width = true := by decide
def e2392313161754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392313161754 : Closed e2392313161754 ∧ code e2392313161754 = 11188406183962 := by decide
theorem cert_e2392313161754 : check e2392313161754 [[]] .width = true := by decide
def e2392313605486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2392313605486 : Closed e2392313605486 ∧ code e2392313605486 = 11188406627694 := by decide
theorem cert_e2392313605486 : check e2392313605486 [[],[.left]] .chain = true := by decide
def e2392313605494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2392313605494 : Closed e2392313605494 ∧ code e2392313605494 = 11188406627702 := by decide
theorem cert_e2392313605494 : check e2392313605494 [[],[.left]] .chain = true := by decide
def e2392313605550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2392313605550 : Closed e2392313605550 ∧ code e2392313605550 = 11188406627758 := by decide
theorem cert_e2392313605550 : check e2392313605550 [[],[.left]] .chain = true := by decide
def e2392313605562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2392313605562 : Closed e2392313605562 ∧ code e2392313605562 = 11188406627770 := by decide
theorem cert_e2392313605562 : check e2392313605562 [[],[.left]] .chain = true := by decide
def e2392313605590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2392313605590 : Closed e2392313605590 ∧ code e2392313605590 = 11188406627798 := by decide
theorem cert_e2392313605590 : check e2392313605590 [[],[.left]] .chain = true := by decide
def e2392313605594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2392313605594 : Closed e2392313605594 ∧ code e2392313605594 = 11188406627802 := by decide
theorem cert_e2392313605594 : check e2392313605594 [[],[.left]] .chain = true := by decide
def e2392313605806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2392313605806 : Closed e2392313605806 ∧ code e2392313605806 = 11188406628014 := by decide
theorem cert_e2392313605806 : check e2392313605806 [[],[.left]] .chain = true := by decide
def e2392313605818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2392313605818 : Closed e2392313605818 ∧ code e2392313605818 = 11188406628026 := by decide
theorem cert_e2392313605818 : check e2392313605818 [[],[.left]] .chain = true := by decide
def e2392313605866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2392313605866 : Closed e2392313605866 ∧ code e2392313605866 = 11188406628074 := by decide
theorem cert_e2392313605866 : check e2392313605866 [[],[.left]] .chain = true := by decide
def e2392313605974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2392313605974 : Closed e2392313605974 ∧ code e2392313605974 = 11188406628182 := by decide
theorem cert_e2392313605974 : check e2392313605974 [[],[.left]] .chain = true := by decide
def e2392313605978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2392313605978 : Closed e2392313605978 ∧ code e2392313605978 = 11188406628186 := by decide
theorem cert_e2392313605978 : check e2392313605978 [[],[.left]] .chain = true := by decide
def e2392313605994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2392313605994 : Closed e2392313605994 ∧ code e2392313605994 = 11188406628202 := by decide
theorem cert_e2392313605994 : check e2392313605994 [[],[.left]] .chain = true := by decide
def e2392313607022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2392313607022 : Closed e2392313607022 ∧ code e2392313607022 = 11188406629230 := by decide
theorem cert_e2392313607022 : check e2392313607022 [[],[.left]] .chain = true := by decide
def e2392313607030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2392313607030 : Closed e2392313607030 ∧ code e2392313607030 = 11188406629238 := by decide
theorem cert_e2392313607030 : check e2392313607030 [[],[.left]] .chain = true := by decide
def e2392313607086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2392313607086 : Closed e2392313607086 ∧ code e2392313607086 = 11188406629294 := by decide
theorem cert_e2392313607086 : check e2392313607086 [[],[.left]] .chain = true := by decide
def e2392313607098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2392313607098 : Closed e2392313607098 ∧ code e2392313607098 = 11188406629306 := by decide
theorem cert_e2392313607098 : check e2392313607098 [[],[.left]] .chain = true := by decide
def e2392313607126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2392313607126 : Closed e2392313607126 ∧ code e2392313607126 = 11188406629334 := by decide
theorem cert_e2392313607126 : check e2392313607126 [[],[.left]] .chain = true := by decide
def e2392313607130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2392313607130 : Closed e2392313607130 ∧ code e2392313607130 = 11188406629338 := by decide
theorem cert_e2392313607130 : check e2392313607130 [[],[.left]] .chain = true := by decide
def e2392313607406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392313607406 : Closed e2392313607406 ∧ code e2392313607406 = 11188406629614 := by decide
theorem cert_e2392313607406 : check e2392313607406 [[],[.left]] .chain = true := by decide
def e2392313607414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392313607414 : Closed e2392313607414 ∧ code e2392313607414 = 11188406629622 := by decide
theorem cert_e2392313607414 : check e2392313607414 [[],[.left]] .chain = true := by decide
def e2392313607790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392313607790 : Closed e2392313607790 ∧ code e2392313607790 = 11188406629998 := by decide
theorem cert_e2392313607790 : check e2392313607790 [[],[.left]] .chain = true := by decide
def e2392313607802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392313607802 : Closed e2392313607802 ∧ code e2392313607802 = 11188406630010 := by decide
theorem cert_e2392313607802 : check e2392313607802 [[],[.left]] .chain = true := by decide
def e2392313607990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392313607990 : Closed e2392313607990 ∧ code e2392313607990 = 11188406630198 := by decide
theorem cert_e2392313607990 : check e2392313607990 [[],[.left]] .chain = true := by decide
def e2392313607994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392313607994 : Closed e2392313607994 ∧ code e2392313607994 = 11188406630202 := by decide
theorem cert_e2392313607994 : check e2392313607994 [[],[.left]] .chain = true := by decide
def e2392313608622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2392313608622 : Closed e2392313608622 ∧ code e2392313608622 = 11188406630830 := by decide
theorem cert_e2392313608622 : check e2392313608622 [[],[.left]] .chain = true := by decide
def e2392313608634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2392313608634 : Closed e2392313608634 ∧ code e2392313608634 = 11188406630842 := by decide
theorem cert_e2392313608634 : check e2392313608634 [[],[.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392308727322
#print axioms Blc.Floor43.cert_e2392308739610
#print axioms Blc.Floor43.cert_e2392308742682
#print axioms Blc.Floor43.cert_e2392308768886
#print axioms Blc.Floor43.cert_e2392308769130
#print axioms Blc.Floor43.cert_e2392308769178
#print axioms Blc.Floor43.cert_e2392308790810
#print axioms Blc.Floor43.cert_e2392308791834
#print axioms Blc.Floor43.cert_e2392308801654
#print axioms Blc.Floor43.cert_e2392308801898
#print axioms Blc.Floor43.cert_e2392308801946
#print axioms Blc.Floor43.cert_e2392308813338
#print axioms Blc.Floor43.cert_e2392308899354
#print axioms Blc.Floor43.cert_e2392308906522
#print axioms Blc.Floor43.cert_e2392308952602
#print axioms Blc.Floor43.cert_e2392308955674
#print axioms Blc.Floor43.cert_e2392308967962
#print axioms Blc.Floor43.cert_e2392308989466
#print axioms Blc.Floor43.cert_e2392309001754
#print axioms Blc.Floor43.cert_e2392309004826
#print axioms Blc.Floor43.cert_e2392309031030
#print axioms Blc.Floor43.cert_e2392309031274
#print axioms Blc.Floor43.cert_e2392309031322
#print axioms Blc.Floor43.cert_e2392309078554
#print axioms Blc.Floor43.cert_e2392309080182
#print axioms Blc.Floor43.cert_e2392309080426
#print axioms Blc.Floor43.cert_e2392309080474
#print axioms Blc.Floor43.cert_e2392309089818
#print axioms Blc.Floor43.cert_e2392309159450
#print axioms Blc.Floor43.cert_e2392309160474
#print axioms Blc.Floor43.cert_e2392309164570
#print axioms Blc.Floor43.cert_e2392309184026
#print axioms Blc.Floor43.cert_e2392309185050
#print axioms Blc.Floor43.cert_e2392309194870
#print axioms Blc.Floor43.cert_e2392309195114
#print axioms Blc.Floor43.cert_e2392309195162
#print axioms Blc.Floor43.cert_e2392309209626
#print axioms Blc.Floor43.cert_e2392309211254
#print axioms Blc.Floor43.cert_e2392309211498
#print axioms Blc.Floor43.cert_e2392309211546
#print axioms Blc.Floor43.cert_e2392309249562
#print axioms Blc.Floor43.cert_e2392309250586
#print axioms Blc.Floor43.cert_e2392309272090
#print axioms Blc.Floor43.cert_e2392309286426
#print axioms Blc.Floor43.cert_e2392309620250
#print axioms Blc.Floor43.cert_e2392309624346
#print axioms Blc.Floor43.cert_e2392310115866
#print axioms Blc.Floor43.cert_e2392310117914
#print axioms Blc.Floor43.cert_e2392310132250
#print axioms Blc.Floor43.cert_e2392310135322
#print axioms Blc.Floor43.cert_e2392310142490
#print axioms Blc.Floor43.cert_e2392310143514
#print axioms Blc.Floor43.cert_e2392310214170
#print axioms Blc.Floor43.cert_e2392310216218
#print axioms Blc.Floor43.cert_e2392310300186
#print axioms Blc.Floor43.cert_e2392310312474
#print axioms Blc.Floor43.cert_e2392310315546
#print axioms Blc.Floor43.cert_e2392310341750
#print axioms Blc.Floor43.cert_e2392310341994
#print axioms Blc.Floor43.cert_e2392310342042
#print axioms Blc.Floor43.cert_e2392310363674
#print axioms Blc.Floor43.cert_e2392310364698
#print axioms Blc.Floor43.cert_e2392310374518
#print axioms Blc.Floor43.cert_e2392310374762
#print axioms Blc.Floor43.cert_e2392310374810
#print axioms Blc.Floor43.cert_e2392310386202
#print axioms Blc.Floor43.cert_e2392311586330
#print axioms Blc.Floor43.cert_e2392311592474
#print axioms Blc.Floor43.cert_e2392311836186
#print axioms Blc.Floor43.cert_e2392311839258
#print axioms Blc.Floor43.cert_e2392311851546
#print axioms Blc.Floor43.cert_e2392311873050
#print axioms Blc.Floor43.cert_e2392311885338
#print axioms Blc.Floor43.cert_e2392311888410
#print axioms Blc.Floor43.cert_e2392311914614
#print axioms Blc.Floor43.cert_e2392311914858
#print axioms Blc.Floor43.cert_e2392311914906
#print axioms Blc.Floor43.cert_e2392311962138
#print axioms Blc.Floor43.cert_e2392311963766
#print axioms Blc.Floor43.cert_e2392311964010
#print axioms Blc.Floor43.cert_e2392311964058
#print axioms Blc.Floor43.cert_e2392311973402
#print axioms Blc.Floor43.cert_e2392312573466
#print axioms Blc.Floor43.cert_e2392312575514
#print axioms Blc.Floor43.cert_e2392312698394
#print axioms Blc.Floor43.cert_e2392312699418
#print axioms Blc.Floor43.cert_e2392312703514
#print axioms Blc.Floor43.cert_e2392312722970
#print axioms Blc.Floor43.cert_e2392312723994
#print axioms Blc.Floor43.cert_e2392312733814
#print axioms Blc.Floor43.cert_e2392312734058
#print axioms Blc.Floor43.cert_e2392312734106
#print axioms Blc.Floor43.cert_e2392312748570
#print axioms Blc.Floor43.cert_e2392312750198
#print axioms Blc.Floor43.cert_e2392312750442
#print axioms Blc.Floor43.cert_e2392312750490
#print axioms Blc.Floor43.cert_e2392313138714
#print axioms Blc.Floor43.cert_e2392313153050
