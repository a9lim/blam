import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e699341649338 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e699341649338 : Closed e699341649338 ∧ code e699341649338 = 9495434671546 := by decide
theorem cert_e699341649338 : check e699341649338 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341649370 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e699341649370 : Closed e699341649370 ∧ code e699341649370 = 9495434671578 := by decide
theorem cert_e699341649370 : check e699341649370 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341649594 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e699341649594 : Closed e699341649594 ∧ code e699341649594 = 9495434671802 := by decide
theorem cert_e699341649594 : check e699341649594 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341649642 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e699341649642 : Closed e699341649642 ∧ code e699341649642 = 9495434671850 := by decide
theorem cert_e699341649642 : check e699341649642 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341649754 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e699341649754 : Closed e699341649754 ∧ code e699341649754 = 9495434671962 := by decide
theorem cert_e699341649754 : check e699341649754 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341649770 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e699341649770 : Closed e699341649770 ∧ code e699341649770 = 9495434671978 := by decide
theorem cert_e699341649770 : check e699341649770 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341650618 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e699341650618 : Closed e699341650618 ∧ code e699341650618 = 9495434672826 := by decide
theorem cert_e699341650618 : check e699341650618 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341650666 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e699341650666 : Closed e699341650666 ∧ code e699341650666 = 9495434672874 := by decide
theorem cert_e699341650666 : check e699341650666 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e699341650858 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e699341650858 : Closed e699341650858 ∧ code e699341650858 = 9495434673066 := by decide
theorem cert_e699341650858 : check e699341650858 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e699341651290 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e699341651290 : Closed e699341651290 ∧ code e699341651290 = 9495434673498 := by decide
theorem cert_e699341651290 : check e699341651290 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341651306 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e699341651306 : Closed e699341651306 ∧ code e699341651306 = 9495434673514 := by decide
theorem cert_e699341651306 : check e699341651306 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e699341651370 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e699341651370 : Closed e699341651370 ∧ code e699341651370 = 9495434673578 := by decide
theorem cert_e699341651370 : check e699341651370 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e699341655482 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e699341655482 : Closed e699341655482 ∧ code e699341655482 = 9495434677690 := by decide
theorem cert_e699341655482 : check e699341655482 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341655514 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e699341655514 : Closed e699341655514 ∧ code e699341655514 = 9495434677722 := by decide
theorem cert_e699341655514 : check e699341655514 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341655738 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e699341655738 : Closed e699341655738 ∧ code e699341655738 = 9495434677946 := by decide
theorem cert_e699341655738 : check e699341655738 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341655786 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e699341655786 : Closed e699341655786 ∧ code e699341655786 = 9495434677994 := by decide
theorem cert_e699341655786 : check e699341655786 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341655898 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e699341655898 : Closed e699341655898 ∧ code e699341655898 = 9495434678106 := by decide
theorem cert_e699341655898 : check e699341655898 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341655914 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e699341655914 : Closed e699341655914 ∧ code e699341655914 = 9495434678122 := by decide
theorem cert_e699341655914 : check e699341655914 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341657018 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e699341657018 : Closed e699341657018 ∧ code e699341657018 = 9495434679226 := by decide
theorem cert_e699341657018 : check e699341657018 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341657050 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e699341657050 : Closed e699341657050 ∧ code e699341657050 = 9495434679258 := by decide
theorem cert_e699341657050 : check e699341657050 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341658554 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e699341658554 : Closed e699341658554 ∧ code e699341658554 = 9495434680762 := by decide
theorem cert_e699341658554 : check e699341658554 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341658602 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e699341658602 : Closed e699341658602 ∧ code e699341658602 = 9495434680810 := by decide
theorem cert_e699341658602 : check e699341658602 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341659354 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e699341659354 : Closed e699341659354 ∧ code e699341659354 = 9495434681562 := by decide
theorem cert_e699341659354 : check e699341659354 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341659370 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e699341659370 : Closed e699341659370 ∧ code e699341659370 = 9495434681578 := by decide
theorem cert_e699341659370 : check e699341659370 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341661882 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e699341661882 : Closed e699341661882 ∧ code e699341661882 = 9495434684090 := by decide
theorem cert_e699341661882 : check e699341661882 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .chain = true := by decide
def e699341661930 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e699341661930 : Closed e699341661930 ∧ code e699341661930 = 9495434684138 := by decide
theorem cert_e699341661930 : check e699341661930 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e699341662122 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e699341662122 : Closed e699341662122 ∧ code e699341662122 = 9495434684330 := by decide
theorem cert_e699341662122 : check e699341662122 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e699341662650 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e699341662650 : Closed e699341662650 ∧ code e699341662650 = 9495434684858 := by decide
theorem cert_e699341662650 : check e699341662650 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .chain = true := by decide
def e699341662698 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e699341662698 : Closed e699341662698 ∧ code e699341662698 = 9495434684906 := by decide
theorem cert_e699341662698 : check e699341662698 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .chain = true := by decide
def e699341663850 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e699341663850 : Closed e699341663850 ∧ code e699341663850 = 9495434686058 := by decide
theorem cert_e699341663850 : check e699341663850 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e699341665114 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e699341665114 : Closed e699341665114 ∧ code e699341665114 = 9495434687322 := by decide
theorem cert_e699341665114 : check e699341665114 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .chain = true := by decide
def e699341665130 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e699341665130 : Closed e699341665130 ∧ code e699341665130 = 9495434687338 := by decide
theorem cert_e699341665130 : check e699341665130 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e699341665194 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e699341665194 : Closed e699341665194 ∧ code e699341665194 = 9495434687402 := by decide
theorem cert_e699341665194 : check e699341665194 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e699341665498 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e699341665498 : Closed e699341665498 ∧ code e699341665498 = 9495434687706 := by decide
theorem cert_e699341665498 : check e699341665498 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .chain = true := by decide
def e699341665514 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e699341665514 : Closed e699341665514 ∧ code e699341665514 = 9495434687722 := by decide
theorem cert_e699341665514 : check e699341665514 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .chain = true := by decide
def e699341665898 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e699341665898 : Closed e699341665898 ∧ code e699341665898 = 9495434688106 := by decide
theorem cert_e699341665898 : check e699341665898 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e699341680058 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e699341680058 : Closed e699341680058 ∧ code e699341680058 = 9495434702266 := by decide
theorem cert_e699341680058 : check e699341680058 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341680090 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e699341680090 : Closed e699341680090 ∧ code e699341680090 = 9495434702298 := by decide
theorem cert_e699341680090 : check e699341680090 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341680314 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e699341680314 : Closed e699341680314 ∧ code e699341680314 = 9495434702522 := by decide
theorem cert_e699341680314 : check e699341680314 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341680362 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e699341680362 : Closed e699341680362 ∧ code e699341680362 = 9495434702570 := by decide
theorem cert_e699341680362 : check e699341680362 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341680474 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e699341680474 : Closed e699341680474 ∧ code e699341680474 = 9495434702682 := by decide
theorem cert_e699341680474 : check e699341680474 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341680490 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e699341680490 : Closed e699341680490 ∧ code e699341680490 = 9495434702698 := by decide
theorem cert_e699341680490 : check e699341680490 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341681594 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e699341681594 : Closed e699341681594 ∧ code e699341681594 = 9495434703802 := by decide
theorem cert_e699341681594 : check e699341681594 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341681626 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e699341681626 : Closed e699341681626 ∧ code e699341681626 = 9495434703834 := by decide
theorem cert_e699341681626 : check e699341681626 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341683130 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e699341683130 : Closed e699341683130 ∧ code e699341683130 = 9495434705338 := by decide
theorem cert_e699341683130 : check e699341683130 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341683178 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e699341683178 : Closed e699341683178 ∧ code e699341683178 = 9495434705386 := by decide
theorem cert_e699341683178 : check e699341683178 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341683930 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e699341683930 : Closed e699341683930 ∧ code e699341683930 = 9495434706138 := by decide
theorem cert_e699341683930 : check e699341683930 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341683946 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e699341683946 : Closed e699341683946 ∧ code e699341683946 = 9495434706154 := by decide
theorem cert_e699341683946 : check e699341683946 [[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699341706938 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e699341706938 : Closed e699341706938 ∧ code e699341706938 = 9495434729146 := by decide
theorem cert_e699341706938 : check e699341706938 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341706986 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e699341706986 : Closed e699341706986 ∧ code e699341706986 = 9495434729194 := by decide
theorem cert_e699341706986 : check e699341706986 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341707178 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e699341707178 : Closed e699341707178 ∧ code e699341707178 = 9495434729386 := by decide
theorem cert_e699341707178 : check e699341707178 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341707706 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e699341707706 : Closed e699341707706 ∧ code e699341707706 = 9495434729914 := by decide
theorem cert_e699341707706 : check e699341707706 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341707754 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e699341707754 : Closed e699341707754 ∧ code e699341707754 = 9495434729962 := by decide
theorem cert_e699341707754 : check e699341707754 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341708906 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e699341708906 : Closed e699341708906 ∧ code e699341708906 = 9495434731114 := by decide
theorem cert_e699341708906 : check e699341708906 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341720410 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e699341720410 : Closed e699341720410 ∧ code e699341720410 = 9495434742618 := by decide
theorem cert_e699341720410 : check e699341720410 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341720426 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e699341720426 : Closed e699341720426 ∧ code e699341720426 = 9495434742634 := by decide
theorem cert_e699341720426 : check e699341720426 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341720490 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e699341720490 : Closed e699341720490 ∧ code e699341720490 = 9495434742698 := by decide
theorem cert_e699341720490 : check e699341720490 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341720794 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e699341720794 : Closed e699341720794 ∧ code e699341720794 = 9495434743002 := by decide
theorem cert_e699341720794 : check e699341720794 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341720810 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e699341720810 : Closed e699341720810 ∧ code e699341720810 = 9495434743018 := by decide
theorem cert_e699341720810 : check e699341720810 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699341721194 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e699341721194 : Closed e699341721194 ∧ code e699341721194 = 9495434743402 := by decide
theorem cert_e699341721194 : check e699341721194 [[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .three = true := by decide
def e699342269882 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e699342269882 : Closed e699342269882 ∧ code e699342269882 = 9495435292090 := by decide
theorem cert_e699342269882 : check e699342269882 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342269914 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e699342269914 : Closed e699342269914 ∧ code e699342269914 = 9495435292122 := by decide
theorem cert_e699342269914 : check e699342269914 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342270138 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e699342270138 : Closed e699342270138 ∧ code e699342270138 = 9495435292346 := by decide
theorem cert_e699342270138 : check e699342270138 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342270186 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e699342270186 : Closed e699342270186 ∧ code e699342270186 = 9495435292394 := by decide
theorem cert_e699342270186 : check e699342270186 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342270298 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e699342270298 : Closed e699342270298 ∧ code e699342270298 = 9495435292506 := by decide
theorem cert_e699342270298 : check e699342270298 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342270314 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e699342270314 : Closed e699342270314 ∧ code e699342270314 = 9495435292522 := by decide
theorem cert_e699342270314 : check e699342270314 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342271418 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e699342271418 : Closed e699342271418 ∧ code e699342271418 = 9495435293626 := by decide
theorem cert_e699342271418 : check e699342271418 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342271450 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e699342271450 : Closed e699342271450 ∧ code e699342271450 = 9495435293658 := by decide
theorem cert_e699342271450 : check e699342271450 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342272954 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e699342272954 : Closed e699342272954 ∧ code e699342272954 = 9495435295162 := by decide
theorem cert_e699342272954 : check e699342272954 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342273002 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e699342273002 : Closed e699342273002 ∧ code e699342273002 = 9495435295210 := by decide
theorem cert_e699342273002 : check e699342273002 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342273754 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e699342273754 : Closed e699342273754 ∧ code e699342273754 = 9495435295962 := by decide
theorem cert_e699342273754 : check e699342273754 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699342273770 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e699342273770 : Closed e699342273770 ∧ code e699342273770 = 9495435295978 := by decide
theorem cert_e699342273770 : check e699342273770 [[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699344629178 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e699344629178 : Closed e699344629178 ∧ code e699344629178 = 9495437651386 := by decide
def e699344629210 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e699344629210 : Closed e699344629210 ∧ code e699344629210 = 9495437651418 := by decide
def e699344629434 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e699344629434 : Closed e699344629434 ∧ code e699344629434 = 9495437651642 := by decide
def e699344629482 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e699344629482 : Closed e699344629482 ∧ code e699344629482 = 9495437651690 := by decide
private def t_e699344629482 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem cert_e699344629482 : ¬ IsSelfInterpreter e699344629482 :=
  wSource (t := t_e699344629482) (replay_sound (ps := []) (t := e699344629482) (by decide)) (by decide)
def e699344629594 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e699344629594 : Closed e699344629594 ∧ code e699344629594 = 9495437651802 := by decide
def e699344629610 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e699344629610 : Closed e699344629610 ∧ code e699344629610 = 9495437651818 := by decide
private def t_e699344629610 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem cert_e699344629610 : ¬ IsSelfInterpreter e699344629610 :=
  wSource (t := t_e699344629610) (replay_sound (ps := []) (t := e699344629610) (by decide)) (by decide)
def e699344630714 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e699344630714 : Closed e699344630714 ∧ code e699344630714 = 9495437652922 := by decide
theorem cert_e699344630714 : check e699344630714 [[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699344630746 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e699344630746 : Closed e699344630746 ∧ code e699344630746 = 9495437652954 := by decide
theorem cert_e699344630746 : check e699344630746 [[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e699344632250 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e699344632250 : Closed e699344632250 ∧ code e699344632250 = 9495437654458 := by decide
theorem cert_e699344632250 : check e699344632250 [[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e699344632298 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e699344632298 : Closed e699344632298 ∧ code e699344632298 = 9495437654506 := by decide
theorem cert_e699344632298 : checkPay e699344632298 [[.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left]] 0 [[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.under,.right,.left],[.under,.under,.right,.under,.right],[.under,.under,.right,.under,.right,.right]] = true := by decide
def e699344633050 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e699344633050 : Closed e699344633050 ∧ code e699344633050 = 9495437655258 := by decide
theorem cert_e699344633050 : check e699344633050 [[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e699344633066 : Term := (.lam (.app (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e699344633066 : Closed e699344633066 ∧ code e699344633066 = 9495437655274 := by decide
def e700127608938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700127608938 : Closed e700127608938 ∧ code e700127608938 = 9496220631146 := by decide
theorem cert_e700127608938 : check e700127608938 [[.under,.left]] .width = true := by decide
def e700127609306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700127609306 : Closed e700127609306 ∧ code e700127609306 = 9496220631514 := by decide
theorem cert_e700127609306 : check e700127609306 [[.under,.left]] .width = true := by decide
def e700127610282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700127610282 : Closed e700127610282 ∧ code e700127610282 = 9496220632490 := by decide
theorem cert_e700127610282 : check e700127610282 [[.under,.left]] .width = true := by decide
def e700127610474 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700127610474 : Closed e700127610474 ∧ code e700127610474 = 9496220632682 := by decide
theorem cert_e700127610474 : check e700127610474 [[.under,.left]] .width = true := by decide
def e700127615082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700127615082 : Closed e700127615082 ∧ code e700127615082 = 9496220637290 := by decide
theorem cert_e700127615082 : check e700127615082 [[.under,.left]] .width = true := by decide
def e700127615514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700127615514 : Closed e700127615514 ∧ code e700127615514 = 9496220637722 := by decide
theorem cert_e700127615514 : check e700127615514 [[.under,.left]] .chain = true := by decide
def e700127740010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700127740010 : Closed e700127740010 ∧ code e700127740010 = 9496220762218 := by decide
theorem cert_e700127740010 : check e700127740010 [[.under,.left]] .width = true := by decide
def e700127740378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700127740378 : Closed e700127740378 ∧ code e700127740378 = 9496220762586 := by decide
theorem cert_e700127740378 : check e700127740378 [[.under,.left]] .width = true := by decide
def e700127741354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700127741354 : Closed e700127741354 ∧ code e700127741354 = 9496220763562 := by decide
theorem cert_e700127741354 : check e700127741354 [[.under,.left]] .width = true := by decide
def e700127741546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700127741546 : Closed e700127741546 ∧ code e700127741546 = 9496220763754 := by decide
theorem cert_e700127741546 : check e700127741546 [[.under,.left]] .width = true := by decide
def e700127746154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700127746154 : Closed e700127746154 ∧ code e700127746154 = 9496220768362 := by decide
theorem cert_e700127746154 : check e700127746154 [[.under,.left]] .width = true := by decide
def e700127746586 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700127746586 : Closed e700127746586 ∧ code e700127746586 = 9496220768794 := by decide
theorem cert_e700127746586 : check e700127746586 [[.under,.left]] .chain = true := by decide
def e700128657514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700128657514 : Closed e700128657514 ∧ code e700128657514 = 9496221679722 := by decide
theorem cert_e700128657514 : check e700128657514 [[.under,.left]] .width = true := by decide
def e700128657882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700128657882 : Closed e700128657882 ∧ code e700128657882 = 9496221680090 := by decide
theorem cert_e700128657882 : check e700128657882 [[.under,.left]] .width = true := by decide
def e700128658858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700128658858 : Closed e700128658858 ∧ code e700128658858 = 9496221681066 := by decide
theorem cert_e700128658858 : check e700128658858 [[.under,.left]] .width = true := by decide
def e700128659050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700128659050 : Closed e700128659050 ∧ code e700128659050 = 9496221681258 := by decide
theorem cert_e700128659050 : check e700128659050 [[.under,.left]] .width = true := by decide
def e700128663658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700128663658 : Closed e700128663658 ∧ code e700128663658 = 9496221685866 := by decide
theorem cert_e700128663658 : check e700128663658 [[.under,.left]] .width = true := by decide
def e700128664090 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700128664090 : Closed e700128664090 ∧ code e700128664090 = 9496221686298 := by decide
theorem cert_e700128664090 : check e700128664090 [[.under,.left]] .chain = true := by decide
def e700128854122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700128854122 : Closed e700128854122 ∧ code e700128854122 = 9496221876330 := by decide
theorem cert_e700128854122 : check e700128854122 [[.under,.left]] .width = true := by decide
def e700128854490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700128854490 : Closed e700128854490 ∧ code e700128854490 = 9496221876698 := by decide
private def t_e700128854490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem cert_e700128854490 : ¬ IsSelfInterpreter e700128854490 :=
  wSource (t := t_e700128854490) (replay_sound (ps := []) (t := e700128854490) (by decide)) (by decide)
def e700128855466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700128855466 : Closed e700128855466 ∧ code e700128855466 = 9496221877674 := by decide
private def t_e700128855466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem cert_e700128855466 : ¬ IsSelfInterpreter e700128855466 :=
  wSource (t := t_e700128855466) (replay_sound (ps := []) (t := e700128855466) (by decide)) (by decide)
def e700128855658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700128855658 : Closed e700128855658 ∧ code e700128855658 = 9496221877866 := by decide
private def t_e700128855658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem cert_e700128855658 : ¬ IsSelfInterpreter e700128855658 :=
  wSource (t := t_e700128855658) (replay_sound (ps := []) (t := e700128855658) (by decide)) (by decide)
def e700128860266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700128860266 : Closed e700128860266 ∧ code e700128860266 = 9496221882474 := by decide
theorem cert_e700128860266 : check e700128860266 [[.under,.left]] .width = true := by decide
def e700128860698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700128860698 : Closed e700128860698 ∧ code e700128860698 = 9496221882906 := by decide
theorem cert_e700128860698 : check e700128860698 [[.under,.left]] .chain = true := by decide
def e700129312874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700129312874 : Closed e700129312874 ∧ code e700129312874 = 9496222335082 := by decide
theorem cert_e700129312874 : check e700129312874 [[.under,.left]] .width = true := by decide
def e700129313242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700129313242 : Closed e700129313242 ∧ code e700129313242 = 9496222335450 := by decide
theorem cert_e700129313242 : check e700129313242 [[.under,.left]] .width = true := by decide
def e700129314218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700129314218 : Closed e700129314218 ∧ code e700129314218 = 9496222336426 := by decide
theorem cert_e700129314218 : check e700129314218 [[.under,.left]] .width = true := by decide
def e700129314410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700129314410 : Closed e700129314410 ∧ code e700129314410 = 9496222336618 := by decide
theorem cert_e700129314410 : check e700129314410 [[.under,.left]] .width = true := by decide
def e700129319018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700129319018 : Closed e700129319018 ∧ code e700129319018 = 9496222341226 := by decide
theorem cert_e700129319018 : check e700129319018 [[.under,.left]] .width = true := by decide
def e700129319450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700129319450 : Closed e700129319450 ∧ code e700129319450 = 9496222341658 := by decide
theorem cert_e700129319450 : check e700129319450 [[.under,.left]] .chain = true := by decide
def e700129378410 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700129378410 : Closed e700129378410 ∧ code e700129378410 = 9496222400618 := by decide
theorem cert_e700129378410 : check e700129378410 [[.under,.left]] .width = true := by decide
def e700129378778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700129378778 : Closed e700129378778 ∧ code e700129378778 = 9496222400986 := by decide
private def t_e700129378778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem cert_e700129378778 : ¬ IsSelfInterpreter e700129378778 :=
  wSource (t := t_e700129378778) (replay_sound (ps := []) (t := e700129378778) (by decide)) (by decide)
def e700129379754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700129379754 : Closed e700129379754 ∧ code e700129379754 = 9496222401962 := by decide
private def t_e700129379754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem cert_e700129379754 : ¬ IsSelfInterpreter e700129379754 :=
  wSource (t := t_e700129379754) (replay_sound (ps := []) (t := e700129379754) (by decide)) (by decide)
def e700129379946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700129379946 : Closed e700129379946 ∧ code e700129379946 = 9496222402154 := by decide
private def t_e700129379946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem cert_e700129379946 : ¬ IsSelfInterpreter e700129379946 :=
  wSource (t := t_e700129379946) (replay_sound (ps := []) (t := e700129379946) (by decide)) (by decide)
def e700129384554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700129384554 : Closed e700129384554 ∧ code e700129384554 = 9496222406762 := by decide
theorem cert_e700129384554 : check e700129384554 [[.under,.left]] .width = true := by decide
def e700129384986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700129384986 : Closed e700129384986 ∧ code e700129384986 = 9496222407194 := by decide
theorem cert_e700129384986 : check e700129384986 [[.under,.left]] .chain = true := by decide
def e700133900394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700133900394 : Closed e700133900394 ∧ code e700133900394 = 9496226922602 := by decide
theorem cert_e700133900394 : check e700133900394 [[.under,.left]] .width = true := by decide
def e700133900762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700133900762 : Closed e700133900762 ∧ code e700133900762 = 9496226922970 := by decide
theorem cert_e700133900762 : check e700133900762 [[.under,.left]] .width = true := by decide
def e700133901738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700133901738 : Closed e700133901738 ∧ code e700133901738 = 9496226923946 := by decide
theorem cert_e700133901738 : check e700133901738 [[.under,.left]] .width = true := by decide
def e700133901930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700133901930 : Closed e700133901930 ∧ code e700133901930 = 9496226924138 := by decide
theorem cert_e700133901930 : check e700133901930 [[.under,.left]] .width = true := by decide
def e700133906538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700133906538 : Closed e700133906538 ∧ code e700133906538 = 9496226928746 := by decide
theorem cert_e700133906538 : check e700133906538 [[.under,.left]] .width = true := by decide
def e700133906970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700133906970 : Closed e700133906970 ∧ code e700133906970 = 9496226929178 := by decide
theorem cert_e700133906970 : check e700133906970 [[.under,.left]] .chain = true := by decide
def e700134031466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700134031466 : Closed e700134031466 ∧ code e700134031466 = 9496227053674 := by decide
theorem cert_e700134031466 : check e700134031466 [[.under,.left]] .width = true := by decide
def e700134031834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700134031834 : Closed e700134031834 ∧ code e700134031834 = 9496227054042 := by decide
theorem cert_e700134031834 : check e700134031834 [[.under,.left]] .width = true := by decide
def e700134032810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700134032810 : Closed e700134032810 ∧ code e700134032810 = 9496227055018 := by decide
theorem cert_e700134032810 : check e700134032810 [[.under,.left]] .width = true := by decide
def e700134033002 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700134033002 : Closed e700134033002 ∧ code e700134033002 = 9496227055210 := by decide
theorem cert_e700134033002 : check e700134033002 [[.under,.left]] .width = true := by decide
def e700134037610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700134037610 : Closed e700134037610 ∧ code e700134037610 = 9496227059818 := by decide
theorem cert_e700134037610 : check e700134037610 [[.under,.left]] .width = true := by decide
def e700134038042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700134038042 : Closed e700134038042 ∧ code e700134038042 = 9496227060250 := by decide
theorem cert_e700134038042 : check e700134038042 [[.under,.left]] .chain = true := by decide
def e700140191850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700140191850 : Closed e700140191850 ∧ code e700140191850 = 9496233214058 := by decide
theorem cert_e700140191850 : check e700140191850 [[.under,.left]] .width = true := by decide
def e700140192218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700140192218 : Closed e700140192218 ∧ code e700140192218 = 9496233214426 := by decide
theorem cert_e700140192218 : check e700140192218 [[.under,.left]] .width = true := by decide
def e700140193194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700140193194 : Closed e700140193194 ∧ code e700140193194 = 9496233215402 := by decide
theorem cert_e700140193194 : check e700140193194 [[.under,.left]] .width = true := by decide
def e700140193386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700140193386 : Closed e700140193386 ∧ code e700140193386 = 9496233215594 := by decide
theorem cert_e700140193386 : check e700140193386 [[.under,.left]] .width = true := by decide
def e700140197994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700140197994 : Closed e700140197994 ∧ code e700140197994 = 9496233220202 := by decide
theorem cert_e700140197994 : check e700140197994 [[.under,.left]] .width = true := by decide
def e700140198426 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700140198426 : Closed e700140198426 ∧ code e700140198426 = 9496233220634 := by decide
theorem cert_e700140198426 : check e700140198426 [[.under,.left]] .chain = true := by decide
def e700140388458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700140388458 : Closed e700140388458 ∧ code e700140388458 = 9496233410666 := by decide
theorem cert_e700140388458 : check e700140388458 [[.under,.left]] .width = true := by decide
def e700140388826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700140388826 : Closed e700140388826 ∧ code e700140388826 = 9496233411034 := by decide
theorem cert_e700140388826 : check e700140388826 [[.under,.left]] .width = true := by decide
def e700140389802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700140389802 : Closed e700140389802 ∧ code e700140389802 = 9496233412010 := by decide
theorem cert_e700140389802 : check e700140389802 [[.under,.left]] .width = true := by decide
def e700140389994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700140389994 : Closed e700140389994 ∧ code e700140389994 = 9496233412202 := by decide
theorem cert_e700140389994 : check e700140389994 [[.under,.left]] .width = true := by decide
def e700140394602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700140394602 : Closed e700140394602 ∧ code e700140394602 = 9496233416810 := by decide
theorem cert_e700140394602 : check e700140394602 [[.under,.left]] .width = true := by decide
def e700140395034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700140395034 : Closed e700140395034 ∧ code e700140395034 = 9496233417242 := by decide
theorem cert_e700140395034 : check e700140395034 [[.under,.left]] .chain = true := by decide
def e700143468650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700143468650 : Closed e700143468650 ∧ code e700143468650 = 9496236490858 := by decide
theorem cert_e700143468650 : check e700143468650 [[.under,.left]] .width = true := by decide
def e700143469018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700143469018 : Closed e700143469018 ∧ code e700143469018 = 9496236491226 := by decide
theorem cert_e700143469018 : check e700143469018 [[.under,.left]] .width = true := by decide
def e700143469994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700143469994 : Closed e700143469994 ∧ code e700143469994 = 9496236492202 := by decide
theorem cert_e700143469994 : check e700143469994 [[.under,.left]] .width = true := by decide
def e700143470186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700143470186 : Closed e700143470186 ∧ code e700143470186 = 9496236492394 := by decide
theorem cert_e700143470186 : check e700143470186 [[.under,.left]] .width = true := by decide
def e700143474794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700143474794 : Closed e700143474794 ∧ code e700143474794 = 9496236497002 := by decide
theorem cert_e700143474794 : check e700143474794 [[.under,.left]] .width = true := by decide
def e700143475226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700143475226 : Closed e700143475226 ∧ code e700143475226 = 9496236497434 := by decide
theorem cert_e700143475226 : check e700143475226 [[.under,.left]] .chain = true := by decide
def e700143534186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))
theorem wire_e700143534186 : Closed e700143534186 ∧ code e700143534186 = 9496236556394 := by decide
theorem cert_e700143534186 : check e700143534186 [[.under,.left]] .width = true := by decide
def e700143534554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)))
theorem wire_e700143534554 : Closed e700143534554 ∧ code e700143534554 = 9496236556762 := by decide
theorem cert_e700143534554 : check e700143534554 [[.under,.left]] .width = true := by decide
def e700143535530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))
theorem wire_e700143535530 : Closed e700143535530 ∧ code e700143535530 = 9496236557738 := by decide
theorem cert_e700143535530 : check e700143535530 [[.under,.left]] .width = true := by decide
def e700143535722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700143535722 : Closed e700143535722 ∧ code e700143535722 = 9496236557930 := by decide
theorem cert_e700143535722 : check e700143535722 [[.under,.left]] .width = true := by decide
def e700143540330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)))
theorem wire_e700143540330 : Closed e700143540330 ∧ code e700143540330 = 9496236562538 := by decide
theorem cert_e700143540330 : check e700143540330 [[.under,.left]] .width = true := by decide
def e700143540762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e700143540762 : Closed e700143540762 ∧ code e700143540762 = 9496236562970 := by decide
theorem cert_e700143540762 : check e700143540762 [[.under,.left]] .chain = true := by decide
def e700482678202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e700482678202 : Closed e700482678202 ∧ code e700482678202 = 9496575700410 := by decide
theorem cert_e700482678202 : check e700482678202 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482678234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e700482678234 : Closed e700482678234 ∧ code e700482678234 = 9496575700442 := by decide
theorem cert_e700482678234 : check e700482678234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482678490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.var 0)))
theorem wire_e700482678490 : Closed e700482678490 ∧ code e700482678490 = 9496575700698 := by decide
theorem cert_e700482678490 : check e700482678490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e700482680250 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e700482680250 : Closed e700482680250 ∧ code e700482680250 = 9496575702458 := by decide
theorem cert_e700482680250 : check e700482680250 [[.under,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e699344629482
#print axioms Blc.Floor43.cert_e699344629610
#print axioms Blc.Floor43.cert_e700128854490
#print axioms Blc.Floor43.cert_e700128855466
#print axioms Blc.Floor43.cert_e700128855658
#print axioms Blc.Floor43.cert_e700129378778
#print axioms Blc.Floor43.cert_e700129379754
#print axioms Blc.Floor43.cert_e700129379946
