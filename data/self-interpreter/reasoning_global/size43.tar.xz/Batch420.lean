import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373726234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373726234 : Closed e2422373726234 ∧ code e2422373726234 = 11218466748442 := by decide
theorem cert_e2422373726234 : check e2422373726234 [[],[]] .smaller = true := by decide
def e2422373726270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373726270 : Closed e2422373726270 ∧ code e2422373726270 = 11218466748478 := by decide
theorem cert_e2422373726270 : check e2422373726270 [[],[]] .smaller = true := by decide
def e2422373726318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373726318 : Closed e2422373726318 ∧ code e2422373726318 = 11218466748526 := by decide
theorem cert_e2422373726318 : check e2422373726318 [[],[]] .smaller = true := by decide
def e2422373726326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373726326 : Closed e2422373726326 ∧ code e2422373726326 = 11218466748534 := by decide
theorem cert_e2422373726326 : check e2422373726326 [[],[]] .smaller = true := by decide
def e2422373726330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373726330 : Closed e2422373726330 ∧ code e2422373726330 = 11218466748538 := by decide
theorem cert_e2422373726330 : check e2422373726330 [[],[]] .smaller = true := by decide
def e2422373726570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373726570 : Closed e2422373726570 ∧ code e2422373726570 = 11218466748778 := by decide
theorem cert_e2422373726570 : check e2422373726570 [[],[]] .smaller = true := by decide
def e2422373726594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373726594 : Closed e2422373726594 ∧ code e2422373726594 = 11218466748802 := by decide
theorem cert_e2422373726594 : check e2422373726594 [[],[]] .smaller = true := by decide
def e2422373726606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373726606 : Closed e2422373726606 ∧ code e2422373726606 = 11218466748814 := by decide
theorem cert_e2422373726606 : check e2422373726606 [[],[]] .smaller = true := by decide
def e2422373726618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373726618 : Closed e2422373726618 ∧ code e2422373726618 = 11218466748826 := by decide
theorem cert_e2422373726618 : check e2422373726618 [[],[]] .smaller = true := by decide
def e2422373726662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373726662 : Closed e2422373726662 ∧ code e2422373726662 = 11218466748870 := by decide
theorem cert_e2422373726662 : check e2422373726662 [[],[]] .smaller = true := by decide
def e2422373726686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373726686 : Closed e2422373726686 ∧ code e2422373726686 = 11218466748894 := by decide
theorem cert_e2422373726686 : check e2422373726686 [[],[]] .three = true := by decide
def e2422373726690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373726690 : Closed e2422373726690 ∧ code e2422373726690 = 11218466748898 := by decide
theorem cert_e2422373726690 : check e2422373726690 [[],[]] .smaller = true := by decide
def e2422373726702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373726702 : Closed e2422373726702 ∧ code e2422373726702 = 11218466748910 := by decide
theorem cert_e2422373726702 : check e2422373726702 [[],[]] .smaller = true := by decide
def e2422373726710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373726710 : Closed e2422373726710 ∧ code e2422373726710 = 11218466748918 := by decide
theorem cert_e2422373726710 : check e2422373726710 [[],[]] .three = true := by decide
def e2422373727262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373727262 : Closed e2422373727262 ∧ code e2422373727262 = 11218466749470 := by decide
theorem cert_e2422373727262 : check e2422373727262 [[],[]] .three = true := by decide
def e2422373727286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373727286 : Closed e2422373727286 ∧ code e2422373727286 = 11218466749494 := by decide
theorem cert_e2422373727286 : check e2422373727286 [[],[]] .three = true := by decide
def e2422373727290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373727290 : Closed e2422373727290 ∧ code e2422373727290 = 11218466749498 := by decide
theorem cert_e2422373727290 : check e2422373727290 [[],[]] .three = true := by decide
def e2422373727430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373727430 : Closed e2422373727430 ∧ code e2422373727430 = 11218466749638 := by decide
theorem cert_e2422373727430 : check e2422373727430 [[],[]] .three = true := by decide
def e2422373727454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373727454 : Closed e2422373727454 ∧ code e2422373727454 = 11218466749662 := by decide
theorem cert_e2422373727454 : check e2422373727454 [[],[]] .three = true := by decide
def e2422373727458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373727458 : Closed e2422373727458 ∧ code e2422373727458 = 11218466749666 := by decide
theorem cert_e2422373727458 : check e2422373727458 [[],[]] .three = true := by decide
def e2422373727470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373727470 : Closed e2422373727470 ∧ code e2422373727470 = 11218466749678 := by decide
theorem cert_e2422373727470 : check e2422373727470 [[],[]] .three = true := by decide
def e2422373727478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373727478 : Closed e2422373727478 ∧ code e2422373727478 = 11218466749686 := by decide
theorem cert_e2422373727478 : check e2422373727478 [[],[]] .three = true := by decide
def e2422373727482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373727482 : Closed e2422373727482 ∧ code e2422373727482 = 11218466749690 := by decide
theorem cert_e2422373727482 : check e2422373727482 [[],[]] .three = true := by decide
def e2422373728734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 3)))))))
theorem wire_e2422373728734 : Closed e2422373728734 ∧ code e2422373728734 = 11218466750942 := by decide
theorem cert_e2422373728734 : check e2422373728734 [[],[]] .three = true := by decide
def e2422373728762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 5))))) (.var 0)))))))
theorem wire_e2422373728762 : Closed e2422373728762 ∧ code e2422373728762 = 11218466750970 := by decide
theorem cert_e2422373728762 : check e2422373728762 [[],[]] .three = true := by decide
def e2422373729134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 2)))))))
theorem wire_e2422373729134 : Closed e2422373729134 ∧ code e2422373729134 = 11218466751342 := by decide
theorem cert_e2422373729134 : check e2422373729134 [[],[]] .smaller = true := by decide
def e2422373729146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 0)))))))
theorem wire_e2422373729146 : Closed e2422373729146 ∧ code e2422373729146 = 11218466751354 := by decide
theorem cert_e2422373729146 : check e2422373729146 [[],[]] .smaller = true := by decide
def e2422373729198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 2)))))))
theorem wire_e2422373729198 : Closed e2422373729198 ∧ code e2422373729198 = 11218466751406 := by decide
theorem cert_e2422373729198 : check e2422373729198 [[],[]] .smaller = true := by decide
def e2422373729258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 0)))))))
theorem wire_e2422373729258 : Closed e2422373729258 ∧ code e2422373729258 = 11218466751466 := by decide
theorem cert_e2422373729258 : check e2422373729258 [[],[]] .smaller = true := by decide
def e2422373729502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373729502 : Closed e2422373729502 ∧ code e2422373729502 = 11218466751710 := by decide
theorem cert_e2422373729502 : check e2422373729502 [[],[]] .three = true := by decide
def e2422373729530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373729530 : Closed e2422373729530 ∧ code e2422373729530 = 11218466751738 := by decide
theorem cert_e2422373729530 : check e2422373729530 [[],[]] .three = true := by decide
def e2422373729854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 4))))))))
theorem wire_e2422373729854 : Closed e2422373729854 ∧ code e2422373729854 = 11218466752062 := by decide
theorem cert_e2422373729854 : check e2422373729854 [[],[]] .three = true := by decide
def e2422373729902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373729902 : Closed e2422373729902 ∧ code e2422373729902 = 11218466752110 := by decide
theorem cert_e2422373729902 : check e2422373729902 [[],[]] .smaller = true := by decide
def e2422373729914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373729914 : Closed e2422373729914 ∧ code e2422373729914 = 11218466752122 := by decide
theorem cert_e2422373729914 : check e2422373729914 [[],[]] .smaller = true := by decide
def e2422373730202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373730202 : Closed e2422373730202 ∧ code e2422373730202 = 11218466752410 := by decide
theorem cert_e2422373730202 : check e2422373730202 [[],[]] .smaller = true := by decide
def e2422373730246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 4)))) (.lam (.var 1))))))))
theorem wire_e2422373730246 : Closed e2422373730246 ∧ code e2422373730246 = 11218466752454 := by decide
theorem cert_e2422373730246 : check e2422373730246 [[],[]] .three = true := by decide
def e2422373731422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 3)))))))
theorem wire_e2422373731422 : Closed e2422373731422 ∧ code e2422373731422 = 11218466753630 := by decide
theorem cert_e2422373731422 : check e2422373731422 [[],[]] .three = true := by decide
def e2422373731438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 2)))))))
theorem wire_e2422373731438 : Closed e2422373731438 ∧ code e2422373731438 = 11218466753646 := by decide
theorem cert_e2422373731438 : check e2422373731438 [[],[]] .smaller = true := by decide
def e2422373731450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373731450 : Closed e2422373731450 ∧ code e2422373731450 = 11218466753658 := by decide
theorem cert_e2422373731450 : check e2422373731450 [[],[]] .smaller = true := by decide
def e2422373731614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 3))))))))
theorem wire_e2422373731614 : Closed e2422373731614 ∧ code e2422373731614 = 11218466753822 := by decide
theorem cert_e2422373731614 : check e2422373731614 [[],[]] .smaller = true := by decide
def e2422373731782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373731782 : Closed e2422373731782 ∧ code e2422373731782 = 11218466753990 := by decide
theorem cert_e2422373731782 : check e2422373731782 [[],[]] .smaller = true := by decide
def e2422373731806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 3)))))))
theorem wire_e2422373731806 : Closed e2422373731806 ∧ code e2422373731806 = 11218466754014 := by decide
theorem cert_e2422373731806 : check e2422373731806 [[],[]] .three = true := by decide
def e2422373731810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))) (.lam (.var 0))))))))
theorem wire_e2422373731810 : Closed e2422373731810 ∧ code e2422373731810 = 11218466754018 := by decide
theorem cert_e2422373731810 : check e2422373731810 [[],[]] .three = true := by decide
def e2422373731822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 2)))))))
theorem wire_e2422373731822 : Closed e2422373731822 ∧ code e2422373731822 = 11218466754030 := by decide
theorem cert_e2422373731822 : check e2422373731822 [[],[]] .three = true := by decide
def e2422373732122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422373732122 : Closed e2422373732122 ∧ code e2422373732122 = 11218466754330 := by decide
theorem cert_e2422373732122 : check e2422373732122 [[],[]] .smaller = true := by decide
def e2422373732166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422373732166 : Closed e2422373732166 ∧ code e2422373732166 = 11218466754374 := by decide
theorem cert_e2422373732166 : check e2422373732166 [[],[]] .smaller = true := by decide
def e2422373732190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 3)))))))
theorem wire_e2422373732190 : Closed e2422373732190 ∧ code e2422373732190 = 11218466754398 := by decide
theorem cert_e2422373732190 : check e2422373732190 [[],[]] .three = true := by decide
def e2422373732218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e2422373732218 : Closed e2422373732218 ∧ code e2422373732218 = 11218466754426 := by decide
theorem cert_e2422373732218 : check e2422373732218 [[],[]] .three = true := by decide
def e2422373732234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373732234 : Closed e2422373732234 ∧ code e2422373732234 = 11218466754442 := by decide
theorem cert_e2422373732234 : check e2422373732234 [[],[]] .three = true := by decide
def e2422373732258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373732258 : Closed e2422373732258 ∧ code e2422373732258 = 11218466754466 := by decide
theorem cert_e2422373732258 : check e2422373732258 [[],[]] .three = true := by decide
def e2422373732270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 2)))))))
theorem wire_e2422373732270 : Closed e2422373732270 ∧ code e2422373732270 = 11218466754478 := by decide
theorem cert_e2422373732270 : check e2422373732270 [[],[]] .three = true := by decide
def e2422373732282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e2422373732282 : Closed e2422373732282 ∧ code e2422373732282 = 11218466754490 := by decide
theorem cert_e2422373732282 : check e2422373732282 [[],[]] .three = true := by decide
def e2422373732478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373732478 : Closed e2422373732478 ∧ code e2422373732478 = 11218466754686 := by decide
theorem cert_e2422373732478 : check e2422373732478 [[],[]] .three = true := by decide
def e2422373732574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373732574 : Closed e2422373732574 ∧ code e2422373732574 = 11218466754782 := by decide
theorem cert_e2422373732574 : check e2422373732574 [[],[]] .smaller = true := by decide
def e2422373732602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373732602 : Closed e2422373732602 ∧ code e2422373732602 = 11218466754810 := by decide
theorem cert_e2422373732602 : check e2422373732602 [[],[]] .smaller = true := by decide
def e2422373733150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373733150 : Closed e2422373733150 ∧ code e2422373733150 = 11218466755358 := by decide
theorem cert_e2422373733150 : check e2422373733150 [[],[]] .smaller = true := by decide
def e2422373733318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373733318 : Closed e2422373733318 ∧ code e2422373733318 = 11218466755526 := by decide
theorem cert_e2422373733318 : check e2422373733318 [[],[]] .smaller = true := by decide
def e2422373733342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373733342 : Closed e2422373733342 ∧ code e2422373733342 = 11218466755550 := by decide
theorem cert_e2422373733342 : check e2422373733342 [[],[]] .three = true := by decide
def e2422373733346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373733346 : Closed e2422373733346 ∧ code e2422373733346 = 11218466755554 := by decide
theorem cert_e2422373733346 : check e2422373733346 [[],[]] .three = true := by decide
def e2422373733358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373733358 : Closed e2422373733358 ∧ code e2422373733358 = 11218466755566 := by decide
theorem cert_e2422373733358 : check e2422373733358 [[],[]] .three = true := by decide
def e2422373735478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373735478 : Closed e2422373735478 ∧ code e2422373735478 = 11218466757686 := by decide
theorem cert_e2422373735478 : check e2422373735478 [[],[]] .smaller = true := by decide
def e2422373735482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373735482 : Closed e2422373735482 ∧ code e2422373735482 = 11218466757690 := by decide
theorem cert_e2422373735482 : check e2422373735482 [[],[]] .smaller = true := by decide
def e2422373735622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373735622 : Closed e2422373735622 ∧ code e2422373735622 = 11218466757830 := by decide
theorem cert_e2422373735622 : check e2422373735622 [[],[]] .smaller = true := by decide
def e2422373735646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373735646 : Closed e2422373735646 ∧ code e2422373735646 = 11218466757854 := by decide
theorem cert_e2422373735646 : check e2422373735646 [[],[]] .three = true := by decide
def e2422373735674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373735674 : Closed e2422373735674 ∧ code e2422373735674 = 11218466757882 := by decide
theorem cert_e2422373735674 : check e2422373735674 [[],[]] .three = true := by decide
def e2422373735950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373735950 : Closed e2422373735950 ∧ code e2422373735950 = 11218466758158 := by decide
theorem cert_e2422373735950 : check e2422373735950 [[],[]] .three = true := by decide
def e2422373736034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373736034 : Closed e2422373736034 ∧ code e2422373736034 = 11218466758242 := by decide
theorem cert_e2422373736034 : check e2422373736034 [[],[]] .three = true := by decide
def e2422373736046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373736046 : Closed e2422373736046 ∧ code e2422373736046 = 11218466758254 := by decide
theorem cert_e2422373736046 : check e2422373736046 [[],[]] .three = true := by decide
def e2422373736058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373736058 : Closed e2422373736058 ∧ code e2422373736058 = 11218466758266 := by decide
theorem cert_e2422373736058 : check e2422373736058 [[],[]] .three = true := by decide
def e2422373736554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)))))))
theorem wire_e2422373736554 : Closed e2422373736554 ∧ code e2422373736554 = 11218466758762 := by decide
theorem cert_e2422373736554 : check e2422373736554 [[],[]] .smaller = true := by decide
def e2422373736602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373736602 : Closed e2422373736602 ∧ code e2422373736602 = 11218466758810 := by decide
theorem cert_e2422373736602 : check e2422373736602 [[],[]] .smaller = true := by decide
def e2422373736686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 2)))))))
theorem wire_e2422373736686 : Closed e2422373736686 ∧ code e2422373736686 = 11218466758894 := by decide
theorem cert_e2422373736686 : check e2422373736686 [[],[]] .smaller = true := by decide
def e2422373736698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 4))))) (.var 0)))))))
theorem wire_e2422373736698 : Closed e2422373736698 ∧ code e2422373736698 = 11218466758906 := by decide
theorem cert_e2422373736698 : check e2422373736698 [[],[]] .smaller = true := by decide
def e2422373736886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 1)))))))
theorem wire_e2422373736886 : Closed e2422373736886 ∧ code e2422373736886 = 11218466759094 := by decide
theorem cert_e2422373736886 : check e2422373736886 [[],[]] .smaller = true := by decide
def e2422373736890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 0)))))))
theorem wire_e2422373736890 : Closed e2422373736890 ∧ code e2422373736890 = 11218466759098 := by decide
theorem cert_e2422373736890 : check e2422373736890 [[],[]] .smaller = true := by decide
def e2422373736918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 1)))))))
theorem wire_e2422373736918 : Closed e2422373736918 ∧ code e2422373736918 = 11218466759126 := by decide
theorem cert_e2422373736918 : check e2422373736918 [[],[]] .smaller = true := by decide
def e2422373736922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))) (.var 0)))))))
theorem wire_e2422373736922 : Closed e2422373736922 ∧ code e2422373736922 = 11218466759130 := by decide
theorem cert_e2422373736922 : check e2422373736922 [[],[]] .smaller = true := by decide
def e2422373736938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 0)))))))
theorem wire_e2422373736938 : Closed e2422373736938 ∧ code e2422373736938 = 11218466759146 := by decide
theorem cert_e2422373736938 : check e2422373736938 [[],[]] .smaller = true := by decide
def e2422373737070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373737070 : Closed e2422373737070 ∧ code e2422373737070 = 11218466759278 := by decide
theorem cert_e2422373737070 : check e2422373737070 [[],[]] .smaller = true := by decide
def e2422373737082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373737082 : Closed e2422373737082 ∧ code e2422373737082 = 11218466759290 := by decide
theorem cert_e2422373737082 : check e2422373737082 [[],[]] .smaller = true := by decide
def e2422373737246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422373737246 : Closed e2422373737246 ∧ code e2422373737246 = 11218466759454 := by decide
theorem cert_e2422373737246 : check e2422373737246 [[],[]] .smaller = true := by decide
def e2422373737270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373737270 : Closed e2422373737270 ∧ code e2422373737270 = 11218466759478 := by decide
theorem cert_e2422373737270 : check e2422373737270 [[],[]] .smaller = true := by decide
def e2422373737274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373737274 : Closed e2422373737274 ∧ code e2422373737274 = 11218466759482 := by decide
theorem cert_e2422373737274 : check e2422373737274 [[],[]] .smaller = true := by decide
def e2422373737370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373737370 : Closed e2422373737370 ∧ code e2422373737370 = 11218466759578 := by decide
theorem cert_e2422373737370 : check e2422373737370 [[],[]] .smaller = true := by decide
def e2422373737414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422373737414 : Closed e2422373737414 ∧ code e2422373737414 = 11218466759622 := by decide
theorem cert_e2422373737414 : check e2422373737414 [[],[]] .smaller = true := by decide
def e2422373737438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e2422373737438 : Closed e2422373737438 ∧ code e2422373737438 = 11218466759646 := by decide
theorem cert_e2422373737438 : check e2422373737438 [[],[]] .three = true := by decide
def e2422373737454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e2422373737454 : Closed e2422373737454 ∧ code e2422373737454 = 11218466759662 := by decide
theorem cert_e2422373737454 : check e2422373737454 [[],[]] .three = true := by decide
def e2422373737898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373737898 : Closed e2422373737898 ∧ code e2422373737898 = 11218466760106 := by decide
theorem cert_e2422373737898 : check e2422373737898 [[],[]] .smaller = true := by decide
def e2422373737994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 0)))))))
theorem wire_e2422373737994 : Closed e2422373737994 ∧ code e2422373737994 = 11218466760202 := by decide
theorem cert_e2422373737994 : check e2422373737994 [[],[]] .smaller = true := by decide
def e2422373738030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373738030 : Closed e2422373738030 ∧ code e2422373738030 = 11218466760238 := by decide
theorem cert_e2422373738030 : check e2422373738030 [[],[]] .smaller = true := by decide
def e2422373738038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373738038 : Closed e2422373738038 ∧ code e2422373738038 = 11218466760246 := by decide
theorem cert_e2422373738038 : check e2422373738038 [[],[]] .smaller = true := by decide
def e2422373738042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373738042 : Closed e2422373738042 ∧ code e2422373738042 = 11218466760250 := by decide
theorem cert_e2422373738042 : check e2422373738042 [[],[]] .smaller = true := by decide
def e2422373738090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373738090 : Closed e2422373738090 ∧ code e2422373738090 = 11218466760298 := by decide
theorem cert_e2422373738090 : check e2422373738090 [[],[]] .smaller = true := by decide
def e2422373738114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373738114 : Closed e2422373738114 ∧ code e2422373738114 = 11218466760322 := by decide
theorem cert_e2422373738114 : check e2422373738114 [[],[]] .smaller = true := by decide
def e2422373738126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373738126 : Closed e2422373738126 ∧ code e2422373738126 = 11218466760334 := by decide
theorem cert_e2422373738126 : check e2422373738126 [[],[]] .smaller = true := by decide
def e2422373738138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373738138 : Closed e2422373738138 ∧ code e2422373738138 = 11218466760346 := by decide
theorem cert_e2422373738138 : check e2422373738138 [[],[]] .smaller = true := by decide
def e2422373738182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373738182 : Closed e2422373738182 ∧ code e2422373738182 = 11218466760390 := by decide
theorem cert_e2422373738182 : check e2422373738182 [[],[]] .smaller = true := by decide
def e2422373738206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e2422373738206 : Closed e2422373738206 ∧ code e2422373738206 = 11218466760414 := by decide
theorem cert_e2422373738206 : check e2422373738206 [[],[]] .three = true := by decide
def e2422373738210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373738210 : Closed e2422373738210 ∧ code e2422373738210 = 11218466760418 := by decide
theorem cert_e2422373738210 : check e2422373738210 [[],[]] .smaller = true := by decide
def e2422373738222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2422373738222 : Closed e2422373738222 ∧ code e2422373738222 = 11218466760430 := by decide
theorem cert_e2422373738222 : check e2422373738222 [[],[]] .smaller = true := by decide
def e2422373738230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2422373738230 : Closed e2422373738230 ∧ code e2422373738230 = 11218466760438 := by decide
theorem cert_e2422373738230 : check e2422373738230 [[],[]] .three = true := by decide
def e2422373738266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422373738266 : Closed e2422373738266 ∧ code e2422373738266 = 11218466760474 := by decide
theorem cert_e2422373738266 : check e2422373738266 [[],[]] .smaller = true := by decide
def e2422373738310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422373738310 : Closed e2422373738310 ∧ code e2422373738310 = 11218466760518 := by decide
theorem cert_e2422373738310 : check e2422373738310 [[],[]] .smaller = true := by decide
def e2422373738334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e2422373738334 : Closed e2422373738334 ∧ code e2422373738334 = 11218466760542 := by decide
theorem cert_e2422373738334 : check e2422373738334 [[],[]] .three = true := by decide
def e2422373738362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2422373738362 : Closed e2422373738362 ∧ code e2422373738362 = 11218466760570 := by decide
theorem cert_e2422373738362 : check e2422373738362 [[],[]] .three = true := by decide
def e2422373738378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373738378 : Closed e2422373738378 ∧ code e2422373738378 = 11218466760586 := by decide
theorem cert_e2422373738378 : check e2422373738378 [[],[]] .smaller = true := by decide
def e2422373738402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373738402 : Closed e2422373738402 ∧ code e2422373738402 = 11218466760610 := by decide
theorem cert_e2422373738402 : check e2422373738402 [[],[]] .smaller = true := by decide
def e2422373738414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2422373738414 : Closed e2422373738414 ∧ code e2422373738414 = 11218466760622 := by decide
theorem cert_e2422373738414 : check e2422373738414 [[],[]] .smaller = true := by decide
def e2422373738426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e2422373738426 : Closed e2422373738426 ∧ code e2422373738426 = 11218466760634 := by decide
theorem cert_e2422373738426 : check e2422373738426 [[],[]] .smaller = true := by decide
def e2422373738454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2422373738454 : Closed e2422373738454 ∧ code e2422373738454 = 11218466760662 := by decide
theorem cert_e2422373738454 : check e2422373738454 [[],[]] .three = true := by decide
def e2422373738458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2422373738458 : Closed e2422373738458 ∧ code e2422373738458 = 11218466760666 := by decide
theorem cert_e2422373738458 : check e2422373738458 [[],[]] .three = true := by decide
def e2422373738522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373738522 : Closed e2422373738522 ∧ code e2422373738522 = 11218466760730 := by decide
theorem cert_e2422373738522 : check e2422373738522 [[],[]] .smaller = true := by decide
def e2422373738558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373738558 : Closed e2422373738558 ∧ code e2422373738558 = 11218466760766 := by decide
theorem cert_e2422373738558 : check e2422373738558 [[],[]] .smaller = true := by decide
def e2422373738606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373738606 : Closed e2422373738606 ∧ code e2422373738606 = 11218466760814 := by decide
theorem cert_e2422373738606 : check e2422373738606 [[],[]] .smaller = true := by decide
def e2422373738614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373738614 : Closed e2422373738614 ∧ code e2422373738614 = 11218466760822 := by decide
theorem cert_e2422373738614 : check e2422373738614 [[],[]] .smaller = true := by decide
def e2422373738618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373738618 : Closed e2422373738618 ∧ code e2422373738618 = 11218466760826 := by decide
theorem cert_e2422373738618 : check e2422373738618 [[],[]] .smaller = true := by decide
def e2422373738858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373738858 : Closed e2422373738858 ∧ code e2422373738858 = 11218466761066 := by decide
theorem cert_e2422373738858 : check e2422373738858 [[],[]] .smaller = true := by decide
def e2422373738882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373738882 : Closed e2422373738882 ∧ code e2422373738882 = 11218466761090 := by decide
theorem cert_e2422373738882 : check e2422373738882 [[],[]] .smaller = true := by decide
def e2422373738894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373738894 : Closed e2422373738894 ∧ code e2422373738894 = 11218466761102 := by decide
theorem cert_e2422373738894 : check e2422373738894 [[],[]] .smaller = true := by decide
def e2422373738906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373738906 : Closed e2422373738906 ∧ code e2422373738906 = 11218466761114 := by decide
theorem cert_e2422373738906 : check e2422373738906 [[],[]] .smaller = true := by decide
def e2422373738950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373738950 : Closed e2422373738950 ∧ code e2422373738950 = 11218466761158 := by decide
theorem cert_e2422373738950 : check e2422373738950 [[],[]] .smaller = true := by decide
def e2422373738974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373738974 : Closed e2422373738974 ∧ code e2422373738974 = 11218466761182 := by decide
theorem cert_e2422373738974 : check e2422373738974 [[],[]] .three = true := by decide
def e2422373738978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373738978 : Closed e2422373738978 ∧ code e2422373738978 = 11218466761186 := by decide
theorem cert_e2422373738978 : check e2422373738978 [[],[]] .smaller = true := by decide
def e2422373738990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373738990 : Closed e2422373738990 ∧ code e2422373738990 = 11218466761198 := by decide
theorem cert_e2422373738990 : check e2422373738990 [[],[]] .smaller = true := by decide
def e2422373738998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373738998 : Closed e2422373738998 ∧ code e2422373738998 = 11218466761206 := by decide
theorem cert_e2422373738998 : check e2422373738998 [[],[]] .three = true := by decide
def e2422373739574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373739574 : Closed e2422373739574 ∧ code e2422373739574 = 11218466761782 := by decide
theorem cert_e2422373739574 : check e2422373739574 [[],[]] .smaller = true := by decide
def e2422373739578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373739578 : Closed e2422373739578 ∧ code e2422373739578 = 11218466761786 := by decide
theorem cert_e2422373739578 : check e2422373739578 [[],[]] .smaller = true := by decide
def e2422373739718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373739718 : Closed e2422373739718 ∧ code e2422373739718 = 11218466761926 := by decide
theorem cert_e2422373739718 : check e2422373739718 [[],[]] .smaller = true := by decide
def e2422373739742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373739742 : Closed e2422373739742 ∧ code e2422373739742 = 11218466761950 := by decide
theorem cert_e2422373739742 : check e2422373739742 [[],[]] .three = true := by decide
def e2422373739770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373739770 : Closed e2422373739770 ∧ code e2422373739770 = 11218466761978 := by decide
theorem cert_e2422373739770 : check e2422373739770 [[],[]] .three = true := by decide
def e2422373740046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373740046 : Closed e2422373740046 ∧ code e2422373740046 = 11218466762254 := by decide
theorem cert_e2422373740046 : check e2422373740046 [[],[]] .smaller = true := by decide
def e2422373740094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.lam (.var 4))))))))
theorem wire_e2422373740094 : Closed e2422373740094 ∧ code e2422373740094 = 11218466762302 := by decide
theorem cert_e2422373740094 : check e2422373740094 [[],[]] .three = true := by decide
def e2422373740130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373740130 : Closed e2422373740130 ∧ code e2422373740130 = 11218466762338 := by decide
theorem cert_e2422373740130 : check e2422373740130 [[],[]] .smaller = true := by decide
def e2422373740142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373740142 : Closed e2422373740142 ∧ code e2422373740142 = 11218466762350 := by decide
theorem cert_e2422373740142 : check e2422373740142 [[],[]] .smaller = true := by decide
def e2422373740154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373740154 : Closed e2422373740154 ∧ code e2422373740154 = 11218466762362 := by decide
theorem cert_e2422373740154 : check e2422373740154 [[],[]] .smaller = true := by decide
def e2422373740318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.lam (.var 3))))))))
theorem wire_e2422373740318 : Closed e2422373740318 ∧ code e2422373740318 = 11218466762526 := by decide
theorem cert_e2422373740318 : check e2422373740318 [[],[]] .three = true := by decide
def e2422373740342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373740342 : Closed e2422373740342 ∧ code e2422373740342 = 11218466762550 := by decide
theorem cert_e2422373740342 : check e2422373740342 [[],[]] .three = true := by decide
def e2422373740346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373740346 : Closed e2422373740346 ∧ code e2422373740346 = 11218466762554 := by decide
theorem cert_e2422373740346 : check e2422373740346 [[],[]] .three = true := by decide
def e2422373740662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373740662 : Closed e2422373740662 ∧ code e2422373740662 = 11218466762870 := by decide
theorem cert_e2422373740662 : check e2422373740662 [[],[]] .three = true := by decide
def e2422373740666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373740666 : Closed e2422373740666 ∧ code e2422373740666 = 11218466762874 := by decide
theorem cert_e2422373740666 : check e2422373740666 [[],[]] .three = true := by decide
def e2422373740762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.app (.var 0) (.var 1))))) (.var 0)))))))
theorem wire_e2422373740762 : Closed e2422373740762 ∧ code e2422373740762 = 11218466762970 := by decide
theorem cert_e2422373740762 : check e2422373740762 [[],[]] .three = true := by decide
def e2422373740778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.app (.var 1) (.var 0))))) (.var 0)))))))
theorem wire_e2422373740778 : Closed e2422373740778 ∧ code e2422373740778 = 11218466762986 := by decide
theorem cert_e2422373740778 : check e2422373740778 [[],[]] .three = true := by decide
def e2422373740854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373740854 : Closed e2422373740854 ∧ code e2422373740854 = 11218466763062 := by decide
theorem cert_e2422373740854 : check e2422373740854 [[],[]] .three = true := by decide
def e2422373740858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373740858 : Closed e2422373740858 ∧ code e2422373740858 = 11218466763066 := by decide
theorem cert_e2422373740858 : check e2422373740858 [[],[]] .three = true := by decide
def e2422373740942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373740942 : Closed e2422373740942 ∧ code e2422373740942 = 11218466763150 := by decide
theorem cert_e2422373740942 : check e2422373740942 [[],[]] .three = true := by decide
def e2422373740954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 1)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373740954 : Closed e2422373740954 ∧ code e2422373740954 = 11218466763162 := by decide
theorem cert_e2422373740954 : check e2422373740954 [[],[]] .three = true := by decide
def e2422373740998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373740998 : Closed e2422373740998 ∧ code e2422373740998 = 11218466763206 := by decide
theorem cert_e2422373740998 : check e2422373740998 [[],[]] .three = true := by decide
def e2422373741038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.lam (.var 3)))) (.var 2)))))))
theorem wire_e2422373741038 : Closed e2422373741038 ∧ code e2422373741038 = 11218466763246 := by decide
theorem cert_e2422373741038 : check e2422373741038 [[],[]] .three = true := by decide
def e2422373741334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373741334 : Closed e2422373741334 ∧ code e2422373741334 = 11218466763542 := by decide
theorem cert_e2422373741334 : check e2422373741334 [[],[]] .three = true := by decide
def e2422373741338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422373741338 : Closed e2422373741338 ∧ code e2422373741338 = 11218466763546 := by decide
theorem cert_e2422373741338 : check e2422373741338 [[],[]] .three = true := by decide
def e2422373741382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422373741382 : Closed e2422373741382 ∧ code e2422373741382 = 11218466763590 := by decide
theorem cert_e2422373741382 : check e2422373741382 [[],[]] .three = true := by decide
def e2422373741406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e2422373741406 : Closed e2422373741406 ∧ code e2422373741406 = 11218466763614 := by decide
theorem cert_e2422373741406 : check e2422373741406 [[],[]] .three = true := by decide
def e2422373741410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373741410 : Closed e2422373741410 ∧ code e2422373741410 = 11218466763618 := by decide
theorem cert_e2422373741410 : check e2422373741410 [[],[]] .three = true := by decide
def e2422373741422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2422373741422 : Closed e2422373741422 ∧ code e2422373741422 = 11218466763630 := by decide
theorem cert_e2422373741422 : check e2422373741422 [[],[]] .three = true := by decide
def e2422373741430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2422373741430 : Closed e2422373741430 ∧ code e2422373741430 = 11218466763638 := by decide
theorem cert_e2422373741430 : check e2422373741430 [[],[]] .three = true := by decide
def e2422373741434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2422373741434 : Closed e2422373741434 ∧ code e2422373741434 = 11218466763642 := by decide
theorem cert_e2422373741434 : check e2422373741434 [[],[]] .three = true := by decide
def e2422373741450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373741450 : Closed e2422373741450 ∧ code e2422373741450 = 11218466763658 := by decide
theorem cert_e2422373741450 : check e2422373741450 [[],[]] .three = true := by decide
def e2422373741474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373741474 : Closed e2422373741474 ∧ code e2422373741474 = 11218466763682 := by decide
theorem cert_e2422373741474 : check e2422373741474 [[],[]] .three = true := by decide
def e2422373741486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2422373741486 : Closed e2422373741486 ∧ code e2422373741486 = 11218466763694 := by decide
theorem cert_e2422373741486 : check e2422373741486 [[],[]] .three = true := by decide
def e2422373741498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2422373741498 : Closed e2422373741498 ∧ code e2422373741498 = 11218466763706 := by decide
theorem cert_e2422373741498 : check e2422373741498 [[],[]] .three = true := by decide
end Blc.Floor43
