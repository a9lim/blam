import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2391558648534 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2391558648534 : Closed e2391558648534 ∧ code e2391558648534 = 11187651670742 := by decide
theorem cert_e2391558648534 : check e2391558648534 [[],[.left],[]] .smaller = true := by decide
def e2391558648538 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2391558648538 : Closed e2391558648538 ∧ code e2391558648538 = 11187651670746 := by decide
theorem cert_e2391558648538 : check e2391558648538 [[],[.left],[]] .smaller = true := by decide
def e2391558648554 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2391558648554 : Closed e2391558648554 ∧ code e2391558648554 = 11187651670762 := by decide
theorem cert_e2391558648554 : check e2391558648554 [[],[.left],[]] .smaller = true := by decide
def e2391558648630 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2391558648630 : Closed e2391558648630 ∧ code e2391558648630 = 11187651670838 := by decide
theorem cert_e2391558648630 : check e2391558648630 [[],[.left],[]] .smaller = true := by decide
def e2391558648634 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2391558648634 : Closed e2391558648634 ∧ code e2391558648634 = 11187651670842 := by decide
theorem cert_e2391558648634 : check e2391558648634 [[],[.left],[]] .smaller = true := by decide
def e2391558648730 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2391558648730 : Closed e2391558648730 ∧ code e2391558648730 = 11187651670938 := by decide
theorem cert_e2391558648730 : check e2391558648730 [[],[.left],[]] .smaller = true := by decide
def e2391558764270 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2391558764270 : Closed e2391558764270 ∧ code e2391558764270 = 11187651786478 := by decide
theorem cert_e2391558764270 : check e2391558764270 [[],[.left],[]] .sourceHead = true := by decide
def e2391558764398 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2391558764398 : Closed e2391558764398 ∧ code e2391558764398 = 11187651786606 := by decide
theorem cert_e2391558764398 : check e2391558764398 [[],[.left],[]] .sourceHead = true := by decide
def e2391558764406 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2391558764406 : Closed e2391558764406 ∧ code e2391558764406 = 11187651786614 := by decide
theorem cert_e2391558764406 : check e2391558764406 [[],[.left],[]] .sourceHead = true := by decide
def e2391558765294 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2391558765294 : Closed e2391558765294 ∧ code e2391558765294 = 11187651787502 := by decide
theorem cert_e2391558765294 : check e2391558765294 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2391558765486 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2391558765486 : Closed e2391558765486 ∧ code e2391558765486 = 11187651787694 := by decide
theorem cert_e2391558765486 : check e2391558765486 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2391558765498 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2391558765498 : Closed e2391558765498 ∧ code e2391558765498 = 11187651787706 := by decide
def e2391558765934 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2391558765934 : Closed e2391558765934 ∧ code e2391558765934 = 11187651788142 := by decide
def e2391558765942 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2391558765942 : Closed e2391558765942 ∧ code e2391558765942 = 11187651788150 := by decide
def e2391558765998 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2391558765998 : Closed e2391558765998 ∧ code e2391558765998 = 11187651788206 := by decide
theorem cert_e2391558765998 : check e2391558765998 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2391558766010 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2391558766010 : Closed e2391558766010 ∧ code e2391558766010 = 11187651788218 := by decide
def e2391558766038 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2391558766038 : Closed e2391558766038 ∧ code e2391558766038 = 11187651788246 := by decide
private def t_e2391558766038 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2391558766038 : ¬ IsSelfInterpreter e2391558766038 :=
  wSource (t := t_e2391558766038) (replay_sound (ps := []) (t := e2391558766038) (by decide)) (by decide)
def e2391558766042 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2391558766042 : Closed e2391558766042 ∧ code e2391558766042 = 11187651788250 := by decide
private def t_e2391558766042 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2391558766042 : ¬ IsSelfInterpreter e2391558766042 :=
  wSource (t := t_e2391558766042) (replay_sound (ps := []) (t := e2391558766042) (by decide)) (by decide)
def e2391558770414 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2391558770414 : Closed e2391558770414 ∧ code e2391558770414 = 11187651792622 := by decide
theorem cert_e2391558770414 : check e2391558770414 [[],[.left],[]] .sourceHead = true := by decide
def e2391558770542 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2391558770542 : Closed e2391558770542 ∧ code e2391558770542 = 11187651792750 := by decide
theorem cert_e2391558770542 : check e2391558770542 [[],[.left],[]] .sourceHead = true := by decide
def e2391558770550 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2391558770550 : Closed e2391558770550 ∧ code e2391558770550 = 11187651792758 := by decide
theorem cert_e2391558770550 : check e2391558770550 [[],[.left],[]] .sourceHead = true := by decide
def e2391558773230 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2391558773230 : Closed e2391558773230 ∧ code e2391558773230 = 11187651795438 := by decide
theorem cert_e2391558773230 : check e2391558773230 [[],[.left],[]] .sourceHead = true := by decide
def e2391558773998 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2391558773998 : Closed e2391558773998 ∧ code e2391558773998 = 11187651796206 := by decide
theorem cert_e2391558773998 : check e2391558773998 [[],[.left],[]] .sourceHead = true := by decide
def e2391558774006 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2391558774006 : Closed e2391558774006 ∧ code e2391558774006 = 11187651796214 := by decide
theorem cert_e2391558774006 : check e2391558774006 [[],[.left],[]] .sourceHead = true := by decide
def e2391558776558 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2391558776558 : Closed e2391558776558 ∧ code e2391558776558 = 11187651798766 := by decide
theorem cert_e2391558776558 : check e2391558776558 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2391558776750 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2391558776750 : Closed e2391558776750 ∧ code e2391558776750 = 11187651798958 := by decide
theorem cert_e2391558776750 : check e2391558776750 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2391558776762 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2391558776762 : Closed e2391558776762 ∧ code e2391558776762 = 11187651798970 := by decide
theorem cert_e2391558776762 : checkPay e2391558776762 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2391558777326 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2391558777326 : Closed e2391558777326 ∧ code e2391558777326 = 11187651799534 := by decide
theorem cert_e2391558777326 : check e2391558777326 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2391558778478 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2391558778478 : Closed e2391558778478 ∧ code e2391558778478 = 11187651800686 := by decide
theorem cert_e2391558778478 : check e2391558778478 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2391558778490 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2391558778490 : Closed e2391558778490 ∧ code e2391558778490 = 11187651800698 := by decide
theorem cert_e2391558778490 : check e2391558778490 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2391558779758 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2391558779758 : Closed e2391558779758 ∧ code e2391558779758 = 11187651801966 := by decide
theorem cert_e2391558779758 : check e2391558779758 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2391558779766 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2391558779766 : Closed e2391558779766 ∧ code e2391558779766 = 11187651801974 := by decide
theorem cert_e2391558779766 : check e2391558779766 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2391558779822 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2391558779822 : Closed e2391558779822 ∧ code e2391558779822 = 11187651802030 := by decide
theorem cert_e2391558779822 : check e2391558779822 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2391558779834 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2391558779834 : Closed e2391558779834 ∧ code e2391558779834 = 11187651802042 := by decide
def e2391558779862 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2391558779862 : Closed e2391558779862 ∧ code e2391558779862 = 11187651802070 := by decide
theorem cert_e2391558779862 : check e2391558779862 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2391558779866 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2391558779866 : Closed e2391558779866 ∧ code e2391558779866 = 11187651802074 := by decide
theorem cert_e2391558779866 : check e2391558779866 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2391558780142 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2391558780142 : Closed e2391558780142 ∧ code e2391558780142 = 11187651802350 := by decide
theorem cert_e2391558780142 : check e2391558780142 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2391558780150 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2391558780150 : Closed e2391558780150 ∧ code e2391558780150 = 11187651802358 := by decide
theorem cert_e2391558780150 : check e2391558780150 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2391558780526 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2391558780526 : Closed e2391558780526 ∧ code e2391558780526 = 11187651802734 := by decide
theorem cert_e2391558780526 : check e2391558780526 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2391558780538 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2391558780538 : Closed e2391558780538 ∧ code e2391558780538 = 11187651802746 := by decide
theorem cert_e2391558780538 : check e2391558780538 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2391558780726 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2391558780726 : Closed e2391558780726 ∧ code e2391558780726 = 11187651802934 := by decide
private def t_e2391558780726 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2391558780726 : ¬ IsSelfInterpreter e2391558780726 :=
  wSource (t := t_e2391558780726) (replay_sound (ps := []) (t := e2391558780726) (by decide)) (by decide)
def e2391558780730 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2391558780730 : Closed e2391558780730 ∧ code e2391558780730 = 11187651802938 := by decide
private def t_e2391558780730 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2391558780730 : ¬ IsSelfInterpreter e2391558780730 :=
  wSource (t := t_e2391558780730) (replay_sound (ps := []) (t := e2391558780730) (by decide)) (by decide)
def e2391558785902 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2391558785902 : Closed e2391558785902 ∧ code e2391558785902 = 11187651808110 := by decide
theorem cert_e2391558785902 : check e2391558785902 [[],[.left],[]] .smaller = true := by decide
def e2391558785910 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2391558785910 : Closed e2391558785910 ∧ code e2391558785910 = 11187651808118 := by decide
theorem cert_e2391558785910 : check e2391558785910 [[],[.left],[]] .smaller = true := by decide
def e2391558785966 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2391558785966 : Closed e2391558785966 ∧ code e2391558785966 = 11187651808174 := by decide
theorem cert_e2391558785966 : check e2391558785966 [[],[.left],[]] .smaller = true := by decide
def e2391558785978 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2391558785978 : Closed e2391558785978 ∧ code e2391558785978 = 11187651808186 := by decide
theorem cert_e2391558785978 : check e2391558785978 [[],[.left],[]] .smaller = true := by decide
def e2391558786006 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2391558786006 : Closed e2391558786006 ∧ code e2391558786006 = 11187651808214 := by decide
theorem cert_e2391558786006 : check e2391558786006 [[],[.left],[]] .smaller = true := by decide
def e2391558786010 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2391558786010 : Closed e2391558786010 ∧ code e2391558786010 = 11187651808218 := by decide
theorem cert_e2391558786010 : check e2391558786010 [[],[.left],[]] .smaller = true := by decide
def e2391558786286 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2391558786286 : Closed e2391558786286 ∧ code e2391558786286 = 11187651808494 := by decide
theorem cert_e2391558786286 : check e2391558786286 [[],[.left],[]] .smaller = true := by decide
def e2391558786294 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2391558786294 : Closed e2391558786294 ∧ code e2391558786294 = 11187651808502 := by decide
theorem cert_e2391558786294 : check e2391558786294 [[],[.left],[]] .smaller = true := by decide
def e2391558786670 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2391558786670 : Closed e2391558786670 ∧ code e2391558786670 = 11187651808878 := by decide
theorem cert_e2391558786670 : check e2391558786670 [[],[.left],[]] .smaller = true := by decide
def e2391558786682 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2391558786682 : Closed e2391558786682 ∧ code e2391558786682 = 11187651808890 := by decide
theorem cert_e2391558786682 : check e2391558786682 [[],[.left],[]] .smaller = true := by decide
def e2391558786870 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2391558786870 : Closed e2391558786870 ∧ code e2391558786870 = 11187651809078 := by decide
theorem cert_e2391558786870 : check e2391558786870 [[],[.left],[]] .smaller = true := by decide
def e2391558786874 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2391558786874 : Closed e2391558786874 ∧ code e2391558786874 = 11187651809082 := by decide
theorem cert_e2391558786874 : check e2391558786874 [[],[.left],[]] .smaller = true := by decide
def e2391558794990 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2391558794990 : Closed e2391558794990 ∧ code e2391558794990 = 11187651817198 := by decide
theorem cert_e2391558794990 : check e2391558794990 [[],[.left],[]] .sourceHead = true := by decide
def e2391558795118 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2391558795118 : Closed e2391558795118 ∧ code e2391558795118 = 11187651817326 := by decide
theorem cert_e2391558795118 : check e2391558795118 [[],[.left],[]] .sourceHead = true := by decide
def e2391558795126 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2391558795126 : Closed e2391558795126 ∧ code e2391558795126 = 11187651817334 := by decide
theorem cert_e2391558795126 : check e2391558795126 [[],[.left],[]] .sourceHead = true := by decide
def e2391558797806 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2391558797806 : Closed e2391558797806 ∧ code e2391558797806 = 11187651820014 := by decide
theorem cert_e2391558797806 : check e2391558797806 [[],[.left],[]] .sourceHead = true := by decide
def e2391558798574 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2391558798574 : Closed e2391558798574 ∧ code e2391558798574 = 11187651820782 := by decide
theorem cert_e2391558798574 : check e2391558798574 [[],[.left],[]] .sourceHead = true := by decide
def e2391558798582 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2391558798582 : Closed e2391558798582 ∧ code e2391558798582 = 11187651820790 := by decide
theorem cert_e2391558798582 : check e2391558798582 [[],[.left],[]] .sourceHead = true := by decide
def e2391558821614 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2391558821614 : Closed e2391558821614 ∧ code e2391558821614 = 11187651843822 := by decide
theorem cert_e2391558821614 : check e2391558821614 [[],[.left],[],[.under]] .three = true := by decide
def e2391558821806 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2391558821806 : Closed e2391558821806 ∧ code e2391558821806 = 11187651844014 := by decide
theorem cert_e2391558821806 : check e2391558821806 [[],[.left],[],[.under]] .three = true := by decide
def e2391558821818 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2391558821818 : Closed e2391558821818 ∧ code e2391558821818 = 11187651844026 := by decide
theorem cert_e2391558821818 : check e2391558821818 [[],[.left],[],[.under]] .three = true := by decide
def e2391558822382 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2391558822382 : Closed e2391558822382 ∧ code e2391558822382 = 11187651844590 := by decide
theorem cert_e2391558822382 : check e2391558822382 [[],[.left],[],[.under]] .three = true := by decide
def e2391558823534 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2391558823534 : Closed e2391558823534 ∧ code e2391558823534 = 11187651845742 := by decide
theorem cert_e2391558823534 : check e2391558823534 [[],[.left],[],[.under]] .three = true := by decide
def e2391558823546 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2391558823546 : Closed e2391558823546 ∧ code e2391558823546 = 11187651845754 := by decide
theorem cert_e2391558823546 : check e2391558823546 [[],[.left],[],[.under]] .three = true := by decide
def e2391558835054 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2391558835054 : Closed e2391558835054 ∧ code e2391558835054 = 11187651857262 := by decide
theorem cert_e2391558835054 : check e2391558835054 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835062 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2391558835062 : Closed e2391558835062 ∧ code e2391558835062 = 11187651857270 := by decide
theorem cert_e2391558835062 : check e2391558835062 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835118 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2391558835118 : Closed e2391558835118 ∧ code e2391558835118 = 11187651857326 := by decide
theorem cert_e2391558835118 : check e2391558835118 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835130 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2391558835130 : Closed e2391558835130 ∧ code e2391558835130 = 11187651857338 := by decide
theorem cert_e2391558835130 : check e2391558835130 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835158 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2391558835158 : Closed e2391558835158 ∧ code e2391558835158 = 11187651857366 := by decide
theorem cert_e2391558835158 : check e2391558835158 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835162 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2391558835162 : Closed e2391558835162 ∧ code e2391558835162 = 11187651857370 := by decide
theorem cert_e2391558835162 : check e2391558835162 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835438 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2391558835438 : Closed e2391558835438 ∧ code e2391558835438 = 11187651857646 := by decide
theorem cert_e2391558835438 : check e2391558835438 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835446 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2391558835446 : Closed e2391558835446 ∧ code e2391558835446 = 11187651857654 := by decide
theorem cert_e2391558835446 : check e2391558835446 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835822 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2391558835822 : Closed e2391558835822 ∧ code e2391558835822 = 11187651858030 := by decide
theorem cert_e2391558835822 : check e2391558835822 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558835834 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2391558835834 : Closed e2391558835834 ∧ code e2391558835834 = 11187651858042 := by decide
theorem cert_e2391558835834 : check e2391558835834 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558836022 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2391558836022 : Closed e2391558836022 ∧ code e2391558836022 = 11187651858230 := by decide
theorem cert_e2391558836022 : check e2391558836022 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391558836026 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2391558836026 : Closed e2391558836026 ∧ code e2391558836026 = 11187651858234 := by decide
theorem cert_e2391558836026 : check e2391558836026 [[],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2391559375726 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2391559375726 : Closed e2391559375726 ∧ code e2391559375726 = 11187652397934 := by decide
theorem cert_e2391559375726 : check e2391559375726 [[],[.left],[],[]] .smaller = true := by decide
def e2391559375734 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2391559375734 : Closed e2391559375734 ∧ code e2391559375734 = 11187652397942 := by decide
theorem cert_e2391559375734 : check e2391559375734 [[],[.left],[],[]] .smaller = true := by decide
def e2391559375790 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2391559375790 : Closed e2391559375790 ∧ code e2391559375790 = 11187652397998 := by decide
theorem cert_e2391559375790 : check e2391559375790 [[],[.left],[],[]] .smaller = true := by decide
def e2391559375802 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2391559375802 : Closed e2391559375802 ∧ code e2391559375802 = 11187652398010 := by decide
theorem cert_e2391559375802 : check e2391559375802 [[],[.left],[],[]] .smaller = true := by decide
def e2391559375830 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2391559375830 : Closed e2391559375830 ∧ code e2391559375830 = 11187652398038 := by decide
theorem cert_e2391559375830 : check e2391559375830 [[],[.left],[],[]] .smaller = true := by decide
def e2391559375834 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2391559375834 : Closed e2391559375834 ∧ code e2391559375834 = 11187652398042 := by decide
theorem cert_e2391559375834 : check e2391559375834 [[],[.left],[],[]] .smaller = true := by decide
def e2391559376110 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2391559376110 : Closed e2391559376110 ∧ code e2391559376110 = 11187652398318 := by decide
theorem cert_e2391559376110 : check e2391559376110 [[],[.left],[],[]] .smaller = true := by decide
def e2391559376118 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2391559376118 : Closed e2391559376118 ∧ code e2391559376118 = 11187652398326 := by decide
theorem cert_e2391559376118 : check e2391559376118 [[],[.left],[],[]] .smaller = true := by decide
def e2391559376494 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2391559376494 : Closed e2391559376494 ∧ code e2391559376494 = 11187652398702 := by decide
theorem cert_e2391559376494 : check e2391559376494 [[],[.left],[],[]] .smaller = true := by decide
def e2391559376506 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2391559376506 : Closed e2391559376506 ∧ code e2391559376506 = 11187652398714 := by decide
theorem cert_e2391559376506 : check e2391559376506 [[],[.left],[],[]] .smaller = true := by decide
def e2391559376694 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2391559376694 : Closed e2391559376694 ∧ code e2391559376694 = 11187652398902 := by decide
theorem cert_e2391559376694 : check e2391559376694 [[],[.left],[],[]] .smaller = true := by decide
def e2391559376698 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2391559376698 : Closed e2391559376698 ∧ code e2391559376698 = 11187652398906 := by decide
theorem cert_e2391559376698 : check e2391559376698 [[],[.left],[],[]] .smaller = true := by decide
def e2392297532954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297532954 : Closed e2392297532954 ∧ code e2392297532954 = 11188390555162 := by decide
private def t_e2392297532954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297532954 : ¬ IsSelfInterpreter e2392297532954 :=
  wSource (t := t_e2392297532954) (replay_sound (ps := []) (t := e2392297532954) (by decide)) (by decide)
def e2392297535002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297535002 : Closed e2392297535002 ∧ code e2392297535002 = 11188390557210 := by decide
private def t_e2392297535002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297535002 : ¬ IsSelfInterpreter e2392297535002 :=
  wSource (t := t_e2392297535002) (replay_sound (ps := []) (t := e2392297535002) (by decide)) (by decide)
def e2392297549338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297549338 : Closed e2392297549338 ∧ code e2392297549338 = 11188390571546 := by decide
private def t_e2392297549338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297549338 : ¬ IsSelfInterpreter e2392297549338 :=
  wSource (t := t_e2392297549338) (replay_sound (ps := []) (t := e2392297549338) (by decide)) (by decide)
def e2392297552410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297552410 : Closed e2392297552410 ∧ code e2392297552410 = 11188390574618 := by decide
private def t_e2392297552410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297552410 : ¬ IsSelfInterpreter e2392297552410 :=
  wSource (t := t_e2392297552410) (replay_sound (ps := []) (t := e2392297552410) (by decide)) (by decide)
def e2392297559578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297559578 : Closed e2392297559578 ∧ code e2392297559578 = 11188390581786 := by decide
private def t_e2392297559578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297559578 : ¬ IsSelfInterpreter e2392297559578 :=
  wSource (t := t_e2392297559578) (replay_sound (ps := []) (t := e2392297559578) (by decide)) (by decide)
def e2392297560602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297560602 : Closed e2392297560602 ∧ code e2392297560602 = 11188390582810 := by decide
private def t_e2392297560602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297560602 : ¬ IsSelfInterpreter e2392297560602 :=
  wSource (t := t_e2392297560602) (replay_sound (ps := []) (t := e2392297560602) (by decide)) (by decide)
def e2392297631258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297631258 : Closed e2392297631258 ∧ code e2392297631258 = 11188390653466 := by decide
private def t_e2392297631258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297631258 : ¬ IsSelfInterpreter e2392297631258 :=
  wSource (t := t_e2392297631258) (replay_sound (ps := []) (t := e2392297631258) (by decide)) (by decide)
def e2392297633306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297633306 : Closed e2392297633306 ∧ code e2392297633306 = 11188390655514 := by decide
private def t_e2392297633306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297633306 : ¬ IsSelfInterpreter e2392297633306 :=
  wSource (t := t_e2392297633306) (replay_sound (ps := []) (t := e2392297633306) (by decide)) (by decide)
def e2392297729562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297729562 : Closed e2392297729562 ∧ code e2392297729562 = 11188390751770 := by decide
private def t_e2392297729562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297729562 : ¬ IsSelfInterpreter e2392297729562 :=
  wSource (t := t_e2392297729562) (replay_sound (ps := []) (t := e2392297729562) (by decide)) (by decide)
def e2392297732634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297732634 : Closed e2392297732634 ∧ code e2392297732634 = 11188390754842 := by decide
private def t_e2392297732634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297732634 : ¬ IsSelfInterpreter e2392297732634 :=
  wSource (t := t_e2392297732634) (replay_sound (ps := []) (t := e2392297732634) (by decide)) (by decide)
def e2392297780762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297780762 : Closed e2392297780762 ∧ code e2392297780762 = 11188390802970 := by decide
private def t_e2392297780762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297780762 : ¬ IsSelfInterpreter e2392297780762 :=
  wSource (t := t_e2392297780762) (replay_sound (ps := []) (t := e2392297780762) (by decide)) (by decide)
def e2392297781786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392297781786 : Closed e2392297781786 ∧ code e2392297781786 = 11188390803994 := by decide
private def t_e2392297781786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392297781786 : ¬ IsSelfInterpreter e2392297781786 :=
  wSource (t := t_e2392297781786) (replay_sound (ps := []) (t := e2392297781786) (by decide)) (by decide)
def e2392299780122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392299780122 : Closed e2392299780122 ∧ code e2392299780122 = 11188392802330 := by decide
theorem cert_e2392299780122 : check e2392299780122 [[],[.left]] .smaller = true := by decide
def e2392299781658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299781658 : Closed e2392299781658 ∧ code e2392299781658 = 11188392803866 := by decide
private def t_e2392299781658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299781658 : ¬ IsSelfInterpreter e2392299781658 :=
  wSource (t := t_e2392299781658) (replay_sound (ps := []) (t := e2392299781658) (by decide)) (by decide)
def e2392299788314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392299788314 : Closed e2392299788314 ∧ code e2392299788314 = 11188392810522 := by decide
theorem cert_e2392299788314 : check e2392299788314 [[],[.left]] .smaller = true := by decide
def e2392299789850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299789850 : Closed e2392299789850 ∧ code e2392299789850 = 11188392812058 := by decide
private def t_e2392299789850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299789850 : ¬ IsSelfInterpreter e2392299789850 :=
  wSource (t := t_e2392299789850) (replay_sound (ps := []) (t := e2392299789850) (by decide)) (by decide)
def e2392299793946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299793946 : Closed e2392299793946 ∧ code e2392299793946 = 11188392816154 := by decide
private def t_e2392299793946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299793946 : ¬ IsSelfInterpreter e2392299793946 :=
  wSource (t := t_e2392299793946) (replay_sound (ps := []) (t := e2392299793946) (by decide)) (by decide)
def e2392299795994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299795994 : Closed e2392299795994 ∧ code e2392299795994 = 11188392818202 := by decide
private def t_e2392299795994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299795994 : ¬ IsSelfInterpreter e2392299795994 :=
  wSource (t := t_e2392299795994) (replay_sound (ps := []) (t := e2392299795994) (by decide)) (by decide)
def e2392299845658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392299845658 : Closed e2392299845658 ∧ code e2392299845658 = 11188392867866 := by decide
theorem cert_e2392299845658 : check e2392299845658 [[],[.left]] .smaller = true := by decide
def e2392299847194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299847194 : Closed e2392299847194 ∧ code e2392299847194 = 11188392869402 := by decide
private def t_e2392299847194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299847194 : ¬ IsSelfInterpreter e2392299847194 :=
  wSource (t := t_e2392299847194) (replay_sound (ps := []) (t := e2392299847194) (by decide)) (by decide)
def e2392299857946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392299857946 : Closed e2392299857946 ∧ code e2392299857946 = 11188392880154 := by decide
theorem cert_e2392299857946 : check e2392299857946 [[],[.left]] .smaller = true := by decide
def e2392299862554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299862554 : Closed e2392299862554 ∧ code e2392299862554 = 11188392884762 := by decide
private def t_e2392299862554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299862554 : ¬ IsSelfInterpreter e2392299862554 :=
  wSource (t := t_e2392299862554) (replay_sound (ps := []) (t := e2392299862554) (by decide)) (by decide)
def e2392299886618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392299886618 : Closed e2392299886618 ∧ code e2392299886618 = 11188392908826 := by decide
theorem cert_e2392299886618 : check e2392299886618 [[],[.left]] .smaller = true := by decide
def e2392299888154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299888154 : Closed e2392299888154 ∧ code e2392299888154 = 11188392910362 := by decide
private def t_e2392299888154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299888154 : ¬ IsSelfInterpreter e2392299888154 :=
  wSource (t := t_e2392299888154) (replay_sound (ps := []) (t := e2392299888154) (by decide)) (by decide)
def e2392299890714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392299890714 : Closed e2392299890714 ∧ code e2392299890714 = 11188392912922 := by decide
theorem cert_e2392299890714 : check e2392299890714 [[],[.left]] .smaller = true := by decide
def e2392299895322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299895322 : Closed e2392299895322 ∧ code e2392299895322 = 11188392917530 := by decide
private def t_e2392299895322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299895322 : ¬ IsSelfInterpreter e2392299895322 :=
  wSource (t := t_e2392299895322) (replay_sound (ps := []) (t := e2392299895322) (by decide)) (by decide)
def e2392299908634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299908634 : Closed e2392299908634 ∧ code e2392299908634 = 11188392930842 := by decide
private def t_e2392299908634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299908634 : ¬ IsSelfInterpreter e2392299908634 :=
  wSource (t := t_e2392299908634) (replay_sound (ps := []) (t := e2392299908634) (by decide)) (by decide)
def e2392299911706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299911706 : Closed e2392299911706 ∧ code e2392299911706 = 11188392933914 := by decide
private def t_e2392299911706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299911706 : ¬ IsSelfInterpreter e2392299911706 :=
  wSource (t := t_e2392299911706) (replay_sound (ps := []) (t := e2392299911706) (by decide)) (by decide)
def e2392299918874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299918874 : Closed e2392299918874 ∧ code e2392299918874 = 11188392941082 := by decide
private def t_e2392299918874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299918874 : ¬ IsSelfInterpreter e2392299918874 :=
  wSource (t := t_e2392299918874) (replay_sound (ps := []) (t := e2392299918874) (by decide)) (by decide)
def e2392299919898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392299919898 : Closed e2392299919898 ∧ code e2392299919898 = 11188392942106 := by decide
private def t_e2392299919898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392299919898 : ¬ IsSelfInterpreter e2392299919898 :=
  wSource (t := t_e2392299919898) (replay_sound (ps := []) (t := e2392299919898) (by decide)) (by decide)
def e2392300173338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392300173338 : Closed e2392300173338 ∧ code e2392300173338 = 11188393195546 := by decide
theorem cert_e2392300173338 : check e2392300173338 [[],[.left]] .smaller = true := by decide
def e2392300174874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300174874 : Closed e2392300174874 ∧ code e2392300174874 = 11188393197082 := by decide
private def t_e2392300174874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300174874 : ¬ IsSelfInterpreter e2392300174874 :=
  wSource (t := t_e2392300174874) (replay_sound (ps := []) (t := e2392300174874) (by decide)) (by decide)
def e2392300181530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392300181530 : Closed e2392300181530 ∧ code e2392300181530 = 11188393203738 := by decide
theorem cert_e2392300181530 : check e2392300181530 [[],[.left]] .smaller = true := by decide
def e2392300183066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300183066 : Closed e2392300183066 ∧ code e2392300183066 = 11188393205274 := by decide
private def t_e2392300183066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300183066 : ¬ IsSelfInterpreter e2392300183066 :=
  wSource (t := t_e2392300183066) (replay_sound (ps := []) (t := e2392300183066) (by decide)) (by decide)
def e2392300187162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300187162 : Closed e2392300187162 ∧ code e2392300187162 = 11188393209370 := by decide
private def t_e2392300187162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300187162 : ¬ IsSelfInterpreter e2392300187162 :=
  wSource (t := t_e2392300187162) (replay_sound (ps := []) (t := e2392300187162) (by decide)) (by decide)
def e2392300189210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300189210 : Closed e2392300189210 ∧ code e2392300189210 = 11188393211418 := by decide
private def t_e2392300189210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300189210 : ¬ IsSelfInterpreter e2392300189210 :=
  wSource (t := t_e2392300189210) (replay_sound (ps := []) (t := e2392300189210) (by decide)) (by decide)
def e2392300566554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392300566554 : Closed e2392300566554 ∧ code e2392300566554 = 11188393588762 := by decide
theorem cert_e2392300566554 : check e2392300566554 [[],[.left]] .smaller = true := by decide
def e2392300568090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300568090 : Closed e2392300568090 ∧ code e2392300568090 = 11188393590298 := by decide
private def t_e2392300568090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300568090 : ¬ IsSelfInterpreter e2392300568090 :=
  wSource (t := t_e2392300568090) (replay_sound (ps := []) (t := e2392300568090) (by decide)) (by decide)
def e2392300578842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392300578842 : Closed e2392300578842 ∧ code e2392300578842 = 11188393601050 := by decide
theorem cert_e2392300578842 : check e2392300578842 [[],[.left]] .smaller = true := by decide
def e2392300583450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300583450 : Closed e2392300583450 ∧ code e2392300583450 = 11188393605658 := by decide
private def t_e2392300583450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300583450 : ¬ IsSelfInterpreter e2392300583450 :=
  wSource (t := t_e2392300583450) (replay_sound (ps := []) (t := e2392300583450) (by decide)) (by decide)
def e2392300771354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392300771354 : Closed e2392300771354 ∧ code e2392300771354 = 11188393793562 := by decide
theorem cert_e2392300771354 : check e2392300771354 [[],[.left]] .smaller = true := by decide
def e2392300772890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300772890 : Closed e2392300772890 ∧ code e2392300772890 = 11188393795098 := by decide
private def t_e2392300772890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300772890 : ¬ IsSelfInterpreter e2392300772890 :=
  wSource (t := t_e2392300772890) (replay_sound (ps := []) (t := e2392300772890) (by decide)) (by decide)
def e2392300775450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392300775450 : Closed e2392300775450 ∧ code e2392300775450 = 11188393797658 := by decide
theorem cert_e2392300775450 : check e2392300775450 [[],[.left]] .smaller = true := by decide
def e2392300780058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300780058 : Closed e2392300780058 ∧ code e2392300780058 = 11188393802266 := by decide
private def t_e2392300780058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300780058 : ¬ IsSelfInterpreter e2392300780058 :=
  wSource (t := t_e2392300780058) (replay_sound (ps := []) (t := e2392300780058) (by decide)) (by decide)
def e2392300875290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300875290 : Closed e2392300875290 ∧ code e2392300875290 = 11188393897498 := by decide
private def t_e2392300875290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300875290 : ¬ IsSelfInterpreter e2392300875290 :=
  wSource (t := t_e2392300875290) (replay_sound (ps := []) (t := e2392300875290) (by decide)) (by decide)
def e2392300878362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300878362 : Closed e2392300878362 ∧ code e2392300878362 = 11188393900570 := by decide
private def t_e2392300878362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300878362 : ¬ IsSelfInterpreter e2392300878362 :=
  wSource (t := t_e2392300878362) (replay_sound (ps := []) (t := e2392300878362) (by decide)) (by decide)
def e2392300926490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300926490 : Closed e2392300926490 ∧ code e2392300926490 = 11188393948698 := by decide
private def t_e2392300926490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300926490 : ¬ IsSelfInterpreter e2392300926490 :=
  wSource (t := t_e2392300926490) (replay_sound (ps := []) (t := e2392300926490) (by decide)) (by decide)
def e2392300927514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392300927514 : Closed e2392300927514 ∧ code e2392300927514 = 11188393949722 := by decide
private def t_e2392300927514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392300927514 : ¬ IsSelfInterpreter e2392300927514 :=
  wSource (t := t_e2392300927514) (replay_sound (ps := []) (t := e2392300927514) (by decide)) (by decide)
def e2392308149786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308149786 : Closed e2392308149786 ∧ code e2392308149786 = 11188401171994 := by decide
private def t_e2392308149786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308149786 : ¬ IsSelfInterpreter e2392308149786 :=
  wSource (t := t_e2392308149786) (replay_sound (ps := []) (t := e2392308149786) (by decide)) (by decide)
def e2392308151834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308151834 : Closed e2392308151834 ∧ code e2392308151834 = 11188401174042 := by decide
private def t_e2392308151834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308151834 : ¬ IsSelfInterpreter e2392308151834 :=
  wSource (t := t_e2392308151834) (replay_sound (ps := []) (t := e2392308151834) (by decide)) (by decide)
def e2392308166170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308166170 : Closed e2392308166170 ∧ code e2392308166170 = 11188401188378 := by decide
private def t_e2392308166170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308166170 : ¬ IsSelfInterpreter e2392308166170 :=
  wSource (t := t_e2392308166170) (replay_sound (ps := []) (t := e2392308166170) (by decide)) (by decide)
def e2392308169242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308169242 : Closed e2392308169242 ∧ code e2392308169242 = 11188401191450 := by decide
private def t_e2392308169242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308169242 : ¬ IsSelfInterpreter e2392308169242 :=
  wSource (t := t_e2392308169242) (replay_sound (ps := []) (t := e2392308169242) (by decide)) (by decide)
def e2392308176410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308176410 : Closed e2392308176410 ∧ code e2392308176410 = 11188401198618 := by decide
private def t_e2392308176410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308176410 : ¬ IsSelfInterpreter e2392308176410 :=
  wSource (t := t_e2392308176410) (replay_sound (ps := []) (t := e2392308176410) (by decide)) (by decide)
def e2392308177434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308177434 : Closed e2392308177434 ∧ code e2392308177434 = 11188401199642 := by decide
private def t_e2392308177434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308177434 : ¬ IsSelfInterpreter e2392308177434 :=
  wSource (t := t_e2392308177434) (replay_sound (ps := []) (t := e2392308177434) (by decide)) (by decide)
def e2392308231706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308231706 : Closed e2392308231706 ∧ code e2392308231706 = 11188401253914 := by decide
private def t_e2392308231706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308231706 : ¬ IsSelfInterpreter e2392308231706 :=
  wSource (t := t_e2392308231706) (replay_sound (ps := []) (t := e2392308231706) (by decide)) (by decide)
def e2392308234778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308234778 : Closed e2392308234778 ∧ code e2392308234778 = 11188401256986 := by decide
private def t_e2392308234778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308234778 : ¬ IsSelfInterpreter e2392308234778 :=
  wSource (t := t_e2392308234778) (replay_sound (ps := []) (t := e2392308234778) (by decide)) (by decide)
def e2392308247066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308247066 : Closed e2392308247066 ∧ code e2392308247066 = 11188401269274 := by decide
private def t_e2392308247066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308247066 : ¬ IsSelfInterpreter e2392308247066 :=
  wSource (t := t_e2392308247066) (replay_sound (ps := []) (t := e2392308247066) (by decide)) (by decide)
def e2392308274714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308274714 : Closed e2392308274714 ∧ code e2392308274714 = 11188401296922 := by decide
private def t_e2392308274714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308274714 : ¬ IsSelfInterpreter e2392308274714 :=
  wSource (t := t_e2392308274714) (replay_sound (ps := []) (t := e2392308274714) (by decide)) (by decide)
def e2392308275738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308275738 : Closed e2392308275738 ∧ code e2392308275738 = 11188401297946 := by decide
private def t_e2392308275738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308275738 : ¬ IsSelfInterpreter e2392308275738 :=
  wSource (t := t_e2392308275738) (replay_sound (ps := []) (t := e2392308275738) (by decide)) (by decide)
def e2392308279834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308279834 : Closed e2392308279834 ∧ code e2392308279834 = 11188401302042 := by decide
private def t_e2392308279834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308279834 : ¬ IsSelfInterpreter e2392308279834 :=
  wSource (t := t_e2392308279834) (replay_sound (ps := []) (t := e2392308279834) (by decide)) (by decide)
def e2392308440602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308440602 : Closed e2392308440602 ∧ code e2392308440602 = 11188401462810 := by decide
private def t_e2392308440602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308440602 : ¬ IsSelfInterpreter e2392308440602 :=
  wSource (t := t_e2392308440602) (replay_sound (ps := []) (t := e2392308440602) (by decide)) (by decide)
def e2392308446746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308446746 : Closed e2392308446746 ∧ code e2392308446746 = 11188401468954 := by decide
private def t_e2392308446746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308446746 : ¬ IsSelfInterpreter e2392308446746 :=
  wSource (t := t_e2392308446746) (replay_sound (ps := []) (t := e2392308446746) (by decide)) (by decide)
def e2392308543002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308543002 : Closed e2392308543002 ∧ code e2392308543002 = 11188401565210 := by decide
private def t_e2392308543002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308543002 : ¬ IsSelfInterpreter e2392308543002 :=
  wSource (t := t_e2392308543002) (replay_sound (ps := []) (t := e2392308543002) (by decide)) (by decide)
def e2392308545050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308545050 : Closed e2392308545050 ∧ code e2392308545050 = 11188401567258 := by decide
private def t_e2392308545050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308545050 : ¬ IsSelfInterpreter e2392308545050 :=
  wSource (t := t_e2392308545050) (replay_sound (ps := []) (t := e2392308545050) (by decide)) (by decide)
def e2392308559386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308559386 : Closed e2392308559386 ∧ code e2392308559386 = 11188401581594 := by decide
private def t_e2392308559386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308559386 : ¬ IsSelfInterpreter e2392308559386 :=
  wSource (t := t_e2392308559386) (replay_sound (ps := []) (t := e2392308559386) (by decide)) (by decide)
def e2392308562458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308562458 : Closed e2392308562458 ∧ code e2392308562458 = 11188401584666 := by decide
private def t_e2392308562458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308562458 : ¬ IsSelfInterpreter e2392308562458 :=
  wSource (t := t_e2392308562458) (replay_sound (ps := []) (t := e2392308562458) (by decide)) (by decide)
def e2392308569626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308569626 : Closed e2392308569626 ∧ code e2392308569626 = 11188401591834 := by decide
private def t_e2392308569626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308569626 : ¬ IsSelfInterpreter e2392308569626 :=
  wSource (t := t_e2392308569626) (replay_sound (ps := []) (t := e2392308569626) (by decide)) (by decide)
def e2392308570650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308570650 : Closed e2392308570650 ∧ code e2392308570650 = 11188401592858 := by decide
private def t_e2392308570650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308570650 : ¬ IsSelfInterpreter e2392308570650 :=
  wSource (t := t_e2392308570650) (replay_sound (ps := []) (t := e2392308570650) (by decide)) (by decide)
def e2392308641306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308641306 : Closed e2392308641306 ∧ code e2392308641306 = 11188401663514 := by decide
private def t_e2392308641306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308641306 : ¬ IsSelfInterpreter e2392308641306 :=
  wSource (t := t_e2392308641306) (replay_sound (ps := []) (t := e2392308641306) (by decide)) (by decide)
def e2392308643354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392308643354 : Closed e2392308643354 ∧ code e2392308643354 = 11188401665562 := by decide
private def t_e2392308643354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392308643354 : ¬ IsSelfInterpreter e2392308643354 :=
  wSource (t := t_e2392308643354) (replay_sound (ps := []) (t := e2392308643354) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2391558766038
#print axioms Blc.Floor43.cert_e2391558766042
#print axioms Blc.Floor43.cert_e2391558780726
#print axioms Blc.Floor43.cert_e2391558780730
#print axioms Blc.Floor43.cert_e2392297532954
#print axioms Blc.Floor43.cert_e2392297535002
#print axioms Blc.Floor43.cert_e2392297549338
#print axioms Blc.Floor43.cert_e2392297552410
#print axioms Blc.Floor43.cert_e2392297559578
#print axioms Blc.Floor43.cert_e2392297560602
#print axioms Blc.Floor43.cert_e2392297631258
#print axioms Blc.Floor43.cert_e2392297633306
#print axioms Blc.Floor43.cert_e2392297729562
#print axioms Blc.Floor43.cert_e2392297732634
#print axioms Blc.Floor43.cert_e2392297780762
#print axioms Blc.Floor43.cert_e2392297781786
#print axioms Blc.Floor43.cert_e2392299781658
#print axioms Blc.Floor43.cert_e2392299789850
#print axioms Blc.Floor43.cert_e2392299793946
#print axioms Blc.Floor43.cert_e2392299795994
#print axioms Blc.Floor43.cert_e2392299847194
#print axioms Blc.Floor43.cert_e2392299862554
#print axioms Blc.Floor43.cert_e2392299888154
#print axioms Blc.Floor43.cert_e2392299895322
#print axioms Blc.Floor43.cert_e2392299908634
#print axioms Blc.Floor43.cert_e2392299911706
#print axioms Blc.Floor43.cert_e2392299918874
#print axioms Blc.Floor43.cert_e2392299919898
#print axioms Blc.Floor43.cert_e2392300174874
#print axioms Blc.Floor43.cert_e2392300183066
#print axioms Blc.Floor43.cert_e2392300187162
#print axioms Blc.Floor43.cert_e2392300189210
#print axioms Blc.Floor43.cert_e2392300568090
#print axioms Blc.Floor43.cert_e2392300583450
#print axioms Blc.Floor43.cert_e2392300772890
#print axioms Blc.Floor43.cert_e2392300780058
#print axioms Blc.Floor43.cert_e2392300875290
#print axioms Blc.Floor43.cert_e2392300878362
#print axioms Blc.Floor43.cert_e2392300926490
#print axioms Blc.Floor43.cert_e2392300927514
#print axioms Blc.Floor43.cert_e2392308149786
#print axioms Blc.Floor43.cert_e2392308151834
#print axioms Blc.Floor43.cert_e2392308166170
#print axioms Blc.Floor43.cert_e2392308169242
#print axioms Blc.Floor43.cert_e2392308176410
#print axioms Blc.Floor43.cert_e2392308177434
#print axioms Blc.Floor43.cert_e2392308231706
#print axioms Blc.Floor43.cert_e2392308234778
#print axioms Blc.Floor43.cert_e2392308247066
#print axioms Blc.Floor43.cert_e2392308274714
#print axioms Blc.Floor43.cert_e2392308275738
#print axioms Blc.Floor43.cert_e2392308279834
#print axioms Blc.Floor43.cert_e2392308440602
#print axioms Blc.Floor43.cert_e2392308446746
#print axioms Blc.Floor43.cert_e2392308543002
#print axioms Blc.Floor43.cert_e2392308545050
#print axioms Blc.Floor43.cert_e2392308559386
#print axioms Blc.Floor43.cert_e2392308562458
#print axioms Blc.Floor43.cert_e2392308569626
#print axioms Blc.Floor43.cert_e2392308570650
#print axioms Blc.Floor43.cert_e2392308641306
#print axioms Blc.Floor43.cert_e2392308643354
