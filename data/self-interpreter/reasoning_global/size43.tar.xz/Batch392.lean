import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372785562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372785562 : Closed e2422372785562 ∧ code e2422372785562 = 11218465807770 := by decide
theorem cert_e2422372785562 : check e2422372785562 [[],[]] .smaller = true := by decide
def e2422372785630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.var 3)))))))
theorem wire_e2422372785630 : Closed e2422372785630 ∧ code e2422372785630 = 11218465807838 := by decide
theorem cert_e2422372785630 : check e2422372785630 [[],[]] .three = true := by decide
def e2422372785634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372785634 : Closed e2422372785634 ∧ code e2422372785634 = 11218465807842 := by decide
theorem cert_e2422372785634 : check e2422372785634 [[],[]] .three = true := by decide
def e2422372785646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)) (.var 2)))))))
theorem wire_e2422372785646 : Closed e2422372785646 ∧ code e2422372785646 = 11218465807854 := by decide
theorem cert_e2422372785646 : check e2422372785646 [[],[]] .three = true := by decide
def e2422372785710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372785710 : Closed e2422372785710 ∧ code e2422372785710 = 11218465807918 := by decide
theorem cert_e2422372785710 : check e2422372785710 [[],[]] .three = true := by decide
def e2422372785718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372785718 : Closed e2422372785718 ∧ code e2422372785718 = 11218465807926 := by decide
theorem cert_e2422372785718 : check e2422372785718 [[],[]] .three = true := by decide
def e2422372785722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372785722 : Closed e2422372785722 ∧ code e2422372785722 = 11218465807930 := by decide
theorem cert_e2422372785722 : check e2422372785722 [[],[]] .three = true := by decide
def e2422372785806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372785806 : Closed e2422372785806 ∧ code e2422372785806 = 11218465808014 := by decide
theorem cert_e2422372785806 : check e2422372785806 [[],[]] .three = true := by decide
def e2422372785862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372785862 : Closed e2422372785862 ∧ code e2422372785862 = 11218465808070 := by decide
theorem cert_e2422372785862 : check e2422372785862 [[],[]] .three = true := by decide
def e2422372785886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)) (.var 3)))))))
theorem wire_e2422372785886 : Closed e2422372785886 ∧ code e2422372785886 = 11218465808094 := by decide
theorem cert_e2422372785886 : check e2422372785886 [[],[]] .three = true := by decide
def e2422372785890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372785890 : Closed e2422372785890 ∧ code e2422372785890 = 11218465808098 := by decide
theorem cert_e2422372785890 : check e2422372785890 [[],[]] .three = true := by decide
def e2422372785902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)) (.var 2)))))))
theorem wire_e2422372785902 : Closed e2422372785902 ∧ code e2422372785902 = 11218465808110 := by decide
theorem cert_e2422372785902 : check e2422372785902 [[],[]] .three = true := by decide
def e2422372785910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 3)) (.var 1)))))))
theorem wire_e2422372785910 : Closed e2422372785910 ∧ code e2422372785910 = 11218465808118 := by decide
theorem cert_e2422372785910 : check e2422372785910 [[],[]] .three = true := by decide
def e2422372786350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372786350 : Closed e2422372786350 ∧ code e2422372786350 = 11218465808558 := by decide
theorem cert_e2422372786350 : check e2422372786350 [[],[]] .smaller = true := by decide
def e2422372786362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372786362 : Closed e2422372786362 ∧ code e2422372786362 = 11218465808570 := by decide
theorem cert_e2422372786362 : check e2422372786362 [[],[]] .smaller = true := by decide
def e2422372786910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 3)))))))
theorem wire_e2422372786910 : Closed e2422372786910 ∧ code e2422372786910 = 11218465809118 := by decide
theorem cert_e2422372786910 : check e2422372786910 [[],[]] .three = true := by decide
def e2422372786926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 2)))))))
theorem wire_e2422372786926 : Closed e2422372786926 ∧ code e2422372786926 = 11218465809134 := by decide
theorem cert_e2422372786926 : check e2422372786926 [[],[]] .smaller = true := by decide
def e2422372786934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 3)) (.var 1)))))))
theorem wire_e2422372786934 : Closed e2422372786934 ∧ code e2422372786934 = 11218465809142 := by decide
theorem cert_e2422372786934 : check e2422372786934 [[],[]] .three = true := by decide
def e2422372787038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 3)))))))
theorem wire_e2422372787038 : Closed e2422372787038 ∧ code e2422372787038 = 11218465809246 := by decide
theorem cert_e2422372787038 : check e2422372787038 [[],[]] .three = true := by decide
def e2422372787054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e2422372787054 : Closed e2422372787054 ∧ code e2422372787054 = 11218465809262 := by decide
theorem cert_e2422372787054 : check e2422372787054 [[],[]] .smaller = true := by decide
def e2422372787062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e2422372787062 : Closed e2422372787062 ∧ code e2422372787062 = 11218465809270 := by decide
theorem cert_e2422372787062 : check e2422372787062 [[],[]] .smaller = true := by decide
def e2422372787066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)) (.var 0)))))))
theorem wire_e2422372787066 : Closed e2422372787066 ∧ code e2422372787066 = 11218465809274 := by decide
theorem cert_e2422372787066 : check e2422372787066 [[],[]] .three = true := by decide
def e2422372787118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e2422372787118 : Closed e2422372787118 ∧ code e2422372787118 = 11218465809326 := by decide
theorem cert_e2422372787118 : check e2422372787118 [[],[]] .smaller = true := by decide
def e2422372787130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e2422372787130 : Closed e2422372787130 ∧ code e2422372787130 = 11218465809338 := by decide
theorem cert_e2422372787130 : check e2422372787130 [[],[]] .smaller = true := by decide
def e2422372787158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e2422372787158 : Closed e2422372787158 ∧ code e2422372787158 = 11218465809366 := by decide
theorem cert_e2422372787158 : check e2422372787158 [[],[]] .smaller = true := by decide
def e2422372787162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e2422372787162 : Closed e2422372787162 ∧ code e2422372787162 = 11218465809370 := by decide
theorem cert_e2422372787162 : check e2422372787162 [[],[]] .smaller = true := by decide
def e2422372787178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0)) (.var 0)))))))
theorem wire_e2422372787178 : Closed e2422372787178 ∧ code e2422372787178 = 11218465809386 := by decide
theorem cert_e2422372787178 : check e2422372787178 [[],[]] .three = true := by decide
def e2422372787886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372787886 : Closed e2422372787886 ∧ code e2422372787886 = 11218465810094 := by decide
theorem cert_e2422372787886 : check e2422372787886 [[],[]] .smaller = true := by decide
def e2422372787898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372787898 : Closed e2422372787898 ∧ code e2422372787898 = 11218465810106 := by decide
theorem cert_e2422372787898 : check e2422372787898 [[],[]] .smaller = true := by decide
def e2422372787946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372787946 : Closed e2422372787946 ∧ code e2422372787946 = 11218465810154 := by decide
theorem cert_e2422372787946 : check e2422372787946 [[],[]] .smaller = true := by decide
def e2422372788138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372788138 : Closed e2422372788138 ∧ code e2422372788138 = 11218465810346 := by decide
theorem cert_e2422372788138 : check e2422372788138 [[],[]] .smaller = true := by decide
def e2422372788270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372788270 : Closed e2422372788270 ∧ code e2422372788270 = 11218465810478 := by decide
theorem cert_e2422372788270 : check e2422372788270 [[],[]] .smaller = true := by decide
def e2422372788446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372788446 : Closed e2422372788446 ∧ code e2422372788446 = 11218465810654 := by decide
theorem cert_e2422372788446 : check e2422372788446 [[],[]] .three = true := by decide
def e2422372788462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422372788462 : Closed e2422372788462 ∧ code e2422372788462 = 11218465810670 := by decide
theorem cert_e2422372788462 : check e2422372788462 [[],[]] .smaller = true := by decide
def e2422372788470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422372788470 : Closed e2422372788470 ∧ code e2422372788470 = 11218465810678 := by decide
theorem cert_e2422372788470 : check e2422372788470 [[],[]] .smaller = true := by decide
def e2422372788474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372788474 : Closed e2422372788474 ∧ code e2422372788474 = 11218465810682 := by decide
theorem cert_e2422372788474 : check e2422372788474 [[],[]] .three = true := by decide
def e2422372788654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372788654 : Closed e2422372788654 ∧ code e2422372788654 = 11218465810862 := by decide
theorem cert_e2422372788654 : check e2422372788654 [[],[]] .smaller = true := by decide
def e2422372788666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372788666 : Closed e2422372788666 ∧ code e2422372788666 = 11218465810874 := by decide
theorem cert_e2422372788666 : check e2422372788666 [[],[]] .smaller = true := by decide
def e2422372788714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372788714 : Closed e2422372788714 ∧ code e2422372788714 = 11218465810922 := by decide
theorem cert_e2422372788714 : check e2422372788714 [[],[]] .smaller = true := by decide
def e2422372788798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372788798 : Closed e2422372788798 ∧ code e2422372788798 = 11218465811006 := by decide
theorem cert_e2422372788798 : check e2422372788798 [[],[]] .three = true := by decide
def e2422372788846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372788846 : Closed e2422372788846 ∧ code e2422372788846 = 11218465811054 := by decide
theorem cert_e2422372788846 : check e2422372788846 [[],[]] .smaller = true := by decide
def e2422372788858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372788858 : Closed e2422372788858 ∧ code e2422372788858 = 11218465811066 := by decide
theorem cert_e2422372788858 : check e2422372788858 [[],[]] .smaller = true := by decide
def e2422372789022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422372789022 : Closed e2422372789022 ∧ code e2422372789022 = 11218465811230 := by decide
theorem cert_e2422372789022 : check e2422372789022 [[],[]] .smaller = true := by decide
def e2422372789122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372789122 : Closed e2422372789122 ∧ code e2422372789122 = 11218465811330 := by decide
theorem cert_e2422372789122 : check e2422372789122 [[],[]] .smaller = true := by decide
def e2422372789134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422372789134 : Closed e2422372789134 ∧ code e2422372789134 = 11218465811342 := by decide
theorem cert_e2422372789134 : check e2422372789134 [[],[]] .smaller = true := by decide
def e2422372789146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372789146 : Closed e2422372789146 ∧ code e2422372789146 = 11218465811354 := by decide
theorem cert_e2422372789146 : check e2422372789146 [[],[]] .smaller = true := by decide
def e2422372789190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372789190 : Closed e2422372789190 ∧ code e2422372789190 = 11218465811398 := by decide
theorem cert_e2422372789190 : check e2422372789190 [[],[]] .three = true := by decide
def e2422372789214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)) (.var 3)))))))
theorem wire_e2422372789214 : Closed e2422372789214 ∧ code e2422372789214 = 11218465811422 := by decide
theorem cert_e2422372789214 : check e2422372789214 [[],[]] .three = true := by decide
def e2422372789342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372789342 : Closed e2422372789342 ∧ code e2422372789342 = 11218465811550 := by decide
theorem cert_e2422372789342 : check e2422372789342 [[],[]] .three = true := by decide
def e2422372789358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372789358 : Closed e2422372789358 ∧ code e2422372789358 = 11218465811566 := by decide
theorem cert_e2422372789358 : check e2422372789358 [[],[]] .smaller = true := by decide
def e2422372789370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372789370 : Closed e2422372789370 ∧ code e2422372789370 = 11218465811578 := by decide
theorem cert_e2422372789370 : check e2422372789370 [[],[]] .smaller = true := by decide
def e2422372789534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372789534 : Closed e2422372789534 ∧ code e2422372789534 = 11218465811742 := by decide
theorem cert_e2422372789534 : check e2422372789534 [[],[]] .smaller = true := by decide
def e2422372789702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372789702 : Closed e2422372789702 ∧ code e2422372789702 = 11218465811910 := by decide
theorem cert_e2422372789702 : check e2422372789702 [[],[]] .smaller = true := by decide
def e2422372789726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 3)))))))
theorem wire_e2422372789726 : Closed e2422372789726 ∧ code e2422372789726 = 11218465811934 := by decide
theorem cert_e2422372789726 : check e2422372789726 [[],[]] .three = true := by decide
def e2422372789730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372789730 : Closed e2422372789730 ∧ code e2422372789730 = 11218465811938 := by decide
theorem cert_e2422372789730 : check e2422372789730 [[],[]] .three = true := by decide
def e2422372789742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)) (.var 2)))))))
theorem wire_e2422372789742 : Closed e2422372789742 ∧ code e2422372789742 = 11218465811950 := by decide
theorem cert_e2422372789742 : check e2422372789742 [[],[]] .three = true := by decide
def e2422372789770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372789770 : Closed e2422372789770 ∧ code e2422372789770 = 11218465811978 := by decide
theorem cert_e2422372789770 : check e2422372789770 [[],[]] .smaller = true := by decide
def e2422372789806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372789806 : Closed e2422372789806 ∧ code e2422372789806 = 11218465812014 := by decide
theorem cert_e2422372789806 : check e2422372789806 [[],[]] .smaller = true := by decide
def e2422372789814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372789814 : Closed e2422372789814 ∧ code e2422372789814 = 11218465812022 := by decide
theorem cert_e2422372789814 : check e2422372789814 [[],[]] .smaller = true := by decide
def e2422372789818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372789818 : Closed e2422372789818 ∧ code e2422372789818 = 11218465812026 := by decide
theorem cert_e2422372789818 : check e2422372789818 [[],[]] .smaller = true := by decide
def e2422372789866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372789866 : Closed e2422372789866 ∧ code e2422372789866 = 11218465812074 := by decide
theorem cert_e2422372789866 : check e2422372789866 [[],[]] .smaller = true := by decide
def e2422372789890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372789890 : Closed e2422372789890 ∧ code e2422372789890 = 11218465812098 := by decide
theorem cert_e2422372789890 : check e2422372789890 [[],[]] .smaller = true := by decide
def e2422372789902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372789902 : Closed e2422372789902 ∧ code e2422372789902 = 11218465812110 := by decide
theorem cert_e2422372789902 : check e2422372789902 [[],[]] .smaller = true := by decide
def e2422372789914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372789914 : Closed e2422372789914 ∧ code e2422372789914 = 11218465812122 := by decide
theorem cert_e2422372789914 : check e2422372789914 [[],[]] .smaller = true := by decide
def e2422372789958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372789958 : Closed e2422372789958 ∧ code e2422372789958 = 11218465812166 := by decide
theorem cert_e2422372789958 : check e2422372789958 [[],[]] .smaller = true := by decide
def e2422372789982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 3)))))))
theorem wire_e2422372789982 : Closed e2422372789982 ∧ code e2422372789982 = 11218465812190 := by decide
theorem cert_e2422372789982 : check e2422372789982 [[],[]] .three = true := by decide
def e2422372789986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372789986 : Closed e2422372789986 ∧ code e2422372789986 = 11218465812194 := by decide
theorem cert_e2422372789986 : check e2422372789986 [[],[]] .smaller = true := by decide
def e2422372789998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 2)))))))
theorem wire_e2422372789998 : Closed e2422372789998 ∧ code e2422372789998 = 11218465812206 := by decide
theorem cert_e2422372789998 : check e2422372789998 [[],[]] .smaller = true := by decide
def e2422372790006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 3)) (.var 1)))))))
theorem wire_e2422372790006 : Closed e2422372790006 ∧ code e2422372790006 = 11218465812214 := by decide
theorem cert_e2422372790006 : check e2422372790006 [[],[]] .three = true := by decide
def e2422372790038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372790038 : Closed e2422372790038 ∧ code e2422372790038 = 11218465812246 := by decide
theorem cert_e2422372790038 : check e2422372790038 [[],[]] .three = true := by decide
def e2422372790042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372790042 : Closed e2422372790042 ∧ code e2422372790042 = 11218465812250 := by decide
theorem cert_e2422372790042 : check e2422372790042 [[],[]] .three = true := by decide
def e2422372790086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372790086 : Closed e2422372790086 ∧ code e2422372790086 = 11218465812294 := by decide
theorem cert_e2422372790086 : check e2422372790086 [[],[]] .three = true := by decide
def e2422372790110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)) (.var 3)))))))
theorem wire_e2422372790110 : Closed e2422372790110 ∧ code e2422372790110 = 11218465812318 := by decide
theorem cert_e2422372790110 : check e2422372790110 [[],[]] .three = true := by decide
def e2422372790114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372790114 : Closed e2422372790114 ∧ code e2422372790114 = 11218465812322 := by decide
theorem cert_e2422372790114 : check e2422372790114 [[],[]] .three = true := by decide
def e2422372790126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)) (.var 2)))))))
theorem wire_e2422372790126 : Closed e2422372790126 ∧ code e2422372790126 = 11218465812334 := by decide
theorem cert_e2422372790126 : check e2422372790126 [[],[]] .three = true := by decide
def e2422372790134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 2)) (.var 1)))))))
theorem wire_e2422372790134 : Closed e2422372790134 ∧ code e2422372790134 = 11218465812342 := by decide
theorem cert_e2422372790134 : check e2422372790134 [[],[]] .three = true := by decide
def e2422372790138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3)) (.var 0)))))))
theorem wire_e2422372790138 : Closed e2422372790138 ∧ code e2422372790138 = 11218465812346 := by decide
theorem cert_e2422372790138 : check e2422372790138 [[],[]] .three = true := by decide
def e2422372790358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372790358 : Closed e2422372790358 ∧ code e2422372790358 = 11218465812566 := by decide
theorem cert_e2422372790358 : check e2422372790358 [[],[]] .smaller = true := by decide
def e2422372790362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372790362 : Closed e2422372790362 ∧ code e2422372790362 = 11218465812570 := by decide
theorem cert_e2422372790362 : check e2422372790362 [[],[]] .smaller = true := by decide
def e2422372790622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 3)))))))
theorem wire_e2422372790622 : Closed e2422372790622 ∧ code e2422372790622 = 11218465812830 := by decide
theorem cert_e2422372790622 : check e2422372790622 [[],[]] .three = true := by decide
def e2422372790638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2422372790638 : Closed e2422372790638 ∧ code e2422372790638 = 11218465812846 := by decide
theorem cert_e2422372790638 : check e2422372790638 [[],[]] .smaller = true := by decide
def e2422372790646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2422372790646 : Closed e2422372790646 ∧ code e2422372790646 = 11218465812854 := by decide
theorem cert_e2422372790646 : check e2422372790646 [[],[]] .smaller = true := by decide
def e2422372790650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 3)) (.var 0)))))))
theorem wire_e2422372790650 : Closed e2422372790650 ∧ code e2422372790650 = 11218465812858 := by decide
theorem cert_e2422372790650 : check e2422372790650 [[],[]] .three = true := by decide
def e2422372790710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e2422372790710 : Closed e2422372790710 ∧ code e2422372790710 = 11218465812918 := by decide
theorem cert_e2422372790710 : check e2422372790710 [[],[]] .smaller = true := by decide
def e2422372790742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2422372790742 : Closed e2422372790742 ∧ code e2422372790742 = 11218465812950 := by decide
theorem cert_e2422372790742 : check e2422372790742 [[],[]] .smaller = true := by decide
def e2422372790746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2422372790746 : Closed e2422372790746 ∧ code e2422372790746 = 11218465812954 := by decide
theorem cert_e2422372790746 : check e2422372790746 [[],[]] .smaller = true := by decide
def e2422372791126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372791126 : Closed e2422372791126 ∧ code e2422372791126 = 11218465813334 := by decide
theorem cert_e2422372791126 : check e2422372791126 [[],[]] .smaller = true := by decide
def e2422372791130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372791130 : Closed e2422372791130 ∧ code e2422372791130 = 11218465813338 := by decide
theorem cert_e2422372791130 : check e2422372791130 [[],[]] .smaller = true := by decide
def e2422372791146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422372791146 : Closed e2422372791146 ∧ code e2422372791146 = 11218465813354 := by decide
theorem cert_e2422372791146 : check e2422372791146 [[],[]] .smaller = true := by decide
def e2422372791210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372791210 : Closed e2422372791210 ∧ code e2422372791210 = 11218465813418 := by decide
theorem cert_e2422372791210 : check e2422372791210 [[],[]] .smaller = true := by decide
def e2422372791318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372791318 : Closed e2422372791318 ∧ code e2422372791318 = 11218465813526 := by decide
theorem cert_e2422372791318 : check e2422372791318 [[],[]] .smaller = true := by decide
def e2422372791390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372791390 : Closed e2422372791390 ∧ code e2422372791390 = 11218465813598 := by decide
theorem cert_e2422372791390 : check e2422372791390 [[],[]] .three = true := by decide
def e2422372791414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422372791414 : Closed e2422372791414 ∧ code e2422372791414 = 11218465813622 := by decide
theorem cert_e2422372791414 : check e2422372791414 [[],[]] .smaller = true := by decide
def e2422372791510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422372791510 : Closed e2422372791510 ∧ code e2422372791510 = 11218465813718 := by decide
theorem cert_e2422372791510 : check e2422372791510 [[],[]] .smaller = true := by decide
def e2422372791514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422372791514 : Closed e2422372791514 ∧ code e2422372791514 = 11218465813722 := by decide
theorem cert_e2422372791514 : check e2422372791514 [[],[]] .smaller = true := by decide
def e2422372791530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422372791530 : Closed e2422372791530 ∧ code e2422372791530 = 11218465813738 := by decide
theorem cert_e2422372791530 : check e2422372791530 [[],[]] .smaller = true := by decide
def e2422372791606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372791606 : Closed e2422372791606 ∧ code e2422372791606 = 11218465813814 := by decide
theorem cert_e2422372791606 : check e2422372791606 [[],[]] .smaller = true := by decide
def e2422372791610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372791610 : Closed e2422372791610 ∧ code e2422372791610 = 11218465813818 := by decide
theorem cert_e2422372791610 : check e2422372791610 [[],[]] .smaller = true := by decide
def e2422372791682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372791682 : Closed e2422372791682 ∧ code e2422372791682 = 11218465813890 := by decide
theorem cert_e2422372791682 : check e2422372791682 [[],[]] .smaller = true := by decide
def e2422372791694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422372791694 : Closed e2422372791694 ∧ code e2422372791694 = 11218465813902 := by decide
theorem cert_e2422372791694 : check e2422372791694 [[],[]] .smaller = true := by decide
def e2422372791706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372791706 : Closed e2422372791706 ∧ code e2422372791706 = 11218465813914 := by decide
theorem cert_e2422372791706 : check e2422372791706 [[],[]] .smaller = true := by decide
def e2422372791774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 3)))))))
theorem wire_e2422372791774 : Closed e2422372791774 ∧ code e2422372791774 = 11218465813982 := by decide
theorem cert_e2422372791774 : check e2422372791774 [[],[]] .three = true := by decide
def e2422372791778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372791778 : Closed e2422372791778 ∧ code e2422372791778 = 11218465813986 := by decide
theorem cert_e2422372791778 : check e2422372791778 [[],[]] .three = true := by decide
def e2422372791790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)) (.var 2)))))))
theorem wire_e2422372791790 : Closed e2422372791790 ∧ code e2422372791790 = 11218465813998 := by decide
theorem cert_e2422372791790 : check e2422372791790 [[],[]] .three = true := by decide
def e2422372791818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422372791818 : Closed e2422372791818 ∧ code e2422372791818 = 11218465814026 := by decide
theorem cert_e2422372791818 : check e2422372791818 [[],[]] .smaller = true := by decide
def e2422372791854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372791854 : Closed e2422372791854 ∧ code e2422372791854 = 11218465814062 := by decide
theorem cert_e2422372791854 : check e2422372791854 [[],[]] .smaller = true := by decide
def e2422372791862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372791862 : Closed e2422372791862 ∧ code e2422372791862 = 11218465814070 := by decide
theorem cert_e2422372791862 : check e2422372791862 [[],[]] .smaller = true := by decide
def e2422372791866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372791866 : Closed e2422372791866 ∧ code e2422372791866 = 11218465814074 := by decide
theorem cert_e2422372791866 : check e2422372791866 [[],[]] .smaller = true := by decide
def e2422372791914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2422372791914 : Closed e2422372791914 ∧ code e2422372791914 = 11218465814122 := by decide
theorem cert_e2422372791914 : check e2422372791914 [[],[]] .smaller = true := by decide
def e2422372791938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372791938 : Closed e2422372791938 ∧ code e2422372791938 = 11218465814146 := by decide
theorem cert_e2422372791938 : check e2422372791938 [[],[]] .smaller = true := by decide
def e2422372791950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372791950 : Closed e2422372791950 ∧ code e2422372791950 = 11218465814158 := by decide
theorem cert_e2422372791950 : check e2422372791950 [[],[]] .smaller = true := by decide
def e2422372791962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372791962 : Closed e2422372791962 ∧ code e2422372791962 = 11218465814170 := by decide
theorem cert_e2422372791962 : check e2422372791962 [[],[]] .smaller = true := by decide
def e2422372792006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372792006 : Closed e2422372792006 ∧ code e2422372792006 = 11218465814214 := by decide
theorem cert_e2422372792006 : check e2422372792006 [[],[]] .smaller = true := by decide
def e2422372792030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 3)))))))
theorem wire_e2422372792030 : Closed e2422372792030 ∧ code e2422372792030 = 11218465814238 := by decide
theorem cert_e2422372792030 : check e2422372792030 [[],[]] .three = true := by decide
def e2422372792034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372792034 : Closed e2422372792034 ∧ code e2422372792034 = 11218465814242 := by decide
theorem cert_e2422372792034 : check e2422372792034 [[],[]] .smaller = true := by decide
def e2422372792046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 2)))))))
theorem wire_e2422372792046 : Closed e2422372792046 ∧ code e2422372792046 = 11218465814254 := by decide
theorem cert_e2422372792046 : check e2422372792046 [[],[]] .smaller = true := by decide
def e2422372792054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 3)) (.var 1)))))))
theorem wire_e2422372792054 : Closed e2422372792054 ∧ code e2422372792054 = 11218465814262 := by decide
theorem cert_e2422372792054 : check e2422372792054 [[],[]] .three = true := by decide
def e2422372792086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372792086 : Closed e2422372792086 ∧ code e2422372792086 = 11218465814294 := by decide
theorem cert_e2422372792086 : check e2422372792086 [[],[]] .smaller = true := by decide
def e2422372792158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 3)))))))
theorem wire_e2422372792158 : Closed e2422372792158 ∧ code e2422372792158 = 11218465814366 := by decide
theorem cert_e2422372792158 : check e2422372792158 [[],[]] .three = true := by decide
def e2422372792162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372792162 : Closed e2422372792162 ∧ code e2422372792162 = 11218465814370 := by decide
theorem cert_e2422372792162 : check e2422372792162 [[],[]] .smaller = true := by decide
def e2422372792174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 2)))))))
theorem wire_e2422372792174 : Closed e2422372792174 ∧ code e2422372792174 = 11218465814382 := by decide
theorem cert_e2422372792174 : check e2422372792174 [[],[]] .smaller = true := by decide
def e2422372792182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 2)) (.var 1)))))))
theorem wire_e2422372792182 : Closed e2422372792182 ∧ code e2422372792182 = 11218465814390 := by decide
theorem cert_e2422372792182 : check e2422372792182 [[],[]] .smaller = true := by decide
def e2422372792186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3)) (.var 0)))))))
theorem wire_e2422372792186 : Closed e2422372792186 ∧ code e2422372792186 = 11218465814394 := by decide
theorem cert_e2422372792186 : check e2422372792186 [[],[]] .three = true := by decide
def e2422372792202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372792202 : Closed e2422372792202 ∧ code e2422372792202 = 11218465814410 := by decide
theorem cert_e2422372792202 : check e2422372792202 [[],[]] .three = true := by decide
def e2422372792226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372792226 : Closed e2422372792226 ∧ code e2422372792226 = 11218465814434 := by decide
theorem cert_e2422372792226 : check e2422372792226 [[],[]] .three = true := by decide
def e2422372792238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)) (.var 2)))))))
theorem wire_e2422372792238 : Closed e2422372792238 ∧ code e2422372792238 = 11218465814446 := by decide
theorem cert_e2422372792238 : check e2422372792238 [[],[]] .three = true := by decide
def e2422372792246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 1)) (.var 1)))))))
theorem wire_e2422372792246 : Closed e2422372792246 ∧ code e2422372792246 = 11218465814454 := by decide
theorem cert_e2422372792246 : check e2422372792246 [[],[]] .three = true := by decide
def e2422372792250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2)) (.var 0)))))))
theorem wire_e2422372792250 : Closed e2422372792250 ∧ code e2422372792250 = 11218465814458 := by decide
theorem cert_e2422372792250 : check e2422372792250 [[],[]] .three = true := by decide
def e2422372792494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372792494 : Closed e2422372792494 ∧ code e2422372792494 = 11218465814702 := by decide
theorem cert_e2422372792494 : check e2422372792494 [[],[]] .three = true := by decide
def e2422372792502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 1)) (.var 1)))))))
theorem wire_e2422372792502 : Closed e2422372792502 ∧ code e2422372792502 = 11218465814710 := by decide
theorem cert_e2422372792502 : check e2422372792502 [[],[]] .three = true := by decide
def e2422372792506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372792506 : Closed e2422372792506 ∧ code e2422372792506 = 11218465814714 := by decide
theorem cert_e2422372792506 : check e2422372792506 [[],[]] .three = true := by decide
def e2422372792534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e2422372792534 : Closed e2422372792534 ∧ code e2422372792534 = 11218465814742 := by decide
theorem cert_e2422372792534 : check e2422372792534 [[],[]] .three = true := by decide
def e2422372792538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e2422372792538 : Closed e2422372792538 ∧ code e2422372792538 = 11218465814746 := by decide
theorem cert_e2422372792538 : check e2422372792538 [[],[]] .three = true := by decide
def e2422372792554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372792554 : Closed e2422372792554 ∧ code e2422372792554 = 11218465814762 := by decide
theorem cert_e2422372792554 : check e2422372792554 [[],[]] .three = true := by decide
def e2422372792878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372792878 : Closed e2422372792878 ∧ code e2422372792878 = 11218465815086 := by decide
theorem cert_e2422372792878 : check e2422372792878 [[],[]] .three = true := by decide
def e2422372792886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372792886 : Closed e2422372792886 ∧ code e2422372792886 = 11218465815094 := by decide
theorem cert_e2422372792886 : check e2422372792886 [[],[]] .three = true := by decide
def e2422372792890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372792890 : Closed e2422372792890 ∧ code e2422372792890 = 11218465815098 := by decide
theorem cert_e2422372792890 : check e2422372792890 [[],[]] .three = true := by decide
def e2422372792974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372792974 : Closed e2422372792974 ∧ code e2422372792974 = 11218465815182 := by decide
theorem cert_e2422372792974 : check e2422372792974 [[],[]] .three = true := by decide
def e2422372793030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372793030 : Closed e2422372793030 ∧ code e2422372793030 = 11218465815238 := by decide
theorem cert_e2422372793030 : check e2422372793030 [[],[]] .three = true := by decide
def e2422372793054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)) (.var 3)))))))
theorem wire_e2422372793054 : Closed e2422372793054 ∧ code e2422372793054 = 11218465815262 := by decide
theorem cert_e2422372793054 : check e2422372793054 [[],[]] .three = true := by decide
def e2422372793058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372793058 : Closed e2422372793058 ∧ code e2422372793058 = 11218465815266 := by decide
theorem cert_e2422372793058 : check e2422372793058 [[],[]] .three = true := by decide
def e2422372793070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2422372793070 : Closed e2422372793070 ∧ code e2422372793070 = 11218465815278 := by decide
theorem cert_e2422372793070 : check e2422372793070 [[],[]] .three = true := by decide
def e2422372793078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 3)) (.var 1)))))))
theorem wire_e2422372793078 : Closed e2422372793078 ∧ code e2422372793078 = 11218465815286 := by decide
theorem cert_e2422372793078 : check e2422372793078 [[],[]] .three = true := by decide
def e2422372793110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2422372793110 : Closed e2422372793110 ∧ code e2422372793110 = 11218465815318 := by decide
theorem cert_e2422372793110 : check e2422372793110 [[],[]] .three = true := by decide
def e2422372793114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2422372793114 : Closed e2422372793114 ∧ code e2422372793114 = 11218465815322 := by decide
theorem cert_e2422372793114 : check e2422372793114 [[],[]] .three = true := by decide
def e2422372793158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2422372793158 : Closed e2422372793158 ∧ code e2422372793158 = 11218465815366 := by decide
theorem cert_e2422372793158 : check e2422372793158 [[],[]] .three = true := by decide
def e2422372793182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)) (.var 3)))))))
theorem wire_e2422372793182 : Closed e2422372793182 ∧ code e2422372793182 = 11218465815390 := by decide
theorem cert_e2422372793182 : check e2422372793182 [[],[]] .three = true := by decide
def e2422372793186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2422372793186 : Closed e2422372793186 ∧ code e2422372793186 = 11218465815394 := by decide
theorem cert_e2422372793186 : check e2422372793186 [[],[]] .three = true := by decide
def e2422372793198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2422372793198 : Closed e2422372793198 ∧ code e2422372793198 = 11218465815406 := by decide
theorem cert_e2422372793198 : check e2422372793198 [[],[]] .three = true := by decide
def e2422372793206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2422372793206 : Closed e2422372793206 ∧ code e2422372793206 = 11218465815414 := by decide
theorem cert_e2422372793206 : check e2422372793206 [[],[]] .three = true := by decide
def e2422372793210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3)) (.var 0)))))))
theorem wire_e2422372793210 : Closed e2422372793210 ∧ code e2422372793210 = 11218465815418 := by decide
theorem cert_e2422372793210 : check e2422372793210 [[],[]] .three = true := by decide
def e2422372793226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422372793226 : Closed e2422372793226 ∧ code e2422372793226 = 11218465815434 := by decide
theorem cert_e2422372793226 : check e2422372793226 [[],[]] .three = true := by decide
def e2422372793250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422372793250 : Closed e2422372793250 ∧ code e2422372793250 = 11218465815458 := by decide
theorem cert_e2422372793250 : check e2422372793250 [[],[]] .three = true := by decide
def e2422372793262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2422372793262 : Closed e2422372793262 ∧ code e2422372793262 = 11218465815470 := by decide
theorem cert_e2422372793262 : check e2422372793262 [[],[]] .three = true := by decide
def e2422372793270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2422372793270 : Closed e2422372793270 ∧ code e2422372793270 = 11218465815478 := by decide
theorem cert_e2422372793270 : check e2422372793270 [[],[]] .three = true := by decide
def e2422372793274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2422372793274 : Closed e2422372793274 ∧ code e2422372793274 = 11218465815482 := by decide
theorem cert_e2422372793274 : check e2422372793274 [[],[]] .three = true := by decide
def e2422372793302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 0)) (.var 1)))))))
theorem wire_e2422372793302 : Closed e2422372793302 ∧ code e2422372793302 = 11218465815510 := by decide
theorem cert_e2422372793302 : check e2422372793302 [[],[]] .three = true := by decide
def e2422372793306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1)) (.var 0)))))))
theorem wire_e2422372793306 : Closed e2422372793306 ∧ code e2422372793306 = 11218465815514 := by decide
theorem cert_e2422372793306 : check e2422372793306 [[],[]] .three = true := by decide
def e2422372795054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2422372795054 : Closed e2422372795054 ∧ code e2422372795054 = 11218465817262 := by decide
theorem cert_e2422372795054 : check e2422372795054 [[],[]] .smaller = true := by decide
def e2422372795066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2422372795066 : Closed e2422372795066 ∧ code e2422372795066 = 11218465817274 := by decide
theorem cert_e2422372795066 : check e2422372795066 [[],[]] .smaller = true := by decide
end Blc.Floor43
