import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411649689146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2411649689146 : Closed e2411649689146 ∧ code e2411649689146 = 11207742711354 := by decide
theorem cert_e2411649689146 : check e2411649689146 [[],[]] .chain = true := by decide
def e2411649689230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2411649689230 : Closed e2411649689230 ∧ code e2411649689230 = 11207742711438 := by decide
theorem cert_e2411649689230 : check e2411649689230 [[],[]] .chain = true := by decide
def e2411649689286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2411649689286 : Closed e2411649689286 ∧ code e2411649689286 = 11207742711494 := by decide
theorem cert_e2411649689286 : check e2411649689286 [[],[]] .chain = true := by decide
def e2411649689370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2411649689370 : Closed e2411649689370 ∧ code e2411649689370 = 11207742711578 := by decide
theorem cert_e2411649689370 : check e2411649689370 [[],[]] .chain = true := by decide
def e2411649689414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2411649689414 : Closed e2411649689414 ∧ code e2411649689414 = 11207742711622 := by decide
theorem cert_e2411649689414 : check e2411649689414 [[],[]] .chain = true := by decide
def e2411649689710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411649689710 : Closed e2411649689710 ∧ code e2411649689710 = 11207742711918 := by decide
theorem cert_e2411649689710 : check e2411649689710 [[],[]] .chain = true := by decide
def e2411649689722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411649689722 : Closed e2411649689722 ∧ code e2411649689722 = 11207742711930 := by decide
theorem cert_e2411649689722 : check e2411649689722 [[],[]] .chain = true := by decide
def e2411649689998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411649689998 : Closed e2411649689998 ∧ code e2411649689998 = 11207742712206 := by decide
theorem cert_e2411649689998 : check e2411649689998 [[],[]] .chain = true := by decide
def e2411649690054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411649690054 : Closed e2411649690054 ∧ code e2411649690054 = 11207742712262 := by decide
theorem cert_e2411649690054 : check e2411649690054 [[],[]] .chain = true := by decide
def e2411649690678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411649690678 : Closed e2411649690678 ∧ code e2411649690678 = 11207742712886 := by decide
theorem cert_e2411649690678 : check e2411649690678 [[],[]] .chain = true := by decide
def e2411649690682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411649690682 : Closed e2411649690682 ∧ code e2411649690682 = 11207742712890 := by decide
theorem cert_e2411649690682 : check e2411649690682 [[],[]] .chain = true := by decide
def e2411649690822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411649690822 : Closed e2411649690822 ∧ code e2411649690822 = 11207742713030 := by decide
theorem cert_e2411649690822 : check e2411649690822 [[],[]] .chain = true := by decide
def e2411649701598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411649701598 : Closed e2411649701598 ∧ code e2411649701598 = 11207742723806 := by decide
theorem cert_e2411649701598 : check e2411649701598 [[],[]] .chain = true := by decide
def e2411649701622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411649701622 : Closed e2411649701622 ∧ code e2411649701622 = 11207742723830 := by decide
theorem cert_e2411649701622 : check e2411649701622 [[],[]] .chain = true := by decide
def e2411649701726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411649701726 : Closed e2411649701726 ∧ code e2411649701726 = 11207742723934 := by decide
theorem cert_e2411649701726 : check e2411649701726 [[],[]] .chain = true := by decide
def e2411649701754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411649701754 : Closed e2411649701754 ∧ code e2411649701754 = 11207742723962 := by decide
theorem cert_e2411649701754 : check e2411649701754 [[],[]] .chain = true := by decide
def e2411649701846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411649701846 : Closed e2411649701846 ∧ code e2411649701846 = 11207742724054 := by decide
theorem cert_e2411649701846 : check e2411649701846 [[],[]] .chain = true := by decide
def e2411649701850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411649701850 : Closed e2411649701850 ∧ code e2411649701850 = 11207742724058 := by decide
theorem cert_e2411649701850 : check e2411649701850 [[],[]] .chain = true := by decide
def e2411649702366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411649702366 : Closed e2411649702366 ∧ code e2411649702366 = 11207742724574 := by decide
theorem cert_e2411649702366 : check e2411649702366 [[],[]] .chain = true := by decide
def e2411649702390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411649702390 : Closed e2411649702390 ∧ code e2411649702390 = 11207742724598 := by decide
theorem cert_e2411649702390 : check e2411649702390 [[],[]] .chain = true := by decide
def e2411649703134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411649703134 : Closed e2411649703134 ∧ code e2411649703134 = 11207742725342 := by decide
theorem cert_e2411649703134 : check e2411649703134 [[],[]] .chain = true := by decide
def e2411649703162 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411649703162 : Closed e2411649703162 ∧ code e2411649703162 = 11207742725370 := by decide
theorem cert_e2411649703162 : check e2411649703162 [[],[]] .chain = true := by decide
def e2411649703486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2411649703486 : Closed e2411649703486 ∧ code e2411649703486 = 11207742725694 := by decide
theorem cert_e2411649703486 : check e2411649703486 [[],[]] .chain = true := by decide
def e2411649703710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2411649703710 : Closed e2411649703710 ∧ code e2411649703710 = 11207742725918 := by decide
theorem cert_e2411649703710 : check e2411649703710 [[],[]] .chain = true := by decide
def e2411649703734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649703734 : Closed e2411649703734 ∧ code e2411649703734 = 11207742725942 := by decide
theorem cert_e2411649703734 : check e2411649703734 [[],[]] .chain = true := by decide
def e2411649703738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649703738 : Closed e2411649703738 ∧ code e2411649703738 = 11207742725946 := by decide
theorem cert_e2411649703738 : check e2411649703738 [[],[]] .chain = true := by decide
def e2411649718510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411649718510 : Closed e2411649718510 ∧ code e2411649718510 = 11207742740718 := by decide
theorem cert_e2411649718510 : check e2411649718510 [[],[]] .chain = true := by decide
def e2411649718518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411649718518 : Closed e2411649718518 ∧ code e2411649718518 = 11207742740726 := by decide
theorem cert_e2411649718518 : check e2411649718518 [[],[]] .chain = true := by decide
def e2411649719070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411649719070 : Closed e2411649719070 ∧ code e2411649719070 = 11207742741278 := by decide
theorem cert_e2411649719070 : check e2411649719070 [[],[]] .chain = true := by decide
def e2411649719182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411649719182 : Closed e2411649719182 ∧ code e2411649719182 = 11207742741390 := by decide
theorem cert_e2411649719182 : check e2411649719182 [[],[]] .chain = true := by decide
def e2411649719406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411649719406 : Closed e2411649719406 ∧ code e2411649719406 = 11207742741614 := by decide
theorem cert_e2411649719406 : check e2411649719406 [[],[]] .chain = true := by decide
def e2411649719418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411649719418 : Closed e2411649719418 ∧ code e2411649719418 = 11207742741626 := by decide
theorem cert_e2411649719418 : check e2411649719418 [[],[]] .chain = true := by decide
def e2411649719582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411649719582 : Closed e2411649719582 ∧ code e2411649719582 = 11207742741790 := by decide
theorem cert_e2411649719582 : check e2411649719582 [[],[]] .chain = true := by decide
def e2411649719750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411649719750 : Closed e2411649719750 ∧ code e2411649719750 = 11207742741958 := by decide
theorem cert_e2411649719750 : check e2411649719750 [[],[]] .chain = true := by decide
def e2411649719862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411649719862 : Closed e2411649719862 ∧ code e2411649719862 = 11207742742070 := by decide
theorem cert_e2411649719862 : check e2411649719862 [[],[]] .chain = true := by decide
def e2411649719866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411649719866 : Closed e2411649719866 ∧ code e2411649719866 = 11207742742074 := by decide
theorem cert_e2411649719866 : check e2411649719866 [[],[]] .chain = true := by decide
def e2411649719950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411649719950 : Closed e2411649719950 ∧ code e2411649719950 = 11207742742158 := by decide
theorem cert_e2411649719950 : check e2411649719950 [[],[]] .chain = true := by decide
def e2411649720006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411649720006 : Closed e2411649720006 ∧ code e2411649720006 = 11207742742214 := by decide
theorem cert_e2411649720006 : check e2411649720006 [[],[]] .chain = true := by decide
def e2411649722142 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411649722142 : Closed e2411649722142 ∧ code e2411649722142 = 11207742744350 := by decide
theorem cert_e2411649722142 : check e2411649722142 [[],[]] .chain = true := by decide
def e2411649722254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411649722254 : Closed e2411649722254 ∧ code e2411649722254 = 11207742744462 := by decide
theorem cert_e2411649722254 : check e2411649722254 [[],[]] .chain = true := by decide
def e2411649724638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2411649724638 : Closed e2411649724638 ∧ code e2411649724638 = 11207742746846 := by decide
theorem cert_e2411649724638 : check e2411649724638 [[],[]] .chain = true := by decide
def e2411649724666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2411649724666 : Closed e2411649724666 ∧ code e2411649724666 = 11207742746874 := by decide
theorem cert_e2411649724666 : check e2411649724666 [[],[]] .chain = true := by decide
def e2411649725214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411649725214 : Closed e2411649725214 ∧ code e2411649725214 = 11207742747422 := by decide
theorem cert_e2411649725214 : check e2411649725214 [[],[]] .chain = true := by decide
def e2411649725382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411649725382 : Closed e2411649725382 ∧ code e2411649725382 = 11207742747590 := by decide
theorem cert_e2411649725382 : check e2411649725382 [[],[]] .chain = true := by decide
def e2411649726574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2411649726574 : Closed e2411649726574 ∧ code e2411649726574 = 11207742748782 := by decide
theorem cert_e2411649726574 : check e2411649726574 [[],[]] .chain = true := by decide
def e2411649726586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2411649726586 : Closed e2411649726586 ∧ code e2411649726586 = 11207742748794 := by decide
theorem cert_e2411649726586 : check e2411649726586 [[],[]] .chain = true := by decide
def e2411649726862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411649726862 : Closed e2411649726862 ∧ code e2411649726862 = 11207742749070 := by decide
theorem cert_e2411649726862 : check e2411649726862 [[],[]] .chain = true := by decide
def e2411649726918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411649726918 : Closed e2411649726918 ∧ code e2411649726918 = 11207742749126 := by decide
theorem cert_e2411649726918 : check e2411649726918 [[],[]] .chain = true := by decide
def e2411649764206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411649764206 : Closed e2411649764206 ∧ code e2411649764206 = 11207742786414 := by decide
theorem cert_e2411649764206 : check e2411649764206 [[],[]] .smaller = true := by decide
def e2411649764214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411649764214 : Closed e2411649764214 ∧ code e2411649764214 = 11207742786422 := by decide
theorem cert_e2411649764214 : check e2411649764214 [[],[]] .smaller = true := by decide
def e2411649764270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411649764270 : Closed e2411649764270 ∧ code e2411649764270 = 11207742786478 := by decide
theorem cert_e2411649764270 : check e2411649764270 [[],[]] .smaller = true := by decide
def e2411649764282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411649764282 : Closed e2411649764282 ∧ code e2411649764282 = 11207742786490 := by decide
theorem cert_e2411649764282 : check e2411649764282 [[],[]] .smaller = true := by decide
def e2411649764310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411649764310 : Closed e2411649764310 ∧ code e2411649764310 = 11207742786518 := by decide
theorem cert_e2411649764310 : check e2411649764310 [[],[]] .smaller = true := by decide
def e2411649764314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411649764314 : Closed e2411649764314 ∧ code e2411649764314 = 11207742786522 := by decide
theorem cert_e2411649764314 : check e2411649764314 [[],[]] .smaller = true := by decide
def e2411649764590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411649764590 : Closed e2411649764590 ∧ code e2411649764590 = 11207742786798 := by decide
theorem cert_e2411649764590 : check e2411649764590 [[],[]] .smaller = true := by decide
def e2411649764598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411649764598 : Closed e2411649764598 ∧ code e2411649764598 = 11207742786806 := by decide
theorem cert_e2411649764598 : check e2411649764598 [[],[]] .smaller = true := by decide
def e2411649764926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2411649764926 : Closed e2411649764926 ∧ code e2411649764926 = 11207742787134 := by decide
theorem cert_e2411649764926 : check e2411649764926 [[],[]] .chain = true := by decide
def e2411649764974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411649764974 : Closed e2411649764974 ∧ code e2411649764974 = 11207742787182 := by decide
theorem cert_e2411649764974 : check e2411649764974 [[],[]] .smaller = true := by decide
def e2411649764986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411649764986 : Closed e2411649764986 ∧ code e2411649764986 = 11207742787194 := by decide
theorem cert_e2411649764986 : check e2411649764986 [[],[]] .smaller = true := by decide
def e2411649765174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649765174 : Closed e2411649765174 ∧ code e2411649765174 = 11207742787382 := by decide
theorem cert_e2411649765174 : check e2411649765174 [[],[]] .smaller = true := by decide
def e2411649765178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649765178 : Closed e2411649765178 ∧ code e2411649765178 = 11207742787386 := by decide
theorem cert_e2411649765178 : check e2411649765178 [[],[]] .smaller = true := by decide
def e2411649765262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2411649765262 : Closed e2411649765262 ∧ code e2411649765262 = 11207742787470 := by decide
theorem cert_e2411649765262 : check e2411649765262 [[],[]] .chain = true := by decide
def e2411649772654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411649772654 : Closed e2411649772654 ∧ code e2411649772654 = 11207742794862 := by decide
theorem cert_e2411649772654 : check e2411649772654 [[],[]] .chain = true := by decide
def e2411649772666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411649772666 : Closed e2411649772666 ∧ code e2411649772666 = 11207742794874 := by decide
theorem cert_e2411649772666 : check e2411649772666 [[],[]] .chain = true := by decide
def e2411649772830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411649772830 : Closed e2411649772830 ∧ code e2411649772830 = 11207742795038 := by decide
theorem cert_e2411649772830 : check e2411649772830 [[],[]] .chain = true := by decide
def e2411649772998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411649772998 : Closed e2411649772998 ∧ code e2411649772998 = 11207742795206 := by decide
theorem cert_e2411649772998 : check e2411649772998 [[],[]] .chain = true := by decide
def e2411649773338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411649773338 : Closed e2411649773338 ∧ code e2411649773338 = 11207742795546 := by decide
theorem cert_e2411649773338 : check e2411649773338 [[],[]] .chain = true := by decide
def e2411649773382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411649773382 : Closed e2411649773382 ∧ code e2411649773382 = 11207742795590 := by decide
theorem cert_e2411649773382 : check e2411649773382 [[],[]] .chain = true := by decide
def e2411649773790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2411649773790 : Closed e2411649773790 ∧ code e2411649773790 = 11207742795998 := by decide
theorem cert_e2411649773790 : check e2411649773790 [[],[]] .chain = true := by decide
def e2411649773818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2411649773818 : Closed e2411649773818 ∧ code e2411649773818 = 11207742796026 := by decide
theorem cert_e2411649773818 : check e2411649773818 [[],[]] .chain = true := by decide
def e2411649774366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411649774366 : Closed e2411649774366 ∧ code e2411649774366 = 11207742796574 := by decide
theorem cert_e2411649774366 : check e2411649774366 [[],[]] .chain = true := by decide
def e2411649774534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411649774534 : Closed e2411649774534 ∧ code e2411649774534 = 11207742796742 := by decide
theorem cert_e2411649774534 : check e2411649774534 [[],[]] .chain = true := by decide
def e2411649776694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649776694 : Closed e2411649776694 ∧ code e2411649776694 = 11207742798902 := by decide
theorem cert_e2411649776694 : check e2411649776694 [[],[]] .chain = true := by decide
def e2411649776698 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649776698 : Closed e2411649776698 ∧ code e2411649776698 = 11207742798906 := by decide
theorem cert_e2411649776698 : check e2411649776698 [[],[]] .chain = true := by decide
def e2411649776838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411649776838 : Closed e2411649776838 ∧ code e2411649776838 = 11207742799046 := by decide
theorem cert_e2411649776838 : check e2411649776838 [[],[]] .chain = true := by decide
def e2411649795870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411649795870 : Closed e2411649795870 ∧ code e2411649795870 = 11207742818078 := by decide
theorem cert_e2411649795870 : check e2411649795870 [[],[]] .chain = true := by decide
def e2411649795982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411649795982 : Closed e2411649795982 ∧ code e2411649795982 = 11207742818190 := by decide
theorem cert_e2411649795982 : check e2411649795982 [[],[]] .chain = true := by decide
def e2411649799734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411649799734 : Closed e2411649799734 ∧ code e2411649799734 = 11207742821942 := by decide
theorem cert_e2411649799734 : check e2411649799734 [[],[]] .chain = true := by decide
def e2411649799738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411649799738 : Closed e2411649799738 ∧ code e2411649799738 = 11207742821946 := by decide
theorem cert_e2411649799738 : check e2411649799738 [[],[]] .chain = true := by decide
def e2411649799822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411649799822 : Closed e2411649799822 ∧ code e2411649799822 = 11207742822030 := by decide
theorem cert_e2411649799822 : check e2411649799822 [[],[]] .chain = true := by decide
def e2411649799878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411649799878 : Closed e2411649799878 ∧ code e2411649799878 = 11207742822086 := by decide
theorem cert_e2411649799878 : check e2411649799878 [[],[]] .chain = true := by decide
def e2411649799962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411649799962 : Closed e2411649799962 ∧ code e2411649799962 = 11207742822170 := by decide
theorem cert_e2411649799962 : check e2411649799962 [[],[]] .chain = true := by decide
def e2411649800006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411649800006 : Closed e2411649800006 ∧ code e2411649800006 = 11207742822214 := by decide
theorem cert_e2411649800006 : check e2411649800006 [[],[]] .chain = true := by decide
def e2411649800302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2411649800302 : Closed e2411649800302 ∧ code e2411649800302 = 11207742822510 := by decide
theorem cert_e2411649800302 : check e2411649800302 [[],[]] .chain = true := by decide
def e2411649800314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2411649800314 : Closed e2411649800314 ∧ code e2411649800314 = 11207742822522 := by decide
theorem cert_e2411649800314 : check e2411649800314 [[],[]] .chain = true := by decide
def e2411649800590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411649800590 : Closed e2411649800590 ∧ code e2411649800590 = 11207742822798 := by decide
theorem cert_e2411649800590 : check e2411649800590 [[],[]] .chain = true := by decide
def e2411649800646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411649800646 : Closed e2411649800646 ∧ code e2411649800646 = 11207742822854 := by decide
theorem cert_e2411649800646 : check e2411649800646 [[],[]] .chain = true := by decide
def e2411649801270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411649801270 : Closed e2411649801270 ∧ code e2411649801270 = 11207742823478 := by decide
theorem cert_e2411649801270 : check e2411649801270 [[],[]] .chain = true := by decide
def e2411649801274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411649801274 : Closed e2411649801274 ∧ code e2411649801274 = 11207742823482 := by decide
theorem cert_e2411649801274 : check e2411649801274 [[],[]] .chain = true := by decide
def e2411649801414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411649801414 : Closed e2411649801414 ∧ code e2411649801414 = 11207742823622 := by decide
theorem cert_e2411649801414 : check e2411649801414 [[],[]] .chain = true := by decide
def e2411650881246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2411650881246 : Closed e2411650881246 ∧ code e2411650881246 = 11207743903454 := by decide
theorem cert_e2411650881246 : check e2411650881246 [[],[]] .chain = true := by decide
def e2411650881270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2411650881270 : Closed e2411650881270 ∧ code e2411650881270 = 11207743903478 := by decide
theorem cert_e2411650881270 : check e2411650881270 [[],[]] .chain = true := by decide
def e2411650881374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2411650881374 : Closed e2411650881374 ∧ code e2411650881374 = 11207743903582 := by decide
theorem cert_e2411650881374 : check e2411650881374 [[],[]] .chain = true := by decide
def e2411650881402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2411650881402 : Closed e2411650881402 ∧ code e2411650881402 = 11207743903610 := by decide
theorem cert_e2411650881402 : check e2411650881402 [[],[]] .chain = true := by decide
def e2411650881494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2411650881494 : Closed e2411650881494 ∧ code e2411650881494 = 11207743903702 := by decide
theorem cert_e2411650881494 : check e2411650881494 [[],[]] .chain = true := by decide
def e2411650881498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2411650881498 : Closed e2411650881498 ∧ code e2411650881498 = 11207743903706 := by decide
theorem cert_e2411650881498 : check e2411650881498 [[],[]] .chain = true := by decide
def e2411650882014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2411650882014 : Closed e2411650882014 ∧ code e2411650882014 = 11207743904222 := by decide
theorem cert_e2411650882014 : check e2411650882014 [[],[]] .chain = true := by decide
def e2411650882038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2411650882038 : Closed e2411650882038 ∧ code e2411650882038 = 11207743904246 := by decide
theorem cert_e2411650882038 : check e2411650882038 [[],[]] .chain = true := by decide
def e2411650882782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2411650882782 : Closed e2411650882782 ∧ code e2411650882782 = 11207743904990 := by decide
theorem cert_e2411650882782 : check e2411650882782 [[],[]] .chain = true := by decide
def e2411650882810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2411650882810 : Closed e2411650882810 ∧ code e2411650882810 = 11207743905018 := by decide
theorem cert_e2411650882810 : check e2411650882810 [[],[]] .chain = true := by decide
def e2411650883382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411650883382 : Closed e2411650883382 ∧ code e2411650883382 = 11207743905590 := by decide
theorem cert_e2411650883382 : check e2411650883382 [[],[]] .chain = true := by decide
def e2411650883386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411650883386 : Closed e2411650883386 ∧ code e2411650883386 = 11207743905594 := by decide
theorem cert_e2411650883386 : check e2411650883386 [[],[]] .chain = true := by decide
def e2411650898158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2411650898158 : Closed e2411650898158 ∧ code e2411650898158 = 11207743920366 := by decide
theorem cert_e2411650898158 : check e2411650898158 [[],[]] .chain = true := by decide
def e2411650898166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2411650898166 : Closed e2411650898166 ∧ code e2411650898166 = 11207743920374 := by decide
theorem cert_e2411650898166 : check e2411650898166 [[],[]] .chain = true := by decide
def e2411650898718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2411650898718 : Closed e2411650898718 ∧ code e2411650898718 = 11207743920926 := by decide
theorem cert_e2411650898718 : check e2411650898718 [[],[]] .chain = true := by decide
def e2411650898830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2411650898830 : Closed e2411650898830 ∧ code e2411650898830 = 11207743921038 := by decide
theorem cert_e2411650898830 : check e2411650898830 [[],[]] .chain = true := by decide
def e2411650899054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411650899054 : Closed e2411650899054 ∧ code e2411650899054 = 11207743921262 := by decide
theorem cert_e2411650899054 : check e2411650899054 [[],[]] .chain = true := by decide
def e2411650899066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411650899066 : Closed e2411650899066 ∧ code e2411650899066 = 11207743921274 := by decide
theorem cert_e2411650899066 : check e2411650899066 [[],[]] .chain = true := by decide
def e2411650899230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411650899230 : Closed e2411650899230 ∧ code e2411650899230 = 11207743921438 := by decide
theorem cert_e2411650899230 : check e2411650899230 [[],[]] .chain = true := by decide
def e2411650899398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411650899398 : Closed e2411650899398 ∧ code e2411650899398 = 11207743921606 := by decide
theorem cert_e2411650899398 : check e2411650899398 [[],[]] .chain = true := by decide
def e2411650899510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411650899510 : Closed e2411650899510 ∧ code e2411650899510 = 11207743921718 := by decide
theorem cert_e2411650899510 : check e2411650899510 [[],[]] .chain = true := by decide
def e2411650899514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411650899514 : Closed e2411650899514 ∧ code e2411650899514 = 11207743921722 := by decide
theorem cert_e2411650899514 : check e2411650899514 [[],[]] .chain = true := by decide
def e2411650899598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411650899598 : Closed e2411650899598 ∧ code e2411650899598 = 11207743921806 := by decide
theorem cert_e2411650899598 : check e2411650899598 [[],[]] .chain = true := by decide
def e2411650899654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411650899654 : Closed e2411650899654 ∧ code e2411650899654 = 11207743921862 := by decide
theorem cert_e2411650899654 : check e2411650899654 [[],[]] .chain = true := by decide
def e2411650901790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411650901790 : Closed e2411650901790 ∧ code e2411650901790 = 11207743923998 := by decide
theorem cert_e2411650901790 : check e2411650901790 [[],[]] .chain = true := by decide
def e2411650901902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411650901902 : Closed e2411650901902 ∧ code e2411650901902 = 11207743924110 := by decide
theorem cert_e2411650901902 : check e2411650901902 [[],[]] .chain = true := by decide
def e2411650904862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411650904862 : Closed e2411650904862 ∧ code e2411650904862 = 11207743927070 := by decide
theorem cert_e2411650904862 : check e2411650904862 [[],[]] .chain = true := by decide
def e2411650905030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411650905030 : Closed e2411650905030 ∧ code e2411650905030 = 11207743927238 := by decide
theorem cert_e2411650905030 : check e2411650905030 [[],[]] .chain = true := by decide
def e2411650906510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411650906510 : Closed e2411650906510 ∧ code e2411650906510 = 11207743928718 := by decide
theorem cert_e2411650906510 : check e2411650906510 [[],[]] .chain = true := by decide
def e2411650906566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411650906566 : Closed e2411650906566 ∧ code e2411650906566 = 11207743928774 := by decide
theorem cert_e2411650906566 : check e2411650906566 [[],[]] .chain = true := by decide
def e2411651140462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2411651140462 : Closed e2411651140462 ∧ code e2411651140462 = 11207744162670 := by decide
theorem cert_e2411651140462 : check e2411651140462 [[],[]] .chain = true := by decide
def e2411651140470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2411651140470 : Closed e2411651140470 ∧ code e2411651140470 = 11207744162678 := by decide
theorem cert_e2411651140470 : check e2411651140470 [[],[]] .chain = true := by decide
def e2411651140526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2411651140526 : Closed e2411651140526 ∧ code e2411651140526 = 11207744162734 := by decide
theorem cert_e2411651140526 : check e2411651140526 [[],[]] .chain = true := by decide
def e2411651140538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2411651140538 : Closed e2411651140538 ∧ code e2411651140538 = 11207744162746 := by decide
theorem cert_e2411651140538 : check e2411651140538 [[],[]] .chain = true := by decide
def e2411651140566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2411651140566 : Closed e2411651140566 ∧ code e2411651140566 = 11207744162774 := by decide
theorem cert_e2411651140566 : check e2411651140566 [[],[]] .chain = true := by decide
def e2411651140570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2411651140570 : Closed e2411651140570 ∧ code e2411651140570 = 11207744162778 := by decide
theorem cert_e2411651140570 : check e2411651140570 [[],[]] .chain = true := by decide
def e2411651140846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2411651140846 : Closed e2411651140846 ∧ code e2411651140846 = 11207744163054 := by decide
theorem cert_e2411651140846 : check e2411651140846 [[],[]] .chain = true := by decide
def e2411651140854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2411651140854 : Closed e2411651140854 ∧ code e2411651140854 = 11207744163062 := by decide
theorem cert_e2411651140854 : check e2411651140854 [[],[]] .chain = true := by decide
def e2411651141230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411651141230 : Closed e2411651141230 ∧ code e2411651141230 = 11207744163438 := by decide
theorem cert_e2411651141230 : check e2411651141230 [[],[]] .chain = true := by decide
def e2411651141242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411651141242 : Closed e2411651141242 ∧ code e2411651141242 = 11207744163450 := by decide
theorem cert_e2411651141242 : check e2411651141242 [[],[]] .chain = true := by decide
def e2411651141430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411651141430 : Closed e2411651141430 ∧ code e2411651141430 = 11207744163638 := by decide
theorem cert_e2411651141430 : check e2411651141430 [[],[]] .chain = true := by decide
def e2411651141434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411651141434 : Closed e2411651141434 ∧ code e2411651141434 = 11207744163642 := by decide
theorem cert_e2411651141434 : check e2411651141434 [[],[]] .chain = true := by decide
def e2411653508542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2411653508542 : Closed e2411653508542 ∧ code e2411653508542 = 11207746530750 := by decide
theorem cert_e2411653508542 : check e2411653508542 [[],[],[.under]] .smaller = true := by decide
def e2411653508598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2411653508598 : Closed e2411653508598 ∧ code e2411653508598 = 11207746530806 := by decide
theorem cert_e2411653508598 : check e2411653508598 [[],[],[.under]] .smaller = true := by decide
def e2411653508798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2411653508798 : Closed e2411653508798 ∧ code e2411653508798 = 11207746531006 := by decide
theorem cert_e2411653508798 : check e2411653508798 [[],[],[.under]] .smaller = true := by decide
def e2411653508858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2411653508858 : Closed e2411653508858 ∧ code e2411653508858 = 11207746531066 := by decide
theorem cert_e2411653508858 : check e2411653508858 [[],[],[.under]] .smaller = true := by decide
def e2411653509078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2411653509078 : Closed e2411653509078 ∧ code e2411653509078 = 11207746531286 := by decide
theorem cert_e2411653509078 : check e2411653509078 [[],[],[.under]] .smaller = true := by decide
def e2411653509082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2411653509082 : Closed e2411653509082 ∧ code e2411653509082 = 11207746531290 := by decide
theorem cert_e2411653509082 : check e2411653509082 [[],[],[.under]] .smaller = true := by decide
def e2411653510078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2411653510078 : Closed e2411653510078 ∧ code e2411653510078 = 11207746532286 := by decide
theorem cert_e2411653510078 : check e2411653510078 [[],[],[.under]] .smaller = true := by decide
def e2411653510134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2411653510134 : Closed e2411653510134 ∧ code e2411653510134 = 11207746532342 := by decide
theorem cert_e2411653510134 : check e2411653510134 [[],[],[.under]] .smaller = true := by decide
def e2411653511614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2411653511614 : Closed e2411653511614 ∧ code e2411653511614 = 11207746533822 := by decide
theorem cert_e2411653511614 : check e2411653511614 [[],[],[.under]] .smaller = true := by decide
def e2411653511674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2411653511674 : Closed e2411653511674 ∧ code e2411653511674 = 11207746533882 := by decide
theorem cert_e2411653511674 : check e2411653511674 [[],[],[.under]] .smaller = true := by decide
def e2411653513014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411653513014 : Closed e2411653513014 ∧ code e2411653513014 = 11207746535222 := by decide
theorem cert_e2411653513014 : check e2411653513014 [[],[],[.under]] .smaller = true := by decide
def e2411653513018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411653513018 : Closed e2411653513018 ∧ code e2411653513018 = 11207746535226 := by decide
theorem cert_e2411653513018 : check e2411653513018 [[],[],[.under]] .smaller = true := by decide
def e2411653541230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2411653541230 : Closed e2411653541230 ∧ code e2411653541230 = 11207746563438 := by decide
theorem cert_e2411653541230 : check e2411653541230 [[],[],[.under]] .smaller = true := by decide
def e2411653541238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2411653541238 : Closed e2411653541238 ∧ code e2411653541238 = 11207746563446 := by decide
theorem cert_e2411653541238 : check e2411653541238 [[],[],[.under]] .smaller = true := by decide
def e2411653541294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2411653541294 : Closed e2411653541294 ∧ code e2411653541294 = 11207746563502 := by decide
theorem cert_e2411653541294 : check e2411653541294 [[],[],[.under]] .smaller = true := by decide
def e2411653541306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2411653541306 : Closed e2411653541306 ∧ code e2411653541306 = 11207746563514 := by decide
theorem cert_e2411653541306 : check e2411653541306 [[],[],[.under]] .smaller = true := by decide
def e2411653541334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2411653541334 : Closed e2411653541334 ∧ code e2411653541334 = 11207746563542 := by decide
theorem cert_e2411653541334 : check e2411653541334 [[],[],[.under]] .smaller = true := by decide
def e2411653541338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2411653541338 : Closed e2411653541338 ∧ code e2411653541338 = 11207746563546 := by decide
theorem cert_e2411653541338 : check e2411653541338 [[],[],[.under]] .smaller = true := by decide
def e2411653541550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2411653541550 : Closed e2411653541550 ∧ code e2411653541550 = 11207746563758 := by decide
theorem cert_e2411653541550 : check e2411653541550 [[],[],[.under]] .smaller = true := by decide
def e2411653541562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2411653541562 : Closed e2411653541562 ∧ code e2411653541562 = 11207746563770 := by decide
theorem cert_e2411653541562 : check e2411653541562 [[],[],[.under]] .smaller = true := by decide
def e2411653541610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2411653541610 : Closed e2411653541610 ∧ code e2411653541610 = 11207746563818 := by decide
theorem cert_e2411653541610 : check e2411653541610 [[],[],[.under]] .smaller = true := by decide
def e2411653541718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411653541718 : Closed e2411653541718 ∧ code e2411653541718 = 11207746563926 := by decide
theorem cert_e2411653541718 : check e2411653541718 [[],[],[.under]] .smaller = true := by decide
def e2411653541722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411653541722 : Closed e2411653541722 ∧ code e2411653541722 = 11207746563930 := by decide
theorem cert_e2411653541722 : check e2411653541722 [[],[],[.under]] .smaller = true := by decide
def e2411653541738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411653541738 : Closed e2411653541738 ∧ code e2411653541738 = 11207746563946 := by decide
theorem cert_e2411653541738 : check e2411653541738 [[],[],[.under]] .smaller = true := by decide
def e2411653542366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2411653542366 : Closed e2411653542366 ∧ code e2411653542366 = 11207746564574 := by decide
theorem cert_e2411653542366 : check e2411653542366 [[],[],[.under]] .smaller = true := by decide
def e2411653542390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2411653542390 : Closed e2411653542390 ∧ code e2411653542390 = 11207746564598 := by decide
theorem cert_e2411653542390 : check e2411653542390 [[],[],[.under]] .smaller = true := by decide
def e2411653542766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2411653542766 : Closed e2411653542766 ∧ code e2411653542766 = 11207746564974 := by decide
theorem cert_e2411653542766 : check e2411653542766 [[],[],[.under]] .smaller = true := by decide
def e2411653542774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2411653542774 : Closed e2411653542774 ∧ code e2411653542774 = 11207746564982 := by decide
theorem cert_e2411653542774 : check e2411653542774 [[],[],[.under]] .smaller = true := by decide
end Blc.Floor43
