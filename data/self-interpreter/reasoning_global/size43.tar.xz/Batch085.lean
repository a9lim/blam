import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e826994778522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826994778522 : Closed e826994778522 ∧ code e826994778522 = 9623087800730 := by decide
theorem cert_e826994778522 : check e826994778522 [] .sourceHead = true := by decide
def e826994779674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826994779674 : Closed e826994779674 ∧ code e826994779674 = 9623087801882 := by decide
theorem cert_e826994779674 : check e826994779674 [] .sourceHead = true := by decide
def e826994825754 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994825754 : Closed e826994825754 ∧ code e826994825754 = 9623087847962 := by decide
theorem cert_e826994825754 : check e826994825754 [] .sourceHead = true := by decide
def e826994827290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826994827290 : Closed e826994827290 ∧ code e826994827290 = 9623087849498 := by decide
theorem cert_e826994827290 : check e826994827290 [] .sourceHead = true := by decide
def e826994827382 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826994827382 : Closed e826994827382 ∧ code e826994827382 = 9623087849590 := by decide
theorem cert_e826994827382 : check e826994827382 [] .sourceHead = true := by decide
def e826994827626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826994827626 : Closed e826994827626 ∧ code e826994827626 = 9623087849834 := by decide
theorem cert_e826994827626 : check e826994827626 [] .sourceHead = true := by decide
def e826994827674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826994827674 : Closed e826994827674 ∧ code e826994827674 = 9623087849882 := by decide
theorem cert_e826994827674 : check e826994827674 [] .sourceHead = true := by decide
def e826994828826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826994828826 : Closed e826994828826 ∧ code e826994828826 = 9623087851034 := by decide
theorem cert_e826994828826 : check e826994828826 [] .sourceHead = true := by decide
def e826994906650 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994906650 : Closed e826994906650 ∧ code e826994906650 = 9623087928858 := by decide
theorem cert_e826994906650 : check e826994906650 [] .sourceHead = true := by decide
def e826994907674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994907674 : Closed e826994907674 ∧ code e826994907674 = 9623087929882 := by decide
theorem cert_e826994907674 : check e826994907674 [] .sourceHead = true := by decide
def e826994911770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994911770 : Closed e826994911770 ∧ code e826994911770 = 9623087933978 := by decide
theorem cert_e826994911770 : check e826994911770 [] .sourceHead = true := by decide
def e826994931226 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994931226 : Closed e826994931226 ∧ code e826994931226 = 9623087953434 := by decide
theorem cert_e826994931226 : check e826994931226 [] .sourceHead = true := by decide
def e826994932250 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994932250 : Closed e826994932250 ∧ code e826994932250 = 9623087954458 := by decide
theorem cert_e826994932250 : check e826994932250 [] .sourceHead = true := by decide
def e826994941978 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826994941978 : Closed e826994941978 ∧ code e826994941978 = 9623087964186 := by decide
theorem cert_e826994941978 : check e826994941978 [] .sourceHead = true := by decide
def e826994942070 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826994942070 : Closed e826994942070 ∧ code e826994942070 = 9623087964278 := by decide
theorem cert_e826994942070 : check e826994942070 [] .sourceHead = true := by decide
def e826994942314 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826994942314 : Closed e826994942314 ∧ code e826994942314 = 9623087964522 := by decide
theorem cert_e826994942314 : check e826994942314 [] .sourceHead = true := by decide
def e826994942362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826994942362 : Closed e826994942362 ∧ code e826994942362 = 9623087964570 := by decide
theorem cert_e826994942362 : check e826994942362 [] .sourceHead = true := by decide
def e826994943514 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826994943514 : Closed e826994943514 ∧ code e826994943514 = 9623087965722 := by decide
theorem cert_e826994943514 : check e826994943514 [] .sourceHead = true := by decide
def e826994956826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826994956826 : Closed e826994956826 ∧ code e826994956826 = 9623087979034 := by decide
theorem cert_e826994956826 : check e826994956826 [] .sourceHead = true := by decide
def e826994958362 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826994958362 : Closed e826994958362 ∧ code e826994958362 = 9623087980570 := by decide
theorem cert_e826994958362 : check e826994958362 [] .sourceHead = true := by decide
def e826994958454 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826994958454 : Closed e826994958454 ∧ code e826994958454 = 9623087980662 := by decide
theorem cert_e826994958454 : check e826994958454 [] .sourceHead = true := by decide
def e826994958698 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826994958698 : Closed e826994958698 ∧ code e826994958698 = 9623087980906 := by decide
theorem cert_e826994958698 : check e826994958698 [] .sourceHead = true := by decide
def e826994958746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826994958746 : Closed e826994958746 ∧ code e826994958746 = 9623087980954 := by decide
theorem cert_e826994958746 : check e826994958746 [] .sourceHead = true := by decide
def e826994959898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826994959898 : Closed e826994959898 ∧ code e826994959898 = 9623087982106 := by decide
theorem cert_e826994959898 : check e826994959898 [] .sourceHead = true := by decide
def e826995863066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995863066 : Closed e826995863066 ∧ code e826995863066 = 9623088885274 := by decide
theorem cert_e826995863066 : check e826995863066 [] .sourceHead = true := by decide
def e826995865114 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995865114 : Closed e826995865114 ∧ code e826995865114 = 9623088887322 := by decide
theorem cert_e826995865114 : check e826995865114 [] .sourceHead = true := by decide
def e826995879450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995879450 : Closed e826995879450 ∧ code e826995879450 = 9623088901658 := by decide
theorem cert_e826995879450 : check e826995879450 [] .sourceHead = true := by decide
def e826995882522 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995882522 : Closed e826995882522 ∧ code e826995882522 = 9623088904730 := by decide
theorem cert_e826995882522 : check e826995882522 [] .sourceHead = true := by decide
def e826995889690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995889690 : Closed e826995889690 ∧ code e826995889690 = 9623088911898 := by decide
theorem cert_e826995889690 : check e826995889690 [] .sourceHead = true := by decide
def e826995890714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995890714 : Closed e826995890714 ∧ code e826995890714 = 9623088912922 := by decide
theorem cert_e826995890714 : check e826995890714 [] .sourceHead = true := by decide
def e826995961370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995961370 : Closed e826995961370 ∧ code e826995961370 = 9623088983578 := by decide
theorem cert_e826995961370 : check e826995961370 [] .sourceHead = true := by decide
def e826995963418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826995963418 : Closed e826995963418 ∧ code e826995963418 = 9623088985626 := by decide
theorem cert_e826995963418 : check e826995963418 [] .sourceHead = true := by decide
def e826996059674 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826996059674 : Closed e826996059674 ∧ code e826996059674 = 9623089081882 := by decide
theorem cert_e826996059674 : check e826996059674 [] .sourceHead = true := by decide
def e826996062746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826996062746 : Closed e826996062746 ∧ code e826996062746 = 9623089084954 := by decide
theorem cert_e826996062746 : check e826996062746 [] .sourceHead = true := by decide
def e826996088858 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826996088858 : Closed e826996088858 ∧ code e826996088858 = 9623089111066 := by decide
theorem cert_e826996088858 : check e826996088858 [] .sourceHead = true := by decide
def e826996088950 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826996088950 : Closed e826996088950 ∧ code e826996088950 = 9623089111158 := by decide
theorem cert_e826996088950 : check e826996088950 [] .sourceHead = true := by decide
def e826996089194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826996089194 : Closed e826996089194 ∧ code e826996089194 = 9623089111402 := by decide
theorem cert_e826996089194 : check e826996089194 [] .sourceHead = true := by decide
def e826996089242 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826996089242 : Closed e826996089242 ∧ code e826996089242 = 9623089111450 := by decide
theorem cert_e826996089242 : check e826996089242 [] .sourceHead = true := by decide
def e826996090394 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826996090394 : Closed e826996090394 ∧ code e826996090394 = 9623089112602 := by decide
theorem cert_e826996090394 : check e826996090394 [] .sourceHead = true := by decide
def e826996110874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826996110874 : Closed e826996110874 ∧ code e826996110874 = 9623089133082 := by decide
theorem cert_e826996110874 : check e826996110874 [] .sourceHead = true := by decide
def e826996111898 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826996111898 : Closed e826996111898 ∧ code e826996111898 = 9623089134106 := by decide
theorem cert_e826996111898 : check e826996111898 [] .sourceHead = true := by decide
def e826996121626 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826996121626 : Closed e826996121626 ∧ code e826996121626 = 9623089143834 := by decide
theorem cert_e826996121626 : check e826996121626 [] .sourceHead = true := by decide
def e826996121718 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826996121718 : Closed e826996121718 ∧ code e826996121718 = 9623089143926 := by decide
theorem cert_e826996121718 : check e826996121718 [] .sourceHead = true := by decide
def e826996121962 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826996121962 : Closed e826996121962 ∧ code e826996121962 = 9623089144170 := by decide
theorem cert_e826996121962 : check e826996121962 [] .sourceHead = true := by decide
def e826996122010 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826996122010 : Closed e826996122010 ∧ code e826996122010 = 9623089144218 := by decide
theorem cert_e826996122010 : check e826996122010 [] .sourceHead = true := by decide
def e826996123162 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826996123162 : Closed e826996123162 ∧ code e826996123162 = 9623089145370 := by decide
theorem cert_e826996123162 : check e826996123162 [] .sourceHead = true := by decide
def e826996206958 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e826996206958 : Closed e826996206958 ∧ code e826996206958 = 9623089229166 := by decide
theorem cert_e826996206958 : check e826996206958 [] .sourceHead = true := by decide
def e826996206966 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e826996206966 : Closed e826996206966 ∧ code e826996206966 = 9623089229174 := by decide
theorem cert_e826996206966 : check e826996206966 [] .sourceHead = true := by decide
def e826996207022 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e826996207022 : Closed e826996207022 ∧ code e826996207022 = 9623089229230 := by decide
theorem cert_e826996207022 : check e826996207022 [] .sourceHead = true := by decide
def e826996207034 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e826996207034 : Closed e826996207034 ∧ code e826996207034 = 9623089229242 := by decide
theorem cert_e826996207034 : check e826996207034 [] .sourceHead = true := by decide
def e826996207062 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e826996207062 : Closed e826996207062 ∧ code e826996207062 = 9623089229270 := by decide
theorem cert_e826996207062 : check e826996207062 [] .sourceHead = true := by decide
def e826996207066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e826996207066 : Closed e826996207066 ∧ code e826996207066 = 9623089229274 := by decide
theorem cert_e826996207066 : check e826996207066 [] .sourceHead = true := by decide
def e826996207278 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e826996207278 : Closed e826996207278 ∧ code e826996207278 = 9623089229486 := by decide
theorem cert_e826996207278 : check e826996207278 [] .sourceHead = true := by decide
def e826996207290 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e826996207290 : Closed e826996207290 ∧ code e826996207290 = 9623089229498 := by decide
theorem cert_e826996207290 : check e826996207290 [] .sourceHead = true := by decide
def e826996207338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e826996207338 : Closed e826996207338 ∧ code e826996207338 = 9623089229546 := by decide
theorem cert_e826996207338 : check e826996207338 [] .sourceHead = true := by decide
def e826996207446 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e826996207446 : Closed e826996207446 ∧ code e826996207446 = 9623089229654 := by decide
theorem cert_e826996207446 : check e826996207446 [] .sourceHead = true := by decide
def e826996207450 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e826996207450 : Closed e826996207450 ∧ code e826996207450 = 9623089229658 := by decide
theorem cert_e826996207450 : check e826996207450 [] .sourceHead = true := by decide
def e826996207466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e826996207466 : Closed e826996207466 ∧ code e826996207466 = 9623089229674 := by decide
theorem cert_e826996207466 : check e826996207466 [] .sourceHead = true := by decide
def e826996208494 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e826996208494 : Closed e826996208494 ∧ code e826996208494 = 9623089230702 := by decide
theorem cert_e826996208494 : check e826996208494 [] .sourceHead = true := by decide
def e826996208502 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e826996208502 : Closed e826996208502 ∧ code e826996208502 = 9623089230710 := by decide
theorem cert_e826996208502 : check e826996208502 [] .sourceHead = true := by decide
def e826996208558 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e826996208558 : Closed e826996208558 ∧ code e826996208558 = 9623089230766 := by decide
theorem cert_e826996208558 : check e826996208558 [] .sourceHead = true := by decide
def e826996208570 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e826996208570 : Closed e826996208570 ∧ code e826996208570 = 9623089230778 := by decide
theorem cert_e826996208570 : check e826996208570 [] .sourceHead = true := by decide
def e826996208598 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e826996208598 : Closed e826996208598 ∧ code e826996208598 = 9623089230806 := by decide
theorem cert_e826996208598 : check e826996208598 [] .sourceHead = true := by decide
def e826996208602 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e826996208602 : Closed e826996208602 ∧ code e826996208602 = 9623089230810 := by decide
theorem cert_e826996208602 : check e826996208602 [] .sourceHead = true := by decide
def e826996208878 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e826996208878 : Closed e826996208878 ∧ code e826996208878 = 9623089231086 := by decide
theorem cert_e826996208878 : check e826996208878 [] .sourceHead = true := by decide
def e826996208886 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e826996208886 : Closed e826996208886 ∧ code e826996208886 = 9623089231094 := by decide
theorem cert_e826996208886 : check e826996208886 [] .sourceHead = true := by decide
def e826996209262 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e826996209262 : Closed e826996209262 ∧ code e826996209262 = 9623089231470 := by decide
theorem cert_e826996209262 : check e826996209262 [] .sourceHead = true := by decide
def e826996209274 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e826996209274 : Closed e826996209274 ∧ code e826996209274 = 9623089231482 := by decide
theorem cert_e826996209274 : check e826996209274 [] .sourceHead = true := by decide
def e826996209462 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e826996209462 : Closed e826996209462 ∧ code e826996209462 = 9623089231670 := by decide
theorem cert_e826996209462 : check e826996209462 [] .sourceHead = true := by decide
def e826996209466 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e826996209466 : Closed e826996209466 ∧ code e826996209466 = 9623089231674 := by decide
theorem cert_e826996209466 : check e826996209466 [] .sourceHead = true := by decide
def e826996210094 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e826996210094 : Closed e826996210094 ∧ code e826996210094 = 9623089232302 := by decide
theorem cert_e826996210094 : check e826996210094 [] .sourceHead = true := by decide
def e826996210106 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e826996210106 : Closed e826996210106 ∧ code e826996210106 = 9623089232314 := by decide
theorem cert_e826996210106 : check e826996210106 [] .sourceHead = true := by decide
def e826996210154 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e826996210154 : Closed e826996210154 ∧ code e826996210154 = 9623089232362 := by decide
theorem cert_e826996210154 : check e826996210154 [] .sourceHead = true := by decide
def e826996210286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e826996210286 : Closed e826996210286 ∧ code e826996210286 = 9623089232494 := by decide
theorem cert_e826996210286 : check e826996210286 [] .sourceHead = true := by decide
def e826996210298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e826996210298 : Closed e826996210298 ∧ code e826996210298 = 9623089232506 := by decide
theorem cert_e826996210298 : check e826996210298 [] .sourceHead = true := by decide
def e826996210586 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e826996210586 : Closed e826996210586 ∧ code e826996210586 = 9623089232794 := by decide
theorem cert_e826996210586 : check e826996210586 [] .sourceHead = true := by decide
def e826996210902 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e826996210902 : Closed e826996210902 ∧ code e826996210902 = 9623089233110 := by decide
theorem cert_e826996210902 : check e826996210902 [] .sourceHead = true := by decide
def e826996210906 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e826996210906 : Closed e826996210906 ∧ code e826996210906 = 9623089233114 := by decide
theorem cert_e826996210906 : check e826996210906 [] .sourceHead = true := by decide
def e826996210922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e826996210922 : Closed e826996210922 ∧ code e826996210922 = 9623089233130 := by decide
theorem cert_e826996210922 : check e826996210922 [] .sourceHead = true := by decide
def e826996210998 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e826996210998 : Closed e826996210998 ∧ code e826996210998 = 9623089233206 := by decide
theorem cert_e826996210998 : check e826996210998 [] .sourceHead = true := by decide
def e826996211002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e826996211002 : Closed e826996211002 ∧ code e826996211002 = 9623089233210 := by decide
theorem cert_e826996211002 : check e826996211002 [] .sourceHead = true := by decide
def e826996211098 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e826996211098 : Closed e826996211098 ∧ code e826996211098 = 9623089233306 := by decide
theorem cert_e826996211098 : check e826996211098 [] .sourceHead = true := by decide
def e826996214638 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e826996214638 : Closed e826996214638 ∧ code e826996214638 = 9623089236846 := by decide
theorem cert_e826996214638 : check e826996214638 [] .sourceHead = true := by decide
def e826996214646 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e826996214646 : Closed e826996214646 ∧ code e826996214646 = 9623089236854 := by decide
theorem cert_e826996214646 : check e826996214646 [] .sourceHead = true := by decide
def e826996214702 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e826996214702 : Closed e826996214702 ∧ code e826996214702 = 9623089236910 := by decide
theorem cert_e826996214702 : check e826996214702 [] .sourceHead = true := by decide
def e826996214714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e826996214714 : Closed e826996214714 ∧ code e826996214714 = 9623089236922 := by decide
theorem cert_e826996214714 : check e826996214714 [] .sourceHead = true := by decide
def e826996214742 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e826996214742 : Closed e826996214742 ∧ code e826996214742 = 9623089236950 := by decide
theorem cert_e826996214742 : check e826996214742 [] .sourceHead = true := by decide
def e826996214746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e826996214746 : Closed e826996214746 ∧ code e826996214746 = 9623089236954 := by decide
theorem cert_e826996214746 : check e826996214746 [] .sourceHead = true := by decide
def e826996215022 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e826996215022 : Closed e826996215022 ∧ code e826996215022 = 9623089237230 := by decide
theorem cert_e826996215022 : check e826996215022 [] .sourceHead = true := by decide
def e826996215030 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e826996215030 : Closed e826996215030 ∧ code e826996215030 = 9623089237238 := by decide
theorem cert_e826996215030 : check e826996215030 [] .sourceHead = true := by decide
def e826996215406 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e826996215406 : Closed e826996215406 ∧ code e826996215406 = 9623089237614 := by decide
theorem cert_e826996215406 : check e826996215406 [] .sourceHead = true := by decide
def e826996215418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e826996215418 : Closed e826996215418 ∧ code e826996215418 = 9623089237626 := by decide
theorem cert_e826996215418 : check e826996215418 [] .sourceHead = true := by decide
def e826996215606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e826996215606 : Closed e826996215606 ∧ code e826996215606 = 9623089237814 := by decide
theorem cert_e826996215606 : check e826996215606 [] .sourceHead = true := by decide
def e826996215610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e826996215610 : Closed e826996215610 ∧ code e826996215610 = 9623089237818 := by decide
theorem cert_e826996215610 : check e826996215610 [] .sourceHead = true := by decide
def e826996221358 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e826996221358 : Closed e826996221358 ∧ code e826996221358 = 9623089243566 := by decide
theorem cert_e826996221358 : check e826996221358 [] .sourceHead = true := by decide
def e826996221370 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e826996221370 : Closed e826996221370 ∧ code e826996221370 = 9623089243578 := by decide
theorem cert_e826996221370 : check e826996221370 [] .sourceHead = true := by decide
def e826996221418 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e826996221418 : Closed e826996221418 ∧ code e826996221418 = 9623089243626 := by decide
theorem cert_e826996221418 : check e826996221418 [] .sourceHead = true := by decide
def e826996221550 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e826996221550 : Closed e826996221550 ∧ code e826996221550 = 9623089243758 := by decide
theorem cert_e826996221550 : check e826996221550 [] .sourceHead = true := by decide
def e826996221562 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e826996221562 : Closed e826996221562 ∧ code e826996221562 = 9623089243770 := by decide
theorem cert_e826996221562 : check e826996221562 [] .sourceHead = true := by decide
def e826996221850 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e826996221850 : Closed e826996221850 ∧ code e826996221850 = 9623089244058 := by decide
theorem cert_e826996221850 : check e826996221850 [] .sourceHead = true := by decide
def e826996224726 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e826996224726 : Closed e826996224726 ∧ code e826996224726 = 9623089246934 := by decide
theorem cert_e826996224726 : check e826996224726 [] .sourceHead = true := by decide
def e826996224730 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e826996224730 : Closed e826996224730 ∧ code e826996224730 = 9623089246938 := by decide
theorem cert_e826996224730 : check e826996224730 [] .sourceHead = true := by decide
def e826996224746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e826996224746 : Closed e826996224746 ∧ code e826996224746 = 9623089246954 := by decide
theorem cert_e826996224746 : check e826996224746 [] .sourceHead = true := by decide
def e826996224822 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e826996224822 : Closed e826996224822 ∧ code e826996224822 = 9623089247030 := by decide
theorem cert_e826996224822 : check e826996224822 [] .sourceHead = true := by decide
def e826996224826 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e826996224826 : Closed e826996224826 ∧ code e826996224826 = 9623089247034 := by decide
theorem cert_e826996224826 : check e826996224826 [] .sourceHead = true := by decide
def e826996224922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e826996224922 : Closed e826996224922 ∧ code e826996224922 = 9623089247130 := by decide
theorem cert_e826996224922 : check e826996224922 [] .sourceHead = true := by decide
def e826997583386 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826997583386 : Closed e826997583386 ∧ code e826997583386 = 9623090605594 := by decide
theorem cert_e826997583386 : check e826997583386 [] .sourceHead = true := by decide
def e826997586458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826997586458 : Closed e826997586458 ∧ code e826997586458 = 9623090608666 := by decide
theorem cert_e826997586458 : check e826997586458 [] .sourceHead = true := by decide
def e826997598746 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826997598746 : Closed e826997598746 ∧ code e826997598746 = 9623090620954 := by decide
theorem cert_e826997598746 : check e826997598746 [] .sourceHead = true := by decide
def e826997632538 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826997632538 : Closed e826997632538 ∧ code e826997632538 = 9623090654746 := by decide
theorem cert_e826997632538 : check e826997632538 [] .sourceHead = true := by decide
def e826997635610 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826997635610 : Closed e826997635610 ∧ code e826997635610 = 9623090657818 := by decide
theorem cert_e826997635610 : check e826997635610 [] .sourceHead = true := by decide
def e826997661722 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826997661722 : Closed e826997661722 ∧ code e826997661722 = 9623090683930 := by decide
theorem cert_e826997661722 : check e826997661722 [] .sourceHead = true := by decide
def e826997661814 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826997661814 : Closed e826997661814 ∧ code e826997661814 = 9623090684022 := by decide
theorem cert_e826997661814 : check e826997661814 [] .sourceHead = true := by decide
def e826997662058 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826997662058 : Closed e826997662058 ∧ code e826997662058 = 9623090684266 := by decide
theorem cert_e826997662058 : check e826997662058 [] .sourceHead = true := by decide
def e826997662106 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826997662106 : Closed e826997662106 ∧ code e826997662106 = 9623090684314 := by decide
theorem cert_e826997662106 : check e826997662106 [] .sourceHead = true := by decide
def e826997663258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826997663258 : Closed e826997663258 ∧ code e826997663258 = 9623090685466 := by decide
theorem cert_e826997663258 : check e826997663258 [] .sourceHead = true := by decide
def e826997709338 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826997709338 : Closed e826997709338 ∧ code e826997709338 = 9623090731546 := by decide
theorem cert_e826997709338 : check e826997709338 [] .sourceHead = true := by decide
def e826997710874 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826997710874 : Closed e826997710874 ∧ code e826997710874 = 9623090733082 := by decide
theorem cert_e826997710874 : check e826997710874 [] .sourceHead = true := by decide
def e826997710966 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826997710966 : Closed e826997710966 ∧ code e826997710966 = 9623090733174 := by decide
theorem cert_e826997710966 : check e826997710966 [] .sourceHead = true := by decide
def e826997711210 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826997711210 : Closed e826997711210 ∧ code e826997711210 = 9623090733418 := by decide
theorem cert_e826997711210 : check e826997711210 [] .sourceHead = true := by decide
def e826997711258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826997711258 : Closed e826997711258 ∧ code e826997711258 = 9623090733466 := by decide
theorem cert_e826997711258 : check e826997711258 [] .sourceHead = true := by decide
def e826997712410 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826997712410 : Closed e826997712410 ∧ code e826997712410 = 9623090734618 := by decide
theorem cert_e826997712410 : check e826997712410 [] .sourceHead = true := by decide
def e826998445594 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826998445594 : Closed e826998445594 ∧ code e826998445594 = 9623091467802 := by decide
theorem cert_e826998445594 : check e826998445594 [] .sourceHead = true := by decide
def e826998446618 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826998446618 : Closed e826998446618 ∧ code e826998446618 = 9623091468826 := by decide
theorem cert_e826998446618 : check e826998446618 [] .sourceHead = true := by decide
def e826998450714 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826998450714 : Closed e826998450714 ∧ code e826998450714 = 9623091472922 := by decide
theorem cert_e826998450714 : check e826998450714 [] .sourceHead = true := by decide
def e826998470170 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826998470170 : Closed e826998470170 ∧ code e826998470170 = 9623091492378 := by decide
theorem cert_e826998470170 : check e826998470170 [] .sourceHead = true := by decide
def e826998471194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826998471194 : Closed e826998471194 ∧ code e826998471194 = 9623091493402 := by decide
theorem cert_e826998471194 : check e826998471194 [] .sourceHead = true := by decide
def e826998480922 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826998480922 : Closed e826998480922 ∧ code e826998480922 = 9623091503130 := by decide
theorem cert_e826998480922 : check e826998480922 [] .sourceHead = true := by decide
def e826998481014 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826998481014 : Closed e826998481014 ∧ code e826998481014 = 9623091503222 := by decide
theorem cert_e826998481014 : check e826998481014 [] .sourceHead = true := by decide
def e826998481258 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826998481258 : Closed e826998481258 ∧ code e826998481258 = 9623091503466 := by decide
theorem cert_e826998481258 : check e826998481258 [] .sourceHead = true := by decide
def e826998481306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826998481306 : Closed e826998481306 ∧ code e826998481306 = 9623091503514 := by decide
theorem cert_e826998481306 : check e826998481306 [] .sourceHead = true := by decide
def e826998482458 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826998482458 : Closed e826998482458 ∧ code e826998482458 = 9623091504666 := by decide
theorem cert_e826998482458 : check e826998482458 [] .sourceHead = true := by decide
def e826998495770 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e826998495770 : Closed e826998495770 ∧ code e826998495770 = 9623091517978 := by decide
theorem cert_e826998495770 : check e826998495770 [] .sourceHead = true := by decide
def e826998497306 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e826998497306 : Closed e826998497306 ∧ code e826998497306 = 9623091519514 := by decide
theorem cert_e826998497306 : check e826998497306 [] .sourceHead = true := by decide
def e826998497398 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e826998497398 : Closed e826998497398 ∧ code e826998497398 = 9623091519606 := by decide
theorem cert_e826998497398 : check e826998497398 [] .sourceHead = true := by decide
def e826998497642 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e826998497642 : Closed e826998497642 ∧ code e826998497642 = 9623091519850 := by decide
theorem cert_e826998497642 : check e826998497642 [] .sourceHead = true := by decide
def e826998497690 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e826998497690 : Closed e826998497690 ∧ code e826998497690 = 9623091519898 := by decide
theorem cert_e826998497690 : check e826998497690 [] .sourceHead = true := by decide
def e826998498842 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e826998498842 : Closed e826998498842 ∧ code e826998498842 = 9623091521050 := by decide
theorem cert_e826998498842 : check e826998498842 [] .sourceHead = true := by decide
def e826999352686 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e826999352686 : Closed e826999352686 ∧ code e826999352686 = 9623092374894 := by decide
theorem cert_e826999352686 : check e826999352686 [] .sourceHead = true := by decide
def e826999352694 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e826999352694 : Closed e826999352694 ∧ code e826999352694 = 9623092374902 := by decide
theorem cert_e826999352694 : check e826999352694 [] .sourceHead = true := by decide
def e826999352750 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e826999352750 : Closed e826999352750 ∧ code e826999352750 = 9623092374958 := by decide
theorem cert_e826999352750 : check e826999352750 [] .sourceHead = true := by decide
def e826999352762 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e826999352762 : Closed e826999352762 ∧ code e826999352762 = 9623092374970 := by decide
theorem cert_e826999352762 : check e826999352762 [] .sourceHead = true := by decide
def e826999352790 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e826999352790 : Closed e826999352790 ∧ code e826999352790 = 9623092374998 := by decide
theorem cert_e826999352790 : check e826999352790 [] .sourceHead = true := by decide
def e826999352794 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e826999352794 : Closed e826999352794 ∧ code e826999352794 = 9623092375002 := by decide
theorem cert_e826999352794 : check e826999352794 [] .sourceHead = true := by decide
def e826999353006 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e826999353006 : Closed e826999353006 ∧ code e826999353006 = 9623092375214 := by decide
theorem cert_e826999353006 : check e826999353006 [] .sourceHead = true := by decide
def e826999353018 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e826999353018 : Closed e826999353018 ∧ code e826999353018 = 9623092375226 := by decide
theorem cert_e826999353018 : check e826999353018 [] .sourceHead = true := by decide
def e826999353066 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e826999353066 : Closed e826999353066 ∧ code e826999353066 = 9623092375274 := by decide
theorem cert_e826999353066 : check e826999353066 [] .sourceHead = true := by decide
def e826999353174 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e826999353174 : Closed e826999353174 ∧ code e826999353174 = 9623092375382 := by decide
theorem cert_e826999353174 : check e826999353174 [] .sourceHead = true := by decide
def e826999353178 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e826999353178 : Closed e826999353178 ∧ code e826999353178 = 9623092375386 := by decide
theorem cert_e826999353178 : check e826999353178 [] .sourceHead = true := by decide
def e826999353194 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e826999353194 : Closed e826999353194 ∧ code e826999353194 = 9623092375402 := by decide
theorem cert_e826999353194 : check e826999353194 [] .sourceHead = true := by decide
def e826999354222 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e826999354222 : Closed e826999354222 ∧ code e826999354222 = 9623092376430 := by decide
theorem cert_e826999354222 : check e826999354222 [] .sourceHead = true := by decide
def e826999354230 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e826999354230 : Closed e826999354230 ∧ code e826999354230 = 9623092376438 := by decide
theorem cert_e826999354230 : check e826999354230 [] .sourceHead = true := by decide
def e826999354286 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e826999354286 : Closed e826999354286 ∧ code e826999354286 = 9623092376494 := by decide
theorem cert_e826999354286 : check e826999354286 [] .sourceHead = true := by decide
def e826999354298 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e826999354298 : Closed e826999354298 ∧ code e826999354298 = 9623092376506 := by decide
theorem cert_e826999354298 : check e826999354298 [] .sourceHead = true := by decide
def e826999354326 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e826999354326 : Closed e826999354326 ∧ code e826999354326 = 9623092376534 := by decide
theorem cert_e826999354326 : check e826999354326 [] .sourceHead = true := by decide
def e826999354330 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e826999354330 : Closed e826999354330 ∧ code e826999354330 = 9623092376538 := by decide
theorem cert_e826999354330 : check e826999354330 [] .sourceHead = true := by decide
def e826999354606 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e826999354606 : Closed e826999354606 ∧ code e826999354606 = 9623092376814 := by decide
theorem cert_e826999354606 : check e826999354606 [] .sourceHead = true := by decide
def e826999354614 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e826999354614 : Closed e826999354614 ∧ code e826999354614 = 9623092376822 := by decide
theorem cert_e826999354614 : check e826999354614 [] .sourceHead = true := by decide
def e826999354990 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e826999354990 : Closed e826999354990 ∧ code e826999354990 = 9623092377198 := by decide
theorem cert_e826999354990 : check e826999354990 [] .sourceHead = true := by decide
def e826999355002 : Term := (.lam (.app (.var 0) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e826999355002 : Closed e826999355002 ∧ code e826999355002 = 9623092377210 := by decide
theorem cert_e826999355002 : check e826999355002 [] .sourceHead = true := by decide
end Blc.Floor43
