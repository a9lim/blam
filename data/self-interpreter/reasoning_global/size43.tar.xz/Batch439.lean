import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422375124790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422375124790 : Closed e2422375124790 ∧ code e2422375124790 = 11218468146998 := by decide
theorem cert_e2422375124790 : check e2422375124790 [[],[]] .smaller = true := by decide
def e2422375124794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422375124794 : Closed e2422375124794 ∧ code e2422375124794 = 11218468147002 := by decide
theorem cert_e2422375124794 : check e2422375124794 [[],[]] .smaller = true := by decide
def e2422375124926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 4))))))))))
theorem wire_e2422375124926 : Closed e2422375124926 ∧ code e2422375124926 = 11218468147134 := by decide
theorem cert_e2422375124926 : check e2422375124926 [[],[]] .three = true := by decide
def e2422375124958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 4) (.var 3))))))))))
theorem wire_e2422375124958 : Closed e2422375124958 ∧ code e2422375124958 = 11218468147166 := by decide
theorem cert_e2422375124958 : check e2422375124958 [[],[]] .three = true := by decide
def e2422375131990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422375131990 : Closed e2422375131990 ∧ code e2422375131990 = 11218468154198 := by decide
theorem cert_e2422375131990 : check e2422375131990 [[],[]] .smaller = true := by decide
def e2422375131994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422375131994 : Closed e2422375131994 ∧ code e2422375131994 = 11218468154202 := by decide
theorem cert_e2422375131994 : check e2422375131994 [[],[]] .smaller = true := by decide
def e2422375132010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422375132010 : Closed e2422375132010 ∧ code e2422375132010 = 11218468154218 := by decide
theorem cert_e2422375132010 : check e2422375132010 [[],[]] .smaller = true := by decide
def e2422375132074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422375132074 : Closed e2422375132074 ∧ code e2422375132074 = 11218468154282 := by decide
theorem cert_e2422375132074 : check e2422375132074 [[],[]] .smaller = true := by decide
def e2422375132182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)))))))))
theorem wire_e2422375132182 : Closed e2422375132182 ∧ code e2422375132182 = 11218468154390 := by decide
theorem cert_e2422375132182 : check e2422375132182 [[],[]] .smaller = true := by decide
def e2422375132254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 3)))))))))
theorem wire_e2422375132254 : Closed e2422375132254 ∧ code e2422375132254 = 11218468154462 := by decide
theorem cert_e2422375132254 : check e2422375132254 [[],[]] .three = true := by decide
def e2422375132278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422375132278 : Closed e2422375132278 ∧ code e2422375132278 = 11218468154486 := by decide
theorem cert_e2422375132278 : check e2422375132278 [[],[]] .smaller = true := by decide
def e2422375132374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422375132374 : Closed e2422375132374 ∧ code e2422375132374 = 11218468154582 := by decide
theorem cert_e2422375132374 : check e2422375132374 [[],[]] .smaller = true := by decide
def e2422375132378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422375132378 : Closed e2422375132378 ∧ code e2422375132378 = 11218468154586 := by decide
theorem cert_e2422375132378 : check e2422375132378 [[],[]] .smaller = true := by decide
def e2422375132394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422375132394 : Closed e2422375132394 ∧ code e2422375132394 = 11218468154602 := by decide
theorem cert_e2422375132394 : check e2422375132394 [[],[]] .smaller = true := by decide
def e2422375132470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422375132470 : Closed e2422375132470 ∧ code e2422375132470 = 11218468154678 := by decide
theorem cert_e2422375132470 : check e2422375132470 [[],[]] .smaller = true := by decide
def e2422375132474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422375132474 : Closed e2422375132474 ∧ code e2422375132474 = 11218468154682 := by decide
theorem cert_e2422375132474 : check e2422375132474 [[],[]] .smaller = true := by decide
def e2422375132546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422375132546 : Closed e2422375132546 ∧ code e2422375132546 = 11218468154754 := by decide
theorem cert_e2422375132546 : check e2422375132546 [[],[]] .smaller = true := by decide
def e2422375132558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422375132558 : Closed e2422375132558 ∧ code e2422375132558 = 11218468154766 := by decide
theorem cert_e2422375132558 : check e2422375132558 [[],[]] .smaller = true := by decide
def e2422375132570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422375132570 : Closed e2422375132570 ∧ code e2422375132570 = 11218468154778 := by decide
theorem cert_e2422375132570 : check e2422375132570 [[],[]] .smaller = true := by decide
def e2422375132638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2422375132638 : Closed e2422375132638 ∧ code e2422375132638 = 11218468154846 := by decide
theorem cert_e2422375132638 : check e2422375132638 [[],[]] .three = true := by decide
def e2422375132642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.lam (.var 0))))))))))
theorem wire_e2422375132642 : Closed e2422375132642 ∧ code e2422375132642 = 11218468154850 := by decide
theorem cert_e2422375132642 : check e2422375132642 [[],[]] .three = true := by decide
def e2422375132654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2422375132654 : Closed e2422375132654 ∧ code e2422375132654 = 11218468154862 := by decide
theorem cert_e2422375132654 : check e2422375132654 [[],[]] .three = true := by decide
def e2422375132682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422375132682 : Closed e2422375132682 ∧ code e2422375132682 = 11218468154890 := by decide
theorem cert_e2422375132682 : check e2422375132682 [[],[]] .smaller = true := by decide
def e2422375132718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422375132718 : Closed e2422375132718 ∧ code e2422375132718 = 11218468154926 := by decide
theorem cert_e2422375132718 : check e2422375132718 [[],[]] .smaller = true := by decide
def e2422375132726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422375132726 : Closed e2422375132726 ∧ code e2422375132726 = 11218468154934 := by decide
theorem cert_e2422375132726 : check e2422375132726 [[],[]] .smaller = true := by decide
def e2422375132730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422375132730 : Closed e2422375132730 ∧ code e2422375132730 = 11218468154938 := by decide
theorem cert_e2422375132730 : check e2422375132730 [[],[]] .smaller = true := by decide
def e2422375132778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422375132778 : Closed e2422375132778 ∧ code e2422375132778 = 11218468154986 := by decide
theorem cert_e2422375132778 : check e2422375132778 [[],[]] .smaller = true := by decide
def e2422375132802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422375132802 : Closed e2422375132802 ∧ code e2422375132802 = 11218468155010 := by decide
theorem cert_e2422375132802 : check e2422375132802 [[],[]] .smaller = true := by decide
def e2422375132814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422375132814 : Closed e2422375132814 ∧ code e2422375132814 = 11218468155022 := by decide
theorem cert_e2422375132814 : check e2422375132814 [[],[]] .smaller = true := by decide
def e2422375132826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422375132826 : Closed e2422375132826 ∧ code e2422375132826 = 11218468155034 := by decide
theorem cert_e2422375132826 : check e2422375132826 [[],[]] .smaller = true := by decide
def e2422375132870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422375132870 : Closed e2422375132870 ∧ code e2422375132870 = 11218468155078 := by decide
theorem cert_e2422375132870 : check e2422375132870 [[],[]] .smaller = true := by decide
def e2422375132894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e2422375132894 : Closed e2422375132894 ∧ code e2422375132894 = 11218468155102 := by decide
theorem cert_e2422375132894 : check e2422375132894 [[],[]] .three = true := by decide
def e2422375132898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422375132898 : Closed e2422375132898 ∧ code e2422375132898 = 11218468155106 := by decide
theorem cert_e2422375132898 : check e2422375132898 [[],[]] .smaller = true := by decide
def e2422375132910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e2422375132910 : Closed e2422375132910 ∧ code e2422375132910 = 11218468155118 := by decide
theorem cert_e2422375132910 : check e2422375132910 [[],[]] .smaller = true := by decide
def e2422375132918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e2422375132918 : Closed e2422375132918 ∧ code e2422375132918 = 11218468155126 := by decide
theorem cert_e2422375132918 : check e2422375132918 [[],[]] .three = true := by decide
def e2422375132950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422375132950 : Closed e2422375132950 ∧ code e2422375132950 = 11218468155158 := by decide
theorem cert_e2422375132950 : check e2422375132950 [[],[]] .smaller = true := by decide
def e2422375133022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2422375133022 : Closed e2422375133022 ∧ code e2422375133022 = 11218468155230 := by decide
theorem cert_e2422375133022 : check e2422375133022 [[],[]] .three = true := by decide
def e2422375133026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422375133026 : Closed e2422375133026 ∧ code e2422375133026 = 11218468155234 := by decide
theorem cert_e2422375133026 : check e2422375133026 [[],[]] .smaller = true := by decide
def e2422375133038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e2422375133038 : Closed e2422375133038 ∧ code e2422375133038 = 11218468155246 := by decide
theorem cert_e2422375133038 : check e2422375133038 [[],[]] .smaller = true := by decide
def e2422375133046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e2422375133046 : Closed e2422375133046 ∧ code e2422375133046 = 11218468155254 := by decide
theorem cert_e2422375133046 : check e2422375133046 [[],[]] .smaller = true := by decide
def e2422375133050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2422375133050 : Closed e2422375133050 ∧ code e2422375133050 = 11218468155258 := by decide
theorem cert_e2422375133050 : check e2422375133050 [[],[]] .three = true := by decide
def e2422375133066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422375133066 : Closed e2422375133066 ∧ code e2422375133066 = 11218468155274 := by decide
theorem cert_e2422375133066 : check e2422375133066 [[],[]] .three = true := by decide
def e2422375133090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422375133090 : Closed e2422375133090 ∧ code e2422375133090 = 11218468155298 := by decide
theorem cert_e2422375133090 : check e2422375133090 [[],[]] .three = true := by decide
def e2422375133102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2422375133102 : Closed e2422375133102 ∧ code e2422375133102 = 11218468155310 := by decide
theorem cert_e2422375133102 : check e2422375133102 [[],[]] .three = true := by decide
def e2422375133110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e2422375133110 : Closed e2422375133110 ∧ code e2422375133110 = 11218468155318 := by decide
theorem cert_e2422375133110 : check e2422375133110 [[],[]] .three = true := by decide
def e2422375133114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2422375133114 : Closed e2422375133114 ∧ code e2422375133114 = 11218468155322 := by decide
theorem cert_e2422375133114 : check e2422375133114 [[],[]] .three = true := by decide
def e2422375133310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 5)))))))))))
theorem wire_e2422375133310 : Closed e2422375133310 ∧ code e2422375133310 = 11218468155518 := by decide
theorem cert_e2422375133310 : check e2422375133310 [[],[]] .three = true := by decide
def e2422375133422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422375133422 : Closed e2422375133422 ∧ code e2422375133422 = 11218468155630 := by decide
theorem cert_e2422375133422 : check e2422375133422 [[],[]] .smaller = true := by decide
def e2422375133430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422375133430 : Closed e2422375133430 ∧ code e2422375133430 = 11218468155638 := by decide
theorem cert_e2422375133430 : check e2422375133430 [[],[]] .smaller = true := by decide
def e2422375133910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422375133910 : Closed e2422375133910 ∧ code e2422375133910 = 11218468156118 := by decide
theorem cert_e2422375133910 : check e2422375133910 [[],[]] .smaller = true := by decide
def e2422375133914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422375133914 : Closed e2422375133914 ∧ code e2422375133914 = 11218468156122 := by decide
theorem cert_e2422375133914 : check e2422375133914 [[],[]] .smaller = true := by decide
def e2422375133930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422375133930 : Closed e2422375133930 ∧ code e2422375133930 = 11218468156138 := by decide
theorem cert_e2422375133930 : check e2422375133930 [[],[]] .smaller = true := by decide
def e2422375134006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422375134006 : Closed e2422375134006 ∧ code e2422375134006 = 11218468156214 := by decide
theorem cert_e2422375134006 : check e2422375134006 [[],[]] .smaller = true := by decide
def e2422375134010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422375134010 : Closed e2422375134010 ∧ code e2422375134010 = 11218468156218 := by decide
theorem cert_e2422375134010 : check e2422375134010 [[],[]] .smaller = true := by decide
def e2422375134082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422375134082 : Closed e2422375134082 ∧ code e2422375134082 = 11218468156290 := by decide
theorem cert_e2422375134082 : check e2422375134082 [[],[]] .smaller = true := by decide
def e2422375134094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422375134094 : Closed e2422375134094 ∧ code e2422375134094 = 11218468156302 := by decide
theorem cert_e2422375134094 : check e2422375134094 [[],[]] .smaller = true := by decide
def e2422375134106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375134106 : Closed e2422375134106 ∧ code e2422375134106 = 11218468156314 := by decide
theorem cert_e2422375134106 : check e2422375134106 [[],[]] .smaller = true := by decide
def e2422375134174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2422375134174 : Closed e2422375134174 ∧ code e2422375134174 = 11218468156382 := by decide
theorem cert_e2422375134174 : check e2422375134174 [[],[]] .three = true := by decide
def e2422375134178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.var 0)))))))))))
theorem wire_e2422375134178 : Closed e2422375134178 ∧ code e2422375134178 = 11218468156386 := by decide
theorem cert_e2422375134178 : check e2422375134178 [[],[]] .three = true := by decide
def e2422375134190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2422375134190 : Closed e2422375134190 ∧ code e2422375134190 = 11218468156398 := by decide
theorem cert_e2422375134190 : check e2422375134190 [[],[]] .three = true := by decide
def e2422375135258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422375135258 : Closed e2422375135258 ∧ code e2422375135258 = 11218468157466 := by decide
theorem cert_e2422375135258 : check e2422375135258 [[],[]] .smaller = true := by decide
def e2422375135294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422375135294 : Closed e2422375135294 ∧ code e2422375135294 = 11218468157502 := by decide
theorem cert_e2422375135294 : check e2422375135294 [[],[]] .smaller = true := by decide
def e2422375135342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422375135342 : Closed e2422375135342 ∧ code e2422375135342 = 11218468157550 := by decide
theorem cert_e2422375135342 : check e2422375135342 [[],[]] .smaller = true := by decide
def e2422375135350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422375135350 : Closed e2422375135350 ∧ code e2422375135350 = 11218468157558 := by decide
theorem cert_e2422375135350 : check e2422375135350 [[],[]] .smaller = true := by decide
def e2422375135354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422375135354 : Closed e2422375135354 ∧ code e2422375135354 = 11218468157562 := by decide
theorem cert_e2422375135354 : check e2422375135354 [[],[]] .smaller = true := by decide
def e2422375135594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422375135594 : Closed e2422375135594 ∧ code e2422375135594 = 11218468157802 := by decide
theorem cert_e2422375135594 : check e2422375135594 [[],[]] .smaller = true := by decide
def e2422375135618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0))))))))))))
theorem wire_e2422375135618 : Closed e2422375135618 ∧ code e2422375135618 = 11218468157826 := by decide
theorem cert_e2422375135618 : check e2422375135618 [[],[]] .smaller = true := by decide
def e2422375135630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422375135630 : Closed e2422375135630 ∧ code e2422375135630 = 11218468157838 := by decide
theorem cert_e2422375135630 : check e2422375135630 [[],[]] .smaller = true := by decide
def e2422375135642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375135642 : Closed e2422375135642 ∧ code e2422375135642 = 11218468157850 := by decide
theorem cert_e2422375135642 : check e2422375135642 [[],[]] .smaller = true := by decide
def e2422375135686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422375135686 : Closed e2422375135686 ∧ code e2422375135686 = 11218468157894 := by decide
theorem cert_e2422375135686 : check e2422375135686 [[],[]] .smaller = true := by decide
def e2422375135710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422375135710 : Closed e2422375135710 ∧ code e2422375135710 = 11218468157918 := by decide
theorem cert_e2422375135710 : check e2422375135710 [[],[]] .three = true := by decide
def e2422375135714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422375135714 : Closed e2422375135714 ∧ code e2422375135714 = 11218468157922 := by decide
theorem cert_e2422375135714 : check e2422375135714 [[],[]] .smaller = true := by decide
def e2422375135726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422375135726 : Closed e2422375135726 ∧ code e2422375135726 = 11218468157934 := by decide
theorem cert_e2422375135726 : check e2422375135726 [[],[]] .smaller = true := by decide
def e2422375135734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422375135734 : Closed e2422375135734 ∧ code e2422375135734 = 11218468157942 := by decide
theorem cert_e2422375135734 : check e2422375135734 [[],[]] .three = true := by decide
def e2422375136286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422375136286 : Closed e2422375136286 ∧ code e2422375136286 = 11218468158494 := by decide
theorem cert_e2422375136286 : check e2422375136286 [[],[]] .smaller = true := by decide
def e2422375136478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422375136478 : Closed e2422375136478 ∧ code e2422375136478 = 11218468158686 := by decide
theorem cert_e2422375136478 : check e2422375136478 [[],[]] .three = true := by decide
def e2422375136482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422375136482 : Closed e2422375136482 ∧ code e2422375136482 = 11218468158690 := by decide
theorem cert_e2422375136482 : check e2422375136482 [[],[]] .smaller = true := by decide
def e2422375136494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422375136494 : Closed e2422375136494 ∧ code e2422375136494 = 11218468158702 := by decide
theorem cert_e2422375136494 : check e2422375136494 [[],[]] .smaller = true := by decide
def e2422375136502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422375136502 : Closed e2422375136502 ∧ code e2422375136502 = 11218468158710 := by decide
theorem cert_e2422375136502 : check e2422375136502 [[],[]] .smaller = true := by decide
def e2422375136506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422375136506 : Closed e2422375136506 ∧ code e2422375136506 = 11218468158714 := by decide
theorem cert_e2422375136506 : check e2422375136506 [[],[]] .three = true := by decide
def e2422375136782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422375136782 : Closed e2422375136782 ∧ code e2422375136782 = 11218468158990 := by decide
theorem cert_e2422375136782 : check e2422375136782 [[],[]] .three = true := by decide
def e2422375136794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375136794 : Closed e2422375136794 ∧ code e2422375136794 = 11218468159002 := by decide
theorem cert_e2422375136794 : check e2422375136794 [[],[]] .three = true := by decide
def e2422375136830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.lam (.var 4))))))))))
theorem wire_e2422375136830 : Closed e2422375136830 ∧ code e2422375136830 = 11218468159038 := by decide
theorem cert_e2422375136830 : check e2422375136830 [[],[]] .three = true := by decide
def e2422375136866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422375136866 : Closed e2422375136866 ∧ code e2422375136866 = 11218468159074 := by decide
theorem cert_e2422375136866 : check e2422375136866 [[],[]] .three = true := by decide
def e2422375136878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422375136878 : Closed e2422375136878 ∧ code e2422375136878 = 11218468159086 := by decide
theorem cert_e2422375136878 : check e2422375136878 [[],[]] .three = true := by decide
def e2422375136886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422375136886 : Closed e2422375136886 ∧ code e2422375136886 = 11218468159094 := by decide
theorem cert_e2422375136886 : check e2422375136886 [[],[]] .three = true := by decide
def e2422375136890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422375136890 : Closed e2422375136890 ∧ code e2422375136890 = 11218468159098 := by decide
theorem cert_e2422375136890 : check e2422375136890 [[],[]] .three = true := by decide
def e2422375155118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422375155118 : Closed e2422375155118 ∧ code e2422375155118 = 11218468177326 := by decide
theorem cert_e2422375155118 : check e2422375155118 [[],[]] .three = true := by decide
def e2422375155130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422375155130 : Closed e2422375155130 ∧ code e2422375155130 = 11218468177338 := by decide
theorem cert_e2422375155130 : check e2422375155130 [[],[]] .three = true := by decide
def e2422375155178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422375155178 : Closed e2422375155178 ∧ code e2422375155178 = 11218468177386 := by decide
theorem cert_e2422375155178 : check e2422375155178 [[],[]] .three = true := by decide
def e2422375155310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422375155310 : Closed e2422375155310 ∧ code e2422375155310 = 11218468177518 := by decide
theorem cert_e2422375155310 : check e2422375155310 [[],[]] .three = true := by decide
def e2422375155322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422375155322 : Closed e2422375155322 ∧ code e2422375155322 = 11218468177530 := by decide
theorem cert_e2422375155322 : check e2422375155322 [[],[]] .three = true := by decide
def e2422375155486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e2422375155486 : Closed e2422375155486 ∧ code e2422375155486 = 11218468177694 := by decide
theorem cert_e2422375155486 : check e2422375155486 [[],[]] .three = true := by decide
def e2422375155598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e2422375155598 : Closed e2422375155598 ∧ code e2422375155598 = 11218468177806 := by decide
theorem cert_e2422375155598 : check e2422375155598 [[],[]] .three = true := by decide
def e2422375155610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375155610 : Closed e2422375155610 ∧ code e2422375155610 = 11218468177818 := by decide
theorem cert_e2422375155610 : check e2422375155610 [[],[]] .three = true := by decide
def e2422375155646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 2) (.var 4))))))))))
theorem wire_e2422375155646 : Closed e2422375155646 ∧ code e2422375155646 = 11218468177854 := by decide
theorem cert_e2422375155646 : check e2422375155646 [[],[]] .three = true := by decide
def e2422375155678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 3) (.var 3))))))))))
theorem wire_e2422375155678 : Closed e2422375155678 ∧ code e2422375155678 = 11218468177886 := by decide
theorem cert_e2422375155678 : check e2422375155678 [[],[]] .three = true := by decide
def e2422375155694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.app (.var 4) (.var 2))))))))))
theorem wire_e2422375155694 : Closed e2422375155694 ∧ code e2422375155694 = 11218468177902 := by decide
theorem cert_e2422375155694 : check e2422375155694 [[],[]] .three = true := by decide
def e2422375159342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422375159342 : Closed e2422375159342 ∧ code e2422375159342 = 11218468181550 := by decide
theorem cert_e2422375159342 : check e2422375159342 [[],[]] .three = true := by decide
def e2422375159350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))))
theorem wire_e2422375159350 : Closed e2422375159350 ∧ code e2422375159350 = 11218468181558 := by decide
theorem cert_e2422375159350 : check e2422375159350 [[],[]] .three = true := by decide
def e2422375159354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))))
theorem wire_e2422375159354 : Closed e2422375159354 ∧ code e2422375159354 = 11218468181562 := by decide
theorem cert_e2422375159354 : check e2422375159354 [[],[]] .three = true := by decide
def e2422375159438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))))
theorem wire_e2422375159438 : Closed e2422375159438 ∧ code e2422375159438 = 11218468181646 := by decide
theorem cert_e2422375159438 : check e2422375159438 [[],[]] .three = true := by decide
def e2422375159494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))))
theorem wire_e2422375159494 : Closed e2422375159494 ∧ code e2422375159494 = 11218468181702 := by decide
theorem cert_e2422375159494 : check e2422375159494 [[],[]] .three = true := by decide
def e2422375159518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2422375159518 : Closed e2422375159518 ∧ code e2422375159518 = 11218468181726 := by decide
theorem cert_e2422375159518 : check e2422375159518 [[],[]] .three = true := by decide
def e2422375159522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422375159522 : Closed e2422375159522 ∧ code e2422375159522 = 11218468181730 := by decide
theorem cert_e2422375159522 : check e2422375159522 [[],[]] .three = true := by decide
def e2422375159534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e2422375159534 : Closed e2422375159534 ∧ code e2422375159534 = 11218468181742 := by decide
theorem cert_e2422375159534 : check e2422375159534 [[],[]] .three = true := by decide
def e2422375159542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2422375159542 : Closed e2422375159542 ∧ code e2422375159542 = 11218468181750 := by decide
theorem cert_e2422375159542 : check e2422375159542 [[],[]] .three = true := by decide
def e2422375159574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422375159574 : Closed e2422375159574 ∧ code e2422375159574 = 11218468181782 := by decide
theorem cert_e2422375159574 : check e2422375159574 [[],[]] .three = true := by decide
def e2422375159578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422375159578 : Closed e2422375159578 ∧ code e2422375159578 = 11218468181786 := by decide
theorem cert_e2422375159578 : check e2422375159578 [[],[]] .three = true := by decide
def e2422375159622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422375159622 : Closed e2422375159622 ∧ code e2422375159622 = 11218468181830 := by decide
theorem cert_e2422375159622 : check e2422375159622 [[],[]] .three = true := by decide
def e2422375159646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2422375159646 : Closed e2422375159646 ∧ code e2422375159646 = 11218468181854 := by decide
theorem cert_e2422375159646 : check e2422375159646 [[],[]] .three = true := by decide
def e2422375159650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422375159650 : Closed e2422375159650 ∧ code e2422375159650 = 11218468181858 := by decide
theorem cert_e2422375159650 : check e2422375159650 [[],[]] .three = true := by decide
def e2422375159662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e2422375159662 : Closed e2422375159662 ∧ code e2422375159662 = 11218468181870 := by decide
theorem cert_e2422375159662 : check e2422375159662 [[],[]] .three = true := by decide
def e2422375159670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e2422375159670 : Closed e2422375159670 ∧ code e2422375159670 = 11218468181878 := by decide
theorem cert_e2422375159670 : check e2422375159670 [[],[]] .three = true := by decide
def e2422375159674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2422375159674 : Closed e2422375159674 ∧ code e2422375159674 = 11218468181882 := by decide
theorem cert_e2422375159674 : check e2422375159674 [[],[]] .three = true := by decide
def e2422375159690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))))
theorem wire_e2422375159690 : Closed e2422375159690 ∧ code e2422375159690 = 11218468181898 := by decide
theorem cert_e2422375159690 : check e2422375159690 [[],[]] .three = true := by decide
def e2422375159714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))))
theorem wire_e2422375159714 : Closed e2422375159714 ∧ code e2422375159714 = 11218468181922 := by decide
theorem cert_e2422375159714 : check e2422375159714 [[],[]] .three = true := by decide
def e2422375159726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e2422375159726 : Closed e2422375159726 ∧ code e2422375159726 = 11218468181934 := by decide
theorem cert_e2422375159726 : check e2422375159726 [[],[]] .three = true := by decide
def e2422375159734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e2422375159734 : Closed e2422375159734 ∧ code e2422375159734 = 11218468181942 := by decide
theorem cert_e2422375159734 : check e2422375159734 [[],[]] .three = true := by decide
def e2422375159738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e2422375159738 : Closed e2422375159738 ∧ code e2422375159738 = 11218468181946 := by decide
theorem cert_e2422375159738 : check e2422375159738 [[],[]] .three = true := by decide
def e2422375159766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2422375159766 : Closed e2422375159766 ∧ code e2422375159766 = 11218468181974 := by decide
theorem cert_e2422375159766 : check e2422375159766 [[],[]] .three = true := by decide
def e2422375159770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2422375159770 : Closed e2422375159770 ∧ code e2422375159770 = 11218468181978 := by decide
theorem cert_e2422375159770 : check e2422375159770 [[],[]] .three = true := by decide
def e2422375159870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.lam (.var 4)))))))))))
theorem wire_e2422375159870 : Closed e2422375159870 ∧ code e2422375159870 = 11218468182078 := by decide
theorem cert_e2422375159870 : check e2422375159870 [[],[]] .three = true := by decide
def e2422375159918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422375159918 : Closed e2422375159918 ∧ code e2422375159918 = 11218468182126 := by decide
theorem cert_e2422375159918 : check e2422375159918 [[],[]] .three = true := by decide
def e2422375159930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422375159930 : Closed e2422375159930 ∧ code e2422375159930 = 11218468182138 := by decide
theorem cert_e2422375159930 : check e2422375159930 [[],[]] .three = true := by decide
def e2422375160206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e2422375160206 : Closed e2422375160206 ∧ code e2422375160206 = 11218468182414 := by decide
theorem cert_e2422375160206 : check e2422375160206 [[],[]] .three = true := by decide
def e2422375160262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e2422375160262 : Closed e2422375160262 ∧ code e2422375160262 = 11218468182470 := by decide
theorem cert_e2422375160262 : check e2422375160262 [[],[]] .three = true := by decide
def e2422375160286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422375160286 : Closed e2422375160286 ∧ code e2422375160286 = 11218468182494 := by decide
theorem cert_e2422375160286 : check e2422375160286 [[],[]] .three = true := by decide
def e2422375160290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))))
theorem wire_e2422375160290 : Closed e2422375160290 ∧ code e2422375160290 = 11218468182498 := by decide
theorem cert_e2422375160290 : check e2422375160290 [[],[]] .three = true := by decide
def e2422375160302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e2422375160302 : Closed e2422375160302 ∧ code e2422375160302 = 11218468182510 := by decide
theorem cert_e2422375160302 : check e2422375160302 [[],[]] .three = true := by decide
def e2422375160310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422375160310 : Closed e2422375160310 ∧ code e2422375160310 = 11218468182518 := by decide
theorem cert_e2422375160310 : check e2422375160310 [[],[]] .three = true := by decide
def e2422375160862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.lam (.var 3)))))))))))
theorem wire_e2422375160862 : Closed e2422375160862 ∧ code e2422375160862 = 11218468183070 := by decide
theorem cert_e2422375160862 : check e2422375160862 [[],[]] .three = true := by decide
def e2422375160886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422375160886 : Closed e2422375160886 ∧ code e2422375160886 = 11218468183094 := by decide
theorem cert_e2422375160886 : check e2422375160886 [[],[]] .three = true := by decide
def e2422375160890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422375160890 : Closed e2422375160890 ∧ code e2422375160890 = 11218468183098 := by decide
theorem cert_e2422375160890 : check e2422375160890 [[],[]] .three = true := by decide
def e2422375161030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422375161030 : Closed e2422375161030 ∧ code e2422375161030 = 11218468183238 := by decide
theorem cert_e2422375161030 : check e2422375161030 [[],[]] .three = true := by decide
def e2422375161054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422375161054 : Closed e2422375161054 ∧ code e2422375161054 = 11218468183262 := by decide
theorem cert_e2422375161054 : check e2422375161054 [[],[]] .three = true := by decide
def e2422375161058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.lam (.var 0)))))))))))
theorem wire_e2422375161058 : Closed e2422375161058 ∧ code e2422375161058 = 11218468183266 := by decide
theorem cert_e2422375161058 : check e2422375161058 [[],[]] .three = true := by decide
def e2422375161070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422375161070 : Closed e2422375161070 ∧ code e2422375161070 = 11218468183278 := by decide
theorem cert_e2422375161070 : check e2422375161070 [[],[]] .three = true := by decide
def e2422375161078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422375161078 : Closed e2422375161078 ∧ code e2422375161078 = 11218468183286 := by decide
theorem cert_e2422375161078 : check e2422375161078 [[],[]] .three = true := by decide
def e2422375161082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422375161082 : Closed e2422375161082 ∧ code e2422375161082 = 11218468183290 := by decide
theorem cert_e2422375161082 : check e2422375161082 [[],[]] .three = true := by decide
def e2422375161358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422375161358 : Closed e2422375161358 ∧ code e2422375161358 = 11218468183566 := by decide
theorem cert_e2422375161358 : check e2422375161358 [[],[]] .three = true := by decide
def e2422375161370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422375161370 : Closed e2422375161370 ∧ code e2422375161370 = 11218468183578 := by decide
theorem cert_e2422375161370 : check e2422375161370 [[],[]] .three = true := by decide
def e2422375161406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.lam (.var 4))))))))))
theorem wire_e2422375161406 : Closed e2422375161406 ∧ code e2422375161406 = 11218468183614 := by decide
theorem cert_e2422375161406 : check e2422375161406 [[],[]] .three = true := by decide
def e2422375161442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422375161442 : Closed e2422375161442 ∧ code e2422375161442 = 11218468183650 := by decide
theorem cert_e2422375161442 : check e2422375161442 [[],[]] .three = true := by decide
def e2422375161454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422375161454 : Closed e2422375161454 ∧ code e2422375161454 = 11218468183662 := by decide
theorem cert_e2422375161454 : check e2422375161454 [[],[]] .three = true := by decide
def e2422375161462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422375161462 : Closed e2422375161462 ∧ code e2422375161462 = 11218468183670 := by decide
theorem cert_e2422375161462 : check e2422375161462 [[],[]] .three = true := by decide
def e2422375161466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422375161466 : Closed e2422375161466 ∧ code e2422375161466 = 11218468183674 := by decide
theorem cert_e2422375161466 : check e2422375161466 [[],[]] .three = true := by decide
def e2422375161630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.lam (.var 3))))))))))
theorem wire_e2422375161630 : Closed e2422375161630 ∧ code e2422375161630 = 11218468183838 := by decide
theorem cert_e2422375161630 : check e2422375161630 [[],[]] .three = true := by decide
def e2422375161654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422375161654 : Closed e2422375161654 ∧ code e2422375161654 = 11218468183862 := by decide
theorem cert_e2422375161654 : check e2422375161654 [[],[]] .three = true := by decide
def e2422375161658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422375161658 : Closed e2422375161658 ∧ code e2422375161658 = 11218468183866 := by decide
theorem cert_e2422375161658 : check e2422375161658 [[],[]] .three = true := by decide
def e2422376259038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))))
theorem wire_e2422376259038 : Closed e2422376259038 ∧ code e2422376259038 = 11218469281246 := by decide
theorem cert_e2422376259038 : check e2422376259038 [[],[]] .smaller = true := by decide
def e2422376259054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))))
theorem wire_e2422376259054 : Closed e2422376259054 ∧ code e2422376259054 = 11218469281262 := by decide
theorem cert_e2422376259054 : check e2422376259054 [[],[]] .smaller = true := by decide
def e2422376259294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))))
theorem wire_e2422376259294 : Closed e2422376259294 ∧ code e2422376259294 = 11218469281502 := by decide
theorem cert_e2422376259294 : check e2422376259294 [[],[]] .smaller = true := by decide
def e2422376259318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))))
theorem wire_e2422376259318 : Closed e2422376259318 ∧ code e2422376259318 = 11218469281526 := by decide
theorem cert_e2422376259318 : check e2422376259318 [[],[]] .smaller = true := by decide
def e2422376259438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))))
theorem wire_e2422376259438 : Closed e2422376259438 ∧ code e2422376259438 = 11218469281646 := by decide
theorem cert_e2422376259438 : check e2422376259438 [[],[]] .smaller = true := by decide
def e2422376259446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))))
theorem wire_e2422376259446 : Closed e2422376259446 ∧ code e2422376259446 = 11218469281654 := by decide
theorem cert_e2422376259446 : check e2422376259446 [[],[]] .smaller = true := by decide
def e2422376264670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422376264670 : Closed e2422376264670 ∧ code e2422376264670 = 11218469286878 := by decide
theorem cert_e2422376264670 : check e2422376264670 [[],[]] .smaller = true := by decide
def e2422376264686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422376264686 : Closed e2422376264686 ∧ code e2422376264686 = 11218469286894 := by decide
theorem cert_e2422376264686 : check e2422376264686 [[],[]] .smaller = true := by decide
def e2422376266206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422376266206 : Closed e2422376266206 ∧ code e2422376266206 = 11218469288414 := by decide
theorem cert_e2422376266206 : check e2422376266206 [[],[]] .smaller = true := by decide
def e2422376266230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422376266230 : Closed e2422376266230 ∧ code e2422376266230 = 11218469288438 := by decide
theorem cert_e2422376266230 : check e2422376266230 [[],[]] .smaller = true := by decide
end Blc.Floor43
