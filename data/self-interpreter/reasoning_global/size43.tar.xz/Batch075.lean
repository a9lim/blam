import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759406803386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e759406803386 : Closed e759406803386 ∧ code e759406803386 = 9555499825594 := by decide
theorem cert_e759406803386 : check e759406803386 [] .sourceHead = true := by decide
def e759406803434 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e759406803434 : Closed e759406803434 ∧ code e759406803434 = 9555499825642 := by decide
theorem cert_e759406803434 : check e759406803434 [] .sourceHead = true := by decide
def e759406804186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e759406804186 : Closed e759406804186 ∧ code e759406804186 = 9555499826394 := by decide
theorem cert_e759406804186 : check e759406804186 [] .sourceHead = true := by decide
def e759406804202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e759406804202 : Closed e759406804202 ∧ code e759406804202 = 9555499826410 := by decide
theorem cert_e759406804202 : check e759406804202 [] .sourceHead = true := by decide
def e759406857070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759406857070 : Closed e759406857070 ∧ code e759406857070 = 9555499879278 := by decide
theorem cert_e759406857070 : check e759406857070 [] .sourceHead = true := by decide
def e759406857078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759406857078 : Closed e759406857078 ∧ code e759406857078 = 9555499879286 := by decide
theorem cert_e759406857078 : check e759406857078 [] .sourceHead = true := by decide
def e759406857134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759406857134 : Closed e759406857134 ∧ code e759406857134 = 9555499879342 := by decide
theorem cert_e759406857134 : check e759406857134 [] .sourceHead = true := by decide
def e759406857146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759406857146 : Closed e759406857146 ∧ code e759406857146 = 9555499879354 := by decide
theorem cert_e759406857146 : check e759406857146 [] .sourceHead = true := by decide
def e759406857174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759406857174 : Closed e759406857174 ∧ code e759406857174 = 9555499879382 := by decide
theorem cert_e759406857174 : check e759406857174 [] .sourceHead = true := by decide
def e759406857178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759406857178 : Closed e759406857178 ∧ code e759406857178 = 9555499879386 := by decide
theorem cert_e759406857178 : check e759406857178 [] .sourceHead = true := by decide
def e759406857454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759406857454 : Closed e759406857454 ∧ code e759406857454 = 9555499879662 := by decide
theorem cert_e759406857454 : check e759406857454 [] .sourceHead = true := by decide
def e759406857462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759406857462 : Closed e759406857462 ∧ code e759406857462 = 9555499879670 := by decide
theorem cert_e759406857462 : check e759406857462 [] .sourceHead = true := by decide
def e759406857838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759406857838 : Closed e759406857838 ∧ code e759406857838 = 9555499880046 := by decide
theorem cert_e759406857838 : check e759406857838 [] .sourceHead = true := by decide
def e759406857850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759406857850 : Closed e759406857850 ∧ code e759406857850 = 9555499880058 := by decide
theorem cert_e759406857850 : check e759406857850 [] .sourceHead = true := by decide
def e759406858038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759406858038 : Closed e759406858038 ∧ code e759406858038 = 9555499880246 := by decide
theorem cert_e759406858038 : check e759406858038 [] .sourceHead = true := by decide
def e759406858042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759406858042 : Closed e759406858042 ∧ code e759406858042 = 9555499880250 := by decide
theorem cert_e759406858042 : check e759406858042 [] .sourceHead = true := by decide
def e759407062494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e759407062494 : Closed e759407062494 ∧ code e759407062494 = 9555500084702 := by decide
theorem cert_e759407062494 : check e759407062494 [] .sourceHead = true := by decide
def e759407062510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e759407062510 : Closed e759407062510 ∧ code e759407062510 = 9555500084718 := by decide
theorem cert_e759407062510 : check e759407062510 [] .sourceHead = true := by decide
def e759407062878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e759407062878 : Closed e759407062878 ∧ code e759407062878 = 9555500085086 := by decide
theorem cert_e759407062878 : check e759407062878 [] .sourceHead = true := by decide
def e759407062906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e759407062906 : Closed e759407062906 ∧ code e759407062906 = 9555500085114 := by decide
theorem cert_e759407062906 : check e759407062906 [] .sourceHead = true := by decide
def e759407062958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e759407062958 : Closed e759407062958 ∧ code e759407062958 = 9555500085166 := by decide
theorem cert_e759407062958 : check e759407062958 [] .sourceHead = true := by decide
def e759407062970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e759407062970 : Closed e759407062970 ∧ code e759407062970 = 9555500085178 := by decide
theorem cert_e759407062970 : check e759407062970 [] .sourceHead = true := by decide
def e759407064030 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e759407064030 : Closed e759407064030 ∧ code e759407064030 = 9555500086238 := by decide
theorem cert_e759407064030 : check e759407064030 [] .sourceHead = true := by decide
def e759407064046 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e759407064046 : Closed e759407064046 ∧ code e759407064046 = 9555500086254 := by decide
theorem cert_e759407064046 : check e759407064046 [] .sourceHead = true := by decide
def e759407066334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e759407066334 : Closed e759407066334 ∧ code e759407066334 = 9555500088542 := by decide
theorem cert_e759407066334 : check e759407066334 [] .sourceHead = true := by decide
def e759407066362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e759407066362 : Closed e759407066362 ∧ code e759407066362 = 9555500088570 := by decide
theorem cert_e759407066362 : check e759407066362 [] .sourceHead = true := by decide
def e759407066734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e759407066734 : Closed e759407066734 ∧ code e759407066734 = 9555500088942 := by decide
theorem cert_e759407066734 : check e759407066734 [] .sourceHead = true := by decide
def e759407066746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e759407066746 : Closed e759407066746 ∧ code e759407066746 = 9555500088954 := by decide
theorem cert_e759407066746 : check e759407066746 [] .sourceHead = true := by decide
def e759407095150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e759407095150 : Closed e759407095150 ∧ code e759407095150 = 9555500117358 := by decide
theorem cert_e759407095150 : check e759407095150 [] .sourceHead = true := by decide
def e759407095158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e759407095158 : Closed e759407095158 ∧ code e759407095158 = 9555500117366 := by decide
theorem cert_e759407095158 : check e759407095158 [] .sourceHead = true := by decide
def e759407095214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e759407095214 : Closed e759407095214 ∧ code e759407095214 = 9555500117422 := by decide
theorem cert_e759407095214 : check e759407095214 [] .sourceHead = true := by decide
def e759407095226 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e759407095226 : Closed e759407095226 ∧ code e759407095226 = 9555500117434 := by decide
theorem cert_e759407095226 : check e759407095226 [] .sourceHead = true := by decide
def e759407095254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e759407095254 : Closed e759407095254 ∧ code e759407095254 = 9555500117462 := by decide
theorem cert_e759407095254 : check e759407095254 [] .sourceHead = true := by decide
def e759407095258 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e759407095258 : Closed e759407095258 ∧ code e759407095258 = 9555500117466 := by decide
theorem cert_e759407095258 : check e759407095258 [] .sourceHead = true := by decide
def e759407095470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e759407095470 : Closed e759407095470 ∧ code e759407095470 = 9555500117678 := by decide
theorem cert_e759407095470 : check e759407095470 [] .sourceHead = true := by decide
def e759407095482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e759407095482 : Closed e759407095482 ∧ code e759407095482 = 9555500117690 := by decide
theorem cert_e759407095482 : check e759407095482 [] .sourceHead = true := by decide
def e759407095530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e759407095530 : Closed e759407095530 ∧ code e759407095530 = 9555500117738 := by decide
theorem cert_e759407095530 : check e759407095530 [] .sourceHead = true := by decide
def e759407095638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e759407095638 : Closed e759407095638 ∧ code e759407095638 = 9555500117846 := by decide
theorem cert_e759407095638 : check e759407095638 [] .sourceHead = true := by decide
def e759407095642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e759407095642 : Closed e759407095642 ∧ code e759407095642 = 9555500117850 := by decide
theorem cert_e759407095642 : check e759407095642 [] .sourceHead = true := by decide
def e759407095658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e759407095658 : Closed e759407095658 ∧ code e759407095658 = 9555500117866 := by decide
theorem cert_e759407095658 : check e759407095658 [] .sourceHead = true := by decide
def e759407096686 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e759407096686 : Closed e759407096686 ∧ code e759407096686 = 9555500118894 := by decide
theorem cert_e759407096686 : check e759407096686 [] .sourceHead = true := by decide
def e759407096694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e759407096694 : Closed e759407096694 ∧ code e759407096694 = 9555500118902 := by decide
theorem cert_e759407096694 : check e759407096694 [] .sourceHead = true := by decide
def e759407096750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e759407096750 : Closed e759407096750 ∧ code e759407096750 = 9555500118958 := by decide
theorem cert_e759407096750 : check e759407096750 [] .sourceHead = true := by decide
def e759407096762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e759407096762 : Closed e759407096762 ∧ code e759407096762 = 9555500118970 := by decide
theorem cert_e759407096762 : check e759407096762 [] .sourceHead = true := by decide
def e759407096790 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e759407096790 : Closed e759407096790 ∧ code e759407096790 = 9555500118998 := by decide
theorem cert_e759407096790 : check e759407096790 [] .sourceHead = true := by decide
def e759407096794 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e759407096794 : Closed e759407096794 ∧ code e759407096794 = 9555500119002 := by decide
theorem cert_e759407096794 : check e759407096794 [] .sourceHead = true := by decide
def e759407097070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e759407097070 : Closed e759407097070 ∧ code e759407097070 = 9555500119278 := by decide
theorem cert_e759407097070 : check e759407097070 [] .sourceHead = true := by decide
def e759407097078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e759407097078 : Closed e759407097078 ∧ code e759407097078 = 9555500119286 := by decide
theorem cert_e759407097078 : check e759407097078 [] .sourceHead = true := by decide
def e759407097454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759407097454 : Closed e759407097454 ∧ code e759407097454 = 9555500119662 := by decide
theorem cert_e759407097454 : check e759407097454 [] .sourceHead = true := by decide
def e759407097466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759407097466 : Closed e759407097466 ∧ code e759407097466 = 9555500119674 := by decide
theorem cert_e759407097466 : check e759407097466 [] .sourceHead = true := by decide
def e759407097654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759407097654 : Closed e759407097654 ∧ code e759407097654 = 9555500119862 := by decide
theorem cert_e759407097654 : check e759407097654 [] .sourceHead = true := by decide
def e759407097658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759407097658 : Closed e759407097658 ∧ code e759407097658 = 9555500119866 := by decide
theorem cert_e759407097658 : check e759407097658 [] .sourceHead = true := by decide
def e759407098286 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e759407098286 : Closed e759407098286 ∧ code e759407098286 = 9555500120494 := by decide
theorem cert_e759407098286 : check e759407098286 [] .sourceHead = true := by decide
def e759407098298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e759407098298 : Closed e759407098298 ∧ code e759407098298 = 9555500120506 := by decide
theorem cert_e759407098298 : check e759407098298 [] .sourceHead = true := by decide
def e759407098346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e759407098346 : Closed e759407098346 ∧ code e759407098346 = 9555500120554 := by decide
theorem cert_e759407098346 : check e759407098346 [] .sourceHead = true := by decide
def e759407098478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759407098478 : Closed e759407098478 ∧ code e759407098478 = 9555500120686 := by decide
theorem cert_e759407098478 : check e759407098478 [] .sourceHead = true := by decide
def e759407098490 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759407098490 : Closed e759407098490 ∧ code e759407098490 = 9555500120698 := by decide
theorem cert_e759407098490 : check e759407098490 [] .sourceHead = true := by decide
def e759407098778 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759407098778 : Closed e759407098778 ∧ code e759407098778 = 9555500120986 := by decide
theorem cert_e759407098778 : check e759407098778 [] .sourceHead = true := by decide
def e759407099094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e759407099094 : Closed e759407099094 ∧ code e759407099094 = 9555500121302 := by decide
theorem cert_e759407099094 : check e759407099094 [] .sourceHead = true := by decide
def e759407099098 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e759407099098 : Closed e759407099098 ∧ code e759407099098 = 9555500121306 := by decide
theorem cert_e759407099098 : check e759407099098 [] .sourceHead = true := by decide
def e759407099114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e759407099114 : Closed e759407099114 ∧ code e759407099114 = 9555500121322 := by decide
theorem cert_e759407099114 : check e759407099114 [] .sourceHead = true := by decide
def e759407099190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759407099190 : Closed e759407099190 ∧ code e759407099190 = 9555500121398 := by decide
theorem cert_e759407099190 : check e759407099190 [] .sourceHead = true := by decide
def e759407099194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759407099194 : Closed e759407099194 ∧ code e759407099194 = 9555500121402 := by decide
theorem cert_e759407099194 : check e759407099194 [] .sourceHead = true := by decide
def e759407099290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759407099290 : Closed e759407099290 ∧ code e759407099290 = 9555500121498 := by decide
theorem cert_e759407099290 : check e759407099290 [] .sourceHead = true := by decide
def e759407100894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e759407100894 : Closed e759407100894 ∧ code e759407100894 = 9555500123102 := by decide
theorem cert_e759407100894 : check e759407100894 [] .sourceHead = true := by decide
def e759407100910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e759407100910 : Closed e759407100910 ∧ code e759407100910 = 9555500123118 := by decide
theorem cert_e759407100910 : check e759407100910 [] .sourceHead = true := by decide
def e759407102830 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759407102830 : Closed e759407102830 ∧ code e759407102830 = 9555500125038 := by decide
theorem cert_e759407102830 : check e759407102830 [] .sourceHead = true := by decide
def e759407102838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759407102838 : Closed e759407102838 ∧ code e759407102838 = 9555500125046 := by decide
theorem cert_e759407102838 : check e759407102838 [] .sourceHead = true := by decide
def e759407102894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759407102894 : Closed e759407102894 ∧ code e759407102894 = 9555500125102 := by decide
theorem cert_e759407102894 : check e759407102894 [] .sourceHead = true := by decide
def e759407102906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759407102906 : Closed e759407102906 ∧ code e759407102906 = 9555500125114 := by decide
theorem cert_e759407102906 : check e759407102906 [] .sourceHead = true := by decide
def e759407102934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759407102934 : Closed e759407102934 ∧ code e759407102934 = 9555500125142 := by decide
theorem cert_e759407102934 : check e759407102934 [] .sourceHead = true := by decide
def e759407102938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759407102938 : Closed e759407102938 ∧ code e759407102938 = 9555500125146 := by decide
theorem cert_e759407102938 : check e759407102938 [] .sourceHead = true := by decide
def e759407103214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759407103214 : Closed e759407103214 ∧ code e759407103214 = 9555500125422 := by decide
theorem cert_e759407103214 : check e759407103214 [] .sourceHead = true := by decide
def e759407103222 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759407103222 : Closed e759407103222 ∧ code e759407103222 = 9555500125430 := by decide
theorem cert_e759407103222 : check e759407103222 [] .sourceHead = true := by decide
def e759407103598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759407103598 : Closed e759407103598 ∧ code e759407103598 = 9555500125806 := by decide
theorem cert_e759407103598 : check e759407103598 [] .sourceHead = true := by decide
def e759407103610 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759407103610 : Closed e759407103610 ∧ code e759407103610 = 9555500125818 := by decide
theorem cert_e759407103610 : check e759407103610 [] .sourceHead = true := by decide
def e759407103798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759407103798 : Closed e759407103798 ∧ code e759407103798 = 9555500126006 := by decide
theorem cert_e759407103798 : check e759407103798 [] .sourceHead = true := by decide
def e759407103802 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759407103802 : Closed e759407103802 ∧ code e759407103802 = 9555500126010 := by decide
theorem cert_e759407103802 : check e759407103802 [] .sourceHead = true := by decide
def e759407108574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e759407108574 : Closed e759407108574 ∧ code e759407108574 = 9555500130782 := by decide
theorem cert_e759407108574 : check e759407108574 [] .sourceHead = true := by decide
def e759407108598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e759407108598 : Closed e759407108598 ∧ code e759407108598 = 9555500130806 := by decide
theorem cert_e759407108598 : check e759407108598 [] .sourceHead = true := by decide
def e759407109550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e759407109550 : Closed e759407109550 ∧ code e759407109550 = 9555500131758 := by decide
theorem cert_e759407109550 : check e759407109550 [] .sourceHead = true := by decide
def e759407109562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e759407109562 : Closed e759407109562 ∧ code e759407109562 = 9555500131770 := by decide
theorem cert_e759407109562 : check e759407109562 [] .sourceHead = true := by decide
def e759407109610 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e759407109610 : Closed e759407109610 ∧ code e759407109610 = 9555500131818 := by decide
theorem cert_e759407109610 : check e759407109610 [] .sourceHead = true := by decide
def e759407109742 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e759407109742 : Closed e759407109742 ∧ code e759407109742 = 9555500131950 := by decide
theorem cert_e759407109742 : check e759407109742 [] .sourceHead = true := by decide
def e759407109754 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e759407109754 : Closed e759407109754 ∧ code e759407109754 = 9555500131962 := by decide
theorem cert_e759407109754 : check e759407109754 [] .sourceHead = true := by decide
def e759407110042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e759407110042 : Closed e759407110042 ∧ code e759407110042 = 9555500132250 := by decide
theorem cert_e759407110042 : check e759407110042 [] .sourceHead = true := by decide
def e759407112430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e759407112430 : Closed e759407112430 ∧ code e759407112430 = 9555500134638 := by decide
theorem cert_e759407112430 : check e759407112430 [] .sourceHead = true := by decide
def e759407112438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e759407112438 : Closed e759407112438 ∧ code e759407112438 = 9555500134646 := by decide
theorem cert_e759407112438 : check e759407112438 [] .sourceHead = true := by decide
def e759407112918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e759407112918 : Closed e759407112918 ∧ code e759407112918 = 9555500135126 := by decide
theorem cert_e759407112918 : check e759407112918 [] .sourceHead = true := by decide
def e759407112922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e759407112922 : Closed e759407112922 ∧ code e759407112922 = 9555500135130 := by decide
theorem cert_e759407112922 : check e759407112922 [] .sourceHead = true := by decide
def e759407112938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e759407112938 : Closed e759407112938 ∧ code e759407112938 = 9555500135146 := by decide
theorem cert_e759407112938 : check e759407112938 [] .sourceHead = true := by decide
def e759407113014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e759407113014 : Closed e759407113014 ∧ code e759407113014 = 9555500135222 := by decide
theorem cert_e759407113014 : check e759407113014 [] .sourceHead = true := by decide
def e759407113018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e759407113018 : Closed e759407113018 ∧ code e759407113018 = 9555500135226 := by decide
theorem cert_e759407113018 : check e759407113018 [] .sourceHead = true := by decide
def e759407113114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e759407113114 : Closed e759407113114 ∧ code e759407113114 = 9555500135322 := by decide
theorem cert_e759407113114 : check e759407113114 [] .sourceHead = true := by decide
def e759407250286 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759407250286 : Closed e759407250286 ∧ code e759407250286 = 9555500272494 := by decide
theorem cert_e759407250286 : check e759407250286 [] .sourceHead = true := by decide
def e759407250294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759407250294 : Closed e759407250294 ∧ code e759407250294 = 9555500272502 := by decide
theorem cert_e759407250294 : check e759407250294 [] .sourceHead = true := by decide
def e759407250350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759407250350 : Closed e759407250350 ∧ code e759407250350 = 9555500272558 := by decide
theorem cert_e759407250350 : check e759407250350 [] .sourceHead = true := by decide
def e759407250362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759407250362 : Closed e759407250362 ∧ code e759407250362 = 9555500272570 := by decide
theorem cert_e759407250362 : check e759407250362 [] .sourceHead = true := by decide
def e759407250390 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759407250390 : Closed e759407250390 ∧ code e759407250390 = 9555500272598 := by decide
theorem cert_e759407250390 : check e759407250390 [] .sourceHead = true := by decide
def e759407250394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759407250394 : Closed e759407250394 ∧ code e759407250394 = 9555500272602 := by decide
theorem cert_e759407250394 : check e759407250394 [] .sourceHead = true := by decide
def e759407250670 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759407250670 : Closed e759407250670 ∧ code e759407250670 = 9555500272878 := by decide
theorem cert_e759407250670 : check e759407250670 [] .sourceHead = true := by decide
def e759407250678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759407250678 : Closed e759407250678 ∧ code e759407250678 = 9555500272886 := by decide
theorem cert_e759407250678 : check e759407250678 [] .sourceHead = true := by decide
def e759407251054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759407251054 : Closed e759407251054 ∧ code e759407251054 = 9555500273262 := by decide
theorem cert_e759407251054 : check e759407251054 [] .sourceHead = true := by decide
def e759407251066 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759407251066 : Closed e759407251066 ∧ code e759407251066 = 9555500273274 := by decide
theorem cert_e759407251066 : check e759407251066 [] .sourceHead = true := by decide
def e759407251254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759407251254 : Closed e759407251254 ∧ code e759407251254 = 9555500273462 := by decide
theorem cert_e759407251254 : check e759407251254 [] .sourceHead = true := by decide
def e759407251258 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759407251258 : Closed e759407251258 ∧ code e759407251258 = 9555500273466 := by decide
theorem cert_e759407251258 : check e759407251258 [] .sourceHead = true := by decide
def e759407580894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e759407580894 : Closed e759407580894 ∧ code e759407580894 = 9555500603102 := by decide
theorem cert_e759407580894 : check e759407580894 [] .sourceHead = true := by decide
def e759407580918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e759407580918 : Closed e759407580918 ∧ code e759407580918 = 9555500603126 := by decide
theorem cert_e759407580918 : check e759407580918 [] .sourceHead = true := by decide
def e759407581022 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e759407581022 : Closed e759407581022 ∧ code e759407581022 = 9555500603230 := by decide
theorem cert_e759407581022 : check e759407581022 [] .sourceHead = true := by decide
def e759407581050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e759407581050 : Closed e759407581050 ∧ code e759407581050 = 9555500603258 := by decide
theorem cert_e759407581050 : check e759407581050 [] .sourceHead = true := by decide
def e759407581142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e759407581142 : Closed e759407581142 ∧ code e759407581142 = 9555500603350 := by decide
theorem cert_e759407581142 : check e759407581142 [] .sourceHead = true := by decide
def e759407581146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e759407581146 : Closed e759407581146 ∧ code e759407581146 = 9555500603354 := by decide
theorem cert_e759407581146 : check e759407581146 [] .sourceHead = true := by decide
def e759407581662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e759407581662 : Closed e759407581662 ∧ code e759407581662 = 9555500603870 := by decide
theorem cert_e759407581662 : check e759407581662 [] .sourceHead = true := by decide
def e759407581686 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e759407581686 : Closed e759407581686 ∧ code e759407581686 = 9555500603894 := by decide
theorem cert_e759407581686 : check e759407581686 [] .sourceHead = true := by decide
def e759407582430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e759407582430 : Closed e759407582430 ∧ code e759407582430 = 9555500604638 := by decide
theorem cert_e759407582430 : check e759407582430 [] .sourceHead = true := by decide
def e759407582458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e759407582458 : Closed e759407582458 ∧ code e759407582458 = 9555500604666 := by decide
theorem cert_e759407582458 : check e759407582458 [] .sourceHead = true := by decide
def e759407583030 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e759407583030 : Closed e759407583030 ∧ code e759407583030 = 9555500605238 := by decide
theorem cert_e759407583030 : check e759407583030 [] .sourceHead = true := by decide
def e759407583034 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e759407583034 : Closed e759407583034 ∧ code e759407583034 = 9555500605242 := by decide
theorem cert_e759407583034 : check e759407583034 [] .sourceHead = true := by decide
def e759407597806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e759407597806 : Closed e759407597806 ∧ code e759407597806 = 9555500620014 := by decide
theorem cert_e759407597806 : check e759407597806 [] .sourceHead = true := by decide
def e759407597814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e759407597814 : Closed e759407597814 ∧ code e759407597814 = 9555500620022 := by decide
theorem cert_e759407597814 : check e759407597814 [] .sourceHead = true := by decide
def e759407598366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e759407598366 : Closed e759407598366 ∧ code e759407598366 = 9555500620574 := by decide
theorem cert_e759407598366 : check e759407598366 [] .sourceHead = true := by decide
def e759407598478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e759407598478 : Closed e759407598478 ∧ code e759407598478 = 9555500620686 := by decide
theorem cert_e759407598478 : check e759407598478 [] .sourceHead = true := by decide
def e759407598702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e759407598702 : Closed e759407598702 ∧ code e759407598702 = 9555500620910 := by decide
theorem cert_e759407598702 : check e759407598702 [] .sourceHead = true := by decide
def e759407598714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e759407598714 : Closed e759407598714 ∧ code e759407598714 = 9555500620922 := by decide
theorem cert_e759407598714 : check e759407598714 [] .sourceHead = true := by decide
def e759407598878 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e759407598878 : Closed e759407598878 ∧ code e759407598878 = 9555500621086 := by decide
theorem cert_e759407598878 : check e759407598878 [] .sourceHead = true := by decide
def e759407599046 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e759407599046 : Closed e759407599046 ∧ code e759407599046 = 9555500621254 := by decide
theorem cert_e759407599046 : check e759407599046 [] .sourceHead = true := by decide
def e759407599158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e759407599158 : Closed e759407599158 ∧ code e759407599158 = 9555500621366 := by decide
theorem cert_e759407599158 : check e759407599158 [] .sourceHead = true := by decide
def e759407599162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e759407599162 : Closed e759407599162 ∧ code e759407599162 = 9555500621370 := by decide
theorem cert_e759407599162 : check e759407599162 [] .sourceHead = true := by decide
def e759407599246 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e759407599246 : Closed e759407599246 ∧ code e759407599246 = 9555500621454 := by decide
theorem cert_e759407599246 : check e759407599246 [] .sourceHead = true := by decide
def e759407599302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e759407599302 : Closed e759407599302 ∧ code e759407599302 = 9555500621510 := by decide
theorem cert_e759407599302 : check e759407599302 [] .sourceHead = true := by decide
def e759407601438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e759407601438 : Closed e759407601438 ∧ code e759407601438 = 9555500623646 := by decide
theorem cert_e759407601438 : check e759407601438 [] .sourceHead = true := by decide
def e759407601550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e759407601550 : Closed e759407601550 ∧ code e759407601550 = 9555500623758 := by decide
theorem cert_e759407601550 : check e759407601550 [] .sourceHead = true := by decide
def e759407604510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e759407604510 : Closed e759407604510 ∧ code e759407604510 = 9555500626718 := by decide
theorem cert_e759407604510 : check e759407604510 [] .sourceHead = true := by decide
def e759407604678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e759407604678 : Closed e759407604678 ∧ code e759407604678 = 9555500626886 := by decide
theorem cert_e759407604678 : check e759407604678 [] .sourceHead = true := by decide
def e759407606158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e759407606158 : Closed e759407606158 ∧ code e759407606158 = 9555500628366 := by decide
theorem cert_e759407606158 : check e759407606158 [] .sourceHead = true := by decide
def e759407606214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e759407606214 : Closed e759407606214 ∧ code e759407606214 = 9555500628422 := by decide
theorem cert_e759407606214 : check e759407606214 [] .sourceHead = true := by decide
def e759415451066 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e759415451066 : Closed e759415451066 ∧ code e759415451066 = 9555508473274 := by decide
theorem cert_e759415451066 : check e759415451066 [] .sourceHead = true := by decide
def e759415451098 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e759415451098 : Closed e759415451098 ∧ code e759415451098 = 9555508473306 := by decide
theorem cert_e759415451098 : check e759415451098 [] .sourceHead = true := by decide
def e759415451322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e759415451322 : Closed e759415451322 ∧ code e759415451322 = 9555508473530 := by decide
theorem cert_e759415451322 : check e759415451322 [] .sourceHead = true := by decide
def e759415451370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e759415451370 : Closed e759415451370 ∧ code e759415451370 = 9555508473578 := by decide
theorem cert_e759415451370 : check e759415451370 [] .sourceHead = true := by decide
def e759415451482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e759415451482 : Closed e759415451482 ∧ code e759415451482 = 9555508473690 := by decide
theorem cert_e759415451482 : check e759415451482 [] .sourceHead = true := by decide
def e759415451498 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e759415451498 : Closed e759415451498 ∧ code e759415451498 = 9555508473706 := by decide
theorem cert_e759415451498 : check e759415451498 [] .sourceHead = true := by decide
def e759415452602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e759415452602 : Closed e759415452602 ∧ code e759415452602 = 9555508474810 := by decide
theorem cert_e759415452602 : check e759415452602 [] .sourceHead = true := by decide
def e759415452634 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e759415452634 : Closed e759415452634 ∧ code e759415452634 = 9555508474842 := by decide
theorem cert_e759415452634 : check e759415452634 [] .sourceHead = true := by decide
def e759415454138 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e759415454138 : Closed e759415454138 ∧ code e759415454138 = 9555508476346 := by decide
theorem cert_e759415454138 : check e759415454138 [] .sourceHead = true := by decide
def e759415454186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e759415454186 : Closed e759415454186 ∧ code e759415454186 = 9555508476394 := by decide
theorem cert_e759415454186 : check e759415454186 [] .sourceHead = true := by decide
def e759415454938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e759415454938 : Closed e759415454938 ∧ code e759415454938 = 9555508477146 := by decide
theorem cert_e759415454938 : check e759415454938 [] .sourceHead = true := by decide
def e759415454954 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e759415454954 : Closed e759415454954 ∧ code e759415454954 = 9555508477162 := by decide
theorem cert_e759415454954 : check e759415454954 [] .sourceHead = true := by decide
def e759415704430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e759415704430 : Closed e759415704430 ∧ code e759415704430 = 9555508726638 := by decide
theorem cert_e759415704430 : check e759415704430 [] .sourceHead = true := by decide
def e759415704438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e759415704438 : Closed e759415704438 ∧ code e759415704438 = 9555508726646 := by decide
theorem cert_e759415704438 : check e759415704438 [] .sourceHead = true := by decide
def e759415704494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e759415704494 : Closed e759415704494 ∧ code e759415704494 = 9555508726702 := by decide
theorem cert_e759415704494 : check e759415704494 [] .sourceHead = true := by decide
def e759415704506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e759415704506 : Closed e759415704506 ∧ code e759415704506 = 9555508726714 := by decide
theorem cert_e759415704506 : check e759415704506 [] .sourceHead = true := by decide
def e759415704534 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e759415704534 : Closed e759415704534 ∧ code e759415704534 = 9555508726742 := by decide
theorem cert_e759415704534 : check e759415704534 [] .sourceHead = true := by decide
def e759415704538 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e759415704538 : Closed e759415704538 ∧ code e759415704538 = 9555508726746 := by decide
theorem cert_e759415704538 : check e759415704538 [] .sourceHead = true := by decide
def e759415704814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e759415704814 : Closed e759415704814 ∧ code e759415704814 = 9555508727022 := by decide
theorem cert_e759415704814 : check e759415704814 [] .sourceHead = true := by decide
def e759415704822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e759415704822 : Closed e759415704822 ∧ code e759415704822 = 9555508727030 := by decide
theorem cert_e759415704822 : check e759415704822 [] .sourceHead = true := by decide
def e759415705198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e759415705198 : Closed e759415705198 ∧ code e759415705198 = 9555508727406 := by decide
theorem cert_e759415705198 : check e759415705198 [] .sourceHead = true := by decide
def e759415705210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e759415705210 : Closed e759415705210 ∧ code e759415705210 = 9555508727418 := by decide
theorem cert_e759415705210 : check e759415705210 [] .sourceHead = true := by decide
def e759415705398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e759415705398 : Closed e759415705398 ∧ code e759415705398 = 9555508727606 := by decide
theorem cert_e759415705398 : check e759415705398 [] .sourceHead = true := by decide
def e759415705402 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e759415705402 : Closed e759415705402 ∧ code e759415705402 = 9555508727610 := by decide
theorem cert_e759415705402 : check e759415705402 [] .sourceHead = true := by decide
end Blc.Floor43
