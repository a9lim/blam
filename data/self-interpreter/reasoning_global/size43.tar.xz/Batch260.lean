import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405972074522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405972074522 : Closed e2405972074522 ∧ code e2405972074522 = 11202065096730 := by decide
theorem cert_e2405972074522 : check e2405972074522 [[]] .width = true := by decide
def e2405972074614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405972074614 : Closed e2405972074614 ∧ code e2405972074614 = 11202065096822 := by decide
theorem cert_e2405972074614 : check e2405972074614 [[]] .width = true := by decide
def e2405972074858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405972074858 : Closed e2405972074858 ∧ code e2405972074858 = 11202065097066 := by decide
theorem cert_e2405972074858 : check e2405972074858 [[]] .width = true := by decide
def e2405972074906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405972074906 : Closed e2405972074906 ∧ code e2405972074906 = 11202065097114 := by decide
theorem cert_e2405972074906 : check e2405972074906 [[]] .width = true := by decide
def e2405972103366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405972103366 : Closed e2405972103366 ∧ code e2405972103366 = 11202065125574 := by decide
theorem cert_e2405972103366 : check e2405972103366 [[]] .width = true := by decide
def e2405972105242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405972105242 : Closed e2405972105242 ∧ code e2405972105242 = 11202065127450 := by decide
theorem cert_e2405972105242 : check e2405972105242 [[]] .width = true := by decide
def e2405972109338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405972109338 : Closed e2405972109338 ∧ code e2405972109338 = 11202065131546 := by decide
theorem cert_e2405972109338 : check e2405972109338 [[]] .width = true := by decide
def e2405972115654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405972115654 : Closed e2405972115654 ∧ code e2405972115654 = 11202065137862 := by decide
theorem cert_e2405972115654 : check e2405972115654 [[]] .width = true := by decide
def e2405972116182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405972116182 : Closed e2405972116182 ∧ code e2405972116182 = 11202065138390 := by decide
theorem cert_e2405972116182 : check e2405972116182 [[]] .width = true := by decide
def e2405972116186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405972116186 : Closed e2405972116186 ∧ code e2405972116186 = 11202065138394 := by decide
theorem cert_e2405972116186 : check e2405972116186 [[]] .width = true := by decide
def e2405972116202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405972116202 : Closed e2405972116202 ∧ code e2405972116202 = 11202065138410 := by decide
theorem cert_e2405972116202 : check e2405972116202 [[]] .width = true := by decide
def e2405972116278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405972116278 : Closed e2405972116278 ∧ code e2405972116278 = 11202065138486 := by decide
theorem cert_e2405972116278 : check e2405972116278 [[]] .width = true := by decide
def e2405972116282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405972116282 : Closed e2405972116282 ∧ code e2405972116282 = 11202065138490 := by decide
theorem cert_e2405972116282 : check e2405972116282 [[]] .width = true := by decide
def e2405972116366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405972116366 : Closed e2405972116366 ∧ code e2405972116366 = 11202065138574 := by decide
theorem cert_e2405972116366 : check e2405972116366 [[]] .width = true := by decide
def e2405972116378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405972116378 : Closed e2405972116378 ∧ code e2405972116378 = 11202065138586 := by decide
theorem cert_e2405972116378 : check e2405972116378 [[]] .width = true := by decide
def e2405972118298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405972118298 : Closed e2405972118298 ∧ code e2405972118298 = 11202065140506 := by decide
theorem cert_e2405972118298 : check e2405972118298 [[]] .width = true := by decide
def e2405972118342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405972118342 : Closed e2405972118342 ∧ code e2405972118342 = 11202065140550 := by decide
theorem cert_e2405972118342 : check e2405972118342 [[]] .width = true := by decide
def e2405972118582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405972118582 : Closed e2405972118582 ∧ code e2405972118582 = 11202065140790 := by decide
theorem cert_e2405972118582 : check e2405972118582 [[]] .width = true := by decide
def e2405972118586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405972118586 : Closed e2405972118586 ∧ code e2405972118586 = 11202065140794 := by decide
theorem cert_e2405972118586 : check e2405972118586 [[]] .width = true := by decide
def e2405972118726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405972118726 : Closed e2405972118726 ∧ code e2405972118726 = 11202065140934 := by decide
theorem cert_e2405972118726 : check e2405972118726 [[]] .width = true := by decide
def e2405973186586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973186586 : Closed e2405973186586 ∧ code e2405973186586 = 11202066208794 := by decide
theorem cert_e2405973186586 : check e2405973186586 [[]] .width = true := by decide
def e2405973190682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973190682 : Closed e2405973190682 ∧ code e2405973190682 = 11202066212890 := by decide
theorem cert_e2405973190682 : check e2405973190682 [[]] .width = true := by decide
def e2405973192218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973192218 : Closed e2405973192218 ∧ code e2405973192218 = 11202066214426 := by decide
theorem cert_e2405973192218 : check e2405973192218 [[]] .width = true := by decide
def e2405973194266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973194266 : Closed e2405973194266 ∧ code e2405973194266 = 11202066216474 := by decide
theorem cert_e2405973194266 : check e2405973194266 [[]] .width = true := by decide
def e2405973207066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973207066 : Closed e2405973207066 ∧ code e2405973207066 = 11202066229274 := by decide
theorem cert_e2405973207066 : check e2405973207066 [[]] .width = true := by decide
def e2405973208602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973208602 : Closed e2405973208602 ∧ code e2405973208602 = 11202066230810 := by decide
theorem cert_e2405973208602 : check e2405973208602 [[]] .width = true := by decide
def e2405973211674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973211674 : Closed e2405973211674 ∧ code e2405973211674 = 11202066233882 := by decide
theorem cert_e2405973211674 : check e2405973211674 [[]] .width = true := by decide
def e2405973218842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973218842 : Closed e2405973218842 ∧ code e2405973218842 = 11202066241050 := by decide
theorem cert_e2405973218842 : check e2405973218842 [[]] .width = true := by decide
def e2405973219866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973219866 : Closed e2405973219866 ∧ code e2405973219866 = 11202066242074 := by decide
theorem cert_e2405973219866 : check e2405973219866 [[]] .width = true := by decide
def e2405973272602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973272602 : Closed e2405973272602 ∧ code e2405973272602 = 11202066294810 := by decide
theorem cert_e2405973272602 : check e2405973272602 [[]] .width = true := by decide
def e2405973274138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973274138 : Closed e2405973274138 ∧ code e2405973274138 = 11202066296346 := by decide
theorem cert_e2405973274138 : check e2405973274138 [[]] .width = true := by decide
def e2405973277210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973277210 : Closed e2405973277210 ∧ code e2405973277210 = 11202066299418 := by decide
theorem cert_e2405973277210 : check e2405973277210 [[]] .width = true := by decide
def e2405973289498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973289498 : Closed e2405973289498 ∧ code e2405973289498 = 11202066311706 := by decide
private def t_e2405973289498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405973289498 : ¬ IsSelfInterpreter e2405973289498 :=
  wSource (t := t_e2405973289498) (replay_sound (ps := []) (t := e2405973289498) (by decide)) (by decide)
def e2405973317146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973317146 : Closed e2405973317146 ∧ code e2405973317146 = 11202066339354 := by decide
theorem cert_e2405973317146 : check e2405973317146 [[]] .width = true := by decide
def e2405973318170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973318170 : Closed e2405973318170 ∧ code e2405973318170 = 11202066340378 := by decide
theorem cert_e2405973318170 : check e2405973318170 [[]] .width = true := by decide
def e2405973322266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973322266 : Closed e2405973322266 ∧ code e2405973322266 = 11202066344474 := by decide
private def t_e2405973322266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405973322266 : ¬ IsSelfInterpreter e2405973322266 :=
  wSource (t := t_e2405973322266) (replay_sound (ps := []) (t := e2405973322266) (by decide)) (by decide)
def e2405973383194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973383194 : Closed e2405973383194 ∧ code e2405973383194 = 11202066405402 := by decide
theorem cert_e2405973383194 : check e2405973383194 [[]] .width = true := by decide
def e2405973450778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405973450778 : Closed e2405973450778 ∧ code e2405973450778 = 11202066472986 := by decide
theorem cert_e2405973450778 : check e2405973450778 [[]] .width = true := by decide
def e2405973450870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405973450870 : Closed e2405973450870 ∧ code e2405973450870 = 11202066473078 := by decide
theorem cert_e2405973450870 : check e2405973450870 [[]] .width = true := by decide
def e2405973451114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405973451114 : Closed e2405973451114 ∧ code e2405973451114 = 11202066473322 := by decide
theorem cert_e2405973451114 : check e2405973451114 [[]] .width = true := by decide
def e2405973451162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405973451162 : Closed e2405973451162 ∧ code e2405973451162 = 11202066473370 := by decide
theorem cert_e2405973451162 : check e2405973451162 [[]] .width = true := by decide
def e2405973471430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405973471430 : Closed e2405973471430 ∧ code e2405973471430 = 11202066493638 := by decide
theorem cert_e2405973471430 : check e2405973471430 [[]] .width = true := by decide
def e2405973479622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405973479622 : Closed e2405973479622 ∧ code e2405973479622 = 11202066501830 := by decide
theorem cert_e2405973479622 : check e2405973479622 [[]] .width = true := by decide
def e2405973481498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973481498 : Closed e2405973481498 ∧ code e2405973481498 = 11202066503706 := by decide
theorem cert_e2405973481498 : check e2405973481498 [[]] .width = true := by decide
def e2405973579802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973579802 : Closed e2405973579802 ∧ code e2405973579802 = 11202066602010 := by decide
theorem cert_e2405973579802 : check e2405973579802 [[]] .width = true := by decide
def e2405973583898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973583898 : Closed e2405973583898 ∧ code e2405973583898 = 11202066606106 := by decide
theorem cert_e2405973583898 : check e2405973583898 [[]] .width = true := by decide
def e2405973585434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973585434 : Closed e2405973585434 ∧ code e2405973585434 = 11202066607642 := by decide
theorem cert_e2405973585434 : check e2405973585434 [[]] .width = true := by decide
def e2405973587482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973587482 : Closed e2405973587482 ∧ code e2405973587482 = 11202066609690 := by decide
theorem cert_e2405973587482 : check e2405973587482 [[]] .width = true := by decide
def e2405973600282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973600282 : Closed e2405973600282 ∧ code e2405973600282 = 11202066622490 := by decide
theorem cert_e2405973600282 : check e2405973600282 [[]] .width = true := by decide
def e2405973601818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973601818 : Closed e2405973601818 ∧ code e2405973601818 = 11202066624026 := by decide
theorem cert_e2405973601818 : check e2405973601818 [[]] .width = true := by decide
def e2405973604890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973604890 : Closed e2405973604890 ∧ code e2405973604890 = 11202066627098 := by decide
theorem cert_e2405973604890 : check e2405973604890 [[]] .width = true := by decide
def e2405973612058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973612058 : Closed e2405973612058 ∧ code e2405973612058 = 11202066634266 := by decide
theorem cert_e2405973612058 : check e2405973612058 [[]] .width = true := by decide
def e2405973613082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973613082 : Closed e2405973613082 ∧ code e2405973613082 = 11202066635290 := by decide
theorem cert_e2405973613082 : check e2405973613082 [[]] .width = true := by decide
def e2405973651654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405973651654 : Closed e2405973651654 ∧ code e2405973651654 = 11202066673862 := by decide
theorem cert_e2405973651654 : check e2405973651654 [[]] .width = true := by decide
def e2405973678106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973678106 : Closed e2405973678106 ∧ code e2405973678106 = 11202066700314 := by decide
theorem cert_e2405973678106 : check e2405973678106 [[]] .width = true := by decide
def e2405973682202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973682202 : Closed e2405973682202 ∧ code e2405973682202 = 11202066704410 := by decide
theorem cert_e2405973682202 : check e2405973682202 [[]] .width = true := by decide
def e2405973683738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973683738 : Closed e2405973683738 ∧ code e2405973683738 = 11202066705946 := by decide
theorem cert_e2405973683738 : check e2405973683738 [[]] .width = true := by decide
def e2405973685786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973685786 : Closed e2405973685786 ∧ code e2405973685786 = 11202066707994 := by decide
theorem cert_e2405973685786 : check e2405973685786 [[]] .width = true := by decide
def e2405973721114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405973721114 : Closed e2405973721114 ∧ code e2405973721114 = 11202066743322 := by decide
theorem cert_e2405973721114 : check e2405973721114 [[]] .width = true := by decide
def e2405973721206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405973721206 : Closed e2405973721206 ∧ code e2405973721206 = 11202066743414 := by decide
theorem cert_e2405973721206 : check e2405973721206 [[]] .width = true := by decide
def e2405973721450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405973721450 : Closed e2405973721450 ∧ code e2405973721450 = 11202066743658 := by decide
theorem cert_e2405973721450 : check e2405973721450 [[]] .width = true := by decide
def e2405973721498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405973721498 : Closed e2405973721498 ∧ code e2405973721498 = 11202066743706 := by decide
theorem cert_e2405973721498 : check e2405973721498 [[]] .width = true := by decide
def e2405973722506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405973722506 : Closed e2405973722506 ∧ code e2405973722506 = 11202066744714 := by decide
theorem cert_e2405973722506 : check e2405973722506 [[]] .width = true := by decide
def e2405973722530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405973722530 : Closed e2405973722530 ∧ code e2405973722530 = 11202066744738 := by decide
theorem cert_e2405973722530 : check e2405973722530 [[]] .width = true := by decide
def e2405973722638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405973722638 : Closed e2405973722638 ∧ code e2405973722638 = 11202066744846 := by decide
theorem cert_e2405973722638 : check e2405973722638 [[]] .width = true := by decide
def e2405973722650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405973722650 : Closed e2405973722650 ∧ code e2405973722650 = 11202066744858 := by decide
theorem cert_e2405973722650 : check e2405973722650 [[]] .width = true := by decide
def e2405973722722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405973722722 : Closed e2405973722722 ∧ code e2405973722722 = 11202066744930 := by decide
theorem cert_e2405973722722 : check e2405973722722 [[]] .width = true := by decide
def e2405973755930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973755930 : Closed e2405973755930 ∧ code e2405973755930 = 11202066778138 := by decide
theorem cert_e2405973755930 : check e2405973755930 [[]] .width = true := by decide
def e2405973762074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405973762074 : Closed e2405973762074 ∧ code e2405973762074 = 11202066784282 := by decide
theorem cert_e2405973762074 : check e2405973762074 [[]] .width = true := by decide
def e2405973762166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405973762166 : Closed e2405973762166 ∧ code e2405973762166 = 11202066784374 := by decide
theorem cert_e2405973762166 : check e2405973762166 [[]] .width = true := by decide
def e2405973762410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405973762410 : Closed e2405973762410 ∧ code e2405973762410 = 11202066784618 := by decide
theorem cert_e2405973762410 : check e2405973762410 [[]] .width = true := by decide
def e2405973762458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405973762458 : Closed e2405973762458 ∧ code e2405973762458 = 11202066784666 := by decide
theorem cert_e2405973762458 : check e2405973762458 [[]] .width = true := by decide
def e2405973766342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405973766342 : Closed e2405973766342 ∧ code e2405973766342 = 11202066788550 := by decide
theorem cert_e2405973766342 : check e2405973766342 [[]] .width = true := by decide
def e2405973768218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973768218 : Closed e2405973768218 ∧ code e2405973768218 = 11202066790426 := by decide
theorem cert_e2405973768218 : check e2405973768218 [[]] .width = true := by decide
def e2405973780506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973780506 : Closed e2405973780506 ∧ code e2405973780506 = 11202066802714 := by decide
theorem cert_e2405973780506 : check e2405973780506 [[]] .width = true := by decide
def e2405973782042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973782042 : Closed e2405973782042 ∧ code e2405973782042 = 11202066804250 := by decide
theorem cert_e2405973782042 : check e2405973782042 [[]] .width = true := by decide
def e2405973785114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973785114 : Closed e2405973785114 ∧ code e2405973785114 = 11202066807322 := by decide
theorem cert_e2405973785114 : check e2405973785114 [[]] .width = true := by decide
def e2405973786650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405973786650 : Closed e2405973786650 ∧ code e2405973786650 = 11202066808858 := by decide
theorem cert_e2405973786650 : check e2405973786650 [[]] .width = true := by decide
def e2405973786742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405973786742 : Closed e2405973786742 ∧ code e2405973786742 = 11202066808950 := by decide
theorem cert_e2405973786742 : check e2405973786742 [[]] .width = true := by decide
def e2405973786986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405973786986 : Closed e2405973786986 ∧ code e2405973786986 = 11202066809194 := by decide
theorem cert_e2405973786986 : check e2405973786986 [[]] .width = true := by decide
def e2405973787034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405973787034 : Closed e2405973787034 ∧ code e2405973787034 = 11202066809242 := by decide
theorem cert_e2405973787034 : check e2405973787034 [[]] .width = true := by decide
def e2405973788042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405973788042 : Closed e2405973788042 ∧ code e2405973788042 = 11202066810250 := by decide
theorem cert_e2405973788042 : check e2405973788042 [[]] .width = true := by decide
def e2405973788066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405973788066 : Closed e2405973788066 ∧ code e2405973788066 = 11202066810274 := by decide
theorem cert_e2405973788066 : check e2405973788066 [[]] .width = true := by decide
def e2405973788174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405973788174 : Closed e2405973788174 ∧ code e2405973788174 = 11202066810382 := by decide
theorem cert_e2405973788174 : check e2405973788174 [[]] .width = true := by decide
def e2405973788186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405973788186 : Closed e2405973788186 ∧ code e2405973788186 = 11202066810394 := by decide
theorem cert_e2405973788186 : check e2405973788186 [[]] .width = true := by decide
def e2405973788258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405973788258 : Closed e2405973788258 ∧ code e2405973788258 = 11202066810466 := by decide
theorem cert_e2405973788258 : check e2405973788258 [[]] .width = true := by decide
def e2405973803206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405973803206 : Closed e2405973803206 ∧ code e2405973803206 = 11202066825414 := by decide
theorem cert_e2405973803206 : check e2405973803206 [[]] .width = true := by decide
def e2405973811226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405973811226 : Closed e2405973811226 ∧ code e2405973811226 = 11202066833434 := by decide
theorem cert_e2405973811226 : check e2405973811226 [[]] .width = true := by decide
def e2405973811318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405973811318 : Closed e2405973811318 ∧ code e2405973811318 = 11202066833526 := by decide
theorem cert_e2405973811318 : check e2405973811318 [[]] .width = true := by decide
def e2405973811562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405973811562 : Closed e2405973811562 ∧ code e2405973811562 = 11202066833770 := by decide
theorem cert_e2405973811562 : check e2405973811562 [[]] .width = true := by decide
def e2405973811610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405973811610 : Closed e2405973811610 ∧ code e2405973811610 = 11202066833818 := by decide
theorem cert_e2405973811610 : check e2405973811610 [[]] .width = true := by decide
def e2405973833242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973833242 : Closed e2405973833242 ∧ code e2405973833242 = 11202066855450 := by decide
theorem cert_e2405973833242 : check e2405973833242 [[]] .width = true := by decide
def e2405973834266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973834266 : Closed e2405973834266 ∧ code e2405973834266 = 11202066856474 := by decide
theorem cert_e2405973834266 : check e2405973834266 [[]] .width = true := by decide
def e2405973843994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405973843994 : Closed e2405973843994 ∧ code e2405973843994 = 11202066866202 := by decide
theorem cert_e2405973843994 : check e2405973843994 [[]] .width = true := by decide
def e2405973844086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405973844086 : Closed e2405973844086 ∧ code e2405973844086 = 11202066866294 := by decide
theorem cert_e2405973844086 : check e2405973844086 [[]] .width = true := by decide
def e2405973844330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405973844330 : Closed e2405973844330 ∧ code e2405973844330 = 11202066866538 := by decide
theorem cert_e2405973844330 : check e2405973844330 [[]] .width = true := by decide
def e2405973844378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405973844378 : Closed e2405973844378 ∧ code e2405973844378 = 11202066866586 := by decide
theorem cert_e2405973844378 : check e2405973844378 [[]] .width = true := by decide
def e2405973895194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973895194 : Closed e2405973895194 ∧ code e2405973895194 = 11202066917402 := by decide
theorem cert_e2405973895194 : check e2405973895194 [[]] .width = true := by decide
def e2405973925914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405973925914 : Closed e2405973925914 ∧ code e2405973925914 = 11202066948122 := by decide
theorem cert_e2405973925914 : check e2405973925914 [[]] .width = true := by decide
def e2405973926006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405973926006 : Closed e2405973926006 ∧ code e2405973926006 = 11202066948214 := by decide
theorem cert_e2405973926006 : check e2405973926006 [[]] .width = true := by decide
def e2405973926250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405973926250 : Closed e2405973926250 ∧ code e2405973926250 = 11202066948458 := by decide
theorem cert_e2405973926250 : check e2405973926250 [[]] .width = true := by decide
def e2405973926298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405973926298 : Closed e2405973926298 ∧ code e2405973926298 = 11202066948506 := by decide
theorem cert_e2405973926298 : check e2405973926298 [[]] .width = true := by decide
def e2405973938374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405973938374 : Closed e2405973938374 ∧ code e2405973938374 = 11202066960582 := by decide
theorem cert_e2405973938374 : check e2405973938374 [[]] .width = true := by decide
def e2405973940250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973940250 : Closed e2405973940250 ∧ code e2405973940250 = 11202066962458 := by decide
theorem cert_e2405973940250 : check e2405973940250 [[]] .width = true := by decide
def e2405973944346 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973944346 : Closed e2405973944346 ∧ code e2405973944346 = 11202066966554 := by decide
theorem cert_e2405973944346 : check e2405973944346 [[]] .width = true := by decide
def e2405973993498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405973993498 : Closed e2405973993498 ∧ code e2405973993498 = 11202067015706 := by decide
theorem cert_e2405973993498 : check e2405973993498 [[]] .width = true := by decide
def e2405973995034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973995034 : Closed e2405973995034 ∧ code e2405973995034 = 11202067017242 := by decide
theorem cert_e2405973995034 : check e2405973995034 [[]] .width = true := by decide
def e2405973998106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405973998106 : Closed e2405973998106 ∧ code e2405973998106 = 11202067020314 := by decide
theorem cert_e2405973998106 : check e2405973998106 [[]] .width = true := by decide
def e2405974010394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974010394 : Closed e2405974010394 ∧ code e2405974010394 = 11202067032602 := by decide
theorem cert_e2405974010394 : check e2405974010394 [[]] .width = true := by decide
def e2405974018074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405974018074 : Closed e2405974018074 ∧ code e2405974018074 = 11202067040282 := by decide
theorem cert_e2405974018074 : check e2405974018074 [[]] .width = true := by decide
def e2405974024218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405974024218 : Closed e2405974024218 ∧ code e2405974024218 = 11202067046426 := by decide
theorem cert_e2405974024218 : check e2405974024218 [[]] .width = true := by decide
def e2405974024310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405974024310 : Closed e2405974024310 ∧ code e2405974024310 = 11202067046518 := by decide
theorem cert_e2405974024310 : check e2405974024310 [[]] .width = true := by decide
def e2405974024554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405974024554 : Closed e2405974024554 ∧ code e2405974024554 = 11202067046762 := by decide
theorem cert_e2405974024554 : check e2405974024554 [[]] .width = true := by decide
def e2405974024602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405974024602 : Closed e2405974024602 ∧ code e2405974024602 = 11202067046810 := by decide
theorem cert_e2405974024602 : check e2405974024602 [[]] .width = true := by decide
def e2405974028486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405974028486 : Closed e2405974028486 ∧ code e2405974028486 = 11202067050694 := by decide
theorem cert_e2405974028486 : check e2405974028486 [[]] .width = true := by decide
def e2405974030362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405974030362 : Closed e2405974030362 ∧ code e2405974030362 = 11202067052570 := by decide
theorem cert_e2405974030362 : check e2405974030362 [[]] .width = true := by decide
def e2405974042650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405974042650 : Closed e2405974042650 ∧ code e2405974042650 = 11202067064858 := by decide
theorem cert_e2405974042650 : check e2405974042650 [[]] .width = true := by decide
def e2405974044186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974044186 : Closed e2405974044186 ∧ code e2405974044186 = 11202067066394 := by decide
theorem cert_e2405974044186 : check e2405974044186 [[]] .width = true := by decide
def e2405974047258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974047258 : Closed e2405974047258 ∧ code e2405974047258 = 11202067069466 := by decide
theorem cert_e2405974047258 : check e2405974047258 [[]] .width = true := by decide
def e2405974048794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405974048794 : Closed e2405974048794 ∧ code e2405974048794 = 11202067071002 := by decide
theorem cert_e2405974048794 : check e2405974048794 [[]] .width = true := by decide
def e2405974048886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405974048886 : Closed e2405974048886 ∧ code e2405974048886 = 11202067071094 := by decide
theorem cert_e2405974048886 : check e2405974048886 [[]] .width = true := by decide
def e2405974049130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405974049130 : Closed e2405974049130 ∧ code e2405974049130 = 11202067071338 := by decide
theorem cert_e2405974049130 : check e2405974049130 [[]] .width = true := by decide
def e2405974049178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405974049178 : Closed e2405974049178 ∧ code e2405974049178 = 11202067071386 := by decide
theorem cert_e2405974049178 : check e2405974049178 [[]] .width = true := by decide
def e2405974050186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405974050186 : Closed e2405974050186 ∧ code e2405974050186 = 11202067072394 := by decide
theorem cert_e2405974050186 : check e2405974050186 [[]] .width = true := by decide
def e2405974050210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405974050210 : Closed e2405974050210 ∧ code e2405974050210 = 11202067072418 := by decide
theorem cert_e2405974050210 : check e2405974050210 [[]] .width = true := by decide
def e2405974050318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405974050318 : Closed e2405974050318 ∧ code e2405974050318 = 11202067072526 := by decide
theorem cert_e2405974050318 : check e2405974050318 [[]] .width = true := by decide
def e2405974050330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405974050330 : Closed e2405974050330 ∧ code e2405974050330 = 11202067072538 := by decide
theorem cert_e2405974050330 : check e2405974050330 [[]] .width = true := by decide
def e2405974050402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405974050402 : Closed e2405974050402 ∧ code e2405974050402 = 11202067072610 := by decide
theorem cert_e2405974050402 : check e2405974050402 [[]] .width = true := by decide
def e2405974065350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405974065350 : Closed e2405974065350 ∧ code e2405974065350 = 11202067087558 := by decide
theorem cert_e2405974065350 : check e2405974065350 [[]] .width = true := by decide
def e2405974073370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405974073370 : Closed e2405974073370 ∧ code e2405974073370 = 11202067095578 := by decide
theorem cert_e2405974073370 : check e2405974073370 [[]] .width = true := by decide
def e2405974073462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405974073462 : Closed e2405974073462 ∧ code e2405974073462 = 11202067095670 := by decide
theorem cert_e2405974073462 : check e2405974073462 [[]] .width = true := by decide
def e2405974073706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405974073706 : Closed e2405974073706 ∧ code e2405974073706 = 11202067095914 := by decide
theorem cert_e2405974073706 : check e2405974073706 [[]] .width = true := by decide
def e2405974073754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405974073754 : Closed e2405974073754 ∧ code e2405974073754 = 11202067095962 := by decide
theorem cert_e2405974073754 : check e2405974073754 [[]] .width = true := by decide
def e2405974087706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405974087706 : Closed e2405974087706 ∧ code e2405974087706 = 11202067109914 := by decide
theorem cert_e2405974087706 : check e2405974087706 [[]] .width = true := by decide
def e2405974098118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405974098118 : Closed e2405974098118 ∧ code e2405974098118 = 11202067120326 := by decide
theorem cert_e2405974098118 : check e2405974098118 [[]] .width = true := by decide
def e2405974120986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974120986 : Closed e2405974120986 ∧ code e2405974120986 = 11202067143194 := by decide
private def t_e2405974120986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405974120986 : ¬ IsSelfInterpreter e2405974120986 :=
  wSource (t := t_e2405974120986) (replay_sound (ps := []) (t := e2405974120986) (by decide)) (by decide)
def e2405974122522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405974122522 : Closed e2405974122522 ∧ code e2405974122522 = 11202067144730 := by decide
theorem cert_e2405974122522 : check e2405974122522 [[]] .width = true := by decide
def e2405974122614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405974122614 : Closed e2405974122614 ∧ code e2405974122614 = 11202067144822 := by decide
private def t_e2405974122614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405974122614 : ¬ IsSelfInterpreter e2405974122614 :=
  wSource (t := t_e2405974122614) (replay_sound (ps := []) (t := e2405974122614) (by decide)) (by decide)
def e2405974122858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405974122858 : Closed e2405974122858 ∧ code e2405974122858 = 11202067145066 := by decide
private def t_e2405974122858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405974122858 : ¬ IsSelfInterpreter e2405974122858 :=
  wSource (t := t_e2405974122858) (replay_sound (ps := []) (t := e2405974122858) (by decide)) (by decide)
def e2405974122906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405974122906 : Closed e2405974122906 ∧ code e2405974122906 = 11202067145114 := by decide
private def t_e2405974122906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405974122906 : ¬ IsSelfInterpreter e2405974122906 :=
  wSource (t := t_e2405974122906) (replay_sound (ps := []) (t := e2405974122906) (by decide)) (by decide)
def e2405974201882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974201882 : Closed e2405974201882 ∧ code e2405974201882 = 11202067224090 := by decide
theorem cert_e2405974201882 : check e2405974201882 [[]] .width = true := by decide
def e2405974202906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974202906 : Closed e2405974202906 ∧ code e2405974202906 = 11202067225114 := by decide
theorem cert_e2405974202906 : check e2405974202906 [[]] .width = true := by decide
def e2405974207002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974207002 : Closed e2405974207002 ∧ code e2405974207002 = 11202067229210 := by decide
theorem cert_e2405974207002 : check e2405974207002 [[]] .width = true := by decide
def e2405974226458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974226458 : Closed e2405974226458 ∧ code e2405974226458 = 11202067248666 := by decide
theorem cert_e2405974226458 : check e2405974226458 [[]] .width = true := by decide
def e2405974227482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974227482 : Closed e2405974227482 ∧ code e2405974227482 = 11202067249690 := by decide
theorem cert_e2405974227482 : check e2405974227482 [[]] .width = true := by decide
def e2405974237210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405974237210 : Closed e2405974237210 ∧ code e2405974237210 = 11202067259418 := by decide
theorem cert_e2405974237210 : check e2405974237210 [[]] .width = true := by decide
def e2405974237302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405974237302 : Closed e2405974237302 ∧ code e2405974237302 = 11202067259510 := by decide
theorem cert_e2405974237302 : check e2405974237302 [[]] .width = true := by decide
def e2405974237546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405974237546 : Closed e2405974237546 ∧ code e2405974237546 = 11202067259754 := by decide
theorem cert_e2405974237546 : check e2405974237546 [[]] .width = true := by decide
def e2405974237594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405974237594 : Closed e2405974237594 ∧ code e2405974237594 = 11202067259802 := by decide
theorem cert_e2405974237594 : check e2405974237594 [[]] .width = true := by decide
def e2405974252058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405974252058 : Closed e2405974252058 ∧ code e2405974252058 = 11202067274266 := by decide
private def t_e2405974252058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405974252058 : ¬ IsSelfInterpreter e2405974252058 :=
  wSource (t := t_e2405974252058) (replay_sound (ps := []) (t := e2405974252058) (by decide)) (by decide)
def e2405974253594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405974253594 : Closed e2405974253594 ∧ code e2405974253594 = 11202067275802 := by decide
theorem cert_e2405974253594 : check e2405974253594 [[]] .width = true := by decide
def e2405974253686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405974253686 : Closed e2405974253686 ∧ code e2405974253686 = 11202067275894 := by decide
private def t_e2405974253686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2405974253686 : ¬ IsSelfInterpreter e2405974253686 :=
  wSource (t := t_e2405974253686) (replay_sound (ps := []) (t := e2405974253686) (by decide)) (by decide)
def e2405974253930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405974253930 : Closed e2405974253930 ∧ code e2405974253930 = 11202067276138 := by decide
private def t_e2405974253930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2405974253930 : ¬ IsSelfInterpreter e2405974253930 :=
  wSource (t := t_e2405974253930) (replay_sound (ps := []) (t := e2405974253930) (by decide)) (by decide)
def e2405974253978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405974253978 : Closed e2405974253978 ∧ code e2405974253978 = 11202067276186 := by decide
private def t_e2405974253978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2405974253978 : ¬ IsSelfInterpreter e2405974253978 :=
  wSource (t := t_e2405974253978) (replay_sound (ps := []) (t := e2405974253978) (by decide)) (by decide)
def e2405974532122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405974532122 : Closed e2405974532122 ∧ code e2405974532122 = 11202067554330 := by decide
theorem cert_e2405974532122 : check e2405974532122 [[]] .width = true := by decide
def e2405974532214 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405974532214 : Closed e2405974532214 ∧ code e2405974532214 = 11202067554422 := by decide
theorem cert_e2405974532214 : check e2405974532214 [[]] .width = true := by decide
def e2405974532458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405974532458 : Closed e2405974532458 ∧ code e2405974532458 = 11202067554666 := by decide
theorem cert_e2405974532458 : check e2405974532458 [[]] .width = true := by decide
def e2405974532506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405974532506 : Closed e2405974532506 ∧ code e2405974532506 = 11202067554714 := by decide
theorem cert_e2405974532506 : check e2405974532506 [[]] .width = true := by decide
def e2405974634694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405974634694 : Closed e2405974634694 ∧ code e2405974634694 = 11202067656902 := by decide
theorem cert_e2405974634694 : check e2405974634694 [[]] .width = true := by decide
def e2405974652954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2405974652954 : Closed e2405974652954 ∧ code e2405974652954 = 11202067675162 := by decide
theorem cert_e2405974652954 : check e2405974652954 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405973289498
#print axioms Blc.Floor43.cert_e2405973322266
#print axioms Blc.Floor43.cert_e2405974120986
#print axioms Blc.Floor43.cert_e2405974122614
#print axioms Blc.Floor43.cert_e2405974122858
#print axioms Blc.Floor43.cert_e2405974122906
#print axioms Blc.Floor43.cert_e2405974252058
#print axioms Blc.Floor43.cert_e2405974253686
#print axioms Blc.Floor43.cert_e2405974253930
#print axioms Blc.Floor43.cert_e2405974253978
