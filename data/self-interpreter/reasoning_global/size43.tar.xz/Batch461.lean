import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406569274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406569274 : Closed e2422406569274 ∧ code e2422406569274 = 11218499591482 := by decide
theorem cert_e2422406569274 : check e2422406569274 [[],[]] .chain = true := by decide
def e2422406569370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406569370 : Closed e2422406569370 ∧ code e2422406569370 = 11218499591578 := by decide
theorem cert_e2422406569370 : check e2422406569370 [[],[]] .chain = true := by decide
def e2422406569414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406569414 : Closed e2422406569414 ∧ code e2422406569414 = 11218499591622 := by decide
theorem cert_e2422406569414 : check e2422406569414 [[],[]] .sourceHead = true := by decide
def e2422406570026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422406570026 : Closed e2422406570026 ∧ code e2422406570026 = 11218499592234 := by decide
theorem cert_e2422406570026 : check e2422406570026 [[],[]] .chain = true := by decide
def e2422406570158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406570158 : Closed e2422406570158 ∧ code e2422406570158 = 11218499592366 := by decide
theorem cert_e2422406570158 : check e2422406570158 [[],[]] .sourceHead = true := by decide
def e2422406570170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406570170 : Closed e2422406570170 ∧ code e2422406570170 = 11218499592378 := by decide
theorem cert_e2422406570170 : check e2422406570170 [[],[]] .sourceHead = true := by decide
def e2422406570198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422406570198 : Closed e2422406570198 ∧ code e2422406570198 = 11218499592406 := by decide
theorem cert_e2422406570198 : check e2422406570198 [[],[]] .chain = true := by decide
def e2422406570202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422406570202 : Closed e2422406570202 ∧ code e2422406570202 = 11218499592410 := by decide
theorem cert_e2422406570202 : check e2422406570202 [[],[]] .chain = true := by decide
def e2422406570218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422406570218 : Closed e2422406570218 ∧ code e2422406570218 = 11218499592426 := by decide
theorem cert_e2422406570218 : check e2422406570218 [[],[]] .chain = true := by decide
def e2422406570410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406570410 : Closed e2422406570410 ∧ code e2422406570410 = 11218499592618 := by decide
theorem cert_e2422406570410 : check e2422406570410 [[],[]] .sourceHead = true := by decide
def e2422406570550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406570550 : Closed e2422406570550 ∧ code e2422406570550 = 11218499592758 := by decide
theorem cert_e2422406570550 : check e2422406570550 [[],[]] .chain = true := by decide
def e2422406570554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406570554 : Closed e2422406570554 ∧ code e2422406570554 = 11218499592762 := by decide
theorem cert_e2422406570554 : check e2422406570554 [[],[]] .chain = true := by decide
def e2422406570602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422406570602 : Closed e2422406570602 ∧ code e2422406570602 = 11218499592810 := by decide
theorem cert_e2422406570602 : check e2422406570602 [[],[]] .chain = true := by decide
def e2422406570638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406570638 : Closed e2422406570638 ∧ code e2422406570638 = 11218499592846 := by decide
theorem cert_e2422406570638 : check e2422406570638 [[],[]] .chain = true := by decide
def e2422406570650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406570650 : Closed e2422406570650 ∧ code e2422406570650 = 11218499592858 := by decide
theorem cert_e2422406570650 : check e2422406570650 [[],[]] .chain = true := by decide
def e2422406570694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406570694 : Closed e2422406570694 ∧ code e2422406570694 = 11218499592902 := by decide
theorem cert_e2422406570694 : check e2422406570694 [[],[]] .chain = true := by decide
def e2422406570774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406570774 : Closed e2422406570774 ∧ code e2422406570774 = 11218499592982 := by decide
theorem cert_e2422406570774 : check e2422406570774 [[],[]] .chain = true := by decide
def e2422406570778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406570778 : Closed e2422406570778 ∧ code e2422406570778 = 11218499592986 := by decide
theorem cert_e2422406570778 : check e2422406570778 [[],[]] .chain = true := by decide
def e2422406570822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406570822 : Closed e2422406570822 ∧ code e2422406570822 = 11218499593030 := by decide
theorem cert_e2422406570822 : check e2422406570822 [[],[]] .chain = true := by decide
def e2422406570850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406570850 : Closed e2422406570850 ∧ code e2422406570850 = 11218499593058 := by decide
theorem cert_e2422406570850 : check e2422406570850 [[],[]] .chain = true := by decide
def e2422406570862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406570862 : Closed e2422406570862 ∧ code e2422406570862 = 11218499593070 := by decide
theorem cert_e2422406570862 : check e2422406570862 [[],[]] .sourceHead = true := by decide
def e2422406570870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406570870 : Closed e2422406570870 ∧ code e2422406570870 = 11218499593078 := by decide
theorem cert_e2422406570870 : check e2422406570870 [[],[]] .sourceHead = true := by decide
def e2422406570890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406570890 : Closed e2422406570890 ∧ code e2422406570890 = 11218499593098 := by decide
theorem cert_e2422406570890 : check e2422406570890 [[],[]] .chain = true := by decide
def e2422406570914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406570914 : Closed e2422406570914 ∧ code e2422406570914 = 11218499593122 := by decide
theorem cert_e2422406570914 : check e2422406570914 [[],[]] .chain = true := by decide
def e2422406570926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406570926 : Closed e2422406570926 ∧ code e2422406570926 = 11218499593134 := by decide
theorem cert_e2422406570926 : check e2422406570926 [[],[]] .sourceHead = true := by decide
def e2422406570938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406570938 : Closed e2422406570938 ∧ code e2422406570938 = 11218499593146 := by decide
theorem cert_e2422406570938 : check e2422406570938 [[],[]] .sourceHead = true := by decide
def e2422406570966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2422406570966 : Closed e2422406570966 ∧ code e2422406570966 = 11218499593174 := by decide
theorem cert_e2422406570966 : check e2422406570966 [[],[]] .sourceHead = true := by decide
def e2422406570970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2422406570970 : Closed e2422406570970 ∧ code e2422406570970 = 11218499593178 := by decide
theorem cert_e2422406570970 : check e2422406570970 [[],[]] .sourceHead = true := by decide
def e2422406571562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406571562 : Closed e2422406571562 ∧ code e2422406571562 = 11218499593770 := by decide
theorem cert_e2422406571562 : check e2422406571562 [[],[]] .chain = true := by decide
def e2422406571658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406571658 : Closed e2422406571658 ∧ code e2422406571658 = 11218499593866 := by decide
theorem cert_e2422406571658 : check e2422406571658 [[],[]] .chain = true := by decide
def e2422406571682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406571682 : Closed e2422406571682 ∧ code e2422406571682 = 11218499593890 := by decide
theorem cert_e2422406571682 : check e2422406571682 [[],[]] .chain = true := by decide
def e2422406571694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406571694 : Closed e2422406571694 ∧ code e2422406571694 = 11218499593902 := by decide
theorem cert_e2422406571694 : check e2422406571694 [[],[]] .sourceHead = true := by decide
def e2422406571702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406571702 : Closed e2422406571702 ∧ code e2422406571702 = 11218499593910 := by decide
theorem cert_e2422406571702 : check e2422406571702 [[],[]] .chain = true := by decide
def e2422406571706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406571706 : Closed e2422406571706 ∧ code e2422406571706 = 11218499593914 := by decide
theorem cert_e2422406571706 : check e2422406571706 [[],[]] .sourceHead = true := by decide
def e2422406571734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406571734 : Closed e2422406571734 ∧ code e2422406571734 = 11218499593942 := by decide
theorem cert_e2422406571734 : check e2422406571734 [[],[]] .chain = true := by decide
def e2422406571738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406571738 : Closed e2422406571738 ∧ code e2422406571738 = 11218499593946 := by decide
theorem cert_e2422406571738 : check e2422406571738 [[],[]] .chain = true := by decide
def e2422406571754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406571754 : Closed e2422406571754 ∧ code e2422406571754 = 11218499593962 := by decide
theorem cert_e2422406571754 : check e2422406571754 [[],[]] .sourceHead = true := by decide
def e2422406571862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406571862 : Closed e2422406571862 ∧ code e2422406571862 = 11218499594070 := by decide
theorem cert_e2422406571862 : check e2422406571862 [[],[]] .chain = true := by decide
def e2422406571866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406571866 : Closed e2422406571866 ∧ code e2422406571866 = 11218499594074 := by decide
theorem cert_e2422406571866 : check e2422406571866 [[],[]] .chain = true := by decide
def e2422406571882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406571882 : Closed e2422406571882 ∧ code e2422406571882 = 11218499594090 := by decide
theorem cert_e2422406571882 : check e2422406571882 [[],[]] .chain = true := by decide
def e2422406571946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406571946 : Closed e2422406571946 ∧ code e2422406571946 = 11218499594154 := by decide
theorem cert_e2422406571946 : check e2422406571946 [[],[]] .sourceHead = true := by decide
def e2422406572042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406572042 : Closed e2422406572042 ∧ code e2422406572042 = 11218499594250 := by decide
theorem cert_e2422406572042 : check e2422406572042 [[],[]] .chain = true := by decide
def e2422406572078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406572078 : Closed e2422406572078 ∧ code e2422406572078 = 11218499594286 := by decide
theorem cert_e2422406572078 : check e2422406572078 [[],[]] .sourceHead = true := by decide
def e2422406572086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406572086 : Closed e2422406572086 ∧ code e2422406572086 = 11218499594294 := by decide
theorem cert_e2422406572086 : check e2422406572086 [[],[]] .chain = true := by decide
def e2422406572090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406572090 : Closed e2422406572090 ∧ code e2422406572090 = 11218499594298 := by decide
theorem cert_e2422406572090 : check e2422406572090 [[],[]] .chain = true := by decide
def e2422406572138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406572138 : Closed e2422406572138 ∧ code e2422406572138 = 11218499594346 := by decide
theorem cert_e2422406572138 : check e2422406572138 [[],[]] .sourceHead = true := by decide
def e2422406572174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406572174 : Closed e2422406572174 ∧ code e2422406572174 = 11218499594382 := by decide
theorem cert_e2422406572174 : check e2422406572174 [[],[]] .chain = true := by decide
def e2422406572186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406572186 : Closed e2422406572186 ∧ code e2422406572186 = 11218499594394 := by decide
theorem cert_e2422406572186 : check e2422406572186 [[],[]] .chain = true := by decide
def e2422406572230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406572230 : Closed e2422406572230 ∧ code e2422406572230 = 11218499594438 := by decide
theorem cert_e2422406572230 : check e2422406572230 [[],[]] .chain = true := by decide
def e2422406572258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406572258 : Closed e2422406572258 ∧ code e2422406572258 = 11218499594466 := by decide
theorem cert_e2422406572258 : check e2422406572258 [[],[]] .chain = true := by decide
def e2422406572270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406572270 : Closed e2422406572270 ∧ code e2422406572270 = 11218499594478 := by decide
theorem cert_e2422406572270 : check e2422406572270 [[],[]] .sourceHead = true := by decide
def e2422406572278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406572278 : Closed e2422406572278 ∧ code e2422406572278 = 11218499594486 := by decide
theorem cert_e2422406572278 : check e2422406572278 [[],[]] .sourceHead = true := by decide
def e2422406572426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406572426 : Closed e2422406572426 ∧ code e2422406572426 = 11218499594634 := by decide
theorem cert_e2422406572426 : check e2422406572426 [[],[]] .chain = true := by decide
def e2422406572450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406572450 : Closed e2422406572450 ∧ code e2422406572450 = 11218499594658 := by decide
theorem cert_e2422406572450 : check e2422406572450 [[],[]] .chain = true := by decide
def e2422406572462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406572462 : Closed e2422406572462 ∧ code e2422406572462 = 11218499594670 := by decide
theorem cert_e2422406572462 : check e2422406572462 [[],[]] .sourceHead = true := by decide
def e2422406572470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406572470 : Closed e2422406572470 ∧ code e2422406572470 = 11218499594678 := by decide
theorem cert_e2422406572470 : check e2422406572470 [[],[]] .chain = true := by decide
def e2422406572474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406572474 : Closed e2422406572474 ∧ code e2422406572474 = 11218499594682 := by decide
theorem cert_e2422406572474 : check e2422406572474 [[],[]] .sourceHead = true := by decide
def e2422406572502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406572502 : Closed e2422406572502 ∧ code e2422406572502 = 11218499594710 := by decide
theorem cert_e2422406572502 : check e2422406572502 [[],[]] .chain = true := by decide
def e2422406572506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406572506 : Closed e2422406572506 ∧ code e2422406572506 = 11218499594714 := by decide
theorem cert_e2422406572506 : check e2422406572506 [[],[]] .chain = true := by decide
def e2422406572522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406572522 : Closed e2422406572522 ∧ code e2422406572522 = 11218499594730 := by decide
theorem cert_e2422406572522 : check e2422406572522 [[],[]] .sourceHead = true := by decide
def e2422406572546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406572546 : Closed e2422406572546 ∧ code e2422406572546 = 11218499594754 := by decide
theorem cert_e2422406572546 : check e2422406572546 [[],[]] .chain = true := by decide
def e2422406572558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406572558 : Closed e2422406572558 ∧ code e2422406572558 = 11218499594766 := by decide
theorem cert_e2422406572558 : check e2422406572558 [[],[]] .chain = true := by decide
def e2422406572570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406572570 : Closed e2422406572570 ∧ code e2422406572570 = 11218499594778 := by decide
theorem cert_e2422406572570 : check e2422406572570 [[],[]] .sourceHead = true := by decide
def e2422406572642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406572642 : Closed e2422406572642 ∧ code e2422406572642 = 11218499594850 := by decide
theorem cert_e2422406572642 : check e2422406572642 [[],[]] .chain = true := by decide
def e2422406572654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406572654 : Closed e2422406572654 ∧ code e2422406572654 = 11218499594862 := by decide
theorem cert_e2422406572654 : check e2422406572654 [[],[]] .sourceHead = true := by decide
def e2422406572662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406572662 : Closed e2422406572662 ∧ code e2422406572662 = 11218499594870 := by decide
theorem cert_e2422406572662 : check e2422406572662 [[],[]] .chain = true := by decide
def e2422406572666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406572666 : Closed e2422406572666 ∧ code e2422406572666 = 11218499594874 := by decide
theorem cert_e2422406572666 : check e2422406572666 [[],[]] .sourceHead = true := by decide
def e2422406572806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406572806 : Closed e2422406572806 ∧ code e2422406572806 = 11218499595014 := by decide
theorem cert_e2422406572806 : check e2422406572806 [[],[]] .chain = true := by decide
def e2422406572830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406572830 : Closed e2422406572830 ∧ code e2422406572830 = 11218499595038 := by decide
theorem cert_e2422406572830 : check e2422406572830 [[],[]] .sourceHead = true := by decide
def e2422406572854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406572854 : Closed e2422406572854 ∧ code e2422406572854 = 11218499595062 := by decide
theorem cert_e2422406572854 : check e2422406572854 [[],[]] .chain = true := by decide
def e2422406572858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406572858 : Closed e2422406572858 ∧ code e2422406572858 = 11218499595066 := by decide
theorem cert_e2422406572858 : check e2422406572858 [[],[]] .chain = true := by decide
def e2422406572930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406572930 : Closed e2422406572930 ∧ code e2422406572930 = 11218499595138 := by decide
theorem cert_e2422406572930 : check e2422406572930 [[],[]] .sourceHead = true := by decide
def e2422406572942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406572942 : Closed e2422406572942 ∧ code e2422406572942 = 11218499595150 := by decide
theorem cert_e2422406572942 : check e2422406572942 [[],[]] .sourceHead = true := by decide
def e2422406572954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406572954 : Closed e2422406572954 ∧ code e2422406572954 = 11218499595162 := by decide
theorem cert_e2422406572954 : check e2422406572954 [[],[]] .sourceHead = true := by decide
def e2422406573082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422406573082 : Closed e2422406573082 ∧ code e2422406573082 = 11218499595290 := by decide
theorem cert_e2422406573082 : check e2422406573082 [[],[]] .chain = true := by decide
def e2422406573126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422406573126 : Closed e2422406573126 ∧ code e2422406573126 = 11218499595334 := by decide
theorem cert_e2422406573126 : check e2422406573126 [[],[]] .chain = true := by decide
def e2422406573154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406573154 : Closed e2422406573154 ∧ code e2422406573154 = 11218499595362 := by decide
theorem cert_e2422406573154 : check e2422406573154 [[],[]] .chain = true := by decide
def e2422406573166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406573166 : Closed e2422406573166 ∧ code e2422406573166 = 11218499595374 := by decide
theorem cert_e2422406573166 : check e2422406573166 [[],[]] .sourceHead = true := by decide
def e2422406573178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406573178 : Closed e2422406573178 ∧ code e2422406573178 = 11218499595386 := by decide
theorem cert_e2422406573178 : check e2422406573178 [[],[]] .sourceHead = true := by decide
def e2422406573270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406573270 : Closed e2422406573270 ∧ code e2422406573270 = 11218499595478 := by decide
theorem cert_e2422406573270 : check e2422406573270 [[],[]] .chain = true := by decide
def e2422406573274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406573274 : Closed e2422406573274 ∧ code e2422406573274 = 11218499595482 := by decide
theorem cert_e2422406573274 : check e2422406573274 [[],[]] .chain = true := by decide
def e2422406573290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406573290 : Closed e2422406573290 ∧ code e2422406573290 = 11218499595498 := by decide
theorem cert_e2422406573290 : check e2422406573290 [[],[]] .chain = true := by decide
def e2422406573318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406573318 : Closed e2422406573318 ∧ code e2422406573318 = 11218499595526 := by decide
theorem cert_e2422406573318 : check e2422406573318 [[],[]] .chain = true := by decide
def e2422406573342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406573342 : Closed e2422406573342 ∧ code e2422406573342 = 11218499595550 := by decide
theorem cert_e2422406573342 : check e2422406573342 [[],[]] .sourceHead = true := by decide
def e2422406573366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406573366 : Closed e2422406573366 ∧ code e2422406573366 = 11218499595574 := by decide
theorem cert_e2422406573366 : check e2422406573366 [[],[]] .chain = true := by decide
def e2422406573370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406573370 : Closed e2422406573370 ∧ code e2422406573370 = 11218499595578 := by decide
theorem cert_e2422406573370 : check e2422406573370 [[],[]] .chain = true := by decide
def e2422406573466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406573466 : Closed e2422406573466 ∧ code e2422406573466 = 11218499595674 := by decide
theorem cert_e2422406573466 : check e2422406573466 [[],[]] .chain = true := by decide
def e2422406573510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406573510 : Closed e2422406573510 ∧ code e2422406573510 = 11218499595718 := by decide
theorem cert_e2422406573510 : check e2422406573510 [[],[]] .sourceHead = true := by decide
def e2422406573578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406573578 : Closed e2422406573578 ∧ code e2422406573578 = 11218499595786 := by decide
theorem cert_e2422406573578 : check e2422406573578 [[],[]] .sourceHead = true := by decide
def e2422406573622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406573622 : Closed e2422406573622 ∧ code e2422406573622 = 11218499595830 := by decide
theorem cert_e2422406573622 : check e2422406573622 [[],[]] .sourceHead = true := by decide
def e2422406573626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406573626 : Closed e2422406573626 ∧ code e2422406573626 = 11218499595834 := by decide
theorem cert_e2422406573626 : check e2422406573626 [[],[]] .sourceHead = true := by decide
def e2422406573674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422406573674 : Closed e2422406573674 ∧ code e2422406573674 = 11218499595882 := by decide
theorem cert_e2422406573674 : check e2422406573674 [[],[]] .sourceHead = true := by decide
def e2422406573698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))))))
theorem wire_e2422406573698 : Closed e2422406573698 ∧ code e2422406573698 = 11218499595906 := by decide
theorem cert_e2422406573698 : check e2422406573698 [[],[]] .sourceHead = true := by decide
def e2422406573710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406573710 : Closed e2422406573710 ∧ code e2422406573710 = 11218499595918 := by decide
theorem cert_e2422406573710 : check e2422406573710 [[],[]] .sourceHead = true := by decide
def e2422406573722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406573722 : Closed e2422406573722 ∧ code e2422406573722 = 11218499595930 := by decide
theorem cert_e2422406573722 : check e2422406573722 [[],[]] .sourceHead = true := by decide
def e2422406573766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406573766 : Closed e2422406573766 ∧ code e2422406573766 = 11218499595974 := by decide
theorem cert_e2422406573766 : check e2422406573766 [[],[]] .sourceHead = true := by decide
def e2422406578518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406578518 : Closed e2422406578518 ∧ code e2422406578518 = 11218499600726 := by decide
theorem cert_e2422406578518 : check e2422406578518 [[],[]] .chain = true := by decide
def e2422406578522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406578522 : Closed e2422406578522 ∧ code e2422406578522 = 11218499600730 := by decide
theorem cert_e2422406578522 : check e2422406578522 [[],[]] .chain = true := by decide
def e2422406578538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406578538 : Closed e2422406578538 ∧ code e2422406578538 = 11218499600746 := by decide
theorem cert_e2422406578538 : check e2422406578538 [[],[]] .chain = true := by decide
def e2422406579566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406579566 : Closed e2422406579566 ∧ code e2422406579566 = 11218499601774 := by decide
theorem cert_e2422406579566 : check e2422406579566 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406579574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406579574 : Closed e2422406579574 ∧ code e2422406579574 = 11218499601782 := by decide
theorem cert_e2422406579574 : check e2422406579574 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406579630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406579630 : Closed e2422406579630 ∧ code e2422406579630 = 11218499601838 := by decide
theorem cert_e2422406579630 : check e2422406579630 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406579642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406579642 : Closed e2422406579642 ∧ code e2422406579642 = 11218499601850 := by decide
theorem cert_e2422406579642 : check e2422406579642 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406579670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406579670 : Closed e2422406579670 ∧ code e2422406579670 = 11218499601878 := by decide
theorem cert_e2422406579670 : check e2422406579670 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406579674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406579674 : Closed e2422406579674 ∧ code e2422406579674 = 11218499601882 := by decide
theorem cert_e2422406579674 : check e2422406579674 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406579894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406579894 : Closed e2422406579894 ∧ code e2422406579894 = 11218499602102 := by decide
theorem cert_e2422406579894 : check e2422406579894 [[],[]] .chain = true := by decide
def e2422406579926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406579926 : Closed e2422406579926 ∧ code e2422406579926 = 11218499602134 := by decide
theorem cert_e2422406579926 : check e2422406579926 [[],[]] .chain = true := by decide
def e2422406579930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406579930 : Closed e2422406579930 ∧ code e2422406579930 = 11218499602138 := by decide
theorem cert_e2422406579930 : check e2422406579930 [[],[]] .chain = true := by decide
def e2422406580054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406580054 : Closed e2422406580054 ∧ code e2422406580054 = 11218499602262 := by decide
theorem cert_e2422406580054 : check e2422406580054 [[],[]] .chain = true := by decide
def e2422406580058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406580058 : Closed e2422406580058 ∧ code e2422406580058 = 11218499602266 := by decide
theorem cert_e2422406580058 : check e2422406580058 [[],[]] .chain = true := by decide
def e2422406580074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406580074 : Closed e2422406580074 ∧ code e2422406580074 = 11218499602282 := by decide
theorem cert_e2422406580074 : check e2422406580074 [[],[]] .chain = true := by decide
def e2422406580138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406580138 : Closed e2422406580138 ∧ code e2422406580138 = 11218499602346 := by decide
theorem cert_e2422406580138 : check e2422406580138 [[],[]] .chain = true := by decide
def e2422406581590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406581590 : Closed e2422406581590 ∧ code e2422406581590 = 11218499603798 := by decide
private def t_e2422406581590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 0)) (.var 1))))))
theorem cert_e2422406581590 : ¬ IsSelfInterpreter e2422406581590 :=
  wSource (t := t_e2422406581590) (replay_sound (ps := []) (t := e2422406581590) (by decide)) (by decide)
def e2422406581594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406581594 : Closed e2422406581594 ∧ code e2422406581594 = 11218499603802 := by decide
private def t_e2422406581594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)) (.var 0))))))
theorem cert_e2422406581594 : ¬ IsSelfInterpreter e2422406581594 :=
  wSource (t := t_e2422406581594) (replay_sound (ps := []) (t := e2422406581594) (by decide)) (by decide)
def e2422406581610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406581610 : Closed e2422406581610 ∧ code e2422406581610 = 11218499603818 := by decide
private def t_e2422406581610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)) (.var 0))))))
theorem cert_e2422406581610 : ¬ IsSelfInterpreter e2422406581610 :=
  wSource (t := t_e2422406581610) (replay_sound (ps := []) (t := e2422406581610) (by decide)) (by decide)
def e2422406582710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422406582710 : Closed e2422406582710 ∧ code e2422406582710 = 11218499604918 := by decide
theorem cert_e2422406582710 : check e2422406582710 [[],[]] .chain = true := by decide
def e2422406582742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406582742 : Closed e2422406582742 ∧ code e2422406582742 = 11218499604950 := by decide
theorem cert_e2422406582742 : check e2422406582742 [[],[]] .chain = true := by decide
def e2422406582746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406582746 : Closed e2422406582746 ∧ code e2422406582746 = 11218499604954 := by decide
theorem cert_e2422406582746 : check e2422406582746 [[],[]] .chain = true := by decide
def e2422406583126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406583126 : Closed e2422406583126 ∧ code e2422406583126 = 11218499605334 := by decide
theorem cert_e2422406583126 : check e2422406583126 [[],[]] .chain = true := by decide
def e2422406583130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406583130 : Closed e2422406583130 ∧ code e2422406583130 = 11218499605338 := by decide
theorem cert_e2422406583130 : check e2422406583130 [[],[]] .chain = true := by decide
def e2422406583146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406583146 : Closed e2422406583146 ∧ code e2422406583146 = 11218499605354 := by decide
theorem cert_e2422406583146 : check e2422406583146 [[],[]] .chain = true := by decide
def e2422406583210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406583210 : Closed e2422406583210 ∧ code e2422406583210 = 11218499605418 := by decide
theorem cert_e2422406583210 : check e2422406583210 [[],[]] .chain = true := by decide
def e2422406583414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406583414 : Closed e2422406583414 ∧ code e2422406583414 = 11218499605622 := by decide
theorem cert_e2422406583414 : check e2422406583414 [[],[]] .chain = true := by decide
def e2422406583510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406583510 : Closed e2422406583510 ∧ code e2422406583510 = 11218499605718 := by decide
theorem cert_e2422406583510 : check e2422406583510 [[],[]] .chain = true := by decide
def e2422406583514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406583514 : Closed e2422406583514 ∧ code e2422406583514 = 11218499605722 := by decide
theorem cert_e2422406583514 : check e2422406583514 [[],[]] .chain = true := by decide
def e2422406583530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406583530 : Closed e2422406583530 ∧ code e2422406583530 = 11218499605738 := by decide
theorem cert_e2422406583530 : check e2422406583530 [[],[]] .chain = true := by decide
def e2422406583606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406583606 : Closed e2422406583606 ∧ code e2422406583606 = 11218499605814 := by decide
theorem cert_e2422406583606 : check e2422406583606 [[],[]] .chain = true := by decide
def e2422406583610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406583610 : Closed e2422406583610 ∧ code e2422406583610 = 11218499605818 := by decide
theorem cert_e2422406583610 : check e2422406583610 [[],[]] .chain = true := by decide
def e2422406583694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406583694 : Closed e2422406583694 ∧ code e2422406583694 = 11218499605902 := by decide
theorem cert_e2422406583694 : check e2422406583694 [[],[]] .chain = true := by decide
def e2422406583706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406583706 : Closed e2422406583706 ∧ code e2422406583706 = 11218499605914 := by decide
theorem cert_e2422406583706 : check e2422406583706 [[],[]] .chain = true := by decide
def e2422406583862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406583862 : Closed e2422406583862 ∧ code e2422406583862 = 11218499606070 := by decide
theorem cert_e2422406583862 : check e2422406583862 [[],[]] .chain = true := by decide
def e2422406583866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406583866 : Closed e2422406583866 ∧ code e2422406583866 = 11218499606074 := by decide
theorem cert_e2422406583866 : check e2422406583866 [[],[]] .chain = true := by decide
def e2422406583914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422406583914 : Closed e2422406583914 ∧ code e2422406583914 = 11218499606122 := by decide
theorem cert_e2422406583914 : check e2422406583914 [[],[]] .chain = true := by decide
def e2422406583950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406583950 : Closed e2422406583950 ∧ code e2422406583950 = 11218499606158 := by decide
theorem cert_e2422406583950 : check e2422406583950 [[],[]] .chain = true := by decide
def e2422406583962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406583962 : Closed e2422406583962 ∧ code e2422406583962 = 11218499606170 := by decide
theorem cert_e2422406583962 : check e2422406583962 [[],[]] .chain = true := by decide
def e2422406584006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406584006 : Closed e2422406584006 ∧ code e2422406584006 = 11218499606214 := by decide
theorem cert_e2422406584006 : check e2422406584006 [[],[]] .chain = true := by decide
def e2422406584502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406584502 : Closed e2422406584502 ∧ code e2422406584502 = 11218499606710 := by decide
theorem cert_e2422406584502 : check e2422406584502 [[],[]] .chain = true := by decide
def e2422406584534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406584534 : Closed e2422406584534 ∧ code e2422406584534 = 11218499606742 := by decide
theorem cert_e2422406584534 : check e2422406584534 [[],[]] .chain = true := by decide
def e2422406584538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406584538 : Closed e2422406584538 ∧ code e2422406584538 = 11218499606746 := by decide
theorem cert_e2422406584538 : check e2422406584538 [[],[]] .chain = true := by decide
def e2422406584554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406584554 : Closed e2422406584554 ∧ code e2422406584554 = 11218499606762 := by decide
theorem cert_e2422406584554 : check e2422406584554 [[],[]] .chain = true := by decide
def e2422406584886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406584886 : Closed e2422406584886 ∧ code e2422406584886 = 11218499607094 := by decide
theorem cert_e2422406584886 : check e2422406584886 [[],[]] .chain = true := by decide
def e2422406584890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406584890 : Closed e2422406584890 ∧ code e2422406584890 = 11218499607098 := by decide
theorem cert_e2422406584890 : check e2422406584890 [[],[]] .chain = true := by decide
def e2422406584974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406584974 : Closed e2422406584974 ∧ code e2422406584974 = 11218499607182 := by decide
theorem cert_e2422406584974 : check e2422406584974 [[],[]] .chain = true := by decide
def e2422406585030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406585030 : Closed e2422406585030 ∧ code e2422406585030 = 11218499607238 := by decide
theorem cert_e2422406585030 : check e2422406585030 [[],[]] .chain = true := by decide
def e2422406585110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406585110 : Closed e2422406585110 ∧ code e2422406585110 = 11218499607318 := by decide
theorem cert_e2422406585110 : check e2422406585110 [[],[]] .chain = true := by decide
def e2422406585114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406585114 : Closed e2422406585114 ∧ code e2422406585114 = 11218499607322 := by decide
theorem cert_e2422406585114 : check e2422406585114 [[],[]] .chain = true := by decide
def e2422406585158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406585158 : Closed e2422406585158 ∧ code e2422406585158 = 11218499607366 := by decide
theorem cert_e2422406585158 : check e2422406585158 [[],[]] .chain = true := by decide
def e2422406585186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406585186 : Closed e2422406585186 ∧ code e2422406585186 = 11218499607394 := by decide
theorem cert_e2422406585186 : check e2422406585186 [[],[]] .chain = true := by decide
def e2422406585198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406585198 : Closed e2422406585198 ∧ code e2422406585198 = 11218499607406 := by decide
theorem cert_e2422406585198 : check e2422406585198 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406585206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406585206 : Closed e2422406585206 ∧ code e2422406585206 = 11218499607414 := by decide
theorem cert_e2422406585206 : check e2422406585206 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406585270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406585270 : Closed e2422406585270 ∧ code e2422406585270 = 11218499607478 := by decide
theorem cert_e2422406585270 : check e2422406585270 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406585430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406585430 : Closed e2422406585430 ∧ code e2422406585430 = 11218499607638 := by decide
theorem cert_e2422406585430 : check e2422406585430 [[],[]] .chain = true := by decide
def e2422406585434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406585434 : Closed e2422406585434 ∧ code e2422406585434 = 11218499607642 := by decide
theorem cert_e2422406585434 : check e2422406585434 [[],[]] .chain = true := by decide
def e2422406585450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406585450 : Closed e2422406585450 ∧ code e2422406585450 = 11218499607658 := by decide
theorem cert_e2422406585450 : check e2422406585450 [[],[]] .chain = true := by decide
def e2422406585622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406585622 : Closed e2422406585622 ∧ code e2422406585622 = 11218499607830 := by decide
theorem cert_e2422406585622 : check e2422406585622 [[],[]] .chain = true := by decide
def e2422406585626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406585626 : Closed e2422406585626 ∧ code e2422406585626 = 11218499607834 := by decide
theorem cert_e2422406585626 : check e2422406585626 [[],[]] .chain = true := by decide
def e2422406585670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406585670 : Closed e2422406585670 ∧ code e2422406585670 = 11218499607878 := by decide
theorem cert_e2422406585670 : check e2422406585670 [[],[]] .chain = true := by decide
def e2422406585698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406585698 : Closed e2422406585698 ∧ code e2422406585698 = 11218499607906 := by decide
theorem cert_e2422406585698 : check e2422406585698 [[],[]] .chain = true := by decide
def e2422406585710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406585710 : Closed e2422406585710 ∧ code e2422406585710 = 11218499607918 := by decide
theorem cert_e2422406585710 : check e2422406585710 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406585718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406585718 : Closed e2422406585718 ∧ code e2422406585718 = 11218499607926 := by decide
theorem cert_e2422406585718 : check e2422406585718 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422406581590
#print axioms Blc.Floor43.cert_e2422406581594
#print axioms Blc.Floor43.cert_e2422406581610
