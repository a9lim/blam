import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406346146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406346146 : Closed e2422406346146 ∧ code e2422406346146 = 11218499368354 := by decide
theorem cert_e2422406346146 : check e2422406346146 [[],[]] .chain = true := by decide
def e2422406346158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406346158 : Closed e2422406346158 ∧ code e2422406346158 = 11218499368366 := by decide
theorem cert_e2422406346158 : check e2422406346158 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406346166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2422406346166 : Closed e2422406346166 ∧ code e2422406346166 = 11218499368374 := by decide
theorem cert_e2422406346166 : check e2422406346166 [[],[]] .chain = true := by decide
def e2422406346170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406346170 : Closed e2422406346170 ∧ code e2422406346170 = 11218499368378 := by decide
theorem cert_e2422406346170 : check e2422406346170 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406346198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406346198 : Closed e2422406346198 ∧ code e2422406346198 = 11218499368406 := by decide
theorem cert_e2422406346198 : checkPay e2422406346198 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406346202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406346202 : Closed e2422406346202 ∧ code e2422406346202 = 11218499368410 := by decide
theorem cert_e2422406346202 : check e2422406346202 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406346282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406346282 : Closed e2422406346282 ∧ code e2422406346282 = 11218499368490 := by decide
theorem cert_e2422406346282 : check e2422406346282 [[],[]] .chain = true := by decide
def e2422406346378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406346378 : Closed e2422406346378 ∧ code e2422406346378 = 11218499368586 := by decide
theorem cert_e2422406346378 : check e2422406346378 [[],[]] .chain = true := by decide
def e2422406346402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406346402 : Closed e2422406346402 ∧ code e2422406346402 = 11218499368610 := by decide
theorem cert_e2422406346402 : check e2422406346402 [[],[]] .chain = true := by decide
def e2422406346414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406346414 : Closed e2422406346414 ∧ code e2422406346414 = 11218499368622 := by decide
theorem cert_e2422406346414 : check e2422406346414 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406346422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406346422 : Closed e2422406346422 ∧ code e2422406346422 = 11218499368630 := by decide
theorem cert_e2422406346422 : check e2422406346422 [[],[]] .chain = true := by decide
def e2422406346426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406346426 : Closed e2422406346426 ∧ code e2422406346426 = 11218499368634 := by decide
theorem cert_e2422406346426 : check e2422406346426 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406346454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406346454 : Closed e2422406346454 ∧ code e2422406346454 = 11218499368662 := by decide
theorem cert_e2422406346454 : check e2422406346454 [[],[]] .chain = true := by decide
def e2422406346458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406346458 : Closed e2422406346458 ∧ code e2422406346458 = 11218499368666 := by decide
theorem cert_e2422406346458 : check e2422406346458 [[],[]] .chain = true := by decide
def e2422406346474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406346474 : Closed e2422406346474 ∧ code e2422406346474 = 11218499368682 := by decide
theorem cert_e2422406346474 : check e2422406346474 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406346582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406346582 : Closed e2422406346582 ∧ code e2422406346582 = 11218499368790 := by decide
def e2422406346586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406346586 : Closed e2422406346586 ∧ code e2422406346586 = 11218499368794 := by decide
def e2422406346602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406346602 : Closed e2422406346602 ∧ code e2422406346602 = 11218499368810 := by decide
theorem cert_e2422406346602 : check e2422406346602 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406351534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406351534 : Closed e2422406351534 ∧ code e2422406351534 = 11218499373742 := by decide
theorem cert_e2422406351534 : check e2422406351534 [[],[]] .chain = true := by decide
def e2422406351546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406351546 : Closed e2422406351546 ∧ code e2422406351546 = 11218499373754 := by decide
theorem cert_e2422406351546 : check e2422406351546 [[],[]] .chain = true := by decide
def e2422406351594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406351594 : Closed e2422406351594 ∧ code e2422406351594 = 11218499373802 := by decide
theorem cert_e2422406351594 : check e2422406351594 [[],[]] .chain = true := by decide
def e2422406351786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406351786 : Closed e2422406351786 ∧ code e2422406351786 = 11218499373994 := by decide
theorem cert_e2422406351786 : check e2422406351786 [[],[]] .chain = true := by decide
def e2422406357678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406357678 : Closed e2422406357678 ∧ code e2422406357678 = 11218499379886 := by decide
theorem cert_e2422406357678 : check e2422406357678 [[],[]] .chain = true := by decide
def e2422406357690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406357690 : Closed e2422406357690 ∧ code e2422406357690 = 11218499379898 := by decide
theorem cert_e2422406357690 : check e2422406357690 [[],[]] .chain = true := by decide
def e2422406357738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406357738 : Closed e2422406357738 ∧ code e2422406357738 = 11218499379946 := by decide
theorem cert_e2422406357738 : check e2422406357738 [[],[]] .chain = true := by decide
def e2422406359214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406359214 : Closed e2422406359214 ∧ code e2422406359214 = 11218499381422 := by decide
theorem cert_e2422406359214 : check e2422406359214 [[],[]] .chain = true := by decide
def e2422406359226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406359226 : Closed e2422406359226 ∧ code e2422406359226 = 11218499381434 := by decide
theorem cert_e2422406359226 : check e2422406359226 [[],[]] .chain = true := by decide
def e2422406359598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406359598 : Closed e2422406359598 ∧ code e2422406359598 = 11218499381806 := by decide
theorem cert_e2422406359598 : check e2422406359598 [[],[]] .chain = true := by decide
def e2422406359778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406359778 : Closed e2422406359778 ∧ code e2422406359778 = 11218499381986 := by decide
theorem cert_e2422406359778 : check e2422406359778 [[],[]] .chain = true := by decide
def e2422406359790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406359790 : Closed e2422406359790 ∧ code e2422406359790 = 11218499381998 := by decide
theorem cert_e2422406359790 : check e2422406359790 [[],[]] .sourceHead = true := by decide
def e2422406359918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406359918 : Closed e2422406359918 ∧ code e2422406359918 = 11218499382126 := by decide
theorem cert_e2422406359918 : check e2422406359918 [[],[]] .chain = true := by decide
def e2422406359926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406359926 : Closed e2422406359926 ∧ code e2422406359926 = 11218499382134 := by decide
theorem cert_e2422406359926 : check e2422406359926 [[],[]] .chain = true := by decide
def e2422406359946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406359946 : Closed e2422406359946 ∧ code e2422406359946 = 11218499382154 := by decide
theorem cert_e2422406359946 : check e2422406359946 [[],[]] .chain = true := by decide
def e2422406359970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406359970 : Closed e2422406359970 ∧ code e2422406359970 = 11218499382178 := by decide
theorem cert_e2422406359970 : check e2422406359970 [[],[]] .chain = true := by decide
def e2422406359982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406359982 : Closed e2422406359982 ∧ code e2422406359982 = 11218499382190 := by decide
theorem cert_e2422406359982 : check e2422406359982 [[],[]] .sourceHead = true := by decide
def e2422406359990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406359990 : Closed e2422406359990 ∧ code e2422406359990 = 11218499382198 := by decide
theorem cert_e2422406359990 : check e2422406359990 [[],[]] .chain = true := by decide
def e2422406359994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406359994 : Closed e2422406359994 ∧ code e2422406359994 = 11218499382202 := by decide
theorem cert_e2422406359994 : check e2422406359994 [[],[]] .sourceHead = true := by decide
def e2422406360430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406360430 : Closed e2422406360430 ∧ code e2422406360430 = 11218499382638 := by decide
theorem cert_e2422406360430 : check e2422406360430 [[],[]] .chain = true := by decide
def e2422406360438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406360438 : Closed e2422406360438 ∧ code e2422406360438 = 11218499382646 := by decide
theorem cert_e2422406360438 : check e2422406360438 [[],[]] .chain = true := by decide
def e2422406360494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406360494 : Closed e2422406360494 ∧ code e2422406360494 = 11218499382702 := by decide
theorem cert_e2422406360494 : check e2422406360494 [[],[]] .chain = true := by decide
def e2422406360506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406360506 : Closed e2422406360506 ∧ code e2422406360506 = 11218499382714 := by decide
theorem cert_e2422406360506 : check e2422406360506 [[],[]] .chain = true := by decide
def e2422406360534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406360534 : Closed e2422406360534 ∧ code e2422406360534 = 11218499382742 := by decide
theorem cert_e2422406360534 : check e2422406360534 [[],[]] .chain = true := by decide
def e2422406360538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406360538 : Closed e2422406360538 ∧ code e2422406360538 = 11218499382746 := by decide
theorem cert_e2422406360538 : check e2422406360538 [[],[]] .chain = true := by decide
def e2422406360618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406360618 : Closed e2422406360618 ∧ code e2422406360618 = 11218499382826 := by decide
theorem cert_e2422406360618 : check e2422406360618 [[],[]] .chain = true := by decide
def e2422406360714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406360714 : Closed e2422406360714 ∧ code e2422406360714 = 11218499382922 := by decide
theorem cert_e2422406360714 : check e2422406360714 [[],[]] .chain = true := by decide
def e2422406360738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406360738 : Closed e2422406360738 ∧ code e2422406360738 = 11218499382946 := by decide
theorem cert_e2422406360738 : check e2422406360738 [[],[]] .chain = true := by decide
def e2422406360750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406360750 : Closed e2422406360750 ∧ code e2422406360750 = 11218499382958 := by decide
theorem cert_e2422406360750 : check e2422406360750 [[],[]] .sourceHead = true := by decide
def e2422406360758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406360758 : Closed e2422406360758 ∧ code e2422406360758 = 11218499382966 := by decide
theorem cert_e2422406360758 : check e2422406360758 [[],[]] .chain = true := by decide
def e2422406360762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406360762 : Closed e2422406360762 ∧ code e2422406360762 = 11218499382970 := by decide
theorem cert_e2422406360762 : check e2422406360762 [[],[]] .sourceHead = true := by decide
def e2422406360790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406360790 : Closed e2422406360790 ∧ code e2422406360790 = 11218499382998 := by decide
theorem cert_e2422406360790 : check e2422406360790 [[],[]] .chain = true := by decide
def e2422406360794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406360794 : Closed e2422406360794 ∧ code e2422406360794 = 11218499383002 := by decide
theorem cert_e2422406360794 : check e2422406360794 [[],[]] .chain = true := by decide
def e2422406360810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406360810 : Closed e2422406360810 ∧ code e2422406360810 = 11218499383018 := by decide
theorem cert_e2422406360810 : check e2422406360810 [[],[]] .sourceHead = true := by decide
def e2422406362478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406362478 : Closed e2422406362478 ∧ code e2422406362478 = 11218499384686 := by decide
theorem cert_e2422406362478 : check e2422406362478 [[],[]] .chain = true := by decide
def e2422406362486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406362486 : Closed e2422406362486 ∧ code e2422406362486 = 11218499384694 := by decide
theorem cert_e2422406362486 : check e2422406362486 [[],[]] .chain = true := by decide
def e2422406362542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406362542 : Closed e2422406362542 ∧ code e2422406362542 = 11218499384750 := by decide
theorem cert_e2422406362542 : check e2422406362542 [[],[]] .chain = true := by decide
def e2422406362554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406362554 : Closed e2422406362554 ∧ code e2422406362554 = 11218499384762 := by decide
theorem cert_e2422406362554 : check e2422406362554 [[],[]] .chain = true := by decide
def e2422406362582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406362582 : Closed e2422406362582 ∧ code e2422406362582 = 11218499384790 := by decide
theorem cert_e2422406362582 : check e2422406362582 [[],[]] .chain = true := by decide
def e2422406362586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406362586 : Closed e2422406362586 ∧ code e2422406362586 = 11218499384794 := by decide
theorem cert_e2422406362586 : check e2422406362586 [[],[]] .chain = true := by decide
def e2422406362798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406362798 : Closed e2422406362798 ∧ code e2422406362798 = 11218499385006 := by decide
theorem cert_e2422406362798 : check e2422406362798 [[],[]] .chain = true := by decide
def e2422406362810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406362810 : Closed e2422406362810 ∧ code e2422406362810 = 11218499385018 := by decide
theorem cert_e2422406362810 : check e2422406362810 [[],[]] .chain = true := by decide
def e2422406362858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406362858 : Closed e2422406362858 ∧ code e2422406362858 = 11218499385066 := by decide
theorem cert_e2422406362858 : check e2422406362858 [[],[]] .chain = true := by decide
def e2422406362966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406362966 : Closed e2422406362966 ∧ code e2422406362966 = 11218499385174 := by decide
theorem cert_e2422406362966 : check e2422406362966 [[],[]] .chain = true := by decide
def e2422406362970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406362970 : Closed e2422406362970 ∧ code e2422406362970 = 11218499385178 := by decide
theorem cert_e2422406362970 : check e2422406362970 [[],[]] .chain = true := by decide
def e2422406362986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406362986 : Closed e2422406362986 ∧ code e2422406362986 = 11218499385194 := by decide
theorem cert_e2422406362986 : check e2422406362986 [[],[]] .chain = true := by decide
def e2422406363306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406363306 : Closed e2422406363306 ∧ code e2422406363306 = 11218499385514 := by decide
theorem cert_e2422406363306 : check e2422406363306 [[],[]] .chain = true := by decide
def e2422406363690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406363690 : Closed e2422406363690 ∧ code e2422406363690 = 11218499385898 := by decide
theorem cert_e2422406363690 : check e2422406363690 [[],[]] .chain = true := by decide
def e2422406363786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406363786 : Closed e2422406363786 ∧ code e2422406363786 = 11218499385994 := by decide
theorem cert_e2422406363786 : check e2422406363786 [[],[]] .chain = true := by decide
def e2422406363810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406363810 : Closed e2422406363810 ∧ code e2422406363810 = 11218499386018 := by decide
theorem cert_e2422406363810 : check e2422406363810 [[],[]] .chain = true := by decide
def e2422406363822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406363822 : Closed e2422406363822 ∧ code e2422406363822 = 11218499386030 := by decide
theorem cert_e2422406363822 : check e2422406363822 [[],[]] .sourceHead = true := by decide
def e2422406363830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406363830 : Closed e2422406363830 ∧ code e2422406363830 = 11218499386038 := by decide
theorem cert_e2422406363830 : check e2422406363830 [[],[]] .chain = true := by decide
def e2422406363834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406363834 : Closed e2422406363834 ∧ code e2422406363834 = 11218499386042 := by decide
theorem cert_e2422406363834 : check e2422406363834 [[],[]] .sourceHead = true := by decide
def e2422406363862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406363862 : Closed e2422406363862 ∧ code e2422406363862 = 11218499386070 := by decide
theorem cert_e2422406363862 : check e2422406363862 [[],[]] .chain = true := by decide
def e2422406363866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406363866 : Closed e2422406363866 ∧ code e2422406363866 = 11218499386074 := by decide
theorem cert_e2422406363866 : check e2422406363866 [[],[]] .chain = true := by decide
def e2422406363882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406363882 : Closed e2422406363882 ∧ code e2422406363882 = 11218499386090 := by decide
theorem cert_e2422406363882 : check e2422406363882 [[],[]] .sourceHead = true := by decide
def e2422406363990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406363990 : Closed e2422406363990 ∧ code e2422406363990 = 11218499386198 := by decide
theorem cert_e2422406363990 : check e2422406363990 [[],[]] .chain = true := by decide
def e2422406363994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406363994 : Closed e2422406363994 ∧ code e2422406363994 = 11218499386202 := by decide
theorem cert_e2422406363994 : check e2422406363994 [[],[]] .chain = true := by decide
def e2422406364010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406364010 : Closed e2422406364010 ∧ code e2422406364010 = 11218499386218 := by decide
theorem cert_e2422406364010 : check e2422406364010 [[],[]] .chain = true := by decide
def e2422406364074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406364074 : Closed e2422406364074 ∧ code e2422406364074 = 11218499386282 := by decide
theorem cert_e2422406364074 : check e2422406364074 [[],[]] .sourceHead = true := by decide
def e2422406366550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406366550 : Closed e2422406366550 ∧ code e2422406366550 = 11218499388758 := by decide
theorem cert_e2422406366550 : check e2422406366550 [[],[]] .chain = true := by decide
def e2422406366554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406366554 : Closed e2422406366554 ∧ code e2422406366554 = 11218499388762 := by decide
theorem cert_e2422406366554 : check e2422406366554 [[],[]] .chain = true := by decide
def e2422406366570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406366570 : Closed e2422406366570 ∧ code e2422406366570 = 11218499388778 := by decide
theorem cert_e2422406366570 : check e2422406366570 [[],[]] .chain = true := by decide
def e2422406366634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406366634 : Closed e2422406366634 ∧ code e2422406366634 = 11218499388842 := by decide
theorem cert_e2422406366634 : check e2422406366634 [[],[]] .chain = true := by decide
def e2422406369622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406369622 : Closed e2422406369622 ∧ code e2422406369622 = 11218499391830 := by decide
theorem cert_e2422406369622 : check e2422406369622 [[],[]] .chain = true := by decide
def e2422406369626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406369626 : Closed e2422406369626 ∧ code e2422406369626 = 11218499391834 := by decide
theorem cert_e2422406369626 : check e2422406369626 [[],[]] .chain = true := by decide
def e2422406369642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406369642 : Closed e2422406369642 ∧ code e2422406369642 = 11218499391850 := by decide
theorem cert_e2422406369642 : check e2422406369642 [[],[]] .chain = true := by decide
def e2422406370390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406370390 : Closed e2422406370390 ∧ code e2422406370390 = 11218499392598 := by decide
theorem cert_e2422406370390 : check e2422406370390 [[],[]] .chain = true := by decide
def e2422406370394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406370394 : Closed e2422406370394 ∧ code e2422406370394 = 11218499392602 := by decide
theorem cert_e2422406370394 : check e2422406370394 [[],[]] .chain = true := by decide
def e2422406370582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406370582 : Closed e2422406370582 ∧ code e2422406370582 = 11218499392790 := by decide
theorem cert_e2422406370582 : check e2422406370582 [[],[]] .chain = true := by decide
def e2422406370658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406370658 : Closed e2422406370658 ∧ code e2422406370658 = 11218499392866 := by decide
theorem cert_e2422406370658 : check e2422406370658 [[],[]] .chain = true := by decide
def e2422406370670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406370670 : Closed e2422406370670 ∧ code e2422406370670 = 11218499392878 := by decide
theorem cert_e2422406370670 : check e2422406370670 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406370678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406370678 : Closed e2422406370678 ∧ code e2422406370678 = 11218499392886 := by decide
theorem cert_e2422406370678 : check e2422406370678 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406370698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406370698 : Closed e2422406370698 ∧ code e2422406370698 = 11218499392906 := by decide
theorem cert_e2422406370698 : check e2422406370698 [[],[]] .chain = true := by decide
def e2422406370722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406370722 : Closed e2422406370722 ∧ code e2422406370722 = 11218499392930 := by decide
theorem cert_e2422406370722 : check e2422406370722 [[],[]] .chain = true := by decide
def e2422406370734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406370734 : Closed e2422406370734 ∧ code e2422406370734 = 11218499392942 := by decide
theorem cert_e2422406370734 : check e2422406370734 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406370742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2422406370742 : Closed e2422406370742 ∧ code e2422406370742 = 11218499392950 := by decide
theorem cert_e2422406370742 : check e2422406370742 [[],[]] .chain = true := by decide
def e2422406370746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406370746 : Closed e2422406370746 ∧ code e2422406370746 = 11218499392954 := by decide
theorem cert_e2422406370746 : check e2422406370746 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406370774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406370774 : Closed e2422406370774 ∧ code e2422406370774 = 11218499392982 := by decide
theorem cert_e2422406370774 : checkPay e2422406370774 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422406370778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406370778 : Closed e2422406370778 ∧ code e2422406370778 = 11218499392986 := by decide
def e2422406370858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406370858 : Closed e2422406370858 ∧ code e2422406370858 = 11218499393066 := by decide
theorem cert_e2422406370858 : check e2422406370858 [[],[]] .chain = true := by decide
def e2422406370954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406370954 : Closed e2422406370954 ∧ code e2422406370954 = 11218499393162 := by decide
theorem cert_e2422406370954 : check e2422406370954 [[],[]] .chain = true := by decide
def e2422406370978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406370978 : Closed e2422406370978 ∧ code e2422406370978 = 11218499393186 := by decide
theorem cert_e2422406370978 : check e2422406370978 [[],[]] .chain = true := by decide
def e2422406370990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406370990 : Closed e2422406370990 ∧ code e2422406370990 = 11218499393198 := by decide
theorem cert_e2422406370990 : check e2422406370990 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406370998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406370998 : Closed e2422406370998 ∧ code e2422406370998 = 11218499393206 := by decide
theorem cert_e2422406370998 : check e2422406370998 [[],[]] .chain = true := by decide
def e2422406371002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406371002 : Closed e2422406371002 ∧ code e2422406371002 = 11218499393210 := by decide
theorem cert_e2422406371002 : check e2422406371002 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406371030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406371030 : Closed e2422406371030 ∧ code e2422406371030 = 11218499393238 := by decide
theorem cert_e2422406371030 : check e2422406371030 [[],[]] .chain = true := by decide
def e2422406371034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406371034 : Closed e2422406371034 ∧ code e2422406371034 = 11218499393242 := by decide
theorem cert_e2422406371034 : check e2422406371034 [[],[]] .chain = true := by decide
def e2422406371050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406371050 : Closed e2422406371050 ∧ code e2422406371050 = 11218499393258 := by decide
theorem cert_e2422406371050 : check e2422406371050 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406371158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406371158 : Closed e2422406371158 ∧ code e2422406371158 = 11218499393366 := by decide
theorem cert_e2422406371158 : check e2422406371158 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406371162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406371162 : Closed e2422406371162 ∧ code e2422406371162 = 11218499393370 := by decide
theorem cert_e2422406371162 : check e2422406371162 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406371178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406371178 : Closed e2422406371178 ∧ code e2422406371178 = 11218499393386 := by decide
theorem cert_e2422406371178 : check e2422406371178 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406371498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406371498 : Closed e2422406371498 ∧ code e2422406371498 = 11218499393706 := by decide
theorem cert_e2422406371498 : check e2422406371498 [[],[]] .chain = true := by decide
def e2422406371882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406371882 : Closed e2422406371882 ∧ code e2422406371882 = 11218499394090 := by decide
theorem cert_e2422406371882 : check e2422406371882 [[],[]] .chain = true := by decide
def e2422406371978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406371978 : Closed e2422406371978 ∧ code e2422406371978 = 11218499394186 := by decide
theorem cert_e2422406371978 : check e2422406371978 [[],[]] .chain = true := by decide
def e2422406372002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406372002 : Closed e2422406372002 ∧ code e2422406372002 = 11218499394210 := by decide
theorem cert_e2422406372002 : check e2422406372002 [[],[]] .chain = true := by decide
def e2422406372014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406372014 : Closed e2422406372014 ∧ code e2422406372014 = 11218499394222 := by decide
theorem cert_e2422406372014 : check e2422406372014 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406372022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406372022 : Closed e2422406372022 ∧ code e2422406372022 = 11218499394230 := by decide
theorem cert_e2422406372022 : check e2422406372022 [[],[]] .chain = true := by decide
def e2422406372026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406372026 : Closed e2422406372026 ∧ code e2422406372026 = 11218499394234 := by decide
theorem cert_e2422406372026 : check e2422406372026 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2422406372054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406372054 : Closed e2422406372054 ∧ code e2422406372054 = 11218499394262 := by decide
theorem cert_e2422406372054 : check e2422406372054 [[],[]] .chain = true := by decide
def e2422406372058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406372058 : Closed e2422406372058 ∧ code e2422406372058 = 11218499394266 := by decide
theorem cert_e2422406372058 : check e2422406372058 [[],[]] .chain = true := by decide
def e2422406372074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406372074 : Closed e2422406372074 ∧ code e2422406372074 = 11218499394282 := by decide
theorem cert_e2422406372074 : check e2422406372074 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2422406372182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406372182 : Closed e2422406372182 ∧ code e2422406372182 = 11218499394390 := by decide
theorem cert_e2422406372182 : check e2422406372182 [[],[]] .chain = true := by decide
def e2422406372186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406372186 : Closed e2422406372186 ∧ code e2422406372186 = 11218499394394 := by decide
theorem cert_e2422406372186 : check e2422406372186 [[],[]] .chain = true := by decide
def e2422406372202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406372202 : Closed e2422406372202 ∧ code e2422406372202 = 11218499394410 := by decide
theorem cert_e2422406372202 : check e2422406372202 [[],[]] .chain = true := by decide
def e2422406372266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406372266 : Closed e2422406372266 ∧ code e2422406372266 = 11218499394474 := by decide
theorem cert_e2422406372266 : check e2422406372266 [[],[],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2422406372694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406372694 : Closed e2422406372694 ∧ code e2422406372694 = 11218499394902 := by decide
private def t_e2422406372694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))
theorem cert_e2422406372694 : ¬ IsSelfInterpreter e2422406372694 :=
  wSource (t := t_e2422406372694) (replay_sound (ps := []) (t := e2422406372694) (by decide)) (by decide)
def e2422406372698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406372698 : Closed e2422406372698 ∧ code e2422406372698 = 11218499394906 := by decide
private def t_e2422406372698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))
theorem cert_e2422406372698 : ¬ IsSelfInterpreter e2422406372698 :=
  wSource (t := t_e2422406372698) (replay_sound (ps := []) (t := e2422406372698) (by decide)) (by decide)
def e2422406372714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406372714 : Closed e2422406372714 ∧ code e2422406372714 = 11218499394922 := by decide
private def t_e2422406372714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))
theorem cert_e2422406372714 : ¬ IsSelfInterpreter e2422406372714 :=
  wSource (t := t_e2422406372714) (replay_sound (ps := []) (t := e2422406372714) (by decide)) (by decide)
def e2422406372778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406372778 : Closed e2422406372778 ∧ code e2422406372778 = 11218499394986 := by decide
private def t_e2422406372778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))
theorem cert_e2422406372778 : ¬ IsSelfInterpreter e2422406372778 :=
  wSource (t := t_e2422406372778) (replay_sound (ps := []) (t := e2422406372778) (by decide)) (by decide)
def e2422406382958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406382958 : Closed e2422406382958 ∧ code e2422406382958 = 11218499405166 := by decide
theorem cert_e2422406382958 : check e2422406382958 [[],[]] .chain = true := by decide
def e2422406382966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406382966 : Closed e2422406382966 ∧ code e2422406382966 = 11218499405174 := by decide
theorem cert_e2422406382966 : check e2422406382966 [[],[]] .chain = true := by decide
def e2422406383022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406383022 : Closed e2422406383022 ∧ code e2422406383022 = 11218499405230 := by decide
theorem cert_e2422406383022 : check e2422406383022 [[],[]] .chain = true := by decide
def e2422406383034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406383034 : Closed e2422406383034 ∧ code e2422406383034 = 11218499405242 := by decide
theorem cert_e2422406383034 : check e2422406383034 [[],[]] .chain = true := by decide
def e2422406383062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406383062 : Closed e2422406383062 ∧ code e2422406383062 = 11218499405270 := by decide
theorem cert_e2422406383062 : check e2422406383062 [[],[]] .chain = true := by decide
def e2422406383066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406383066 : Closed e2422406383066 ∧ code e2422406383066 = 11218499405274 := by decide
theorem cert_e2422406383066 : check e2422406383066 [[],[]] .chain = true := by decide
def e2422406387438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2422406387438 : Closed e2422406387438 ∧ code e2422406387438 = 11218499409646 := by decide
theorem cert_e2422406387438 : check e2422406387438 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406387566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2422406387566 : Closed e2422406387566 ∧ code e2422406387566 = 11218499409774 := by decide
theorem cert_e2422406387566 : check e2422406387566 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406387574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2422406387574 : Closed e2422406387574 ∧ code e2422406387574 = 11218499409782 := by decide
theorem cert_e2422406387574 : check e2422406387574 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406388590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406388590 : Closed e2422406388590 ∧ code e2422406388590 = 11218499410798 := by decide
theorem cert_e2422406388590 : check e2422406388590 [[],[]] .chain = true := by decide
def e2422406388598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406388598 : Closed e2422406388598 ∧ code e2422406388598 = 11218499410806 := by decide
theorem cert_e2422406388598 : check e2422406388598 [[],[]] .chain = true := by decide
def e2422406388662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406388662 : Closed e2422406388662 ∧ code e2422406388662 = 11218499410870 := by decide
theorem cert_e2422406388662 : check e2422406388662 [[],[]] .chain = true := by decide
def e2422406389102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406389102 : Closed e2422406389102 ∧ code e2422406389102 = 11218499411310 := by decide
theorem cert_e2422406389102 : check e2422406389102 [[],[]] .chain = true := by decide
def e2422406389110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406389110 : Closed e2422406389110 ∧ code e2422406389110 = 11218499411318 := by decide
theorem cert_e2422406389110 : check e2422406389110 [[],[]] .chain = true := by decide
def e2422406389166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406389166 : Closed e2422406389166 ∧ code e2422406389166 = 11218499411374 := by decide
theorem cert_e2422406389166 : check e2422406389166 [[],[]] .chain = true := by decide
def e2422406389178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406389178 : Closed e2422406389178 ∧ code e2422406389178 = 11218499411386 := by decide
theorem cert_e2422406389178 : check e2422406389178 [[],[]] .chain = true := by decide
def e2422406389206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406389206 : Closed e2422406389206 ∧ code e2422406389206 = 11218499411414 := by decide
theorem cert_e2422406389206 : check e2422406389206 [[],[]] .chain = true := by decide
def e2422406389210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406389210 : Closed e2422406389210 ∧ code e2422406389210 = 11218499411418 := by decide
theorem cert_e2422406389210 : check e2422406389210 [[],[]] .chain = true := by decide
def e2422406389422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406389422 : Closed e2422406389422 ∧ code e2422406389422 = 11218499411630 := by decide
theorem cert_e2422406389422 : check e2422406389422 [[],[]] .chain = true := by decide
def e2422406389434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406389434 : Closed e2422406389434 ∧ code e2422406389434 = 11218499411642 := by decide
theorem cert_e2422406389434 : check e2422406389434 [[],[]] .chain = true := by decide
def e2422406389482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406389482 : Closed e2422406389482 ∧ code e2422406389482 = 11218499411690 := by decide
theorem cert_e2422406389482 : check e2422406389482 [[],[]] .chain = true := by decide
def e2422406389590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406389590 : Closed e2422406389590 ∧ code e2422406389590 = 11218499411798 := by decide
theorem cert_e2422406389590 : check e2422406389590 [[],[]] .chain = true := by decide
def e2422406389594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406389594 : Closed e2422406389594 ∧ code e2422406389594 = 11218499411802 := by decide
theorem cert_e2422406389594 : check e2422406389594 [[],[]] .chain = true := by decide
def e2422406389610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406389610 : Closed e2422406389610 ∧ code e2422406389610 = 11218499411818 := by decide
theorem cert_e2422406389610 : check e2422406389610 [[],[]] .chain = true := by decide
def e2422406395246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406395246 : Closed e2422406395246 ∧ code e2422406395246 = 11218499417454 := by decide
theorem cert_e2422406395246 : check e2422406395246 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406395254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406395254 : Closed e2422406395254 ∧ code e2422406395254 = 11218499417462 := by decide
theorem cert_e2422406395254 : checkPay e2422406395254 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406395310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406395310 : Closed e2422406395310 ∧ code e2422406395310 = 11218499417518 := by decide
theorem cert_e2422406395310 : check e2422406395310 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406395322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406395322 : Closed e2422406395322 ∧ code e2422406395322 = 11218499417530 := by decide
theorem cert_e2422406395322 : check e2422406395322 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406395350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406395350 : Closed e2422406395350 ∧ code e2422406395350 = 11218499417558 := by decide
theorem cert_e2422406395350 : check e2422406395350 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406395354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406395354 : Closed e2422406395354 ∧ code e2422406395354 = 11218499417562 := by decide
theorem cert_e2422406395354 : check e2422406395354 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406399854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2422406399854 : Closed e2422406399854 ∧ code e2422406399854 = 11218499422062 := by decide
theorem cert_e2422406399854 : check e2422406399854 [[],[]] .chain = true := by decide
def e2422406399862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2422406399862 : Closed e2422406399862 ∧ code e2422406399862 = 11218499422070 := by decide
theorem cert_e2422406399862 : check e2422406399862 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422406372694
#print axioms Blc.Floor43.cert_e2422406372698
#print axioms Blc.Floor43.cert_e2422406372714
#print axioms Blc.Floor43.cert_e2422406372778
