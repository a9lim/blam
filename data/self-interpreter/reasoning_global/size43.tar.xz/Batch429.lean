import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374041486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422374041486 : Closed e2422374041486 ∧ code e2422374041486 = 11218467063694 := by decide
theorem cert_e2422374041486 : check e2422374041486 [[],[]] .three = true := by decide
def e2422374041498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374041498 : Closed e2422374041498 ∧ code e2422374041498 = 11218467063706 := by decide
theorem cert_e2422374041498 : check e2422374041498 [[],[]] .three = true := by decide
def e2422374041534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e2422374041534 : Closed e2422374041534 ∧ code e2422374041534 = 11218467063742 := by decide
theorem cert_e2422374041534 : check e2422374041534 [[],[]] .three = true := by decide
def e2422374041566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2422374041566 : Closed e2422374041566 ∧ code e2422374041566 = 11218467063774 := by decide
theorem cert_e2422374041566 : check e2422374041566 [[],[]] .three = true := by decide
def e2422374041582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e2422374041582 : Closed e2422374041582 ∧ code e2422374041582 = 11218467063790 := by decide
theorem cert_e2422374041582 : check e2422374041582 [[],[]] .three = true := by decide
def e2422374045230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422374045230 : Closed e2422374045230 ∧ code e2422374045230 = 11218467067438 := by decide
theorem cert_e2422374045230 : check e2422374045230 [[],[]] .three = true := by decide
def e2422374045238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422374045238 : Closed e2422374045238 ∧ code e2422374045238 = 11218467067446 := by decide
theorem cert_e2422374045238 : check e2422374045238 [[],[]] .three = true := by decide
def e2422374045242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422374045242 : Closed e2422374045242 ∧ code e2422374045242 = 11218467067450 := by decide
theorem cert_e2422374045242 : check e2422374045242 [[],[]] .three = true := by decide
def e2422374045326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422374045326 : Closed e2422374045326 ∧ code e2422374045326 = 11218467067534 := by decide
theorem cert_e2422374045326 : check e2422374045326 [[],[]] .three = true := by decide
def e2422374045382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422374045382 : Closed e2422374045382 ∧ code e2422374045382 = 11218467067590 := by decide
theorem cert_e2422374045382 : check e2422374045382 [[],[]] .three = true := by decide
def e2422374045406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2422374045406 : Closed e2422374045406 ∧ code e2422374045406 = 11218467067614 := by decide
theorem cert_e2422374045406 : check e2422374045406 [[],[]] .three = true := by decide
def e2422374045410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422374045410 : Closed e2422374045410 ∧ code e2422374045410 = 11218467067618 := by decide
theorem cert_e2422374045410 : check e2422374045410 [[],[]] .three = true := by decide
def e2422374045422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2422374045422 : Closed e2422374045422 ∧ code e2422374045422 = 11218467067630 := by decide
theorem cert_e2422374045422 : check e2422374045422 [[],[]] .three = true := by decide
def e2422374045430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2422374045430 : Closed e2422374045430 ∧ code e2422374045430 = 11218467067638 := by decide
theorem cert_e2422374045430 : check e2422374045430 [[],[]] .three = true := by decide
def e2422374045462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422374045462 : Closed e2422374045462 ∧ code e2422374045462 = 11218467067670 := by decide
theorem cert_e2422374045462 : check e2422374045462 [[],[]] .three = true := by decide
def e2422374045466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422374045466 : Closed e2422374045466 ∧ code e2422374045466 = 11218467067674 := by decide
theorem cert_e2422374045466 : check e2422374045466 [[],[]] .three = true := by decide
def e2422374045510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422374045510 : Closed e2422374045510 ∧ code e2422374045510 = 11218467067718 := by decide
theorem cert_e2422374045510 : check e2422374045510 [[],[]] .three = true := by decide
def e2422374045534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2422374045534 : Closed e2422374045534 ∧ code e2422374045534 = 11218467067742 := by decide
theorem cert_e2422374045534 : check e2422374045534 [[],[]] .three = true := by decide
def e2422374045538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422374045538 : Closed e2422374045538 ∧ code e2422374045538 = 11218467067746 := by decide
theorem cert_e2422374045538 : check e2422374045538 [[],[]] .three = true := by decide
def e2422374045550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2422374045550 : Closed e2422374045550 ∧ code e2422374045550 = 11218467067758 := by decide
theorem cert_e2422374045550 : check e2422374045550 [[],[]] .three = true := by decide
def e2422374045558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2422374045558 : Closed e2422374045558 ∧ code e2422374045558 = 11218467067766 := by decide
theorem cert_e2422374045558 : check e2422374045558 [[],[]] .three = true := by decide
def e2422374045562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2422374045562 : Closed e2422374045562 ∧ code e2422374045562 = 11218467067770 := by decide
theorem cert_e2422374045562 : check e2422374045562 [[],[]] .three = true := by decide
def e2422374045578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422374045578 : Closed e2422374045578 ∧ code e2422374045578 = 11218467067786 := by decide
theorem cert_e2422374045578 : check e2422374045578 [[],[]] .three = true := by decide
def e2422374045602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422374045602 : Closed e2422374045602 ∧ code e2422374045602 = 11218467067810 := by decide
theorem cert_e2422374045602 : check e2422374045602 [[],[]] .three = true := by decide
def e2422374045614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2422374045614 : Closed e2422374045614 ∧ code e2422374045614 = 11218467067822 := by decide
theorem cert_e2422374045614 : check e2422374045614 [[],[]] .three = true := by decide
def e2422374045622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2422374045622 : Closed e2422374045622 ∧ code e2422374045622 = 11218467067830 := by decide
theorem cert_e2422374045622 : check e2422374045622 [[],[]] .three = true := by decide
def e2422374045626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2422374045626 : Closed e2422374045626 ∧ code e2422374045626 = 11218467067834 := by decide
theorem cert_e2422374045626 : check e2422374045626 [[],[]] .three = true := by decide
def e2422374045654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2422374045654 : Closed e2422374045654 ∧ code e2422374045654 = 11218467067862 := by decide
theorem cert_e2422374045654 : check e2422374045654 [[],[]] .three = true := by decide
def e2422374045658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2422374045658 : Closed e2422374045658 ∧ code e2422374045658 = 11218467067866 := by decide
theorem cert_e2422374045658 : check e2422374045658 [[],[]] .three = true := by decide
def e2422374045758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2422374045758 : Closed e2422374045758 ∧ code e2422374045758 = 11218467067966 := by decide
theorem cert_e2422374045758 : check e2422374045758 [[],[]] .three = true := by decide
def e2422374045806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374045806 : Closed e2422374045806 ∧ code e2422374045806 = 11218467068014 := by decide
theorem cert_e2422374045806 : check e2422374045806 [[],[]] .three = true := by decide
def e2422374045818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374045818 : Closed e2422374045818 ∧ code e2422374045818 = 11218467068026 := by decide
theorem cert_e2422374045818 : check e2422374045818 [[],[]] .three = true := by decide
def e2422374046094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422374046094 : Closed e2422374046094 ∧ code e2422374046094 = 11218467068302 := by decide
theorem cert_e2422374046094 : check e2422374046094 [[],[]] .three = true := by decide
def e2422374046150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422374046150 : Closed e2422374046150 ∧ code e2422374046150 = 11218467068358 := by decide
theorem cert_e2422374046150 : check e2422374046150 [[],[]] .three = true := by decide
def e2422374046174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374046174 : Closed e2422374046174 ∧ code e2422374046174 = 11218467068382 := by decide
theorem cert_e2422374046174 : check e2422374046174 [[],[]] .three = true := by decide
def e2422374046178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422374046178 : Closed e2422374046178 ∧ code e2422374046178 = 11218467068386 := by decide
theorem cert_e2422374046178 : check e2422374046178 [[],[]] .three = true := by decide
def e2422374046190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422374046190 : Closed e2422374046190 ∧ code e2422374046190 = 11218467068398 := by decide
theorem cert_e2422374046190 : check e2422374046190 [[],[]] .three = true := by decide
def e2422374046198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374046198 : Closed e2422374046198 ∧ code e2422374046198 = 11218467068406 := by decide
theorem cert_e2422374046198 : check e2422374046198 [[],[]] .three = true := by decide
def e2422374046750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e2422374046750 : Closed e2422374046750 ∧ code e2422374046750 = 11218467068958 := by decide
theorem cert_e2422374046750 : check e2422374046750 [[],[]] .three = true := by decide
def e2422374046774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374046774 : Closed e2422374046774 ∧ code e2422374046774 = 11218467068982 := by decide
theorem cert_e2422374046774 : check e2422374046774 [[],[]] .three = true := by decide
def e2422374046778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374046778 : Closed e2422374046778 ∧ code e2422374046778 = 11218467068986 := by decide
theorem cert_e2422374046778 : check e2422374046778 [[],[]] .three = true := by decide
def e2422374046918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422374046918 : Closed e2422374046918 ∧ code e2422374046918 = 11218467069126 := by decide
theorem cert_e2422374046918 : check e2422374046918 [[],[]] .three = true := by decide
def e2422374046942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374046942 : Closed e2422374046942 ∧ code e2422374046942 = 11218467069150 := by decide
theorem cert_e2422374046942 : check e2422374046942 [[],[]] .three = true := by decide
def e2422374046946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422374046946 : Closed e2422374046946 ∧ code e2422374046946 = 11218467069154 := by decide
theorem cert_e2422374046946 : check e2422374046946 [[],[]] .three = true := by decide
def e2422374046958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374046958 : Closed e2422374046958 ∧ code e2422374046958 = 11218467069166 := by decide
theorem cert_e2422374046958 : check e2422374046958 [[],[]] .three = true := by decide
def e2422374046966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374046966 : Closed e2422374046966 ∧ code e2422374046966 = 11218467069174 := by decide
theorem cert_e2422374046966 : check e2422374046966 [[],[]] .three = true := by decide
def e2422374046970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374046970 : Closed e2422374046970 ∧ code e2422374046970 = 11218467069178 := by decide
theorem cert_e2422374046970 : check e2422374046970 [[],[]] .three = true := by decide
def e2422374047246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2422374047246 : Closed e2422374047246 ∧ code e2422374047246 = 11218467069454 := by decide
theorem cert_e2422374047246 : check e2422374047246 [[],[]] .three = true := by decide
def e2422374047258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374047258 : Closed e2422374047258 ∧ code e2422374047258 = 11218467069466 := by decide
theorem cert_e2422374047258 : check e2422374047258 [[],[]] .three = true := by decide
def e2422374047294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2422374047294 : Closed e2422374047294 ∧ code e2422374047294 = 11218467069502 := by decide
theorem cert_e2422374047294 : check e2422374047294 [[],[]] .three = true := by decide
def e2422374047330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422374047330 : Closed e2422374047330 ∧ code e2422374047330 = 11218467069538 := by decide
theorem cert_e2422374047330 : check e2422374047330 [[],[]] .three = true := by decide
def e2422374047342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374047342 : Closed e2422374047342 ∧ code e2422374047342 = 11218467069550 := by decide
theorem cert_e2422374047342 : check e2422374047342 [[],[]] .three = true := by decide
def e2422374047350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374047350 : Closed e2422374047350 ∧ code e2422374047350 = 11218467069558 := by decide
theorem cert_e2422374047350 : check e2422374047350 [[],[]] .three = true := by decide
def e2422374047354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374047354 : Closed e2422374047354 ∧ code e2422374047354 = 11218467069562 := by decide
theorem cert_e2422374047354 : check e2422374047354 [[],[]] .three = true := by decide
def e2422374047518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2422374047518 : Closed e2422374047518 ∧ code e2422374047518 = 11218467069726 := by decide
theorem cert_e2422374047518 : check e2422374047518 [[],[]] .three = true := by decide
def e2422374047542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374047542 : Closed e2422374047542 ∧ code e2422374047542 = 11218467069750 := by decide
theorem cert_e2422374047542 : check e2422374047542 [[],[]] .three = true := by decide
def e2422374047546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374047546 : Closed e2422374047546 ∧ code e2422374047546 = 11218467069754 := by decide
theorem cert_e2422374047546 : check e2422374047546 [[],[]] .three = true := by decide
def e2422374056662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422374056662 : Closed e2422374056662 ∧ code e2422374056662 = 11218467078870 := by decide
theorem cert_e2422374056662 : check e2422374056662 [[],[]] .three = true := by decide
def e2422374056666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422374056666 : Closed e2422374056666 ∧ code e2422374056666 = 11218467078874 := by decide
theorem cert_e2422374056666 : check e2422374056666 [[],[]] .three = true := by decide
def e2422374056682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422374056682 : Closed e2422374056682 ∧ code e2422374056682 = 11218467078890 := by decide
theorem cert_e2422374056682 : check e2422374056682 [[],[]] .three = true := by decide
def e2422374056758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374056758 : Closed e2422374056758 ∧ code e2422374056758 = 11218467078966 := by decide
theorem cert_e2422374056758 : check e2422374056758 [[],[]] .three = true := by decide
def e2422374056762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374056762 : Closed e2422374056762 ∧ code e2422374056762 = 11218467078970 := by decide
theorem cert_e2422374056762 : check e2422374056762 [[],[]] .three = true := by decide
def e2422374056846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422374056846 : Closed e2422374056846 ∧ code e2422374056846 = 11218467079054 := by decide
theorem cert_e2422374056846 : check e2422374056846 [[],[]] .three = true := by decide
def e2422374056858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374056858 : Closed e2422374056858 ∧ code e2422374056858 = 11218467079066 := by decide
theorem cert_e2422374056858 : check e2422374056858 [[],[]] .three = true := by decide
def e2422374056894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e2422374056894 : Closed e2422374056894 ∧ code e2422374056894 = 11218467079102 := by decide
theorem cert_e2422374056894 : check e2422374056894 [[],[]] .three = true := by decide
def e2422374056926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422374056926 : Closed e2422374056926 ∧ code e2422374056926 = 11218467079134 := by decide
theorem cert_e2422374056926 : check e2422374056926 [[],[]] .three = true := by decide
def e2422374056942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422374056942 : Closed e2422374056942 ∧ code e2422374056942 = 11218467079150 := by decide
theorem cert_e2422374056942 : check e2422374056942 [[],[]] .three = true := by decide
def e2422374056950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e2422374056950 : Closed e2422374056950 ∧ code e2422374056950 = 11218467079158 := by decide
theorem cert_e2422374056950 : check e2422374056950 [[],[]] .three = true := by decide
def e2422374058774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422374058774 : Closed e2422374058774 ∧ code e2422374058774 = 11218467080982 := by decide
theorem cert_e2422374058774 : check e2422374058774 [[],[]] .three = true := by decide
def e2422374058778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422374058778 : Closed e2422374058778 ∧ code e2422374058778 = 11218467080986 := by decide
theorem cert_e2422374058778 : check e2422374058778 [[],[]] .three = true := by decide
def e2422374058822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422374058822 : Closed e2422374058822 ∧ code e2422374058822 = 11218467081030 := by decide
theorem cert_e2422374058822 : check e2422374058822 [[],[]] .three = true := by decide
def e2422374058846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2422374058846 : Closed e2422374058846 ∧ code e2422374058846 = 11218467081054 := by decide
theorem cert_e2422374058846 : check e2422374058846 [[],[]] .three = true := by decide
def e2422374058850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422374058850 : Closed e2422374058850 ∧ code e2422374058850 = 11218467081058 := by decide
theorem cert_e2422374058850 : check e2422374058850 [[],[]] .three = true := by decide
def e2422374058862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422374058862 : Closed e2422374058862 ∧ code e2422374058862 = 11218467081070 := by decide
theorem cert_e2422374058862 : check e2422374058862 [[],[]] .three = true := by decide
def e2422374058870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422374058870 : Closed e2422374058870 ∧ code e2422374058870 = 11218467081078 := by decide
theorem cert_e2422374058870 : check e2422374058870 [[],[]] .three = true := by decide
def e2422374058874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2422374058874 : Closed e2422374058874 ∧ code e2422374058874 = 11218467081082 := by decide
theorem cert_e2422374058874 : check e2422374058874 [[],[]] .three = true := by decide
def e2422374058890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422374058890 : Closed e2422374058890 ∧ code e2422374058890 = 11218467081098 := by decide
theorem cert_e2422374058890 : check e2422374058890 [[],[]] .three = true := by decide
def e2422374058914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422374058914 : Closed e2422374058914 ∧ code e2422374058914 = 11218467081122 := by decide
theorem cert_e2422374058914 : check e2422374058914 [[],[]] .three = true := by decide
def e2422374058926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422374058926 : Closed e2422374058926 ∧ code e2422374058926 = 11218467081134 := by decide
theorem cert_e2422374058926 : check e2422374058926 [[],[]] .three = true := by decide
def e2422374058938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422374058938 : Closed e2422374058938 ∧ code e2422374058938 = 11218467081146 := by decide
theorem cert_e2422374058938 : check e2422374058938 [[],[]] .three = true := by decide
def e2422374058966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422374058966 : Closed e2422374058966 ∧ code e2422374058966 = 11218467081174 := by decide
theorem cert_e2422374058966 : check e2422374058966 [[],[]] .three = true := by decide
def e2422374058970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422374058970 : Closed e2422374058970 ∧ code e2422374058970 = 11218467081178 := by decide
theorem cert_e2422374058970 : check e2422374058970 [[],[]] .three = true := by decide
def e2422374058986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2422374058986 : Closed e2422374058986 ∧ code e2422374058986 = 11218467081194 := by decide
theorem cert_e2422374058986 : check e2422374058986 [[],[]] .three = true := by decide
def e2422374059038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2422374059038 : Closed e2422374059038 ∧ code e2422374059038 = 11218467081246 := by decide
theorem cert_e2422374059038 : check e2422374059038 [[],[]] .three = true := by decide
def e2422374059062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374059062 : Closed e2422374059062 ∧ code e2422374059062 = 11218467081270 := by decide
theorem cert_e2422374059062 : check e2422374059062 [[],[]] .three = true := by decide
def e2422374059066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374059066 : Closed e2422374059066 ∧ code e2422374059066 = 11218467081274 := by decide
theorem cert_e2422374059066 : check e2422374059066 [[],[]] .three = true := by decide
def e2422374059206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422374059206 : Closed e2422374059206 ∧ code e2422374059206 = 11218467081414 := by decide
theorem cert_e2422374059206 : check e2422374059206 [[],[]] .three = true := by decide
def e2422374059230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374059230 : Closed e2422374059230 ∧ code e2422374059230 = 11218467081438 := by decide
theorem cert_e2422374059230 : check e2422374059230 [[],[]] .three = true := by decide
def e2422374059234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422374059234 : Closed e2422374059234 ∧ code e2422374059234 = 11218467081442 := by decide
theorem cert_e2422374059234 : check e2422374059234 [[],[]] .three = true := by decide
def e2422374059246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374059246 : Closed e2422374059246 ∧ code e2422374059246 = 11218467081454 := by decide
theorem cert_e2422374059246 : check e2422374059246 [[],[]] .three = true := by decide
def e2422374059254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374059254 : Closed e2422374059254 ∧ code e2422374059254 = 11218467081462 := by decide
theorem cert_e2422374059254 : check e2422374059254 [[],[]] .three = true := by decide
def e2422374059258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374059258 : Closed e2422374059258 ∧ code e2422374059258 = 11218467081466 := by decide
theorem cert_e2422374059258 : check e2422374059258 [[],[]] .three = true := by decide
def e2422374059534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2422374059534 : Closed e2422374059534 ∧ code e2422374059534 = 11218467081742 := by decide
theorem cert_e2422374059534 : check e2422374059534 [[],[]] .three = true := by decide
def e2422374059618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422374059618 : Closed e2422374059618 ∧ code e2422374059618 = 11218467081826 := by decide
theorem cert_e2422374059618 : check e2422374059618 [[],[]] .three = true := by decide
def e2422374059630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374059630 : Closed e2422374059630 ∧ code e2422374059630 = 11218467081838 := by decide
theorem cert_e2422374059630 : check e2422374059630 [[],[]] .three = true := by decide
def e2422374059642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374059642 : Closed e2422374059642 ∧ code e2422374059642 = 11218467081850 := by decide
theorem cert_e2422374059642 : check e2422374059642 [[],[]] .three = true := by decide
def e2422374059806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e2422374059806 : Closed e2422374059806 ∧ code e2422374059806 = 11218467082014 := by decide
theorem cert_e2422374059806 : check e2422374059806 [[],[]] .three = true := by decide
def e2422374059830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374059830 : Closed e2422374059830 ∧ code e2422374059830 = 11218467082038 := by decide
theorem cert_e2422374059830 : check e2422374059830 [[],[]] .three = true := by decide
def e2422374059834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374059834 : Closed e2422374059834 ∧ code e2422374059834 = 11218467082042 := by decide
theorem cert_e2422374059834 : check e2422374059834 [[],[]] .three = true := by decide
def e2422374059930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374059930 : Closed e2422374059930 ∧ code e2422374059930 = 11218467082138 := by decide
theorem cert_e2422374059930 : check e2422374059930 [[],[]] .three = true := by decide
def e2422374064606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374064606 : Closed e2422374064606 ∧ code e2422374064606 = 11218467086814 := by decide
theorem cert_e2422374064606 : check e2422374064606 [[],[]] .three = true := by decide
def e2422374064622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.app (.var 2) (.var 2)))))))))
theorem wire_e2422374064622 : Closed e2422374064622 ∧ code e2422374064622 = 11218467086830 := by decide
theorem cert_e2422374064622 : check e2422374064622 [[],[]] .three = true := by decide
def e2422374064630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374064630 : Closed e2422374064630 ∧ code e2422374064630 = 11218467086838 := by decide
theorem cert_e2422374064630 : check e2422374064630 [[],[]] .three = true := by decide
def e2422374065546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422374065546 : Closed e2422374065546 ∧ code e2422374065546 = 11218467087754 := by decide
theorem cert_e2422374065546 : check e2422374065546 [[],[]] .three = true := by decide
def e2422374065570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422374065570 : Closed e2422374065570 ∧ code e2422374065570 = 11218467087778 := by decide
theorem cert_e2422374065570 : check e2422374065570 [[],[]] .three = true := by decide
def e2422374065582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422374065582 : Closed e2422374065582 ∧ code e2422374065582 = 11218467087790 := by decide
theorem cert_e2422374065582 : check e2422374065582 [[],[]] .three = true := by decide
def e2422374065590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2422374065590 : Closed e2422374065590 ∧ code e2422374065590 = 11218467087798 := by decide
theorem cert_e2422374065590 : check e2422374065590 [[],[]] .three = true := by decide
def e2422374065594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422374065594 : Closed e2422374065594 ∧ code e2422374065594 = 11218467087802 := by decide
theorem cert_e2422374065594 : check e2422374065594 [[],[]] .three = true := by decide
def e2422374065622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2422374065622 : Closed e2422374065622 ∧ code e2422374065622 = 11218467087830 := by decide
theorem cert_e2422374065622 : check e2422374065622 [[],[]] .three = true := by decide
def e2422374065626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2422374065626 : Closed e2422374065626 ∧ code e2422374065626 = 11218467087834 := by decide
theorem cert_e2422374065626 : check e2422374065626 [[],[]] .three = true := by decide
def e2422374065642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422374065642 : Closed e2422374065642 ∧ code e2422374065642 = 11218467087850 := by decide
theorem cert_e2422374065642 : check e2422374065642 [[],[]] .three = true := by decide
def e2422374065678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2422374065678 : Closed e2422374065678 ∧ code e2422374065678 = 11218467087886 := by decide
theorem cert_e2422374065678 : check e2422374065678 [[],[]] .three = true := by decide
def e2422374065690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422374065690 : Closed e2422374065690 ∧ code e2422374065690 = 11218467087898 := by decide
theorem cert_e2422374065690 : check e2422374065690 [[],[]] .three = true := by decide
def e2422374065726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422374065726 : Closed e2422374065726 ∧ code e2422374065726 = 11218467087934 := by decide
theorem cert_e2422374065726 : check e2422374065726 [[],[]] .three = true := by decide
def e2422374065762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422374065762 : Closed e2422374065762 ∧ code e2422374065762 = 11218467087970 := by decide
theorem cert_e2422374065762 : check e2422374065762 [[],[]] .three = true := by decide
def e2422374065774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374065774 : Closed e2422374065774 ∧ code e2422374065774 = 11218467087982 := by decide
theorem cert_e2422374065774 : check e2422374065774 [[],[]] .three = true := by decide
def e2422374065782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374065782 : Closed e2422374065782 ∧ code e2422374065782 = 11218467087990 := by decide
theorem cert_e2422374065782 : check e2422374065782 [[],[]] .three = true := by decide
def e2422374065786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374065786 : Closed e2422374065786 ∧ code e2422374065786 = 11218467087994 := by decide
theorem cert_e2422374065786 : check e2422374065786 [[],[]] .three = true := by decide
def e2422374065950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422374065950 : Closed e2422374065950 ∧ code e2422374065950 = 11218467088158 := by decide
theorem cert_e2422374065950 : check e2422374065950 [[],[]] .three = true := by decide
def e2422374065974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374065974 : Closed e2422374065974 ∧ code e2422374065974 = 11218467088182 := by decide
theorem cert_e2422374065974 : check e2422374065974 [[],[]] .three = true := by decide
def e2422374065978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374065978 : Closed e2422374065978 ∧ code e2422374065978 = 11218467088186 := by decide
theorem cert_e2422374065978 : check e2422374065978 [[],[]] .three = true := by decide
def e2422374066062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422374066062 : Closed e2422374066062 ∧ code e2422374066062 = 11218467088270 := by decide
theorem cert_e2422374066062 : check e2422374066062 [[],[]] .three = true := by decide
def e2422374066074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374066074 : Closed e2422374066074 ∧ code e2422374066074 = 11218467088282 := by decide
theorem cert_e2422374066074 : check e2422374066074 [[],[]] .three = true := by decide
def e2422374066118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422374066118 : Closed e2422374066118 ∧ code e2422374066118 = 11218467088326 := by decide
theorem cert_e2422374066118 : check e2422374066118 [[],[]] .three = true := by decide
def e2422374068462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374068462 : Closed e2422374068462 ∧ code e2422374068462 = 11218467090670 := by decide
private def t_e2422374068462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.lam (.app (.var 1) (.var 2)))))))))
theorem cert_e2422374068462 : ¬ IsSelfInterpreter e2422374068462 :=
  wSource (t := t_e2422374068462) (replay_sound (ps := []) (t := e2422374068462) (by decide)) (by decide)
def e2422374068470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374068470 : Closed e2422374068470 ∧ code e2422374068470 = 11218467090678 := by decide
private def t_e2422374068470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.lam (.app (.var 2) (.var 1)))))))))
theorem cert_e2422374068470 : ¬ IsSelfInterpreter e2422374068470 :=
  wSource (t := t_e2422374068470) (replay_sound (ps := []) (t := e2422374068470) (by decide)) (by decide)
def e2422374068950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422374068950 : Closed e2422374068950 ∧ code e2422374068950 = 11218467091158 := by decide
private def t_e2422374068950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem cert_e2422374068950 : ¬ IsSelfInterpreter e2422374068950 :=
  wSource (t := t_e2422374068950) (replay_sound (ps := []) (t := e2422374068950) (by decide)) (by decide)
def e2422374068954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422374068954 : Closed e2422374068954 ∧ code e2422374068954 = 11218467091162 := by decide
private def t_e2422374068954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem cert_e2422374068954 : ¬ IsSelfInterpreter e2422374068954 :=
  wSource (t := t_e2422374068954) (replay_sound (ps := []) (t := e2422374068954) (by decide)) (by decide)
def e2422374068970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422374068970 : Closed e2422374068970 ∧ code e2422374068970 = 11218467091178 := by decide
private def t_e2422374068970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem cert_e2422374068970 : ¬ IsSelfInterpreter e2422374068970 :=
  wSource (t := t_e2422374068970) (replay_sound (ps := []) (t := e2422374068970) (by decide)) (by decide)
def e2422374069022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422374069022 : Closed e2422374069022 ∧ code e2422374069022 = 11218467091230 := by decide
private def t_e2422374069022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.lam (.var 3)))))))))
theorem cert_e2422374069022 : ¬ IsSelfInterpreter e2422374069022 :=
  wSource (t := t_e2422374069022) (replay_sound (ps := []) (t := e2422374069022) (by decide)) (by decide)
def e2422374069046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374069046 : Closed e2422374069046 ∧ code e2422374069046 = 11218467091254 := by decide
private def t_e2422374069046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem cert_e2422374069046 : ¬ IsSelfInterpreter e2422374069046 :=
  wSource (t := t_e2422374069046) (replay_sound (ps := []) (t := e2422374069046) (by decide)) (by decide)
def e2422374069050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374069050 : Closed e2422374069050 ∧ code e2422374069050 = 11218467091258 := by decide
private def t_e2422374069050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem cert_e2422374069050 : ¬ IsSelfInterpreter e2422374069050 :=
  wSource (t := t_e2422374069050) (replay_sound (ps := []) (t := e2422374069050) (by decide)) (by decide)
def e2422374069146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374069146 : Closed e2422374069146 ∧ code e2422374069146 = 11218467091354 := by decide
private def t_e2422374069146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem cert_e2422374069146 : ¬ IsSelfInterpreter e2422374069146 :=
  wSource (t := t_e2422374069146) (replay_sound (ps := []) (t := e2422374069146) (by decide)) (by decide)
def e2422374069190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422374069190 : Closed e2422374069190 ∧ code e2422374069190 = 11218467091398 := by decide
private def t_e2422374069190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 2) (.lam (.var 1)))))))))
theorem cert_e2422374069190 : ¬ IsSelfInterpreter e2422374069190 :=
  wSource (t := t_e2422374069190) (replay_sound (ps := []) (t := e2422374069190) (by decide)) (by decide)
def e2422374149598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))))
theorem wire_e2422374149598 : Closed e2422374149598 ∧ code e2422374149598 = 11218467171806 := by decide
theorem cert_e2422374149598 : check e2422374149598 [[],[]] .smaller = true := by decide
def e2422374149614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))))
theorem wire_e2422374149614 : Closed e2422374149614 ∧ code e2422374149614 = 11218467171822 := by decide
theorem cert_e2422374149614 : check e2422374149614 [[],[]] .smaller = true := by decide
def e2422374149982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))))
theorem wire_e2422374149982 : Closed e2422374149982 ∧ code e2422374149982 = 11218467172190 := by decide
theorem cert_e2422374149982 : check e2422374149982 [[],[]] .smaller = true := by decide
def e2422374150010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))))
theorem wire_e2422374150010 : Closed e2422374150010 ∧ code e2422374150010 = 11218467172218 := by decide
theorem cert_e2422374150010 : check e2422374150010 [[],[]] .smaller = true := by decide
def e2422374150062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))))
theorem wire_e2422374150062 : Closed e2422374150062 ∧ code e2422374150062 = 11218467172270 := by decide
theorem cert_e2422374150062 : check e2422374150062 [[],[]] .smaller = true := by decide
def e2422374150074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))))
theorem wire_e2422374150074 : Closed e2422374150074 ∧ code e2422374150074 = 11218467172282 := by decide
theorem cert_e2422374150074 : check e2422374150074 [[],[]] .smaller = true := by decide
def e2422374151134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))))
theorem wire_e2422374151134 : Closed e2422374151134 ∧ code e2422374151134 = 11218467173342 := by decide
theorem cert_e2422374151134 : check e2422374151134 [[],[]] .smaller = true := by decide
def e2422374151150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))))
theorem wire_e2422374151150 : Closed e2422374151150 ∧ code e2422374151150 = 11218467173358 := by decide
theorem cert_e2422374151150 : check e2422374151150 [[],[]] .smaller = true := by decide
def e2422374153438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))))
theorem wire_e2422374153438 : Closed e2422374153438 ∧ code e2422374153438 = 11218467175646 := by decide
theorem cert_e2422374153438 : check e2422374153438 [[],[]] .smaller = true := by decide
def e2422374153466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))))
theorem wire_e2422374153466 : Closed e2422374153466 ∧ code e2422374153466 = 11218467175674 := by decide
theorem cert_e2422374153466 : check e2422374153466 [[],[]] .smaller = true := by decide
def e2422374153838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422374153838 : Closed e2422374153838 ∧ code e2422374153838 = 11218467176046 := by decide
theorem cert_e2422374153838 : check e2422374153838 [[],[]] .smaller = true := by decide
def e2422374153850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422374153850 : Closed e2422374153850 ∧ code e2422374153850 = 11218467176058 := by decide
theorem cert_e2422374153850 : check e2422374153850 [[],[]] .smaller = true := by decide
def e2422374182254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e2422374182254 : Closed e2422374182254 ∧ code e2422374182254 = 11218467204462 := by decide
theorem cert_e2422374182254 : check e2422374182254 [[],[]] .smaller = true := by decide
def e2422374182262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e2422374182262 : Closed e2422374182262 ∧ code e2422374182262 = 11218467204470 := by decide
theorem cert_e2422374182262 : check e2422374182262 [[],[]] .smaller = true := by decide
def e2422374182318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e2422374182318 : Closed e2422374182318 ∧ code e2422374182318 = 11218467204526 := by decide
theorem cert_e2422374182318 : check e2422374182318 [[],[]] .smaller = true := by decide
def e2422374182330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e2422374182330 : Closed e2422374182330 ∧ code e2422374182330 = 11218467204538 := by decide
theorem cert_e2422374182330 : check e2422374182330 [[],[]] .smaller = true := by decide
def e2422374182358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e2422374182358 : Closed e2422374182358 ∧ code e2422374182358 = 11218467204566 := by decide
theorem cert_e2422374182358 : check e2422374182358 [[],[]] .smaller = true := by decide
def e2422374182362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e2422374182362 : Closed e2422374182362 ∧ code e2422374182362 = 11218467204570 := by decide
theorem cert_e2422374182362 : check e2422374182362 [[],[]] .smaller = true := by decide
def e2422374182574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e2422374182574 : Closed e2422374182574 ∧ code e2422374182574 = 11218467204782 := by decide
theorem cert_e2422374182574 : check e2422374182574 [[],[]] .smaller = true := by decide
def e2422374182586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e2422374182586 : Closed e2422374182586 ∧ code e2422374182586 = 11218467204794 := by decide
theorem cert_e2422374182586 : check e2422374182586 [[],[]] .smaller = true := by decide
def e2422374182634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e2422374182634 : Closed e2422374182634 ∧ code e2422374182634 = 11218467204842 := by decide
theorem cert_e2422374182634 : check e2422374182634 [[],[]] .smaller = true := by decide
def e2422374182742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e2422374182742 : Closed e2422374182742 ∧ code e2422374182742 = 11218467204950 := by decide
theorem cert_e2422374182742 : check e2422374182742 [[],[]] .smaller = true := by decide
def e2422374182746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e2422374182746 : Closed e2422374182746 ∧ code e2422374182746 = 11218467204954 := by decide
theorem cert_e2422374182746 : check e2422374182746 [[],[]] .smaller = true := by decide
def e2422374182762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e2422374182762 : Closed e2422374182762 ∧ code e2422374182762 = 11218467204970 := by decide
theorem cert_e2422374182762 : check e2422374182762 [[],[]] .smaller = true := by decide
def e2422374183790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e2422374183790 : Closed e2422374183790 ∧ code e2422374183790 = 11218467205998 := by decide
theorem cert_e2422374183790 : check e2422374183790 [[],[]] .smaller = true := by decide
def e2422374183798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e2422374183798 : Closed e2422374183798 ∧ code e2422374183798 = 11218467206006 := by decide
theorem cert_e2422374183798 : check e2422374183798 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422374068462
#print axioms Blc.Floor43.cert_e2422374068470
#print axioms Blc.Floor43.cert_e2422374068950
#print axioms Blc.Floor43.cert_e2422374068954
#print axioms Blc.Floor43.cert_e2422374068970
#print axioms Blc.Floor43.cert_e2422374069022
#print axioms Blc.Floor43.cert_e2422374069046
#print axioms Blc.Floor43.cert_e2422374069050
#print axioms Blc.Floor43.cert_e2422374069146
#print axioms Blc.Floor43.cert_e2422374069190
