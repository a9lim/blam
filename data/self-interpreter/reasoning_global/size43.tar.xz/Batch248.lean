import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405381670426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405381670426 : Closed e2405381670426 ∧ code e2405381670426 = 11201474692634 := by decide
theorem cert_e2405381670426 : check e2405381670426 [[]] .width = true := by decide
def e2405381670498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405381670498 : Closed e2405381670498 ∧ code e2405381670498 = 11201474692706 := by decide
theorem cert_e2405381670498 : check e2405381670498 [[]] .width = true := by decide
def e2405381726234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405381726234 : Closed e2405381726234 ∧ code e2405381726234 = 11201474748442 := by decide
theorem cert_e2405381726234 : check e2405381726234 [[]] .width = true := by decide
def e2405381726326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405381726326 : Closed e2405381726326 ∧ code e2405381726326 = 11201474748534 := by decide
theorem cert_e2405381726326 : check e2405381726326 [[]] .width = true := by decide
def e2405381726570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405381726570 : Closed e2405381726570 ∧ code e2405381726570 = 11201474748778 := by decide
theorem cert_e2405381726570 : check e2405381726570 [[]] .width = true := by decide
def e2405381726618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405381726618 : Closed e2405381726618 ∧ code e2405381726618 = 11201474748826 := by decide
theorem cert_e2405381726618 : check e2405381726618 [[]] .width = true := by decide
def e2405381755078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381755078 : Closed e2405381755078 ∧ code e2405381755078 = 11201474777286 := by decide
theorem cert_e2405381755078 : check e2405381755078 [[]] .width = true := by decide
def e2405381758490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381758490 : Closed e2405381758490 ∧ code e2405381758490 = 11201474780698 := by decide
theorem cert_e2405381758490 : check e2405381758490 [[]] .width = true := by decide
def e2405381765658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381765658 : Closed e2405381765658 ∧ code e2405381765658 = 11201474787866 := by decide
theorem cert_e2405381765658 : check e2405381765658 [[]] .width = true := by decide
def e2405381767366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405381767366 : Closed e2405381767366 ∧ code e2405381767366 = 11201474789574 := by decide
theorem cert_e2405381767366 : check e2405381767366 [[]] .width = true := by decide
def e2405381767894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405381767894 : Closed e2405381767894 ∧ code e2405381767894 = 11201474790102 := by decide
theorem cert_e2405381767894 : check e2405381767894 [[]] .width = true := by decide
def e2405381767898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405381767898 : Closed e2405381767898 ∧ code e2405381767898 = 11201474790106 := by decide
theorem cert_e2405381767898 : check e2405381767898 [[]] .width = true := by decide
def e2405381767914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405381767914 : Closed e2405381767914 ∧ code e2405381767914 = 11201474790122 := by decide
theorem cert_e2405381767914 : check e2405381767914 [[]] .width = true := by decide
def e2405381767990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405381767990 : Closed e2405381767990 ∧ code e2405381767990 = 11201474790198 := by decide
theorem cert_e2405381767990 : check e2405381767990 [[]] .width = true := by decide
def e2405381767994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405381767994 : Closed e2405381767994 ∧ code e2405381767994 = 11201474790202 := by decide
theorem cert_e2405381767994 : check e2405381767994 [[]] .width = true := by decide
def e2405381768078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405381768078 : Closed e2405381768078 ∧ code e2405381768078 = 11201474790286 := by decide
theorem cert_e2405381768078 : check e2405381768078 [[]] .width = true := by decide
def e2405381768090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405381768090 : Closed e2405381768090 ∧ code e2405381768090 = 11201474790298 := by decide
theorem cert_e2405381768090 : check e2405381768090 [[]] .width = true := by decide
def e2405381770010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405381770010 : Closed e2405381770010 ∧ code e2405381770010 = 11201474792218 := by decide
theorem cert_e2405381770010 : check e2405381770010 [[]] .width = true := by decide
def e2405381770054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405381770054 : Closed e2405381770054 ∧ code e2405381770054 = 11201474792262 := by decide
theorem cert_e2405381770054 : check e2405381770054 [[]] .width = true := by decide
def e2405381770294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405381770294 : Closed e2405381770294 ∧ code e2405381770294 = 11201474792502 := by decide
theorem cert_e2405381770294 : check e2405381770294 [[]] .width = true := by decide
def e2405381770298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405381770298 : Closed e2405381770298 ∧ code e2405381770298 = 11201474792506 := by decide
theorem cert_e2405381770298 : check e2405381770298 [[]] .width = true := by decide
def e2405381770438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405381770438 : Closed e2405381770438 ∧ code e2405381770438 = 11201474792646 := by decide
theorem cert_e2405381770438 : check e2405381770438 [[]] .width = true := by decide
def e2405381816518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405381816518 : Closed e2405381816518 ∧ code e2405381816518 = 11201474838726 := by decide
theorem cert_e2405381816518 : check e2405381816518 [[]] .width = true := by decide
def e2405381845190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405381845190 : Closed e2405381845190 ∧ code e2405381845190 = 11201474867398 := by decide
theorem cert_e2405381845190 : check e2405381845190 [[]] .width = true := by decide
def e2405381865498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405381865498 : Closed e2405381865498 ∧ code e2405381865498 = 11201474887706 := by decide
theorem cert_e2405381865498 : check e2405381865498 [[]] .width = true := by decide
def e2405381865590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405381865590 : Closed e2405381865590 ∧ code e2405381865590 = 11201474887798 := by decide
theorem cert_e2405381865590 : check e2405381865590 [[]] .width = true := by decide
def e2405381865834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405381865834 : Closed e2405381865834 ∧ code e2405381865834 = 11201474888042 := by decide
theorem cert_e2405381865834 : check e2405381865834 [[]] .width = true := by decide
def e2405381865882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405381865882 : Closed e2405381865882 ∧ code e2405381865882 = 11201474888090 := by decide
theorem cert_e2405381865882 : check e2405381865882 [[]] .width = true := by decide
def e2405381866890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405381866890 : Closed e2405381866890 ∧ code e2405381866890 = 11201474889098 := by decide
theorem cert_e2405381866890 : check e2405381866890 [[]] .width = true := by decide
def e2405381866914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405381866914 : Closed e2405381866914 ∧ code e2405381866914 = 11201474889122 := by decide
private def t_e2405381866914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2405381866914 : ¬ IsSelfInterpreter e2405381866914 :=
  wSource (t := t_e2405381866914) (replay_sound (ps := []) (t := e2405381866914) (by decide)) (by decide)
def e2405381867022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405381867022 : Closed e2405381867022 ∧ code e2405381867022 = 11201474889230 := by decide
theorem cert_e2405381867022 : check e2405381867022 [[]] .width = true := by decide
def e2405381867034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405381867034 : Closed e2405381867034 ∧ code e2405381867034 = 11201474889242 := by decide
private def t_e2405381867034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2405381867034 : ¬ IsSelfInterpreter e2405381867034 :=
  wSource (t := t_e2405381867034) (replay_sound (ps := []) (t := e2405381867034) (by decide)) (by decide)
def e2405381867106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405381867106 : Closed e2405381867106 ∧ code e2405381867106 = 11201474889314 := by decide
theorem cert_e2405381867106 : check e2405381867106 [[]] .width = true := by decide
def e2405381882054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405381882054 : Closed e2405381882054 ∧ code e2405381882054 = 11201474904262 := by decide
theorem cert_e2405381882054 : check e2405381882054 [[]] .width = true := by decide
def e2405381912090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381912090 : Closed e2405381912090 ∧ code e2405381912090 = 11201474934298 := by decide
private def t_e2405381912090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405381912090 : ¬ IsSelfInterpreter e2405381912090 :=
  wSource (t := t_e2405381912090) (replay_sound (ps := []) (t := e2405381912090) (by decide)) (by decide)
def e2405381913114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405381913114 : Closed e2405381913114 ∧ code e2405381913114 = 11201474935322 := by decide
private def t_e2405381913114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405381913114 : ¬ IsSelfInterpreter e2405381913114 :=
  wSource (t := t_e2405381913114) (replay_sound (ps := []) (t := e2405381913114) (by decide)) (by decide)
def e2405395001542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405395001542 : Closed e2405395001542 ∧ code e2405395001542 = 11201488023750 := by decide
theorem cert_e2405395001542 : check e2405395001542 [[]] .width = true := by decide
def e2405395050694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405395050694 : Closed e2405395050694 ∧ code e2405395050694 = 11201488072902 := by decide
theorem cert_e2405395050694 : check e2405395050694 [[]] .width = true := by decide
def e2405395263686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405395263686 : Closed e2405395263686 ∧ code e2405395263686 = 11201488285894 := by decide
theorem cert_e2405395263686 : check e2405395263686 [[]] .width = true := by decide
def e2405395321030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405395321030 : Closed e2405395321030 ∧ code e2405395321030 = 11201488343238 := by decide
theorem cert_e2405395321030 : check e2405395321030 [[]] .width = true := by decide
def e2405395324442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405395324442 : Closed e2405395324442 ∧ code e2405395324442 = 11201488346650 := by decide
theorem cert_e2405395324442 : check e2405395324442 [[]] .width = true := by decide
def e2405395509446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405395509446 : Closed e2405395509446 ∧ code e2405395509446 = 11201488531654 := by decide
theorem cert_e2405395509446 : check e2405395509446 [[]] .width = true := by decide
def e2405395517638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405395517638 : Closed e2405395517638 ∧ code e2405395517638 = 11201488539846 := by decide
theorem cert_e2405395517638 : check e2405395517638 [[]] .width = true := by decide
def e2405395521050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405395521050 : Closed e2405395521050 ∧ code e2405395521050 = 11201488543258 := by decide
theorem cert_e2405395521050 : check e2405395521050 [[]] .width = true := by decide
def e2405395527194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405395527194 : Closed e2405395527194 ∧ code e2405395527194 = 11201488549402 := by decide
theorem cert_e2405395527194 : check e2405395527194 [[]] .width = true := by decide
def e2405396574406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405396574406 : Closed e2405396574406 ∧ code e2405396574406 = 11201489596614 := by decide
theorem cert_e2405396574406 : check e2405396574406 [[]] .width = true := by decide
def e2405396623558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405396623558 : Closed e2405396623558 ∧ code e2405396623558 = 11201489645766 := by decide
theorem cert_e2405396623558 : check e2405396623558 [[]] .width = true := by decide
def e2405397946394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405397946394 : Closed e2405397946394 ∧ code e2405397946394 = 11201490968602 := by decide
theorem cert_e2405397946394 : check e2405397946394 [[]] .width = true := by decide
def e2405397946486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405397946486 : Closed e2405397946486 ∧ code e2405397946486 = 11201490968694 := by decide
theorem cert_e2405397946486 : check e2405397946486 [[]] .width = true := by decide
def e2405397946730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405397946730 : Closed e2405397946730 ∧ code e2405397946730 = 11201490968938 := by decide
theorem cert_e2405397946730 : check e2405397946730 [[]] .width = true := by decide
def e2405397946778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405397946778 : Closed e2405397946778 ∧ code e2405397946778 = 11201490968986 := by decide
theorem cert_e2405397946778 : check e2405397946778 [[]] .width = true := by decide
def e2405398147270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405398147270 : Closed e2405398147270 ∧ code e2405398147270 = 11201491169478 := by decide
theorem cert_e2405398147270 : check e2405398147270 [[]] .width = true := by decide
def e2405398204614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405398204614 : Closed e2405398204614 ∧ code e2405398204614 = 11201491226822 := by decide
theorem cert_e2405398204614 : check e2405398204614 [[]] .width = true := by decide
def e2405398208026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405398208026 : Closed e2405398208026 ∧ code e2405398208026 = 11201491230234 := by decide
theorem cert_e2405398208026 : check e2405398208026 [[]] .width = true := by decide
def e2405398675654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405398675654 : Closed e2405398675654 ∧ code e2405398675654 = 11201491697862 := by decide
theorem cert_e2405398675654 : check e2405398675654 [[]] .width = true := by decide
def e2405398676182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405398676182 : Closed e2405398676182 ∧ code e2405398676182 = 11201491698390 := by decide
theorem cert_e2405398676182 : check e2405398676182 [[]] .width = true := by decide
def e2405398676186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405398676186 : Closed e2405398676186 ∧ code e2405398676186 = 11201491698394 := by decide
theorem cert_e2405398676186 : check e2405398676186 [[]] .width = true := by decide
def e2405398676202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405398676202 : Closed e2405398676202 ∧ code e2405398676202 = 11201491698410 := by decide
theorem cert_e2405398676202 : check e2405398676202 [[]] .width = true := by decide
def e2405398676278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405398676278 : Closed e2405398676278 ∧ code e2405398676278 = 11201491698486 := by decide
theorem cert_e2405398676278 : check e2405398676278 [[]] .width = true := by decide
def e2405398676282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405398676282 : Closed e2405398676282 ∧ code e2405398676282 = 11201491698490 := by decide
theorem cert_e2405398676282 : check e2405398676282 [[]] .width = true := by decide
def e2405398676366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405398676366 : Closed e2405398676366 ∧ code e2405398676366 = 11201491698574 := by decide
theorem cert_e2405398676366 : check e2405398676366 [[]] .width = true := by decide
def e2405398676378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405398676378 : Closed e2405398676378 ∧ code e2405398676378 = 11201491698586 := by decide
theorem cert_e2405398676378 : check e2405398676378 [[]] .width = true := by decide
def e2405398678298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405398678298 : Closed e2405398678298 ∧ code e2405398678298 = 11201491700506 := by decide
theorem cert_e2405398678298 : check e2405398678298 [[]] .width = true := by decide
def e2405398678342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405398678342 : Closed e2405398678342 ∧ code e2405398678342 = 11201491700550 := by decide
theorem cert_e2405398678342 : check e2405398678342 [[]] .width = true := by decide
def e2405398678582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405398678582 : Closed e2405398678582 ∧ code e2405398678582 = 11201491700790 := by decide
theorem cert_e2405398678582 : check e2405398678582 [[]] .width = true := by decide
def e2405398678586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405398678586 : Closed e2405398678586 ∧ code e2405398678586 = 11201491700794 := by decide
theorem cert_e2405398678586 : check e2405398678586 [[]] .width = true := by decide
def e2405398678726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405398678726 : Closed e2405398678726 ∧ code e2405398678726 = 11201491700934 := by decide
theorem cert_e2405398678726 : check e2405398678726 [[]] .width = true := by decide
def e2405399232538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405399232538 : Closed e2405399232538 ∧ code e2405399232538 = 11201492254746 := by decide
theorem cert_e2405399232538 : check e2405399232538 [[]] .width = true := by decide
def e2405399232630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405399232630 : Closed e2405399232630 ∧ code e2405399232630 = 11201492254838 := by decide
theorem cert_e2405399232630 : check e2405399232630 [[]] .width = true := by decide
def e2405399232874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405399232874 : Closed e2405399232874 ∧ code e2405399232874 = 11201492255082 := by decide
theorem cert_e2405399232874 : check e2405399232874 [[]] .width = true := by decide
def e2405399232922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405399232922 : Closed e2405399232922 ∧ code e2405399232922 = 11201492255130 := by decide
theorem cert_e2405399232922 : check e2405399232922 [[]] .width = true := by decide
def e2405399233930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405399233930 : Closed e2405399233930 ∧ code e2405399233930 = 11201492256138 := by decide
theorem cert_e2405399233930 : check e2405399233930 [[]] .width = true := by decide
def e2405399233954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405399233954 : Closed e2405399233954 ∧ code e2405399233954 = 11201492256162 := by decide
theorem cert_e2405399233954 : check e2405399233954 [[]] .width = true := by decide
def e2405399234062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405399234062 : Closed e2405399234062 ∧ code e2405399234062 = 11201492256270 := by decide
theorem cert_e2405399234062 : check e2405399234062 [[]] .width = true := by decide
def e2405399234074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405399234074 : Closed e2405399234074 ∧ code e2405399234074 = 11201492256282 := by decide
theorem cert_e2405399234074 : check e2405399234074 [[]] .width = true := by decide
def e2405399234146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405399234146 : Closed e2405399234146 ∧ code e2405399234146 = 11201492256354 := by decide
theorem cert_e2405399234146 : check e2405399234146 [[]] .width = true := by decide
def e2405399322650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405399322650 : Closed e2405399322650 ∧ code e2405399322650 = 11201492344858 := by decide
theorem cert_e2405399322650 : check e2405399322650 [[]] .width = true := by decide
def e2405399322742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405399322742 : Closed e2405399322742 ∧ code e2405399322742 = 11201492344950 := by decide
theorem cert_e2405399322742 : check e2405399322742 [[]] .width = true := by decide
def e2405399322986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405399322986 : Closed e2405399322986 ∧ code e2405399322986 = 11201492345194 := by decide
theorem cert_e2405399322986 : check e2405399322986 [[]] .width = true := by decide
def e2405399323034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405399323034 : Closed e2405399323034 ∧ code e2405399323034 = 11201492345242 := by decide
theorem cert_e2405399323034 : check e2405399323034 [[]] .width = true := by decide
def e2405399326918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405399326918 : Closed e2405399326918 ∧ code e2405399326918 = 11201492349126 := by decide
theorem cert_e2405399326918 : check e2405399326918 [[]] .width = true := by decide
def e2405399376070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405399376070 : Closed e2405399376070 ∧ code e2405399376070 = 11201492398278 := by decide
theorem cert_e2405399376070 : check e2405399376070 [[]] .width = true := by decide
def e2405399384262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405399384262 : Closed e2405399384262 ∧ code e2405399384262 = 11201492406470 := by decide
theorem cert_e2405399384262 : check e2405399384262 [[]] .width = true := by decide
def e2405399387674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405399387674 : Closed e2405399387674 ∧ code e2405399387674 = 11201492409882 := by decide
theorem cert_e2405399387674 : check e2405399387674 [[]] .width = true := by decide
def e2405399393818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405399393818 : Closed e2405399393818 ∧ code e2405399393818 = 11201492416026 := by decide
theorem cert_e2405399393818 : check e2405399393818 [[]] .width = true := by decide
def e2405399462086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405399462086 : Closed e2405399462086 ∧ code e2405399462086 = 11201492484294 := by decide
theorem cert_e2405399462086 : check e2405399462086 [[]] .width = true := by decide
def e2405399462614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405399462614 : Closed e2405399462614 ∧ code e2405399462614 = 11201492484822 := by decide
theorem cert_e2405399462614 : check e2405399462614 [[]] .width = true := by decide
def e2405399462618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405399462618 : Closed e2405399462618 ∧ code e2405399462618 = 11201492484826 := by decide
theorem cert_e2405399462618 : check e2405399462618 [[]] .width = true := by decide
def e2405399462634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405399462634 : Closed e2405399462634 ∧ code e2405399462634 = 11201492484842 := by decide
theorem cert_e2405399462634 : check e2405399462634 [[]] .width = true := by decide
def e2405399462710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405399462710 : Closed e2405399462710 ∧ code e2405399462710 = 11201492484918 := by decide
theorem cert_e2405399462710 : check e2405399462710 [[]] .width = true := by decide
def e2405399462714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405399462714 : Closed e2405399462714 ∧ code e2405399462714 = 11201492484922 := by decide
theorem cert_e2405399462714 : check e2405399462714 [[]] .width = true := by decide
def e2405399462798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405399462798 : Closed e2405399462798 ∧ code e2405399462798 = 11201492485006 := by decide
theorem cert_e2405399462798 : check e2405399462798 [[]] .width = true := by decide
def e2405399462810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405399462810 : Closed e2405399462810 ∧ code e2405399462810 = 11201492485018 := by decide
theorem cert_e2405399462810 : check e2405399462810 [[]] .width = true := by decide
def e2405399464730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405399464730 : Closed e2405399464730 ∧ code e2405399464730 = 11201492486938 := by decide
theorem cert_e2405399464730 : check e2405399464730 [[]] .width = true := by decide
def e2405399464774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405399464774 : Closed e2405399464774 ∧ code e2405399464774 = 11201492486982 := by decide
theorem cert_e2405399464774 : check e2405399464774 [[]] .width = true := by decide
def e2405399465014 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405399465014 : Closed e2405399465014 ∧ code e2405399465014 = 11201492487222 := by decide
theorem cert_e2405399465014 : check e2405399465014 [[]] .width = true := by decide
def e2405399465018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405399465018 : Closed e2405399465018 ∧ code e2405399465018 = 11201492487226 := by decide
theorem cert_e2405399465018 : check e2405399465018 [[]] .width = true := by decide
def e2405399465158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405399465158 : Closed e2405399465158 ∧ code e2405399465158 = 11201492487366 := by decide
theorem cert_e2405399465158 : check e2405399465158 [[]] .width = true := by decide
def e2405399494682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405399494682 : Closed e2405399494682 ∧ code e2405399494682 = 11201492516890 := by decide
theorem cert_e2405399494682 : check e2405399494682 [[]] .width = true := by decide
def e2405399494774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405399494774 : Closed e2405399494774 ∧ code e2405399494774 = 11201492516982 := by decide
theorem cert_e2405399494774 : check e2405399494774 [[]] .width = true := by decide
def e2405399495018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405399495018 : Closed e2405399495018 ∧ code e2405399495018 = 11201492517226 := by decide
theorem cert_e2405399495018 : check e2405399495018 [[]] .width = true := by decide
def e2405399495066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405399495066 : Closed e2405399495066 ∧ code e2405399495066 = 11201492517274 := by decide
theorem cert_e2405399495066 : check e2405399495066 [[]] .width = true := by decide
def e2405399496074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405399496074 : Closed e2405399496074 ∧ code e2405399496074 = 11201492518282 := by decide
theorem cert_e2405399496074 : check e2405399496074 [[]] .width = true := by decide
def e2405399496098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405399496098 : Closed e2405399496098 ∧ code e2405399496098 = 11201492518306 := by decide
theorem cert_e2405399496098 : check e2405399496098 [[]] .width = true := by decide
def e2405399496206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405399496206 : Closed e2405399496206 ∧ code e2405399496206 = 11201492518414 := by decide
theorem cert_e2405399496206 : check e2405399496206 [[]] .width = true := by decide
def e2405399496218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405399496218 : Closed e2405399496218 ∧ code e2405399496218 = 11201492518426 := by decide
theorem cert_e2405399496218 : check e2405399496218 [[]] .width = true := by decide
def e2405399496290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405399496290 : Closed e2405399496290 ∧ code e2405399496290 = 11201492518498 := by decide
theorem cert_e2405399496290 : check e2405399496290 [[]] .width = true := by decide
def e2405422526662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405422526662 : Closed e2405422526662 ∧ code e2405422526662 = 11201515548870 := by decide
theorem cert_e2405422526662 : check e2405422526662 [[]] .width = true := by decide
def e2405422584006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405422584006 : Closed e2405422584006 ∧ code e2405422584006 = 11201515606214 := by decide
theorem cert_e2405422584006 : check e2405422584006 [[]] .width = true := by decide
def e2405422587418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405422587418 : Closed e2405422587418 ∧ code e2405422587418 = 11201515609626 := by decide
theorem cert_e2405422587418 : check e2405422587418 [[]] .width = true := by decide
def e2405422813382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405422813382 : Closed e2405422813382 ∧ code e2405422813382 = 11201515835590 := by decide
theorem cert_e2405422813382 : check e2405422813382 [[]] .width = true := by decide
def e2405422816794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405422816794 : Closed e2405422816794 ∧ code e2405422816794 = 11201515839002 := by decide
theorem cert_e2405422816794 : check e2405422816794 [[]] .width = true := by decide
def e2405422823962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405422823962 : Closed e2405422823962 ∧ code e2405422823962 = 11201515846170 := by decide
theorem cert_e2405422823962 : check e2405422823962 [[]] .width = true := by decide
def e2405423112218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405423112218 : Closed e2405423112218 ∧ code e2405423112218 = 11201516134426 := by decide
theorem cert_e2405423112218 : check e2405423112218 [[]] .width = true := by decide
def e2405423112310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405423112310 : Closed e2405423112310 ∧ code e2405423112310 = 11201516134518 := by decide
theorem cert_e2405423112310 : check e2405423112310 [[]] .width = true := by decide
def e2405423112554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405423112554 : Closed e2405423112554 ∧ code e2405423112554 = 11201516134762 := by decide
theorem cert_e2405423112554 : check e2405423112554 [[]] .width = true := by decide
def e2405423112602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405423112602 : Closed e2405423112602 ∧ code e2405423112602 = 11201516134810 := by decide
theorem cert_e2405423112602 : check e2405423112602 [[]] .width = true := by decide
def e2405423313094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405423313094 : Closed e2405423313094 ∧ code e2405423313094 = 11201516335302 := by decide
theorem cert_e2405423313094 : check e2405423313094 [[]] .width = true := by decide
def e2405423370438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405423370438 : Closed e2405423370438 ∧ code e2405423370438 = 11201516392646 := by decide
theorem cert_e2405423370438 : check e2405423370438 [[]] .width = true := by decide
def e2405423373850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405423373850 : Closed e2405423373850 ∧ code e2405423373850 = 11201516396058 := by decide
theorem cert_e2405423373850 : check e2405423373850 [[]] .width = true := by decide
def e2405423841478 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405423841478 : Closed e2405423841478 ∧ code e2405423841478 = 11201516863686 := by decide
theorem cert_e2405423841478 : check e2405423841478 [[]] .width = true := by decide
def e2405423842006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405423842006 : Closed e2405423842006 ∧ code e2405423842006 = 11201516864214 := by decide
theorem cert_e2405423842006 : check e2405423842006 [[]] .width = true := by decide
def e2405423842010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405423842010 : Closed e2405423842010 ∧ code e2405423842010 = 11201516864218 := by decide
theorem cert_e2405423842010 : check e2405423842010 [[]] .width = true := by decide
def e2405423842026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405423842026 : Closed e2405423842026 ∧ code e2405423842026 = 11201516864234 := by decide
theorem cert_e2405423842026 : check e2405423842026 [[]] .width = true := by decide
def e2405423842102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405423842102 : Closed e2405423842102 ∧ code e2405423842102 = 11201516864310 := by decide
theorem cert_e2405423842102 : check e2405423842102 [[]] .width = true := by decide
def e2405423842106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405423842106 : Closed e2405423842106 ∧ code e2405423842106 = 11201516864314 := by decide
theorem cert_e2405423842106 : check e2405423842106 [[]] .width = true := by decide
def e2405423842190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405423842190 : Closed e2405423842190 ∧ code e2405423842190 = 11201516864398 := by decide
theorem cert_e2405423842190 : check e2405423842190 [[]] .width = true := by decide
def e2405423842202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405423842202 : Closed e2405423842202 ∧ code e2405423842202 = 11201516864410 := by decide
theorem cert_e2405423842202 : check e2405423842202 [[]] .width = true := by decide
def e2405423844122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405423844122 : Closed e2405423844122 ∧ code e2405423844122 = 11201516866330 := by decide
theorem cert_e2405423844122 : check e2405423844122 [[]] .width = true := by decide
def e2405423844166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405423844166 : Closed e2405423844166 ∧ code e2405423844166 = 11201516866374 := by decide
theorem cert_e2405423844166 : check e2405423844166 [[]] .width = true := by decide
def e2405423844406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405423844406 : Closed e2405423844406 ∧ code e2405423844406 = 11201516866614 := by decide
theorem cert_e2405423844406 : check e2405423844406 [[]] .width = true := by decide
def e2405423844410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405423844410 : Closed e2405423844410 ∧ code e2405423844410 = 11201516866618 := by decide
theorem cert_e2405423844410 : check e2405423844410 [[]] .width = true := by decide
def e2405423844550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405423844550 : Closed e2405423844550 ∧ code e2405423844550 = 11201516866758 := by decide
theorem cert_e2405423844550 : check e2405423844550 [[]] .width = true := by decide
def e2405424677062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405424677062 : Closed e2405424677062 ∧ code e2405424677062 = 11201517699270 := by decide
theorem cert_e2405424677062 : check e2405424677062 [[]] .width = true := by decide
def e2405424717850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405424717850 : Closed e2405424717850 ∧ code e2405424717850 = 11201517740058 := by decide
theorem cert_e2405424717850 : check e2405424717850 [[]] .width = true := by decide
def e2405424717942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405424717942 : Closed e2405424717942 ∧ code e2405424717942 = 11201517740150 := by decide
theorem cert_e2405424717942 : check e2405424717942 [[]] .width = true := by decide
def e2405424718186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405424718186 : Closed e2405424718186 ∧ code e2405424718186 = 11201517740394 := by decide
theorem cert_e2405424718186 : check e2405424718186 [[]] .width = true := by decide
def e2405424718234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405424718234 : Closed e2405424718234 ∧ code e2405424718234 = 11201517740442 := by decide
theorem cert_e2405424718234 : check e2405424718234 [[]] .width = true := by decide
def e2405424746694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405424746694 : Closed e2405424746694 ∧ code e2405424746694 = 11201517768902 := by decide
theorem cert_e2405424746694 : check e2405424746694 [[]] .width = true := by decide
def e2405424750106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405424750106 : Closed e2405424750106 ∧ code e2405424750106 = 11201517772314 := by decide
theorem cert_e2405424750106 : check e2405424750106 [[]] .width = true := by decide
def e2405424757274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405424757274 : Closed e2405424757274 ∧ code e2405424757274 = 11201517779482 := by decide
theorem cert_e2405424757274 : check e2405424757274 [[]] .width = true := by decide
def e2405424758982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405424758982 : Closed e2405424758982 ∧ code e2405424758982 = 11201517781190 := by decide
theorem cert_e2405424758982 : check e2405424758982 [[]] .width = true := by decide
def e2405424759510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405424759510 : Closed e2405424759510 ∧ code e2405424759510 = 11201517781718 := by decide
theorem cert_e2405424759510 : check e2405424759510 [[]] .width = true := by decide
def e2405424759514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405424759514 : Closed e2405424759514 ∧ code e2405424759514 = 11201517781722 := by decide
theorem cert_e2405424759514 : check e2405424759514 [[]] .width = true := by decide
def e2405424759530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405424759530 : Closed e2405424759530 ∧ code e2405424759530 = 11201517781738 := by decide
theorem cert_e2405424759530 : check e2405424759530 [[]] .width = true := by decide
def e2405424759606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405424759606 : Closed e2405424759606 ∧ code e2405424759606 = 11201517781814 := by decide
theorem cert_e2405424759606 : check e2405424759606 [[]] .width = true := by decide
def e2405424759610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405424759610 : Closed e2405424759610 ∧ code e2405424759610 = 11201517781818 := by decide
theorem cert_e2405424759610 : check e2405424759610 [[]] .width = true := by decide
def e2405424759694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405424759694 : Closed e2405424759694 ∧ code e2405424759694 = 11201517781902 := by decide
theorem cert_e2405424759694 : check e2405424759694 [[]] .width = true := by decide
def e2405424759706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405424759706 : Closed e2405424759706 ∧ code e2405424759706 = 11201517781914 := by decide
theorem cert_e2405424759706 : check e2405424759706 [[]] .width = true := by decide
def e2405424761626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405424761626 : Closed e2405424761626 ∧ code e2405424761626 = 11201517783834 := by decide
theorem cert_e2405424761626 : check e2405424761626 [[]] .width = true := by decide
def e2405424761670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405424761670 : Closed e2405424761670 ∧ code e2405424761670 = 11201517783878 := by decide
theorem cert_e2405424761670 : check e2405424761670 [[]] .width = true := by decide
def e2405424761910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405424761910 : Closed e2405424761910 ∧ code e2405424761910 = 11201517784118 := by decide
theorem cert_e2405424761910 : check e2405424761910 [[]] .width = true := by decide
def e2405424761914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405424761914 : Closed e2405424761914 ∧ code e2405424761914 = 11201517784122 := by decide
theorem cert_e2405424761914 : check e2405424761914 [[]] .width = true := by decide
def e2405424762054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405424762054 : Closed e2405424762054 ∧ code e2405424762054 = 11201517784262 := by decide
theorem cert_e2405424762054 : check e2405424762054 [[]] .width = true := by decide
def e2405424808134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405424808134 : Closed e2405424808134 ∧ code e2405424808134 = 11201517830342 := by decide
theorem cert_e2405424808134 : check e2405424808134 [[]] .width = true := by decide
def e2405436981274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405436981274 : Closed e2405436981274 ∧ code e2405436981274 = 11201530003482 := by decide
theorem cert_e2405436981274 : check e2405436981274 [[]] .width = true := by decide
def e2405436981366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405436981366 : Closed e2405436981366 ∧ code e2405436981366 = 11201530003574 := by decide
theorem cert_e2405436981366 : check e2405436981366 [[]] .width = true := by decide
def e2405436981610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405436981610 : Closed e2405436981610 ∧ code e2405436981610 = 11201530003818 := by decide
theorem cert_e2405436981610 : check e2405436981610 [[]] .width = true := by decide
def e2405436981658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405436981658 : Closed e2405436981658 ∧ code e2405436981658 = 11201530003866 := by decide
theorem cert_e2405436981658 : check e2405436981658 [[]] .width = true := by decide
def e2405436982666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405436982666 : Closed e2405436982666 ∧ code e2405436982666 = 11201530004874 := by decide
theorem cert_e2405436982666 : check e2405436982666 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2405381866914
#print axioms Blc.Floor43.cert_e2405381867034
#print axioms Blc.Floor43.cert_e2405381912090
#print axioms Blc.Floor43.cert_e2405381913114
