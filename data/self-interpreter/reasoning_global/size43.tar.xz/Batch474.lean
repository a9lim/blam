import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407131866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407131866 : Closed e2422407131866 ∧ code e2422407131866 = 11218500154074 := by decide
theorem cert_e2422407131866 : check e2422407131866 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422407131882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407131882 : Closed e2422407131882 ∧ code e2422407131882 = 11218500154090 := by decide
def e2422407131958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407131958 : Closed e2422407131958 ∧ code e2422407131958 = 11218500154166 := by decide
def e2422407131962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407131962 : Closed e2422407131962 ∧ code e2422407131962 = 11218500154170 := by decide
def e2422407132034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407132034 : Closed e2422407132034 ∧ code e2422407132034 = 11218500154242 := by decide
theorem cert_e2422407132034 : check e2422407132034 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2422407132046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422407132046 : Closed e2422407132046 ∧ code e2422407132046 = 11218500154254 := by decide
theorem cert_e2422407132046 : check e2422407132046 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407132058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407132058 : Closed e2422407132058 ∧ code e2422407132058 = 11218500154266 := by decide
def e2422407169710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)) (.var 2))))))
theorem wire_e2422407169710 : Closed e2422407169710 ∧ code e2422407169710 = 11218500191918 := by decide
theorem cert_e2422407169710 : check e2422407169710 [[],[]] .sourceHead = true := by decide
def e2422407169722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 2)) (.var 0))))))
theorem wire_e2422407169722 : Closed e2422407169722 ∧ code e2422407169722 = 11218500191930 := by decide
theorem cert_e2422407169722 : check e2422407169722 [[],[]] .sourceHead = true := by decide
def e2422407170478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407170478 : Closed e2422407170478 ∧ code e2422407170478 = 11218500192686 := by decide
theorem cert_e2422407170478 : check e2422407170478 [[],[]] .chain = true := by decide
def e2422407170490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407170490 : Closed e2422407170490 ∧ code e2422407170490 = 11218500192698 := by decide
theorem cert_e2422407170490 : check e2422407170490 [[],[]] .chain = true := by decide
def e2422407170538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407170538 : Closed e2422407170538 ∧ code e2422407170538 = 11218500192746 := by decide
theorem cert_e2422407170538 : check e2422407170538 [[],[]] .chain = true := by decide
def e2422407170670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407170670 : Closed e2422407170670 ∧ code e2422407170670 = 11218500192878 := by decide
theorem cert_e2422407170670 : check e2422407170670 [[],[]] .chain = true := by decide
def e2422407170682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407170682 : Closed e2422407170682 ∧ code e2422407170682 = 11218500192890 := by decide
theorem cert_e2422407170682 : check e2422407170682 [[],[]] .chain = true := by decide
def e2422407170970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407170970 : Closed e2422407170970 ∧ code e2422407170970 = 11218500193178 := by decide
theorem cert_e2422407170970 : check e2422407170970 [[],[]] .chain = true := by decide
def e2422407171950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 1)) (.var 2))))))
theorem wire_e2422407171950 : Closed e2422407171950 ∧ code e2422407171950 = 11218500194158 := by decide
theorem cert_e2422407171950 : check e2422407171950 [[],[]] .chain = true := by decide
def e2422407171958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 3))))) (.var 2)) (.var 1))))))
theorem wire_e2422407171958 : Closed e2422407171958 ∧ code e2422407171958 = 11218500194166 := by decide
theorem cert_e2422407171958 : check e2422407171958 [[],[]] .chain = true := by decide
def e2422407172014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 4))))) (.var 0)) (.var 2))))))
theorem wire_e2422407172014 : Closed e2422407172014 ∧ code e2422407172014 = 11218500194222 := by decide
theorem cert_e2422407172014 : check e2422407172014 [[],[]] .chain = true := by decide
def e2422407172026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 4))))) (.var 2)) (.var 0))))))
theorem wire_e2422407172026 : Closed e2422407172026 ∧ code e2422407172026 = 11218500194234 := by decide
theorem cert_e2422407172026 : check e2422407172026 [[],[]] .chain = true := by decide
def e2422407172054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 5))))) (.var 0)) (.var 1))))))
theorem wire_e2422407172054 : Closed e2422407172054 ∧ code e2422407172054 = 11218500194262 := by decide
theorem cert_e2422407172054 : check e2422407172054 [[],[]] .chain = true := by decide
def e2422407172058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.lam (.var 5))))) (.var 1)) (.var 0))))))
theorem wire_e2422407172058 : Closed e2422407172058 ∧ code e2422407172058 = 11218500194266 := by decide
theorem cert_e2422407172058 : check e2422407172058 [[],[]] .chain = true := by decide
def e2422407175086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 0)) (.var 2))))))
theorem wire_e2422407175086 : Closed e2422407175086 ∧ code e2422407175086 = 11218500197294 := by decide
theorem cert_e2422407175086 : check e2422407175086 [[],[]] .chain = true := by decide
def e2422407175098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 2)) (.var 0))))))
theorem wire_e2422407175098 : Closed e2422407175098 ∧ code e2422407175098 = 11218500197306 := by decide
theorem cert_e2422407175098 : check e2422407175098 [[],[]] .chain = true := by decide
def e2422407175146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.var 4))))) (.var 0)) (.var 0))))))
theorem wire_e2422407175146 : Closed e2422407175146 ∧ code e2422407175146 = 11218500197354 := by decide
theorem cert_e2422407175146 : check e2422407175146 [[],[]] .chain = true := by decide
def e2422407175598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 2))))))
theorem wire_e2422407175598 : Closed e2422407175598 ∧ code e2422407175598 = 11218500197806 := by decide
theorem cert_e2422407175598 : check e2422407175598 [[],[]] .sourceHead = true := by decide
def e2422407175610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 2)) (.var 0))))))
theorem wire_e2422407175610 : Closed e2422407175610 ∧ code e2422407175610 = 11218500197818 := by decide
theorem cert_e2422407175610 : check e2422407175610 [[],[]] .sourceHead = true := by decide
def e2422407175854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422407175854 : Closed e2422407175854 ∧ code e2422407175854 = 11218500198062 := by decide
theorem cert_e2422407175854 : check e2422407175854 [[],[]] .chain = true := by decide
def e2422407175866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422407175866 : Closed e2422407175866 ∧ code e2422407175866 = 11218500198074 := by decide
theorem cert_e2422407175866 : check e2422407175866 [[],[]] .chain = true := by decide
def e2422407176106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.app (.var 4) (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407176106 : Closed e2422407176106 ∧ code e2422407176106 = 11218500198314 := by decide
theorem cert_e2422407176106 : check e2422407176106 [[],[]] .chain = true := by decide
def e2422407177966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422407177966 : Closed e2422407177966 ∧ code e2422407177966 = 11218500200174 := by decide
theorem cert_e2422407177966 : check e2422407177966 [[],[]] .sourceHead = true := by decide
def e2422407178158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422407178158 : Closed e2422407178158 ∧ code e2422407178158 = 11218500200366 := by decide
theorem cert_e2422407178158 : check e2422407178158 [[],[]] .sourceHead = true := by decide
def e2422407178170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422407178170 : Closed e2422407178170 ∧ code e2422407178170 = 11218500200378 := by decide
theorem cert_e2422407178170 : check e2422407178170 [[],[]] .sourceHead = true := by decide
def e2422407178734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407178734 : Closed e2422407178734 ∧ code e2422407178734 = 11218500200942 := by decide
theorem cert_e2422407178734 : check e2422407178734 [[],[]] .sourceHead = true := by decide
def e2422407179886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407179886 : Closed e2422407179886 ∧ code e2422407179886 = 11218500202094 := by decide
theorem cert_e2422407179886 : check e2422407179886 [[],[]] .sourceHead = true := by decide
def e2422407179898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407179898 : Closed e2422407179898 ∧ code e2422407179898 = 11218500202106 := by decide
theorem cert_e2422407179898 : check e2422407179898 [[],[]] .sourceHead = true := by decide
def e2422407181166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422407181166 : Closed e2422407181166 ∧ code e2422407181166 = 11218500203374 := by decide
theorem cert_e2422407181166 : check e2422407181166 [[],[]] .chain = true := by decide
def e2422407181174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422407181174 : Closed e2422407181174 ∧ code e2422407181174 = 11218500203382 := by decide
theorem cert_e2422407181174 : check e2422407181174 [[],[]] .chain = true := by decide
def e2422407181230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422407181230 : Closed e2422407181230 ∧ code e2422407181230 = 11218500203438 := by decide
theorem cert_e2422407181230 : check e2422407181230 [[],[]] .chain = true := by decide
def e2422407181242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422407181242 : Closed e2422407181242 ∧ code e2422407181242 = 11218500203450 := by decide
theorem cert_e2422407181242 : check e2422407181242 [[],[]] .chain = true := by decide
def e2422407181270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422407181270 : Closed e2422407181270 ∧ code e2422407181270 = 11218500203478 := by decide
theorem cert_e2422407181270 : check e2422407181270 [[],[]] .chain = true := by decide
def e2422407181274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422407181274 : Closed e2422407181274 ∧ code e2422407181274 = 11218500203482 := by decide
theorem cert_e2422407181274 : check e2422407181274 [[],[]] .chain = true := by decide
def e2422407181550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407181550 : Closed e2422407181550 ∧ code e2422407181550 = 11218500203758 := by decide
theorem cert_e2422407181550 : check e2422407181550 [[],[]] .chain = true := by decide
def e2422407181558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407181558 : Closed e2422407181558 ∧ code e2422407181558 = 11218500203766 := by decide
theorem cert_e2422407181558 : check e2422407181558 [[],[]] .chain = true := by decide
def e2422407181934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407181934 : Closed e2422407181934 ∧ code e2422407181934 = 11218500204142 := by decide
theorem cert_e2422407181934 : check e2422407181934 [[],[]] .chain = true := by decide
def e2422407181946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407181946 : Closed e2422407181946 ∧ code e2422407181946 = 11218500204154 := by decide
theorem cert_e2422407181946 : check e2422407181946 [[],[]] .chain = true := by decide
def e2422407182134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407182134 : Closed e2422407182134 ∧ code e2422407182134 = 11218500204342 := by decide
theorem cert_e2422407182134 : check e2422407182134 [[],[]] .chain = true := by decide
def e2422407182138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 1)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407182138 : Closed e2422407182138 ∧ code e2422407182138 = 11218500204346 := by decide
theorem cert_e2422407182138 : check e2422407182138 [[],[]] .chain = true := by decide
def e2422407182574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422407182574 : Closed e2422407182574 ∧ code e2422407182574 = 11218500204782 := by decide
theorem cert_e2422407182574 : check e2422407182574 [[],[]] .chain = true := by decide
def e2422407182582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422407182582 : Closed e2422407182582 ∧ code e2422407182582 = 11218500204790 := by decide
theorem cert_e2422407182582 : check e2422407182582 [[],[]] .chain = true := by decide
def e2422407182766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407182766 : Closed e2422407182766 ∧ code e2422407182766 = 11218500204974 := by decide
theorem cert_e2422407182766 : check e2422407182766 [[],[]] .chain = true := by decide
def e2422407182778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407182778 : Closed e2422407182778 ∧ code e2422407182778 = 11218500204986 := by decide
theorem cert_e2422407182778 : check e2422407182778 [[],[]] .chain = true := by decide
def e2422407182826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407182826 : Closed e2422407182826 ∧ code e2422407182826 = 11218500205034 := by decide
theorem cert_e2422407182826 : check e2422407182826 [[],[]] .chain = true := by decide
def e2422407182958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407182958 : Closed e2422407182958 ∧ code e2422407182958 = 11218500205166 := by decide
theorem cert_e2422407182958 : check e2422407182958 [[],[]] .chain = true := by decide
def e2422407182970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407182970 : Closed e2422407182970 ∧ code e2422407182970 = 11218500205178 := by decide
theorem cert_e2422407182970 : check e2422407182970 [[],[]] .chain = true := by decide
def e2422407183134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422407183134 : Closed e2422407183134 ∧ code e2422407183134 = 11218500205342 := by decide
theorem cert_e2422407183134 : check e2422407183134 [[],[]] .chain = true := by decide
def e2422407183246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422407183246 : Closed e2422407183246 ∧ code e2422407183246 = 11218500205454 := by decide
theorem cert_e2422407183246 : check e2422407183246 [[],[]] .chain = true := by decide
def e2422407183258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407183258 : Closed e2422407183258 ∧ code e2422407183258 = 11218500205466 := by decide
theorem cert_e2422407183258 : check e2422407183258 [[],[]] .chain = true := by decide
def e2422407183470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407183470 : Closed e2422407183470 ∧ code e2422407183470 = 11218500205678 := by decide
theorem cert_e2422407183470 : check e2422407183470 [[],[]] .chain = true := by decide
def e2422407183482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407183482 : Closed e2422407183482 ∧ code e2422407183482 = 11218500205690 := by decide
theorem cert_e2422407183482 : check e2422407183482 [[],[]] .chain = true := by decide
def e2422407183646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407183646 : Closed e2422407183646 ∧ code e2422407183646 = 11218500205854 := by decide
theorem cert_e2422407183646 : check e2422407183646 [[],[]] .chain = true := by decide
def e2422407183814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407183814 : Closed e2422407183814 ∧ code e2422407183814 = 11218500206022 := by decide
theorem cert_e2422407183814 : check e2422407183814 [[],[]] .chain = true := by decide
def e2422407183926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407183926 : Closed e2422407183926 ∧ code e2422407183926 = 11218500206134 := by decide
theorem cert_e2422407183926 : check e2422407183926 [[],[]] .chain = true := by decide
def e2422407183930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407183930 : Closed e2422407183930 ∧ code e2422407183930 = 11218500206138 := by decide
theorem cert_e2422407183930 : check e2422407183930 [[],[]] .chain = true := by decide
def e2422407183978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422407183978 : Closed e2422407183978 ∧ code e2422407183978 = 11218500206186 := by decide
theorem cert_e2422407183978 : check e2422407183978 [[],[]] .chain = true := by decide
def e2422407184014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407184014 : Closed e2422407184014 ∧ code e2422407184014 = 11218500206222 := by decide
theorem cert_e2422407184014 : check e2422407184014 [[],[]] .chain = true := by decide
def e2422407184026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407184026 : Closed e2422407184026 ∧ code e2422407184026 = 11218500206234 := by decide
theorem cert_e2422407184026 : check e2422407184026 [[],[]] .chain = true := by decide
def e2422407184070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407184070 : Closed e2422407184070 ∧ code e2422407184070 = 11218500206278 := by decide
theorem cert_e2422407184070 : check e2422407184070 [[],[]] .chain = true := by decide
def e2422407191214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422407191214 : Closed e2422407191214 ∧ code e2422407191214 = 11218500213422 := by decide
theorem cert_e2422407191214 : check e2422407191214 [[],[]] .sourceHead = true := by decide
def e2422407191226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422407191226 : Closed e2422407191226 ∧ code e2422407191226 = 11218500213434 := by decide
theorem cert_e2422407191226 : check e2422407191226 [[],[]] .sourceHead = true := by decide
def e2422407193518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 0)) (.var 2))))))
theorem wire_e2422407193518 : Closed e2422407193518 ∧ code e2422407193518 = 11218500215726 := by decide
theorem cert_e2422407193518 : check e2422407193518 [[],[]] .chain = true := by decide
def e2422407193530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 2)) (.var 0))))))
theorem wire_e2422407193530 : Closed e2422407193530 ∧ code e2422407193530 = 11218500215738 := by decide
theorem cert_e2422407193530 : check e2422407193530 [[],[]] .chain = true := by decide
def e2422407193578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.lam (.var 4))))) (.var 0)) (.var 0))))))
theorem wire_e2422407193578 : Closed e2422407193578 ∧ code e2422407193578 = 11218500215786 := by decide
theorem cert_e2422407193578 : check e2422407193578 [[],[]] .chain = true := by decide
def e2422407194286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422407194286 : Closed e2422407194286 ∧ code e2422407194286 = 11218500216494 := by decide
theorem cert_e2422407194286 : check e2422407194286 [[],[]] .sourceHead = true := by decide
def e2422407194298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422407194298 : Closed e2422407194298 ∧ code e2422407194298 = 11218500216506 := by decide
theorem cert_e2422407194298 : check e2422407194298 [[],[]] .sourceHead = true := by decide
def e2422407195054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422407195054 : Closed e2422407195054 ∧ code e2422407195054 = 11218500217262 := by decide
theorem cert_e2422407195054 : check e2422407195054 [[],[]] .sourceHead = true := by decide
def e2422407195066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422407195066 : Closed e2422407195066 ∧ code e2422407195066 = 11218500217274 := by decide
theorem cert_e2422407195066 : check e2422407195066 [[],[]] .sourceHead = true := by decide
def e2422407195114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422407195114 : Closed e2422407195114 ∧ code e2422407195114 = 11218500217322 := by decide
theorem cert_e2422407195114 : check e2422407195114 [[],[]] .sourceHead = true := by decide
def e2422407195246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407195246 : Closed e2422407195246 ∧ code e2422407195246 = 11218500217454 := by decide
theorem cert_e2422407195246 : check e2422407195246 [[],[]] .sourceHead = true := by decide
def e2422407195258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407195258 : Closed e2422407195258 ∧ code e2422407195258 = 11218500217466 := by decide
theorem cert_e2422407195258 : check e2422407195258 [[],[]] .sourceHead = true := by decide
def e2422407195546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407195546 : Closed e2422407195546 ∧ code e2422407195546 = 11218500217754 := by decide
theorem cert_e2422407195546 : check e2422407195546 [[],[]] .sourceHead = true := by decide
def e2422407195758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407195758 : Closed e2422407195758 ∧ code e2422407195758 = 11218500217966 := by decide
theorem cert_e2422407195758 : check e2422407195758 [[],[]] .chain = true := by decide
def e2422407195770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407195770 : Closed e2422407195770 ∧ code e2422407195770 = 11218500217978 := by decide
theorem cert_e2422407195770 : check e2422407195770 [[],[]] .chain = true := by decide
def e2422407195934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407195934 : Closed e2422407195934 ∧ code e2422407195934 = 11218500218142 := by decide
theorem cert_e2422407195934 : check e2422407195934 [[],[]] .chain = true := by decide
def e2422407196102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407196102 : Closed e2422407196102 ∧ code e2422407196102 = 11218500218310 := by decide
theorem cert_e2422407196102 : check e2422407196102 [[],[]] .chain = true := by decide
def e2422407196442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407196442 : Closed e2422407196442 ∧ code e2422407196442 = 11218500218650 := by decide
theorem cert_e2422407196442 : check e2422407196442 [[],[]] .chain = true := by decide
def e2422407196486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407196486 : Closed e2422407196486 ∧ code e2422407196486 = 11218500218694 := by decide
theorem cert_e2422407196486 : check e2422407196486 [[],[]] .chain = true := by decide
def e2422407197038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422407197038 : Closed e2422407197038 ∧ code e2422407197038 = 11218500219246 := by decide
theorem cert_e2422407197038 : check e2422407197038 [[],[]] .chain = true := by decide
def e2422407197046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422407197046 : Closed e2422407197046 ∧ code e2422407197046 = 11218500219254 := by decide
theorem cert_e2422407197046 : check e2422407197046 [[],[]] .chain = true := by decide
def e2422407197102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 0)) (.var 2))))))
theorem wire_e2422407197102 : Closed e2422407197102 ∧ code e2422407197102 = 11218500219310 := by decide
theorem cert_e2422407197102 : check e2422407197102 [[],[]] .chain = true := by decide
def e2422407197114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 2)) (.var 0))))))
theorem wire_e2422407197114 : Closed e2422407197114 ∧ code e2422407197114 = 11218500219322 := by decide
theorem cert_e2422407197114 : check e2422407197114 [[],[]] .chain = true := by decide
def e2422407197806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422407197806 : Closed e2422407197806 ∧ code e2422407197806 = 11218500220014 := by decide
theorem cert_e2422407197806 : check e2422407197806 [[],[]] .chain = true := by decide
def e2422407197818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422407197818 : Closed e2422407197818 ∧ code e2422407197818 = 11218500220026 := by decide
theorem cert_e2422407197818 : check e2422407197818 [[],[]] .chain = true := by decide
def e2422407197982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422407197982 : Closed e2422407197982 ∧ code e2422407197982 = 11218500220190 := by decide
theorem cert_e2422407197982 : check e2422407197982 [[],[]] .chain = true := by decide
def e2422407198150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422407198150 : Closed e2422407198150 ∧ code e2422407198150 = 11218500220358 := by decide
theorem cert_e2422407198150 : check e2422407198150 [[],[]] .chain = true := by decide
def e2422407198254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422407198254 : Closed e2422407198254 ∧ code e2422407198254 = 11218500220462 := by decide
theorem cert_e2422407198254 : check e2422407198254 [[],[]] .chain = true := by decide
def e2422407198434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422407198434 : Closed e2422407198434 ∧ code e2422407198434 = 11218500220642 := by decide
theorem cert_e2422407198434 : check e2422407198434 [[],[]] .chain = true := by decide
def e2422407198446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 2))))))
theorem wire_e2422407198446 : Closed e2422407198446 ∧ code e2422407198446 = 11218500220654 := by decide
theorem cert_e2422407198446 : check e2422407198446 [[],[]] .sourceHead = true := by decide
def e2422407198574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2422407198574 : Closed e2422407198574 ∧ code e2422407198574 = 11218500220782 := by decide
theorem cert_e2422407198574 : check e2422407198574 [[],[]] .chain = true := by decide
def e2422407198582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2422407198582 : Closed e2422407198582 ∧ code e2422407198582 = 11218500220790 := by decide
theorem cert_e2422407198582 : check e2422407198582 [[],[]] .chain = true := by decide
def e2422407198602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407198602 : Closed e2422407198602 ∧ code e2422407198602 = 11218500220810 := by decide
theorem cert_e2422407198602 : check e2422407198602 [[],[]] .chain = true := by decide
def e2422407198626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407198626 : Closed e2422407198626 ∧ code e2422407198626 = 11218500220834 := by decide
theorem cert_e2422407198626 : check e2422407198626 [[],[]] .chain = true := by decide
def e2422407198638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e2422407198638 : Closed e2422407198638 ∧ code e2422407198638 = 11218500220846 := by decide
theorem cert_e2422407198638 : check e2422407198638 [[],[]] .sourceHead = true := by decide
def e2422407198646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e2422407198646 : Closed e2422407198646 ∧ code e2422407198646 = 11218500220854 := by decide
theorem cert_e2422407198646 : check e2422407198646 [[],[]] .chain = true := by decide
def e2422407198650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e2422407198650 : Closed e2422407198650 ∧ code e2422407198650 = 11218500220858 := by decide
theorem cert_e2422407198650 : check e2422407198650 [[],[]] .sourceHead = true := by decide
def e2422407198894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422407198894 : Closed e2422407198894 ∧ code e2422407198894 = 11218500221102 := by decide
theorem cert_e2422407198894 : check e2422407198894 [[],[]] .chain = true := by decide
def e2422407198906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422407198906 : Closed e2422407198906 ∧ code e2422407198906 = 11218500221114 := by decide
theorem cert_e2422407198906 : check e2422407198906 [[],[]] .chain = true := by decide
def e2422407199598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422407199598 : Closed e2422407199598 ∧ code e2422407199598 = 11218500221806 := by decide
theorem cert_e2422407199598 : check e2422407199598 [[],[]] .chain = true := by decide
def e2422407199606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422407199606 : Closed e2422407199606 ∧ code e2422407199606 = 11218500221814 := by decide
theorem cert_e2422407199606 : check e2422407199606 [[],[]] .chain = true := by decide
def e2422407199662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422407199662 : Closed e2422407199662 ∧ code e2422407199662 = 11218500221870 := by decide
theorem cert_e2422407199662 : check e2422407199662 [[],[]] .chain = true := by decide
def e2422407199674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422407199674 : Closed e2422407199674 ∧ code e2422407199674 = 11218500221882 := by decide
theorem cert_e2422407199674 : check e2422407199674 [[],[]] .chain = true := by decide
def e2422407199702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2422407199702 : Closed e2422407199702 ∧ code e2422407199702 = 11218500221910 := by decide
theorem cert_e2422407199702 : check e2422407199702 [[],[]] .chain = true := by decide
def e2422407199706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2422407199706 : Closed e2422407199706 ∧ code e2422407199706 = 11218500221914 := by decide
theorem cert_e2422407199706 : check e2422407199706 [[],[]] .chain = true := by decide
def e2422407199830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422407199830 : Closed e2422407199830 ∧ code e2422407199830 = 11218500222038 := by decide
theorem cert_e2422407199830 : check e2422407199830 [[],[]] .chain = true := by decide
def e2422407199834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422407199834 : Closed e2422407199834 ∧ code e2422407199834 = 11218500222042 := by decide
theorem cert_e2422407199834 : check e2422407199834 [[],[]] .chain = true := by decide
def e2422407199850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 1))))) (.var 0)) (.var 0))))))
theorem wire_e2422407199850 : Closed e2422407199850 ∧ code e2422407199850 = 11218500222058 := by decide
theorem cert_e2422407199850 : check e2422407199850 [[],[]] .chain = true := by decide
def e2422407200026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407200026 : Closed e2422407200026 ∧ code e2422407200026 = 11218500222234 := by decide
theorem cert_e2422407200026 : check e2422407200026 [[],[]] .chain = true := by decide
def e2422407200070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407200070 : Closed e2422407200070 ∧ code e2422407200070 = 11218500222278 := by decide
theorem cert_e2422407200070 : check e2422407200070 [[],[]] .chain = true := by decide
def e2422407200138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407200138 : Closed e2422407200138 ∧ code e2422407200138 = 11218500222346 := by decide
theorem cert_e2422407200138 : check e2422407200138 [[],[]] .chain = true := by decide
def e2422407200162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407200162 : Closed e2422407200162 ∧ code e2422407200162 = 11218500222370 := by decide
theorem cert_e2422407200162 : check e2422407200162 [[],[]] .chain = true := by decide
def e2422407200174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422407200174 : Closed e2422407200174 ∧ code e2422407200174 = 11218500222382 := by decide
theorem cert_e2422407200174 : check e2422407200174 [[],[]] .sourceHead = true := by decide
def e2422407200182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422407200182 : Closed e2422407200182 ∧ code e2422407200182 = 11218500222390 := by decide
theorem cert_e2422407200182 : check e2422407200182 [[],[]] .chain = true := by decide
def e2422407200186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422407200186 : Closed e2422407200186 ∧ code e2422407200186 = 11218500222394 := by decide
theorem cert_e2422407200186 : check e2422407200186 [[],[]] .sourceHead = true := by decide
def e2422407200214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422407200214 : Closed e2422407200214 ∧ code e2422407200214 = 11218500222422 := by decide
theorem cert_e2422407200214 : check e2422407200214 [[],[]] .chain = true := by decide
def e2422407200218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422407200218 : Closed e2422407200218 ∧ code e2422407200218 = 11218500222426 := by decide
theorem cert_e2422407200218 : check e2422407200218 [[],[]] .chain = true := by decide
def e2422407200234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 3) (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2422407200234 : Closed e2422407200234 ∧ code e2422407200234 = 11218500222442 := by decide
theorem cert_e2422407200234 : check e2422407200234 [[],[]] .sourceHead = true := by decide
def e2422407202670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2422407202670 : Closed e2422407202670 ∧ code e2422407202670 = 11218500224878 := by decide
theorem cert_e2422407202670 : check e2422407202670 [[],[]] .chain = true := by decide
def e2422407202682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e2422407202682 : Closed e2422407202682 ∧ code e2422407202682 = 11218500224890 := by decide
theorem cert_e2422407202682 : check e2422407202682 [[],[]] .chain = true := by decide
def e2422407202778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e2422407202778 : Closed e2422407202778 ∧ code e2422407202778 = 11218500224986 := by decide
theorem cert_e2422407202778 : check e2422407202778 [[],[]] .chain = true := by decide
def e2422407204078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407204078 : Closed e2422407204078 ∧ code e2422407204078 = 11218500226286 := by decide
theorem cert_e2422407204078 : check e2422407204078 [[],[]] .chain = true := by decide
def e2422407204086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407204086 : Closed e2422407204086 ∧ code e2422407204086 = 11218500226294 := by decide
theorem cert_e2422407204086 : check e2422407204086 [[],[]] .chain = true := by decide
def e2422407204462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407204462 : Closed e2422407204462 ∧ code e2422407204462 = 11218500226670 := by decide
theorem cert_e2422407204462 : check e2422407204462 [[],[]] .chain = true := by decide
def e2422407204474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407204474 : Closed e2422407204474 ∧ code e2422407204474 = 11218500226682 := by decide
theorem cert_e2422407204474 : check e2422407204474 [[],[]] .chain = true := by decide
def e2422407204662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407204662 : Closed e2422407204662 ∧ code e2422407204662 = 11218500226870 := by decide
theorem cert_e2422407204662 : check e2422407204662 [[],[]] .chain = true := by decide
def e2422407204666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407204666 : Closed e2422407204666 ∧ code e2422407204666 = 11218500226874 := by decide
theorem cert_e2422407204666 : check e2422407204666 [[],[]] .chain = true := by decide
def e2422407206574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407206574 : Closed e2422407206574 ∧ code e2422407206574 = 11218500228782 := by decide
theorem cert_e2422407206574 : check e2422407206574 [[],[]] .chain = true := by decide
def e2422407206586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407206586 : Closed e2422407206586 ∧ code e2422407206586 = 11218500228794 := by decide
theorem cert_e2422407206586 : check e2422407206586 [[],[]] .chain = true := by decide
def e2422407206634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407206634 : Closed e2422407206634 ∧ code e2422407206634 = 11218500228842 := by decide
theorem cert_e2422407206634 : check e2422407206634 [[],[]] .chain = true := by decide
def e2422407206826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2422407206826 : Closed e2422407206826 ∧ code e2422407206826 = 11218500229034 := by decide
theorem cert_e2422407206826 : check e2422407206826 [[],[]] .chain = true := by decide
def e2422407207150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407207150 : Closed e2422407207150 ∧ code e2422407207150 = 11218500229358 := by decide
theorem cert_e2422407207150 : check e2422407207150 [[],[]] .chain = true := by decide
def e2422407207158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407207158 : Closed e2422407207158 ∧ code e2422407207158 = 11218500229366 := by decide
theorem cert_e2422407207158 : check e2422407207158 [[],[]] .chain = true := by decide
def e2422407207342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407207342 : Closed e2422407207342 ∧ code e2422407207342 = 11218500229550 := by decide
theorem cert_e2422407207342 : check e2422407207342 [[],[]] .chain = true := by decide
def e2422407207354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407207354 : Closed e2422407207354 ∧ code e2422407207354 = 11218500229562 := by decide
theorem cert_e2422407207354 : check e2422407207354 [[],[]] .chain = true := by decide
def e2422407207402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407207402 : Closed e2422407207402 ∧ code e2422407207402 = 11218500229610 := by decide
theorem cert_e2422407207402 : check e2422407207402 [[],[]] .chain = true := by decide
def e2422407207534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407207534 : Closed e2422407207534 ∧ code e2422407207534 = 11218500229742 := by decide
theorem cert_e2422407207534 : check e2422407207534 [[],[]] .chain = true := by decide
def e2422407207546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407207546 : Closed e2422407207546 ∧ code e2422407207546 = 11218500229754 := by decide
theorem cert_e2422407207546 : check e2422407207546 [[],[]] .chain = true := by decide
def e2422407207710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407207710 : Closed e2422407207710 ∧ code e2422407207710 = 11218500229918 := by decide
theorem cert_e2422407207710 : check e2422407207710 [[],[]] .chain = true := by decide
def e2422407207822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407207822 : Closed e2422407207822 ∧ code e2422407207822 = 11218500230030 := by decide
theorem cert_e2422407207822 : check e2422407207822 [[],[]] .chain = true := by decide
def e2422407207834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407207834 : Closed e2422407207834 ∧ code e2422407207834 = 11218500230042 := by decide
theorem cert_e2422407207834 : check e2422407207834 [[],[]] .chain = true := by decide
def e2422407208046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422407208046 : Closed e2422407208046 ∧ code e2422407208046 = 11218500230254 := by decide
theorem cert_e2422407208046 : check e2422407208046 [[],[]] .chain = true := by decide
def e2422407208058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407208058 : Closed e2422407208058 ∧ code e2422407208058 = 11218500230266 := by decide
theorem cert_e2422407208058 : check e2422407208058 [[],[]] .chain = true := by decide
def e2422407208222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422407208222 : Closed e2422407208222 ∧ code e2422407208222 = 11218500230430 := by decide
theorem cert_e2422407208222 : check e2422407208222 [[],[]] .chain = true := by decide
def e2422407208390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407208390 : Closed e2422407208390 ∧ code e2422407208390 = 11218500230598 := by decide
theorem cert_e2422407208390 : check e2422407208390 [[],[]] .chain = true := by decide
def e2422407208502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407208502 : Closed e2422407208502 ∧ code e2422407208502 = 11218500230710 := by decide
theorem cert_e2422407208502 : check e2422407208502 [[],[]] .chain = true := by decide
def e2422407208506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407208506 : Closed e2422407208506 ∧ code e2422407208506 = 11218500230714 := by decide
theorem cert_e2422407208506 : check e2422407208506 [[],[]] .chain = true := by decide
def e2422407208554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407208554 : Closed e2422407208554 ∧ code e2422407208554 = 11218500230762 := by decide
theorem cert_e2422407208554 : check e2422407208554 [[],[]] .chain = true := by decide
def e2422407208590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407208590 : Closed e2422407208590 ∧ code e2422407208590 = 11218500230798 := by decide
theorem cert_e2422407208590 : check e2422407208590 [[],[]] .chain = true := by decide
def e2422407208602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407208602 : Closed e2422407208602 ∧ code e2422407208602 = 11218500230810 := by decide
theorem cert_e2422407208602 : check e2422407208602 [[],[]] .chain = true := by decide
def e2422407208646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407208646 : Closed e2422407208646 ∧ code e2422407208646 = 11218500230854 := by decide
theorem cert_e2422407208646 : check e2422407208646 [[],[]] .chain = true := by decide
def e2422407209438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407209438 : Closed e2422407209438 ∧ code e2422407209438 = 11218500231646 := by decide
theorem cert_e2422407209438 : check e2422407209438 [[],[]] .chain = true := by decide
def e2422407209462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407209462 : Closed e2422407209462 ∧ code e2422407209462 = 11218500231670 := by decide
theorem cert_e2422407209462 : check e2422407209462 [[],[]] .chain = true := by decide
end Blc.Floor43
