import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606395888558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e606395888558 : Closed e606395888558 ∧ code e606395888558 = 9402488910766 := by decide
theorem cert_e606395888558 : check e606395888558 [[.under]] .sourceHead = true := by decide
def e606395888570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e606395888570 : Closed e606395888570 ∧ code e606395888570 = 9402488910778 := by decide
theorem cert_e606395888570 : check e606395888570 [[.under]] .sourceHead = true := by decide
def e606395888598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e606395888598 : Closed e606395888598 ∧ code e606395888598 = 9402488910806 := by decide
theorem cert_e606395888598 : check e606395888598 [[.under]] .sourceHead = true := by decide
def e606395888602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e606395888602 : Closed e606395888602 ∧ code e606395888602 = 9402488910810 := by decide
theorem cert_e606395888602 : check e606395888602 [[.under]] .sourceHead = true := by decide
def e606395888618 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e606395888618 : Closed e606395888618 ∧ code e606395888618 = 9402488910826 := by decide
theorem cert_e606395888618 : check e606395888618 [[.under]] .sourceHead = true := by decide
def e606395888862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e606395888862 : Closed e606395888862 ∧ code e606395888862 = 9402488911070 := by decide
theorem cert_e606395888862 : check e606395888862 [[.under]] .sourceHead = true := by decide
def e606395888878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e606395888878 : Closed e606395888878 ∧ code e606395888878 = 9402488911086 := by decide
theorem cert_e606395888878 : check e606395888878 [[.under]] .sourceHead = true := by decide
def e606395888886 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e606395888886 : Closed e606395888886 ∧ code e606395888886 = 9402488911094 := by decide
theorem cert_e606395888886 : check e606395888886 [[.under]] .sourceHead = true := by decide
def e606395888890 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e606395888890 : Closed e606395888890 ∧ code e606395888890 = 9402488911098 := by decide
theorem cert_e606395888890 : check e606395888890 [[.under]] .sourceHead = true := by decide
def e606395889262 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606395889262 : Closed e606395889262 ∧ code e606395889262 = 9402488911470 := by decide
theorem cert_e606395889262 : check e606395889262 [[.under]] .sourceHead = true := by decide
def e606395889274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606395889274 : Closed e606395889274 ∧ code e606395889274 = 9402488911482 := by decide
theorem cert_e606395889274 : check e606395889274 [[.under]] .sourceHead = true := by decide
def e606395889462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606395889462 : Closed e606395889462 ∧ code e606395889462 = 9402488911670 := by decide
theorem cert_e606395889462 : check e606395889462 [[.under]] .sourceHead = true := by decide
def e606395889466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606395889466 : Closed e606395889466 ∧ code e606395889466 = 9402488911674 := by decide
theorem cert_e606395889466 : check e606395889466 [[.under]] .sourceHead = true := by decide
def e606395889562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606395889562 : Closed e606395889562 ∧ code e606395889562 = 9402488911770 := by decide
theorem cert_e606395889562 : check e606395889562 [[.under]] .sourceHead = true := by decide
def e606395890094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e606395890094 : Closed e606395890094 ∧ code e606395890094 = 9402488912302 := by decide
theorem cert_e606395890094 : check e606395890094 [[.under]] .sourceHead = true := by decide
def e606395890102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e606395890102 : Closed e606395890102 ∧ code e606395890102 = 9402488912310 := by decide
theorem cert_e606395890102 : check e606395890102 [[.under]] .sourceHead = true := by decide
def e606395890106 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e606395890106 : Closed e606395890106 ∧ code e606395890106 = 9402488912314 := by decide
theorem cert_e606395890106 : check e606395890106 [[.under]] .sourceHead = true := by decide
def e606395890134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e606395890134 : Closed e606395890134 ∧ code e606395890134 = 9402488912342 := by decide
theorem cert_e606395890134 : check e606395890134 [[.under]] .sourceHead = true := by decide
def e606395890138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e606395890138 : Closed e606395890138 ∧ code e606395890138 = 9402488912346 := by decide
theorem cert_e606395890138 : check e606395890138 [[.under]] .sourceHead = true := by decide
def e606395890154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e606395890154 : Closed e606395890154 ∧ code e606395890154 = 9402488912362 := by decide
theorem cert_e606395890154 : check e606395890154 [[.under]] .sourceHead = true := by decide
def e606395890286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e606395890286 : Closed e606395890286 ∧ code e606395890286 = 9402488912494 := by decide
theorem cert_e606395890286 : check e606395890286 [[.under]] .sourceHead = true := by decide
def e606395890294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e606395890294 : Closed e606395890294 ∧ code e606395890294 = 9402488912502 := by decide
theorem cert_e606395890294 : check e606395890294 [[.under]] .sourceHead = true := by decide
def e606395890298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e606395890298 : Closed e606395890298 ∧ code e606395890298 = 9402488912506 := by decide
theorem cert_e606395890298 : check e606395890298 [[.under]] .sourceHead = true := by decide
def e606395890486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e606395890486 : Closed e606395890486 ∧ code e606395890486 = 9402488912694 := by decide
theorem cert_e606395890486 : check e606395890486 [[.under]] .sourceHead = true := by decide
def e606395890490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e606395890490 : Closed e606395890490 ∧ code e606395890490 = 9402488912698 := by decide
theorem cert_e606395890490 : check e606395890490 [[.under]] .sourceHead = true := by decide
def e606395890586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e606395890586 : Closed e606395890586 ∧ code e606395890586 = 9402488912794 := by decide
theorem cert_e606395890586 : check e606395890586 [[.under]] .sourceHead = true := by decide
def e606395894638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e606395894638 : Closed e606395894638 ∧ code e606395894638 = 9402488916846 := by decide
theorem cert_e606395894638 : check e606395894638 [[.under]] .sourceHead = true := by decide
def e606395894646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e606395894646 : Closed e606395894646 ∧ code e606395894646 = 9402488916854 := by decide
theorem cert_e606395894646 : check e606395894646 [[.under]] .sourceHead = true := by decide
def e606395894702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e606395894702 : Closed e606395894702 ∧ code e606395894702 = 9402488916910 := by decide
theorem cert_e606395894702 : check e606395894702 [[.under]] .sourceHead = true := by decide
def e606395894714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e606395894714 : Closed e606395894714 ∧ code e606395894714 = 9402488916922 := by decide
theorem cert_e606395894714 : check e606395894714 [[.under]] .sourceHead = true := by decide
def e606395894742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e606395894742 : Closed e606395894742 ∧ code e606395894742 = 9402488916950 := by decide
theorem cert_e606395894742 : check e606395894742 [[.under]] .sourceHead = true := by decide
def e606395894746 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e606395894746 : Closed e606395894746 ∧ code e606395894746 = 9402488916954 := by decide
theorem cert_e606395894746 : check e606395894746 [[.under]] .sourceHead = true := by decide
def e606395895022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e606395895022 : Closed e606395895022 ∧ code e606395895022 = 9402488917230 := by decide
theorem cert_e606395895022 : check e606395895022 [[.under]] .sourceHead = true := by decide
def e606395895030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e606395895030 : Closed e606395895030 ∧ code e606395895030 = 9402488917238 := by decide
theorem cert_e606395895030 : check e606395895030 [[.under]] .sourceHead = true := by decide
def e606395895406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e606395895406 : Closed e606395895406 ∧ code e606395895406 = 9402488917614 := by decide
theorem cert_e606395895406 : check e606395895406 [[.under]] .sourceHead = true := by decide
def e606395895418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e606395895418 : Closed e606395895418 ∧ code e606395895418 = 9402488917626 := by decide
theorem cert_e606395895418 : check e606395895418 [[.under]] .sourceHead = true := by decide
def e606395895606 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e606395895606 : Closed e606395895606 ∧ code e606395895606 = 9402488917814 := by decide
theorem cert_e606395895606 : check e606395895606 [[.under]] .sourceHead = true := by decide
def e606395895610 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e606395895610 : Closed e606395895610 ∧ code e606395895610 = 9402488917818 := by decide
theorem cert_e606395895610 : check e606395895610 [[.under]] .sourceHead = true := by decide
def e606395903454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3))))))))))
theorem wire_e606395903454 : Closed e606395903454 ∧ code e606395903454 = 9402488925662 := by decide
theorem cert_e606395903454 : check e606395903454 [[.under]] .sourceHead = true := by decide
def e606395903470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2))))))))))
theorem wire_e606395903470 : Closed e606395903470 ∧ code e606395903470 = 9402488925678 := by decide
theorem cert_e606395903470 : check e606395903470 [[.under]] .sourceHead = true := by decide
def e606395903710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3))))))))))
theorem wire_e606395903710 : Closed e606395903710 ∧ code e606395903710 = 9402488925918 := by decide
theorem cert_e606395903710 : check e606395903710 [[.under]] .sourceHead = true := by decide
def e606395903726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))))
theorem wire_e606395903726 : Closed e606395903726 ∧ code e606395903726 = 9402488925934 := by decide
theorem cert_e606395903726 : check e606395903726 [[.under]] .sourceHead = true := by decide
def e606395903734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1))))))))))
theorem wire_e606395903734 : Closed e606395903734 ∧ code e606395903734 = 9402488925942 := by decide
theorem cert_e606395903734 : check e606395903734 [[.under]] .sourceHead = true := by decide
def e606395903838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3))))))))))
theorem wire_e606395903838 : Closed e606395903838 ∧ code e606395903838 = 9402488926046 := by decide
theorem cert_e606395903838 : check e606395903838 [[.under]] .sourceHead = true := by decide
def e606395903854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))))
theorem wire_e606395903854 : Closed e606395903854 ∧ code e606395903854 = 9402488926062 := by decide
theorem cert_e606395903854 : check e606395903854 [[.under]] .sourceHead = true := by decide
def e606395903862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))))
theorem wire_e606395903862 : Closed e606395903862 ∧ code e606395903862 = 9402488926070 := by decide
theorem cert_e606395903862 : check e606395903862 [[.under]] .sourceHead = true := by decide
def e606395903866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0))))))))))
theorem wire_e606395903866 : Closed e606395903866 ∧ code e606395903866 = 9402488926074 := by decide
theorem cert_e606395903866 : check e606395903866 [[.under]] .sourceHead = true := by decide
def e606395903918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2))))))))))
theorem wire_e606395903918 : Closed e606395903918 ∧ code e606395903918 = 9402488926126 := by decide
theorem cert_e606395903918 : check e606395903918 [[.under]] .sourceHead = true := by decide
def e606395903926 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1))))))))))
theorem wire_e606395903926 : Closed e606395903926 ∧ code e606395903926 = 9402488926134 := by decide
theorem cert_e606395903926 : check e606395903926 [[.under]] .sourceHead = true := by decide
def e606395903930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0))))))))))
theorem wire_e606395903930 : Closed e606395903930 ∧ code e606395903930 = 9402488926138 := by decide
theorem cert_e606395903930 : check e606395903930 [[.under]] .sourceHead = true := by decide
def e606395904990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3)))))))))))
theorem wire_e606395904990 : Closed e606395904990 ∧ code e606395904990 = 9402488927198 := by decide
theorem cert_e606395904990 : check e606395904990 [[.under]] .sourceHead = true := by decide
def e606395905006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2)))))))))))
theorem wire_e606395905006 : Closed e606395905006 ∧ code e606395905006 = 9402488927214 := by decide
theorem cert_e606395905006 : check e606395905006 [[.under]] .sourceHead = true := by decide
def e606395906526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3)))))))))))
theorem wire_e606395906526 : Closed e606395906526 ∧ code e606395906526 = 9402488928734 := by decide
theorem cert_e606395906526 : check e606395906526 [[.under]] .sourceHead = true := by decide
def e606395906542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))))
theorem wire_e606395906542 : Closed e606395906542 ∧ code e606395906542 = 9402488928750 := by decide
theorem cert_e606395906542 : check e606395906542 [[.under]] .sourceHead = true := by decide
def e606395906550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1)))))))))))
theorem wire_e606395906550 : Closed e606395906550 ∧ code e606395906550 = 9402488928758 := by decide
theorem cert_e606395906550 : check e606395906550 [[.under]] .sourceHead = true := by decide
def e606395907294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3)))))))))))
theorem wire_e606395907294 : Closed e606395907294 ∧ code e606395907294 = 9402488929502 := by decide
theorem cert_e606395907294 : check e606395907294 [[.under]] .sourceHead = true := by decide
def e606395907310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606395907310 : Closed e606395907310 ∧ code e606395907310 = 9402488929518 := by decide
theorem cert_e606395907310 : check e606395907310 [[.under]] .sourceHead = true := by decide
def e606395907318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606395907318 : Closed e606395907318 ∧ code e606395907318 = 9402488929526 := by decide
theorem cert_e606395907318 : check e606395907318 [[.under]] .sourceHead = true := by decide
def e606395907322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0)))))))))))
theorem wire_e606395907322 : Closed e606395907322 ∧ code e606395907322 = 9402488929530 := by decide
theorem cert_e606395907322 : check e606395907322 [[.under]] .sourceHead = true := by decide
def e606395907694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606395907694 : Closed e606395907694 ∧ code e606395907694 = 9402488929902 := by decide
theorem cert_e606395907694 : check e606395907694 [[.under]] .sourceHead = true := by decide
def e606395907702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1)))))))))))
theorem wire_e606395907702 : Closed e606395907702 ∧ code e606395907702 = 9402488929910 := by decide
theorem cert_e606395907702 : check e606395907702 [[.under]] .sourceHead = true := by decide
def e606395907706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606395907706 : Closed e606395907706 ∧ code e606395907706 = 9402488929914 := by decide
theorem cert_e606395907706 : check e606395907706 [[.under]] .sourceHead = true := by decide
def e606395930334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e606395930334 : Closed e606395930334 ∧ code e606395930334 = 9402488952542 := by decide
theorem cert_e606395930334 : check e606395930334 [[.under]] .sourceHead = true := by decide
def e606395930350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))))
theorem wire_e606395930350 : Closed e606395930350 ∧ code e606395930350 = 9402488952558 := by decide
theorem cert_e606395930350 : check e606395930350 [[.under]] .sourceHead = true := by decide
def e606395930358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e606395930358 : Closed e606395930358 ∧ code e606395930358 = 9402488952566 := by decide
theorem cert_e606395930358 : check e606395930358 [[.under]] .sourceHead = true := by decide
def e606395930462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e606395930462 : Closed e606395930462 ∧ code e606395930462 = 9402488952670 := by decide
theorem cert_e606395930462 : check e606395930462 [[.under]] .sourceHead = true := by decide
def e606395930490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e606395930490 : Closed e606395930490 ∧ code e606395930490 = 9402488952698 := by decide
theorem cert_e606395930490 : check e606395930490 [[.under]] .sourceHead = true := by decide
def e606395930542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))))
theorem wire_e606395930542 : Closed e606395930542 ∧ code e606395930542 = 9402488952750 := by decide
theorem cert_e606395930542 : check e606395930542 [[.under]] .sourceHead = true := by decide
def e606395930554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))))
theorem wire_e606395930554 : Closed e606395930554 ∧ code e606395930554 = 9402488952762 := by decide
theorem cert_e606395930554 : check e606395930554 [[.under]] .sourceHead = true := by decide
def e606395930582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e606395930582 : Closed e606395930582 ∧ code e606395930582 = 9402488952790 := by decide
theorem cert_e606395930582 : check e606395930582 [[.under]] .sourceHead = true := by decide
def e606395930586 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e606395930586 : Closed e606395930586 ∧ code e606395930586 = 9402488952794 := by decide
theorem cert_e606395930586 : check e606395930586 [[.under]] .sourceHead = true := by decide
def e606395931102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e606395931102 : Closed e606395931102 ∧ code e606395931102 = 9402488953310 := by decide
theorem cert_e606395931102 : check e606395931102 [[.under]] .sourceHead = true := by decide
def e606395931118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))))
theorem wire_e606395931118 : Closed e606395931118 ∧ code e606395931118 = 9402488953326 := by decide
theorem cert_e606395931118 : check e606395931118 [[.under]] .sourceHead = true := by decide
def e606395931126 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e606395931126 : Closed e606395931126 ∧ code e606395931126 = 9402488953334 := by decide
theorem cert_e606395931126 : check e606395931126 [[.under]] .sourceHead = true := by decide
def e606395931870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e606395931870 : Closed e606395931870 ∧ code e606395931870 = 9402488954078 := by decide
theorem cert_e606395931870 : check e606395931870 [[.under]] .sourceHead = true := by decide
def e606395931898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e606395931898 : Closed e606395931898 ∧ code e606395931898 = 9402488954106 := by decide
theorem cert_e606395931898 : check e606395931898 [[.under]] .sourceHead = true := by decide
def e606395932270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606395932270 : Closed e606395932270 ∧ code e606395932270 = 9402488954478 := by decide
theorem cert_e606395932270 : check e606395932270 [[.under]] .sourceHead = true := by decide
def e606395932282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606395932282 : Closed e606395932282 ∧ code e606395932282 = 9402488954490 := by decide
theorem cert_e606395932282 : check e606395932282 [[.under]] .sourceHead = true := by decide
def e606395932470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606395932470 : Closed e606395932470 ∧ code e606395932470 = 9402488954678 := by decide
theorem cert_e606395932470 : check e606395932470 [[.under]] .sourceHead = true := by decide
def e606395932474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606395932474 : Closed e606395932474 ∧ code e606395932474 = 9402488954682 := by decide
theorem cert_e606395932474 : check e606395932474 [[.under]] .sourceHead = true := by decide
def e606395943774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e606395943774 : Closed e606395943774 ∧ code e606395943774 = 9402488965982 := by decide
theorem cert_e606395943774 : check e606395943774 [[.under]] .sourceHead = true := by decide
def e606395943790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e606395943790 : Closed e606395943790 ∧ code e606395943790 = 9402488965998 := by decide
theorem cert_e606395943790 : check e606395943790 [[.under]] .sourceHead = true := by decide
def e606395943798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e606395943798 : Closed e606395943798 ∧ code e606395943798 = 9402488966006 := by decide
theorem cert_e606395943798 : check e606395943798 [[.under]] .sourceHead = true := by decide
def e606395943802 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e606395943802 : Closed e606395943802 ∧ code e606395943802 = 9402488966010 := by decide
theorem cert_e606395943802 : check e606395943802 [[.under]] .sourceHead = true := by decide
def e606395943854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e606395943854 : Closed e606395943854 ∧ code e606395943854 = 9402488966062 := by decide
theorem cert_e606395943854 : check e606395943854 [[.under]] .sourceHead = true := by decide
def e606395943866 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e606395943866 : Closed e606395943866 ∧ code e606395943866 = 9402488966074 := by decide
theorem cert_e606395943866 : check e606395943866 [[.under]] .sourceHead = true := by decide
def e606395943894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e606395943894 : Closed e606395943894 ∧ code e606395943894 = 9402488966102 := by decide
theorem cert_e606395943894 : check e606395943894 [[.under]] .sourceHead = true := by decide
def e606395943898 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e606395943898 : Closed e606395943898 ∧ code e606395943898 = 9402488966106 := by decide
theorem cert_e606395943898 : check e606395943898 [[.under]] .sourceHead = true := by decide
def e606395943914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e606395943914 : Closed e606395943914 ∧ code e606395943914 = 9402488966122 := by decide
theorem cert_e606395943914 : check e606395943914 [[.under]] .sourceHead = true := by decide
def e606395944158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e606395944158 : Closed e606395944158 ∧ code e606395944158 = 9402488966366 := by decide
theorem cert_e606395944158 : check e606395944158 [[.under]] .sourceHead = true := by decide
def e606395944174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e606395944174 : Closed e606395944174 ∧ code e606395944174 = 9402488966382 := by decide
theorem cert_e606395944174 : check e606395944174 [[.under]] .sourceHead = true := by decide
def e606395944182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e606395944182 : Closed e606395944182 ∧ code e606395944182 = 9402488966390 := by decide
theorem cert_e606395944182 : check e606395944182 [[.under]] .sourceHead = true := by decide
def e606395944186 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e606395944186 : Closed e606395944186 ∧ code e606395944186 = 9402488966394 := by decide
theorem cert_e606395944186 : check e606395944186 [[.under]] .sourceHead = true := by decide
def e606395944558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606395944558 : Closed e606395944558 ∧ code e606395944558 = 9402488966766 := by decide
theorem cert_e606395944558 : check e606395944558 [[.under]] .sourceHead = true := by decide
def e606395944570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606395944570 : Closed e606395944570 ∧ code e606395944570 = 9402488966778 := by decide
theorem cert_e606395944570 : check e606395944570 [[.under]] .sourceHead = true := by decide
def e606395944758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606395944758 : Closed e606395944758 ∧ code e606395944758 = 9402488966966 := by decide
theorem cert_e606395944758 : check e606395944758 [[.under]] .sourceHead = true := by decide
def e606395944762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606395944762 : Closed e606395944762 ∧ code e606395944762 = 9402488966970 := by decide
theorem cert_e606395944762 : check e606395944762 [[.under]] .sourceHead = true := by decide
def e606395944858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606395944858 : Closed e606395944858 ∧ code e606395944858 = 9402488967066 := by decide
theorem cert_e606395944858 : check e606395944858 [[.under]] .sourceHead = true := by decide
def e606395950510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e606395950510 : Closed e606395950510 ∧ code e606395950510 = 9402488972718 := by decide
theorem cert_e606395950510 : check e606395950510 [[.under]] .sourceHead = true := by decide
def e606395950518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e606395950518 : Closed e606395950518 ∧ code e606395950518 = 9402488972726 := by decide
theorem cert_e606395950518 : check e606395950518 [[.under]] .sourceHead = true := by decide
def e606395950522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e606395950522 : Closed e606395950522 ∧ code e606395950522 = 9402488972730 := by decide
theorem cert_e606395950522 : check e606395950522 [[.under]] .sourceHead = true := by decide
def e606395950550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e606395950550 : Closed e606395950550 ∧ code e606395950550 = 9402488972758 := by decide
theorem cert_e606395950550 : check e606395950550 [[.under]] .sourceHead = true := by decide
def e606395950554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e606395950554 : Closed e606395950554 ∧ code e606395950554 = 9402488972762 := by decide
theorem cert_e606395950554 : check e606395950554 [[.under]] .sourceHead = true := by decide
def e606395950570 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e606395950570 : Closed e606395950570 ∧ code e606395950570 = 9402488972778 := by decide
theorem cert_e606395950570 : check e606395950570 [[.under]] .sourceHead = true := by decide
def e606395950702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e606395950702 : Closed e606395950702 ∧ code e606395950702 = 9402488972910 := by decide
theorem cert_e606395950702 : check e606395950702 [[.under]] .sourceHead = true := by decide
def e606395950710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e606395950710 : Closed e606395950710 ∧ code e606395950710 = 9402488972918 := by decide
theorem cert_e606395950710 : check e606395950710 [[.under]] .sourceHead = true := by decide
def e606395950714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e606395950714 : Closed e606395950714 ∧ code e606395950714 = 9402488972922 := by decide
theorem cert_e606395950714 : check e606395950714 [[.under]] .sourceHead = true := by decide
def e606395950902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e606395950902 : Closed e606395950902 ∧ code e606395950902 = 9402488973110 := by decide
theorem cert_e606395950902 : check e606395950902 [[.under]] .sourceHead = true := by decide
def e606395950906 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e606395950906 : Closed e606395950906 ∧ code e606395950906 = 9402488973114 := by decide
theorem cert_e606395950906 : check e606395950906 [[.under]] .sourceHead = true := by decide
def e606395951002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e606395951002 : Closed e606395951002 ∧ code e606395951002 = 9402488973210 := by decide
theorem cert_e606395951002 : check e606395951002 [[.under]] .sourceHead = true := by decide
def e606396396910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e606396396910 : Closed e606396396910 ∧ code e606396396910 = 9402489419118 := by decide
theorem cert_e606396396910 : check e606396396910 [[.under]] .sourceHead = true := by decide
def e606396396918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e606396396918 : Closed e606396396918 ∧ code e606396396918 = 9402489419126 := by decide
theorem cert_e606396396918 : check e606396396918 [[.under]] .sourceHead = true := by decide
def e606396396974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e606396396974 : Closed e606396396974 ∧ code e606396396974 = 9402489419182 := by decide
theorem cert_e606396396974 : check e606396396974 [[.under]] .sourceHead = true := by decide
def e606396396986 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e606396396986 : Closed e606396396986 ∧ code e606396396986 = 9402489419194 := by decide
theorem cert_e606396396986 : check e606396396986 [[.under]] .sourceHead = true := by decide
def e606396397014 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e606396397014 : Closed e606396397014 ∧ code e606396397014 = 9402489419222 := by decide
theorem cert_e606396397014 : check e606396397014 [[.under]] .sourceHead = true := by decide
def e606396397018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e606396397018 : Closed e606396397018 ∧ code e606396397018 = 9402489419226 := by decide
theorem cert_e606396397018 : check e606396397018 [[.under]] .sourceHead = true := by decide
def e606396397230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e606396397230 : Closed e606396397230 ∧ code e606396397230 = 9402489419438 := by decide
theorem cert_e606396397230 : check e606396397230 [[.under]] .sourceHead = true := by decide
def e606396397242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e606396397242 : Closed e606396397242 ∧ code e606396397242 = 9402489419450 := by decide
theorem cert_e606396397242 : check e606396397242 [[.under]] .sourceHead = true := by decide
def e606396397290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e606396397290 : Closed e606396397290 ∧ code e606396397290 = 9402489419498 := by decide
theorem cert_e606396397290 : check e606396397290 [[.under]] .sourceHead = true := by decide
def e606396397398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e606396397398 : Closed e606396397398 ∧ code e606396397398 = 9402489419606 := by decide
theorem cert_e606396397398 : check e606396397398 [[.under]] .sourceHead = true := by decide
def e606396397402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e606396397402 : Closed e606396397402 ∧ code e606396397402 = 9402489419610 := by decide
theorem cert_e606396397402 : check e606396397402 [[.under]] .sourceHead = true := by decide
def e606396397418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e606396397418 : Closed e606396397418 ∧ code e606396397418 = 9402489419626 := by decide
theorem cert_e606396397418 : check e606396397418 [[.under]] .sourceHead = true := by decide
def e606396398254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e606396398254 : Closed e606396398254 ∧ code e606396398254 = 9402489420462 := by decide
theorem cert_e606396398254 : check e606396398254 [[.under]] .sourceHead = true := by decide
def e606396398266 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e606396398266 : Closed e606396398266 ∧ code e606396398266 = 9402489420474 := by decide
theorem cert_e606396398266 : check e606396398266 [[.under]] .sourceHead = true := by decide
def e606396398314 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e606396398314 : Closed e606396398314 ∧ code e606396398314 = 9402489420522 := by decide
theorem cert_e606396398314 : check e606396398314 [[.under]] .sourceHead = true := by decide
def e606396398506 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e606396398506 : Closed e606396398506 ∧ code e606396398506 = 9402489420714 := by decide
theorem cert_e606396398506 : check e606396398506 [[.under]] .sourceHead = true := by decide
def e606396398934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e606396398934 : Closed e606396398934 ∧ code e606396398934 = 9402489421142 := by decide
theorem cert_e606396398934 : check e606396398934 [[.under]] .sourceHead = true := by decide
def e606396398938 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e606396398938 : Closed e606396398938 ∧ code e606396398938 = 9402489421146 := by decide
theorem cert_e606396398938 : check e606396398938 [[.under]] .sourceHead = true := by decide
def e606396398954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e606396398954 : Closed e606396398954 ∧ code e606396398954 = 9402489421162 := by decide
theorem cert_e606396398954 : check e606396398954 [[.under]] .sourceHead = true := by decide
def e606396399018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e606396399018 : Closed e606396399018 ∧ code e606396399018 = 9402489421226 := by decide
theorem cert_e606396399018 : check e606396399018 [[.under]] .sourceHead = true := by decide
def e606396401518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2))))))))
theorem wire_e606396401518 : Closed e606396401518 ∧ code e606396401518 = 9402489423726 := by decide
theorem cert_e606396401518 : check e606396401518 [[.under]] .sourceHead = true := by decide
def e606396401526 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1))))))))
theorem wire_e606396401526 : Closed e606396401526 ∧ code e606396401526 = 9402489423734 := by decide
theorem cert_e606396401526 : check e606396401526 [[.under]] .sourceHead = true := by decide
def e606396401590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1))))))))
theorem wire_e606396401590 : Closed e606396401590 ∧ code e606396401590 = 9402489423798 := by decide
theorem cert_e606396401590 : check e606396401590 [[.under]] .sourceHead = true := by decide
def e606396403054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e606396403054 : Closed e606396403054 ∧ code e606396403054 = 9402489425262 := by decide
theorem cert_e606396403054 : check e606396403054 [[.under]] .sourceHead = true := by decide
def e606396403062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e606396403062 : Closed e606396403062 ∧ code e606396403062 = 9402489425270 := by decide
theorem cert_e606396403062 : check e606396403062 [[.under]] .sourceHead = true := by decide
def e606396403118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e606396403118 : Closed e606396403118 ∧ code e606396403118 = 9402489425326 := by decide
theorem cert_e606396403118 : check e606396403118 [[.under]] .sourceHead = true := by decide
def e606396403130 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e606396403130 : Closed e606396403130 ∧ code e606396403130 = 9402489425338 := by decide
theorem cert_e606396403130 : check e606396403130 [[.under]] .sourceHead = true := by decide
def e606396403158 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e606396403158 : Closed e606396403158 ∧ code e606396403158 = 9402489425366 := by decide
theorem cert_e606396403158 : check e606396403158 [[.under]] .sourceHead = true := by decide
def e606396403162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e606396403162 : Closed e606396403162 ∧ code e606396403162 = 9402489425370 := by decide
theorem cert_e606396403162 : check e606396403162 [[.under]] .sourceHead = true := by decide
def e606396403374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e606396403374 : Closed e606396403374 ∧ code e606396403374 = 9402489425582 := by decide
theorem cert_e606396403374 : check e606396403374 [[.under]] .sourceHead = true := by decide
def e606396403386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e606396403386 : Closed e606396403386 ∧ code e606396403386 = 9402489425594 := by decide
theorem cert_e606396403386 : check e606396403386 [[.under]] .sourceHead = true := by decide
def e606396403434 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e606396403434 : Closed e606396403434 ∧ code e606396403434 = 9402489425642 := by decide
theorem cert_e606396403434 : check e606396403434 [[.under]] .sourceHead = true := by decide
def e606396403542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e606396403542 : Closed e606396403542 ∧ code e606396403542 = 9402489425750 := by decide
theorem cert_e606396403542 : check e606396403542 [[.under]] .sourceHead = true := by decide
def e606396403546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e606396403546 : Closed e606396403546 ∧ code e606396403546 = 9402489425754 := by decide
theorem cert_e606396403546 : check e606396403546 [[.under]] .sourceHead = true := by decide
def e606396403562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e606396403562 : Closed e606396403562 ∧ code e606396403562 = 9402489425770 := by decide
theorem cert_e606396403562 : check e606396403562 [[.under]] .sourceHead = true := by decide
def e606396404590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e606396404590 : Closed e606396404590 ∧ code e606396404590 = 9402489426798 := by decide
theorem cert_e606396404590 : check e606396404590 [[.under]] .sourceHead = true := by decide
def e606396404598 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e606396404598 : Closed e606396404598 ∧ code e606396404598 = 9402489426806 := by decide
theorem cert_e606396404598 : check e606396404598 [[.under]] .sourceHead = true := by decide
def e606396404654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e606396404654 : Closed e606396404654 ∧ code e606396404654 = 9402489426862 := by decide
theorem cert_e606396404654 : check e606396404654 [[.under]] .sourceHead = true := by decide
def e606396404666 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e606396404666 : Closed e606396404666 ∧ code e606396404666 = 9402489426874 := by decide
theorem cert_e606396404666 : check e606396404666 [[.under]] .sourceHead = true := by decide
def e606396404694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e606396404694 : Closed e606396404694 ∧ code e606396404694 = 9402489426902 := by decide
theorem cert_e606396404694 : check e606396404694 [[.under]] .sourceHead = true := by decide
def e606396404698 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e606396404698 : Closed e606396404698 ∧ code e606396404698 = 9402489426906 := by decide
theorem cert_e606396404698 : check e606396404698 [[.under]] .sourceHead = true := by decide
def e606396404974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e606396404974 : Closed e606396404974 ∧ code e606396404974 = 9402489427182 := by decide
theorem cert_e606396404974 : check e606396404974 [[.under]] .sourceHead = true := by decide
def e606396404982 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e606396404982 : Closed e606396404982 ∧ code e606396404982 = 9402489427190 := by decide
theorem cert_e606396404982 : check e606396404982 [[.under]] .sourceHead = true := by decide
def e606396405358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e606396405358 : Closed e606396405358 ∧ code e606396405358 = 9402489427566 := by decide
theorem cert_e606396405358 : check e606396405358 [[.under]] .sourceHead = true := by decide
def e606396405370 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e606396405370 : Closed e606396405370 ∧ code e606396405370 = 9402489427578 := by decide
theorem cert_e606396405370 : check e606396405370 [[.under]] .sourceHead = true := by decide
def e606396405558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396405558 : Closed e606396405558 ∧ code e606396405558 = 9402489427766 := by decide
theorem cert_e606396405558 : check e606396405558 [[.under]] .sourceHead = true := by decide
def e606396405562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396405562 : Closed e606396405562 ∧ code e606396405562 = 9402489427770 := by decide
theorem cert_e606396405562 : check e606396405562 [[.under]] .sourceHead = true := by decide
def e606396405998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e606396405998 : Closed e606396405998 ∧ code e606396405998 = 9402489428206 := by decide
theorem cert_e606396405998 : check e606396405998 [[.under]] .sourceHead = true := by decide
def e606396406006 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e606396406006 : Closed e606396406006 ∧ code e606396406006 = 9402489428214 := by decide
theorem cert_e606396406006 : check e606396406006 [[.under]] .sourceHead = true := by decide
def e606396406190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e606396406190 : Closed e606396406190 ∧ code e606396406190 = 9402489428398 := by decide
theorem cert_e606396406190 : check e606396406190 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
