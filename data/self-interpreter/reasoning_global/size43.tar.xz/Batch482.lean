import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407450218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422407450218 : Closed e2422407450218 ∧ code e2422407450218 = 11218500472426 := by decide
theorem cert_e2422407450218 : check e2422407450218 [[],[]] .chain = true := by decide
def e2422407450254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407450254 : Closed e2422407450254 ∧ code e2422407450254 = 11218500472462 := by decide
theorem cert_e2422407450254 : check e2422407450254 [[],[]] .chain = true := by decide
def e2422407450266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407450266 : Closed e2422407450266 ∧ code e2422407450266 = 11218500472474 := by decide
theorem cert_e2422407450266 : check e2422407450266 [[],[]] .chain = true := by decide
def e2422407450310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407450310 : Closed e2422407450310 ∧ code e2422407450310 = 11218500472518 := by decide
theorem cert_e2422407450310 : check e2422407450310 [[],[]] .chain = true := by decide
def e2422407450862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407450862 : Closed e2422407450862 ∧ code e2422407450862 = 11218500473070 := by decide
theorem cert_e2422407450862 : check e2422407450862 [[],[]] .chain = true := by decide
def e2422407450870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407450870 : Closed e2422407450870 ∧ code e2422407450870 = 11218500473078 := by decide
theorem cert_e2422407450870 : check e2422407450870 [[],[]] .chain = true := by decide
def e2422407451350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407451350 : Closed e2422407451350 ∧ code e2422407451350 = 11218500473558 := by decide
theorem cert_e2422407451350 : check e2422407451350 [[],[]] .chain = true := by decide
def e2422407451354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407451354 : Closed e2422407451354 ∧ code e2422407451354 = 11218500473562 := by decide
theorem cert_e2422407451354 : check e2422407451354 [[],[]] .chain = true := by decide
def e2422407451370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407451370 : Closed e2422407451370 ∧ code e2422407451370 = 11218500473578 := by decide
theorem cert_e2422407451370 : check e2422407451370 [[],[]] .chain = true := by decide
def e2422407451446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407451446 : Closed e2422407451446 ∧ code e2422407451446 = 11218500473654 := by decide
theorem cert_e2422407451446 : check e2422407451446 [[],[]] .chain = true := by decide
def e2422407451450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407451450 : Closed e2422407451450 ∧ code e2422407451450 = 11218500473658 := by decide
theorem cert_e2422407451450 : check e2422407451450 [[],[]] .chain = true := by decide
def e2422407451534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2422407451534 : Closed e2422407451534 ∧ code e2422407451534 = 11218500473742 := by decide
theorem cert_e2422407451534 : check e2422407451534 [[],[]] .chain = true := by decide
def e2422407451546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407451546 : Closed e2422407451546 ∧ code e2422407451546 = 11218500473754 := by decide
theorem cert_e2422407451546 : check e2422407451546 [[],[]] .chain = true := by decide
def e2422407452790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2422407452790 : Closed e2422407452790 ∧ code e2422407452790 = 11218500474998 := by decide
theorem cert_e2422407452790 : check e2422407452790 [[],[]] .chain = true := by decide
def e2422407453034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2422407453034 : Closed e2422407453034 ∧ code e2422407453034 = 11218500475242 := by decide
theorem cert_e2422407453034 : check e2422407453034 [[],[]] .chain = true := by decide
def e2422407453070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407453070 : Closed e2422407453070 ∧ code e2422407453070 = 11218500475278 := by decide
theorem cert_e2422407453070 : check e2422407453070 [[],[]] .chain = true := by decide
def e2422407453082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407453082 : Closed e2422407453082 ∧ code e2422407453082 = 11218500475290 := by decide
theorem cert_e2422407453082 : check e2422407453082 [[],[]] .chain = true := by decide
def e2422407453126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407453126 : Closed e2422407453126 ∧ code e2422407453126 = 11218500475334 := by decide
theorem cert_e2422407453126 : check e2422407453126 [[],[]] .chain = true := by decide
def e2422407454966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.lam (.var 3)))) (.var 1))))))
theorem wire_e2422407454966 : Closed e2422407454966 ∧ code e2422407454966 = 11218500477174 := by decide
theorem cert_e2422407454966 : check e2422407454966 [[],[]] .chain = true := by decide
def e2422407455158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2422407455158 : Closed e2422407455158 ∧ code e2422407455158 = 11218500477366 := by decide
theorem cert_e2422407455158 : check e2422407455158 [[],[]] .chain = true := by decide
def e2422407455162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407455162 : Closed e2422407455162 ∧ code e2422407455162 = 11218500477370 := by decide
theorem cert_e2422407455162 : check e2422407455162 [[],[]] .chain = true := by decide
def e2422407455190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2422407455190 : Closed e2422407455190 ∧ code e2422407455190 = 11218500477398 := by decide
theorem cert_e2422407455190 : check e2422407455190 [[],[]] .chain = true := by decide
def e2422407455210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407455210 : Closed e2422407455210 ∧ code e2422407455210 = 11218500477418 := by decide
theorem cert_e2422407455210 : check e2422407455210 [[],[]] .chain = true := by decide
def e2422407455350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407455350 : Closed e2422407455350 ∧ code e2422407455350 = 11218500477558 := by decide
theorem cert_e2422407455350 : check e2422407455350 [[],[]] .chain = true := by decide
def e2422407455542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407455542 : Closed e2422407455542 ∧ code e2422407455542 = 11218500477750 := by decide
theorem cert_e2422407455542 : check e2422407455542 [[],[]] .chain = true := by decide
def e2422407455546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407455546 : Closed e2422407455546 ∧ code e2422407455546 = 11218500477754 := by decide
theorem cert_e2422407455546 : check e2422407455546 [[],[]] .chain = true := by decide
def e2422407455630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.lam (.var 2)))))))
theorem wire_e2422407455630 : Closed e2422407455630 ∧ code e2422407455630 = 11218500477838 := by decide
theorem cert_e2422407455630 : check e2422407455630 [[],[]] .chain = true := by decide
def e2422407455642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407455642 : Closed e2422407455642 ∧ code e2422407455642 = 11218500477850 := by decide
theorem cert_e2422407455642 : check e2422407455642 [[],[]] .chain = true := by decide
def e2422407456310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407456310 : Closed e2422407456310 ∧ code e2422407456310 = 11218500478518 := by decide
theorem cert_e2422407456310 : check e2422407456310 [[],[]] .chain = true := by decide
def e2422407456314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407456314 : Closed e2422407456314 ∧ code e2422407456314 = 11218500478522 := by decide
theorem cert_e2422407456314 : check e2422407456314 [[],[]] .chain = true := by decide
def e2422407456398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422407456398 : Closed e2422407456398 ∧ code e2422407456398 = 11218500478606 := by decide
theorem cert_e2422407456398 : check e2422407456398 [[],[]] .chain = true := by decide
def e2422407456454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422407456454 : Closed e2422407456454 ∧ code e2422407456454 = 11218500478662 := by decide
theorem cert_e2422407456454 : check e2422407456454 [[],[]] .chain = true := by decide
def e2422407456534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407456534 : Closed e2422407456534 ∧ code e2422407456534 = 11218500478742 := by decide
theorem cert_e2422407456534 : check e2422407456534 [[],[]] .chain = true := by decide
def e2422407456538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422407456538 : Closed e2422407456538 ∧ code e2422407456538 = 11218500478746 := by decide
theorem cert_e2422407456538 : check e2422407456538 [[],[]] .chain = true := by decide
def e2422407456582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422407456582 : Closed e2422407456582 ∧ code e2422407456582 = 11218500478790 := by decide
theorem cert_e2422407456582 : check e2422407456582 [[],[]] .chain = true := by decide
def e2422407456610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407456610 : Closed e2422407456610 ∧ code e2422407456610 = 11218500478818 := by decide
theorem cert_e2422407456610 : check e2422407456610 [[],[]] .chain = true := by decide
def e2422407456622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422407456622 : Closed e2422407456622 ∧ code e2422407456622 = 11218500478830 := by decide
theorem cert_e2422407456622 : check e2422407456622 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407456630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422407456630 : Closed e2422407456630 ∧ code e2422407456630 = 11218500478838 := by decide
theorem cert_e2422407456630 : check e2422407456630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left]] .identityHead = true := by decide
def e2422407456694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422407456694 : Closed e2422407456694 ∧ code e2422407456694 = 11218500478902 := by decide
theorem cert_e2422407456694 : check e2422407456694 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407456878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422407456878 : Closed e2422407456878 ∧ code e2422407456878 = 11218500479086 := by decide
theorem cert_e2422407456878 : check e2422407456878 [[],[]] .chain = true := by decide
def e2422407456890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422407456890 : Closed e2422407456890 ∧ code e2422407456890 = 11218500479098 := by decide
theorem cert_e2422407456890 : check e2422407456890 [[],[]] .chain = true := by decide
def e2422407457166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407457166 : Closed e2422407457166 ∧ code e2422407457166 = 11218500479374 := by decide
theorem cert_e2422407457166 : check e2422407457166 [[],[]] .chain = true := by decide
def e2422407457222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407457222 : Closed e2422407457222 ∧ code e2422407457222 = 11218500479430 := by decide
theorem cert_e2422407457222 : check e2422407457222 [[],[]] .chain = true := by decide
def e2422407457822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.lam (.var 3))))))))
theorem wire_e2422407457822 : Closed e2422407457822 ∧ code e2422407457822 = 11218500480030 := by decide
theorem cert_e2422407457822 : check e2422407457822 [[],[]] .chain = true := by decide
def e2422407457846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407457846 : Closed e2422407457846 ∧ code e2422407457846 = 11218500480054 := by decide
theorem cert_e2422407457846 : check e2422407457846 [[],[]] .chain = true := by decide
def e2422407457850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407457850 : Closed e2422407457850 ∧ code e2422407457850 = 11218500480058 := by decide
theorem cert_e2422407457850 : check e2422407457850 [[],[]] .chain = true := by decide
def e2422407457990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407457990 : Closed e2422407457990 ∧ code e2422407457990 = 11218500480198 := by decide
theorem cert_e2422407457990 : check e2422407457990 [[],[]] .chain = true := by decide
def e2422407458018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407458018 : Closed e2422407458018 ∧ code e2422407458018 = 11218500480226 := by decide
theorem cert_e2422407458018 : check e2422407458018 [[],[]] .chain = true := by decide
def e2422407458030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407458030 : Closed e2422407458030 ∧ code e2422407458030 = 11218500480238 := by decide
theorem cert_e2422407458030 : check e2422407458030 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407458038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407458038 : Closed e2422407458038 ∧ code e2422407458038 = 11218500480246 := by decide
theorem cert_e2422407458038 : check e2422407458038 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407458422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407458422 : Closed e2422407458422 ∧ code e2422407458422 = 11218500480630 := by decide
theorem cert_e2422407458422 : check e2422407458422 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407458934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422407458934 : Closed e2422407458934 ∧ code e2422407458934 = 11218500481142 := by decide
theorem cert_e2422407458934 : check e2422407458934 [[],[]] .chain = true := by decide
def e2422407458938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407458938 : Closed e2422407458938 ∧ code e2422407458938 = 11218500481146 := by decide
theorem cert_e2422407458938 : check e2422407458938 [[],[]] .chain = true := by decide
def e2422407459034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407459034 : Closed e2422407459034 ∧ code e2422407459034 = 11218500481242 := by decide
theorem cert_e2422407459034 : check e2422407459034 [[],[]] .chain = true := by decide
def e2422407459050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407459050 : Closed e2422407459050 ∧ code e2422407459050 = 11218500481258 := by decide
theorem cert_e2422407459050 : check e2422407459050 [[],[]] .chain = true := by decide
def e2422407459126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407459126 : Closed e2422407459126 ∧ code e2422407459126 = 11218500481334 := by decide
theorem cert_e2422407459126 : check e2422407459126 [[],[]] .chain = true := by decide
def e2422407459130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407459130 : Closed e2422407459130 ∧ code e2422407459130 = 11218500481338 := by decide
theorem cert_e2422407459130 : check e2422407459130 [[],[]] .chain = true := by decide
def e2422407459214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422407459214 : Closed e2422407459214 ∧ code e2422407459214 = 11218500481422 := by decide
theorem cert_e2422407459214 : check e2422407459214 [[],[]] .chain = true := by decide
def e2422407459226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407459226 : Closed e2422407459226 ∧ code e2422407459226 = 11218500481434 := by decide
theorem cert_e2422407459226 : check e2422407459226 [[],[]] .chain = true := by decide
def e2422407459270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407459270 : Closed e2422407459270 ∧ code e2422407459270 = 11218500481478 := by decide
theorem cert_e2422407459270 : check e2422407459270 [[],[]] .chain = true := by decide
def e2422407459606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407459606 : Closed e2422407459606 ∧ code e2422407459606 = 11218500481814 := by decide
theorem cert_e2422407459606 : check e2422407459606 [[],[]] .chain = true := by decide
def e2422407459610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422407459610 : Closed e2422407459610 ∧ code e2422407459610 = 11218500481818 := by decide
theorem cert_e2422407459610 : check e2422407459610 [[],[]] .chain = true := by decide
def e2422407459654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422407459654 : Closed e2422407459654 ∧ code e2422407459654 = 11218500481862 := by decide
theorem cert_e2422407459654 : check e2422407459654 [[],[]] .chain = true := by decide
def e2422407459682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407459682 : Closed e2422407459682 ∧ code e2422407459682 = 11218500481890 := by decide
theorem cert_e2422407459682 : check e2422407459682 [[],[]] .chain = true := by decide
def e2422407459694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422407459694 : Closed e2422407459694 ∧ code e2422407459694 = 11218500481902 := by decide
theorem cert_e2422407459694 : check e2422407459694 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407459702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422407459702 : Closed e2422407459702 ∧ code e2422407459702 = 11218500481910 := by decide
theorem cert_e2422407459702 : check e2422407459702 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407459722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407459722 : Closed e2422407459722 ∧ code e2422407459722 = 11218500481930 := by decide
theorem cert_e2422407459722 : check e2422407459722 [[],[]] .chain = true := by decide
def e2422407459746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407459746 : Closed e2422407459746 ∧ code e2422407459746 = 11218500481954 := by decide
theorem cert_e2422407459746 : check e2422407459746 [[],[]] .chain = true := by decide
def e2422407459758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422407459758 : Closed e2422407459758 ∧ code e2422407459758 = 11218500481966 := by decide
theorem cert_e2422407459758 : check e2422407459758 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407459770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422407459770 : Closed e2422407459770 ∧ code e2422407459770 = 11218500481978 := by decide
theorem cert_e2422407459770 : check e2422407459770 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407459798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422407459798 : Closed e2422407459798 ∧ code e2422407459798 = 11218500482006 := by decide
theorem cert_e2422407459798 : check e2422407459798 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407459802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422407459802 : Closed e2422407459802 ∧ code e2422407459802 = 11218500482010 := by decide
theorem cert_e2422407459802 : check e2422407459802 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407459870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422407459870 : Closed e2422407459870 ∧ code e2422407459870 = 11218500482078 := by decide
theorem cert_e2422407459870 : check e2422407459870 [[],[]] .chain = true := by decide
def e2422407459894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407459894 : Closed e2422407459894 ∧ code e2422407459894 = 11218500482102 := by decide
theorem cert_e2422407459894 : check e2422407459894 [[],[]] .chain = true := by decide
def e2422407459898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407459898 : Closed e2422407459898 ∧ code e2422407459898 = 11218500482106 := by decide
theorem cert_e2422407459898 : check e2422407459898 [[],[]] .chain = true := by decide
def e2422407460038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407460038 : Closed e2422407460038 ∧ code e2422407460038 = 11218500482246 := by decide
theorem cert_e2422407460038 : check e2422407460038 [[],[]] .chain = true := by decide
def e2422407460066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407460066 : Closed e2422407460066 ∧ code e2422407460066 = 11218500482274 := by decide
theorem cert_e2422407460066 : check e2422407460066 [[],[]] .chain = true := by decide
def e2422407460078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407460078 : Closed e2422407460078 ∧ code e2422407460078 = 11218500482286 := by decide
theorem cert_e2422407460078 : check e2422407460078 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407460086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407460086 : Closed e2422407460086 ∧ code e2422407460086 = 11218500482294 := by decide
theorem cert_e2422407460086 : check e2422407460086 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407460366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407460366 : Closed e2422407460366 ∧ code e2422407460366 = 11218500482574 := by decide
theorem cert_e2422407460366 : check e2422407460366 [[],[]] .chain = true := by decide
def e2422407460450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407460450 : Closed e2422407460450 ∧ code e2422407460450 = 11218500482658 := by decide
theorem cert_e2422407460450 : check e2422407460450 [[],[]] .chain = true := by decide
def e2422407460462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407460462 : Closed e2422407460462 ∧ code e2422407460462 = 11218500482670 := by decide
theorem cert_e2422407460462 : check e2422407460462 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407460474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407460474 : Closed e2422407460474 ∧ code e2422407460474 = 11218500482682 := by decide
theorem cert_e2422407460474 : check e2422407460474 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407460662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407460662 : Closed e2422407460662 ∧ code e2422407460662 = 11218500482870 := by decide
theorem cert_e2422407460662 : check e2422407460662 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407460666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407460666 : Closed e2422407460666 ∧ code e2422407460666 = 11218500482874 := by decide
theorem cert_e2422407460666 : check e2422407460666 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407461302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422407461302 : Closed e2422407461302 ∧ code e2422407461302 = 11218500483510 := by decide
theorem cert_e2422407461302 : check e2422407461302 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407461334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422407461334 : Closed e2422407461334 ∧ code e2422407461334 = 11218500483542 := by decide
theorem cert_e2422407461334 : check e2422407461334 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407461338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422407461338 : Closed e2422407461338 ∧ code e2422407461338 = 11218500483546 := by decide
theorem cert_e2422407461338 : check e2422407461338 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407461494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407461494 : Closed e2422407461494 ∧ code e2422407461494 = 11218500483702 := by decide
theorem cert_e2422407461494 : check e2422407461494 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407461686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407461686 : Closed e2422407461686 ∧ code e2422407461686 = 11218500483894 := by decide
theorem cert_e2422407461686 : check e2422407461686 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407461690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 3))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407461690 : Closed e2422407461690 ∧ code e2422407461690 = 11218500483898 := by decide
theorem cert_e2422407461690 : check e2422407461690 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407475542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422407475542 : Closed e2422407475542 ∧ code e2422407475542 = 11218500497750 := by decide
theorem cert_e2422407475542 : check e2422407475542 [[],[]] .chain = true := by decide
def e2422407475546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422407475546 : Closed e2422407475546 ∧ code e2422407475546 = 11218500497754 := by decide
theorem cert_e2422407475546 : check e2422407475546 [[],[]] .chain = true := by decide
def e2422407475562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422407475562 : Closed e2422407475562 ∧ code e2422407475562 = 11218500497770 := by decide
theorem cert_e2422407475562 : check e2422407475562 [[],[]] .chain = true := by decide
def e2422407476310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422407476310 : Closed e2422407476310 ∧ code e2422407476310 = 11218500498518 := by decide
theorem cert_e2422407476310 : check e2422407476310 [[],[]] .chain = true := by decide
def e2422407476314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422407476314 : Closed e2422407476314 ∧ code e2422407476314 = 11218500498522 := by decide
theorem cert_e2422407476314 : check e2422407476314 [[],[]] .chain = true := by decide
def e2422407476502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422407476502 : Closed e2422407476502 ∧ code e2422407476502 = 11218500498710 := by decide
theorem cert_e2422407476502 : check e2422407476502 [[],[]] .chain = true := by decide
def e2422407476578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422407476578 : Closed e2422407476578 ∧ code e2422407476578 = 11218500498786 := by decide
theorem cert_e2422407476578 : check e2422407476578 [[],[]] .chain = true := by decide
def e2422407476590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422407476590 : Closed e2422407476590 ∧ code e2422407476590 = 11218500498798 := by decide
def e2422407476598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422407476598 : Closed e2422407476598 ∧ code e2422407476598 = 11218500498806 := by decide
theorem cert_e2422407476598 : check e2422407476598 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407476618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407476618 : Closed e2422407476618 ∧ code e2422407476618 = 11218500498826 := by decide
theorem cert_e2422407476618 : check e2422407476618 [[],[]] .chain = true := by decide
def e2422407476642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407476642 : Closed e2422407476642 ∧ code e2422407476642 = 11218500498850 := by decide
theorem cert_e2422407476642 : check e2422407476642 [[],[]] .chain = true := by decide
def e2422407476654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422407476654 : Closed e2422407476654 ∧ code e2422407476654 = 11218500498862 := by decide
def e2422407476662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422407476662 : Closed e2422407476662 ∧ code e2422407476662 = 11218500498870 := by decide
theorem cert_e2422407476662 : check e2422407476662 [[],[]] .chain = true := by decide
def e2422407476666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422407476666 : Closed e2422407476666 ∧ code e2422407476666 = 11218500498874 := by decide
theorem cert_e2422407476666 : check e2422407476666 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407476694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422407476694 : Closed e2422407476694 ∧ code e2422407476694 = 11218500498902 := by decide
theorem cert_e2422407476694 : check e2422407476694 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422407476698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422407476698 : Closed e2422407476698 ∧ code e2422407476698 = 11218500498906 := by decide
theorem cert_e2422407476698 : check e2422407476698 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422407476778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422407476778 : Closed e2422407476778 ∧ code e2422407476778 = 11218500498986 := by decide
theorem cert_e2422407476778 : check e2422407476778 [[],[]] .chain = true := by decide
def e2422407476874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407476874 : Closed e2422407476874 ∧ code e2422407476874 = 11218500499082 := by decide
theorem cert_e2422407476874 : check e2422407476874 [[],[]] .chain = true := by decide
def e2422407476898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407476898 : Closed e2422407476898 ∧ code e2422407476898 = 11218500499106 := by decide
theorem cert_e2422407476898 : check e2422407476898 [[],[]] .chain = true := by decide
def e2422407476910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422407476910 : Closed e2422407476910 ∧ code e2422407476910 = 11218500499118 := by decide
theorem cert_e2422407476910 : check e2422407476910 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407476918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422407476918 : Closed e2422407476918 ∧ code e2422407476918 = 11218500499126 := by decide
theorem cert_e2422407476918 : check e2422407476918 [[],[]] .chain = true := by decide
def e2422407476922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422407476922 : Closed e2422407476922 ∧ code e2422407476922 = 11218500499130 := by decide
theorem cert_e2422407476922 : check e2422407476922 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407476950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422407476950 : Closed e2422407476950 ∧ code e2422407476950 = 11218500499158 := by decide
theorem cert_e2422407476950 : check e2422407476950 [[],[]] .chain = true := by decide
def e2422407476954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422407476954 : Closed e2422407476954 ∧ code e2422407476954 = 11218500499162 := by decide
theorem cert_e2422407476954 : check e2422407476954 [[],[]] .chain = true := by decide
def e2422407476970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422407476970 : Closed e2422407476970 ∧ code e2422407476970 = 11218500499178 := by decide
theorem cert_e2422407476970 : check e2422407476970 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407477078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422407477078 : Closed e2422407477078 ∧ code e2422407477078 = 11218500499286 := by decide
theorem cert_e2422407477078 : check e2422407477078 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422407477082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422407477082 : Closed e2422407477082 ∧ code e2422407477082 = 11218500499290 := by decide
def e2422407477098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422407477098 : Closed e2422407477098 ∧ code e2422407477098 = 11218500499306 := by decide
theorem cert_e2422407477098 : check e2422407477098 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422407477418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422407477418 : Closed e2422407477418 ∧ code e2422407477418 = 11218500499626 := by decide
theorem cert_e2422407477418 : check e2422407477418 [[],[]] .chain = true := by decide
def e2422407477802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422407477802 : Closed e2422407477802 ∧ code e2422407477802 = 11218500500010 := by decide
theorem cert_e2422407477802 : check e2422407477802 [[],[]] .chain = true := by decide
def e2422407477898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407477898 : Closed e2422407477898 ∧ code e2422407477898 = 11218500500106 := by decide
theorem cert_e2422407477898 : check e2422407477898 [[],[]] .chain = true := by decide
def e2422407477922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407477922 : Closed e2422407477922 ∧ code e2422407477922 = 11218500500130 := by decide
theorem cert_e2422407477922 : check e2422407477922 [[],[]] .chain = true := by decide
def e2422407477934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422407477934 : Closed e2422407477934 ∧ code e2422407477934 = 11218500500142 := by decide
theorem cert_e2422407477934 : check e2422407477934 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407477942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422407477942 : Closed e2422407477942 ∧ code e2422407477942 = 11218500500150 := by decide
theorem cert_e2422407477942 : check e2422407477942 [[],[]] .chain = true := by decide
def e2422407477946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422407477946 : Closed e2422407477946 ∧ code e2422407477946 = 11218500500154 := by decide
theorem cert_e2422407477946 : check e2422407477946 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407477974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422407477974 : Closed e2422407477974 ∧ code e2422407477974 = 11218500500182 := by decide
theorem cert_e2422407477974 : check e2422407477974 [[],[]] .chain = true := by decide
def e2422407477978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422407477978 : Closed e2422407477978 ∧ code e2422407477978 = 11218500500186 := by decide
theorem cert_e2422407477978 : check e2422407477978 [[],[]] .chain = true := by decide
def e2422407477994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422407477994 : Closed e2422407477994 ∧ code e2422407477994 = 11218500500202 := by decide
theorem cert_e2422407477994 : check e2422407477994 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407478102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422407478102 : Closed e2422407478102 ∧ code e2422407478102 = 11218500500310 := by decide
theorem cert_e2422407478102 : check e2422407478102 [[],[]] .chain = true := by decide
def e2422407478106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422407478106 : Closed e2422407478106 ∧ code e2422407478106 = 11218500500314 := by decide
theorem cert_e2422407478106 : check e2422407478106 [[],[]] .chain = true := by decide
def e2422407478122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422407478122 : Closed e2422407478122 ∧ code e2422407478122 = 11218500500330 := by decide
theorem cert_e2422407478122 : check e2422407478122 [[],[]] .chain = true := by decide
def e2422407478186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422407478186 : Closed e2422407478186 ∧ code e2422407478186 = 11218500500394 := by decide
theorem cert_e2422407478186 : check e2422407478186 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2422407478614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422407478614 : Closed e2422407478614 ∧ code e2422407478614 = 11218500500822 := by decide
def e2422407478618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422407478618 : Closed e2422407478618 ∧ code e2422407478618 = 11218500500826 := by decide
def e2422407478634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422407478634 : Closed e2422407478634 ∧ code e2422407478634 = 11218500500842 := by decide
def e2422407478698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422407478698 : Closed e2422407478698 ∧ code e2422407478698 = 11218500500906 := by decide
theorem cert_e2422407478698 : check e2422407478698 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2422407479382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 0)) (.var 1))))))
theorem wire_e2422407479382 : Closed e2422407479382 ∧ code e2422407479382 = 11218500501590 := by decide
theorem cert_e2422407479382 : check e2422407479382 [[],[]] .chain = true := by decide
def e2422407479386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.var 0))))))
theorem wire_e2422407479386 : Closed e2422407479386 ∧ code e2422407479386 = 11218500501594 := by decide
theorem cert_e2422407479386 : check e2422407479386 [[],[]] .chain = true := by decide
def e2422407479662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422407479662 : Closed e2422407479662 ∧ code e2422407479662 = 11218500501870 := by decide
theorem cert_e2422407479662 : check e2422407479662 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407479670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422407479670 : Closed e2422407479670 ∧ code e2422407479670 = 11218500501878 := by decide
theorem cert_e2422407479670 : check e2422407479670 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407479734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 1)) (.var 1))))))
theorem wire_e2422407479734 : Closed e2422407479734 ∧ code e2422407479734 = 11218500501942 := by decide
theorem cert_e2422407479734 : check e2422407479734 [[],[]] .chain = true := by decide
def e2422407479766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 0)) (.var 1))))))
theorem wire_e2422407479766 : Closed e2422407479766 ∧ code e2422407479766 = 11218500501974 := by decide
theorem cert_e2422407479766 : check e2422407479766 [[],[]] .chain = true := by decide
def e2422407479770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1)) (.var 0))))))
theorem wire_e2422407479770 : Closed e2422407479770 ∧ code e2422407479770 = 11218500501978 := by decide
theorem cert_e2422407479770 : check e2422407479770 [[],[]] .chain = true := by decide
def e2422407479786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0)) (.var 0))))))
theorem wire_e2422407479786 : Closed e2422407479786 ∧ code e2422407479786 = 11218500501994 := by decide
theorem cert_e2422407479786 : check e2422407479786 [[],[]] .chain = true := by decide
def e2422407480150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422407480150 : Closed e2422407480150 ∧ code e2422407480150 = 11218500502358 := by decide
theorem cert_e2422407480150 : check e2422407480150 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407480154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422407480154 : Closed e2422407480154 ∧ code e2422407480154 = 11218500502362 := by decide
theorem cert_e2422407480154 : check e2422407480154 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407480438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422407480438 : Closed e2422407480438 ∧ code e2422407480438 = 11218500502646 := by decide
theorem cert_e2422407480438 : check e2422407480438 [[],[]] .chain = true := by decide
def e2422407480534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407480534 : Closed e2422407480534 ∧ code e2422407480534 = 11218500502742 := by decide
theorem cert_e2422407480534 : check e2422407480534 [[],[]] .chain = true := by decide
def e2422407480538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407480538 : Closed e2422407480538 ∧ code e2422407480538 = 11218500502746 := by decide
theorem cert_e2422407480538 : check e2422407480538 [[],[]] .chain = true := by decide
def e2422407480554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407480554 : Closed e2422407480554 ∧ code e2422407480554 = 11218500502762 := by decide
theorem cert_e2422407480554 : check e2422407480554 [[],[]] .chain = true := by decide
def e2422407480630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407480630 : Closed e2422407480630 ∧ code e2422407480630 = 11218500502838 := by decide
theorem cert_e2422407480630 : check e2422407480630 [[],[]] .chain = true := by decide
def e2422407480634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407480634 : Closed e2422407480634 ∧ code e2422407480634 = 11218500502842 := by decide
theorem cert_e2422407480634 : check e2422407480634 [[],[]] .chain = true := by decide
def e2422407480718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422407480718 : Closed e2422407480718 ∧ code e2422407480718 = 11218500502926 := by decide
theorem cert_e2422407480718 : check e2422407480718 [[],[]] .chain = true := by decide
def e2422407480730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407480730 : Closed e2422407480730 ∧ code e2422407480730 = 11218500502938 := by decide
theorem cert_e2422407480730 : check e2422407480730 [[],[]] .chain = true := by decide
def e2422407480886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407480886 : Closed e2422407480886 ∧ code e2422407480886 = 11218500503094 := by decide
theorem cert_e2422407480886 : check e2422407480886 [[],[]] .chain = true := by decide
def e2422407480890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407480890 : Closed e2422407480890 ∧ code e2422407480890 = 11218500503098 := by decide
theorem cert_e2422407480890 : check e2422407480890 [[],[]] .chain = true := by decide
def e2422407480974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407480974 : Closed e2422407480974 ∧ code e2422407480974 = 11218500503182 := by decide
theorem cert_e2422407480974 : check e2422407480974 [[],[]] .chain = true := by decide
def e2422407481030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407481030 : Closed e2422407481030 ∧ code e2422407481030 = 11218500503238 := by decide
theorem cert_e2422407481030 : check e2422407481030 [[],[]] .chain = true := by decide
def e2422407481110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422407481110 : Closed e2422407481110 ∧ code e2422407481110 = 11218500503318 := by decide
theorem cert_e2422407481110 : check e2422407481110 [[],[]] .chain = true := by decide
end Blc.Floor43
