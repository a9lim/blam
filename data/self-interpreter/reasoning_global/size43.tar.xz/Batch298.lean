import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411626127198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 3))))))))
theorem wire_e2411626127198 : Closed e2411626127198 ∧ code e2411626127198 = 11207719149406 := by decide
theorem cert_e2411626127198 : check e2411626127198 [[],[]] .three = true := by decide
def e2411626127214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2411626127214 : Closed e2411626127214 ∧ code e2411626127214 = 11207719149422 := by decide
theorem cert_e2411626127214 : check e2411626127214 [[],[]] .three = true := by decide
def e2411626127222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2411626127222 : Closed e2411626127222 ∧ code e2411626127222 = 11207719149430 := by decide
theorem cert_e2411626127222 : check e2411626127222 [[],[]] .three = true := by decide
def e2411626127226 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 3)) (.var 0))))))))
theorem wire_e2411626127226 : Closed e2411626127226 ∧ code e2411626127226 = 11207719149434 := by decide
theorem cert_e2411626127226 : check e2411626127226 [[],[]] .three = true := by decide
def e2411626127854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2411626127854 : Closed e2411626127854 ∧ code e2411626127854 = 11207719150062 := by decide
theorem cert_e2411626127854 : check e2411626127854 [[],[]] .smaller = true := by decide
def e2411626128822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2411626128822 : Closed e2411626128822 ∧ code e2411626128822 = 11207719151030 := by decide
theorem cert_e2411626128822 : check e2411626128822 [[],[]] .smaller = true := by decide
def e2411626128854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2411626128854 : Closed e2411626128854 ∧ code e2411626128854 = 11207719151062 := by decide
theorem cert_e2411626128854 : check e2411626128854 [[],[]] .smaller = true := by decide
def e2411626128858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2411626128858 : Closed e2411626128858 ∧ code e2411626128858 = 11207719151066 := by decide
theorem cert_e2411626128858 : check e2411626128858 [[],[]] .smaller = true := by decide
def e2411626128958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2411626128958 : Closed e2411626128958 ∧ code e2411626128958 = 11207719151166 := by decide
theorem cert_e2411626128958 : check e2411626128958 [[],[]] .three = true := by decide
def e2411626129014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2411626129014 : Closed e2411626129014 ∧ code e2411626129014 = 11207719151222 := by decide
theorem cert_e2411626129014 : check e2411626129014 [[],[]] .smaller = true := by decide
def e2411626129182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411626129182 : Closed e2411626129182 ∧ code e2411626129182 = 11207719151390 := by decide
theorem cert_e2411626129182 : check e2411626129182 [[],[]] .smaller = true := by decide
def e2411626129206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411626129206 : Closed e2411626129206 ∧ code e2411626129206 = 11207719151414 := by decide
theorem cert_e2411626129206 : check e2411626129206 [[],[]] .smaller = true := by decide
def e2411626129210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411626129210 : Closed e2411626129210 ∧ code e2411626129210 = 11207719151418 := by decide
theorem cert_e2411626129210 : check e2411626129210 [[],[]] .smaller = true := by decide
def e2411626129294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411626129294 : Closed e2411626129294 ∧ code e2411626129294 = 11207719151502 := by decide
theorem cert_e2411626129294 : check e2411626129294 [[],[]] .smaller = true := by decide
def e2411626129350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2411626129350 : Closed e2411626129350 ∧ code e2411626129350 = 11207719151558 := by decide
theorem cert_e2411626129350 : check e2411626129350 [[],[]] .three = true := by decide
def e2411626129374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 3)))))))))
theorem wire_e2411626129374 : Closed e2411626129374 ∧ code e2411626129374 = 11207719151582 := by decide
theorem cert_e2411626129374 : check e2411626129374 [[],[]] .three = true := by decide
def e2411626131694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2411626131694 : Closed e2411626131694 ∧ code e2411626131694 = 11207719153902 := by decide
theorem cert_e2411626131694 : check e2411626131694 [[],[]] .smaller = true := by decide
def e2411626131702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2411626131702 : Closed e2411626131702 ∧ code e2411626131702 = 11207719153910 := by decide
theorem cert_e2411626131702 : check e2411626131702 [[],[]] .smaller = true := by decide
def e2411626132182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411626132182 : Closed e2411626132182 ∧ code e2411626132182 = 11207719154390 := by decide
theorem cert_e2411626132182 : check e2411626132182 [[],[]] .smaller = true := by decide
def e2411626132186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411626132186 : Closed e2411626132186 ∧ code e2411626132186 = 11207719154394 := by decide
theorem cert_e2411626132186 : check e2411626132186 [[],[]] .smaller = true := by decide
def e2411626132202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411626132202 : Closed e2411626132202 ∧ code e2411626132202 = 11207719154410 := by decide
theorem cert_e2411626132202 : check e2411626132202 [[],[]] .smaller = true := by decide
def e2411626132254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411626132254 : Closed e2411626132254 ∧ code e2411626132254 = 11207719154462 := by decide
theorem cert_e2411626132254 : check e2411626132254 [[],[]] .smaller = true := by decide
def e2411626132278 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411626132278 : Closed e2411626132278 ∧ code e2411626132278 = 11207719154486 := by decide
theorem cert_e2411626132278 : check e2411626132278 [[],[]] .smaller = true := by decide
def e2411626132282 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411626132282 : Closed e2411626132282 ∧ code e2411626132282 = 11207719154490 := by decide
theorem cert_e2411626132282 : check e2411626132282 [[],[]] .smaller = true := by decide
def e2411626132378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411626132378 : Closed e2411626132378 ∧ code e2411626132378 = 11207719154586 := by decide
theorem cert_e2411626132378 : check e2411626132378 [[],[]] .smaller = true := by decide
def e2411626132422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411626132422 : Closed e2411626132422 ∧ code e2411626132422 = 11207719154630 := by decide
theorem cert_e2411626132422 : check e2411626132422 [[],[]] .smaller = true := by decide
def e2411626132446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2411626132446 : Closed e2411626132446 ∧ code e2411626132446 = 11207719154654 := by decide
theorem cert_e2411626132446 : check e2411626132446 [[],[]] .three = true := by decide
def e2411626132462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2411626132462 : Closed e2411626132462 ∧ code e2411626132462 = 11207719154670 := by decide
theorem cert_e2411626132462 : check e2411626132462 [[],[]] .three = true := by decide
def e2411626133902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411626133902 : Closed e2411626133902 ∧ code e2411626133902 = 11207719156110 := by decide
theorem cert_e2411626133902 : check e2411626133902 [[],[]] .smaller = true := by decide
def e2411626133958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411626133958 : Closed e2411626133958 ∧ code e2411626133958 = 11207719156166 := by decide
theorem cert_e2411626133958 : check e2411626133958 [[],[]] .smaller = true := by decide
def e2411626133982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411626133982 : Closed e2411626133982 ∧ code e2411626133982 = 11207719156190 := by decide
theorem cert_e2411626133982 : check e2411626133982 [[],[]] .three = true := by decide
def e2411626134006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411626134006 : Closed e2411626134006 ∧ code e2411626134006 = 11207719156214 := by decide
theorem cert_e2411626134006 : check e2411626134006 [[],[]] .three = true := by decide
def e2411626134726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411626134726 : Closed e2411626134726 ∧ code e2411626134726 = 11207719156934 := by decide
theorem cert_e2411626134726 : check e2411626134726 [[],[]] .three = true := by decide
def e2411626134750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411626134750 : Closed e2411626134750 ∧ code e2411626134750 = 11207719156958 := by decide
theorem cert_e2411626134750 : check e2411626134750 [[],[]] .three = true := by decide
def e2411626134766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411626134766 : Closed e2411626134766 ∧ code e2411626134766 = 11207719156974 := by decide
theorem cert_e2411626134766 : check e2411626134766 [[],[]] .three = true := by decide
def e2411626134774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411626134774 : Closed e2411626134774 ∧ code e2411626134774 = 11207719156982 := by decide
theorem cert_e2411626134774 : check e2411626134774 [[],[]] .three = true := by decide
def e2411626134778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411626134778 : Closed e2411626134778 ∧ code e2411626134778 = 11207719156986 := by decide
theorem cert_e2411626134778 : check e2411626134778 [[],[]] .three = true := by decide
def e2411626179414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2411626179414 : Closed e2411626179414 ∧ code e2411626179414 = 11207719201622 := by decide
theorem cert_e2411626179414 : check e2411626179414 [[],[]] .three = true := by decide
def e2411626179418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2411626179418 : Closed e2411626179418 ∧ code e2411626179418 = 11207719201626 := by decide
theorem cert_e2411626179418 : check e2411626179418 [[],[]] .three = true := by decide
def e2411626179434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2411626179434 : Closed e2411626179434 ∧ code e2411626179434 = 11207719201642 := by decide
theorem cert_e2411626179434 : check e2411626179434 [[],[]] .three = true := by decide
def e2411626179498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2411626179498 : Closed e2411626179498 ∧ code e2411626179498 = 11207719201706 := by decide
theorem cert_e2411626179498 : check e2411626179498 [[],[]] .three = true := by decide
def e2411626179694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2411626179694 : Closed e2411626179694 ∧ code e2411626179694 = 11207719201902 := by decide
theorem cert_e2411626179694 : check e2411626179694 [[],[]] .three = true := by decide
def e2411626179702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2411626179702 : Closed e2411626179702 ∧ code e2411626179702 = 11207719201910 := by decide
theorem cert_e2411626179702 : check e2411626179702 [[],[]] .three = true := by decide
def e2411626179706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2411626179706 : Closed e2411626179706 ∧ code e2411626179706 = 11207719201914 := by decide
theorem cert_e2411626179706 : check e2411626179706 [[],[]] .three = true := by decide
def e2411626179798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2411626179798 : Closed e2411626179798 ∧ code e2411626179798 = 11207719202006 := by decide
theorem cert_e2411626179798 : check e2411626179798 [[],[]] .three = true := by decide
def e2411626179802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2411626179802 : Closed e2411626179802 ∧ code e2411626179802 = 11207719202010 := by decide
theorem cert_e2411626179802 : check e2411626179802 [[],[]] .three = true := by decide
def e2411626179818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2411626179818 : Closed e2411626179818 ∧ code e2411626179818 = 11207719202026 := by decide
theorem cert_e2411626179818 : check e2411626179818 [[],[]] .three = true := by decide
def e2411626179870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2411626179870 : Closed e2411626179870 ∧ code e2411626179870 = 11207719202078 := by decide
theorem cert_e2411626179870 : check e2411626179870 [[],[]] .three = true := by decide
def e2411626179894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411626179894 : Closed e2411626179894 ∧ code e2411626179894 = 11207719202102 := by decide
theorem cert_e2411626179894 : check e2411626179894 [[],[]] .three = true := by decide
def e2411626179898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411626179898 : Closed e2411626179898 ∧ code e2411626179898 = 11207719202106 := by decide
theorem cert_e2411626179898 : check e2411626179898 [[],[]] .three = true := by decide
def e2411626179982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2411626179982 : Closed e2411626179982 ∧ code e2411626179982 = 11207719202190 := by decide
theorem cert_e2411626179982 : check e2411626179982 [[],[]] .three = true := by decide
def e2411626179994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411626179994 : Closed e2411626179994 ∧ code e2411626179994 = 11207719202202 := by decide
theorem cert_e2411626179994 : check e2411626179994 [[],[]] .three = true := by decide
def e2411626180038 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2411626180038 : Closed e2411626180038 ∧ code e2411626180038 = 11207719202246 := by decide
theorem cert_e2411626180038 : check e2411626180038 [[],[]] .three = true := by decide
def e2411626180062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2411626180062 : Closed e2411626180062 ∧ code e2411626180062 = 11207719202270 := by decide
theorem cert_e2411626180062 : check e2411626180062 [[],[]] .three = true := by decide
def e2411626180078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2411626180078 : Closed e2411626180078 ∧ code e2411626180078 = 11207719202286 := by decide
theorem cert_e2411626180078 : check e2411626180078 [[],[]] .three = true := by decide
def e2411626180150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411626180150 : Closed e2411626180150 ∧ code e2411626180150 = 11207719202358 := by decide
theorem cert_e2411626180150 : check e2411626180150 [[],[]] .three = true := by decide
def e2411626180154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411626180154 : Closed e2411626180154 ∧ code e2411626180154 = 11207719202362 := by decide
theorem cert_e2411626180154 : check e2411626180154 [[],[]] .three = true := by decide
def e2411626180202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2411626180202 : Closed e2411626180202 ∧ code e2411626180202 = 11207719202410 := by decide
theorem cert_e2411626180202 : check e2411626180202 [[],[]] .three = true := by decide
def e2411626180238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411626180238 : Closed e2411626180238 ∧ code e2411626180238 = 11207719202446 := by decide
theorem cert_e2411626180238 : check e2411626180238 [[],[]] .three = true := by decide
def e2411626180250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411626180250 : Closed e2411626180250 ∧ code e2411626180250 = 11207719202458 := by decide
theorem cert_e2411626180250 : check e2411626180250 [[],[]] .three = true := by decide
def e2411626180294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411626180294 : Closed e2411626180294 ∧ code e2411626180294 = 11207719202502 := by decide
theorem cert_e2411626180294 : check e2411626180294 [[],[]] .three = true := by decide
def e2411626180334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2411626180334 : Closed e2411626180334 ∧ code e2411626180334 = 11207719202542 := by decide
theorem cert_e2411626180334 : check e2411626180334 [[],[]] .three = true := by decide
def e2411626180378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411626180378 : Closed e2411626180378 ∧ code e2411626180378 = 11207719202586 := by decide
theorem cert_e2411626180378 : check e2411626180378 [[],[]] .three = true := by decide
def e2411626180422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411626180422 : Closed e2411626180422 ∧ code e2411626180422 = 11207719202630 := by decide
theorem cert_e2411626180422 : check e2411626180422 [[],[]] .three = true := by decide
def e2411626180446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2411626180446 : Closed e2411626180446 ∧ code e2411626180446 = 11207719202654 := by decide
theorem cert_e2411626180446 : check e2411626180446 [[],[]] .three = true := by decide
def e2411626180462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2411626180462 : Closed e2411626180462 ∧ code e2411626180462 = 11207719202670 := by decide
theorem cert_e2411626180462 : check e2411626180462 [[],[]] .three = true := by decide
def e2411626180470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2411626180470 : Closed e2411626180470 ∧ code e2411626180470 = 11207719202678 := by decide
theorem cert_e2411626180470 : check e2411626180470 [[],[]] .three = true := by decide
def e2411626180474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2411626180474 : Closed e2411626180474 ∧ code e2411626180474 = 11207719202682 := by decide
theorem cert_e2411626180474 : check e2411626180474 [[],[]] .three = true := by decide
def e2411626180526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2411626180526 : Closed e2411626180526 ∧ code e2411626180526 = 11207719202734 := by decide
theorem cert_e2411626180526 : check e2411626180526 [[],[]] .three = true := by decide
def e2411626180538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2411626180538 : Closed e2411626180538 ∧ code e2411626180538 = 11207719202746 := by decide
theorem cert_e2411626180538 : check e2411626180538 [[],[]] .three = true := by decide
def e2411626180846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e2411626180846 : Closed e2411626180846 ∧ code e2411626180846 = 11207719203054 := by decide
theorem cert_e2411626180846 : check e2411626180846 [[],[]] .three = true := by decide
def e2411626180854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e2411626180854 : Closed e2411626180854 ∧ code e2411626180854 = 11207719203062 := by decide
theorem cert_e2411626180854 : check e2411626180854 [[],[]] .three = true := by decide
def e2411626181334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411626181334 : Closed e2411626181334 ∧ code e2411626181334 = 11207719203542 := by decide
theorem cert_e2411626181334 : check e2411626181334 [[],[]] .three = true := by decide
def e2411626181338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411626181338 : Closed e2411626181338 ∧ code e2411626181338 = 11207719203546 := by decide
theorem cert_e2411626181338 : check e2411626181338 [[],[]] .three = true := by decide
def e2411626181354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411626181354 : Closed e2411626181354 ∧ code e2411626181354 = 11207719203562 := by decide
theorem cert_e2411626181354 : check e2411626181354 [[],[]] .three = true := by decide
def e2411626181406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2411626181406 : Closed e2411626181406 ∧ code e2411626181406 = 11207719203614 := by decide
theorem cert_e2411626181406 : check e2411626181406 [[],[]] .three = true := by decide
def e2411626181430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411626181430 : Closed e2411626181430 ∧ code e2411626181430 = 11207719203638 := by decide
theorem cert_e2411626181430 : check e2411626181430 [[],[]] .three = true := by decide
def e2411626181434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411626181434 : Closed e2411626181434 ∧ code e2411626181434 = 11207719203642 := by decide
theorem cert_e2411626181434 : check e2411626181434 [[],[]] .three = true := by decide
def e2411626181518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2411626181518 : Closed e2411626181518 ∧ code e2411626181518 = 11207719203726 := by decide
theorem cert_e2411626181518 : check e2411626181518 [[],[]] .three = true := by decide
def e2411626181530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411626181530 : Closed e2411626181530 ∧ code e2411626181530 = 11207719203738 := by decide
theorem cert_e2411626181530 : check e2411626181530 [[],[]] .three = true := by decide
def e2411626181574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2411626181574 : Closed e2411626181574 ∧ code e2411626181574 = 11207719203782 := by decide
theorem cert_e2411626181574 : check e2411626181574 [[],[]] .three = true := by decide
def e2411626181598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2411626181598 : Closed e2411626181598 ∧ code e2411626181598 = 11207719203806 := by decide
theorem cert_e2411626181598 : check e2411626181598 [[],[]] .three = true := by decide
def e2411626181614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2411626181614 : Closed e2411626181614 ∧ code e2411626181614 = 11207719203822 := by decide
theorem cert_e2411626181614 : check e2411626181614 [[],[]] .three = true := by decide
def e2411626182774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2411626182774 : Closed e2411626182774 ∧ code e2411626182774 = 11207719204982 := by decide
theorem cert_e2411626182774 : check e2411626182774 [[],[]] .three = true := by decide
def e2411626183018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2411626183018 : Closed e2411626183018 ∧ code e2411626183018 = 11207719205226 := by decide
theorem cert_e2411626183018 : check e2411626183018 [[],[]] .three = true := by decide
def e2411626183054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411626183054 : Closed e2411626183054 ∧ code e2411626183054 = 11207719205262 := by decide
theorem cert_e2411626183054 : check e2411626183054 [[],[]] .three = true := by decide
def e2411626183066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411626183066 : Closed e2411626183066 ∧ code e2411626183066 = 11207719205274 := by decide
theorem cert_e2411626183066 : check e2411626183066 [[],[]] .three = true := by decide
def e2411626183110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411626183110 : Closed e2411626183110 ∧ code e2411626183110 = 11207719205318 := by decide
theorem cert_e2411626183110 : check e2411626183110 [[],[]] .three = true := by decide
def e2411626183150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2411626183150 : Closed e2411626183150 ∧ code e2411626183150 = 11207719205358 := by decide
theorem cert_e2411626183150 : check e2411626183150 [[],[]] .three = true := by decide
def e2411626183878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411626183878 : Closed e2411626183878 ∧ code e2411626183878 = 11207719206086 := by decide
theorem cert_e2411626183878 : check e2411626183878 [[],[]] .three = true := by decide
def e2411626183902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411626183902 : Closed e2411626183902 ∧ code e2411626183902 = 11207719206110 := by decide
theorem cert_e2411626183902 : check e2411626183902 [[],[]] .three = true := by decide
def e2411626183918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411626183918 : Closed e2411626183918 ∧ code e2411626183918 = 11207719206126 := by decide
theorem cert_e2411626183918 : check e2411626183918 [[],[]] .three = true := by decide
def e2411626183926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411626183926 : Closed e2411626183926 ∧ code e2411626183926 = 11207719206134 := by decide
theorem cert_e2411626183926 : check e2411626183926 [[],[]] .three = true := by decide
def e2411626183930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411626183930 : Closed e2411626183930 ∧ code e2411626183930 = 11207719206138 := by decide
theorem cert_e2411626183930 : check e2411626183930 [[],[]] .three = true := by decide
def e2411626184302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411626184302 : Closed e2411626184302 ∧ code e2411626184302 = 11207719206510 := by decide
theorem cert_e2411626184302 : check e2411626184302 [[],[]] .three = true := by decide
def e2411626184314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411626184314 : Closed e2411626184314 ∧ code e2411626184314 = 11207719206522 := by decide
theorem cert_e2411626184314 : check e2411626184314 [[],[]] .three = true := by decide
def e2411628702958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411628702958 : Closed e2411628702958 ∧ code e2411628702958 = 11207721725166 := by decide
theorem cert_e2411628702958 : check e2411628702958 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2411628702966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411628702966 : Closed e2411628702966 ∧ code e2411628702966 = 11207721725174 := by decide
theorem cert_e2411628702966 : check e2411628702966 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411628705006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411628705006 : Closed e2411628705006 ∧ code e2411628705006 = 11207721727214 := by decide
theorem cert_e2411628705006 : check e2411628705006 [[],[],[.under,.under]] .sourceHead = true := by decide
def e2411628705014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411628705014 : Closed e2411628705014 ∧ code e2411628705014 = 11207721727222 := by decide
theorem cert_e2411628705014 : check e2411628705014 [[],[],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411628713198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411628713198 : Closed e2411628713198 ∧ code e2411628713198 = 11207721735406 := by decide
theorem cert_e2411628713198 : check e2411628713198 [[.left,.left],[.left,.left],[.left],[],[],[.left]] .identityHead = true := by decide
def e2411628713206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411628713206 : Closed e2411628713206 ∧ code e2411628713206 = 11207721735414 := by decide
theorem cert_e2411628713206 : check e2411628713206 [[.left,.left],[.left,.left],[.left],[],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2411628752110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411628752110 : Closed e2411628752110 ∧ code e2411628752110 = 11207721774318 := by decide
theorem cert_e2411628752110 : checkPay e2411628752110 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under,.under]] = true := by decide
def e2411628752118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411628752118 : Closed e2411628752118 ∧ code e2411628752118 = 11207721774326 := by decide
theorem cert_e2411628752118 : check e2411628752118 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411628754158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411628754158 : Closed e2411628754158 ∧ code e2411628754158 = 11207721776366 := by decide
theorem cert_e2411628754158 : checkPay e2411628754158 [[.left,.left],[.left,.left],[.left],[],[]] 0 [[.under,.under,.under,.under]] = true := by decide
def e2411628754166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411628754166 : Closed e2411628754166 ∧ code e2411628754166 = 11207721776374 := by decide
theorem cert_e2411628754166 : check e2411628754166 [[],[],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411628803310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411628803310 : Closed e2411628803310 ∧ code e2411628803310 = 11207721825518 := by decide
theorem cert_e2411628803310 : check e2411628803310 [[.left,.left],[.left,.left],[.left],[],[],[]] .identityHead = true := by decide
def e2411628803318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411628803318 : Closed e2411628803318 ∧ code e2411628803318 = 11207721825526 := by decide
theorem cert_e2411628803318 : check e2411628803318 [[.left,.left],[.left,.left],[.left],[],[],[],[.left,.left,.left],[.left,.left],[.left],[],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left],[],[.left],[],[.left],[],[.under,.under]] .identityHead = true := by decide
def e2411629742958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2411629742958 : Closed e2411629742958 ∧ code e2411629742958 = 11207722765166 := by decide
theorem cert_e2411629742958 : check e2411629742958 [[],[]] .chain = true := by decide
def e2411629742966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2411629742966 : Closed e2411629742966 ∧ code e2411629742966 = 11207722765174 := by decide
theorem cert_e2411629742966 : check e2411629742966 [[],[]] .chain = true := by decide
def e2411629743030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2411629743030 : Closed e2411629743030 ∧ code e2411629743030 = 11207722765238 := by decide
theorem cert_e2411629743030 : check e2411629743030 [[],[]] .chain = true := by decide
def e2411629743470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2411629743470 : Closed e2411629743470 ∧ code e2411629743470 = 11207722765678 := by decide
theorem cert_e2411629743470 : check e2411629743470 [[],[]] .chain = true := by decide
def e2411629743478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2411629743478 : Closed e2411629743478 ∧ code e2411629743478 = 11207722765686 := by decide
theorem cert_e2411629743478 : check e2411629743478 [[],[]] .chain = true := by decide
def e2411629743534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2411629743534 : Closed e2411629743534 ∧ code e2411629743534 = 11207722765742 := by decide
theorem cert_e2411629743534 : check e2411629743534 [[],[]] .chain = true := by decide
def e2411629743546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2411629743546 : Closed e2411629743546 ∧ code e2411629743546 = 11207722765754 := by decide
theorem cert_e2411629743546 : check e2411629743546 [[],[]] .chain = true := by decide
def e2411629743574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2411629743574 : Closed e2411629743574 ∧ code e2411629743574 = 11207722765782 := by decide
theorem cert_e2411629743574 : check e2411629743574 [[],[]] .chain = true := by decide
def e2411629743578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2411629743578 : Closed e2411629743578 ∧ code e2411629743578 = 11207722765786 := by decide
theorem cert_e2411629743578 : check e2411629743578 [[],[]] .chain = true := by decide
def e2411629743790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2411629743790 : Closed e2411629743790 ∧ code e2411629743790 = 11207722765998 := by decide
theorem cert_e2411629743790 : check e2411629743790 [[],[]] .chain = true := by decide
def e2411629743802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2411629743802 : Closed e2411629743802 ∧ code e2411629743802 = 11207722766010 := by decide
theorem cert_e2411629743802 : check e2411629743802 [[],[]] .chain = true := by decide
def e2411629743850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2411629743850 : Closed e2411629743850 ∧ code e2411629743850 = 11207722766058 := by decide
theorem cert_e2411629743850 : check e2411629743850 [[],[]] .chain = true := by decide
def e2411629743958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2411629743958 : Closed e2411629743958 ∧ code e2411629743958 = 11207722766166 := by decide
theorem cert_e2411629743958 : check e2411629743958 [[],[]] .chain = true := by decide
def e2411629743962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2411629743962 : Closed e2411629743962 ∧ code e2411629743962 = 11207722766170 := by decide
theorem cert_e2411629743962 : check e2411629743962 [[],[]] .chain = true := by decide
def e2411629743978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2411629743978 : Closed e2411629743978 ∧ code e2411629743978 = 11207722766186 := by decide
theorem cert_e2411629743978 : check e2411629743978 [[],[]] .chain = true := by decide
def e2411629749102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2411629749102 : Closed e2411629749102 ∧ code e2411629749102 = 11207722771310 := by decide
theorem cert_e2411629749102 : check e2411629749102 [[],[]] .chain = true := by decide
def e2411629749110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2411629749110 : Closed e2411629749110 ∧ code e2411629749110 = 11207722771318 := by decide
theorem cert_e2411629749110 : check e2411629749110 [[],[]] .chain = true := by decide
def e2411629749166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2411629749166 : Closed e2411629749166 ∧ code e2411629749166 = 11207722771374 := by decide
theorem cert_e2411629749166 : check e2411629749166 [[],[]] .chain = true := by decide
def e2411629749178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2411629749178 : Closed e2411629749178 ∧ code e2411629749178 = 11207722771386 := by decide
theorem cert_e2411629749178 : check e2411629749178 [[],[]] .chain = true := by decide
def e2411629749206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 0)) (.var 1))))))
theorem wire_e2411629749206 : Closed e2411629749206 ∧ code e2411629749206 = 11207722771414 := by decide
theorem cert_e2411629749206 : check e2411629749206 [[],[]] .chain = true := by decide
def e2411629749210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 0))))))
theorem wire_e2411629749210 : Closed e2411629749210 ∧ code e2411629749210 = 11207722771418 := by decide
theorem cert_e2411629749210 : check e2411629749210 [[],[]] .chain = true := by decide
def e2411629750510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2411629750510 : Closed e2411629750510 ∧ code e2411629750510 = 11207722772718 := by decide
theorem cert_e2411629750510 : check e2411629750510 [[],[]] .chain = true := by decide
def e2411629750518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2411629750518 : Closed e2411629750518 ∧ code e2411629750518 = 11207722772726 := by decide
theorem cert_e2411629750518 : check e2411629750518 [[],[]] .chain = true := by decide
def e2411629751070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2411629751070 : Closed e2411629751070 ∧ code e2411629751070 = 11207722773278 := by decide
theorem cert_e2411629751070 : check e2411629751070 [[],[]] .chain = true := by decide
def e2411629751182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2411629751182 : Closed e2411629751182 ∧ code e2411629751182 = 11207722773390 := by decide
theorem cert_e2411629751182 : check e2411629751182 [[],[]] .chain = true := by decide
def e2411629751406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2411629751406 : Closed e2411629751406 ∧ code e2411629751406 = 11207722773614 := by decide
theorem cert_e2411629751406 : check e2411629751406 [[],[]] .chain = true := by decide
def e2411629751418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2411629751418 : Closed e2411629751418 ∧ code e2411629751418 = 11207722773626 := by decide
theorem cert_e2411629751418 : check e2411629751418 [[],[]] .chain = true := by decide
def e2411629751582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2411629751582 : Closed e2411629751582 ∧ code e2411629751582 = 11207722773790 := by decide
theorem cert_e2411629751582 : check e2411629751582 [[],[]] .chain = true := by decide
def e2411629751750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2411629751750 : Closed e2411629751750 ∧ code e2411629751750 = 11207722773958 := by decide
theorem cert_e2411629751750 : check e2411629751750 [[],[]] .chain = true := by decide
def e2411629751862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629751862 : Closed e2411629751862 ∧ code e2411629751862 = 11207722774070 := by decide
theorem cert_e2411629751862 : check e2411629751862 [[],[]] .chain = true := by decide
def e2411629751866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629751866 : Closed e2411629751866 ∧ code e2411629751866 = 11207722774074 := by decide
theorem cert_e2411629751866 : check e2411629751866 [[],[]] .chain = true := by decide
def e2411629751950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629751950 : Closed e2411629751950 ∧ code e2411629751950 = 11207722774158 := by decide
theorem cert_e2411629751950 : check e2411629751950 [[],[]] .chain = true := by decide
def e2411629752006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629752006 : Closed e2411629752006 ∧ code e2411629752006 = 11207722774214 := by decide
theorem cert_e2411629752006 : check e2411629752006 [[],[]] .chain = true := by decide
def e2411629752686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2411629752686 : Closed e2411629752686 ∧ code e2411629752686 = 11207722774894 := by decide
theorem cert_e2411629752686 : check e2411629752686 [[],[]] .chain = true := by decide
def e2411629752694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2411629752694 : Closed e2411629752694 ∧ code e2411629752694 = 11207722774902 := by decide
theorem cert_e2411629752694 : check e2411629752694 [[],[]] .chain = true := by decide
def e2411629752750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2411629752750 : Closed e2411629752750 ∧ code e2411629752750 = 11207722774958 := by decide
theorem cert_e2411629752750 : check e2411629752750 [[],[]] .chain = true := by decide
def e2411629752762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2411629752762 : Closed e2411629752762 ∧ code e2411629752762 = 11207722774970 := by decide
theorem cert_e2411629752762 : check e2411629752762 [[],[]] .chain = true := by decide
def e2411629752810 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2411629752810 : Closed e2411629752810 ∧ code e2411629752810 = 11207722775018 := by decide
theorem cert_e2411629752810 : check e2411629752810 [[],[]] .chain = true := by decide
def e2411629753454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2411629753454 : Closed e2411629753454 ∧ code e2411629753454 = 11207722775662 := by decide
theorem cert_e2411629753454 : check e2411629753454 [[],[]] .chain = true := by decide
def e2411629753466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2411629753466 : Closed e2411629753466 ∧ code e2411629753466 = 11207722775674 := by decide
theorem cert_e2411629753466 : check e2411629753466 [[],[]] .chain = true := by decide
def e2411629753630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2411629753630 : Closed e2411629753630 ∧ code e2411629753630 = 11207722775838 := by decide
theorem cert_e2411629753630 : check e2411629753630 [[],[]] .chain = true := by decide
def e2411629753798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2411629753798 : Closed e2411629753798 ∧ code e2411629753798 = 11207722776006 := by decide
theorem cert_e2411629753798 : check e2411629753798 [[],[]] .chain = true := by decide
def e2411629753902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2411629753902 : Closed e2411629753902 ∧ code e2411629753902 = 11207722776110 := by decide
theorem cert_e2411629753902 : check e2411629753902 [[],[]] .chain = true := by decide
def e2411629754082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2411629754082 : Closed e2411629754082 ∧ code e2411629754082 = 11207722776290 := by decide
theorem cert_e2411629754082 : check e2411629754082 [[],[]] .chain = true := by decide
def e2411629754094 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2411629754094 : Closed e2411629754094 ∧ code e2411629754094 = 11207722776302 := by decide
theorem cert_e2411629754094 : check e2411629754094 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2411629754134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629754134 : Closed e2411629754134 ∧ code e2411629754134 = 11207722776342 := by decide
theorem cert_e2411629754134 : check e2411629754134 [[],[]] .chain = true := by decide
def e2411629754138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629754138 : Closed e2411629754138 ∧ code e2411629754138 = 11207722776346 := by decide
theorem cert_e2411629754138 : check e2411629754138 [[],[]] .chain = true := by decide
def e2411629754182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629754182 : Closed e2411629754182 ∧ code e2411629754182 = 11207722776390 := by decide
theorem cert_e2411629754182 : check e2411629754182 [[],[]] .chain = true := by decide
def e2411629754210 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629754210 : Closed e2411629754210 ∧ code e2411629754210 = 11207722776418 := by decide
theorem cert_e2411629754210 : check e2411629754210 [[],[]] .chain = true := by decide
def e2411629754222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2411629754222 : Closed e2411629754222 ∧ code e2411629754222 = 11207722776430 := by decide
theorem cert_e2411629754222 : check e2411629754222 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2411629754230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2411629754230 : Closed e2411629754230 ∧ code e2411629754230 = 11207722776438 := by decide
theorem cert_e2411629754230 : check e2411629754230 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2411629754550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2411629754550 : Closed e2411629754550 ∧ code e2411629754550 = 11207722776758 := by decide
theorem cert_e2411629754550 : check e2411629754550 [[],[]] .chain = true := by decide
end Blc.Floor43
