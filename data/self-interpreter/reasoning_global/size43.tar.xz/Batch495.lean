import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422408491510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 4)))))) (.var 1))))))
theorem wire_e2422408491510 : Closed e2422408491510 ∧ code e2422408491510 = 11218501513718 := by decide
theorem cert_e2422408491510 : check e2422408491510 [[],[]] .chain = true := by decide
def e2422408491962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))))
theorem wire_e2422408491962 : Closed e2422408491962 ∧ code e2422408491962 = 11218501514170 := by decide
theorem cert_e2422408491962 : check e2422408491962 [[],[]] .smaller = true := by decide
def e2422408491994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))))
theorem wire_e2422408491994 : Closed e2422408491994 ∧ code e2422408491994 = 11218501514202 := by decide
theorem cert_e2422408491994 : check e2422408491994 [[],[]] .smaller = true := by decide
def e2422408492270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408492270 : Closed e2422408492270 ∧ code e2422408492270 = 11218501514478 := by decide
theorem cert_e2422408492270 : check e2422408492270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408492278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408492278 : Closed e2422408492278 ∧ code e2422408492278 = 11218501514486 := by decide
theorem cert_e2422408492278 : check e2422408492278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.under]] .identityHead = true := by decide
def e2422408492830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.lam (.var 3)))))))
theorem wire_e2422408492830 : Closed e2422408492830 ∧ code e2422408492830 = 11218501515038 := by decide
theorem cert_e2422408492830 : check e2422408492830 [[],[]] .chain = true := by decide
def e2422408492942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))) (.lam (.var 2)))))))
theorem wire_e2422408492942 : Closed e2422408492942 ∧ code e2422408492942 = 11218501515150 := by decide
theorem cert_e2422408492942 : check e2422408492942 [[],[]] .chain = true := by decide
def e2422408493498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))))
theorem wire_e2422408493498 : Closed e2422408493498 ∧ code e2422408493498 = 11218501515706 := by decide
theorem cert_e2422408493498 : check e2422408493498 [[],[]] .smaller = true := by decide
def e2422408493546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))))
theorem wire_e2422408493546 : Closed e2422408493546 ∧ code e2422408493546 = 11218501515754 := by decide
theorem cert_e2422408493546 : check e2422408493546 [[],[]] .smaller = true := by decide
def e2422408494190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 1)))))) (.var 2))))))
theorem wire_e2422408494190 : Closed e2422408494190 ∧ code e2422408494190 = 11218501516398 := by decide
theorem cert_e2422408494190 : check e2422408494190 [[],[]] .chain = true := by decide
def e2422408494298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))))
theorem wire_e2422408494298 : Closed e2422408494298 ∧ code e2422408494298 = 11218501516506 := by decide
theorem cert_e2422408494298 : check e2422408494298 [[],[]] .smaller = true := by decide
def e2422408494314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))))
theorem wire_e2422408494314 : Closed e2422408494314 ∧ code e2422408494314 = 11218501516522 := by decide
theorem cert_e2422408494314 : check e2422408494314 [[],[]] .smaller = true := by decide
def e2422408494366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.lam (.var 3)))))))
theorem wire_e2422408494366 : Closed e2422408494366 ∧ code e2422408494366 = 11218501516574 := by decide
theorem cert_e2422408494366 : check e2422408494366 [[],[]] .chain = true := by decide
def e2422408494562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))) (.lam (.var 0)))))))
theorem wire_e2422408494562 : Closed e2422408494562 ∧ code e2422408494562 = 11218501516770 := by decide
theorem cert_e2422408494562 : check e2422408494562 [[],[]] .chain = true := by decide
def e2422408494574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))) (.var 2))))))
theorem wire_e2422408494574 : Closed e2422408494574 ∧ code e2422408494574 = 11218501516782 := by decide
theorem cert_e2422408494574 : check e2422408494574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408494646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 1)))))) (.var 1))))))
theorem wire_e2422408494646 : Closed e2422408494646 ∧ code e2422408494646 = 11218501516854 := by decide
theorem cert_e2422408494646 : check e2422408494646 [[],[]] .chain = true := by decide
def e2422408494734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))) (.lam (.var 2)))))))
theorem wire_e2422408494734 : Closed e2422408494734 ∧ code e2422408494734 = 11218501516942 := by decide
theorem cert_e2422408494734 : check e2422408494734 [[],[]] .chain = true := by decide
def e2422408494818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422408494818 : Closed e2422408494818 ∧ code e2422408494818 = 11218501517026 := by decide
theorem cert_e2422408494818 : check e2422408494818 [[],[]] .chain = true := by decide
def e2422408494830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))) (.var 2))))))
theorem wire_e2422408494830 : Closed e2422408494830 ∧ code e2422408494830 = 11218501517038 := by decide
theorem cert_e2422408494830 : check e2422408494830 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408494838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 3))))) (.var 1))))))
theorem wire_e2422408494838 : Closed e2422408494838 ∧ code e2422408494838 = 11218501517046 := by decide
theorem cert_e2422408494838 : check e2422408494838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422408496094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422408496094 : Closed e2422408496094 ∧ code e2422408496094 = 11218501518302 := by decide
theorem cert_e2422408496094 : check e2422408496094 [[],[]] .chain = true := by decide
def e2422408496110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422408496110 : Closed e2422408496110 ∧ code e2422408496110 = 11218501518318 := by decide
theorem cert_e2422408496110 : check e2422408496110 [[],[]] .chain = true := by decide
def e2422408498030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422408498030 : Closed e2422408498030 ∧ code e2422408498030 = 11218501520238 := by decide
theorem cert_e2422408498030 : check e2422408498030 [[],[]] .chain = true := by decide
def e2422408498038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422408498038 : Closed e2422408498038 ∧ code e2422408498038 = 11218501520246 := by decide
theorem cert_e2422408498038 : check e2422408498038 [[],[]] .chain = true := by decide
def e2422408498094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422408498094 : Closed e2422408498094 ∧ code e2422408498094 = 11218501520302 := by decide
theorem cert_e2422408498094 : check e2422408498094 [[],[]] .chain = true := by decide
def e2422408498106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422408498106 : Closed e2422408498106 ∧ code e2422408498106 = 11218501520314 := by decide
theorem cert_e2422408498106 : check e2422408498106 [[],[]] .chain = true := by decide
def e2422408498134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422408498134 : Closed e2422408498134 ∧ code e2422408498134 = 11218501520342 := by decide
theorem cert_e2422408498134 : check e2422408498134 [[],[]] .chain = true := by decide
def e2422408498138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422408498138 : Closed e2422408498138 ∧ code e2422408498138 = 11218501520346 := by decide
theorem cert_e2422408498138 : check e2422408498138 [[],[]] .chain = true := by decide
def e2422408498414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422408498414 : Closed e2422408498414 ∧ code e2422408498414 = 11218501520622 := by decide
theorem cert_e2422408498414 : check e2422408498414 [[],[]] .chain = true := by decide
def e2422408498422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422408498422 : Closed e2422408498422 ∧ code e2422408498422 = 11218501520630 := by decide
theorem cert_e2422408498422 : check e2422408498422 [[],[]] .chain = true := by decide
def e2422408498798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422408498798 : Closed e2422408498798 ∧ code e2422408498798 = 11218501521006 := by decide
theorem cert_e2422408498798 : check e2422408498798 [[],[]] .chain = true := by decide
def e2422408498810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422408498810 : Closed e2422408498810 ∧ code e2422408498810 = 11218501521018 := by decide
theorem cert_e2422408498810 : check e2422408498810 [[],[]] .chain = true := by decide
def e2422408498998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422408498998 : Closed e2422408498998 ∧ code e2422408498998 = 11218501521206 := by decide
theorem cert_e2422408498998 : check e2422408498998 [[],[]] .chain = true := by decide
def e2422408499002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422408499002 : Closed e2422408499002 ∧ code e2422408499002 = 11218501521210 := by decide
theorem cert_e2422408499002 : check e2422408499002 [[],[]] .chain = true := by decide
def e2422408505118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422408505118 : Closed e2422408505118 ∧ code e2422408505118 = 11218501527326 := by decide
theorem cert_e2422408505118 : check e2422408505118 [[],[]] .chain = true := by decide
def e2422408505230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422408505230 : Closed e2422408505230 ∧ code e2422408505230 = 11218501527438 := by decide
theorem cert_e2422408505230 : check e2422408505230 [[],[]] .chain = true := by decide
def e2422408507614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422408507614 : Closed e2422408507614 ∧ code e2422408507614 = 11218501529822 := by decide
theorem cert_e2422408507614 : check e2422408507614 [[],[]] .chain = true := by decide
def e2422408507642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422408507642 : Closed e2422408507642 ∧ code e2422408507642 = 11218501529850 := by decide
theorem cert_e2422408507642 : check e2422408507642 [[],[]] .chain = true := by decide
def e2422408508190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422408508190 : Closed e2422408508190 ∧ code e2422408508190 = 11218501530398 := by decide
theorem cert_e2422408508190 : check e2422408508190 [[],[]] .chain = true := by decide
def e2422408508358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422408508358 : Closed e2422408508358 ∧ code e2422408508358 = 11218501530566 := by decide
theorem cert_e2422408508358 : check e2422408508358 [[],[]] .chain = true := by decide
def e2422408509550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422408509550 : Closed e2422408509550 ∧ code e2422408509550 = 11218501531758 := by decide
theorem cert_e2422408509550 : check e2422408509550 [[],[]] .chain = true := by decide
def e2422408509562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422408509562 : Closed e2422408509562 ∧ code e2422408509562 = 11218501531770 := by decide
theorem cert_e2422408509562 : check e2422408509562 [[],[]] .chain = true := by decide
def e2422408509838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422408509838 : Closed e2422408509838 ∧ code e2422408509838 = 11218501532046 := by decide
theorem cert_e2422408509838 : check e2422408509838 [[],[]] .chain = true := by decide
def e2422408509894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422408509894 : Closed e2422408509894 ∧ code e2422408509894 = 11218501532102 := by decide
theorem cert_e2422408509894 : check e2422408509894 [[],[]] .chain = true := by decide
def e2422408524142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))) (.var 2))))))
theorem wire_e2422408524142 : Closed e2422408524142 ∧ code e2422408524142 = 11218501546350 := by decide
theorem cert_e2422408524142 : check e2422408524142 [[],[]] .chain = true := by decide
def e2422408524150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))) (.var 1))))))
theorem wire_e2422408524150 : Closed e2422408524150 ∧ code e2422408524150 = 11218501546358 := by decide
theorem cert_e2422408524150 : check e2422408524150 [[],[]] .chain = true := by decide
def e2422408525358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408525358 : Closed e2422408525358 ∧ code e2422408525358 = 11218501547566 := by decide
theorem cert_e2422408525358 : check e2422408525358 [[],[]] .chain = true := by decide
def e2422408525538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408525538 : Closed e2422408525538 ∧ code e2422408525538 = 11218501547746 := by decide
theorem cert_e2422408525538 : check e2422408525538 [[],[]] .chain = true := by decide
def e2422408525550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 2))))))
theorem wire_e2422408525550 : Closed e2422408525550 ∧ code e2422408525550 = 11218501547758 := by decide
theorem cert_e2422408525550 : check e2422408525550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408525590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422408525590 : Closed e2422408525590 ∧ code e2422408525590 = 11218501547798 := by decide
theorem cert_e2422408525590 : check e2422408525590 [[],[]] .chain = true := by decide
def e2422408525666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422408525666 : Closed e2422408525666 ∧ code e2422408525666 = 11218501547874 := by decide
theorem cert_e2422408525666 : check e2422408525666 [[],[]] .chain = true := by decide
def e2422408525678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 2))))))
theorem wire_e2422408525678 : Closed e2422408525678 ∧ code e2422408525678 = 11218501547886 := by decide
theorem cert_e2422408525678 : check e2422408525678 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408525686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2)))) (.var 1))))))
theorem wire_e2422408525686 : Closed e2422408525686 ∧ code e2422408525686 = 11218501547894 := by decide
theorem cert_e2422408525686 : check e2422408525686 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408525998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))) (.var 2))))))
theorem wire_e2422408525998 : Closed e2422408525998 ∧ code e2422408525998 = 11218501548206 := by decide
theorem cert_e2422408525998 : check e2422408525998 [[],[]] .chain = true := by decide
def e2422408526010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))) (.var 0))))))
theorem wire_e2422408526010 : Closed e2422408526010 ∧ code e2422408526010 = 11218501548218 := by decide
theorem cert_e2422408526010 : check e2422408526010 [[],[]] .chain = true := by decide
def e2422408526382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422408526382 : Closed e2422408526382 ∧ code e2422408526382 = 11218501548590 := by decide
theorem cert_e2422408526382 : check e2422408526382 [[],[]] .chain = true := by decide
def e2422408526562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2422408526562 : Closed e2422408526562 ∧ code e2422408526562 = 11218501548770 := by decide
theorem cert_e2422408526562 : check e2422408526562 [[],[]] .chain = true := by decide
def e2422408526574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 2))))))
theorem wire_e2422408526574 : Closed e2422408526574 ∧ code e2422408526574 = 11218501548782 := by decide
theorem cert_e2422408526574 : check e2422408526574 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408526702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1)))) (.var 2))))))
theorem wire_e2422408526702 : Closed e2422408526702 ∧ code e2422408526702 = 11218501548910 := by decide
theorem cert_e2422408526702 : check e2422408526702 [[],[]] .chain = true := by decide
def e2422408526710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))) (.var 1))))))
theorem wire_e2422408526710 : Closed e2422408526710 ∧ code e2422408526710 = 11218501548918 := by decide
theorem cert_e2422408526710 : check e2422408526710 [[],[]] .chain = true := by decide
def e2422408526730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408526730 : Closed e2422408526730 ∧ code e2422408526730 = 11218501548938 := by decide
theorem cert_e2422408526730 : check e2422408526730 [[],[]] .chain = true := by decide
def e2422408526754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408526754 : Closed e2422408526754 ∧ code e2422408526754 = 11218501548962 := by decide
theorem cert_e2422408526754 : check e2422408526754 [[],[]] .chain = true := by decide
def e2422408526766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 2))))))
theorem wire_e2422408526766 : Closed e2422408526766 ∧ code e2422408526766 = 11218501548974 := by decide
theorem cert_e2422408526766 : check e2422408526766 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408526774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))) (.var 1))))))
theorem wire_e2422408526774 : Closed e2422408526774 ∧ code e2422408526774 = 11218501548982 := by decide
theorem cert_e2422408526774 : check e2422408526774 [[],[]] .chain = true := by decide
def e2422408526778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))) (.var 0))))))
theorem wire_e2422408526778 : Closed e2422408526778 ∧ code e2422408526778 = 11218501548986 := by decide
theorem cert_e2422408526778 : check e2422408526778 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408526934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))) (.var 1))))))
theorem wire_e2422408526934 : Closed e2422408526934 ∧ code e2422408526934 = 11218501549142 := by decide
theorem cert_e2422408526934 : check e2422408526934 [[],[]] .chain = true := by decide
def e2422408526938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))) (.var 0))))))
theorem wire_e2422408526938 : Closed e2422408526938 ∧ code e2422408526938 = 11218501549146 := by decide
theorem cert_e2422408526938 : check e2422408526938 [[],[]] .chain = true := by decide
def e2422408527126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422408527126 : Closed e2422408527126 ∧ code e2422408527126 = 11218501549334 := by decide
theorem cert_e2422408527126 : check e2422408527126 [[],[]] .chain = true := by decide
def e2422408527202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422408527202 : Closed e2422408527202 ∧ code e2422408527202 = 11218501549410 := by decide
theorem cert_e2422408527202 : check e2422408527202 [[],[]] .chain = true := by decide
def e2422408527214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 2))))))
theorem wire_e2422408527214 : Closed e2422408527214 ∧ code e2422408527214 = 11218501549422 := by decide
theorem cert_e2422408527214 : checkPay e2422408527214 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] 0 [] = true := by decide
def e2422408527222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2)))) (.var 1))))))
theorem wire_e2422408527222 : Closed e2422408527222 ∧ code e2422408527222 = 11218501549430 := by decide
theorem cert_e2422408527222 : check e2422408527222 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408527242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422408527242 : Closed e2422408527242 ∧ code e2422408527242 = 11218501549450 := by decide
theorem cert_e2422408527242 : check e2422408527242 [[],[]] .chain = true := by decide
def e2422408527266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2422408527266 : Closed e2422408527266 ∧ code e2422408527266 = 11218501549474 := by decide
theorem cert_e2422408527266 : check e2422408527266 [[],[]] .chain = true := by decide
def e2422408527278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 2))))))
theorem wire_e2422408527278 : Closed e2422408527278 ∧ code e2422408527278 = 11218501549486 := by decide
theorem cert_e2422408527278 : check e2422408527278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408527286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))) (.var 1))))))
theorem wire_e2422408527286 : Closed e2422408527286 ∧ code e2422408527286 = 11218501549494 := by decide
theorem cert_e2422408527286 : check e2422408527286 [[],[]] .chain = true := by decide
def e2422408527290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e2422408527290 : Closed e2422408527290 ∧ code e2422408527290 = 11218501549498 := by decide
theorem cert_e2422408527290 : check e2422408527290 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408527318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0)))) (.var 1))))))
theorem wire_e2422408527318 : Closed e2422408527318 ∧ code e2422408527318 = 11218501549526 := by decide
theorem cert_e2422408527318 : checkPay e2422408527318 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422408527322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e2422408527322 : Closed e2422408527322 ∧ code e2422408527322 = 11218501549530 := by decide
def e2422408528366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3)))))) (.var 2))))))
theorem wire_e2422408528366 : Closed e2422408528366 ∧ code e2422408528366 = 11218501550574 := by decide
theorem cert_e2422408528366 : check e2422408528366 [[],[]] .chain = true := by decide
def e2422408528374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4)))))) (.var 1))))))
theorem wire_e2422408528374 : Closed e2422408528374 ∧ code e2422408528374 = 11218501550582 := by decide
theorem cert_e2422408528374 : check e2422408528374 [[],[]] .chain = true := by decide
def e2422408529134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408529134 : Closed e2422408529134 ∧ code e2422408529134 = 11218501551342 := by decide
theorem cert_e2422408529134 : check e2422408529134 [[],[]] .chain = true := by decide
def e2422408529142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408529142 : Closed e2422408529142 ∧ code e2422408529142 = 11218501551350 := by decide
theorem cert_e2422408529142 : check e2422408529142 [[],[]] .chain = true := by decide
def e2422408529694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.var 3)))))))
theorem wire_e2422408529694 : Closed e2422408529694 ∧ code e2422408529694 = 11218501551902 := by decide
theorem cert_e2422408529694 : check e2422408529694 [[],[]] .chain = true := by decide
def e2422408529806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.lam (.var 2)))))))
theorem wire_e2422408529806 : Closed e2422408529806 ∧ code e2422408529806 = 11218501552014 := by decide
theorem cert_e2422408529806 : check e2422408529806 [[],[]] .chain = true := by decide
def e2422408531502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408531502 : Closed e2422408531502 ∧ code e2422408531502 = 11218501553710 := by decide
theorem cert_e2422408531502 : check e2422408531502 [[],[]] .chain = true := by decide
def e2422408531682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422408531682 : Closed e2422408531682 ∧ code e2422408531682 = 11218501553890 := by decide
theorem cert_e2422408531682 : check e2422408531682 [[],[]] .chain = true := by decide
def e2422408531694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 2))))))
theorem wire_e2422408531694 : Closed e2422408531694 ∧ code e2422408531694 = 11218501553902 := by decide
theorem cert_e2422408531694 : check e2422408531694 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408531734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408531734 : Closed e2422408531734 ∧ code e2422408531734 = 11218501553942 := by decide
theorem cert_e2422408531734 : check e2422408531734 [[],[]] .chain = true := by decide
def e2422408531810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e2422408531810 : Closed e2422408531810 ∧ code e2422408531810 = 11218501554018 := by decide
theorem cert_e2422408531810 : check e2422408531810 [[],[]] .chain = true := by decide
def e2422408531822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 2))))))
theorem wire_e2422408531822 : Closed e2422408531822 ∧ code e2422408531822 = 11218501554030 := by decide
theorem cert_e2422408531822 : check e2422408531822 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408531830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2))))) (.var 1))))))
theorem wire_e2422408531830 : Closed e2422408531830 ∧ code e2422408531830 = 11218501554038 := by decide
theorem cert_e2422408531830 : check e2422408531830 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408534078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.var 4))))))))
theorem wire_e2422408534078 : Closed e2422408534078 ∧ code e2422408534078 = 11218501556286 := by decide
theorem cert_e2422408534078 : check e2422408534078 [[],[]] .chain = true := by decide
def e2422408534498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422408534498 : Closed e2422408534498 ∧ code e2422408534498 = 11218501556706 := by decide
theorem cert_e2422408534498 : check e2422408534498 [[],[]] .chain = true := by decide
def e2422408534510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408534510 : Closed e2422408534510 ∧ code e2422408534510 = 11218501556718 := by decide
theorem cert_e2422408534510 : check e2422408534510 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408535070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408535070 : Closed e2422408535070 ∧ code e2422408535070 = 11218501557278 := by decide
theorem cert_e2422408535070 : check e2422408535070 [[],[]] .chain = true := by decide
def e2422408535266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408535266 : Closed e2422408535266 ∧ code e2422408535266 = 11218501557474 := by decide
theorem cert_e2422408535266 : check e2422408535266 [[],[]] .chain = true := by decide
def e2422408535278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408535278 : Closed e2422408535278 ∧ code e2422408535278 = 11218501557486 := by decide
theorem cert_e2422408535278 : check e2422408535278 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408535286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408535286 : Closed e2422408535286 ∧ code e2422408535286 = 11218501557494 := by decide
theorem cert_e2422408535286 : check e2422408535286 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408536110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.lam (.var 0))))))) (.var 2))))))
theorem wire_e2422408536110 : Closed e2422408536110 ∧ code e2422408536110 = 11218501558318 := by decide
theorem cert_e2422408536110 : check e2422408536110 [[],[]] .chain = true := by decide
def e2422408536302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2)))))) (.var 2))))))
theorem wire_e2422408536302 : Closed e2422408536302 ∧ code e2422408536302 = 11218501558510 := by decide
theorem cert_e2422408536302 : check e2422408536302 [[],[]] .chain = true := by decide
def e2422408536314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))) (.var 0))))))
theorem wire_e2422408536314 : Closed e2422408536314 ∧ code e2422408536314 = 11218501558522 := by decide
theorem cert_e2422408536314 : check e2422408536314 [[],[]] .chain = true := by decide
def e2422408536494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))) (.var 2))))))
theorem wire_e2422408536494 : Closed e2422408536494 ∧ code e2422408536494 = 11218501558702 := by decide
theorem cert_e2422408536494 : check e2422408536494 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408536686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408536686 : Closed e2422408536686 ∧ code e2422408536686 = 11218501558894 := by decide
theorem cert_e2422408536686 : check e2422408536686 [[],[]] .chain = true := by decide
def e2422408536698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408536698 : Closed e2422408536698 ∧ code e2422408536698 = 11218501558906 := by decide
theorem cert_e2422408536698 : check e2422408536698 [[],[]] .chain = true := by decide
def e2422408536862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.lam (.var 3)))))))
theorem wire_e2422408536862 : Closed e2422408536862 ∧ code e2422408536862 = 11218501559070 := by decide
theorem cert_e2422408536862 : check e2422408536862 [[],[]] .chain = true := by decide
def e2422408537030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))) (.lam (.var 1)))))))
theorem wire_e2422408537030 : Closed e2422408537030 ∧ code e2422408537030 = 11218501559238 := by decide
theorem cert_e2422408537030 : check e2422408537030 [[],[]] .chain = true := by decide
def e2422408537646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))) (.var 2))))))
theorem wire_e2422408537646 : Closed e2422408537646 ∧ code e2422408537646 = 11218501559854 := by decide
theorem cert_e2422408537646 : check e2422408537646 [[],[]] .chain = true := by decide
def e2422408537826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0)))))))
theorem wire_e2422408537826 : Closed e2422408537826 ∧ code e2422408537826 = 11218501560034 := by decide
theorem cert_e2422408537826 : check e2422408537826 [[],[]] .chain = true := by decide
def e2422408537838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 2))))))
theorem wire_e2422408537838 : Closed e2422408537838 ∧ code e2422408537838 = 11218501560046 := by decide
theorem cert_e2422408537838 : check e2422408537838 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408537966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1))))) (.var 2))))))
theorem wire_e2422408537966 : Closed e2422408537966 ∧ code e2422408537966 = 11218501560174 := by decide
theorem cert_e2422408537966 : check e2422408537966 [[],[]] .chain = true := by decide
def e2422408537974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))) (.var 1))))))
theorem wire_e2422408537974 : Closed e2422408537974 ∧ code e2422408537974 = 11218501560182 := by decide
theorem cert_e2422408537974 : check e2422408537974 [[],[]] .chain = true := by decide
def e2422408537994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408537994 : Closed e2422408537994 ∧ code e2422408537994 = 11218501560202 := by decide
theorem cert_e2422408537994 : check e2422408537994 [[],[]] .chain = true := by decide
def e2422408538018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422408538018 : Closed e2422408538018 ∧ code e2422408538018 = 11218501560226 := by decide
theorem cert_e2422408538018 : check e2422408538018 [[],[]] .chain = true := by decide
def e2422408538030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 2))))))
theorem wire_e2422408538030 : Closed e2422408538030 ∧ code e2422408538030 = 11218501560238 := by decide
theorem cert_e2422408538030 : check e2422408538030 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408538038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))) (.var 1))))))
theorem wire_e2422408538038 : Closed e2422408538038 ∧ code e2422408538038 = 11218501560246 := by decide
theorem cert_e2422408538038 : check e2422408538038 [[],[]] .chain = true := by decide
def e2422408538042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))) (.var 0))))))
theorem wire_e2422408538042 : Closed e2422408538042 ∧ code e2422408538042 = 11218501560250 := by decide
theorem cert_e2422408538042 : check e2422408538042 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408538174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.lam (.var 4))))))))
theorem wire_e2422408538174 : Closed e2422408538174 ∧ code e2422408538174 = 11218501560382 := by decide
theorem cert_e2422408538174 : check e2422408538174 [[],[]] .chain = true := by decide
def e2422408538594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422408538594 : Closed e2422408538594 ∧ code e2422408538594 = 11218501560802 := by decide
theorem cert_e2422408538594 : check e2422408538594 [[],[]] .chain = true := by decide
def e2422408538606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422408538606 : Closed e2422408538606 ∧ code e2422408538606 = 11218501560814 := by decide
theorem cert_e2422408538606 : check e2422408538606 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408539374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408539374 : Closed e2422408539374 ∧ code e2422408539374 = 11218501561582 := by decide
theorem cert_e2422408539374 : check e2422408539374 [[],[]] .chain = true := by decide
def e2422408539382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 1)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408539382 : Closed e2422408539382 ∧ code e2422408539382 = 11218501561590 := by decide
theorem cert_e2422408539382 : check e2422408539382 [[],[]] .chain = true := by decide
def e2422408539650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408539650 : Closed e2422408539650 ∧ code e2422408539650 = 11218501561858 := by decide
theorem cert_e2422408539650 : check e2422408539650 [[],[]] .chain = true := by decide
def e2422408539662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408539662 : Closed e2422408539662 ∧ code e2422408539662 = 11218501561870 := by decide
theorem cert_e2422408539662 : check e2422408539662 [[],[]] .chain = true := by decide
def e2422408539674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408539674 : Closed e2422408539674 ∧ code e2422408539674 = 11218501561882 := by decide
theorem cert_e2422408539674 : check e2422408539674 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408539746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408539746 : Closed e2422408539746 ∧ code e2422408539746 = 11218501561954 := by decide
theorem cert_e2422408539746 : check e2422408539746 [[],[]] .chain = true := by decide
def e2422408539758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408539758 : Closed e2422408539758 ∧ code e2422408539758 = 11218501561966 := by decide
theorem cert_e2422408539758 : check e2422408539758 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408539766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408539766 : Closed e2422408539766 ∧ code e2422408539766 = 11218501561974 := by decide
theorem cert_e2422408539766 : check e2422408539766 [[],[]] .chain = true := by decide
def e2422408539770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408539770 : Closed e2422408539770 ∧ code e2422408539770 = 11218501561978 := by decide
theorem cert_e2422408539770 : check e2422408539770 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422408540182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.lam (.var 0))))))) (.var 1))))))
theorem wire_e2422408540182 : Closed e2422408540182 ∧ code e2422408540182 = 11218501562390 := by decide
theorem cert_e2422408540182 : check e2422408540182 [[],[]] .chain = true := by decide
def e2422408540278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2)))))) (.var 1))))))
theorem wire_e2422408540278 : Closed e2422408540278 ∧ code e2422408540278 = 11218501562486 := by decide
theorem cert_e2422408540278 : check e2422408540278 [[],[]] .chain = true := by decide
def e2422408540282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))) (.var 0))))))
theorem wire_e2422408540282 : Closed e2422408540282 ∧ code e2422408540282 = 11218501562490 := by decide
theorem cert_e2422408540282 : check e2422408540282 [[],[]] .chain = true := by decide
def e2422408540374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))) (.var 1))))))
theorem wire_e2422408540374 : Closed e2422408540374 ∧ code e2422408540374 = 11218501562582 := by decide
private def t_e2422408540374 : Term := (.app (.app (.app (.app (.app (.app (.app (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)))))) (.lam (.lam (.var 1)))) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3)))))))) (.var 1))
theorem cert_e2422408540374 : ¬ IsSelfInterpreter e2422408540374 :=
  wIdentity (t := t_e2422408540374) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]]) (t := (inv e2422408540374)) (by decide)) (by decide)
def e2422408540470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408540470 : Closed e2422408540470 ∧ code e2422408540470 = 11218501562678 := by decide
theorem cert_e2422408540470 : check e2422408540470 [[],[]] .chain = true := by decide
def e2422408540474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408540474 : Closed e2422408540474 ∧ code e2422408540474 = 11218501562682 := by decide
theorem cert_e2422408540474 : check e2422408540474 [[],[]] .chain = true := by decide
def e2422408540558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.lam (.var 2)))))))
theorem wire_e2422408540558 : Closed e2422408540558 ∧ code e2422408540558 = 11218501562766 := by decide
theorem cert_e2422408540558 : check e2422408540558 [[],[]] .chain = true := by decide
def e2422408540614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.lam (.var 1)))))))
theorem wire_e2422408540614 : Closed e2422408540614 ∧ code e2422408540614 = 11218501562822 := by decide
theorem cert_e2422408540614 : check e2422408540614 [[],[]] .chain = true := by decide
def e2422408540950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))) (.var 1))))))
theorem wire_e2422408540950 : Closed e2422408540950 ∧ code e2422408540950 = 11218501563158 := by decide
theorem cert_e2422408540950 : check e2422408540950 [[],[]] .chain = true := by decide
def e2422408541026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0)))))))
theorem wire_e2422408541026 : Closed e2422408541026 ∧ code e2422408541026 = 11218501563234 := by decide
theorem cert_e2422408541026 : check e2422408541026 [[],[]] .chain = true := by decide
def e2422408541038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e2422408541038 : Closed e2422408541038 ∧ code e2422408541038 = 11218501563246 := by decide
theorem cert_e2422408541038 : check e2422408541038 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408541046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2))))) (.var 1))))))
theorem wire_e2422408541046 : Closed e2422408541046 ∧ code e2422408541046 = 11218501563254 := by decide
def e2422408541066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))) (.var 0))))))
theorem wire_e2422408541066 : Closed e2422408541066 ∧ code e2422408541066 = 11218501563274 := by decide
theorem cert_e2422408541066 : check e2422408541066 [[],[]] .chain = true := by decide
def e2422408541090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0)))))))
theorem wire_e2422408541090 : Closed e2422408541090 ∧ code e2422408541090 = 11218501563298 := by decide
theorem cert_e2422408541090 : check e2422408541090 [[],[]] .chain = true := by decide
def e2422408541102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e2422408541102 : Closed e2422408541102 ∧ code e2422408541102 = 11218501563310 := by decide
theorem cert_e2422408541102 : check e2422408541102 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408541110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))) (.var 1))))))
theorem wire_e2422408541110 : Closed e2422408541110 ∧ code e2422408541110 = 11218501563318 := by decide
theorem cert_e2422408541110 : check e2422408541110 [[],[]] .chain = true := by decide
def e2422408541114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e2422408541114 : Closed e2422408541114 ∧ code e2422408541114 = 11218501563322 := by decide
theorem cert_e2422408541114 : check e2422408541114 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408541142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0))))) (.var 1))))))
theorem wire_e2422408541142 : Closed e2422408541142 ∧ code e2422408541142 = 11218501563350 := by decide
theorem cert_e2422408541142 : check e2422408541142 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408541146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e2422408541146 : Closed e2422408541146 ∧ code e2422408541146 = 11218501563354 := by decide
theorem cert_e2422408541146 : check e2422408541146 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408541214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.lam (.var 3))))))))
theorem wire_e2422408541214 : Closed e2422408541214 ∧ code e2422408541214 = 11218501563422 := by decide
theorem cert_e2422408541214 : check e2422408541214 [[],[]] .chain = true := by decide
def e2422408541410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422408541410 : Closed e2422408541410 ∧ code e2422408541410 = 11218501563618 := by decide
theorem cert_e2422408541410 : check e2422408541410 [[],[]] .chain = true := by decide
def e2422408541422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422408541422 : Closed e2422408541422 ∧ code e2422408541422 = 11218501563630 := by decide
theorem cert_e2422408541422 : check e2422408541422 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422408541430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422408541430 : Closed e2422408541430 ∧ code e2422408541430 = 11218501563638 := by decide
theorem cert_e2422408541430 : check e2422408541430 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422408541698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422408541698 : Closed e2422408541698 ∧ code e2422408541698 = 11218501563906 := by decide
theorem cert_e2422408541698 : check e2422408541698 [[],[]] .chain = true := by decide
def e2422408541710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.lam (.var 2))))))))
theorem wire_e2422408541710 : Closed e2422408541710 ∧ code e2422408541710 = 11218501563918 := by decide
theorem cert_e2422408541710 : check e2422408541710 [[],[]] .chain = true := by decide
def e2422408541722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422408541722 : Closed e2422408541722 ∧ code e2422408541722 = 11218501563930 := by decide
theorem cert_e2422408541722 : check e2422408541722 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408541794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422408541794 : Closed e2422408541794 ∧ code e2422408541794 = 11218501564002 := by decide
theorem cert_e2422408541794 : check e2422408541794 [[],[]] .chain = true := by decide
def e2422408541806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422408541806 : Closed e2422408541806 ∧ code e2422408541806 = 11218501564014 := by decide
theorem cert_e2422408541806 : check e2422408541806 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408541814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422408541814 : Closed e2422408541814 ∧ code e2422408541814 = 11218501564022 := by decide
theorem cert_e2422408541814 : check e2422408541814 [[],[]] .chain = true := by decide
def e2422408541818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422408541818 : Closed e2422408541818 ∧ code e2422408541818 = 11218501564026 := by decide
theorem cert_e2422408541818 : check e2422408541818 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408542006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422408542006 : Closed e2422408542006 ∧ code e2422408542006 = 11218501564214 := by decide
theorem cert_e2422408542006 : check e2422408542006 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422408542010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422408542010 : Closed e2422408542010 ∧ code e2422408542010 = 11218501564218 := by decide
theorem cert_e2422408542010 : check e2422408542010 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422408540374
