import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406145032218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406145032218 : Closed e2406145032218 ∧ code e2406145032218 = 11202238054426 := by decide
theorem cert_e2406145032218 : check e2406145032218 [[]] .width = true := by decide
def e2406145032310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406145032310 : Closed e2406145032310 ∧ code e2406145032310 = 11202238054518 := by decide
theorem cert_e2406145032310 : check e2406145032310 [[]] .width = true := by decide
def e2406145032554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406145032554 : Closed e2406145032554 ∧ code e2406145032554 = 11202238054762 := by decide
theorem cert_e2406145032554 : check e2406145032554 [[]] .width = true := by decide
def e2406145032602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406145032602 : Closed e2406145032602 ∧ code e2406145032602 = 11202238054810 := by decide
theorem cert_e2406145032602 : check e2406145032602 [[]] .width = true := by decide
def e2406145033610 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406145033610 : Closed e2406145033610 ∧ code e2406145033610 = 11202238055818 := by decide
theorem cert_e2406145033610 : check e2406145033610 [[]] .width = true := by decide
def e2406145033634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406145033634 : Closed e2406145033634 ∧ code e2406145033634 = 11202238055842 := by decide
theorem cert_e2406145033634 : check e2406145033634 [[]] .width = true := by decide
def e2406145033742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406145033742 : Closed e2406145033742 ∧ code e2406145033742 = 11202238055950 := by decide
theorem cert_e2406145033742 : check e2406145033742 [[]] .width = true := by decide
def e2406145033754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406145033754 : Closed e2406145033754 ∧ code e2406145033754 = 11202238055962 := by decide
theorem cert_e2406145033754 : check e2406145033754 [[]] .width = true := by decide
def e2406145033826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406145033826 : Closed e2406145033826 ∧ code e2406145033826 = 11202238056034 := by decide
theorem cert_e2406145033826 : check e2406145033826 [[]] .width = true := by decide
def e2406145179846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406145179846 : Closed e2406145179846 ∧ code e2406145179846 = 11202238202054 := by decide
theorem cert_e2406145179846 : check e2406145179846 [[]] .width = true := by decide
def e2406145198106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145198106 : Closed e2406145198106 ∧ code e2406145198106 = 11202238220314 := by decide
theorem cert_e2406145198106 : check e2406145198106 [[]] .width = true := by decide
def e2406145204250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406145204250 : Closed e2406145204250 ∧ code e2406145204250 = 11202238226458 := by decide
theorem cert_e2406145204250 : check e2406145204250 [[]] .width = true := by decide
def e2406145204342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406145204342 : Closed e2406145204342 ∧ code e2406145204342 = 11202238226550 := by decide
theorem cert_e2406145204342 : check e2406145204342 [[]] .width = true := by decide
def e2406145204586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406145204586 : Closed e2406145204586 ∧ code e2406145204586 = 11202238226794 := by decide
theorem cert_e2406145204586 : check e2406145204586 [[]] .width = true := by decide
def e2406145204634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406145204634 : Closed e2406145204634 ∧ code e2406145204634 = 11202238226842 := by decide
theorem cert_e2406145204634 : check e2406145204634 [[]] .width = true := by decide
def e2406145208518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406145208518 : Closed e2406145208518 ∧ code e2406145208518 = 11202238230726 := by decide
theorem cert_e2406145208518 : check e2406145208518 [[]] .width = true := by decide
def e2406145210394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145210394 : Closed e2406145210394 ∧ code e2406145210394 = 11202238232602 := by decide
theorem cert_e2406145210394 : check e2406145210394 [[]] .width = true := by decide
def e2406145222682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145222682 : Closed e2406145222682 ∧ code e2406145222682 = 11202238244890 := by decide
theorem cert_e2406145222682 : check e2406145222682 [[]] .width = true := by decide
def e2406145224218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406145224218 : Closed e2406145224218 ∧ code e2406145224218 = 11202238246426 := by decide
theorem cert_e2406145224218 : check e2406145224218 [[]] .width = true := by decide
def e2406145227290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406145227290 : Closed e2406145227290 ∧ code e2406145227290 = 11202238249498 := by decide
theorem cert_e2406145227290 : check e2406145227290 [[]] .width = true := by decide
def e2406145228826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406145228826 : Closed e2406145228826 ∧ code e2406145228826 = 11202238251034 := by decide
theorem cert_e2406145228826 : check e2406145228826 [[]] .width = true := by decide
def e2406145228918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406145228918 : Closed e2406145228918 ∧ code e2406145228918 = 11202238251126 := by decide
theorem cert_e2406145228918 : check e2406145228918 [[]] .width = true := by decide
def e2406145229162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406145229162 : Closed e2406145229162 ∧ code e2406145229162 = 11202238251370 := by decide
theorem cert_e2406145229162 : check e2406145229162 [[]] .width = true := by decide
def e2406145229210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406145229210 : Closed e2406145229210 ∧ code e2406145229210 = 11202238251418 := by decide
theorem cert_e2406145229210 : check e2406145229210 [[]] .width = true := by decide
def e2406145230218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406145230218 : Closed e2406145230218 ∧ code e2406145230218 = 11202238252426 := by decide
theorem cert_e2406145230218 : check e2406145230218 [[]] .width = true := by decide
def e2406145230242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406145230242 : Closed e2406145230242 ∧ code e2406145230242 = 11202238252450 := by decide
theorem cert_e2406145230242 : check e2406145230242 [[]] .width = true := by decide
def e2406145230350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406145230350 : Closed e2406145230350 ∧ code e2406145230350 = 11202238252558 := by decide
theorem cert_e2406145230350 : check e2406145230350 [[]] .width = true := by decide
def e2406145230362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406145230362 : Closed e2406145230362 ∧ code e2406145230362 = 11202238252570 := by decide
theorem cert_e2406145230362 : check e2406145230362 [[]] .width = true := by decide
def e2406145230434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406145230434 : Closed e2406145230434 ∧ code e2406145230434 = 11202238252642 := by decide
theorem cert_e2406145230434 : check e2406145230434 [[]] .width = true := by decide
def e2406145245382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406145245382 : Closed e2406145245382 ∧ code e2406145245382 = 11202238267590 := by decide
theorem cert_e2406145245382 : check e2406145245382 [[]] .width = true := by decide
def e2406145253402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406145253402 : Closed e2406145253402 ∧ code e2406145253402 = 11202238275610 := by decide
theorem cert_e2406145253402 : check e2406145253402 [[]] .width = true := by decide
def e2406145253494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406145253494 : Closed e2406145253494 ∧ code e2406145253494 = 11202238275702 := by decide
theorem cert_e2406145253494 : check e2406145253494 [[]] .width = true := by decide
def e2406145253738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406145253738 : Closed e2406145253738 ∧ code e2406145253738 = 11202238275946 := by decide
theorem cert_e2406145253738 : check e2406145253738 [[]] .width = true := by decide
def e2406145253786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406145253786 : Closed e2406145253786 ∧ code e2406145253786 = 11202238275994 := by decide
theorem cert_e2406145253786 : check e2406145253786 [[]] .width = true := by decide
def e2406145439770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145439770 : Closed e2406145439770 ∧ code e2406145439770 = 11202238461978 := by decide
theorem cert_e2406145439770 : check e2406145439770 [[]] .width = true := by decide
def e2406145704134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406145704134 : Closed e2406145704134 ∧ code e2406145704134 = 11202238726342 := by decide
theorem cert_e2406145704134 : check e2406145704134 [[]] .width = true := by decide
def e2406145792026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145792026 : Closed e2406145792026 ∧ code e2406145792026 = 11202238814234 := by decide
theorem cert_e2406145792026 : check e2406145792026 [[]] .width = true := by decide
def e2406145802438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406145802438 : Closed e2406145802438 ∧ code e2406145802438 = 11202238824646 := by decide
theorem cert_e2406145802438 : check e2406145802438 [[]] .width = true := by decide
def e2406145861658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145861658 : Closed e2406145861658 ∧ code e2406145861658 = 11202238883866 := by decide
theorem cert_e2406145861658 : check e2406145861658 [[]] .width = true := by decide
def e2406145892378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406145892378 : Closed e2406145892378 ∧ code e2406145892378 = 11202238914586 := by decide
theorem cert_e2406145892378 : check e2406145892378 [[]] .width = true := by decide
def e2406145892470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406145892470 : Closed e2406145892470 ∧ code e2406145892470 = 11202238914678 := by decide
theorem cert_e2406145892470 : check e2406145892470 [[]] .width = true := by decide
def e2406145892714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406145892714 : Closed e2406145892714 ∧ code e2406145892714 = 11202238914922 := by decide
theorem cert_e2406145892714 : check e2406145892714 [[]] .width = true := by decide
def e2406145892762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406145892762 : Closed e2406145892762 ∧ code e2406145892762 = 11202238914970 := by decide
theorem cert_e2406145892762 : check e2406145892762 [[]] .width = true := by decide
def e2406145904838 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406145904838 : Closed e2406145904838 ∧ code e2406145904838 = 11202238927046 := by decide
theorem cert_e2406145904838 : check e2406145904838 [[]] .width = true := by decide
def e2406145906714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145906714 : Closed e2406145906714 ∧ code e2406145906714 = 11202238928922 := by decide
theorem cert_e2406145906714 : check e2406145906714 [[]] .width = true := by decide
def e2406145910810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145910810 : Closed e2406145910810 ∧ code e2406145910810 = 11202238933018 := by decide
theorem cert_e2406145910810 : check e2406145910810 [[]] .width = true := by decide
def e2406145959962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145959962 : Closed e2406145959962 ∧ code e2406145959962 = 11202238982170 := by decide
theorem cert_e2406145959962 : check e2406145959962 [[]] .width = true := by decide
def e2406145961498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406145961498 : Closed e2406145961498 ∧ code e2406145961498 = 11202238983706 := by decide
theorem cert_e2406145961498 : check e2406145961498 [[]] .width = true := by decide
def e2406145964570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406145964570 : Closed e2406145964570 ∧ code e2406145964570 = 11202238986778 := by decide
theorem cert_e2406145964570 : check e2406145964570 [[]] .width = true := by decide
def e2406145976858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406145976858 : Closed e2406145976858 ∧ code e2406145976858 = 11202238999066 := by decide
theorem cert_e2406145976858 : check e2406145976858 [[]] .width = true := by decide
def e2406145984538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145984538 : Closed e2406145984538 ∧ code e2406145984538 = 11202239006746 := by decide
theorem cert_e2406145984538 : check e2406145984538 [[]] .width = true := by decide
def e2406145990682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406145990682 : Closed e2406145990682 ∧ code e2406145990682 = 11202239012890 := by decide
theorem cert_e2406145990682 : check e2406145990682 [[]] .width = true := by decide
def e2406145990774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406145990774 : Closed e2406145990774 ∧ code e2406145990774 = 11202239012982 := by decide
theorem cert_e2406145990774 : check e2406145990774 [[]] .width = true := by decide
def e2406145991018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406145991018 : Closed e2406145991018 ∧ code e2406145991018 = 11202239013226 := by decide
theorem cert_e2406145991018 : check e2406145991018 [[]] .width = true := by decide
def e2406145991066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406145991066 : Closed e2406145991066 ∧ code e2406145991066 = 11202239013274 := by decide
theorem cert_e2406145991066 : check e2406145991066 [[]] .width = true := by decide
def e2406145994950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406145994950 : Closed e2406145994950 ∧ code e2406145994950 = 11202239017158 := by decide
theorem cert_e2406145994950 : check e2406145994950 [[]] .width = true := by decide
def e2406145996826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406145996826 : Closed e2406145996826 ∧ code e2406145996826 = 11202239019034 := by decide
theorem cert_e2406145996826 : check e2406145996826 [[]] .width = true := by decide
def e2406146009114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406146009114 : Closed e2406146009114 ∧ code e2406146009114 = 11202239031322 := by decide
theorem cert_e2406146009114 : check e2406146009114 [[]] .width = true := by decide
def e2406146010650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406146010650 : Closed e2406146010650 ∧ code e2406146010650 = 11202239032858 := by decide
theorem cert_e2406146010650 : check e2406146010650 [[]] .width = true := by decide
def e2406146013722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406146013722 : Closed e2406146013722 ∧ code e2406146013722 = 11202239035930 := by decide
theorem cert_e2406146013722 : check e2406146013722 [[]] .width = true := by decide
def e2406146015258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406146015258 : Closed e2406146015258 ∧ code e2406146015258 = 11202239037466 := by decide
theorem cert_e2406146015258 : check e2406146015258 [[]] .width = true := by decide
def e2406146015350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406146015350 : Closed e2406146015350 ∧ code e2406146015350 = 11202239037558 := by decide
theorem cert_e2406146015350 : check e2406146015350 [[]] .width = true := by decide
def e2406146015594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406146015594 : Closed e2406146015594 ∧ code e2406146015594 = 11202239037802 := by decide
theorem cert_e2406146015594 : check e2406146015594 [[]] .width = true := by decide
def e2406146015642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406146015642 : Closed e2406146015642 ∧ code e2406146015642 = 11202239037850 := by decide
theorem cert_e2406146015642 : check e2406146015642 [[]] .width = true := by decide
def e2406146016650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406146016650 : Closed e2406146016650 ∧ code e2406146016650 = 11202239038858 := by decide
theorem cert_e2406146016650 : check e2406146016650 [[]] .width = true := by decide
def e2406146016674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406146016674 : Closed e2406146016674 ∧ code e2406146016674 = 11202239038882 := by decide
theorem cert_e2406146016674 : check e2406146016674 [[]] .width = true := by decide
def e2406146016782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406146016782 : Closed e2406146016782 ∧ code e2406146016782 = 11202239038990 := by decide
theorem cert_e2406146016782 : check e2406146016782 [[]] .width = true := by decide
def e2406146016794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406146016794 : Closed e2406146016794 ∧ code e2406146016794 = 11202239039002 := by decide
theorem cert_e2406146016794 : check e2406146016794 [[]] .width = true := by decide
def e2406146016866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406146016866 : Closed e2406146016866 ∧ code e2406146016866 = 11202239039074 := by decide
theorem cert_e2406146016866 : check e2406146016866 [[]] .width = true := by decide
def e2406146031814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406146031814 : Closed e2406146031814 ∧ code e2406146031814 = 11202239054022 := by decide
theorem cert_e2406146031814 : check e2406146031814 [[]] .width = true := by decide
def e2406146039834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406146039834 : Closed e2406146039834 ∧ code e2406146039834 = 11202239062042 := by decide
theorem cert_e2406146039834 : check e2406146039834 [[]] .width = true := by decide
def e2406146039926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406146039926 : Closed e2406146039926 ∧ code e2406146039926 = 11202239062134 := by decide
theorem cert_e2406146039926 : check e2406146039926 [[]] .width = true := by decide
def e2406146040170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406146040170 : Closed e2406146040170 ∧ code e2406146040170 = 11202239062378 := by decide
theorem cert_e2406146040170 : check e2406146040170 [[]] .width = true := by decide
def e2406146040218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406146040218 : Closed e2406146040218 ∧ code e2406146040218 = 11202239062426 := by decide
theorem cert_e2406146040218 : check e2406146040218 [[]] .width = true := by decide
def e2406146054170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406146054170 : Closed e2406146054170 ∧ code e2406146054170 = 11202239076378 := by decide
theorem cert_e2406146054170 : check e2406146054170 [[]] .width = true := by decide
def e2406146064582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406146064582 : Closed e2406146064582 ∧ code e2406146064582 = 11202239086790 := by decide
theorem cert_e2406146064582 : check e2406146064582 [[]] .width = true := by decide
def e2406146087450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406146087450 : Closed e2406146087450 ∧ code e2406146087450 = 11202239109658 := by decide
private def t_e2406146087450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406146087450 : ¬ IsSelfInterpreter e2406146087450 :=
  wSource (t := t_e2406146087450) (replay_sound (ps := []) (t := e2406146087450) (by decide)) (by decide)
def e2406146088986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406146088986 : Closed e2406146088986 ∧ code e2406146088986 = 11202239111194 := by decide
theorem cert_e2406146088986 : check e2406146088986 [[]] .width = true := by decide
def e2406146089078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406146089078 : Closed e2406146089078 ∧ code e2406146089078 = 11202239111286 := by decide
private def t_e2406146089078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2406146089078 : ¬ IsSelfInterpreter e2406146089078 :=
  wSource (t := t_e2406146089078) (replay_sound (ps := []) (t := e2406146089078) (by decide)) (by decide)
def e2406146089322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406146089322 : Closed e2406146089322 ∧ code e2406146089322 = 11202239111530 := by decide
private def t_e2406146089322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2406146089322 : ¬ IsSelfInterpreter e2406146089322 :=
  wSource (t := t_e2406146089322) (replay_sound (ps := []) (t := e2406146089322) (by decide)) (by decide)
def e2406146089370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406146089370 : Closed e2406146089370 ∧ code e2406146089370 = 11202239111578 := by decide
private def t_e2406146089370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2406146089370 : ¬ IsSelfInterpreter e2406146089370 :=
  wSource (t := t_e2406146089370) (replay_sound (ps := []) (t := e2406146089370) (by decide)) (by decide)
def e2406146629658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406146629658 : Closed e2406146629658 ∧ code e2406146629658 = 11202239651866 := by decide
theorem cert_e2406146629658 : check e2406146629658 [[]] .width = true := by decide
def e2406146629750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406146629750 : Closed e2406146629750 ∧ code e2406146629750 = 11202239651958 := by decide
theorem cert_e2406146629750 : check e2406146629750 [[]] .width = true := by decide
def e2406146629994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406146629994 : Closed e2406146629994 ∧ code e2406146629994 = 11202239652202 := by decide
theorem cert_e2406146629994 : check e2406146629994 [[]] .width = true := by decide
def e2406146630042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406146630042 : Closed e2406146630042 ∧ code e2406146630042 = 11202239652250 := by decide
theorem cert_e2406146630042 : check e2406146630042 [[]] .width = true := by decide
def e2406146830534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406146830534 : Closed e2406146830534 ∧ code e2406146830534 = 11202239852742 := by decide
theorem cert_e2406146830534 : check e2406146830534 [[]] .width = true := by decide
def e2406146887878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406146887878 : Closed e2406146887878 ∧ code e2406146887878 = 11202239910086 := by decide
theorem cert_e2406146887878 : check e2406146887878 [[]] .width = true := by decide
def e2406146891290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406146891290 : Closed e2406146891290 ∧ code e2406146891290 = 11202239913498 := by decide
theorem cert_e2406146891290 : check e2406146891290 [[]] .width = true := by decide
def e2406147358918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2406147358918 : Closed e2406147358918 ∧ code e2406147358918 = 11202240381126 := by decide
theorem cert_e2406147358918 : check e2406147358918 [[]] .width = true := by decide
def e2406147359446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2406147359446 : Closed e2406147359446 ∧ code e2406147359446 = 11202240381654 := by decide
theorem cert_e2406147359446 : check e2406147359446 [[]] .width = true := by decide
def e2406147359450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2406147359450 : Closed e2406147359450 ∧ code e2406147359450 = 11202240381658 := by decide
theorem cert_e2406147359450 : check e2406147359450 [[]] .width = true := by decide
def e2406147359466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2406147359466 : Closed e2406147359466 ∧ code e2406147359466 = 11202240381674 := by decide
theorem cert_e2406147359466 : check e2406147359466 [[]] .width = true := by decide
def e2406147359542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2406147359542 : Closed e2406147359542 ∧ code e2406147359542 = 11202240381750 := by decide
theorem cert_e2406147359542 : check e2406147359542 [[]] .width = true := by decide
def e2406147359546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2406147359546 : Closed e2406147359546 ∧ code e2406147359546 = 11202240381754 := by decide
theorem cert_e2406147359546 : check e2406147359546 [[]] .width = true := by decide
def e2406147359630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2406147359630 : Closed e2406147359630 ∧ code e2406147359630 = 11202240381838 := by decide
theorem cert_e2406147359630 : check e2406147359630 [[]] .width = true := by decide
def e2406147359642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2406147359642 : Closed e2406147359642 ∧ code e2406147359642 = 11202240381850 := by decide
theorem cert_e2406147359642 : check e2406147359642 [[]] .width = true := by decide
def e2406147361562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2406147361562 : Closed e2406147361562 ∧ code e2406147361562 = 11202240383770 := by decide
theorem cert_e2406147361562 : check e2406147361562 [[]] .width = true := by decide
def e2406147361606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2406147361606 : Closed e2406147361606 ∧ code e2406147361606 = 11202240383814 := by decide
theorem cert_e2406147361606 : check e2406147361606 [[]] .width = true := by decide
def e2406147361846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2406147361846 : Closed e2406147361846 ∧ code e2406147361846 = 11202240384054 := by decide
theorem cert_e2406147361846 : check e2406147361846 [[]] .width = true := by decide
def e2406147361850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2406147361850 : Closed e2406147361850 ∧ code e2406147361850 = 11202240384058 := by decide
theorem cert_e2406147361850 : check e2406147361850 [[]] .width = true := by decide
def e2406147361990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406147361990 : Closed e2406147361990 ∧ code e2406147361990 = 11202240384198 := by decide
theorem cert_e2406147361990 : check e2406147361990 [[]] .width = true := by decide
def e2406147864602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406147864602 : Closed e2406147864602 ∧ code e2406147864602 = 11202240886810 := by decide
theorem cert_e2406147864602 : check e2406147864602 [[]] .width = true := by decide
def e2406147876890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406147876890 : Closed e2406147876890 ∧ code e2406147876890 = 11202240899098 := by decide
theorem cert_e2406147876890 : check e2406147876890 [[]] .width = true := by decide
def e2406147878426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406147878426 : Closed e2406147878426 ∧ code e2406147878426 = 11202240900634 := by decide
theorem cert_e2406147878426 : check e2406147878426 [[]] .width = true := by decide
def e2406147926042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406147926042 : Closed e2406147926042 ∧ code e2406147926042 = 11202240948250 := by decide
theorem cert_e2406147926042 : check e2406147926042 [[]] .width = true := by decide
def e2406147927578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406147927578 : Closed e2406147927578 ∧ code e2406147927578 = 11202240949786 := by decide
theorem cert_e2406147927578 : check e2406147927578 [[]] .width = true := by decide
def e2406147930650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406147930650 : Closed e2406147930650 ∧ code e2406147930650 = 11202240952858 := by decide
theorem cert_e2406147930650 : check e2406147930650 [[]] .width = true := by decide
def e2406148010182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406148010182 : Closed e2406148010182 ∧ code e2406148010182 = 11202241032390 := by decide
theorem cert_e2406148010182 : check e2406148010182 [[]] .width = true := by decide
def e2406148061210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406148061210 : Closed e2406148061210 ∧ code e2406148061210 = 11202241083418 := by decide
theorem cert_e2406148061210 : check e2406148061210 [[]] .width = true := by decide
def e2406148073498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406148073498 : Closed e2406148073498 ∧ code e2406148073498 = 11202241095706 := by decide
theorem cert_e2406148073498 : check e2406148073498 [[]] .width = true := by decide
def e2406148075034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406148075034 : Closed e2406148075034 ∧ code e2406148075034 = 11202241097242 := by decide
theorem cert_e2406148075034 : check e2406148075034 [[]] .width = true := by decide
def e2406148177946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406148177946 : Closed e2406148177946 ∧ code e2406148177946 = 11202241200154 := by decide
theorem cert_e2406148177946 : check e2406148177946 [[]] .width = true := by decide
def e2406148178038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406148178038 : Closed e2406148178038 ∧ code e2406148178038 = 11202241200246 := by decide
theorem cert_e2406148178038 : check e2406148178038 [[]] .width = true := by decide
def e2406148178282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406148178282 : Closed e2406148178282 ∧ code e2406148178282 = 11202241200490 := by decide
theorem cert_e2406148178282 : check e2406148178282 [[]] .width = true := by decide
def e2406148178330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406148178330 : Closed e2406148178330 ∧ code e2406148178330 = 11202241200538 := by decide
theorem cert_e2406148178330 : check e2406148178330 [[]] .width = true := by decide
def e2406148179338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406148179338 : Closed e2406148179338 ∧ code e2406148179338 = 11202241201546 := by decide
theorem cert_e2406148179338 : check e2406148179338 [[]] .width = true := by decide
def e2406148179362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406148179362 : Closed e2406148179362 ∧ code e2406148179362 = 11202241201570 := by decide
theorem cert_e2406148179362 : check e2406148179362 [[]] .width = true := by decide
def e2406148179470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406148179470 : Closed e2406148179470 ∧ code e2406148179470 = 11202241201678 := by decide
theorem cert_e2406148179470 : check e2406148179470 [[]] .width = true := by decide
def e2406148179482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406148179482 : Closed e2406148179482 ∧ code e2406148179482 = 11202241201690 := by decide
theorem cert_e2406148179482 : check e2406148179482 [[]] .width = true := by decide
def e2406148179554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406148179554 : Closed e2406148179554 ∧ code e2406148179554 = 11202241201762 := by decide
theorem cert_e2406148179554 : check e2406148179554 [[]] .width = true := by decide
def e2406148325574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406148325574 : Closed e2406148325574 ∧ code e2406148325574 = 11202241347782 := by decide
theorem cert_e2406148325574 : check e2406148325574 [[]] .width = true := by decide
def e2406148343834 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0)))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406148343834 : Closed e2406148343834 ∧ code e2406148343834 = 11202241366042 := by decide
theorem cert_e2406148343834 : check e2406148343834 [[]] .width = true := by decide
def e2406148349978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406148349978 : Closed e2406148349978 ∧ code e2406148349978 = 11202241372186 := by decide
theorem cert_e2406148349978 : check e2406148349978 [[]] .width = true := by decide
def e2406148350070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406148350070 : Closed e2406148350070 ∧ code e2406148350070 = 11202241372278 := by decide
theorem cert_e2406148350070 : check e2406148350070 [[]] .width = true := by decide
def e2406148350314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406148350314 : Closed e2406148350314 ∧ code e2406148350314 = 11202241372522 := by decide
theorem cert_e2406148350314 : check e2406148350314 [[]] .width = true := by decide
def e2406148350362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406148350362 : Closed e2406148350362 ∧ code e2406148350362 = 11202241372570 := by decide
theorem cert_e2406148350362 : check e2406148350362 [[]] .width = true := by decide
def e2406148354246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406148354246 : Closed e2406148354246 ∧ code e2406148354246 = 11202241376454 := by decide
theorem cert_e2406148354246 : check e2406148354246 [[]] .width = true := by decide
def e2406148356122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406148356122 : Closed e2406148356122 ∧ code e2406148356122 = 11202241378330 := by decide
theorem cert_e2406148356122 : check e2406148356122 [[]] .width = true := by decide
def e2406148368410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406148368410 : Closed e2406148368410 ∧ code e2406148368410 = 11202241390618 := by decide
theorem cert_e2406148368410 : check e2406148368410 [[]] .width = true := by decide
def e2406148369946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406148369946 : Closed e2406148369946 ∧ code e2406148369946 = 11202241392154 := by decide
theorem cert_e2406148369946 : check e2406148369946 [[]] .width = true := by decide
def e2406148373018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406148373018 : Closed e2406148373018 ∧ code e2406148373018 = 11202241395226 := by decide
theorem cert_e2406148373018 : check e2406148373018 [[]] .width = true := by decide
def e2406148374554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406148374554 : Closed e2406148374554 ∧ code e2406148374554 = 11202241396762 := by decide
theorem cert_e2406148374554 : check e2406148374554 [[]] .width = true := by decide
def e2406148374646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406148374646 : Closed e2406148374646 ∧ code e2406148374646 = 11202241396854 := by decide
theorem cert_e2406148374646 : check e2406148374646 [[]] .width = true := by decide
def e2406148374890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406148374890 : Closed e2406148374890 ∧ code e2406148374890 = 11202241397098 := by decide
theorem cert_e2406148374890 : check e2406148374890 [[]] .width = true := by decide
def e2406148374938 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406148374938 : Closed e2406148374938 ∧ code e2406148374938 = 11202241397146 := by decide
theorem cert_e2406148374938 : check e2406148374938 [[]] .width = true := by decide
def e2406148375946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406148375946 : Closed e2406148375946 ∧ code e2406148375946 = 11202241398154 := by decide
theorem cert_e2406148375946 : check e2406148375946 [[]] .width = true := by decide
def e2406148375970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406148375970 : Closed e2406148375970 ∧ code e2406148375970 = 11202241398178 := by decide
theorem cert_e2406148375970 : check e2406148375970 [[]] .width = true := by decide
def e2406148376078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406148376078 : Closed e2406148376078 ∧ code e2406148376078 = 11202241398286 := by decide
theorem cert_e2406148376078 : check e2406148376078 [[]] .width = true := by decide
def e2406148376090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406148376090 : Closed e2406148376090 ∧ code e2406148376090 = 11202241398298 := by decide
theorem cert_e2406148376090 : check e2406148376090 [[]] .width = true := by decide
def e2406148376162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406148376162 : Closed e2406148376162 ∧ code e2406148376162 = 11202241398370 := by decide
theorem cert_e2406148376162 : check e2406148376162 [[]] .width = true := by decide
def e2406148391110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2406148391110 : Closed e2406148391110 ∧ code e2406148391110 = 11202241413318 := by decide
theorem cert_e2406148391110 : check e2406148391110 [[]] .width = true := by decide
def e2406148399130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406148399130 : Closed e2406148399130 ∧ code e2406148399130 = 11202241421338 := by decide
theorem cert_e2406148399130 : check e2406148399130 [[]] .width = true := by decide
def e2406148399222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406148399222 : Closed e2406148399222 ∧ code e2406148399222 = 11202241421430 := by decide
theorem cert_e2406148399222 : check e2406148399222 [[]] .width = true := by decide
def e2406148399466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406148399466 : Closed e2406148399466 ∧ code e2406148399466 = 11202241421674 := by decide
theorem cert_e2406148399466 : check e2406148399466 [[]] .width = true := by decide
def e2406148399514 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406148399514 : Closed e2406148399514 ∧ code e2406148399514 = 11202241421722 := by decide
theorem cert_e2406148399514 : check e2406148399514 [[]] .width = true := by decide
def e2406150045722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2406150045722 : Closed e2406150045722 ∧ code e2406150045722 = 11202243067930 := by decide
theorem cert_e2406150045722 : check e2406150045722 [[]] .width = true := by decide
def e2406150045814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2406150045814 : Closed e2406150045814 ∧ code e2406150045814 = 11202243068022 := by decide
theorem cert_e2406150045814 : check e2406150045814 [[]] .width = true := by decide
def e2406150046058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2406150046058 : Closed e2406150046058 ∧ code e2406150046058 = 11202243068266 := by decide
theorem cert_e2406150046058 : check e2406150046058 [[]] .width = true := by decide
def e2406150046106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2406150046106 : Closed e2406150046106 ∧ code e2406150046106 = 11202243068314 := by decide
theorem cert_e2406150046106 : check e2406150046106 [[]] .width = true := by decide
def e2406150046190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.var 2)))))))
theorem wire_e2406150046190 : Closed e2406150046190 ∧ code e2406150046190 = 11202243068398 := by decide
theorem cert_e2406150046190 : check e2406150046190 [[]] .width = true := by decide
def e2406150047114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))
theorem wire_e2406150047114 : Closed e2406150047114 ∧ code e2406150047114 = 11202243069322 := by decide
theorem cert_e2406150047114 : check e2406150047114 [[]] .width = true := by decide
def e2406150047138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2406150047138 : Closed e2406150047138 ∧ code e2406150047138 = 11202243069346 := by decide
theorem cert_e2406150047138 : check e2406150047138 [[]] .width = true := by decide
def e2406150047150 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e2406150047150 : Closed e2406150047150 ∧ code e2406150047150 = 11202243069358 := by decide
theorem cert_e2406150047150 : check e2406150047150 [[]] .width = true := by decide
def e2406150047158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 1))))))
theorem wire_e2406150047158 : Closed e2406150047158 ∧ code e2406150047158 = 11202243069366 := by decide
theorem cert_e2406150047158 : check e2406150047158 [[]] .width = true := by decide
def e2406150047162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e2406150047162 : Closed e2406150047162 ∧ code e2406150047162 = 11202243069370 := by decide
theorem cert_e2406150047162 : check e2406150047162 [[]] .width = true := by decide
def e2406150047190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1))))))
theorem wire_e2406150047190 : Closed e2406150047190 ∧ code e2406150047190 = 11202243069398 := by decide
theorem cert_e2406150047190 : check e2406150047190 [[]] .width = true := by decide
def e2406150047194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 0))))))
theorem wire_e2406150047194 : Closed e2406150047194 ∧ code e2406150047194 = 11202243069402 := by decide
theorem cert_e2406150047194 : check e2406150047194 [[]] .width = true := by decide
def e2406150047210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e2406150047210 : Closed e2406150047210 ∧ code e2406150047210 = 11202243069418 := by decide
theorem cert_e2406150047210 : check e2406150047210 [[]] .width = true := by decide
def e2406150047246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.var 2))))))))
theorem wire_e2406150047246 : Closed e2406150047246 ∧ code e2406150047246 = 11202243069454 := by decide
theorem cert_e2406150047246 : check e2406150047246 [[]] .width = true := by decide
def e2406150047258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406150047258 : Closed e2406150047258 ∧ code e2406150047258 = 11202243069466 := by decide
theorem cert_e2406150047258 : check e2406150047258 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2406146087450
#print axioms Blc.Floor43.cert_e2406146089078
#print axioms Blc.Floor43.cert_e2406146089322
#print axioms Blc.Floor43.cert_e2406146089370
