import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e611630311222 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e611630311222 : Closed e611630311222 ∧ code e611630311222 = 9407723333430 := by decide
theorem cert_e611630311222 : check e611630311222 [[.under]] .sourceHead = true := by decide
def e611630311226 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e611630311226 : Closed e611630311226 ∧ code e611630311226 = 9407723333434 := by decide
theorem cert_e611630311226 : check e611630311226 [[.under]] .sourceHead = true := by decide
def e611630314198 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e611630314198 : Closed e611630314198 ∧ code e611630314198 = 9407723336406 := by decide
theorem cert_e611630314198 : check e611630314198 [[.under]] .sourceHead = true := by decide
def e611630314202 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e611630314202 : Closed e611630314202 ∧ code e611630314202 = 9407723336410 := by decide
theorem cert_e611630314202 : check e611630314202 [[.under]] .sourceHead = true := by decide
def e611630314218 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e611630314218 : Closed e611630314218 ∧ code e611630314218 = 9407723336426 := by decide
theorem cert_e611630314218 : check e611630314218 [[.under]] .sourceHead = true := by decide
def e611630314294 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e611630314294 : Closed e611630314294 ∧ code e611630314294 = 9407723336502 := by decide
theorem cert_e611630314294 : check e611630314294 [[.under]] .sourceHead = true := by decide
def e611630314298 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e611630314298 : Closed e611630314298 ∧ code e611630314298 = 9407723336506 := by decide
theorem cert_e611630314298 : check e611630314298 [[.under]] .sourceHead = true := by decide
def e611630314394 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e611630314394 : Closed e611630314394 ∧ code e611630314394 = 9407723336602 := by decide
theorem cert_e611630314394 : check e611630314394 [[.under]] .sourceHead = true := by decide
def e611630539630 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e611630539630 : Closed e611630539630 ∧ code e611630539630 = 9407723561838 := by decide
theorem cert_e611630539630 : check e611630539630 [[.under]] .sourceHead = true := by decide
def e611630539638 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e611630539638 : Closed e611630539638 ∧ code e611630539638 = 9407723561846 := by decide
theorem cert_e611630539638 : check e611630539638 [[.under]] .sourceHead = true := by decide
def e611630539694 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e611630539694 : Closed e611630539694 ∧ code e611630539694 = 9407723561902 := by decide
theorem cert_e611630539694 : check e611630539694 [[.under]] .sourceHead = true := by decide
def e611630539706 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e611630539706 : Closed e611630539706 ∧ code e611630539706 = 9407723561914 := by decide
theorem cert_e611630539706 : check e611630539706 [[.under]] .sourceHead = true := by decide
def e611630539734 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e611630539734 : Closed e611630539734 ∧ code e611630539734 = 9407723561942 := by decide
theorem cert_e611630539734 : check e611630539734 [[.under]] .sourceHead = true := by decide
def e611630539738 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e611630539738 : Closed e611630539738 ∧ code e611630539738 = 9407723561946 := by decide
theorem cert_e611630539738 : check e611630539738 [[.under]] .sourceHead = true := by decide
def e611630541038 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e611630541038 : Closed e611630541038 ∧ code e611630541038 = 9407723563246 := by decide
theorem cert_e611630541038 : check e611630541038 [[.under]] .sourceHead = true := by decide
def e611630541046 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e611630541046 : Closed e611630541046 ∧ code e611630541046 = 9407723563254 := by decide
theorem cert_e611630541046 : check e611630541046 [[.under]] .sourceHead = true := by decide
def e611630541598 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e611630541598 : Closed e611630541598 ∧ code e611630541598 = 9407723563806 := by decide
theorem cert_e611630541598 : check e611630541598 [[.under]] .sourceHead = true := by decide
def e611630541710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e611630541710 : Closed e611630541710 ∧ code e611630541710 = 9407723563918 := by decide
theorem cert_e611630541710 : check e611630541710 [[.under]] .sourceHead = true := by decide
def e611630541934 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e611630541934 : Closed e611630541934 ∧ code e611630541934 = 9407723564142 := by decide
theorem cert_e611630541934 : check e611630541934 [[.under]] .sourceHead = true := by decide
def e611630541946 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e611630541946 : Closed e611630541946 ∧ code e611630541946 = 9407723564154 := by decide
theorem cert_e611630541946 : check e611630541946 [[.under]] .sourceHead = true := by decide
def e611630542110 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e611630542110 : Closed e611630542110 ∧ code e611630542110 = 9407723564318 := by decide
theorem cert_e611630542110 : check e611630542110 [[.under]] .sourceHead = true := by decide
def e611630542278 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e611630542278 : Closed e611630542278 ∧ code e611630542278 = 9407723564486 := by decide
theorem cert_e611630542278 : check e611630542278 [[.under]] .sourceHead = true := by decide
def e611630542390 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e611630542390 : Closed e611630542390 ∧ code e611630542390 = 9407723564598 := by decide
theorem cert_e611630542390 : check e611630542390 [[.under]] .sourceHead = true := by decide
def e611630542394 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e611630542394 : Closed e611630542394 ∧ code e611630542394 = 9407723564602 := by decide
theorem cert_e611630542394 : check e611630542394 [[.under]] .sourceHead = true := by decide
def e611630542478 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e611630542478 : Closed e611630542478 ∧ code e611630542478 = 9407723564686 := by decide
theorem cert_e611630542478 : check e611630542478 [[.under]] .sourceHead = true := by decide
def e611630542534 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e611630542534 : Closed e611630542534 ∧ code e611630542534 = 9407723564742 := by decide
theorem cert_e611630542534 : check e611630542534 [[.under]] .sourceHead = true := by decide
def e611630543278 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e611630543278 : Closed e611630543278 ∧ code e611630543278 = 9407723565486 := by decide
theorem cert_e611630543278 : check e611630543278 [[.under]] .sourceHead = true := by decide
def e611630543290 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e611630543290 : Closed e611630543290 ∧ code e611630543290 = 9407723565498 := by decide
theorem cert_e611630543290 : check e611630543290 [[.under]] .sourceHead = true := by decide
def e611630543338 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e611630543338 : Closed e611630543338 ∧ code e611630543338 = 9407723565546 := by decide
theorem cert_e611630543338 : check e611630543338 [[.under]] .sourceHead = true := by decide
def e611630543982 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e611630543982 : Closed e611630543982 ∧ code e611630543982 = 9407723566190 := by decide
theorem cert_e611630543982 : check e611630543982 [[.under]] .sourceHead = true := by decide
def e611630543994 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e611630543994 : Closed e611630543994 ∧ code e611630543994 = 9407723566202 := by decide
theorem cert_e611630543994 : check e611630543994 [[.under]] .sourceHead = true := by decide
def e611630544158 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e611630544158 : Closed e611630544158 ∧ code e611630544158 = 9407723566366 := by decide
theorem cert_e611630544158 : check e611630544158 [[.under]] .sourceHead = true := by decide
def e611630544326 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e611630544326 : Closed e611630544326 ∧ code e611630544326 = 9407723566534 := by decide
theorem cert_e611630544326 : check e611630544326 [[.under]] .sourceHead = true := by decide
def e611630544666 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e611630544666 : Closed e611630544666 ∧ code e611630544666 = 9407723566874 := by decide
theorem cert_e611630544666 : check e611630544666 [[.under]] .sourceHead = true := by decide
def e611630544710 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e611630544710 : Closed e611630544710 ∧ code e611630544710 = 9407723566918 := by decide
theorem cert_e611630544710 : check e611630544710 [[.under]] .sourceHead = true := by decide
def e611630545110 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e611630545110 : Closed e611630545110 ∧ code e611630545110 = 9407723567318 := by decide
theorem cert_e611630545110 : check e611630545110 [[.under]] .sourceHead = true := by decide
def e611630545114 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e611630545114 : Closed e611630545114 ∧ code e611630545114 = 9407723567322 := by decide
theorem cert_e611630545114 : check e611630545114 [[.under]] .sourceHead = true := by decide
def e611630545130 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e611630545130 : Closed e611630545130 ∧ code e611630545130 = 9407723567338 := by decide
theorem cert_e611630545130 : check e611630545130 [[.under]] .sourceHead = true := by decide
def e611630545462 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e611630545462 : Closed e611630545462 ∧ code e611630545462 = 9407723567670 := by decide
theorem cert_e611630545462 : check e611630545462 [[.under]] .sourceHead = true := by decide
def e611630545466 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e611630545466 : Closed e611630545466 ∧ code e611630545466 = 9407723567674 := by decide
theorem cert_e611630545466 : check e611630545466 [[.under]] .sourceHead = true := by decide
def e611630545550 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e611630545550 : Closed e611630545550 ∧ code e611630545550 = 9407723567758 := by decide
theorem cert_e611630545550 : check e611630545550 [[.under]] .sourceHead = true := by decide
def e611630545606 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e611630545606 : Closed e611630545606 ∧ code e611630545606 = 9407723567814 := by decide
theorem cert_e611630545606 : check e611630545606 [[.under]] .sourceHead = true := by decide
def e611630545690 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e611630545690 : Closed e611630545690 ∧ code e611630545690 = 9407723567898 := by decide
theorem cert_e611630545690 : check e611630545690 [[.under]] .sourceHead = true := by decide
def e611630545734 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e611630545734 : Closed e611630545734 ∧ code e611630545734 = 9407723567942 := by decide
theorem cert_e611630545734 : check e611630545734 [[.under]] .sourceHead = true := by decide
def e611630550254 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e611630550254 : Closed e611630550254 ∧ code e611630550254 = 9407723572462 := by decide
theorem cert_e611630550254 : check e611630550254 [[.under]] .sourceHead = true := by decide
def e611630550262 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e611630550262 : Closed e611630550262 ∧ code e611630550262 = 9407723572470 := by decide
theorem cert_e611630550262 : check e611630550262 [[.under]] .sourceHead = true := by decide
def e611630550638 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e611630550638 : Closed e611630550638 ∧ code e611630550638 = 9407723572846 := by decide
theorem cert_e611630550638 : check e611630550638 [[.under]] .sourceHead = true := by decide
def e611630550650 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e611630550650 : Closed e611630550650 ∧ code e611630550650 = 9407723572858 := by decide
theorem cert_e611630550650 : check e611630550650 [[.under]] .sourceHead = true := by decide
def e611630550838 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e611630550838 : Closed e611630550838 ∧ code e611630550838 = 9407723573046 := by decide
theorem cert_e611630550838 : check e611630550838 [[.under]] .sourceHead = true := by decide
def e611630550842 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e611630550842 : Closed e611630550842 ∧ code e611630550842 = 9407723573050 := by decide
theorem cert_e611630550842 : check e611630550842 [[.under]] .sourceHead = true := by decide
def e611630553326 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e611630553326 : Closed e611630553326 ∧ code e611630553326 = 9407723575534 := by decide
theorem cert_e611630553326 : check e611630553326 [[.under]] .sourceHead = true := by decide
def e611630553334 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e611630553334 : Closed e611630553334 ∧ code e611630553334 = 9407723575542 := by decide
theorem cert_e611630553334 : check e611630553334 [[.under]] .sourceHead = true := by decide
def e611630553886 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))))))))
theorem wire_e611630553886 : Closed e611630553886 ∧ code e611630553886 = 9407723576094 := by decide
theorem cert_e611630553886 : check e611630553886 [[.under]] .sourceHead = true := by decide
def e611630553998 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))))))))
theorem wire_e611630553998 : Closed e611630553998 ∧ code e611630553998 = 9407723576206 := by decide
theorem cert_e611630553998 : check e611630553998 [[.under]] .sourceHead = true := by decide
def e611630554222 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e611630554222 : Closed e611630554222 ∧ code e611630554222 = 9407723576430 := by decide
theorem cert_e611630554222 : check e611630554222 [[.under]] .sourceHead = true := by decide
def e611630554234 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e611630554234 : Closed e611630554234 ∧ code e611630554234 = 9407723576442 := by decide
theorem cert_e611630554234 : check e611630554234 [[.under]] .sourceHead = true := by decide
def e611630554398 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))))))))
theorem wire_e611630554398 : Closed e611630554398 ∧ code e611630554398 = 9407723576606 := by decide
theorem cert_e611630554398 : check e611630554398 [[.under]] .sourceHead = true := by decide
def e611630554566 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))))))))
theorem wire_e611630554566 : Closed e611630554566 ∧ code e611630554566 = 9407723576774 := by decide
theorem cert_e611630554566 : check e611630554566 [[.under]] .sourceHead = true := by decide
def e611630554678 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e611630554678 : Closed e611630554678 ∧ code e611630554678 = 9407723576886 := by decide
theorem cert_e611630554678 : check e611630554678 [[.under]] .sourceHead = true := by decide
def e611630554682 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e611630554682 : Closed e611630554682 ∧ code e611630554682 = 9407723576890 := by decide
theorem cert_e611630554682 : check e611630554682 [[.under]] .sourceHead = true := by decide
def e611630554766 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))))))))
theorem wire_e611630554766 : Closed e611630554766 ∧ code e611630554766 = 9407723576974 := by decide
theorem cert_e611630554766 : check e611630554766 [[.under]] .sourceHead = true := by decide
def e611630554822 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))))))))
theorem wire_e611630554822 : Closed e611630554822 ∧ code e611630554822 = 9407723577030 := by decide
theorem cert_e611630554822 : check e611630554822 [[.under]] .sourceHead = true := by decide
def e611630556958 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e611630556958 : Closed e611630556958 ∧ code e611630556958 = 9407723579166 := by decide
theorem cert_e611630556958 : check e611630556958 [[.under]] .sourceHead = true := by decide
def e611630557070 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e611630557070 : Closed e611630557070 ∧ code e611630557070 = 9407723579278 := by decide
theorem cert_e611630557070 : check e611630557070 [[.under]] .sourceHead = true := by decide
def e611630560030 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e611630560030 : Closed e611630560030 ∧ code e611630560030 = 9407723582238 := by decide
theorem cert_e611630560030 : check e611630560030 [[.under]] .sourceHead = true := by decide
def e611630560198 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e611630560198 : Closed e611630560198 ∧ code e611630560198 = 9407723582406 := by decide
theorem cert_e611630560198 : check e611630560198 [[.under]] .sourceHead = true := by decide
def e611630561678 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e611630561678 : Closed e611630561678 ∧ code e611630561678 = 9407723583886 := by decide
theorem cert_e611630561678 : check e611630561678 [[.under]] .sourceHead = true := by decide
def e611630561734 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e611630561734 : Closed e611630561734 ∧ code e611630561734 = 9407723583942 := by decide
theorem cert_e611630561734 : check e611630561734 [[.under]] .sourceHead = true := by decide
def e611630564974 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e611630564974 : Closed e611630564974 ∧ code e611630564974 = 9407723587182 := by decide
theorem cert_e611630564974 : check e611630564974 [[.under]] .sourceHead = true := by decide
def e611630564986 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e611630564986 : Closed e611630564986 ∧ code e611630564986 = 9407723587194 := by decide
theorem cert_e611630564986 : check e611630564986 [[.under]] .sourceHead = true := by decide
def e611630565274 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e611630565274 : Closed e611630565274 ∧ code e611630565274 = 9407723587482 := by decide
theorem cert_e611630565274 : check e611630565274 [[.under]] .sourceHead = true := by decide
def e611630566510 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e611630566510 : Closed e611630566510 ∧ code e611630566510 = 9407723588718 := by decide
theorem cert_e611630566510 : check e611630566510 [[.under]] .sourceHead = true := by decide
def e611630566522 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e611630566522 : Closed e611630566522 ∧ code e611630566522 = 9407723588730 := by decide
theorem cert_e611630566522 : check e611630566522 [[.under]] .sourceHead = true := by decide
def e611630566686 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e611630566686 : Closed e611630566686 ∧ code e611630566686 = 9407723588894 := by decide
theorem cert_e611630566686 : check e611630566686 [[.under]] .sourceHead = true := by decide
def e611630566854 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e611630566854 : Closed e611630566854 ∧ code e611630566854 = 9407723589062 := by decide
theorem cert_e611630566854 : check e611630566854 [[.under]] .sourceHead = true := by decide
def e611630567194 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e611630567194 : Closed e611630567194 ∧ code e611630567194 = 9407723589402 := by decide
theorem cert_e611630567194 : check e611630567194 [[.under]] .sourceHead = true := by decide
def e611630567238 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e611630567238 : Closed e611630567238 ∧ code e611630567238 = 9407723589446 := by decide
theorem cert_e611630567238 : check e611630567238 [[.under]] .sourceHead = true := by decide
def e611630568222 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e611630568222 : Closed e611630568222 ∧ code e611630568222 = 9407723590430 := by decide
theorem cert_e611630568222 : check e611630568222 [[.under]] .sourceHead = true := by decide
def e611630568390 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e611630568390 : Closed e611630568390 ∧ code e611630568390 = 9407723590598 := by decide
theorem cert_e611630568390 : check e611630568390 [[.under]] .sourceHead = true := by decide
def e611630570694 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e611630570694 : Closed e611630570694 ∧ code e611630570694 = 9407723592902 := by decide
theorem cert_e611630570694 : check e611630570694 [[.under]] .sourceHead = true := by decide
def e611630572342 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e611630572342 : Closed e611630572342 ∧ code e611630572342 = 9407723594550 := by decide
theorem cert_e611630572342 : check e611630572342 [[.under]] .sourceHead = true := by decide
def e611630572346 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e611630572346 : Closed e611630572346 ∧ code e611630572346 = 9407723594554 := by decide
theorem cert_e611630572346 : check e611630572346 [[.under]] .sourceHead = true := by decide
def e611630572442 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e611630572442 : Closed e611630572442 ∧ code e611630572442 = 9407723594650 := by decide
theorem cert_e611630572442 : check e611630572442 [[.under]] .sourceHead = true := by decide
def e611630573110 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e611630573110 : Closed e611630573110 ∧ code e611630573110 = 9407723595318 := by decide
theorem cert_e611630573110 : check e611630573110 [[.under]] .sourceHead = true := by decide
def e611630573114 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e611630573114 : Closed e611630573114 ∧ code e611630573114 = 9407723595322 := by decide
theorem cert_e611630573114 : check e611630573114 [[.under]] .sourceHead = true := by decide
def e611630573198 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e611630573198 : Closed e611630573198 ∧ code e611630573198 = 9407723595406 := by decide
theorem cert_e611630573198 : check e611630573198 [[.under]] .sourceHead = true := by decide
def e611630573254 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e611630573254 : Closed e611630573254 ∧ code e611630573254 = 9407723595462 := by decide
theorem cert_e611630573254 : check e611630573254 [[.under]] .sourceHead = true := by decide
def e611630573338 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e611630573338 : Closed e611630573338 ∧ code e611630573338 = 9407723595546 := by decide
theorem cert_e611630573338 : check e611630573338 [[.under]] .sourceHead = true := by decide
def e611630573382 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e611630573382 : Closed e611630573382 ∧ code e611630573382 = 9407723595590 := by decide
theorem cert_e611630573382 : check e611630573382 [[.under]] .sourceHead = true := by decide
def e611630573966 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e611630573966 : Closed e611630573966 ∧ code e611630573966 = 9407723596174 := by decide
theorem cert_e611630573966 : check e611630573966 [[.under]] .sourceHead = true := by decide
def e611630574022 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e611630574022 : Closed e611630574022 ∧ code e611630574022 = 9407723596230 := by decide
theorem cert_e611630574022 : check e611630574022 [[.under]] .sourceHead = true := by decide
def e611630574790 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e611630574790 : Closed e611630574790 ∧ code e611630574790 = 9407723596998 := by decide
theorem cert_e611630574790 : check e611630574790 [[.under]] .sourceHead = true := by decide
def e611630585566 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e611630585566 : Closed e611630585566 ∧ code e611630585566 = 9407723607774 := by decide
theorem cert_e611630585566 : check e611630585566 [[.under]] .sourceHead = true := by decide
def e611630585590 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e611630585590 : Closed e611630585590 ∧ code e611630585590 = 9407723607798 := by decide
theorem cert_e611630585590 : check e611630585590 [[.under]] .sourceHead = true := by decide
def e611630585694 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e611630585694 : Closed e611630585694 ∧ code e611630585694 = 9407723607902 := by decide
theorem cert_e611630585694 : check e611630585694 [[.under]] .sourceHead = true := by decide
def e611630585722 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e611630585722 : Closed e611630585722 ∧ code e611630585722 = 9407723607930 := by decide
theorem cert_e611630585722 : check e611630585722 [[.under]] .sourceHead = true := by decide
def e611630585814 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e611630585814 : Closed e611630585814 ∧ code e611630585814 = 9407723608022 := by decide
theorem cert_e611630585814 : check e611630585814 [[.under]] .sourceHead = true := by decide
def e611630585818 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e611630585818 : Closed e611630585818 ∧ code e611630585818 = 9407723608026 := by decide
theorem cert_e611630585818 : check e611630585818 [[.under]] .sourceHead = true := by decide
def e611630586334 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e611630586334 : Closed e611630586334 ∧ code e611630586334 = 9407723608542 := by decide
theorem cert_e611630586334 : check e611630586334 [[.under]] .sourceHead = true := by decide
def e611630586358 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e611630586358 : Closed e611630586358 ∧ code e611630586358 = 9407723608566 := by decide
theorem cert_e611630586358 : check e611630586358 [[.under]] .sourceHead = true := by decide
def e611630587102 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e611630587102 : Closed e611630587102 ∧ code e611630587102 = 9407723609310 := by decide
theorem cert_e611630587102 : check e611630587102 [[.under]] .sourceHead = true := by decide
def e611630587130 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e611630587130 : Closed e611630587130 ∧ code e611630587130 = 9407723609338 := by decide
theorem cert_e611630587130 : check e611630587130 [[.under]] .sourceHead = true := by decide
def e611630587702 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e611630587702 : Closed e611630587702 ∧ code e611630587702 = 9407723609910 := by decide
theorem cert_e611630587702 : check e611630587702 [[.under]] .sourceHead = true := by decide
def e611630587706 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e611630587706 : Closed e611630587706 ∧ code e611630587706 = 9407723609914 := by decide
theorem cert_e611630587706 : check e611630587706 [[.under]] .sourceHead = true := by decide
def e611630602478 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e611630602478 : Closed e611630602478 ∧ code e611630602478 = 9407723624686 := by decide
theorem cert_e611630602478 : check e611630602478 [[.under]] .sourceHead = true := by decide
def e611630602486 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e611630602486 : Closed e611630602486 ∧ code e611630602486 = 9407723624694 := by decide
theorem cert_e611630602486 : check e611630602486 [[.under]] .sourceHead = true := by decide
def e611630603038 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e611630603038 : Closed e611630603038 ∧ code e611630603038 = 9407723625246 := by decide
theorem cert_e611630603038 : check e611630603038 [[.under]] .sourceHead = true := by decide
def e611630603150 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e611630603150 : Closed e611630603150 ∧ code e611630603150 = 9407723625358 := by decide
theorem cert_e611630603150 : check e611630603150 [[.under]] .sourceHead = true := by decide
def e611630603374 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e611630603374 : Closed e611630603374 ∧ code e611630603374 = 9407723625582 := by decide
theorem cert_e611630603374 : check e611630603374 [[.under]] .sourceHead = true := by decide
def e611630603386 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e611630603386 : Closed e611630603386 ∧ code e611630603386 = 9407723625594 := by decide
theorem cert_e611630603386 : check e611630603386 [[.under]] .sourceHead = true := by decide
def e611630603550 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e611630603550 : Closed e611630603550 ∧ code e611630603550 = 9407723625758 := by decide
theorem cert_e611630603550 : check e611630603550 [[.under]] .sourceHead = true := by decide
def e611630603718 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e611630603718 : Closed e611630603718 ∧ code e611630603718 = 9407723625926 := by decide
theorem cert_e611630603718 : check e611630603718 [[.under]] .sourceHead = true := by decide
def e611630603830 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e611630603830 : Closed e611630603830 ∧ code e611630603830 = 9407723626038 := by decide
theorem cert_e611630603830 : check e611630603830 [[.under]] .sourceHead = true := by decide
def e611630603834 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e611630603834 : Closed e611630603834 ∧ code e611630603834 = 9407723626042 := by decide
theorem cert_e611630603834 : check e611630603834 [[.under]] .sourceHead = true := by decide
def e611630603918 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e611630603918 : Closed e611630603918 ∧ code e611630603918 = 9407723626126 := by decide
theorem cert_e611630603918 : check e611630603918 [[.under]] .sourceHead = true := by decide
def e611630603974 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e611630603974 : Closed e611630603974 ∧ code e611630603974 = 9407723626182 := by decide
theorem cert_e611630603974 : check e611630603974 [[.under]] .sourceHead = true := by decide
def e611630606110 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e611630606110 : Closed e611630606110 ∧ code e611630606110 = 9407723628318 := by decide
theorem cert_e611630606110 : check e611630606110 [[.under]] .sourceHead = true := by decide
def e611630606222 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e611630606222 : Closed e611630606222 ∧ code e611630606222 = 9407723628430 := by decide
theorem cert_e611630606222 : check e611630606222 [[.under]] .sourceHead = true := by decide
def e611630609182 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e611630609182 : Closed e611630609182 ∧ code e611630609182 = 9407723631390 := by decide
theorem cert_e611630609182 : check e611630609182 [[.under]] .sourceHead = true := by decide
def e611630609350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e611630609350 : Closed e611630609350 ∧ code e611630609350 = 9407723631558 := by decide
theorem cert_e611630609350 : check e611630609350 [[.under]] .sourceHead = true := by decide
def e611630610830 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e611630610830 : Closed e611630610830 ∧ code e611630610830 = 9407723633038 := by decide
theorem cert_e611630610830 : check e611630610830 [[.under]] .sourceHead = true := by decide
def e611630610886 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e611630610886 : Closed e611630610886 ∧ code e611630610886 = 9407723633094 := by decide
theorem cert_e611630610886 : check e611630610886 [[.under]] .sourceHead = true := by decide
def e611630648174 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e611630648174 : Closed e611630648174 ∧ code e611630648174 = 9407723670382 := by decide
theorem cert_e611630648174 : check e611630648174 [[.under]] .sourceHead = true := by decide
def e611630648182 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e611630648182 : Closed e611630648182 ∧ code e611630648182 = 9407723670390 := by decide
theorem cert_e611630648182 : check e611630648182 [[.under]] .sourceHead = true := by decide
def e611630648238 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e611630648238 : Closed e611630648238 ∧ code e611630648238 = 9407723670446 := by decide
theorem cert_e611630648238 : check e611630648238 [[.under]] .sourceHead = true := by decide
def e611630648250 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e611630648250 : Closed e611630648250 ∧ code e611630648250 = 9407723670458 := by decide
theorem cert_e611630648250 : check e611630648250 [[.under]] .sourceHead = true := by decide
def e611630648278 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e611630648278 : Closed e611630648278 ∧ code e611630648278 = 9407723670486 := by decide
theorem cert_e611630648278 : check e611630648278 [[.under]] .sourceHead = true := by decide
def e611630648282 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e611630648282 : Closed e611630648282 ∧ code e611630648282 = 9407723670490 := by decide
theorem cert_e611630648282 : check e611630648282 [[.under]] .sourceHead = true := by decide
def e611630648558 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e611630648558 : Closed e611630648558 ∧ code e611630648558 = 9407723670766 := by decide
theorem cert_e611630648558 : check e611630648558 [[.under]] .sourceHead = true := by decide
def e611630648566 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e611630648566 : Closed e611630648566 ∧ code e611630648566 = 9407723670774 := by decide
theorem cert_e611630648566 : check e611630648566 [[.under]] .sourceHead = true := by decide
def e611630648942 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e611630648942 : Closed e611630648942 ∧ code e611630648942 = 9407723671150 := by decide
theorem cert_e611630648942 : check e611630648942 [[.under]] .sourceHead = true := by decide
def e611630648954 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e611630648954 : Closed e611630648954 ∧ code e611630648954 = 9407723671162 := by decide
theorem cert_e611630648954 : check e611630648954 [[.under]] .sourceHead = true := by decide
def e611630649142 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e611630649142 : Closed e611630649142 ∧ code e611630649142 = 9407723671350 := by decide
theorem cert_e611630649142 : check e611630649142 [[.under]] .sourceHead = true := by decide
def e611630649146 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e611630649146 : Closed e611630649146 ∧ code e611630649146 = 9407723671354 := by decide
theorem cert_e611630649146 : check e611630649146 [[.under]] .sourceHead = true := by decide
def e611630656622 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e611630656622 : Closed e611630656622 ∧ code e611630656622 = 9407723678830 := by decide
theorem cert_e611630656622 : check e611630656622 [[.under]] .sourceHead = true := by decide
def e611630656634 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e611630656634 : Closed e611630656634 ∧ code e611630656634 = 9407723678842 := by decide
theorem cert_e611630656634 : check e611630656634 [[.under]] .sourceHead = true := by decide
def e611630656798 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e611630656798 : Closed e611630656798 ∧ code e611630656798 = 9407723679006 := by decide
theorem cert_e611630656798 : check e611630656798 [[.under]] .sourceHead = true := by decide
def e611630656966 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e611630656966 : Closed e611630656966 ∧ code e611630656966 = 9407723679174 := by decide
theorem cert_e611630656966 : check e611630656966 [[.under]] .sourceHead = true := by decide
def e611630657306 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e611630657306 : Closed e611630657306 ∧ code e611630657306 = 9407723679514 := by decide
theorem cert_e611630657306 : check e611630657306 [[.under]] .sourceHead = true := by decide
def e611630657350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e611630657350 : Closed e611630657350 ∧ code e611630657350 = 9407723679558 := by decide
theorem cert_e611630657350 : check e611630657350 [[.under]] .sourceHead = true := by decide
def e611630658334 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e611630658334 : Closed e611630658334 ∧ code e611630658334 = 9407723680542 := by decide
theorem cert_e611630658334 : check e611630658334 [[.under]] .sourceHead = true := by decide
def e611630658502 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e611630658502 : Closed e611630658502 ∧ code e611630658502 = 9407723680710 := by decide
theorem cert_e611630658502 : check e611630658502 [[.under]] .sourceHead = true := by decide
def e611630660806 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e611630660806 : Closed e611630660806 ∧ code e611630660806 = 9407723683014 := by decide
theorem cert_e611630660806 : check e611630660806 [[.under]] .sourceHead = true := by decide
def e611630683702 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e611630683702 : Closed e611630683702 ∧ code e611630683702 = 9407723705910 := by decide
theorem cert_e611630683702 : check e611630683702 [[.under]] .sourceHead = true := by decide
def e611630683706 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e611630683706 : Closed e611630683706 ∧ code e611630683706 = 9407723705914 := by decide
theorem cert_e611630683706 : check e611630683706 [[.under]] .sourceHead = true := by decide
def e611630683790 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e611630683790 : Closed e611630683790 ∧ code e611630683790 = 9407723705998 := by decide
theorem cert_e611630683790 : check e611630683790 [[.under]] .sourceHead = true := by decide
def e611630683846 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e611630683846 : Closed e611630683846 ∧ code e611630683846 = 9407723706054 := by decide
theorem cert_e611630683846 : check e611630683846 [[.under]] .sourceHead = true := by decide
def e611630683930 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e611630683930 : Closed e611630683930 ∧ code e611630683930 = 9407723706138 := by decide
theorem cert_e611630683930 : check e611630683930 [[.under]] .sourceHead = true := by decide
def e611630683974 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e611630683974 : Closed e611630683974 ∧ code e611630683974 = 9407723706182 := by decide
theorem cert_e611630683974 : check e611630683974 [[.under]] .sourceHead = true := by decide
def e611630684558 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e611630684558 : Closed e611630684558 ∧ code e611630684558 = 9407723706766 := by decide
theorem cert_e611630684558 : check e611630684558 [[.under]] .sourceHead = true := by decide
def e611630684614 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e611630684614 : Closed e611630684614 ∧ code e611630684614 = 9407723706822 := by decide
theorem cert_e611630684614 : check e611630684614 [[.under]] .sourceHead = true := by decide
def e611630685382 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e611630685382 : Closed e611630685382 ∧ code e611630685382 = 9407723707590 := by decide
theorem cert_e611630685382 : check e611630685382 [[.under]] .sourceHead = true := by decide
def e611631782126 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e611631782126 : Closed e611631782126 ∧ code e611631782126 = 9407724804334 := by decide
theorem cert_e611631782126 : check e611631782126 [[.under]] .sourceHead = true := by decide
def e611631782134 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e611631782134 : Closed e611631782134 ∧ code e611631782134 = 9407724804342 := by decide
theorem cert_e611631782134 : check e611631782134 [[.under]] .sourceHead = true := by decide
def e611631782686 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e611631782686 : Closed e611631782686 ∧ code e611631782686 = 9407724804894 := by decide
theorem cert_e611631782686 : check e611631782686 [[.under]] .sourceHead = true := by decide
def e611631782798 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e611631782798 : Closed e611631782798 ∧ code e611631782798 = 9407724805006 := by decide
theorem cert_e611631782798 : check e611631782798 [[.under]] .sourceHead = true := by decide
def e611631783022 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e611631783022 : Closed e611631783022 ∧ code e611631783022 = 9407724805230 := by decide
theorem cert_e611631783022 : check e611631783022 [[.under]] .sourceHead = true := by decide
def e611631783034 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e611631783034 : Closed e611631783034 ∧ code e611631783034 = 9407724805242 := by decide
theorem cert_e611631783034 : check e611631783034 [[.under]] .sourceHead = true := by decide
def e611631783198 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e611631783198 : Closed e611631783198 ∧ code e611631783198 = 9407724805406 := by decide
theorem cert_e611631783198 : check e611631783198 [[.under]] .sourceHead = true := by decide
def e611631783366 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e611631783366 : Closed e611631783366 ∧ code e611631783366 = 9407724805574 := by decide
theorem cert_e611631783366 : check e611631783366 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
