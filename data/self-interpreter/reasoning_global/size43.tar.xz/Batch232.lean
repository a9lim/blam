import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373341142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2393373341142 : Closed e2393373341142 ∧ code e2393373341142 = 11189466363350 := by decide
theorem cert_e2393373341142 : check e2393373341142 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373341146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2393373341146 : Closed e2393373341146 ∧ code e2393373341146 = 11189466363354 := by decide
theorem cert_e2393373341146 : check e2393373341146 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373341226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2393373341226 : Closed e2393373341226 ∧ code e2393373341226 = 11189466363434 := by decide
theorem cert_e2393373341226 : check e2393373341226 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393373341322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373341322 : Closed e2393373341322 ∧ code e2393373341322 = 11189466363530 := by decide
theorem cert_e2393373341322 : check e2393373341322 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393373341346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373341346 : Closed e2393373341346 ∧ code e2393373341346 = 11189466363554 := by decide
theorem cert_e2393373341346 : check e2393373341346 [[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393373341358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2393373341358 : Closed e2393373341358 ∧ code e2393373341358 = 11189466363566 := by decide
theorem cert_e2393373341358 : check e2393373341358 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373341366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2393373341366 : Closed e2393373341366 ∧ code e2393373341366 = 11189466363574 := by decide
theorem cert_e2393373341366 : check e2393373341366 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373341370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2393373341370 : Closed e2393373341370 ∧ code e2393373341370 = 11189466363578 := by decide
theorem cert_e2393373341370 : check e2393373341370 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373341398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2393373341398 : Closed e2393373341398 ∧ code e2393373341398 = 11189466363606 := by decide
def e2393373341402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2393373341402 : Closed e2393373341402 ∧ code e2393373341402 = 11189466363610 := by decide
def e2393373341418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2393373341418 : Closed e2393373341418 ∧ code e2393373341418 = 11189466363626 := by decide
def e2393373341526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2393373341526 : Closed e2393373341526 ∧ code e2393373341526 = 11189466363734 := by decide
private def t_e2393373341526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)) (.var 1))))))
theorem cert_e2393373341526 : ¬ IsSelfInterpreter e2393373341526 :=
  wSource (t := t_e2393373341526) (replay_sound (ps := []) (t := e2393373341526) (by decide)) (by decide)
def e2393373341530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2393373341530 : Closed e2393373341530 ∧ code e2393373341530 = 11189466363738 := by decide
private def t_e2393373341530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)) (.var 0))))))
theorem cert_e2393373341530 : ¬ IsSelfInterpreter e2393373341530 :=
  wSource (t := t_e2393373341530) (replay_sound (ps := []) (t := e2393373341530) (by decide)) (by decide)
def e2393373341546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2393373341546 : Closed e2393373341546 ∧ code e2393373341546 = 11189466363754 := by decide
private def t_e2393373341546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)) (.var 0))))))
theorem cert_e2393373341546 : ¬ IsSelfInterpreter e2393373341546 :=
  wSource (t := t_e2393373341546) (replay_sound (ps := []) (t := e2393373341546) (by decide)) (by decide)
def e2393373345646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2393373345646 : Closed e2393373345646 ∧ code e2393373345646 = 11189466367854 := by decide
theorem cert_e2393373345646 : check e2393373345646 [[],[.left],[]] .sourceHead = true := by decide
def e2393373345654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2393373345654 : Closed e2393373345654 ∧ code e2393373345654 = 11189466367862 := by decide
theorem cert_e2393373345654 : check e2393373345654 [[],[.left],[]] .sourceHead = true := by decide
def e2393373345710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e2393373345710 : Closed e2393373345710 ∧ code e2393373345710 = 11189466367918 := by decide
theorem cert_e2393373345710 : check e2393373345710 [[],[.left],[]] .sourceHead = true := by decide
def e2393373345722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e2393373345722 : Closed e2393373345722 ∧ code e2393373345722 = 11189466367930 := by decide
theorem cert_e2393373345722 : check e2393373345722 [[],[.left],[]] .sourceHead = true := by decide
def e2393373345750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))
theorem wire_e2393373345750 : Closed e2393373345750 ∧ code e2393373345750 = 11189466367958 := by decide
theorem cert_e2393373345750 : check e2393373345750 [[],[.left],[]] .sourceHead = true := by decide
def e2393373345754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))
theorem wire_e2393373345754 : Closed e2393373345754 ∧ code e2393373345754 = 11189466367962 := by decide
theorem cert_e2393373345754 : check e2393373345754 [[],[.left],[]] .sourceHead = true := by decide
def e2393373347182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2393373347182 : Closed e2393373347182 ∧ code e2393373347182 = 11189466369390 := by decide
theorem cert_e2393373347182 : check e2393373347182 [[],[.left],[]] .sourceHead = true := by decide
def e2393373347190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2393373347190 : Closed e2393373347190 ∧ code e2393373347190 = 11189466369398 := by decide
theorem cert_e2393373347190 : check e2393373347190 [[],[.left],[]] .sourceHead = true := by decide
def e2393373348718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2393373348718 : Closed e2393373348718 ∧ code e2393373348718 = 11189466370926 := by decide
theorem cert_e2393373348718 : check e2393373348718 [[],[.left],[]] .sourceHead = true := by decide
def e2393373348726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2393373348726 : Closed e2393373348726 ∧ code e2393373348726 = 11189466370934 := by decide
theorem cert_e2393373348726 : check e2393373348726 [[],[.left],[]] .sourceHead = true := by decide
def e2393373348782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2393373348782 : Closed e2393373348782 ∧ code e2393373348782 = 11189466370990 := by decide
theorem cert_e2393373348782 : check e2393373348782 [[],[.left],[]] .sourceHead = true := by decide
def e2393373348794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2393373348794 : Closed e2393373348794 ∧ code e2393373348794 = 11189466371002 := by decide
theorem cert_e2393373348794 : check e2393373348794 [[],[.left],[]] .sourceHead = true := by decide
def e2393373348822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2393373348822 : Closed e2393373348822 ∧ code e2393373348822 = 11189466371030 := by decide
theorem cert_e2393373348822 : check e2393373348822 [[],[.left],[]] .sourceHead = true := by decide
def e2393373348826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2393373348826 : Closed e2393373348826 ∧ code e2393373348826 = 11189466371034 := by decide
theorem cert_e2393373348826 : check e2393373348826 [[],[.left],[]] .sourceHead = true := by decide
def e2393373349102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373349102 : Closed e2393373349102 ∧ code e2393373349102 = 11189466371310 := by decide
theorem cert_e2393373349102 : check e2393373349102 [[],[.left],[]] .sourceHead = true := by decide
def e2393373349110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373349110 : Closed e2393373349110 ∧ code e2393373349110 = 11189466371318 := by decide
theorem cert_e2393373349110 : check e2393373349110 [[],[.left],[]] .sourceHead = true := by decide
def e2393373349486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373349486 : Closed e2393373349486 ∧ code e2393373349486 = 11189466371694 := by decide
theorem cert_e2393373349486 : check e2393373349486 [[],[.left],[]] .sourceHead = true := by decide
def e2393373349498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373349498 : Closed e2393373349498 ∧ code e2393373349498 = 11189466371706 := by decide
theorem cert_e2393373349498 : check e2393373349498 [[],[.left],[]] .sourceHead = true := by decide
def e2393373349686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373349686 : Closed e2393373349686 ∧ code e2393373349686 = 11189466371894 := by decide
theorem cert_e2393373349686 : check e2393373349686 [[],[.left],[]] .sourceHead = true := by decide
def e2393373349690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373349690 : Closed e2393373349690 ∧ code e2393373349690 = 11189466371898 := by decide
theorem cert_e2393373349690 : check e2393373349690 [[],[.left],[]] .sourceHead = true := by decide
def e2393373350126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2393373350126 : Closed e2393373350126 ∧ code e2393373350126 = 11189466372334 := by decide
theorem cert_e2393373350126 : check e2393373350126 [[],[.left],[]] .sourceHead = true := by decide
def e2393373350134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2393373350134 : Closed e2393373350134 ∧ code e2393373350134 = 11189466372342 := by decide
theorem cert_e2393373350134 : check e2393373350134 [[],[.left],[]] .sourceHead = true := by decide
def e2393373350686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2393373350686 : Closed e2393373350686 ∧ code e2393373350686 = 11189466372894 := by decide
theorem cert_e2393373350686 : check e2393373350686 [[],[.left],[]] .sourceHead = true := by decide
def e2393373350798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2393373350798 : Closed e2393373350798 ∧ code e2393373350798 = 11189466373006 := by decide
theorem cert_e2393373350798 : check e2393373350798 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2393373351022 : Closed e2393373351022 ∧ code e2393373351022 = 11189466373230 := by decide
theorem cert_e2393373351022 : check e2393373351022 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2393373351034 : Closed e2393373351034 ∧ code e2393373351034 = 11189466373242 := by decide
theorem cert_e2393373351034 : check e2393373351034 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2393373351198 : Closed e2393373351198 ∧ code e2393373351198 = 11189466373406 := by decide
theorem cert_e2393373351198 : check e2393373351198 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2393373351366 : Closed e2393373351366 ∧ code e2393373351366 = 11189466373574 := by decide
theorem cert_e2393373351366 : check e2393373351366 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2393373351478 : Closed e2393373351478 ∧ code e2393373351478 = 11189466373686 := by decide
theorem cert_e2393373351478 : check e2393373351478 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2393373351482 : Closed e2393373351482 ∧ code e2393373351482 = 11189466373690 := by decide
theorem cert_e2393373351482 : check e2393373351482 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2393373351566 : Closed e2393373351566 ∧ code e2393373351566 = 11189466373774 := by decide
theorem cert_e2393373351566 : check e2393373351566 [[],[.left],[]] .sourceHead = true := by decide
def e2393373351622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2393373351622 : Closed e2393373351622 ∧ code e2393373351622 = 11189466373830 := by decide
theorem cert_e2393373351622 : check e2393373351622 [[],[.left],[]] .sourceHead = true := by decide
def e2393373356398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2393373356398 : Closed e2393373356398 ∧ code e2393373356398 = 11189466378606 := by decide
theorem cert_e2393373356398 : check e2393373356398 [[],[.left],[]] .sourceHead = true := by decide
def e2393373356406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2393373356406 : Closed e2393373356406 ∧ code e2393373356406 = 11189466378614 := by decide
theorem cert_e2393373356406 : check e2393373356406 [[],[.left],[]] .sourceHead = true := by decide
def e2393373357614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2393373357614 : Closed e2393373357614 ∧ code e2393373357614 = 11189466379822 := by decide
theorem cert_e2393373357614 : check e2393373357614 [[],[.left],[]] .sourceHead = true := by decide
def e2393373357794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2393373357794 : Closed e2393373357794 ∧ code e2393373357794 = 11189466380002 := by decide
theorem cert_e2393373357794 : check e2393373357794 [[],[.left],[]] .sourceHead = true := by decide
def e2393373357806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e2393373357806 : Closed e2393373357806 ∧ code e2393373357806 = 11189466380014 := by decide
theorem cert_e2393373357806 : check e2393373357806 [[],[.left],[]] .sourceHead = true := by decide
def e2393373357846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2393373357846 : Closed e2393373357846 ∧ code e2393373357846 = 11189466380054 := by decide
theorem cert_e2393373357846 : check e2393373357846 [[],[.left],[]] .sourceHead = true := by decide
def e2393373357922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2393373357922 : Closed e2393373357922 ∧ code e2393373357922 = 11189466380130 := by decide
theorem cert_e2393373357922 : check e2393373357922 [[],[.left],[]] .sourceHead = true := by decide
def e2393373357934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2393373357934 : Closed e2393373357934 ∧ code e2393373357934 = 11189466380142 := by decide
theorem cert_e2393373357934 : check e2393373357934 [[],[.left],[]] .sourceHead = true := by decide
def e2393373357942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2393373357942 : Closed e2393373357942 ∧ code e2393373357942 = 11189466380150 := by decide
theorem cert_e2393373357942 : check e2393373357942 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2393373358254 : Closed e2393373358254 ∧ code e2393373358254 = 11189466380462 := by decide
theorem cert_e2393373358254 : check e2393373358254 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2393373358266 : Closed e2393373358266 ∧ code e2393373358266 = 11189466380474 := by decide
theorem cert_e2393373358266 : check e2393373358266 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2393373358638 : Closed e2393373358638 ∧ code e2393373358638 = 11189466380846 := by decide
theorem cert_e2393373358638 : check e2393373358638 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2393373358818 : Closed e2393373358818 ∧ code e2393373358818 = 11189466381026 := by decide
theorem cert_e2393373358818 : check e2393373358818 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2393373358830 : Closed e2393373358830 ∧ code e2393373358830 = 11189466381038 := by decide
theorem cert_e2393373358830 : check e2393373358830 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2393373358958 : Closed e2393373358958 ∧ code e2393373358958 = 11189466381166 := by decide
theorem cert_e2393373358958 : check e2393373358958 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2393373358966 : Closed e2393373358966 ∧ code e2393373358966 = 11189466381174 := by decide
theorem cert_e2393373358966 : check e2393373358966 [[],[.left],[]] .sourceHead = true := by decide
def e2393373358986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373358986 : Closed e2393373358986 ∧ code e2393373358986 = 11189466381194 := by decide
theorem cert_e2393373358986 : check e2393373358986 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373359010 : Closed e2393373359010 ∧ code e2393373359010 = 11189466381218 := by decide
theorem cert_e2393373359010 : check e2393373359010 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2393373359022 : Closed e2393373359022 ∧ code e2393373359022 = 11189466381230 := by decide
theorem cert_e2393373359022 : check e2393373359022 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2393373359030 : Closed e2393373359030 ∧ code e2393373359030 = 11189466381238 := by decide
theorem cert_e2393373359030 : check e2393373359030 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2393373359034 : Closed e2393373359034 ∧ code e2393373359034 = 11189466381242 := by decide
theorem cert_e2393373359034 : check e2393373359034 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2393373359190 : Closed e2393373359190 ∧ code e2393373359190 = 11189466381398 := by decide
theorem cert_e2393373359190 : check e2393373359190 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2393373359194 : Closed e2393373359194 ∧ code e2393373359194 = 11189466381402 := by decide
theorem cert_e2393373359194 : check e2393373359194 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2393373359382 : Closed e2393373359382 ∧ code e2393373359382 = 11189466381590 := by decide
theorem cert_e2393373359382 : check e2393373359382 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2393373359458 : Closed e2393373359458 ∧ code e2393373359458 = 11189466381666 := by decide
theorem cert_e2393373359458 : check e2393373359458 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2393373359470 : Closed e2393373359470 ∧ code e2393373359470 = 11189466381678 := by decide
theorem cert_e2393373359470 : check e2393373359470 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2393373359478 : Closed e2393373359478 ∧ code e2393373359478 = 11189466381686 := by decide
theorem cert_e2393373359478 : check e2393373359478 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373359498 : Closed e2393373359498 ∧ code e2393373359498 = 11189466381706 := by decide
theorem cert_e2393373359498 : check e2393373359498 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373359522 : Closed e2393373359522 ∧ code e2393373359522 = 11189466381730 := by decide
theorem cert_e2393373359522 : check e2393373359522 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2393373359534 : Closed e2393373359534 ∧ code e2393373359534 = 11189466381742 := by decide
theorem cert_e2393373359534 : check e2393373359534 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2393373359542 : Closed e2393373359542 ∧ code e2393373359542 = 11189466381750 := by decide
theorem cert_e2393373359542 : check e2393373359542 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2393373359546 : Closed e2393373359546 ∧ code e2393373359546 = 11189466381754 := by decide
theorem cert_e2393373359546 : check e2393373359546 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2393373359574 : Closed e2393373359574 ∧ code e2393373359574 = 11189466381782 := by decide
theorem cert_e2393373359574 : check e2393373359574 [[],[.left],[]] .sourceHead = true := by decide
def e2393373359578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2393373359578 : Closed e2393373359578 ∧ code e2393373359578 = 11189466381786 := by decide
theorem cert_e2393373359578 : check e2393373359578 [[],[.left],[]] .sourceHead = true := by decide
def e2393373360622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2393373360622 : Closed e2393373360622 ∧ code e2393373360622 = 11189466382830 := by decide
theorem cert_e2393373360622 : check e2393373360622 [[],[.left],[]] .sourceHead = true := by decide
def e2393373360630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2393373360630 : Closed e2393373360630 ∧ code e2393373360630 = 11189466382838 := by decide
theorem cert_e2393373360630 : check e2393373360630 [[],[.left],[]] .sourceHead = true := by decide
def e2393373361390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373361390 : Closed e2393373361390 ∧ code e2393373361390 = 11189466383598 := by decide
theorem cert_e2393373361390 : check e2393373361390 [[],[.left],[]] .sourceHead = true := by decide
def e2393373361398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373361398 : Closed e2393373361398 ∧ code e2393373361398 = 11189466383606 := by decide
theorem cert_e2393373361398 : check e2393373361398 [[],[.left],[]] .sourceHead = true := by decide
def e2393373361950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2393373361950 : Closed e2393373361950 ∧ code e2393373361950 = 11189466384158 := by decide
theorem cert_e2393373361950 : check e2393373361950 [[],[.left],[]] .sourceHead = true := by decide
def e2393373362062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2393373362062 : Closed e2393373362062 ∧ code e2393373362062 = 11189466384270 := by decide
theorem cert_e2393373362062 : check e2393373362062 [[],[.left],[]] .sourceHead = true := by decide
def e2393373363758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2393373363758 : Closed e2393373363758 ∧ code e2393373363758 = 11189466385966 := by decide
theorem cert_e2393373363758 : check e2393373363758 [[],[.left],[]] .sourceHead = true := by decide
def e2393373363938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2393373363938 : Closed e2393373363938 ∧ code e2393373363938 = 11189466386146 := by decide
theorem cert_e2393373363938 : check e2393373363938 [[],[.left],[]] .sourceHead = true := by decide
def e2393373363950 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2393373363950 : Closed e2393373363950 ∧ code e2393373363950 = 11189466386158 := by decide
theorem cert_e2393373363950 : check e2393373363950 [[],[.left],[]] .sourceHead = true := by decide
def e2393373363990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2393373363990 : Closed e2393373363990 ∧ code e2393373363990 = 11189466386198 := by decide
theorem cert_e2393373363990 : check e2393373363990 [[],[.left],[]] .sourceHead = true := by decide
def e2393373364066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2393373364066 : Closed e2393373364066 ∧ code e2393373364066 = 11189466386274 := by decide
theorem cert_e2393373364066 : check e2393373364066 [[],[.left],[]] .sourceHead = true := by decide
def e2393373364078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2393373364078 : Closed e2393373364078 ∧ code e2393373364078 = 11189466386286 := by decide
theorem cert_e2393373364078 : check e2393373364078 [[],[.left],[]] .sourceHead = true := by decide
def e2393373364086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2393373364086 : Closed e2393373364086 ∧ code e2393373364086 = 11189466386294 := by decide
theorem cert_e2393373364086 : check e2393373364086 [[],[.left],[]] .sourceHead = true := by decide
def e2393373366334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2393373366334 : Closed e2393373366334 ∧ code e2393373366334 = 11189466388542 := by decide
theorem cert_e2393373366334 : check e2393373366334 [[],[.left],[]] .sourceHead = true := by decide
def e2393373366754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2393373366754 : Closed e2393373366754 ∧ code e2393373366754 = 11189466388962 := by decide
theorem cert_e2393373366754 : check e2393373366754 [[],[.left],[]] .sourceHead = true := by decide
def e2393373366766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2393373366766 : Closed e2393373366766 ∧ code e2393373366766 = 11189466388974 := by decide
theorem cert_e2393373366766 : check e2393373366766 [[],[.left],[]] .sourceHead = true := by decide
def e2393373367326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2393373367326 : Closed e2393373367326 ∧ code e2393373367326 = 11189466389534 := by decide
theorem cert_e2393373367326 : check e2393373367326 [[],[.left],[]] .sourceHead = true := by decide
def e2393373367522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2393373367522 : Closed e2393373367522 ∧ code e2393373367522 = 11189466389730 := by decide
theorem cert_e2393373367522 : check e2393373367522 [[],[.left],[]] .sourceHead = true := by decide
def e2393373367534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373367534 : Closed e2393373367534 ∧ code e2393373367534 = 11189466389742 := by decide
theorem cert_e2393373367534 : check e2393373367534 [[],[.left],[]] .sourceHead = true := by decide
def e2393373367542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373367542 : Closed e2393373367542 ∧ code e2393373367542 = 11189466389750 := by decide
theorem cert_e2393373367542 : check e2393373367542 [[],[.left],[]] .sourceHead = true := by decide
def e2393373368558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2393373368558 : Closed e2393373368558 ∧ code e2393373368558 = 11189466390766 := by decide
theorem cert_e2393373368558 : check e2393373368558 [[],[.left],[]] .sourceHead = true := by decide
def e2393373368570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2393373368570 : Closed e2393373368570 ∧ code e2393373368570 = 11189466390778 := by decide
theorem cert_e2393373368570 : check e2393373368570 [[],[.left],[]] .sourceHead = true := by decide
def e2393373368750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2393373368750 : Closed e2393373368750 ∧ code e2393373368750 = 11189466390958 := by decide
theorem cert_e2393373368750 : check e2393373368750 [[],[.left],[]] .sourceHead = true := by decide
def e2393373368942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373368942 : Closed e2393373368942 ∧ code e2393373368942 = 11189466391150 := by decide
theorem cert_e2393373368942 : check e2393373368942 [[],[.left],[]] .sourceHead = true := by decide
def e2393373368954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373368954 : Closed e2393373368954 ∧ code e2393373368954 = 11189466391162 := by decide
theorem cert_e2393373368954 : check e2393373368954 [[],[.left],[]] .sourceHead = true := by decide
def e2393373369118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2393373369118 : Closed e2393373369118 ∧ code e2393373369118 = 11189466391326 := by decide
theorem cert_e2393373369118 : check e2393373369118 [[],[.left],[]] .sourceHead = true := by decide
def e2393373369286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2393373369286 : Closed e2393373369286 ∧ code e2393373369286 = 11189466391494 := by decide
theorem cert_e2393373369286 : check e2393373369286 [[],[.left],[]] .sourceHead = true := by decide
def e2393373369902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2393373369902 : Closed e2393373369902 ∧ code e2393373369902 = 11189466392110 := by decide
theorem cert_e2393373369902 : check e2393373369902 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2393373370082 : Closed e2393373370082 ∧ code e2393373370082 = 11189466392290 := by decide
theorem cert_e2393373370082 : check e2393373370082 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2393373370094 : Closed e2393373370094 ∧ code e2393373370094 = 11189466392302 := by decide
theorem cert_e2393373370094 : check e2393373370094 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2393373370222 : Closed e2393373370222 ∧ code e2393373370222 = 11189466392430 := by decide
theorem cert_e2393373370222 : check e2393373370222 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2393373370230 : Closed e2393373370230 ∧ code e2393373370230 = 11189466392438 := by decide
theorem cert_e2393373370230 : check e2393373370230 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373370250 : Closed e2393373370250 ∧ code e2393373370250 = 11189466392458 := by decide
theorem cert_e2393373370250 : check e2393373370250 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373370274 : Closed e2393373370274 ∧ code e2393373370274 = 11189466392482 := by decide
theorem cert_e2393373370274 : check e2393373370274 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2393373370286 : Closed e2393373370286 ∧ code e2393373370286 = 11189466392494 := by decide
theorem cert_e2393373370286 : check e2393373370286 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2393373370294 : Closed e2393373370294 ∧ code e2393373370294 = 11189466392502 := by decide
theorem cert_e2393373370294 : check e2393373370294 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2393373370298 : Closed e2393373370298 ∧ code e2393373370298 = 11189466392506 := by decide
theorem cert_e2393373370298 : check e2393373370298 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2393373370430 : Closed e2393373370430 ∧ code e2393373370430 = 11189466392638 := by decide
theorem cert_e2393373370430 : check e2393373370430 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2393373370850 : Closed e2393373370850 ∧ code e2393373370850 = 11189466393058 := by decide
theorem cert_e2393373370850 : check e2393373370850 [[],[.left],[]] .sourceHead = true := by decide
def e2393373370862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2393373370862 : Closed e2393373370862 ∧ code e2393373370862 = 11189466393070 := by decide
theorem cert_e2393373370862 : check e2393373370862 [[],[.left],[]] .sourceHead = true := by decide
def e2393373371630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373371630 : Closed e2393373371630 ∧ code e2393373371630 = 11189466393838 := by decide
theorem cert_e2393373371630 : check e2393373371630 [[],[.left],[]] .sourceHead = true := by decide
def e2393373371638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373371638 : Closed e2393373371638 ∧ code e2393373371638 = 11189466393846 := by decide
theorem cert_e2393373371638 : check e2393373371638 [[],[.left],[]] .sourceHead = true := by decide
def e2393373371918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2393373371918 : Closed e2393373371918 ∧ code e2393373371918 = 11189466394126 := by decide
theorem cert_e2393373371918 : check e2393373371918 [[],[.left],[]] .sourceHead = true := by decide
def e2393373371930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373371930 : Closed e2393373371930 ∧ code e2393373371930 = 11189466394138 := by decide
theorem cert_e2393373371930 : check e2393373371930 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373372002 : Closed e2393373372002 ∧ code e2393373372002 = 11189466394210 := by decide
theorem cert_e2393373372002 : check e2393373372002 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373372014 : Closed e2393373372014 ∧ code e2393373372014 = 11189466394222 := by decide
theorem cert_e2393373372014 : check e2393373372014 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373372022 : Closed e2393373372022 ∧ code e2393373372022 = 11189466394230 := by decide
theorem cert_e2393373372022 : check e2393373372022 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373372026 : Closed e2393373372026 ∧ code e2393373372026 = 11189466394234 := by decide
theorem cert_e2393373372026 : check e2393373372026 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2393373372534 : Closed e2393373372534 ∧ code e2393373372534 = 11189466394742 := by decide
theorem cert_e2393373372534 : check e2393373372534 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2393373372538 : Closed e2393373372538 ∧ code e2393373372538 = 11189466394746 := by decide
theorem cert_e2393373372538 : check e2393373372538 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2393373372630 : Closed e2393373372630 ∧ code e2393373372630 = 11189466394838 := by decide
theorem cert_e2393373372630 : check e2393373372630 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373372726 : Closed e2393373372726 ∧ code e2393373372726 = 11189466394934 := by decide
theorem cert_e2393373372726 : check e2393373372726 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373372730 : Closed e2393373372730 ∧ code e2393373372730 = 11189466394938 := by decide
theorem cert_e2393373372730 : check e2393373372730 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2393373372814 : Closed e2393373372814 ∧ code e2393373372814 = 11189466395022 := by decide
theorem cert_e2393373372814 : check e2393373372814 [[],[.left],[]] .sourceHead = true := by decide
def e2393373372870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2393373372870 : Closed e2393373372870 ∧ code e2393373372870 = 11189466395078 := by decide
theorem cert_e2393373372870 : check e2393373372870 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2393373373206 : Closed e2393373373206 ∧ code e2393373373206 = 11189466395414 := by decide
theorem cert_e2393373373206 : check e2393373373206 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2393373373282 : Closed e2393373373282 ∧ code e2393373373282 = 11189466395490 := by decide
theorem cert_e2393373373282 : check e2393373373282 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2393373373294 : Closed e2393373373294 ∧ code e2393373373294 = 11189466395502 := by decide
theorem cert_e2393373373294 : check e2393373373294 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2393373373302 : Closed e2393373373302 ∧ code e2393373373302 = 11189466395510 := by decide
theorem cert_e2393373373302 : check e2393373373302 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373373322 : Closed e2393373373322 ∧ code e2393373373322 = 11189466395530 := by decide
theorem cert_e2393373373322 : check e2393373373322 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373373346 : Closed e2393373373346 ∧ code e2393373373346 = 11189466395554 := by decide
theorem cert_e2393373373346 : check e2393373373346 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2393373373358 : Closed e2393373373358 ∧ code e2393373373358 = 11189466395566 := by decide
theorem cert_e2393373373358 : check e2393373373358 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2393373373366 : Closed e2393373373366 ∧ code e2393373373366 = 11189466395574 := by decide
theorem cert_e2393373373366 : check e2393373373366 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2393373373370 : Closed e2393373373370 ∧ code e2393373373370 = 11189466395578 := by decide
theorem cert_e2393373373370 : check e2393373373370 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2393373373398 : Closed e2393373373398 ∧ code e2393373373398 = 11189466395606 := by decide
theorem cert_e2393373373398 : check e2393373373398 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2393373373402 : Closed e2393373373402 ∧ code e2393373373402 = 11189466395610 := by decide
theorem cert_e2393373373402 : check e2393373373402 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2393373373470 : Closed e2393373373470 ∧ code e2393373373470 = 11189466395678 := by decide
theorem cert_e2393373373470 : check e2393373373470 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2393373373666 : Closed e2393373373666 ∧ code e2393373373666 = 11189466395874 := by decide
theorem cert_e2393373373666 : check e2393373373666 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373373678 : Closed e2393373373678 ∧ code e2393373373678 = 11189466395886 := by decide
theorem cert_e2393373373678 : check e2393373373678 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373373686 : Closed e2393373373686 ∧ code e2393373373686 = 11189466395894 := by decide
theorem cert_e2393373373686 : check e2393373373686 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2393373373966 : Closed e2393373373966 ∧ code e2393373373966 = 11189466396174 := by decide
theorem cert_e2393373373966 : check e2393373373966 [[],[.left],[]] .sourceHead = true := by decide
def e2393373373978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373373978 : Closed e2393373373978 ∧ code e2393373373978 = 11189466396186 := by decide
theorem cert_e2393373373978 : check e2393373373978 [[],[.left],[]] .sourceHead = true := by decide
def e2393373374050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373374050 : Closed e2393373374050 ∧ code e2393373374050 = 11189466396258 := by decide
theorem cert_e2393373374050 : check e2393373374050 [[],[.left],[]] .sourceHead = true := by decide
def e2393373374062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373374062 : Closed e2393373374062 ∧ code e2393373374062 = 11189466396270 := by decide
theorem cert_e2393373374062 : check e2393373374062 [[],[.left],[]] .sourceHead = true := by decide
def e2393373374070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373374070 : Closed e2393373374070 ∧ code e2393373374070 = 11189466396278 := by decide
theorem cert_e2393373374070 : check e2393373374070 [[],[.left],[]] .sourceHead = true := by decide
def e2393373374074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373374074 : Closed e2393373374074 ∧ code e2393373374074 = 11189466396282 := by decide
theorem cert_e2393373374074 : check e2393373374074 [[],[.left],[]] .sourceHead = true := by decide
def e2393373374262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373374262 : Closed e2393373374262 ∧ code e2393373374262 = 11189466396470 := by decide
theorem cert_e2393373374262 : check e2393373374262 [[],[.left],[]] .sourceHead = true := by decide
def e2393373374266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373374266 : Closed e2393373374266 ∧ code e2393373374266 = 11189466396474 := by decide
theorem cert_e2393373374266 : check e2393373374266 [[],[.left],[]] .sourceHead = true := by decide
def e2393373377454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2393373377454 : Closed e2393373377454 ∧ code e2393373377454 = 11189466399662 := by decide
theorem cert_e2393373377454 : check e2393373377454 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373377466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2393373377466 : Closed e2393373377466 ∧ code e2393373377466 = 11189466399674 := by decide
theorem cert_e2393373377466 : check e2393373377466 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393373341526
#print axioms Blc.Floor43.cert_e2393373341530
#print axioms Blc.Floor43.cert_e2393373341546
