import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422365533814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422365533814 : Closed e2422365533814 ∧ code e2422365533814 = 11218458556022 := by decide
theorem cert_e2422365533814 : check e2422365533814 [[],[]] .smaller = true := by decide
def e2422365533818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365533818 : Closed e2422365533818 ∧ code e2422365533818 = 11218458556026 := by decide
theorem cert_e2422365533818 : check e2422365533818 [[],[]] .smaller = true := by decide
def e2422365534006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365534006 : Closed e2422365534006 ∧ code e2422365534006 = 11218458556214 := by decide
theorem cert_e2422365534006 : check e2422365534006 [[],[]] .smaller = true := by decide
def e2422365534010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365534010 : Closed e2422365534010 ∧ code e2422365534010 = 11218458556218 := by decide
theorem cert_e2422365534010 : check e2422365534010 [[],[]] .smaller = true := by decide
def e2422365534106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365534106 : Closed e2422365534106 ∧ code e2422365534106 = 11218458556314 := by decide
theorem cert_e2422365534106 : check e2422365534106 [[],[]] .smaller = true := by decide
def e2422365534150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 4)) (.lam (.var 1))))))))))
theorem wire_e2422365534150 : Closed e2422365534150 ∧ code e2422365534150 = 11218458556358 := by decide
theorem cert_e2422365534150 : check e2422365534150 [[],[]] .three = true := by decide
def e2422365534266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)))))))))
theorem wire_e2422365534266 : Closed e2422365534266 ∧ code e2422365534266 = 11218458556474 := by decide
theorem cert_e2422365534266 : check e2422365534266 [[],[]] .smaller = true := by decide
def e2422365534314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))))
theorem wire_e2422365534314 : Closed e2422365534314 ∧ code e2422365534314 = 11218458556522 := by decide
theorem cert_e2422365534314 : check e2422365534314 [[],[]] .smaller = true := by decide
def e2422365534362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365534362 : Closed e2422365534362 ∧ code e2422365534362 = 11218458556570 := by decide
theorem cert_e2422365534362 : check e2422365534362 [[],[]] .smaller = true := by decide
def e2422365534406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))))))))))
theorem wire_e2422365534406 : Closed e2422365534406 ∧ code e2422365534406 = 11218458556614 := by decide
theorem cert_e2422365534406 : check e2422365534406 [[],[]] .smaller = true := by decide
def e2422365534602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))))
theorem wire_e2422365534602 : Closed e2422365534602 ∧ code e2422365534602 = 11218458556810 := by decide
theorem cert_e2422365534602 : check e2422365534602 [[],[]] .smaller = true := by decide
def e2422365534626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))))
theorem wire_e2422365534626 : Closed e2422365534626 ∧ code e2422365534626 = 11218458556834 := by decide
theorem cert_e2422365534626 : check e2422365534626 [[],[]] .smaller = true := by decide
def e2422365534638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422365534638 : Closed e2422365534638 ∧ code e2422365534638 = 11218458556846 := by decide
theorem cert_e2422365534638 : check e2422365534638 [[],[]] .smaller = true := by decide
def e2422365534646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2422365534646 : Closed e2422365534646 ∧ code e2422365534646 = 11218458556854 := by decide
theorem cert_e2422365534646 : check e2422365534646 [[],[]] .smaller = true := by decide
def e2422365534650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422365534650 : Closed e2422365534650 ∧ code e2422365534650 = 11218458556858 := by decide
theorem cert_e2422365534650 : check e2422365534650 [[],[]] .smaller = true := by decide
def e2422365534678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2422365534678 : Closed e2422365534678 ∧ code e2422365534678 = 11218458556886 := by decide
theorem cert_e2422365534678 : check e2422365534678 [[],[]] .smaller = true := by decide
def e2422365534682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2422365534682 : Closed e2422365534682 ∧ code e2422365534682 = 11218458556890 := by decide
theorem cert_e2422365534682 : check e2422365534682 [[],[]] .smaller = true := by decide
def e2422365534698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422365534698 : Closed e2422365534698 ∧ code e2422365534698 = 11218458556906 := by decide
theorem cert_e2422365534698 : check e2422365534698 [[],[]] .smaller = true := by decide
def e2422365534734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))))))))))
theorem wire_e2422365534734 : Closed e2422365534734 ∧ code e2422365534734 = 11218458556942 := by decide
theorem cert_e2422365534734 : check e2422365534734 [[],[]] .smaller = true := by decide
def e2422365534746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365534746 : Closed e2422365534746 ∧ code e2422365534746 = 11218458556954 := by decide
theorem cert_e2422365534746 : check e2422365534746 [[],[]] .smaller = true := by decide
def e2422365534818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))))
theorem wire_e2422365534818 : Closed e2422365534818 ∧ code e2422365534818 = 11218458557026 := by decide
theorem cert_e2422365534818 : check e2422365534818 [[],[]] .smaller = true := by decide
def e2422365534830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365534830 : Closed e2422365534830 ∧ code e2422365534830 = 11218458557038 := by decide
theorem cert_e2422365534830 : check e2422365534830 [[],[]] .smaller = true := by decide
def e2422365534838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422365534838 : Closed e2422365534838 ∧ code e2422365534838 = 11218458557046 := by decide
theorem cert_e2422365534838 : check e2422365534838 [[],[]] .smaller = true := by decide
def e2422365534842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365534842 : Closed e2422365534842 ∧ code e2422365534842 = 11218458557050 := by decide
theorem cert_e2422365534842 : check e2422365534842 [[],[]] .smaller = true := by decide
def e2422365535030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365535030 : Closed e2422365535030 ∧ code e2422365535030 = 11218458557238 := by decide
theorem cert_e2422365535030 : check e2422365535030 [[],[]] .smaller = true := by decide
def e2422365535034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365535034 : Closed e2422365535034 ∧ code e2422365535034 = 11218458557242 := by decide
theorem cert_e2422365535034 : check e2422365535034 [[],[]] .smaller = true := by decide
def e2422365535130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365535130 : Closed e2422365535130 ∧ code e2422365535130 = 11218458557338 := by decide
theorem cert_e2422365535130 : check e2422365535130 [[],[]] .smaller = true := by decide
def e2422365535166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 4)))))))))
theorem wire_e2422365535166 : Closed e2422365535166 ∧ code e2422365535166 = 11218458557374 := by decide
theorem cert_e2422365535166 : check e2422365535166 [[],[]] .three = true := by decide
def e2422365535198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 3)) (.var 3)))))))))
theorem wire_e2422365535198 : Closed e2422365535198 ∧ code e2422365535198 = 11218458557406 := by decide
theorem cert_e2422365535198 : check e2422365535198 [[],[]] .smaller = true := by decide
def e2422365535214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 4)) (.var 2)))))))))
theorem wire_e2422365535214 : Closed e2422365535214 ∧ code e2422365535214 = 11218458557422 := by decide
theorem cert_e2422365535214 : check e2422365535214 [[],[]] .three = true := by decide
def e2422365535446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422365535446 : Closed e2422365535446 ∧ code e2422365535446 = 11218458557654 := by decide
theorem cert_e2422365535446 : check e2422365535446 [[],[]] .smaller = true := by decide
def e2422365535450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422365535450 : Closed e2422365535450 ∧ code e2422365535450 = 11218458557658 := by decide
theorem cert_e2422365535450 : check e2422365535450 [[],[]] .smaller = true := by decide
def e2422365535466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422365535466 : Closed e2422365535466 ∧ code e2422365535466 = 11218458557674 := by decide
theorem cert_e2422365535466 : check e2422365535466 [[],[]] .smaller = true := by decide
def e2422365535542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365535542 : Closed e2422365535542 ∧ code e2422365535542 = 11218458557750 := by decide
theorem cert_e2422365535542 : check e2422365535542 [[],[]] .smaller = true := by decide
def e2422365535546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365535546 : Closed e2422365535546 ∧ code e2422365535546 = 11218458557754 := by decide
theorem cert_e2422365535546 : check e2422365535546 [[],[]] .smaller = true := by decide
def e2422365535642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365535642 : Closed e2422365535642 ∧ code e2422365535642 = 11218458557850 := by decide
theorem cert_e2422365535642 : check e2422365535642 [[],[]] .smaller = true := by decide
def e2422365535678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 4)))))))))
theorem wire_e2422365535678 : Closed e2422365535678 ∧ code e2422365535678 = 11218458557886 := by decide
theorem cert_e2422365535678 : check e2422365535678 [[],[]] .three = true := by decide
def e2422365535734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 4)) (.var 1)))))))))
theorem wire_e2422365535734 : Closed e2422365535734 ∧ code e2422365535734 = 11218458557942 := by decide
theorem cert_e2422365535734 : check e2422365535734 [[],[]] .three = true := by decide
def e2422365535850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422365535850 : Closed e2422365535850 ∧ code e2422365535850 = 11218458558058 := by decide
theorem cert_e2422365535850 : check e2422365535850 [[],[]] .smaller = true := by decide
def e2422365535898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365535898 : Closed e2422365535898 ∧ code e2422365535898 = 11218458558106 := by decide
theorem cert_e2422365535898 : check e2422365535898 [[],[]] .smaller = true := by decide
def e2422365535966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 1)) (.var 3)))))))))
theorem wire_e2422365535966 : Closed e2422365535966 ∧ code e2422365535966 = 11218458558174 := by decide
theorem cert_e2422365535966 : check e2422365535966 [[],[]] .smaller = true := by decide
def e2422365535990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 3)) (.var 1)))))))))
theorem wire_e2422365535990 : Closed e2422365535990 ∧ code e2422365535990 = 11218458558198 := by decide
theorem cert_e2422365535990 : check e2422365535990 [[],[]] .smaller = true := by decide
def e2422365536026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.lam (.var 1))) (.var 0)))))))))
theorem wire_e2422365536026 : Closed e2422365536026 ∧ code e2422365536026 = 11218458558234 := by decide
theorem cert_e2422365536026 : check e2422365536026 [[],[]] .three = true := by decide
def e2422365536070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 0)) (.lam (.var 1))))))))))
theorem wire_e2422365536070 : Closed e2422365536070 ∧ code e2422365536070 = 11218458558278 := by decide
theorem cert_e2422365536070 : check e2422365536070 [[],[]] .three = true := by decide
def e2422365536110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 1)) (.var 2)))))))))
theorem wire_e2422365536110 : Closed e2422365536110 ∧ code e2422365536110 = 11218458558318 := by decide
theorem cert_e2422365536110 : check e2422365536110 [[],[]] .three = true := by decide
def e2422365536118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 4) (.var 2)) (.var 1)))))))))
theorem wire_e2422365536118 : Closed e2422365536118 ∧ code e2422365536118 = 11218458558326 := by decide
theorem cert_e2422365536118 : check e2422365536118 [[],[]] .three = true := by decide
def e2422365537214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422365537214 : Closed e2422365537214 ∧ code e2422365537214 = 11218458559422 := by decide
theorem cert_e2422365537214 : check e2422365537214 [[],[]] .smaller = true := by decide
def e2422365537246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422365537246 : Closed e2422365537246 ∧ code e2422365537246 = 11218458559454 := by decide
theorem cert_e2422365537246 : check e2422365537246 [[],[]] .smaller = true := by decide
def e2422365537262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422365537262 : Closed e2422365537262 ∧ code e2422365537262 = 11218458559470 := by decide
theorem cert_e2422365537262 : check e2422365537262 [[],[]] .smaller = true := by decide
def e2422365537270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422365537270 : Closed e2422365537270 ∧ code e2422365537270 = 11218458559478 := by decide
theorem cert_e2422365537270 : check e2422365537270 [[],[]] .smaller = true := by decide
def e2422365539094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))))
theorem wire_e2422365539094 : Closed e2422365539094 ∧ code e2422365539094 = 11218458561302 := by decide
theorem cert_e2422365539094 : check e2422365539094 [[],[]] .smaller = true := by decide
def e2422365539166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e2422365539166 : Closed e2422365539166 ∧ code e2422365539166 = 11218458561374 := by decide
theorem cert_e2422365539166 : check e2422365539166 [[],[]] .smaller = true := by decide
def e2422365539170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))))
theorem wire_e2422365539170 : Closed e2422365539170 ∧ code e2422365539170 = 11218458561378 := by decide
theorem cert_e2422365539170 : check e2422365539170 [[],[]] .smaller = true := by decide
def e2422365539182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422365539182 : Closed e2422365539182 ∧ code e2422365539182 = 11218458561390 := by decide
theorem cert_e2422365539182 : check e2422365539182 [[],[]] .smaller = true := by decide
def e2422365539190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422365539190 : Closed e2422365539190 ∧ code e2422365539190 = 11218458561398 := by decide
theorem cert_e2422365539190 : check e2422365539190 [[],[]] .smaller = true := by decide
def e2422365539194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e2422365539194 : Closed e2422365539194 ∧ code e2422365539194 = 11218458561402 := by decide
theorem cert_e2422365539194 : check e2422365539194 [[],[]] .smaller = true := by decide
def e2422365539210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422365539210 : Closed e2422365539210 ∧ code e2422365539210 = 11218458561418 := by decide
theorem cert_e2422365539210 : check e2422365539210 [[],[]] .smaller = true := by decide
def e2422365539234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422365539234 : Closed e2422365539234 ∧ code e2422365539234 = 11218458561442 := by decide
theorem cert_e2422365539234 : check e2422365539234 [[],[]] .smaller = true := by decide
def e2422365539246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422365539246 : Closed e2422365539246 ∧ code e2422365539246 = 11218458561454 := by decide
theorem cert_e2422365539246 : check e2422365539246 [[],[]] .smaller = true := by decide
def e2422365539254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))))))))))
theorem wire_e2422365539254 : Closed e2422365539254 ∧ code e2422365539254 = 11218458561462 := by decide
theorem cert_e2422365539254 : check e2422365539254 [[],[]] .smaller = true := by decide
def e2422365539258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422365539258 : Closed e2422365539258 ∧ code e2422365539258 = 11218458561466 := by decide
theorem cert_e2422365539258 : check e2422365539258 [[],[]] .smaller = true := by decide
def e2422365539286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422365539286 : Closed e2422365539286 ∧ code e2422365539286 = 11218458561494 := by decide
theorem cert_e2422365539286 : check e2422365539286 [[],[]] .smaller = true := by decide
def e2422365539290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422365539290 : Closed e2422365539290 ∧ code e2422365539290 = 11218458561498 := by decide
theorem cert_e2422365539290 : check e2422365539290 [[],[]] .smaller = true := by decide
def e2422365539306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e2422365539306 : Closed e2422365539306 ∧ code e2422365539306 = 11218458561514 := by decide
theorem cert_e2422365539306 : check e2422365539306 [[],[]] .smaller = true := by decide
def e2422365539358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))))))))))
theorem wire_e2422365539358 : Closed e2422365539358 ∧ code e2422365539358 = 11218458561566 := by decide
theorem cert_e2422365539358 : check e2422365539358 [[],[]] .smaller = true := by decide
def e2422365539454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 5)))))))))))
theorem wire_e2422365539454 : Closed e2422365539454 ∧ code e2422365539454 = 11218458561662 := by decide
theorem cert_e2422365539454 : check e2422365539454 [[],[]] .three = true := by decide
def e2422365539550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422365539550 : Closed e2422365539550 ∧ code e2422365539550 = 11218458561758 := by decide
theorem cert_e2422365539550 : check e2422365539550 [[],[]] .smaller = true := by decide
def e2422365539554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))))
theorem wire_e2422365539554 : Closed e2422365539554 ∧ code e2422365539554 = 11218458561762 := by decide
theorem cert_e2422365539554 : check e2422365539554 [[],[]] .smaller = true := by decide
def e2422365539566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365539566 : Closed e2422365539566 ∧ code e2422365539566 = 11218458561774 := by decide
theorem cert_e2422365539566 : check e2422365539566 [[],[]] .smaller = true := by decide
def e2422365539574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365539574 : Closed e2422365539574 ∧ code e2422365539574 = 11218458561782 := by decide
theorem cert_e2422365539574 : check e2422365539574 [[],[]] .smaller = true := by decide
def e2422365539578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422365539578 : Closed e2422365539578 ∧ code e2422365539578 = 11218458561786 := by decide
theorem cert_e2422365539578 : check e2422365539578 [[],[]] .smaller = true := by decide
def e2422365539854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422365539854 : Closed e2422365539854 ∧ code e2422365539854 = 11218458562062 := by decide
theorem cert_e2422365539854 : check e2422365539854 [[],[]] .smaller = true := by decide
def e2422365539866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422365539866 : Closed e2422365539866 ∧ code e2422365539866 = 11218458562074 := by decide
theorem cert_e2422365539866 : check e2422365539866 [[],[]] .smaller = true := by decide
def e2422365539938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422365539938 : Closed e2422365539938 ∧ code e2422365539938 = 11218458562146 := by decide
theorem cert_e2422365539938 : check e2422365539938 [[],[]] .smaller = true := by decide
def e2422365539950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365539950 : Closed e2422365539950 ∧ code e2422365539950 = 11218458562158 := by decide
theorem cert_e2422365539950 : check e2422365539950 [[],[]] .smaller = true := by decide
def e2422365539958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365539958 : Closed e2422365539958 ∧ code e2422365539958 = 11218458562166 := by decide
theorem cert_e2422365539958 : check e2422365539958 [[],[]] .smaller = true := by decide
def e2422365539962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365539962 : Closed e2422365539962 ∧ code e2422365539962 = 11218458562170 := by decide
theorem cert_e2422365539962 : check e2422365539962 [[],[]] .smaller = true := by decide
def e2422365540150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365540150 : Closed e2422365540150 ∧ code e2422365540150 = 11218458562358 := by decide
theorem cert_e2422365540150 : check e2422365540150 [[],[]] .smaller = true := by decide
def e2422365540154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365540154 : Closed e2422365540154 ∧ code e2422365540154 = 11218458562362 := by decide
theorem cert_e2422365540154 : check e2422365540154 [[],[]] .smaller = true := by decide
def e2422365540250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365540250 : Closed e2422365540250 ∧ code e2422365540250 = 11218458562458 := by decide
theorem cert_e2422365540250 : check e2422365540250 [[],[]] .smaller = true := by decide
def e2422365540294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 4) (.lam (.var 1)))))))))))
theorem wire_e2422365540294 : Closed e2422365540294 ∧ code e2422365540294 = 11218458562502 := by decide
theorem cert_e2422365540294 : check e2422365540294 [[],[]] .three = true := by decide
def e2422365544926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422365544926 : Closed e2422365544926 ∧ code e2422365544926 = 11218458567134 := by decide
theorem cert_e2422365544926 : check e2422365544926 [[],[]] .smaller = true := by decide
def e2422365544950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422365544950 : Closed e2422365544950 ∧ code e2422365544950 = 11218458567158 := by decide
theorem cert_e2422365544950 : check e2422365544950 [[],[]] .smaller = true := by decide
def e2422365545866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))))
theorem wire_e2422365545866 : Closed e2422365545866 ∧ code e2422365545866 = 11218458568074 := by decide
theorem cert_e2422365545866 : check e2422365545866 [[],[]] .smaller = true := by decide
def e2422365545890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))))
theorem wire_e2422365545890 : Closed e2422365545890 ∧ code e2422365545890 = 11218458568098 := by decide
theorem cert_e2422365545890 : check e2422365545890 [[],[]] .smaller = true := by decide
def e2422365545902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2422365545902 : Closed e2422365545902 ∧ code e2422365545902 = 11218458568110 := by decide
theorem cert_e2422365545902 : check e2422365545902 [[],[]] .smaller = true := by decide
def e2422365545910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422365545910 : Closed e2422365545910 ∧ code e2422365545910 = 11218458568118 := by decide
theorem cert_e2422365545910 : check e2422365545910 [[],[]] .smaller = true := by decide
def e2422365545914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2422365545914 : Closed e2422365545914 ∧ code e2422365545914 = 11218458568122 := by decide
theorem cert_e2422365545914 : check e2422365545914 [[],[]] .smaller = true := by decide
def e2422365545942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422365545942 : Closed e2422365545942 ∧ code e2422365545942 = 11218458568150 := by decide
theorem cert_e2422365545942 : check e2422365545942 [[],[]] .smaller = true := by decide
def e2422365545946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422365545946 : Closed e2422365545946 ∧ code e2422365545946 = 11218458568154 := by decide
theorem cert_e2422365545946 : check e2422365545946 [[],[]] .smaller = true := by decide
def e2422365545962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2422365545962 : Closed e2422365545962 ∧ code e2422365545962 = 11218458568170 := by decide
theorem cert_e2422365545962 : check e2422365545962 [[],[]] .smaller = true := by decide
def e2422365545998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))))))))))
theorem wire_e2422365545998 : Closed e2422365545998 ∧ code e2422365545998 = 11218458568206 := by decide
theorem cert_e2422365545998 : check e2422365545998 [[],[]] .smaller = true := by decide
def e2422365546010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422365546010 : Closed e2422365546010 ∧ code e2422365546010 = 11218458568218 := by decide
theorem cert_e2422365546010 : check e2422365546010 [[],[]] .smaller = true := by decide
def e2422365546082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))))
theorem wire_e2422365546082 : Closed e2422365546082 ∧ code e2422365546082 = 11218458568290 := by decide
theorem cert_e2422365546082 : check e2422365546082 [[],[]] .smaller = true := by decide
def e2422365546094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422365546094 : Closed e2422365546094 ∧ code e2422365546094 = 11218458568302 := by decide
theorem cert_e2422365546094 : check e2422365546094 [[],[]] .smaller = true := by decide
def e2422365546102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365546102 : Closed e2422365546102 ∧ code e2422365546102 = 11218458568310 := by decide
theorem cert_e2422365546102 : check e2422365546102 [[],[]] .smaller = true := by decide
def e2422365546106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422365546106 : Closed e2422365546106 ∧ code e2422365546106 = 11218458568314 := by decide
theorem cert_e2422365546106 : check e2422365546106 [[],[]] .smaller = true := by decide
def e2422365546294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365546294 : Closed e2422365546294 ∧ code e2422365546294 = 11218458568502 := by decide
theorem cert_e2422365546294 : check e2422365546294 [[],[]] .smaller = true := by decide
def e2422365546298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365546298 : Closed e2422365546298 ∧ code e2422365546298 = 11218458568506 := by decide
theorem cert_e2422365546298 : check e2422365546298 [[],[]] .smaller = true := by decide
def e2422365546394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365546394 : Closed e2422365546394 ∧ code e2422365546394 = 11218458568602 := by decide
theorem cert_e2422365546394 : check e2422365546394 [[],[]] .smaller = true := by decide
def e2422365546430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 4))))))))))
theorem wire_e2422365546430 : Closed e2422365546430 ∧ code e2422365546430 = 11218458568638 := by decide
theorem cert_e2422365546430 : check e2422365546430 [[],[]] .three = true := by decide
def e2422365546462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 3))))))))))
theorem wire_e2422365546462 : Closed e2422365546462 ∧ code e2422365546462 = 11218458568670 := by decide
theorem cert_e2422365546462 : check e2422365546462 [[],[]] .smaller = true := by decide
def e2422365546478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 4) (.var 2))))))))))
theorem wire_e2422365546478 : Closed e2422365546478 ∧ code e2422365546478 = 11218458568686 := by decide
theorem cert_e2422365546478 : check e2422365546478 [[],[]] .three = true := by decide
def e2422365548782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365548782 : Closed e2422365548782 ∧ code e2422365548782 = 11218458570990 := by decide
theorem cert_e2422365548782 : check e2422365548782 [[],[]] .smaller = true := by decide
def e2422365548790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365548790 : Closed e2422365548790 ∧ code e2422365548790 = 11218458570998 := by decide
theorem cert_e2422365548790 : check e2422365548790 [[],[]] .smaller = true := by decide
def e2422365549270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422365549270 : Closed e2422365549270 ∧ code e2422365549270 = 11218458571478 := by decide
theorem cert_e2422365549270 : check e2422365549270 [[],[]] .smaller = true := by decide
def e2422365549274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422365549274 : Closed e2422365549274 ∧ code e2422365549274 = 11218458571482 := by decide
theorem cert_e2422365549274 : check e2422365549274 [[],[]] .smaller = true := by decide
def e2422365549290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422365549290 : Closed e2422365549290 ∧ code e2422365549290 = 11218458571498 := by decide
theorem cert_e2422365549290 : check e2422365549290 [[],[]] .smaller = true := by decide
def e2422365549366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422365549366 : Closed e2422365549366 ∧ code e2422365549366 = 11218458571574 := by decide
theorem cert_e2422365549366 : check e2422365549366 [[],[]] .smaller = true := by decide
def e2422365549370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422365549370 : Closed e2422365549370 ∧ code e2422365549370 = 11218458571578 := by decide
theorem cert_e2422365549370 : check e2422365549370 [[],[]] .smaller = true := by decide
def e2422365549466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365549466 : Closed e2422365549466 ∧ code e2422365549466 = 11218458571674 := by decide
theorem cert_e2422365549466 : check e2422365549466 [[],[]] .smaller = true := by decide
def e2422365549502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 4))))))))))
theorem wire_e2422365549502 : Closed e2422365549502 ∧ code e2422365549502 = 11218458571710 := by decide
theorem cert_e2422365549502 : check e2422365549502 [[],[]] .three = true := by decide
def e2422365549558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 4) (.var 1))))))))))
theorem wire_e2422365549558 : Closed e2422365549558 ∧ code e2422365549558 = 11218458571766 := by decide
theorem cert_e2422365549558 : check e2422365549558 [[],[]] .three = true := by decide
def e2422365550710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365550710 : Closed e2422365550710 ∧ code e2422365550710 = 11218458572918 := by decide
theorem cert_e2422365550710 : check e2422365550710 [[],[]] .smaller = true := by decide
def e2422365550954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 0))))))))))
theorem wire_e2422365550954 : Closed e2422365550954 ∧ code e2422365550954 = 11218458573162 := by decide
theorem cert_e2422365550954 : check e2422365550954 [[],[]] .smaller = true := by decide
def e2422365551002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422365551002 : Closed e2422365551002 ∧ code e2422365551002 = 11218458573210 := by decide
theorem cert_e2422365551002 : check e2422365551002 [[],[]] .smaller = true := by decide
def e2422365551070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422365551070 : Closed e2422365551070 ∧ code e2422365551070 = 11218458573278 := by decide
theorem cert_e2422365551070 : check e2422365551070 [[],[]] .smaller = true := by decide
def e2422365551094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422365551094 : Closed e2422365551094 ∧ code e2422365551094 = 11218458573302 := by decide
theorem cert_e2422365551094 : check e2422365551094 [[],[]] .smaller = true := by decide
def e2422365551814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 0) (.lam (.var 1)))))))))))
theorem wire_e2422365551814 : Closed e2422365551814 ∧ code e2422365551814 = 11218458574022 := by decide
theorem cert_e2422365551814 : check e2422365551814 [[],[]] .three = true := by decide
def e2422365551854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422365551854 : Closed e2422365551854 ∧ code e2422365551854 = 11218458574062 := by decide
theorem cert_e2422365551854 : check e2422365551854 [[],[]] .three = true := by decide
def e2422365551862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 4) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422365551862 : Closed e2422365551862 ∧ code e2422365551862 = 11218458574070 := by decide
theorem cert_e2422365551862 : check e2422365551862 [[],[]] .three = true := by decide
def e2422365624174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e2422365624174 : Closed e2422365624174 ∧ code e2422365624174 = 11218458646382 := by decide
theorem cert_e2422365624174 : check e2422365624174 [[],[]] .smaller = true := by decide
def e2422365624182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e2422365624182 : Closed e2422365624182 ∧ code e2422365624182 = 11218458646390 := by decide
theorem cert_e2422365624182 : check e2422365624182 [[],[]] .smaller = true := by decide
def e2422365624246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e2422365624246 : Closed e2422365624246 ∧ code e2422365624246 = 11218458646454 := by decide
theorem cert_e2422365624246 : check e2422365624246 [[],[]] .smaller = true := by decide
def e2422365625582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422365625582 : Closed e2422365625582 ∧ code e2422365625582 = 11218458647790 := by decide
theorem cert_e2422365625582 : check e2422365625582 [[],[]] .smaller = true := by decide
def e2422365625590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422365625590 : Closed e2422365625590 ∧ code e2422365625590 = 11218458647798 := by decide
theorem cert_e2422365625590 : check e2422365625590 [[],[]] .smaller = true := by decide
def e2422365625974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422365625974 : Closed e2422365625974 ∧ code e2422365625974 = 11218458648182 := by decide
theorem cert_e2422365625974 : check e2422365625974 [[],[]] .smaller = true := by decide
def e2422365640366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422365640366 : Closed e2422365640366 ∧ code e2422365640366 = 11218458662574 := by decide
theorem cert_e2422365640366 : check e2422365640366 [[],[]] .smaller = true := by decide
def e2422365640374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2422365640374 : Closed e2422365640374 ∧ code e2422365640374 = 11218458662582 := by decide
theorem cert_e2422365640374 : check e2422365640374 [[],[]] .smaller = true := by decide
def e2422365640378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422365640378 : Closed e2422365640378 ∧ code e2422365640378 = 11218458662586 := by decide
theorem cert_e2422365640378 : check e2422365640378 [[],[]] .smaller = true := by decide
def e2422365640406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365640406 : Closed e2422365640406 ∧ code e2422365640406 = 11218458662614 := by decide
theorem cert_e2422365640406 : check e2422365640406 [[],[]] .smaller = true := by decide
def e2422365640410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365640410 : Closed e2422365640410 ∧ code e2422365640410 = 11218458662618 := by decide
theorem cert_e2422365640410 : check e2422365640410 [[],[]] .smaller = true := by decide
def e2422365640426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365640426 : Closed e2422365640426 ∧ code e2422365640426 = 11218458662634 := by decide
theorem cert_e2422365640426 : check e2422365640426 [[],[]] .smaller = true := by decide
def e2422365640534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422365640534 : Closed e2422365640534 ∧ code e2422365640534 = 11218458662742 := by decide
theorem cert_e2422365640534 : check e2422365640534 [[],[]] .smaller = true := by decide
def e2422365640538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422365640538 : Closed e2422365640538 ∧ code e2422365640538 = 11218458662746 := by decide
theorem cert_e2422365640538 : check e2422365640538 [[],[]] .smaller = true := by decide
def e2422365640554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365640554 : Closed e2422365640554 ∧ code e2422365640554 = 11218458662762 := by decide
theorem cert_e2422365640554 : check e2422365640554 [[],[]] .smaller = true := by decide
def e2422365640618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422365640618 : Closed e2422365640618 ∧ code e2422365640618 = 11218458662826 := by decide
theorem cert_e2422365640618 : check e2422365640618 [[],[]] .smaller = true := by decide
def e2422365641134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2422365641134 : Closed e2422365641134 ∧ code e2422365641134 = 11218458663342 := by decide
theorem cert_e2422365641134 : check e2422365641134 [[],[]] .smaller = true := by decide
def e2422365641142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2422365641142 : Closed e2422365641142 ∧ code e2422365641142 = 11218458663350 := by decide
theorem cert_e2422365641142 : check e2422365641142 [[],[]] .smaller = true := by decide
def e2422365641146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2422365641146 : Closed e2422365641146 ∧ code e2422365641146 = 11218458663354 := by decide
theorem cert_e2422365641146 : check e2422365641146 [[],[]] .smaller = true := by decide
def e2422365641174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2422365641174 : Closed e2422365641174 ∧ code e2422365641174 = 11218458663382 := by decide
theorem cert_e2422365641174 : check e2422365641174 [[],[]] .smaller = true := by decide
def e2422365641178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2422365641178 : Closed e2422365641178 ∧ code e2422365641178 = 11218458663386 := by decide
theorem cert_e2422365641178 : check e2422365641178 [[],[]] .smaller = true := by decide
def e2422365641194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2422365641194 : Closed e2422365641194 ∧ code e2422365641194 = 11218458663402 := by decide
theorem cert_e2422365641194 : check e2422365641194 [[],[]] .smaller = true := by decide
def e2422365641326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422365641326 : Closed e2422365641326 ∧ code e2422365641326 = 11218458663534 := by decide
theorem cert_e2422365641326 : check e2422365641326 [[],[]] .smaller = true := by decide
def e2422365641334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422365641334 : Closed e2422365641334 ∧ code e2422365641334 = 11218458663542 := by decide
theorem cert_e2422365641334 : check e2422365641334 [[],[]] .smaller = true := by decide
def e2422365641338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422365641338 : Closed e2422365641338 ∧ code e2422365641338 = 11218458663546 := by decide
theorem cert_e2422365641338 : check e2422365641338 [[],[]] .smaller = true := by decide
def e2422365641526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365641526 : Closed e2422365641526 ∧ code e2422365641526 = 11218458663734 := by decide
theorem cert_e2422365641526 : check e2422365641526 [[],[]] .smaller = true := by decide
def e2422365641530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365641530 : Closed e2422365641530 ∧ code e2422365641530 = 11218458663738 := by decide
theorem cert_e2422365641530 : check e2422365641530 [[],[]] .smaller = true := by decide
def e2422365641626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365641626 : Closed e2422365641626 ∧ code e2422365641626 = 11218458663834 := by decide
theorem cert_e2422365641626 : check e2422365641626 [[],[]] .smaller = true := by decide
def e2422365641942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422365641942 : Closed e2422365641942 ∧ code e2422365641942 = 11218458664150 := by decide
theorem cert_e2422365641942 : check e2422365641942 [[],[]] .smaller = true := by decide
def e2422365641946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422365641946 : Closed e2422365641946 ∧ code e2422365641946 = 11218458664154 := by decide
theorem cert_e2422365641946 : check e2422365641946 [[],[]] .smaller = true := by decide
def e2422365641962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422365641962 : Closed e2422365641962 ∧ code e2422365641962 = 11218458664170 := by decide
theorem cert_e2422365641962 : check e2422365641962 [[],[]] .smaller = true := by decide
def e2422365642038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422365642038 : Closed e2422365642038 ∧ code e2422365642038 = 11218458664246 := by decide
theorem cert_e2422365642038 : check e2422365642038 [[],[]] .smaller = true := by decide
def e2422365642042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422365642042 : Closed e2422365642042 ∧ code e2422365642042 = 11218458664250 := by decide
theorem cert_e2422365642042 : check e2422365642042 [[],[]] .smaller = true := by decide
def e2422365642138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422365642138 : Closed e2422365642138 ∧ code e2422365642138 = 11218458664346 := by decide
theorem cert_e2422365642138 : check e2422365642138 [[],[]] .smaller = true := by decide
def e2422365642174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 4)))))))))
theorem wire_e2422365642174 : Closed e2422365642174 ∧ code e2422365642174 = 11218458664382 := by decide
theorem cert_e2422365642174 : check e2422365642174 [[],[]] .three = true := by decide
def e2422365642206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 2)) (.var 3)))))))))
theorem wire_e2422365642206 : Closed e2422365642206 ∧ code e2422365642206 = 11218458664414 := by decide
theorem cert_e2422365642206 : check e2422365642206 [[],[]] .smaller = true := by decide
def e2422365642222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 2)))))))))
theorem wire_e2422365642222 : Closed e2422365642222 ∧ code e2422365642222 = 11218458664430 := by decide
theorem cert_e2422365642222 : check e2422365642222 [[],[]] .smaller = true := by decide
def e2422365642230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 4)) (.var 1)))))))))
theorem wire_e2422365642230 : Closed e2422365642230 ∧ code e2422365642230 = 11218458664438 := by decide
theorem cert_e2422365642230 : check e2422365642230 [[],[]] .three = true := by decide
def e2422365642346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))))
theorem wire_e2422365642346 : Closed e2422365642346 ∧ code e2422365642346 = 11218458664554 := by decide
theorem cert_e2422365642346 : check e2422365642346 [[],[]] .smaller = true := by decide
end Blc.Floor43
