import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372904682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422372904682 : Closed e2422372904682 ∧ code e2422372904682 = 11218465926890 := by decide
theorem cert_e2422372904682 : check e2422372904682 [[],[]] .smaller = true := by decide
def e2422372904790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2422372904790 : Closed e2422372904790 ∧ code e2422372904790 = 11218465926998 := by decide
theorem cert_e2422372904790 : check e2422372904790 [[],[]] .smaller = true := by decide
def e2422372904794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2422372904794 : Closed e2422372904794 ∧ code e2422372904794 = 11218465927002 := by decide
theorem cert_e2422372904794 : check e2422372904794 [[],[]] .smaller = true := by decide
def e2422372904810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2422372904810 : Closed e2422372904810 ∧ code e2422372904810 = 11218465927018 := by decide
theorem cert_e2422372904810 : check e2422372904810 [[],[]] .smaller = true := by decide
def e2422372905438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2422372905438 : Closed e2422372905438 ∧ code e2422372905438 = 11218465927646 := by decide
theorem cert_e2422372905438 : check e2422372905438 [[],[]] .three = true := by decide
def e2422372905462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2422372905462 : Closed e2422372905462 ∧ code e2422372905462 = 11218465927670 := by decide
theorem cert_e2422372905462 : check e2422372905462 [[],[]] .three = true := by decide
def e2422372905838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2422372905838 : Closed e2422372905838 ∧ code e2422372905838 = 11218465928046 := by decide
theorem cert_e2422372905838 : check e2422372905838 [[],[]] .smaller = true := by decide
def e2422372905846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2422372905846 : Closed e2422372905846 ∧ code e2422372905846 = 11218465928054 := by decide
theorem cert_e2422372905846 : check e2422372905846 [[],[]] .smaller = true := by decide
def e2422372905902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2422372905902 : Closed e2422372905902 ∧ code e2422372905902 = 11218465928110 := by decide
theorem cert_e2422372905902 : check e2422372905902 [[],[]] .smaller = true := by decide
def e2422372905914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2422372905914 : Closed e2422372905914 ∧ code e2422372905914 = 11218465928122 := by decide
theorem cert_e2422372905914 : check e2422372905914 [[],[]] .smaller = true := by decide
def e2422372905942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2422372905942 : Closed e2422372905942 ∧ code e2422372905942 = 11218465928150 := by decide
theorem cert_e2422372905942 : check e2422372905942 [[],[]] .smaller = true := by decide
def e2422372905946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2422372905946 : Closed e2422372905946 ∧ code e2422372905946 = 11218465928154 := by decide
theorem cert_e2422372905946 : check e2422372905946 [[],[]] .smaller = true := by decide
def e2422372906222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372906222 : Closed e2422372906222 ∧ code e2422372906222 = 11218465928430 := by decide
theorem cert_e2422372906222 : check e2422372906222 [[],[]] .smaller = true := by decide
def e2422372906230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372906230 : Closed e2422372906230 ∧ code e2422372906230 = 11218465928438 := by decide
theorem cert_e2422372906230 : check e2422372906230 [[],[]] .smaller = true := by decide
def e2422372906558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2422372906558 : Closed e2422372906558 ∧ code e2422372906558 = 11218465928766 := by decide
theorem cert_e2422372906558 : check e2422372906558 [[],[]] .three = true := by decide
def e2422372906606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372906606 : Closed e2422372906606 ∧ code e2422372906606 = 11218465928814 := by decide
theorem cert_e2422372906606 : check e2422372906606 [[],[]] .smaller = true := by decide
def e2422372906618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372906618 : Closed e2422372906618 ∧ code e2422372906618 = 11218465928826 := by decide
theorem cert_e2422372906618 : check e2422372906618 [[],[]] .smaller = true := by decide
def e2422372906806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372906806 : Closed e2422372906806 ∧ code e2422372906806 = 11218465929014 := by decide
theorem cert_e2422372906806 : check e2422372906806 [[],[]] .smaller = true := by decide
def e2422372906810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372906810 : Closed e2422372906810 ∧ code e2422372906810 = 11218465929018 := by decide
theorem cert_e2422372906810 : check e2422372906810 [[],[]] .smaller = true := by decide
def e2422372906894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2422372906894 : Closed e2422372906894 ∧ code e2422372906894 = 11218465929102 := by decide
theorem cert_e2422372906894 : check e2422372906894 [[],[]] .three = true := by decide
def e2422372907054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422372907054 : Closed e2422372907054 ∧ code e2422372907054 = 11218465929262 := by decide
theorem cert_e2422372907054 : check e2422372907054 [[],[]] .smaller = true := by decide
def e2422372907230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422372907230 : Closed e2422372907230 ∧ code e2422372907230 = 11218465929438 := by decide
theorem cert_e2422372907230 : check e2422372907230 [[],[]] .three = true := by decide
def e2422372907246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422372907246 : Closed e2422372907246 ∧ code e2422372907246 = 11218465929454 := by decide
theorem cert_e2422372907246 : check e2422372907246 [[],[]] .smaller = true := by decide
def e2422372907254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422372907254 : Closed e2422372907254 ∧ code e2422372907254 = 11218465929462 := by decide
theorem cert_e2422372907254 : check e2422372907254 [[],[]] .smaller = true := by decide
def e2422372907258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422372907258 : Closed e2422372907258 ∧ code e2422372907258 = 11218465929466 := by decide
theorem cert_e2422372907258 : check e2422372907258 [[],[]] .three = true := by decide
def e2422372907438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422372907438 : Closed e2422372907438 ∧ code e2422372907438 = 11218465929646 := by decide
theorem cert_e2422372907438 : check e2422372907438 [[],[]] .smaller = true := by decide
def e2422372907450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422372907450 : Closed e2422372907450 ∧ code e2422372907450 = 11218465929658 := by decide
theorem cert_e2422372907450 : check e2422372907450 [[],[]] .smaller = true := by decide
def e2422372907498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422372907498 : Closed e2422372907498 ∧ code e2422372907498 = 11218465929706 := by decide
theorem cert_e2422372907498 : check e2422372907498 [[],[]] .smaller = true := by decide
def e2422372907582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422372907582 : Closed e2422372907582 ∧ code e2422372907582 = 11218465929790 := by decide
theorem cert_e2422372907582 : check e2422372907582 [[],[]] .three = true := by decide
def e2422372907630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372907630 : Closed e2422372907630 ∧ code e2422372907630 = 11218465929838 := by decide
theorem cert_e2422372907630 : check e2422372907630 [[],[]] .smaller = true := by decide
def e2422372907642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372907642 : Closed e2422372907642 ∧ code e2422372907642 = 11218465929850 := by decide
theorem cert_e2422372907642 : check e2422372907642 [[],[]] .smaller = true := by decide
def e2422372907806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422372907806 : Closed e2422372907806 ∧ code e2422372907806 = 11218465930014 := by decide
theorem cert_e2422372907806 : check e2422372907806 [[],[]] .smaller = true := by decide
def e2422372907906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372907906 : Closed e2422372907906 ∧ code e2422372907906 = 11218465930114 := by decide
theorem cert_e2422372907906 : check e2422372907906 [[],[]] .smaller = true := by decide
def e2422372907918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422372907918 : Closed e2422372907918 ∧ code e2422372907918 = 11218465930126 := by decide
theorem cert_e2422372907918 : check e2422372907918 [[],[]] .smaller = true := by decide
def e2422372907930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372907930 : Closed e2422372907930 ∧ code e2422372907930 = 11218465930138 := by decide
theorem cert_e2422372907930 : check e2422372907930 [[],[]] .smaller = true := by decide
def e2422372907974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422372907974 : Closed e2422372907974 ∧ code e2422372907974 = 11218465930182 := by decide
theorem cert_e2422372907974 : check e2422372907974 [[],[]] .three = true := by decide
def e2422372907998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))) (.var 3)))))))
theorem wire_e2422372907998 : Closed e2422372907998 ∧ code e2422372907998 = 11218465930206 := by decide
theorem cert_e2422372907998 : check e2422372907998 [[],[]] .three = true := by decide
def e2422372908054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422372908054 : Closed e2422372908054 ∧ code e2422372908054 = 11218465930262 := by decide
theorem cert_e2422372908054 : check e2422372908054 [[],[]] .smaller = true := by decide
def e2422372908126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422372908126 : Closed e2422372908126 ∧ code e2422372908126 = 11218465930334 := by decide
theorem cert_e2422372908126 : check e2422372908126 [[],[]] .three = true := by decide
def e2422372908150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422372908150 : Closed e2422372908150 ∧ code e2422372908150 = 11218465930358 := by decide
theorem cert_e2422372908150 : check e2422372908150 [[],[]] .smaller = true := by decide
def e2422372908246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2422372908246 : Closed e2422372908246 ∧ code e2422372908246 = 11218465930454 := by decide
theorem cert_e2422372908246 : check e2422372908246 [[],[]] .smaller = true := by decide
def e2422372908250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422372908250 : Closed e2422372908250 ∧ code e2422372908250 = 11218465930458 := by decide
theorem cert_e2422372908250 : check e2422372908250 [[],[]] .smaller = true := by decide
def e2422372908266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422372908266 : Closed e2422372908266 ∧ code e2422372908266 = 11218465930474 := by decide
theorem cert_e2422372908266 : check e2422372908266 [[],[]] .smaller = true := by decide
def e2422372908342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372908342 : Closed e2422372908342 ∧ code e2422372908342 = 11218465930550 := by decide
theorem cert_e2422372908342 : check e2422372908342 [[],[]] .smaller = true := by decide
def e2422372908346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372908346 : Closed e2422372908346 ∧ code e2422372908346 = 11218465930554 := by decide
theorem cert_e2422372908346 : check e2422372908346 [[],[]] .smaller = true := by decide
def e2422372908418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372908418 : Closed e2422372908418 ∧ code e2422372908418 = 11218465930626 := by decide
theorem cert_e2422372908418 : check e2422372908418 [[],[]] .smaller = true := by decide
def e2422372908430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422372908430 : Closed e2422372908430 ∧ code e2422372908430 = 11218465930638 := by decide
theorem cert_e2422372908430 : check e2422372908430 [[],[]] .smaller = true := by decide
def e2422372908442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372908442 : Closed e2422372908442 ∧ code e2422372908442 = 11218465930650 := by decide
theorem cert_e2422372908442 : check e2422372908442 [[],[]] .smaller = true := by decide
def e2422372908510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 3)))))))
theorem wire_e2422372908510 : Closed e2422372908510 ∧ code e2422372908510 = 11218465930718 := by decide
theorem cert_e2422372908510 : check e2422372908510 [[],[]] .three = true := by decide
def e2422372908514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422372908514 : Closed e2422372908514 ∧ code e2422372908514 = 11218465930722 := by decide
theorem cert_e2422372908514 : check e2422372908514 [[],[]] .three = true := by decide
def e2422372908526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3))) (.var 2)))))))
theorem wire_e2422372908526 : Closed e2422372908526 ∧ code e2422372908526 = 11218465930734 := by decide
theorem cert_e2422372908526 : check e2422372908526 [[],[]] .three = true := by decide
def e2422372908590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372908590 : Closed e2422372908590 ∧ code e2422372908590 = 11218465930798 := by decide
theorem cert_e2422372908590 : check e2422372908590 [[],[]] .three = true := by decide
def e2422372908598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422372908598 : Closed e2422372908598 ∧ code e2422372908598 = 11218465930806 := by decide
theorem cert_e2422372908598 : check e2422372908598 [[],[]] .three = true := by decide
def e2422372908602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422372908602 : Closed e2422372908602 ∧ code e2422372908602 = 11218465930810 := by decide
theorem cert_e2422372908602 : check e2422372908602 [[],[]] .three = true := by decide
def e2422372908686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422372908686 : Closed e2422372908686 ∧ code e2422372908686 = 11218465930894 := by decide
theorem cert_e2422372908686 : check e2422372908686 [[],[]] .three = true := by decide
def e2422372908742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422372908742 : Closed e2422372908742 ∧ code e2422372908742 = 11218465930950 := by decide
theorem cert_e2422372908742 : check e2422372908742 [[],[]] .three = true := by decide
def e2422372908766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))) (.var 3)))))))
theorem wire_e2422372908766 : Closed e2422372908766 ∧ code e2422372908766 = 11218465930974 := by decide
theorem cert_e2422372908766 : check e2422372908766 [[],[]] .three = true := by decide
def e2422372908770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422372908770 : Closed e2422372908770 ∧ code e2422372908770 = 11218465930978 := by decide
theorem cert_e2422372908770 : check e2422372908770 [[],[]] .three = true := by decide
def e2422372908782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2))) (.var 2)))))))
theorem wire_e2422372908782 : Closed e2422372908782 ∧ code e2422372908782 = 11218465930990 := by decide
theorem cert_e2422372908782 : check e2422372908782 [[],[]] .three = true := by decide
def e2422372908790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 3))) (.var 1)))))))
theorem wire_e2422372908790 : Closed e2422372908790 ∧ code e2422372908790 = 11218465930998 := by decide
theorem cert_e2422372908790 : check e2422372908790 [[],[]] .three = true := by decide
def e2422372910046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422372910046 : Closed e2422372910046 ∧ code e2422372910046 = 11218465932254 := by decide
theorem cert_e2422372910046 : check e2422372910046 [[],[]] .smaller = true := by decide
def e2422372910062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422372910062 : Closed e2422372910062 ∧ code e2422372910062 = 11218465932270 := by decide
theorem cert_e2422372910062 : check e2422372910062 [[],[]] .smaller = true := by decide
def e2422372911982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422372911982 : Closed e2422372911982 ∧ code e2422372911982 = 11218465934190 := by decide
theorem cert_e2422372911982 : check e2422372911982 [[],[]] .smaller = true := by decide
def e2422372911990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422372911990 : Closed e2422372911990 ∧ code e2422372911990 = 11218465934198 := by decide
theorem cert_e2422372911990 : check e2422372911990 [[],[]] .smaller = true := by decide
def e2422372912046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422372912046 : Closed e2422372912046 ∧ code e2422372912046 = 11218465934254 := by decide
theorem cert_e2422372912046 : check e2422372912046 [[],[]] .smaller = true := by decide
def e2422372912058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422372912058 : Closed e2422372912058 ∧ code e2422372912058 = 11218465934266 := by decide
theorem cert_e2422372912058 : check e2422372912058 [[],[]] .smaller = true := by decide
def e2422372912086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422372912086 : Closed e2422372912086 ∧ code e2422372912086 = 11218465934294 := by decide
theorem cert_e2422372912086 : check e2422372912086 [[],[]] .smaller = true := by decide
def e2422372912090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422372912090 : Closed e2422372912090 ∧ code e2422372912090 = 11218465934298 := by decide
theorem cert_e2422372912090 : check e2422372912090 [[],[]] .smaller = true := by decide
def e2422372912366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422372912366 : Closed e2422372912366 ∧ code e2422372912366 = 11218465934574 := by decide
theorem cert_e2422372912366 : check e2422372912366 [[],[]] .smaller = true := by decide
def e2422372912374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422372912374 : Closed e2422372912374 ∧ code e2422372912374 = 11218465934582 := by decide
theorem cert_e2422372912374 : check e2422372912374 [[],[]] .smaller = true := by decide
def e2422372912702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2422372912702 : Closed e2422372912702 ∧ code e2422372912702 = 11218465934910 := by decide
theorem cert_e2422372912702 : check e2422372912702 [[],[]] .three = true := by decide
def e2422372912750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422372912750 : Closed e2422372912750 ∧ code e2422372912750 = 11218465934958 := by decide
theorem cert_e2422372912750 : check e2422372912750 [[],[]] .smaller = true := by decide
def e2422372912762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422372912762 : Closed e2422372912762 ∧ code e2422372912762 = 11218465934970 := by decide
theorem cert_e2422372912762 : check e2422372912762 [[],[]] .smaller = true := by decide
def e2422372912950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422372912950 : Closed e2422372912950 ∧ code e2422372912950 = 11218465935158 := by decide
theorem cert_e2422372912950 : check e2422372912950 [[],[]] .smaller = true := by decide
def e2422372912954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422372912954 : Closed e2422372912954 ∧ code e2422372912954 = 11218465935162 := by decide
theorem cert_e2422372912954 : check e2422372912954 [[],[]] .smaller = true := by decide
def e2422372913038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2422372913038 : Closed e2422372913038 ∧ code e2422372913038 = 11218465935246 := by decide
theorem cert_e2422372913038 : check e2422372913038 [[],[]] .three = true := by decide
def e2422372917694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 4)))))))))
theorem wire_e2422372917694 : Closed e2422372917694 ∧ code e2422372917694 = 11218465939902 := by decide
theorem cert_e2422372917694 : check e2422372917694 [[],[]] .three = true := by decide
def e2422372917726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2422372917726 : Closed e2422372917726 ∧ code e2422372917726 = 11218465939934 := by decide
theorem cert_e2422372917726 : check e2422372917726 [[],[]] .smaller = true := by decide
def e2422372917750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2422372917750 : Closed e2422372917750 ∧ code e2422372917750 = 11218465939958 := by decide
theorem cert_e2422372917750 : check e2422372917750 [[],[]] .smaller = true := by decide
def e2422372917754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 4) (.var 0)))))))))
theorem wire_e2422372917754 : Closed e2422372917754 ∧ code e2422372917754 = 11218465939962 := by decide
theorem cert_e2422372917754 : check e2422372917754 [[],[]] .three = true := by decide
def e2422372918702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2422372918702 : Closed e2422372918702 ∧ code e2422372918702 = 11218465940910 := by decide
theorem cert_e2422372918702 : check e2422372918702 [[],[]] .smaller = true := by decide
def e2422372918714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2422372918714 : Closed e2422372918714 ∧ code e2422372918714 = 11218465940922 := by decide
theorem cert_e2422372918714 : check e2422372918714 [[],[]] .smaller = true := by decide
def e2422372918762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2422372918762 : Closed e2422372918762 ∧ code e2422372918762 = 11218465940970 := by decide
theorem cert_e2422372918762 : check e2422372918762 [[],[]] .smaller = true := by decide
def e2422372918846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 4)))))))))
theorem wire_e2422372918846 : Closed e2422372918846 ∧ code e2422372918846 = 11218465941054 := by decide
theorem cert_e2422372918846 : check e2422372918846 [[],[]] .three = true := by decide
def e2422372918894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422372918894 : Closed e2422372918894 ∧ code e2422372918894 = 11218465941102 := by decide
theorem cert_e2422372918894 : check e2422372918894 [[],[]] .smaller = true := by decide
def e2422372918906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422372918906 : Closed e2422372918906 ∧ code e2422372918906 = 11218465941114 := by decide
theorem cert_e2422372918906 : check e2422372918906 [[],[]] .smaller = true := by decide
def e2422372919070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2422372919070 : Closed e2422372919070 ∧ code e2422372919070 = 11218465941278 := by decide
theorem cert_e2422372919070 : check e2422372919070 [[],[]] .smaller = true := by decide
def e2422372919170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 0))))))))))
theorem wire_e2422372919170 : Closed e2422372919170 ∧ code e2422372919170 = 11218465941378 := by decide
theorem cert_e2422372919170 : check e2422372919170 [[],[]] .smaller = true := by decide
def e2422372919182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2422372919182 : Closed e2422372919182 ∧ code e2422372919182 = 11218465941390 := by decide
theorem cert_e2422372919182 : check e2422372919182 [[],[]] .smaller = true := by decide
def e2422372919194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372919194 : Closed e2422372919194 ∧ code e2422372919194 = 11218465941402 := by decide
theorem cert_e2422372919194 : check e2422372919194 [[],[]] .smaller = true := by decide
def e2422372919238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.lam (.var 1)))))))))
theorem wire_e2422372919238 : Closed e2422372919238 ∧ code e2422372919238 = 11218465941446 := by decide
theorem cert_e2422372919238 : check e2422372919238 [[],[]] .three = true := by decide
def e2422372919262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 3) (.var 3))))))))
theorem wire_e2422372919262 : Closed e2422372919262 ∧ code e2422372919262 = 11218465941470 := by decide
theorem cert_e2422372919262 : check e2422372919262 [[],[]] .three = true := by decide
def e2422372921470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 5)))))))))
theorem wire_e2422372921470 : Closed e2422372921470 ∧ code e2422372921470 = 11218465943678 := by decide
theorem cert_e2422372921470 : check e2422372921470 [[],[]] .three = true := by decide
def e2422372921582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2422372921582 : Closed e2422372921582 ∧ code e2422372921582 = 11218465943790 := by decide
theorem cert_e2422372921582 : check e2422372921582 [[],[]] .smaller = true := by decide
def e2422372921590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2422372921590 : Closed e2422372921590 ∧ code e2422372921590 = 11218465943798 := by decide
theorem cert_e2422372921590 : check e2422372921590 [[],[]] .smaller = true := by decide
def e2422372922070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422372922070 : Closed e2422372922070 ∧ code e2422372922070 = 11218465944278 := by decide
theorem cert_e2422372922070 : check e2422372922070 [[],[]] .smaller = true := by decide
def e2422372922074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422372922074 : Closed e2422372922074 ∧ code e2422372922074 = 11218465944282 := by decide
theorem cert_e2422372922074 : check e2422372922074 [[],[]] .smaller = true := by decide
def e2422372922090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422372922090 : Closed e2422372922090 ∧ code e2422372922090 = 11218465944298 := by decide
theorem cert_e2422372922090 : check e2422372922090 [[],[]] .smaller = true := by decide
def e2422372922166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422372922166 : Closed e2422372922166 ∧ code e2422372922166 = 11218465944374 := by decide
theorem cert_e2422372922166 : check e2422372922166 [[],[]] .smaller = true := by decide
def e2422372922170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422372922170 : Closed e2422372922170 ∧ code e2422372922170 = 11218465944378 := by decide
theorem cert_e2422372922170 : check e2422372922170 [[],[]] .smaller = true := by decide
def e2422372922242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 0))))))))))
theorem wire_e2422372922242 : Closed e2422372922242 ∧ code e2422372922242 = 11218465944450 := by decide
theorem cert_e2422372922242 : check e2422372922242 [[],[]] .smaller = true := by decide
def e2422372922254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2422372922254 : Closed e2422372922254 ∧ code e2422372922254 = 11218465944462 := by decide
theorem cert_e2422372922254 : check e2422372922254 [[],[]] .smaller = true := by decide
def e2422372922266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422372922266 : Closed e2422372922266 ∧ code e2422372922266 = 11218465944474 := by decide
theorem cert_e2422372922266 : check e2422372922266 [[],[]] .smaller = true := by decide
def e2422372922334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 3))))))))
theorem wire_e2422372922334 : Closed e2422372922334 ∧ code e2422372922334 = 11218465944542 := by decide
theorem cert_e2422372922334 : check e2422372922334 [[],[]] .three = true := by decide
def e2422372922338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422372922338 : Closed e2422372922338 ∧ code e2422372922338 = 11218465944546 := by decide
theorem cert_e2422372922338 : check e2422372922338 [[],[]] .three = true := by decide
def e2422372922350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 3) (.var 2))))))))
theorem wire_e2422372922350 : Closed e2422372922350 ∧ code e2422372922350 = 11218465944558 := by decide
theorem cert_e2422372922350 : check e2422372922350 [[],[]] .three = true := by decide
def e2422372923454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422372923454 : Closed e2422372923454 ∧ code e2422372923454 = 11218465945662 := by decide
theorem cert_e2422372923454 : check e2422372923454 [[],[]] .three = true := by decide
def e2422372923502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422372923502 : Closed e2422372923502 ∧ code e2422372923502 = 11218465945710 := by decide
theorem cert_e2422372923502 : check e2422372923502 [[],[]] .three = true := by decide
def e2422372923514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422372923514 : Closed e2422372923514 ∧ code e2422372923514 = 11218465945722 := by decide
theorem cert_e2422372923514 : check e2422372923514 [[],[]] .three = true := by decide
def e2422372923790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422372923790 : Closed e2422372923790 ∧ code e2422372923790 = 11218465945998 := by decide
theorem cert_e2422372923790 : check e2422372923790 [[],[]] .three = true := by decide
def e2422372923846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422372923846 : Closed e2422372923846 ∧ code e2422372923846 = 11218465946054 := by decide
theorem cert_e2422372923846 : check e2422372923846 [[],[]] .three = true := by decide
def e2422372923870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372923870 : Closed e2422372923870 ∧ code e2422372923870 = 11218465946078 := by decide
theorem cert_e2422372923870 : check e2422372923870 [[],[]] .three = true := by decide
def e2422372923874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422372923874 : Closed e2422372923874 ∧ code e2422372923874 = 11218465946082 := by decide
theorem cert_e2422372923874 : check e2422372923874 [[],[]] .three = true := by decide
def e2422372923886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372923886 : Closed e2422372923886 ∧ code e2422372923886 = 11218465946094 := by decide
theorem cert_e2422372923886 : check e2422372923886 [[],[]] .three = true := by decide
def e2422372923894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372923894 : Closed e2422372923894 ∧ code e2422372923894 = 11218465946102 := by decide
theorem cert_e2422372923894 : check e2422372923894 [[],[]] .three = true := by decide
def e2422372925870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 2)))))))
theorem wire_e2422372925870 : Closed e2422372925870 ∧ code e2422372925870 = 11218465948078 := by decide
theorem cert_e2422372925870 : check e2422372925870 [[],[]] .smaller = true := by decide
def e2422372926062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372926062 : Closed e2422372926062 ∧ code e2422372926062 = 11218465948270 := by decide
theorem cert_e2422372926062 : check e2422372926062 [[],[]] .smaller = true := by decide
def e2422372926074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372926074 : Closed e2422372926074 ∧ code e2422372926074 = 11218465948282 := by decide
theorem cert_e2422372926074 : check e2422372926074 [[],[]] .smaller = true := by decide
def e2422372926430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3)))) (.var 3)))))))
theorem wire_e2422372926430 : Closed e2422372926430 ∧ code e2422372926430 = 11218465948638 := by decide
theorem cert_e2422372926430 : check e2422372926430 [[],[]] .three = true := by decide
def e2422372926446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 2)))))))
theorem wire_e2422372926446 : Closed e2422372926446 ∧ code e2422372926446 = 11218465948654 := by decide
theorem cert_e2422372926446 : check e2422372926446 [[],[]] .smaller = true := by decide
def e2422372926454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5)))) (.var 1)))))))
theorem wire_e2422372926454 : Closed e2422372926454 ∧ code e2422372926454 = 11218465948662 := by decide
theorem cert_e2422372926454 : check e2422372926454 [[],[]] .three = true := by decide
def e2422372927198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e2422372927198 : Closed e2422372927198 ∧ code e2422372927198 = 11218465949406 := by decide
theorem cert_e2422372927198 : check e2422372927198 [[],[]] .three = true := by decide
def e2422372927214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2422372927214 : Closed e2422372927214 ∧ code e2422372927214 = 11218465949422 := by decide
theorem cert_e2422372927214 : check e2422372927214 [[],[]] .smaller = true := by decide
def e2422372927222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2422372927222 : Closed e2422372927222 ∧ code e2422372927222 = 11218465949430 := by decide
theorem cert_e2422372927222 : check e2422372927222 [[],[]] .smaller = true := by decide
def e2422372927226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 4)))) (.var 0)))))))
theorem wire_e2422372927226 : Closed e2422372927226 ∧ code e2422372927226 = 11218465949434 := by decide
theorem cert_e2422372927226 : check e2422372927226 [[],[]] .three = true := by decide
def e2422372927326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e2422372927326 : Closed e2422372927326 ∧ code e2422372927326 = 11218465949534 := by decide
theorem cert_e2422372927326 : check e2422372927326 [[],[]] .three = true := by decide
def e2422372927342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))))
theorem wire_e2422372927342 : Closed e2422372927342 ∧ code e2422372927342 = 11218465949550 := by decide
theorem cert_e2422372927342 : check e2422372927342 [[],[]] .smaller = true := by decide
def e2422372927354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2422372927354 : Closed e2422372927354 ∧ code e2422372927354 = 11218465949562 := by decide
theorem cert_e2422372927354 : check e2422372927354 [[],[]] .smaller = true := by decide
def e2422372927406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2422372927406 : Closed e2422372927406 ∧ code e2422372927406 = 11218465949614 := by decide
theorem cert_e2422372927406 : check e2422372927406 [[],[]] .smaller = true := by decide
def e2422372927446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2422372927446 : Closed e2422372927446 ∧ code e2422372927446 = 11218465949654 := by decide
theorem cert_e2422372927446 : check e2422372927446 [[],[]] .smaller = true := by decide
def e2422372927450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2422372927450 : Closed e2422372927450 ∧ code e2422372927450 = 11218465949658 := by decide
theorem cert_e2422372927450 : check e2422372927450 [[],[]] .smaller = true := by decide
def e2422372927466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 0)))) (.var 0)))))))
theorem wire_e2422372927466 : Closed e2422372927466 ∧ code e2422372927466 = 11218465949674 := by decide
theorem cert_e2422372927466 : check e2422372927466 [[],[]] .three = true := by decide
def e2422372927966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422372927966 : Closed e2422372927966 ∧ code e2422372927966 = 11218465950174 := by decide
theorem cert_e2422372927966 : check e2422372927966 [[],[]] .three = true := by decide
def e2422372927982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422372927982 : Closed e2422372927982 ∧ code e2422372927982 = 11218465950190 := by decide
theorem cert_e2422372927982 : check e2422372927982 [[],[]] .smaller = true := by decide
def e2422372927990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422372927990 : Closed e2422372927990 ∧ code e2422372927990 = 11218465950198 := by decide
theorem cert_e2422372927990 : check e2422372927990 [[],[]] .three = true := by decide
def e2422372928734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422372928734 : Closed e2422372928734 ∧ code e2422372928734 = 11218465950942 := by decide
theorem cert_e2422372928734 : check e2422372928734 [[],[]] .three = true := by decide
def e2422372928750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372928750 : Closed e2422372928750 ∧ code e2422372928750 = 11218465950958 := by decide
theorem cert_e2422372928750 : check e2422372928750 [[],[]] .smaller = true := by decide
def e2422372928758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372928758 : Closed e2422372928758 ∧ code e2422372928758 = 11218465950966 := by decide
theorem cert_e2422372928758 : check e2422372928758 [[],[]] .smaller = true := by decide
def e2422372928762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372928762 : Closed e2422372928762 ∧ code e2422372928762 = 11218465950970 := by decide
theorem cert_e2422372928762 : check e2422372928762 [[],[]] .three = true := by decide
def e2422372929086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.lam (.var 4))))))))
theorem wire_e2422372929086 : Closed e2422372929086 ∧ code e2422372929086 = 11218465951294 := by decide
theorem cert_e2422372929086 : check e2422372929086 [[],[]] .three = true := by decide
def e2422372929134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372929134 : Closed e2422372929134 ∧ code e2422372929134 = 11218465951342 := by decide
theorem cert_e2422372929134 : check e2422372929134 [[],[]] .smaller = true := by decide
def e2422372929146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372929146 : Closed e2422372929146 ∧ code e2422372929146 = 11218465951354 := by decide
theorem cert_e2422372929146 : check e2422372929146 [[],[]] .smaller = true := by decide
def e2422372929310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 3))))))))
theorem wire_e2422372929310 : Closed e2422372929310 ∧ code e2422372929310 = 11218465951518 := by decide
theorem cert_e2422372929310 : check e2422372929310 [[],[]] .smaller = true := by decide
def e2422372929334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372929334 : Closed e2422372929334 ∧ code e2422372929334 = 11218465951542 := by decide
theorem cert_e2422372929334 : check e2422372929334 [[],[]] .smaller = true := by decide
def e2422372929338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372929338 : Closed e2422372929338 ∧ code e2422372929338 = 11218465951546 := by decide
theorem cert_e2422372929338 : check e2422372929338 [[],[]] .smaller = true := by decide
def e2422372929422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.lam (.var 2))))))))
theorem wire_e2422372929422 : Closed e2422372929422 ∧ code e2422372929422 = 11218465951630 := by decide
theorem cert_e2422372929422 : check e2422372929422 [[],[]] .three = true := by decide
def e2422372929434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372929434 : Closed e2422372929434 ∧ code e2422372929434 = 11218465951642 := by decide
theorem cert_e2422372929434 : check e2422372929434 [[],[]] .three = true := by decide
def e2422372931246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e2422372931246 : Closed e2422372931246 ∧ code e2422372931246 = 11218465953454 := by decide
theorem cert_e2422372931246 : check e2422372931246 [[],[]] .smaller = true := by decide
def e2422372931258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e2422372931258 : Closed e2422372931258 ∧ code e2422372931258 = 11218465953466 := by decide
theorem cert_e2422372931258 : check e2422372931258 [[],[]] .smaller = true := by decide
def e2422372931306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e2422372931306 : Closed e2422372931306 ∧ code e2422372931306 = 11218465953514 := by decide
theorem cert_e2422372931306 : check e2422372931306 [[],[]] .smaller = true := by decide
def e2422372931498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422372931498 : Closed e2422372931498 ∧ code e2422372931498 = 11218465953706 := by decide
theorem cert_e2422372931498 : check e2422372931498 [[],[]] .smaller = true := by decide
def e2422372931630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422372931630 : Closed e2422372931630 ∧ code e2422372931630 = 11218465953838 := by decide
theorem cert_e2422372931630 : check e2422372931630 [[],[]] .smaller = true := by decide
def e2422372931806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422372931806 : Closed e2422372931806 ∧ code e2422372931806 = 11218465954014 := by decide
theorem cert_e2422372931806 : check e2422372931806 [[],[]] .three = true := by decide
def e2422372931822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422372931822 : Closed e2422372931822 ∧ code e2422372931822 = 11218465954030 := by decide
theorem cert_e2422372931822 : check e2422372931822 [[],[]] .smaller = true := by decide
def e2422372931830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422372931830 : Closed e2422372931830 ∧ code e2422372931830 = 11218465954038 := by decide
theorem cert_e2422372931830 : check e2422372931830 [[],[]] .smaller = true := by decide
def e2422372931834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422372931834 : Closed e2422372931834 ∧ code e2422372931834 = 11218465954042 := by decide
theorem cert_e2422372931834 : check e2422372931834 [[],[]] .three = true := by decide
def e2422372932014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422372932014 : Closed e2422372932014 ∧ code e2422372932014 = 11218465954222 := by decide
theorem cert_e2422372932014 : check e2422372932014 [[],[]] .smaller = true := by decide
def e2422372932026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422372932026 : Closed e2422372932026 ∧ code e2422372932026 = 11218465954234 := by decide
theorem cert_e2422372932026 : check e2422372932026 [[],[]] .smaller = true := by decide
def e2422372932074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422372932074 : Closed e2422372932074 ∧ code e2422372932074 = 11218465954282 := by decide
theorem cert_e2422372932074 : check e2422372932074 [[],[]] .smaller = true := by decide
def e2422372932158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422372932158 : Closed e2422372932158 ∧ code e2422372932158 = 11218465954366 := by decide
theorem cert_e2422372932158 : check e2422372932158 [[],[]] .three = true := by decide
end Blc.Floor43
