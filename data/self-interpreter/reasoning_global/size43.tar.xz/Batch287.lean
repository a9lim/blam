import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2409080315446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2409080315446 : Closed e2409080315446 ∧ code e2409080315446 = 11205173337654 := by decide
theorem cert_e2409080315446 : check e2409080315446 [[],[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2409080315450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2409080315450 : Closed e2409080315450 ∧ code e2409080315450 = 11205173337658 := by decide
theorem cert_e2409080315450 : check e2409080315450 [[],[],[],[],[],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e2409080315534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2409080315534 : Closed e2409080315534 ∧ code e2409080315534 = 11205173337742 := by decide
theorem cert_e2409080315534 : check e2409080315534 [[],[],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2409080315590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2409080315590 : Closed e2409080315590 ∧ code e2409080315590 = 11205173337798 := by decide
private def t_e2409080315590 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e2409080315590 : ¬ IsSelfInterpreter e2409080315590 :=
  wSource (t := t_e2409080315590) (replay_sound (ps := []) (t := e2409080315590) (by decide)) (by decide)
def e2409080317726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2409080317726 : Closed e2409080317726 ∧ code e2409080317726 = 11205173339934 := by decide
theorem cert_e2409080317726 : check e2409080317726 [[],[],[],[],[]] .sourceHead = true := by decide
def e2409080317838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2409080317838 : Closed e2409080317838 ∧ code e2409080317838 = 11205173340046 := by decide
theorem cert_e2409080317838 : check e2409080317838 [[],[],[],[],[]] .sourceHead = true := by decide
def e2409080320798 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2409080320798 : Closed e2409080320798 ∧ code e2409080320798 = 11205173343006 := by decide
theorem cert_e2409080320798 : checkPay e2409080320798 [[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under,.under]] = true := by decide
def e2409080320966 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2409080320966 : Closed e2409080320966 ∧ code e2409080320966 = 11205173343174 := by decide
theorem cert_e2409080320966 : check e2409080320966 [[],[],[],[],[],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2409080322446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2409080322446 : Closed e2409080322446 ∧ code e2409080322446 = 11205173344654 := by decide
theorem cert_e2409080322446 : check e2409080322446 [[],[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e2409080322502 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2409080322502 : Closed e2409080322502 ∧ code e2409080322502 = 11205173344710 := by decide
theorem cert_e2409080322502 : check e2409080322502 [[],[],[],[],[],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2409141153134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2409141153134 : Closed e2409141153134 ∧ code e2409141153134 = 11205234175342 := by decide
theorem cert_e2409141153134 : check e2409141153134 [[],[]] .smaller = true := by decide
def e2409141153142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2409141153142 : Closed e2409141153142 ∧ code e2409141153142 = 11205234175350 := by decide
theorem cert_e2409141153142 : check e2409141153142 [[],[]] .smaller = true := by decide
def e2409141153198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2409141153198 : Closed e2409141153198 ∧ code e2409141153198 = 11205234175406 := by decide
theorem cert_e2409141153198 : check e2409141153198 [[],[]] .smaller = true := by decide
def e2409141153210 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2409141153210 : Closed e2409141153210 ∧ code e2409141153210 = 11205234175418 := by decide
theorem cert_e2409141153210 : check e2409141153210 [[],[]] .smaller = true := by decide
def e2409141153238 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2409141153238 : Closed e2409141153238 ∧ code e2409141153238 = 11205234175446 := by decide
theorem cert_e2409141153238 : check e2409141153238 [[],[]] .smaller = true := by decide
def e2409141153242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2409141153242 : Closed e2409141153242 ∧ code e2409141153242 = 11205234175450 := by decide
theorem cert_e2409141153242 : check e2409141153242 [[],[]] .smaller = true := by decide
def e2409141153454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2409141153454 : Closed e2409141153454 ∧ code e2409141153454 = 11205234175662 := by decide
theorem cert_e2409141153454 : check e2409141153454 [[],[]] .smaller = true := by decide
def e2409141153466 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2409141153466 : Closed e2409141153466 ∧ code e2409141153466 = 11205234175674 := by decide
theorem cert_e2409141153466 : check e2409141153466 [[],[]] .smaller = true := by decide
def e2409141153514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2409141153514 : Closed e2409141153514 ∧ code e2409141153514 = 11205234175722 := by decide
theorem cert_e2409141153514 : check e2409141153514 [[],[]] .smaller = true := by decide
def e2409141153622 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2409141153622 : Closed e2409141153622 ∧ code e2409141153622 = 11205234175830 := by decide
theorem cert_e2409141153622 : check e2409141153622 [[],[]] .smaller = true := by decide
def e2409141153626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2409141153626 : Closed e2409141153626 ∧ code e2409141153626 = 11205234175834 := by decide
theorem cert_e2409141153626 : check e2409141153626 [[],[]] .smaller = true := by decide
def e2409141153642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2409141153642 : Closed e2409141153642 ∧ code e2409141153642 = 11205234175850 := by decide
theorem cert_e2409141153642 : check e2409141153642 [[],[]] .smaller = true := by decide
def e2409141154670 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2409141154670 : Closed e2409141154670 ∧ code e2409141154670 = 11205234176878 := by decide
theorem cert_e2409141154670 : check e2409141154670 [[],[]] .smaller = true := by decide
def e2409141154678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2409141154678 : Closed e2409141154678 ∧ code e2409141154678 = 11205234176886 := by decide
theorem cert_e2409141154678 : check e2409141154678 [[],[]] .smaller = true := by decide
def e2409141154734 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2409141154734 : Closed e2409141154734 ∧ code e2409141154734 = 11205234176942 := by decide
theorem cert_e2409141154734 : check e2409141154734 [[],[]] .smaller = true := by decide
def e2409141154746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2409141154746 : Closed e2409141154746 ∧ code e2409141154746 = 11205234176954 := by decide
theorem cert_e2409141154746 : check e2409141154746 [[],[]] .smaller = true := by decide
def e2409141154774 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2409141154774 : Closed e2409141154774 ∧ code e2409141154774 = 11205234176982 := by decide
theorem cert_e2409141154774 : check e2409141154774 [[],[]] .smaller = true := by decide
def e2409141154778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2409141154778 : Closed e2409141154778 ∧ code e2409141154778 = 11205234176986 := by decide
theorem cert_e2409141154778 : check e2409141154778 [[],[]] .smaller = true := by decide
def e2409141155054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2409141155054 : Closed e2409141155054 ∧ code e2409141155054 = 11205234177262 := by decide
theorem cert_e2409141155054 : check e2409141155054 [[],[]] .smaller = true := by decide
def e2409141155062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2409141155062 : Closed e2409141155062 ∧ code e2409141155062 = 11205234177270 := by decide
theorem cert_e2409141155062 : check e2409141155062 [[],[]] .smaller = true := by decide
def e2409141155438 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2409141155438 : Closed e2409141155438 ∧ code e2409141155438 = 11205234177646 := by decide
theorem cert_e2409141155438 : check e2409141155438 [[],[]] .smaller = true := by decide
def e2409141155450 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2409141155450 : Closed e2409141155450 ∧ code e2409141155450 = 11205234177658 := by decide
theorem cert_e2409141155450 : check e2409141155450 [[],[]] .smaller = true := by decide
def e2409141155638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2409141155638 : Closed e2409141155638 ∧ code e2409141155638 = 11205234177846 := by decide
theorem cert_e2409141155638 : check e2409141155638 [[],[]] .smaller = true := by decide
def e2409141155642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2409141155642 : Closed e2409141155642 ∧ code e2409141155642 = 11205234177850 := by decide
theorem cert_e2409141155642 : check e2409141155642 [[],[]] .smaller = true := by decide
def e2409141156270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2409141156270 : Closed e2409141156270 ∧ code e2409141156270 = 11205234178478 := by decide
theorem cert_e2409141156270 : check e2409141156270 [[],[]] .smaller = true := by decide
def e2409141156282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2409141156282 : Closed e2409141156282 ∧ code e2409141156282 = 11205234178490 := by decide
theorem cert_e2409141156282 : check e2409141156282 [[],[]] .smaller = true := by decide
def e2409141156330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2409141156330 : Closed e2409141156330 ∧ code e2409141156330 = 11205234178538 := by decide
theorem cert_e2409141156330 : check e2409141156330 [[],[]] .smaller = true := by decide
def e2409141156462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2409141156462 : Closed e2409141156462 ∧ code e2409141156462 = 11205234178670 := by decide
theorem cert_e2409141156462 : check e2409141156462 [[],[]] .smaller = true := by decide
def e2409141156474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2409141156474 : Closed e2409141156474 ∧ code e2409141156474 = 11205234178682 := by decide
theorem cert_e2409141156474 : check e2409141156474 [[],[]] .smaller = true := by decide
def e2409141156762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2409141156762 : Closed e2409141156762 ∧ code e2409141156762 = 11205234178970 := by decide
theorem cert_e2409141156762 : check e2409141156762 [[],[]] .smaller = true := by decide
def e2409141157078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2409141157078 : Closed e2409141157078 ∧ code e2409141157078 = 11205234179286 := by decide
theorem cert_e2409141157078 : check e2409141157078 [[],[]] .smaller = true := by decide
def e2409141157082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2409141157082 : Closed e2409141157082 ∧ code e2409141157082 = 11205234179290 := by decide
theorem cert_e2409141157082 : check e2409141157082 [[],[]] .smaller = true := by decide
def e2409141157098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2409141157098 : Closed e2409141157098 ∧ code e2409141157098 = 11205234179306 := by decide
theorem cert_e2409141157098 : check e2409141157098 [[],[]] .smaller = true := by decide
def e2409141157174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2409141157174 : Closed e2409141157174 ∧ code e2409141157174 = 11205234179382 := by decide
theorem cert_e2409141157174 : check e2409141157174 [[],[]] .smaller = true := by decide
def e2409141157178 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2409141157178 : Closed e2409141157178 ∧ code e2409141157178 = 11205234179386 := by decide
theorem cert_e2409141157178 : check e2409141157178 [[],[]] .smaller = true := by decide
def e2409141157274 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2409141157274 : Closed e2409141157274 ∧ code e2409141157274 = 11205234179482 := by decide
theorem cert_e2409141157274 : check e2409141157274 [[],[]] .smaller = true := by decide
def e2409141160814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2409141160814 : Closed e2409141160814 ∧ code e2409141160814 = 11205234183022 := by decide
theorem cert_e2409141160814 : check e2409141160814 [[],[]] .smaller = true := by decide
def e2409141160822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2409141160822 : Closed e2409141160822 ∧ code e2409141160822 = 11205234183030 := by decide
theorem cert_e2409141160822 : check e2409141160822 [[],[]] .smaller = true := by decide
def e2409141160878 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2409141160878 : Closed e2409141160878 ∧ code e2409141160878 = 11205234183086 := by decide
theorem cert_e2409141160878 : check e2409141160878 [[],[]] .smaller = true := by decide
def e2409141160890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2409141160890 : Closed e2409141160890 ∧ code e2409141160890 = 11205234183098 := by decide
theorem cert_e2409141160890 : check e2409141160890 [[],[]] .smaller = true := by decide
def e2409141160918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2409141160918 : Closed e2409141160918 ∧ code e2409141160918 = 11205234183126 := by decide
theorem cert_e2409141160918 : check e2409141160918 [[],[]] .smaller = true := by decide
def e2409141160922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2409141160922 : Closed e2409141160922 ∧ code e2409141160922 = 11205234183130 := by decide
theorem cert_e2409141160922 : check e2409141160922 [[],[]] .smaller = true := by decide
def e2409141161198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2409141161198 : Closed e2409141161198 ∧ code e2409141161198 = 11205234183406 := by decide
theorem cert_e2409141161198 : check e2409141161198 [[],[]] .smaller = true := by decide
def e2409141161206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2409141161206 : Closed e2409141161206 ∧ code e2409141161206 = 11205234183414 := by decide
theorem cert_e2409141161206 : check e2409141161206 [[],[]] .smaller = true := by decide
def e2409141161582 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2409141161582 : Closed e2409141161582 ∧ code e2409141161582 = 11205234183790 := by decide
theorem cert_e2409141161582 : check e2409141161582 [[],[]] .smaller = true := by decide
def e2409141161594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2409141161594 : Closed e2409141161594 ∧ code e2409141161594 = 11205234183802 := by decide
theorem cert_e2409141161594 : check e2409141161594 [[],[]] .smaller = true := by decide
def e2409141161782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409141161782 : Closed e2409141161782 ∧ code e2409141161782 = 11205234183990 := by decide
theorem cert_e2409141161782 : check e2409141161782 [[],[]] .smaller = true := by decide
def e2409141161786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409141161786 : Closed e2409141161786 ∧ code e2409141161786 = 11205234183994 := by decide
theorem cert_e2409141161786 : check e2409141161786 [[],[]] .smaller = true := by decide
def e2409141167534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2409141167534 : Closed e2409141167534 ∧ code e2409141167534 = 11205234189742 := by decide
theorem cert_e2409141167534 : check e2409141167534 [[],[]] .smaller = true := by decide
def e2409141167546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2409141167546 : Closed e2409141167546 ∧ code e2409141167546 = 11205234189754 := by decide
theorem cert_e2409141167546 : check e2409141167546 [[],[]] .smaller = true := by decide
def e2409141167594 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2409141167594 : Closed e2409141167594 ∧ code e2409141167594 = 11205234189802 := by decide
theorem cert_e2409141167594 : check e2409141167594 [[],[]] .smaller = true := by decide
def e2409141167726 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2409141167726 : Closed e2409141167726 ∧ code e2409141167726 = 11205234189934 := by decide
theorem cert_e2409141167726 : check e2409141167726 [[],[]] .smaller = true := by decide
def e2409141167738 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2409141167738 : Closed e2409141167738 ∧ code e2409141167738 = 11205234189946 := by decide
theorem cert_e2409141167738 : check e2409141167738 [[],[]] .smaller = true := by decide
def e2409141168026 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2409141168026 : Closed e2409141168026 ∧ code e2409141168026 = 11205234190234 := by decide
theorem cert_e2409141168026 : check e2409141168026 [[],[]] .smaller = true := by decide
def e2409141170902 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2409141170902 : Closed e2409141170902 ∧ code e2409141170902 = 11205234193110 := by decide
theorem cert_e2409141170902 : check e2409141170902 [[],[]] .smaller = true := by decide
def e2409141170906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2409141170906 : Closed e2409141170906 ∧ code e2409141170906 = 11205234193114 := by decide
theorem cert_e2409141170906 : check e2409141170906 [[],[]] .smaller = true := by decide
def e2409141170922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2409141170922 : Closed e2409141170922 ∧ code e2409141170922 = 11205234193130 := by decide
theorem cert_e2409141170922 : check e2409141170922 [[],[]] .smaller = true := by decide
def e2409141170998 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409141170998 : Closed e2409141170998 ∧ code e2409141170998 = 11205234193206 := by decide
theorem cert_e2409141170998 : check e2409141170998 [[],[]] .smaller = true := by decide
def e2409141171002 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409141171002 : Closed e2409141171002 ∧ code e2409141171002 = 11205234193210 := by decide
theorem cert_e2409141171002 : check e2409141171002 [[],[]] .smaller = true := by decide
def e2409141171098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2409141171098 : Closed e2409141171098 ∧ code e2409141171098 = 11205234193306 := by decide
theorem cert_e2409141171098 : check e2409141171098 [[],[]] .smaller = true := by decide
def e2409141286638 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2409141286638 : Closed e2409141286638 ∧ code e2409141286638 = 11205234308846 := by decide
theorem cert_e2409141286638 : check e2409141286638 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2409141286766 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2409141286766 : Closed e2409141286766 ∧ code e2409141286766 = 11205234308974 := by decide
theorem cert_e2409141286766 : check e2409141286766 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2409141286774 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2409141286774 : Closed e2409141286774 ∧ code e2409141286774 = 11205234308982 := by decide
theorem cert_e2409141286774 : check e2409141286774 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2409141287662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2409141287662 : Closed e2409141287662 ∧ code e2409141287662 = 11205234309870 := by decide
theorem cert_e2409141287662 : check e2409141287662 [[],[]] .sourceHead = true := by decide
def e2409141287854 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2409141287854 : Closed e2409141287854 ∧ code e2409141287854 = 11205234310062 := by decide
theorem cert_e2409141287854 : check e2409141287854 [[],[]] .sourceHead = true := by decide
def e2409141287866 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2409141287866 : Closed e2409141287866 ∧ code e2409141287866 = 11205234310074 := by decide
theorem cert_e2409141287866 : check e2409141287866 [[],[]] .sourceHead = true := by decide
def e2409141288302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2409141288302 : Closed e2409141288302 ∧ code e2409141288302 = 11205234310510 := by decide
def e2409141288310 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2409141288310 : Closed e2409141288310 ∧ code e2409141288310 = 11205234310518 := by decide
theorem cert_e2409141288310 : check e2409141288310 [[],[],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2409141288366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2409141288366 : Closed e2409141288366 ∧ code e2409141288366 = 11205234310574 := by decide
theorem cert_e2409141288366 : check e2409141288366 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2409141288378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2409141288378 : Closed e2409141288378 ∧ code e2409141288378 = 11205234310586 := by decide
def e2409141288406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2409141288406 : Closed e2409141288406 ∧ code e2409141288406 = 11205234310614 := by decide
private def t_e2409141288406 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2409141288406 : ¬ IsSelfInterpreter e2409141288406 :=
  wSource (t := t_e2409141288406) (replay_sound (ps := []) (t := e2409141288406) (by decide)) (by decide)
def e2409141288410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2409141288410 : Closed e2409141288410 ∧ code e2409141288410 = 11205234310618 := by decide
private def t_e2409141288410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2409141288410 : ¬ IsSelfInterpreter e2409141288410 :=
  wSource (t := t_e2409141288410) (replay_sound (ps := []) (t := e2409141288410) (by decide)) (by decide)
def e2409141292782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2409141292782 : Closed e2409141292782 ∧ code e2409141292782 = 11205234314990 := by decide
theorem cert_e2409141292782 : check e2409141292782 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2409141292910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2409141292910 : Closed e2409141292910 ∧ code e2409141292910 = 11205234315118 := by decide
theorem cert_e2409141292910 : check e2409141292910 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left],[]] .identityHead = true := by decide
def e2409141292918 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2409141292918 : Closed e2409141292918 ∧ code e2409141292918 = 11205234315126 := by decide
theorem cert_e2409141292918 : check e2409141292918 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2409141295598 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2409141295598 : Closed e2409141295598 ∧ code e2409141295598 = 11205234317806 := by decide
theorem cert_e2409141295598 : check e2409141295598 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2409141296366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2409141296366 : Closed e2409141296366 ∧ code e2409141296366 = 11205234318574 := by decide
theorem cert_e2409141296366 : check e2409141296366 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2409141296374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2409141296374 : Closed e2409141296374 ∧ code e2409141296374 = 11205234318582 := by decide
theorem cert_e2409141296374 : check e2409141296374 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2409141298926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2409141298926 : Closed e2409141298926 ∧ code e2409141298926 = 11205234321134 := by decide
theorem cert_e2409141298926 : checkPay e2409141298926 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left],[],[.under,.left]] = true := by decide
def e2409141299118 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2409141299118 : Closed e2409141299118 ∧ code e2409141299118 = 11205234321326 := by decide
theorem cert_e2409141299118 : checkPay e2409141299118 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[],[.under,.under,.left,.right]] = true := by decide
def e2409141299130 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2409141299130 : Closed e2409141299130 ∧ code e2409141299130 = 11205234321338 := by decide
theorem cert_e2409141299130 : checkPay e2409141299130 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2409141299694 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2409141299694 : Closed e2409141299694 ∧ code e2409141299694 = 11205234321902 := by decide
theorem cert_e2409141299694 : checkPay e2409141299694 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2409141300846 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2409141300846 : Closed e2409141300846 ∧ code e2409141300846 = 11205234323054 := by decide
theorem cert_e2409141300846 : checkPay e2409141300846 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under]] = true := by decide
def e2409141300858 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2409141300858 : Closed e2409141300858 ∧ code e2409141300858 = 11205234323066 := by decide
theorem cert_e2409141300858 : checkPay e2409141300858 [[.left,.left],[.left,.left],[.left],[]] 0 [[.under],[.under,.under,.under,.right]] = true := by decide
def e2409141302126 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2409141302126 : Closed e2409141302126 ∧ code e2409141302126 = 11205234324334 := by decide
theorem cert_e2409141302126 : check e2409141302126 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302134 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2409141302134 : Closed e2409141302134 ∧ code e2409141302134 = 11205234324342 := by decide
theorem cert_e2409141302134 : check e2409141302134 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2409141302190 : Closed e2409141302190 ∧ code e2409141302190 = 11205234324398 := by decide
theorem cert_e2409141302190 : check e2409141302190 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2409141302202 : Closed e2409141302202 ∧ code e2409141302202 = 11205234324410 := by decide
theorem cert_e2409141302202 : check e2409141302202 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302230 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2409141302230 : Closed e2409141302230 ∧ code e2409141302230 = 11205234324438 := by decide
theorem cert_e2409141302230 : check e2409141302230 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2409141302234 : Closed e2409141302234 ∧ code e2409141302234 = 11205234324442 := by decide
theorem cert_e2409141302234 : check e2409141302234 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302510 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2409141302510 : Closed e2409141302510 ∧ code e2409141302510 = 11205234324718 := by decide
theorem cert_e2409141302510 : check e2409141302510 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302518 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2409141302518 : Closed e2409141302518 ∧ code e2409141302518 = 11205234324726 := by decide
theorem cert_e2409141302518 : check e2409141302518 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2409141302894 : Closed e2409141302894 ∧ code e2409141302894 = 11205234325102 := by decide
theorem cert_e2409141302894 : check e2409141302894 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141302906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2409141302906 : Closed e2409141302906 ∧ code e2409141302906 = 11205234325114 := by decide
theorem cert_e2409141302906 : check e2409141302906 [[],[],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2409141303094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2409141303094 : Closed e2409141303094 ∧ code e2409141303094 = 11205234325302 := by decide
private def t_e2409141303094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2409141303094 : ¬ IsSelfInterpreter e2409141303094 :=
  wSource (t := t_e2409141303094) (replay_sound (ps := []) (t := e2409141303094) (by decide)) (by decide)
def e2409141303098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2409141303098 : Closed e2409141303098 ∧ code e2409141303098 = 11205234325306 := by decide
private def t_e2409141303098 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2409141303098 : ¬ IsSelfInterpreter e2409141303098 :=
  wSource (t := t_e2409141303098) (replay_sound (ps := []) (t := e2409141303098) (by decide)) (by decide)
def e2409141308270 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2409141308270 : Closed e2409141308270 ∧ code e2409141308270 = 11205234330478 := by decide
theorem cert_e2409141308270 : check e2409141308270 [[],[]] .smaller = true := by decide
def e2409141308278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2409141308278 : Closed e2409141308278 ∧ code e2409141308278 = 11205234330486 := by decide
theorem cert_e2409141308278 : check e2409141308278 [[],[]] .smaller = true := by decide
def e2409141308334 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2409141308334 : Closed e2409141308334 ∧ code e2409141308334 = 11205234330542 := by decide
theorem cert_e2409141308334 : check e2409141308334 [[],[]] .smaller = true := by decide
def e2409141308346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2409141308346 : Closed e2409141308346 ∧ code e2409141308346 = 11205234330554 := by decide
theorem cert_e2409141308346 : check e2409141308346 [[],[]] .smaller = true := by decide
def e2409141308374 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2409141308374 : Closed e2409141308374 ∧ code e2409141308374 = 11205234330582 := by decide
theorem cert_e2409141308374 : check e2409141308374 [[],[]] .smaller = true := by decide
def e2409141308378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2409141308378 : Closed e2409141308378 ∧ code e2409141308378 = 11205234330586 := by decide
theorem cert_e2409141308378 : check e2409141308378 [[],[]] .smaller = true := by decide
def e2409141308654 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2409141308654 : Closed e2409141308654 ∧ code e2409141308654 = 11205234330862 := by decide
theorem cert_e2409141308654 : check e2409141308654 [[],[]] .smaller = true := by decide
def e2409141308662 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2409141308662 : Closed e2409141308662 ∧ code e2409141308662 = 11205234330870 := by decide
theorem cert_e2409141308662 : check e2409141308662 [[],[]] .smaller = true := by decide
def e2409141309038 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2409141309038 : Closed e2409141309038 ∧ code e2409141309038 = 11205234331246 := by decide
theorem cert_e2409141309038 : check e2409141309038 [[],[]] .smaller = true := by decide
def e2409141309050 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2409141309050 : Closed e2409141309050 ∧ code e2409141309050 = 11205234331258 := by decide
theorem cert_e2409141309050 : check e2409141309050 [[],[]] .smaller = true := by decide
def e2409141309238 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409141309238 : Closed e2409141309238 ∧ code e2409141309238 = 11205234331446 := by decide
theorem cert_e2409141309238 : check e2409141309238 [[],[]] .smaller = true := by decide
def e2409141309242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409141309242 : Closed e2409141309242 ∧ code e2409141309242 = 11205234331450 := by decide
theorem cert_e2409141309242 : check e2409141309242 [[],[]] .smaller = true := by decide
def e2409141317358 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2409141317358 : Closed e2409141317358 ∧ code e2409141317358 = 11205234339566 := by decide
theorem cert_e2409141317358 : check e2409141317358 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2409141317486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2409141317486 : Closed e2409141317486 ∧ code e2409141317486 = 11205234339694 := by decide
theorem cert_e2409141317486 : check e2409141317486 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2409141317494 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2409141317494 : Closed e2409141317494 ∧ code e2409141317494 = 11205234339702 := by decide
theorem cert_e2409141317494 : check e2409141317494 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2409141320174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2409141320174 : Closed e2409141320174 ∧ code e2409141320174 = 11205234342382 := by decide
theorem cert_e2409141320174 : check e2409141320174 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2409141320942 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2409141320942 : Closed e2409141320942 ∧ code e2409141320942 = 11205234343150 := by decide
theorem cert_e2409141320942 : check e2409141320942 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2409141320950 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2409141320950 : Closed e2409141320950 ∧ code e2409141320950 = 11205234343158 := by decide
theorem cert_e2409141320950 : check e2409141320950 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2409141343982 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2409141343982 : Closed e2409141343982 ∧ code e2409141343982 = 11205234366190 := by decide
theorem cert_e2409141343982 : check e2409141343982 [[],[]] .sourceHead = true := by decide
def e2409141344174 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2409141344174 : Closed e2409141344174 ∧ code e2409141344174 = 11205234366382 := by decide
theorem cert_e2409141344174 : check e2409141344174 [[],[]] .sourceHead = true := by decide
def e2409141344186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2409141344186 : Closed e2409141344186 ∧ code e2409141344186 = 11205234366394 := by decide
theorem cert_e2409141344186 : check e2409141344186 [[],[]] .sourceHead = true := by decide
def e2409141344750 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2409141344750 : Closed e2409141344750 ∧ code e2409141344750 = 11205234366958 := by decide
theorem cert_e2409141344750 : check e2409141344750 [[],[]] .sourceHead = true := by decide
def e2409141345902 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2409141345902 : Closed e2409141345902 ∧ code e2409141345902 = 11205234368110 := by decide
theorem cert_e2409141345902 : check e2409141345902 [[],[]] .sourceHead = true := by decide
def e2409141345914 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2409141345914 : Closed e2409141345914 ∧ code e2409141345914 = 11205234368122 := by decide
theorem cert_e2409141345914 : check e2409141345914 [[],[]] .sourceHead = true := by decide
def e2409141357422 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2409141357422 : Closed e2409141357422 ∧ code e2409141357422 = 11205234379630 := by decide
theorem cert_e2409141357422 : check e2409141357422 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141357430 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2409141357430 : Closed e2409141357430 ∧ code e2409141357430 = 11205234379638 := by decide
theorem cert_e2409141357430 : check e2409141357430 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141357486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2409141357486 : Closed e2409141357486 ∧ code e2409141357486 = 11205234379694 := by decide
theorem cert_e2409141357486 : check e2409141357486 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141357498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2409141357498 : Closed e2409141357498 ∧ code e2409141357498 = 11205234379706 := by decide
theorem cert_e2409141357498 : check e2409141357498 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141357526 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2409141357526 : Closed e2409141357526 ∧ code e2409141357526 = 11205234379734 := by decide
theorem cert_e2409141357526 : check e2409141357526 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141357530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2409141357530 : Closed e2409141357530 ∧ code e2409141357530 = 11205234379738 := by decide
theorem cert_e2409141357530 : check e2409141357530 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141357806 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2409141357806 : Closed e2409141357806 ∧ code e2409141357806 = 11205234380014 := by decide
theorem cert_e2409141357806 : check e2409141357806 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141357814 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2409141357814 : Closed e2409141357814 ∧ code e2409141357814 = 11205234380022 := by decide
theorem cert_e2409141357814 : check e2409141357814 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141358190 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2409141358190 : Closed e2409141358190 ∧ code e2409141358190 = 11205234380398 := by decide
theorem cert_e2409141358190 : check e2409141358190 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141358202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2409141358202 : Closed e2409141358202 ∧ code e2409141358202 = 11205234380410 := by decide
theorem cert_e2409141358202 : check e2409141358202 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141358390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2409141358390 : Closed e2409141358390 ∧ code e2409141358390 = 11205234380598 := by decide
theorem cert_e2409141358390 : check e2409141358390 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141358394 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2409141358394 : Closed e2409141358394 ∧ code e2409141358394 = 11205234380602 := by decide
theorem cert_e2409141358394 : check e2409141358394 [[],[],[.under,.under],[.under,.under]] .three = true := by decide
def e2409141898094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2409141898094 : Closed e2409141898094 ∧ code e2409141898094 = 11205234920302 := by decide
theorem cert_e2409141898094 : check e2409141898094 [[],[]] .smaller = true := by decide
def e2409141898102 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2409141898102 : Closed e2409141898102 ∧ code e2409141898102 = 11205234920310 := by decide
theorem cert_e2409141898102 : check e2409141898102 [[],[]] .smaller = true := by decide
def e2409141898158 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2409141898158 : Closed e2409141898158 ∧ code e2409141898158 = 11205234920366 := by decide
theorem cert_e2409141898158 : check e2409141898158 [[],[]] .smaller = true := by decide
def e2409141898170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2409141898170 : Closed e2409141898170 ∧ code e2409141898170 = 11205234920378 := by decide
theorem cert_e2409141898170 : check e2409141898170 [[],[]] .smaller = true := by decide
def e2409141898198 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2409141898198 : Closed e2409141898198 ∧ code e2409141898198 = 11205234920406 := by decide
theorem cert_e2409141898198 : check e2409141898198 [[],[]] .smaller = true := by decide
def e2409141898202 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2409141898202 : Closed e2409141898202 ∧ code e2409141898202 = 11205234920410 := by decide
theorem cert_e2409141898202 : check e2409141898202 [[],[]] .smaller = true := by decide
def e2409141898478 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2409141898478 : Closed e2409141898478 ∧ code e2409141898478 = 11205234920686 := by decide
theorem cert_e2409141898478 : check e2409141898478 [[],[]] .smaller = true := by decide
def e2409141898486 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2409141898486 : Closed e2409141898486 ∧ code e2409141898486 = 11205234920694 := by decide
theorem cert_e2409141898486 : check e2409141898486 [[],[]] .smaller = true := by decide
def e2409141898862 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2409141898862 : Closed e2409141898862 ∧ code e2409141898862 = 11205234921070 := by decide
theorem cert_e2409141898862 : check e2409141898862 [[],[]] .smaller = true := by decide
def e2409141898874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2409141898874 : Closed e2409141898874 ∧ code e2409141898874 = 11205234921082 := by decide
theorem cert_e2409141898874 : check e2409141898874 [[],[]] .smaller = true := by decide
def e2409141899062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2409141899062 : Closed e2409141899062 ∧ code e2409141899062 = 11205234921270 := by decide
theorem cert_e2409141899062 : check e2409141899062 [[],[]] .smaller = true := by decide
def e2409141899066 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2409141899066 : Closed e2409141899066 ∧ code e2409141899066 = 11205234921274 := by decide
theorem cert_e2409141899066 : check e2409141899066 [[],[]] .smaller = true := by decide
def e2411624225502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e2411624225502 : Closed e2411624225502 ∧ code e2411624225502 = 11207717247710 := by decide
theorem cert_e2411624225502 : check e2411624225502 [[],[]] .smaller = true := by decide
def e2411624225526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e2411624225526 : Closed e2411624225526 ∧ code e2411624225526 = 11207717247734 := by decide
theorem cert_e2411624225526 : check e2411624225526 [[],[]] .smaller = true := by decide
def e2411624225630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e2411624225630 : Closed e2411624225630 ∧ code e2411624225630 = 11207717247838 := by decide
theorem cert_e2411624225630 : check e2411624225630 [[],[]] .smaller = true := by decide
def e2411624225646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e2411624225646 : Closed e2411624225646 ∧ code e2411624225646 = 11207717247854 := by decide
theorem cert_e2411624225646 : check e2411624225646 [[],[]] .smaller = true := by decide
def e2411624225654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e2411624225654 : Closed e2411624225654 ∧ code e2411624225654 = 11207717247862 := by decide
theorem cert_e2411624225654 : check e2411624225654 [[],[]] .smaller = true := by decide
def e2411624225658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e2411624225658 : Closed e2411624225658 ∧ code e2411624225658 = 11207717247866 := by decide
theorem cert_e2411624225658 : check e2411624225658 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2409080315590
#print axioms Blc.Floor43.cert_e2409141288406
#print axioms Blc.Floor43.cert_e2409141288410
#print axioms Blc.Floor43.cert_e2409141303094
#print axioms Blc.Floor43.cert_e2409141303098
