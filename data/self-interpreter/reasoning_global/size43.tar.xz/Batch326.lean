import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418081718298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418081718298 : Closed e2418081718298 ∧ code e2418081718298 = 11214174740506 := by decide
theorem cert_e2418081718298 : check e2418081718298 [[],[]] .smaller = true := by decide
def e2418081718390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418081718390 : Closed e2418081718390 ∧ code e2418081718390 = 11214174740598 := by decide
theorem cert_e2418081718390 : check e2418081718390 [[],[],[.under,.left]] .chain = true := by decide
def e2418081718634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418081718634 : Closed e2418081718634 ∧ code e2418081718634 = 11214174740842 := by decide
theorem cert_e2418081718634 : check e2418081718634 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2418081718682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418081718682 : Closed e2418081718682 ∧ code e2418081718682 = 11214174740890 := by decide
theorem cert_e2418081718682 : check e2418081718682 [[],[],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418081722566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418081722566 : Closed e2418081722566 ∧ code e2418081722566 = 11214174744774 := by decide
theorem cert_e2418081722566 : check e2418081722566 [[]] .width = true := by decide
def e2418081765914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081765914 : Closed e2418081765914 ∧ code e2418081765914 = 11214174788122 := by decide
theorem cert_e2418081765914 : check e2418081765914 [[],[],[.left],[.left],[],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418081767450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418081767450 : Closed e2418081767450 ∧ code e2418081767450 = 11214174789658 := by decide
theorem cert_e2418081767450 : check e2418081767450 [[],[]] .smaller = true := by decide
def e2418081767542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418081767542 : Closed e2418081767542 ∧ code e2418081767542 = 11214174789750 := by decide
theorem cert_e2418081767542 : check e2418081767542 [[],[],[.under,.left]] .chain = true := by decide
def e2418081767786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418081767786 : Closed e2418081767786 ∧ code e2418081767786 = 11214174789994 := by decide
theorem cert_e2418081767786 : check e2418081767786 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2418081767834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418081767834 : Closed e2418081767834 ∧ code e2418081767834 = 11214174790042 := by decide
theorem cert_e2418081767834 : check e2418081767834 [[],[],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418081777178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418081777178 : Closed e2418081777178 ∧ code e2418081777178 = 11214174799386 := by decide
theorem cert_e2418081777178 : check e2418081777178 [[]] .width = true := by decide
def e2418081779910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418081779910 : Closed e2418081779910 ∧ code e2418081779910 = 11214174802118 := by decide
theorem cert_e2418081779910 : check e2418081779910 [[]] .width = true := by decide
def e2418082377242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082377242 : Closed e2418082377242 ∧ code e2418082377242 = 11214175399450 := by decide
theorem cert_e2418082377242 : check e2418082377242 [[],[],[.left]] .chain = true := by decide
def e2418082379290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082379290 : Closed e2418082379290 ∧ code e2418082379290 = 11214175401498 := by decide
theorem cert_e2418082379290 : check e2418082379290 [[],[],[.left]] .chain = true := by decide
def e2418082502170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082502170 : Closed e2418082502170 ∧ code e2418082502170 = 11214175524378 := by decide
theorem cert_e2418082502170 : check e2418082502170 [[],[],[.left],[.left],[],[.under]] .three = true := by decide
def e2418082503194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082503194 : Closed e2418082503194 ∧ code e2418082503194 = 11214175525402 := by decide
theorem cert_e2418082503194 : check e2418082503194 [[],[],[.left],[.left],[],[.under]] .three = true := by decide
def e2418082507290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082507290 : Closed e2418082507290 ∧ code e2418082507290 = 11214175529498 := by decide
theorem cert_e2418082507290 : check e2418082507290 [[],[],[.left],[.left],[],[.under]] .three = true := by decide
def e2418082526746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082526746 : Closed e2418082526746 ∧ code e2418082526746 = 11214175548954 := by decide
theorem cert_e2418082526746 : check e2418082526746 [[],[],[.left],[.left],[],[.under]] .three = true := by decide
def e2418082527770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082527770 : Closed e2418082527770 ∧ code e2418082527770 = 11214175549978 := by decide
theorem cert_e2418082527770 : check e2418082527770 [[],[],[.left],[.left],[],[.under]] .three = true := by decide
def e2418082537498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418082537498 : Closed e2418082537498 ∧ code e2418082537498 = 11214175559706 := by decide
theorem cert_e2418082537498 : check e2418082537498 [[],[]] .smaller = true := by decide
def e2418082537590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418082537590 : Closed e2418082537590 ∧ code e2418082537590 = 11214175559798 := by decide
theorem cert_e2418082537590 : check e2418082537590 [[],[],[.under,.left]] .chain = true := by decide
def e2418082537834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418082537834 : Closed e2418082537834 ∧ code e2418082537834 = 11214175560042 := by decide
theorem cert_e2418082537834 : check e2418082537834 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2418082537882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418082537882 : Closed e2418082537882 ∧ code e2418082537882 = 11214175560090 := by decide
theorem cert_e2418082537882 : check e2418082537882 [[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2418082543642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418082543642 : Closed e2418082543642 ∧ code e2418082543642 = 11214175565850 := by decide
theorem cert_e2418082543642 : check e2418082543642 [[]] .width = true := by decide
def e2418082552346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082552346 : Closed e2418082552346 ∧ code e2418082552346 = 11214175574554 := by decide
theorem cert_e2418082552346 : check e2418082552346 [[],[],[.left],[.left],[],[.under]] .three = true := by decide
def e2418082553882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2418082553882 : Closed e2418082553882 ∧ code e2418082553882 = 11214175576090 := by decide
theorem cert_e2418082553882 : check e2418082553882 [[],[]] .smaller = true := by decide
def e2418082553974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2418082553974 : Closed e2418082553974 ∧ code e2418082553974 = 11214175576182 := by decide
theorem cert_e2418082553974 : check e2418082553974 [[],[],[.under,.left]] .chain = true := by decide
def e2418082554218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2418082554218 : Closed e2418082554218 ∧ code e2418082554218 = 11214175576426 := by decide
theorem cert_e2418082554218 : check e2418082554218 [[],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .chain = true := by decide
def e2418082554266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2418082554266 : Closed e2418082554266 ∧ code e2418082554266 = 11214175576474 := by decide
theorem cert_e2418082554266 : check e2418082554266 [[],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2418082572314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418082572314 : Closed e2418082572314 ∧ code e2418082572314 = 11214175594522 := by decide
theorem cert_e2418082572314 : check e2418082572314 [[]] .width = true := by decide
def e2418082942490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082942490 : Closed e2418082942490 ∧ code e2418082942490 = 11214175964698 := by decide
theorem cert_e2418082942490 : check e2418082942490 [[]] .width = true := by decide
def e2418082951366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418082951366 : Closed e2418082951366 ∧ code e2418082951366 = 11214175973574 := by decide
theorem cert_e2418082951366 : check e2418082951366 [[]] .width = true := by decide
def e2418082953242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418082953242 : Closed e2418082953242 ∧ code e2418082953242 = 11214175975450 := by decide
theorem cert_e2418082953242 : check e2418082953242 [[]] .width = true := by decide
def e2418082956826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418082956826 : Closed e2418082956826 ∧ code e2418082956826 = 11214175979034 := by decide
theorem cert_e2418082956826 : check e2418082956826 [[]] .width = true := by decide
def e2418082959558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2418082959558 : Closed e2418082959558 ∧ code e2418082959558 = 11214175981766 := by decide
theorem cert_e2418082959558 : check e2418082959558 [[]] .width = true := by decide
def e2418082965530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418082965530 : Closed e2418082965530 ∧ code e2418082965530 = 11214175987738 := by decide
theorem cert_e2418082965530 : check e2418082965530 [[]] .width = true := by decide
def e2418083409262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418083409262 : Closed e2418083409262 ∧ code e2418083409262 = 11214176431470 := by decide
theorem cert_e2418083409262 : check e2418083409262 [[],[]] .chain = true := by decide
def e2418083409270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418083409270 : Closed e2418083409270 ∧ code e2418083409270 = 11214176431478 := by decide
theorem cert_e2418083409270 : check e2418083409270 [[],[]] .chain = true := by decide
def e2418083409326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418083409326 : Closed e2418083409326 ∧ code e2418083409326 = 11214176431534 := by decide
theorem cert_e2418083409326 : check e2418083409326 [[],[]] .chain = true := by decide
def e2418083409338 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418083409338 : Closed e2418083409338 ∧ code e2418083409338 = 11214176431546 := by decide
theorem cert_e2418083409338 : check e2418083409338 [[],[]] .chain = true := by decide
def e2418083409366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418083409366 : Closed e2418083409366 ∧ code e2418083409366 = 11214176431574 := by decide
theorem cert_e2418083409366 : check e2418083409366 [[],[]] .chain = true := by decide
def e2418083409370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418083409370 : Closed e2418083409370 ∧ code e2418083409370 = 11214176431578 := by decide
theorem cert_e2418083409370 : check e2418083409370 [[],[]] .chain = true := by decide
def e2418083409582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2418083409582 : Closed e2418083409582 ∧ code e2418083409582 = 11214176431790 := by decide
theorem cert_e2418083409582 : check e2418083409582 [[],[]] .chain = true := by decide
def e2418083409594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2418083409594 : Closed e2418083409594 ∧ code e2418083409594 = 11214176431802 := by decide
theorem cert_e2418083409594 : check e2418083409594 [[],[]] .chain = true := by decide
def e2418083409642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2418083409642 : Closed e2418083409642 ∧ code e2418083409642 = 11214176431850 := by decide
theorem cert_e2418083409642 : check e2418083409642 [[],[]] .chain = true := by decide
def e2418083409750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2418083409750 : Closed e2418083409750 ∧ code e2418083409750 = 11214176431958 := by decide
theorem cert_e2418083409750 : check e2418083409750 [[],[]] .chain = true := by decide
def e2418083409754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2418083409754 : Closed e2418083409754 ∧ code e2418083409754 = 11214176431962 := by decide
theorem cert_e2418083409754 : check e2418083409754 [[],[]] .chain = true := by decide
def e2418083409770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2418083409770 : Closed e2418083409770 ∧ code e2418083409770 = 11214176431978 := by decide
theorem cert_e2418083409770 : check e2418083409770 [[],[]] .chain = true := by decide
def e2418083410798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418083410798 : Closed e2418083410798 ∧ code e2418083410798 = 11214176433006 := by decide
theorem cert_e2418083410798 : check e2418083410798 [[],[]] .chain = true := by decide
def e2418083410806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418083410806 : Closed e2418083410806 ∧ code e2418083410806 = 11214176433014 := by decide
theorem cert_e2418083410806 : check e2418083410806 [[],[]] .chain = true := by decide
def e2418083410862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418083410862 : Closed e2418083410862 ∧ code e2418083410862 = 11214176433070 := by decide
theorem cert_e2418083410862 : check e2418083410862 [[],[]] .chain = true := by decide
def e2418083410874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418083410874 : Closed e2418083410874 ∧ code e2418083410874 = 11214176433082 := by decide
theorem cert_e2418083410874 : check e2418083410874 [[],[]] .chain = true := by decide
def e2418083410902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418083410902 : Closed e2418083410902 ∧ code e2418083410902 = 11214176433110 := by decide
theorem cert_e2418083410902 : check e2418083410902 [[],[]] .chain = true := by decide
def e2418083410906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418083410906 : Closed e2418083410906 ∧ code e2418083410906 = 11214176433114 := by decide
theorem cert_e2418083410906 : check e2418083410906 [[],[]] .chain = true := by decide
def e2418083411182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418083411182 : Closed e2418083411182 ∧ code e2418083411182 = 11214176433390 := by decide
theorem cert_e2418083411182 : check e2418083411182 [[],[]] .chain = true := by decide
def e2418083411190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418083411190 : Closed e2418083411190 ∧ code e2418083411190 = 11214176433398 := by decide
theorem cert_e2418083411190 : check e2418083411190 [[],[]] .chain = true := by decide
def e2418083411566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418083411566 : Closed e2418083411566 ∧ code e2418083411566 = 11214176433774 := by decide
theorem cert_e2418083411566 : check e2418083411566 [[],[]] .chain = true := by decide
def e2418083411578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418083411578 : Closed e2418083411578 ∧ code e2418083411578 = 11214176433786 := by decide
theorem cert_e2418083411578 : check e2418083411578 [[],[]] .chain = true := by decide
def e2418083411766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418083411766 : Closed e2418083411766 ∧ code e2418083411766 = 11214176433974 := by decide
theorem cert_e2418083411766 : check e2418083411766 [[],[]] .chain = true := by decide
def e2418083411770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418083411770 : Closed e2418083411770 ∧ code e2418083411770 = 11214176433978 := by decide
theorem cert_e2418083411770 : check e2418083411770 [[],[]] .chain = true := by decide
def e2418083412398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2418083412398 : Closed e2418083412398 ∧ code e2418083412398 = 11214176434606 := by decide
theorem cert_e2418083412398 : check e2418083412398 [[],[]] .chain = true := by decide
def e2418083412410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2418083412410 : Closed e2418083412410 ∧ code e2418083412410 = 11214176434618 := by decide
theorem cert_e2418083412410 : check e2418083412410 [[],[]] .chain = true := by decide
def e2418083412458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2418083412458 : Closed e2418083412458 ∧ code e2418083412458 = 11214176434666 := by decide
theorem cert_e2418083412458 : check e2418083412458 [[],[]] .chain = true := by decide
def e2418083412590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418083412590 : Closed e2418083412590 ∧ code e2418083412590 = 11214176434798 := by decide
theorem cert_e2418083412590 : check e2418083412590 [[],[]] .chain = true := by decide
def e2418083412602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418083412602 : Closed e2418083412602 ∧ code e2418083412602 = 11214176434810 := by decide
theorem cert_e2418083412602 : check e2418083412602 [[],[]] .chain = true := by decide
def e2418083412890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418083412890 : Closed e2418083412890 ∧ code e2418083412890 = 11214176435098 := by decide
theorem cert_e2418083412890 : check e2418083412890 [[],[]] .chain = true := by decide
def e2418083413206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2418083413206 : Closed e2418083413206 ∧ code e2418083413206 = 11214176435414 := by decide
theorem cert_e2418083413206 : check e2418083413206 [[],[]] .chain = true := by decide
def e2418083413210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2418083413210 : Closed e2418083413210 ∧ code e2418083413210 = 11214176435418 := by decide
theorem cert_e2418083413210 : check e2418083413210 [[],[]] .chain = true := by decide
def e2418083413226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2418083413226 : Closed e2418083413226 ∧ code e2418083413226 = 11214176435434 := by decide
theorem cert_e2418083413226 : check e2418083413226 [[],[]] .chain = true := by decide
def e2418083413302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418083413302 : Closed e2418083413302 ∧ code e2418083413302 = 11214176435510 := by decide
theorem cert_e2418083413302 : check e2418083413302 [[],[]] .chain = true := by decide
def e2418083413306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418083413306 : Closed e2418083413306 ∧ code e2418083413306 = 11214176435514 := by decide
theorem cert_e2418083413306 : check e2418083413306 [[],[]] .chain = true := by decide
def e2418083413402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418083413402 : Closed e2418083413402 ∧ code e2418083413402 = 11214176435610 := by decide
theorem cert_e2418083413402 : check e2418083413402 [[],[]] .chain = true := by decide
def e2418083416942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418083416942 : Closed e2418083416942 ∧ code e2418083416942 = 11214176439150 := by decide
theorem cert_e2418083416942 : check e2418083416942 [[],[]] .chain = true := by decide
def e2418083416950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418083416950 : Closed e2418083416950 ∧ code e2418083416950 = 11214176439158 := by decide
theorem cert_e2418083416950 : check e2418083416950 [[],[]] .chain = true := by decide
def e2418083417006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418083417006 : Closed e2418083417006 ∧ code e2418083417006 = 11214176439214 := by decide
theorem cert_e2418083417006 : check e2418083417006 [[],[]] .chain = true := by decide
def e2418083417018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418083417018 : Closed e2418083417018 ∧ code e2418083417018 = 11214176439226 := by decide
theorem cert_e2418083417018 : check e2418083417018 [[],[]] .chain = true := by decide
def e2418083417046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418083417046 : Closed e2418083417046 ∧ code e2418083417046 = 11214176439254 := by decide
theorem cert_e2418083417046 : check e2418083417046 [[],[]] .chain = true := by decide
def e2418083417050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418083417050 : Closed e2418083417050 ∧ code e2418083417050 = 11214176439258 := by decide
theorem cert_e2418083417050 : check e2418083417050 [[],[]] .chain = true := by decide
def e2418083417326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418083417326 : Closed e2418083417326 ∧ code e2418083417326 = 11214176439534 := by decide
theorem cert_e2418083417326 : check e2418083417326 [[],[]] .chain = true := by decide
def e2418083417334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418083417334 : Closed e2418083417334 ∧ code e2418083417334 = 11214176439542 := by decide
theorem cert_e2418083417334 : check e2418083417334 [[],[]] .chain = true := by decide
def e2418083417710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418083417710 : Closed e2418083417710 ∧ code e2418083417710 = 11214176439918 := by decide
theorem cert_e2418083417710 : check e2418083417710 [[],[]] .chain = true := by decide
def e2418083417722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418083417722 : Closed e2418083417722 ∧ code e2418083417722 = 11214176439930 := by decide
theorem cert_e2418083417722 : check e2418083417722 [[],[]] .chain = true := by decide
def e2418083417910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418083417910 : Closed e2418083417910 ∧ code e2418083417910 = 11214176440118 := by decide
theorem cert_e2418083417910 : check e2418083417910 [[],[]] .chain = true := by decide
def e2418083417914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418083417914 : Closed e2418083417914 ∧ code e2418083417914 = 11214176440122 := by decide
theorem cert_e2418083417914 : check e2418083417914 [[],[]] .chain = true := by decide
def e2418083423662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2418083423662 : Closed e2418083423662 ∧ code e2418083423662 = 11214176445870 := by decide
theorem cert_e2418083423662 : check e2418083423662 [[],[]] .chain = true := by decide
def e2418083423674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2418083423674 : Closed e2418083423674 ∧ code e2418083423674 = 11214176445882 := by decide
theorem cert_e2418083423674 : check e2418083423674 [[],[]] .chain = true := by decide
def e2418083423722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2418083423722 : Closed e2418083423722 ∧ code e2418083423722 = 11214176445930 := by decide
theorem cert_e2418083423722 : check e2418083423722 [[],[]] .chain = true := by decide
def e2418083423854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2418083423854 : Closed e2418083423854 ∧ code e2418083423854 = 11214176446062 := by decide
theorem cert_e2418083423854 : check e2418083423854 [[],[]] .chain = true := by decide
def e2418083423866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2418083423866 : Closed e2418083423866 ∧ code e2418083423866 = 11214176446074 := by decide
theorem cert_e2418083423866 : check e2418083423866 [[],[]] .chain = true := by decide
def e2418083424154 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2418083424154 : Closed e2418083424154 ∧ code e2418083424154 = 11214176446362 := by decide
theorem cert_e2418083424154 : check e2418083424154 [[],[]] .chain = true := by decide
def e2418083427030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2418083427030 : Closed e2418083427030 ∧ code e2418083427030 = 11214176449238 := by decide
theorem cert_e2418083427030 : check e2418083427030 [[],[]] .chain = true := by decide
def e2418083427034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2418083427034 : Closed e2418083427034 ∧ code e2418083427034 = 11214176449242 := by decide
theorem cert_e2418083427034 : check e2418083427034 [[],[]] .chain = true := by decide
def e2418083427050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2418083427050 : Closed e2418083427050 ∧ code e2418083427050 = 11214176449258 := by decide
theorem cert_e2418083427050 : check e2418083427050 [[],[]] .chain = true := by decide
def e2418083427126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2418083427126 : Closed e2418083427126 ∧ code e2418083427126 = 11214176449334 := by decide
theorem cert_e2418083427126 : check e2418083427126 [[],[]] .chain = true := by decide
def e2418083427130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2418083427130 : Closed e2418083427130 ∧ code e2418083427130 = 11214176449338 := by decide
theorem cert_e2418083427130 : check e2418083427130 [[],[]] .chain = true := by decide
def e2418083427226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2418083427226 : Closed e2418083427226 ∧ code e2418083427226 = 11214176449434 := by decide
theorem cert_e2418083427226 : check e2418083427226 [[],[]] .chain = true := by decide
def e2418083564398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418083564398 : Closed e2418083564398 ∧ code e2418083564398 = 11214176586606 := by decide
theorem cert_e2418083564398 : check e2418083564398 [[],[]] .chain = true := by decide
def e2418083564406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418083564406 : Closed e2418083564406 ∧ code e2418083564406 = 11214176586614 := by decide
theorem cert_e2418083564406 : check e2418083564406 [[],[]] .chain = true := by decide
def e2418083564462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418083564462 : Closed e2418083564462 ∧ code e2418083564462 = 11214176586670 := by decide
theorem cert_e2418083564462 : check e2418083564462 [[],[]] .chain = true := by decide
def e2418083564474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418083564474 : Closed e2418083564474 ∧ code e2418083564474 = 11214176586682 := by decide
theorem cert_e2418083564474 : check e2418083564474 [[],[]] .chain = true := by decide
def e2418083564502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418083564502 : Closed e2418083564502 ∧ code e2418083564502 = 11214176586710 := by decide
theorem cert_e2418083564502 : check e2418083564502 [[],[]] .chain = true := by decide
def e2418083564506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418083564506 : Closed e2418083564506 ∧ code e2418083564506 = 11214176586714 := by decide
theorem cert_e2418083564506 : check e2418083564506 [[],[]] .chain = true := by decide
def e2418083564782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418083564782 : Closed e2418083564782 ∧ code e2418083564782 = 11214176586990 := by decide
theorem cert_e2418083564782 : check e2418083564782 [[],[]] .chain = true := by decide
def e2418083564790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418083564790 : Closed e2418083564790 ∧ code e2418083564790 = 11214176586998 := by decide
theorem cert_e2418083564790 : check e2418083564790 [[],[]] .chain = true := by decide
def e2418083565166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418083565166 : Closed e2418083565166 ∧ code e2418083565166 = 11214176587374 := by decide
theorem cert_e2418083565166 : check e2418083565166 [[],[]] .chain = true := by decide
def e2418083565178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418083565178 : Closed e2418083565178 ∧ code e2418083565178 = 11214176587386 := by decide
theorem cert_e2418083565178 : check e2418083565178 [[],[]] .chain = true := by decide
def e2418083565366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418083565366 : Closed e2418083565366 ∧ code e2418083565366 = 11214176587574 := by decide
theorem cert_e2418083565366 : check e2418083565366 [[],[]] .chain = true := by decide
def e2418083565370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418083565370 : Closed e2418083565370 ∧ code e2418083565370 = 11214176587578 := by decide
theorem cert_e2418083565370 : check e2418083565370 [[],[]] .chain = true := by decide
def e2418084154222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418084154222 : Closed e2418084154222 ∧ code e2418084154222 = 11214177176430 := by decide
theorem cert_e2418084154222 : check e2418084154222 [[],[],[.left]] .chain = true := by decide
def e2418084154230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418084154230 : Closed e2418084154230 ∧ code e2418084154230 = 11214177176438 := by decide
theorem cert_e2418084154230 : check e2418084154230 [[],[],[.left]] .chain = true := by decide
def e2418084154286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418084154286 : Closed e2418084154286 ∧ code e2418084154286 = 11214177176494 := by decide
theorem cert_e2418084154286 : check e2418084154286 [[],[],[.left]] .chain = true := by decide
def e2418084154298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418084154298 : Closed e2418084154298 ∧ code e2418084154298 = 11214177176506 := by decide
theorem cert_e2418084154298 : check e2418084154298 [[],[],[.left]] .chain = true := by decide
def e2418084154326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418084154326 : Closed e2418084154326 ∧ code e2418084154326 = 11214177176534 := by decide
theorem cert_e2418084154326 : check e2418084154326 [[],[],[.left]] .chain = true := by decide
def e2418084154330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418084154330 : Closed e2418084154330 ∧ code e2418084154330 = 11214177176538 := by decide
theorem cert_e2418084154330 : check e2418084154330 [[],[],[.left]] .chain = true := by decide
def e2418084154606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418084154606 : Closed e2418084154606 ∧ code e2418084154606 = 11214177176814 := by decide
theorem cert_e2418084154606 : check e2418084154606 [[],[],[.left]] .chain = true := by decide
def e2418084154614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418084154614 : Closed e2418084154614 ∧ code e2418084154614 = 11214177176822 := by decide
theorem cert_e2418084154614 : check e2418084154614 [[],[],[.left]] .chain = true := by decide
def e2418084154990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418084154990 : Closed e2418084154990 ∧ code e2418084154990 = 11214177177198 := by decide
theorem cert_e2418084154990 : check e2418084154990 [[],[],[.left]] .chain = true := by decide
def e2418084155002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418084155002 : Closed e2418084155002 ∧ code e2418084155002 = 11214177177210 := by decide
theorem cert_e2418084155002 : check e2418084155002 [[],[],[.left]] .chain = true := by decide
def e2418084155190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418084155190 : Closed e2418084155190 ∧ code e2418084155190 = 11214177177398 := by decide
theorem cert_e2418084155190 : check e2418084155190 [[],[],[.left]] .chain = true := by decide
def e2418084155194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418084155194 : Closed e2418084155194 ∧ code e2418084155194 = 11214177177402 := by decide
theorem cert_e2418084155194 : check e2418084155194 [[],[],[.left]] .chain = true := by decide
def e2418111770138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418111770138 : Closed e2418111770138 ∧ code e2418111770138 = 11214204792346 := by decide
theorem cert_e2418111770138 : check e2418111770138 [[]] .width = true := by decide
def e2418111772186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418111772186 : Closed e2418111772186 ∧ code e2418111772186 = 11214204794394 := by decide
theorem cert_e2418111772186 : check e2418111772186 [[]] .width = true := by decide
def e2418112051226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112051226 : Closed e2418112051226 ∧ code e2418112051226 = 11214205073434 := by decide
theorem cert_e2418112051226 : check e2418112051226 [[]] .width = true := by decide
def e2418112059418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112059418 : Closed e2418112059418 ∧ code e2418112059418 = 11214205081626 := by decide
theorem cert_e2418112059418 : check e2418112059418 [[]] .width = true := by decide
def e2418112081434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112081434 : Closed e2418112081434 ∧ code e2418112081434 = 11214205103642 := by decide
theorem cert_e2418112081434 : check e2418112081434 [[]] .width = true := by decide
def e2418112116762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112116762 : Closed e2418112116762 ∧ code e2418112116762 = 11214205138970 := by decide
theorem cert_e2418112116762 : check e2418112116762 [[]] .width = true := by decide
def e2418112127514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112127514 : Closed e2418112127514 ∧ code e2418112127514 = 11214205149722 := by decide
theorem cert_e2418112127514 : check e2418112127514 [[]] .width = true := by decide
def e2418112129050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112129050 : Closed e2418112129050 ∧ code e2418112129050 = 11214205151258 := by decide
theorem cert_e2418112129050 : check e2418112129050 [[]] .width = true := by decide
def e2418112130586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112130586 : Closed e2418112130586 ∧ code e2418112130586 = 11214205152794 := by decide
theorem cert_e2418112130586 : check e2418112130586 [[]] .width = true := by decide
def e2418112140826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112140826 : Closed e2418112140826 ∧ code e2418112140826 = 11214205163034 := by decide
theorem cert_e2418112140826 : check e2418112140826 [[]] .width = true := by decide
def e2418112157722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112157722 : Closed e2418112157722 ∧ code e2418112157722 = 11214205179930 := by decide
theorem cert_e2418112157722 : check e2418112157722 [[]] .width = true := by decide
def e2418112160282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112160282 : Closed e2418112160282 ∧ code e2418112160282 = 11214205182490 := by decide
theorem cert_e2418112160282 : check e2418112160282 [[]] .width = true := by decide
def e2418112161818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112161818 : Closed e2418112161818 ∧ code e2418112161818 = 11214205184026 := by decide
theorem cert_e2418112161818 : check e2418112161818 [[]] .width = true := by decide
def e2418112163354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112163354 : Closed e2418112163354 ∧ code e2418112163354 = 11214205185562 := by decide
theorem cert_e2418112163354 : check e2418112163354 [[]] .width = true := by decide
def e2418112165402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112165402 : Closed e2418112165402 ∧ code e2418112165402 = 11214205187610 := by decide
theorem cert_e2418112165402 : check e2418112165402 [[]] .width = true := by decide
def e2418112245274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112245274 : Closed e2418112245274 ∧ code e2418112245274 = 11214205267482 := by decide
theorem cert_e2418112245274 : check e2418112245274 [[]] .width = true := by decide
def e2418112248346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112248346 : Closed e2418112248346 ∧ code e2418112248346 = 11214205270554 := by decide
theorem cert_e2418112248346 : check e2418112248346 [[]] .width = true := by decide
def e2418112343578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112343578 : Closed e2418112343578 ∧ code e2418112343578 = 11214205365786 := by decide
theorem cert_e2418112343578 : check e2418112343578 [[]] .width = true := by decide
def e2418112378906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112378906 : Closed e2418112378906 ∧ code e2418112378906 = 11214205401114 := by decide
theorem cert_e2418112378906 : check e2418112378906 [[]] .width = true := by decide
def e2418112389658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112389658 : Closed e2418112389658 ∧ code e2418112389658 = 11214205411866 := by decide
theorem cert_e2418112389658 : check e2418112389658 [[]] .width = true := by decide
def e2418112391194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112391194 : Closed e2418112391194 ∧ code e2418112391194 = 11214205413402 := by decide
theorem cert_e2418112391194 : check e2418112391194 [[]] .width = true := by decide
def e2418112392730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112392730 : Closed e2418112392730 ∧ code e2418112392730 = 11214205414938 := by decide
theorem cert_e2418112392730 : check e2418112392730 [[]] .width = true := by decide
def e2418112432666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112432666 : Closed e2418112432666 ∧ code e2418112432666 = 11214205454874 := by decide
private def t_e2418112432666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112432666 : ¬ IsSelfInterpreter e2418112432666 :=
  wSource (t := t_e2418112432666) (replay_sound (ps := []) (t := e2418112432666) (by decide)) (by decide)
def e2418112438810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112438810 : Closed e2418112438810 ∧ code e2418112438810 = 11214205461018 := by decide
private def t_e2418112438810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112438810 : ¬ IsSelfInterpreter e2418112438810 :=
  wSource (t := t_e2418112438810) (replay_sound (ps := []) (t := e2418112438810) (by decide)) (by decide)
def e2418112440346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112440346 : Closed e2418112440346 ∧ code e2418112440346 = 11214205462554 := by decide
theorem cert_e2418112440346 : check e2418112440346 [[]] .width = true := by decide
def e2418112441882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112441882 : Closed e2418112441882 ∧ code e2418112441882 = 11214205464090 := by decide
private def t_e2418112441882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112441882 : ¬ IsSelfInterpreter e2418112441882 :=
  wSource (t := t_e2418112441882) (replay_sound (ps := []) (t := e2418112441882) (by decide)) (by decide)
def e2418112444954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112444954 : Closed e2418112444954 ∧ code e2418112444954 = 11214205467162 := by decide
private def t_e2418112444954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112444954 : ¬ IsSelfInterpreter e2418112444954 :=
  wSource (t := t_e2418112444954) (replay_sound (ps := []) (t := e2418112444954) (by decide)) (by decide)
def e2418112484890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112484890 : Closed e2418112484890 ∧ code e2418112484890 = 11214205507098 := by decide
theorem cert_e2418112484890 : check e2418112484890 [[]] .width = true := by decide
def e2418112485914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112485914 : Closed e2418112485914 ∧ code e2418112485914 = 11214205508122 := by decide
theorem cert_e2418112485914 : check e2418112485914 [[]] .width = true := by decide
def e2418112534042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112534042 : Closed e2418112534042 ∧ code e2418112534042 = 11214205556250 := by decide
theorem cert_e2418112534042 : check e2418112534042 [[]] .width = true := by decide
def e2418112550938 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112550938 : Closed e2418112550938 ∧ code e2418112550938 = 11214205573146 := by decide
theorem cert_e2418112550938 : check e2418112550938 [[]] .width = true := by decide
def e2418112553498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112553498 : Closed e2418112553498 ∧ code e2418112553498 = 11214205575706 := by decide
theorem cert_e2418112553498 : check e2418112553498 [[]] .width = true := by decide
def e2418112555034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112555034 : Closed e2418112555034 ∧ code e2418112555034 = 11214205577242 := by decide
theorem cert_e2418112555034 : check e2418112555034 [[]] .width = true := by decide
def e2418112556570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112556570 : Closed e2418112556570 ∧ code e2418112556570 = 11214205578778 := by decide
theorem cert_e2418112556570 : check e2418112556570 [[]] .width = true := by decide
def e2418112558618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112558618 : Closed e2418112558618 ∧ code e2418112558618 = 11214205580826 := by decide
theorem cert_e2418112558618 : check e2418112558618 [[]] .width = true := by decide
def e2418112563738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112563738 : Closed e2418112563738 ∧ code e2418112563738 = 11214205585946 := by decide
private def t_e2418112563738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112563738 : ¬ IsSelfInterpreter e2418112563738 :=
  wSource (t := t_e2418112563738) (replay_sound (ps := []) (t := e2418112563738) (by decide)) (by decide)
def e2418112569882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112569882 : Closed e2418112569882 ∧ code e2418112569882 = 11214205592090 := by decide
private def t_e2418112569882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112569882 : ¬ IsSelfInterpreter e2418112569882 :=
  wSource (t := t_e2418112569882) (replay_sound (ps := []) (t := e2418112569882) (by decide)) (by decide)
def e2418112571418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418112571418 : Closed e2418112571418 ∧ code e2418112571418 = 11214205593626 := by decide
theorem cert_e2418112571418 : check e2418112571418 [[]] .width = true := by decide
def e2418112572954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112572954 : Closed e2418112572954 ∧ code e2418112572954 = 11214205595162 := by decide
private def t_e2418112572954 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112572954 : ¬ IsSelfInterpreter e2418112572954 :=
  wSource (t := t_e2418112572954) (replay_sound (ps := []) (t := e2418112572954) (by decide)) (by decide)
def e2418112576026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418112576026 : Closed e2418112576026 ∧ code e2418112576026 = 11214205598234 := by decide
private def t_e2418112576026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2418112576026 : ¬ IsSelfInterpreter e2418112576026 :=
  wSource (t := t_e2418112576026) (replay_sound (ps := []) (t := e2418112576026) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2418112432666
#print axioms Blc.Floor43.cert_e2418112438810
#print axioms Blc.Floor43.cert_e2418112441882
#print axioms Blc.Floor43.cert_e2418112444954
#print axioms Blc.Floor43.cert_e2418112563738
#print axioms Blc.Floor43.cert_e2418112569882
#print axioms Blc.Floor43.cert_e2418112572954
#print axioms Blc.Floor43.cert_e2418112576026
