import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630009914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2411630009914 : Closed e2411630009914 ∧ code e2411630009914 = 11207723032122 := by decide
theorem cert_e2411630009914 : check e2411630009914 [[],[]] .chain = true := by decide
def e2411630009998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2411630009998 : Closed e2411630009998 ∧ code e2411630009998 = 11207723032206 := by decide
theorem cert_e2411630009998 : check e2411630009998 [[],[]] .chain = true := by decide
def e2411630010054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2411630010054 : Closed e2411630010054 ∧ code e2411630010054 = 11207723032262 := by decide
theorem cert_e2411630010054 : check e2411630010054 [[],[]] .chain = true := by decide
def e2411630012190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2411630012190 : Closed e2411630012190 ∧ code e2411630012190 = 11207723034398 := by decide
theorem cert_e2411630012190 : check e2411630012190 [[],[]] .chain = true := by decide
def e2411630012302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2411630012302 : Closed e2411630012302 ∧ code e2411630012302 = 11207723034510 := by decide
theorem cert_e2411630012302 : check e2411630012302 [[],[]] .chain = true := by decide
def e2411630014686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2411630014686 : Closed e2411630014686 ∧ code e2411630014686 = 11207723036894 := by decide
theorem cert_e2411630014686 : check e2411630014686 [[],[]] .chain = true := by decide
def e2411630014714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2411630014714 : Closed e2411630014714 ∧ code e2411630014714 = 11207723036922 := by decide
theorem cert_e2411630014714 : check e2411630014714 [[],[]] .chain = true := by decide
def e2411630015262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2411630015262 : Closed e2411630015262 ∧ code e2411630015262 = 11207723037470 := by decide
theorem cert_e2411630015262 : check e2411630015262 [[],[]] .chain = true := by decide
def e2411630015430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2411630015430 : Closed e2411630015430 ∧ code e2411630015430 = 11207723037638 := by decide
theorem cert_e2411630015430 : check e2411630015430 [[],[]] .chain = true := by decide
def e2411630016622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2411630016622 : Closed e2411630016622 ∧ code e2411630016622 = 11207723038830 := by decide
theorem cert_e2411630016622 : check e2411630016622 [[],[]] .chain = true := by decide
def e2411630016634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2411630016634 : Closed e2411630016634 ∧ code e2411630016634 = 11207723038842 := by decide
theorem cert_e2411630016634 : check e2411630016634 [[],[]] .chain = true := by decide
def e2411630016910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411630016910 : Closed e2411630016910 ∧ code e2411630016910 = 11207723039118 := by decide
theorem cert_e2411630016910 : check e2411630016910 [[],[]] .chain = true := by decide
def e2411630016966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411630016966 : Closed e2411630016966 ∧ code e2411630016966 = 11207723039174 := by decide
theorem cert_e2411630016966 : check e2411630016966 [[],[]] .chain = true := by decide
def e2411630019054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2411630019054 : Closed e2411630019054 ∧ code e2411630019054 = 11207723041262 := by decide
theorem cert_e2411630019054 : check e2411630019054 [[],[]] .chain = true := by decide
def e2411630019062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 1))))))
theorem wire_e2411630019062 : Closed e2411630019062 ∧ code e2411630019062 = 11207723041270 := by decide
theorem cert_e2411630019062 : check e2411630019062 [[],[]] .chain = true := by decide
def e2411630019438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 2))))))
theorem wire_e2411630019438 : Closed e2411630019438 ∧ code e2411630019438 = 11207723041646 := by decide
theorem cert_e2411630019438 : check e2411630019438 [[],[]] .chain = true := by decide
def e2411630019450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 3))))) (.var 0))))))
theorem wire_e2411630019450 : Closed e2411630019450 ∧ code e2411630019450 = 11207723041658 := by decide
theorem cert_e2411630019450 : check e2411630019450 [[],[]] .chain = true := by decide
def e2411630019502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 2))))))
theorem wire_e2411630019502 : Closed e2411630019502 ∧ code e2411630019502 = 11207723041710 := by decide
theorem cert_e2411630019502 : check e2411630019502 [[],[]] .chain = true := by decide
def e2411630019562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 0))))) (.var 0))))))
theorem wire_e2411630019562 : Closed e2411630019562 ∧ code e2411630019562 = 11207723041770 := by decide
theorem cert_e2411630019562 : check e2411630019562 [[],[]] .chain = true := by decide
def e2411630019822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630019822 : Closed e2411630019822 ∧ code e2411630019822 = 11207723042030 := by decide
theorem cert_e2411630019822 : check e2411630019822 [[],[]] .chain = true := by decide
def e2411630019830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630019830 : Closed e2411630019830 ∧ code e2411630019830 = 11207723042038 := by decide
theorem cert_e2411630019830 : check e2411630019830 [[],[]] .chain = true := by decide
def e2411630020206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630020206 : Closed e2411630020206 ∧ code e2411630020206 = 11207723042414 := by decide
theorem cert_e2411630020206 : check e2411630020206 [[],[]] .chain = true := by decide
def e2411630020218 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630020218 : Closed e2411630020218 ∧ code e2411630020218 = 11207723042426 := by decide
theorem cert_e2411630020218 : check e2411630020218 [[],[]] .chain = true := by decide
def e2411630020382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2411630020382 : Closed e2411630020382 ∧ code e2411630020382 = 11207723042590 := by decide
theorem cert_e2411630020382 : check e2411630020382 [[],[]] .chain = true := by decide
def e2411630020494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2411630020494 : Closed e2411630020494 ∧ code e2411630020494 = 11207723042702 := by decide
theorem cert_e2411630020494 : check e2411630020494 [[],[]] .chain = true := by decide
def e2411630020506 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630020506 : Closed e2411630020506 ∧ code e2411630020506 = 11207723042714 := by decide
theorem cert_e2411630020506 : check e2411630020506 [[],[]] .chain = true := by decide
def e2411630021742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2411630021742 : Closed e2411630021742 ∧ code e2411630021742 = 11207723043950 := by decide
theorem cert_e2411630021742 : check e2411630021742 [[],[]] .chain = true := by decide
def e2411630021754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e2411630021754 : Closed e2411630021754 ∧ code e2411630021754 = 11207723043962 := by decide
theorem cert_e2411630021754 : check e2411630021754 [[],[]] .chain = true := by decide
def e2411630021918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2411630021918 : Closed e2411630021918 ∧ code e2411630021918 = 11207723044126 := by decide
theorem cert_e2411630021918 : check e2411630021918 [[],[]] .chain = true := by decide
def e2411630022086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2411630022086 : Closed e2411630022086 ∧ code e2411630022086 = 11207723044294 := by decide
theorem cert_e2411630022086 : check e2411630022086 [[],[]] .chain = true := by decide
def e2411630022190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2411630022190 : Closed e2411630022190 ∧ code e2411630022190 = 11207723044398 := by decide
theorem cert_e2411630022190 : check e2411630022190 [[],[]] .chain = true := by decide
def e2411630022370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2411630022370 : Closed e2411630022370 ∧ code e2411630022370 = 11207723044578 := by decide
theorem cert_e2411630022370 : check e2411630022370 [[],[]] .chain = true := by decide
def e2411630022382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2411630022382 : Closed e2411630022382 ∧ code e2411630022382 = 11207723044590 := by decide
theorem cert_e2411630022382 : check e2411630022382 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630022422 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2411630022422 : Closed e2411630022422 ∧ code e2411630022422 = 11207723044630 := by decide
theorem cert_e2411630022422 : check e2411630022422 [[],[]] .chain = true := by decide
def e2411630022426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2411630022426 : Closed e2411630022426 ∧ code e2411630022426 = 11207723044634 := by decide
theorem cert_e2411630022426 : check e2411630022426 [[],[]] .chain = true := by decide
def e2411630022470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2411630022470 : Closed e2411630022470 ∧ code e2411630022470 = 11207723044678 := by decide
theorem cert_e2411630022470 : check e2411630022470 [[],[]] .chain = true := by decide
def e2411630022498 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2411630022498 : Closed e2411630022498 ∧ code e2411630022498 = 11207723044706 := by decide
theorem cert_e2411630022498 : check e2411630022498 [[],[]] .chain = true := by decide
def e2411630022510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2411630022510 : Closed e2411630022510 ∧ code e2411630022510 = 11207723044718 := by decide
theorem cert_e2411630022510 : check e2411630022510 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630022518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2411630022518 : Closed e2411630022518 ∧ code e2411630022518 = 11207723044726 := by decide
theorem cert_e2411630022518 : check e2411630022518 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630022878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2411630022878 : Closed e2411630022878 ∧ code e2411630022878 = 11207723045086 := by decide
theorem cert_e2411630022878 : check e2411630022878 [[],[]] .chain = true := by decide
def e2411630022906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2411630022906 : Closed e2411630022906 ∧ code e2411630022906 = 11207723045114 := by decide
theorem cert_e2411630022906 : check e2411630022906 [[],[]] .chain = true := by decide
def e2411630023454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2411630023454 : Closed e2411630023454 ∧ code e2411630023454 = 11207723045662 := by decide
theorem cert_e2411630023454 : check e2411630023454 [[],[]] .chain = true := by decide
def e2411630023622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2411630023622 : Closed e2411630023622 ∧ code e2411630023622 = 11207723045830 := by decide
theorem cert_e2411630023622 : check e2411630023622 [[],[]] .chain = true := by decide
def e2411630024766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2411630024766 : Closed e2411630024766 ∧ code e2411630024766 = 11207723046974 := by decide
theorem cert_e2411630024766 : check e2411630024766 [[],[]] .chain = true := by decide
def e2411630025186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2411630025186 : Closed e2411630025186 ∧ code e2411630025186 = 11207723047394 := by decide
theorem cert_e2411630025186 : check e2411630025186 [[],[]] .chain = true := by decide
def e2411630025198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2411630025198 : Closed e2411630025198 ∧ code e2411630025198 = 11207723047406 := by decide
theorem cert_e2411630025198 : check e2411630025198 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630025758 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2411630025758 : Closed e2411630025758 ∧ code e2411630025758 = 11207723047966 := by decide
theorem cert_e2411630025758 : check e2411630025758 [[],[]] .chain = true := by decide
def e2411630025782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411630025782 : Closed e2411630025782 ∧ code e2411630025782 = 11207723047990 := by decide
theorem cert_e2411630025782 : check e2411630025782 [[],[]] .chain = true := by decide
def e2411630025786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411630025786 : Closed e2411630025786 ∧ code e2411630025786 = 11207723047994 := by decide
theorem cert_e2411630025786 : check e2411630025786 [[],[]] .chain = true := by decide
def e2411630025926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411630025926 : Closed e2411630025926 ∧ code e2411630025926 = 11207723048134 := by decide
theorem cert_e2411630025926 : check e2411630025926 [[],[]] .chain = true := by decide
def e2411630025954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411630025954 : Closed e2411630025954 ∧ code e2411630025954 = 11207723048162 := by decide
theorem cert_e2411630025954 : check e2411630025954 [[],[]] .chain = true := by decide
def e2411630025966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630025966 : Closed e2411630025966 ∧ code e2411630025966 = 11207723048174 := by decide
theorem cert_e2411630025966 : check e2411630025966 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630025974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630025974 : Closed e2411630025974 ∧ code e2411630025974 = 11207723048182 := by decide
theorem cert_e2411630025974 : check e2411630025974 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630026998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e2411630026998 : Closed e2411630026998 ∧ code e2411630026998 = 11207723049206 := by decide
theorem cert_e2411630026998 : check e2411630026998 [[],[]] .chain = true := by decide
def e2411630027190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e2411630027190 : Closed e2411630027190 ∧ code e2411630027190 = 11207723049398 := by decide
theorem cert_e2411630027190 : check e2411630027190 [[],[]] .chain = true := by decide
def e2411630027194 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2411630027194 : Closed e2411630027194 ∧ code e2411630027194 = 11207723049402 := by decide
theorem cert_e2411630027194 : check e2411630027194 [[],[]] .chain = true := by decide
def e2411630027222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e2411630027222 : Closed e2411630027222 ∧ code e2411630027222 = 11207723049430 := by decide
theorem cert_e2411630027222 : check e2411630027222 [[],[]] .chain = true := by decide
def e2411630027242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2411630027242 : Closed e2411630027242 ∧ code e2411630027242 = 11207723049450 := by decide
theorem cert_e2411630027242 : check e2411630027242 [[],[]] .chain = true := by decide
def e2411630027382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411630027382 : Closed e2411630027382 ∧ code e2411630027382 = 11207723049590 := by decide
theorem cert_e2411630027382 : check e2411630027382 [[],[]] .chain = true := by decide
def e2411630027574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630027574 : Closed e2411630027574 ∧ code e2411630027574 = 11207723049782 := by decide
theorem cert_e2411630027574 : check e2411630027574 [[],[]] .chain = true := by decide
def e2411630027578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630027578 : Closed e2411630027578 ∧ code e2411630027578 = 11207723049786 := by decide
theorem cert_e2411630027578 : check e2411630027578 [[],[]] .chain = true := by decide
def e2411630027662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2411630027662 : Closed e2411630027662 ∧ code e2411630027662 = 11207723049870 := by decide
theorem cert_e2411630027662 : check e2411630027662 [[],[]] .chain = true := by decide
def e2411630027674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630027674 : Closed e2411630027674 ∧ code e2411630027674 = 11207723049882 := by decide
theorem cert_e2411630027674 : check e2411630027674 [[],[]] .chain = true := by decide
def e2411630028342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2411630028342 : Closed e2411630028342 ∧ code e2411630028342 = 11207723050550 := by decide
theorem cert_e2411630028342 : check e2411630028342 [[],[]] .chain = true := by decide
def e2411630028346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2411630028346 : Closed e2411630028346 ∧ code e2411630028346 = 11207723050554 := by decide
theorem cert_e2411630028346 : check e2411630028346 [[],[]] .chain = true := by decide
def e2411630028430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2411630028430 : Closed e2411630028430 ∧ code e2411630028430 = 11207723050638 := by decide
theorem cert_e2411630028430 : check e2411630028430 [[],[]] .chain = true := by decide
def e2411630028486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2411630028486 : Closed e2411630028486 ∧ code e2411630028486 = 11207723050694 := by decide
theorem cert_e2411630028486 : check e2411630028486 [[],[]] .chain = true := by decide
def e2411630028566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2411630028566 : Closed e2411630028566 ∧ code e2411630028566 = 11207723050774 := by decide
theorem cert_e2411630028566 : check e2411630028566 [[],[]] .chain = true := by decide
def e2411630028570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2411630028570 : Closed e2411630028570 ∧ code e2411630028570 = 11207723050778 := by decide
theorem cert_e2411630028570 : check e2411630028570 [[],[]] .chain = true := by decide
def e2411630028614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2411630028614 : Closed e2411630028614 ∧ code e2411630028614 = 11207723050822 := by decide
theorem cert_e2411630028614 : check e2411630028614 [[],[]] .chain = true := by decide
def e2411630028642 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2411630028642 : Closed e2411630028642 ∧ code e2411630028642 = 11207723050850 := by decide
theorem cert_e2411630028642 : check e2411630028642 [[],[]] .chain = true := by decide
def e2411630028654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2411630028654 : Closed e2411630028654 ∧ code e2411630028654 = 11207723050862 := by decide
theorem cert_e2411630028654 : check e2411630028654 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2411630028662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2411630028662 : Closed e2411630028662 ∧ code e2411630028662 = 11207723050870 := by decide
theorem cert_e2411630028662 : checkPay e2411630028662 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.under],[.under,.left],[.under]] = true := by decide
def e2411630028726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2411630028726 : Closed e2411630028726 ∧ code e2411630028726 = 11207723050934 := by decide
theorem cert_e2411630028726 : checkPay e2411630028726 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [[],[.under]] = true := by decide
def e2411630028910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2411630028910 : Closed e2411630028910 ∧ code e2411630028910 = 11207723051118 := by decide
theorem cert_e2411630028910 : check e2411630028910 [[],[]] .chain = true := by decide
def e2411630028922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2411630028922 : Closed e2411630028922 ∧ code e2411630028922 = 11207723051130 := by decide
theorem cert_e2411630028922 : check e2411630028922 [[],[]] .chain = true := by decide
def e2411630029198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411630029198 : Closed e2411630029198 ∧ code e2411630029198 = 11207723051406 := by decide
theorem cert_e2411630029198 : check e2411630029198 [[],[]] .chain = true := by decide
def e2411630029254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411630029254 : Closed e2411630029254 ∧ code e2411630029254 = 11207723051462 := by decide
theorem cert_e2411630029254 : check e2411630029254 [[],[]] .chain = true := by decide
def e2411630029854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e2411630029854 : Closed e2411630029854 ∧ code e2411630029854 = 11207723052062 := by decide
theorem cert_e2411630029854 : check e2411630029854 [[],[]] .chain = true := by decide
def e2411630029878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411630029878 : Closed e2411630029878 ∧ code e2411630029878 = 11207723052086 := by decide
theorem cert_e2411630029878 : check e2411630029878 [[],[]] .chain = true := by decide
def e2411630029882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411630029882 : Closed e2411630029882 ∧ code e2411630029882 = 11207723052090 := by decide
theorem cert_e2411630029882 : check e2411630029882 [[],[]] .chain = true := by decide
def e2411630030022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411630030022 : Closed e2411630030022 ∧ code e2411630030022 = 11207723052230 := by decide
theorem cert_e2411630030022 : check e2411630030022 [[],[]] .chain = true := by decide
def e2411630030050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411630030050 : Closed e2411630030050 ∧ code e2411630030050 = 11207723052258 := by decide
theorem cert_e2411630030050 : check e2411630030050 [[],[]] .chain = true := by decide
def e2411630030062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630030062 : Closed e2411630030062 ∧ code e2411630030062 = 11207723052270 := by decide
theorem cert_e2411630030062 : check e2411630030062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630030070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630030070 : Closed e2411630030070 ∧ code e2411630030070 = 11207723052278 := by decide
theorem cert_e2411630030070 : check e2411630030070 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630030454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411630030454 : Closed e2411630030454 ∧ code e2411630030454 = 11207723052662 := by decide
theorem cert_e2411630030454 : check e2411630030454 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411630040798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2411630040798 : Closed e2411630040798 ∧ code e2411630040798 = 11207723063006 := by decide
theorem cert_e2411630040798 : check e2411630040798 [[],[]] .chain = true := by decide
def e2411630040822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2411630040822 : Closed e2411630040822 ∧ code e2411630040822 = 11207723063030 := by decide
theorem cert_e2411630040822 : check e2411630040822 [[],[]] .chain = true := by decide
def e2411630040926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2411630040926 : Closed e2411630040926 ∧ code e2411630040926 = 11207723063134 := by decide
theorem cert_e2411630040926 : check e2411630040926 [[],[]] .chain = true := by decide
def e2411630040954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2411630040954 : Closed e2411630040954 ∧ code e2411630040954 = 11207723063162 := by decide
theorem cert_e2411630040954 : check e2411630040954 [[],[]] .chain = true := by decide
def e2411630041046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2411630041046 : Closed e2411630041046 ∧ code e2411630041046 = 11207723063254 := by decide
theorem cert_e2411630041046 : check e2411630041046 [[],[]] .chain = true := by decide
def e2411630041050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2411630041050 : Closed e2411630041050 ∧ code e2411630041050 = 11207723063258 := by decide
theorem cert_e2411630041050 : check e2411630041050 [[],[]] .chain = true := by decide
def e2411630041566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411630041566 : Closed e2411630041566 ∧ code e2411630041566 = 11207723063774 := by decide
theorem cert_e2411630041566 : check e2411630041566 [[],[]] .chain = true := by decide
def e2411630041590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411630041590 : Closed e2411630041590 ∧ code e2411630041590 = 11207723063798 := by decide
theorem cert_e2411630041590 : check e2411630041590 [[],[]] .chain = true := by decide
def e2411630042334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630042334 : Closed e2411630042334 ∧ code e2411630042334 = 11207723064542 := by decide
theorem cert_e2411630042334 : check e2411630042334 [[],[]] .chain = true := by decide
def e2411630042362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630042362 : Closed e2411630042362 ∧ code e2411630042362 = 11207723064570 := by decide
theorem cert_e2411630042362 : check e2411630042362 [[],[]] .chain = true := by decide
def e2411630042686 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2411630042686 : Closed e2411630042686 ∧ code e2411630042686 = 11207723064894 := by decide
theorem cert_e2411630042686 : check e2411630042686 [[],[]] .chain = true := by decide
def e2411630042910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2411630042910 : Closed e2411630042910 ∧ code e2411630042910 = 11207723065118 := by decide
theorem cert_e2411630042910 : check e2411630042910 [[],[]] .chain = true := by decide
def e2411630042934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630042934 : Closed e2411630042934 ∧ code e2411630042934 = 11207723065142 := by decide
theorem cert_e2411630042934 : check e2411630042934 [[],[]] .chain = true := by decide
def e2411630042938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630042938 : Closed e2411630042938 ∧ code e2411630042938 = 11207723065146 := by decide
theorem cert_e2411630042938 : check e2411630042938 [[],[]] .chain = true := by decide
def e2411630057710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411630057710 : Closed e2411630057710 ∧ code e2411630057710 = 11207723079918 := by decide
theorem cert_e2411630057710 : check e2411630057710 [[],[]] .chain = true := by decide
def e2411630057718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411630057718 : Closed e2411630057718 ∧ code e2411630057718 = 11207723079926 := by decide
theorem cert_e2411630057718 : check e2411630057718 [[],[]] .chain = true := by decide
def e2411630058270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411630058270 : Closed e2411630058270 ∧ code e2411630058270 = 11207723080478 := by decide
theorem cert_e2411630058270 : check e2411630058270 [[],[]] .chain = true := by decide
def e2411630058382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411630058382 : Closed e2411630058382 ∧ code e2411630058382 = 11207723080590 := by decide
theorem cert_e2411630058382 : check e2411630058382 [[],[]] .chain = true := by decide
def e2411630058606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411630058606 : Closed e2411630058606 ∧ code e2411630058606 = 11207723080814 := by decide
theorem cert_e2411630058606 : check e2411630058606 [[],[]] .chain = true := by decide
def e2411630058618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411630058618 : Closed e2411630058618 ∧ code e2411630058618 = 11207723080826 := by decide
theorem cert_e2411630058618 : check e2411630058618 [[],[]] .chain = true := by decide
def e2411630058782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411630058782 : Closed e2411630058782 ∧ code e2411630058782 = 11207723080990 := by decide
theorem cert_e2411630058782 : check e2411630058782 [[],[]] .chain = true := by decide
def e2411630058950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411630058950 : Closed e2411630058950 ∧ code e2411630058950 = 11207723081158 := by decide
theorem cert_e2411630058950 : check e2411630058950 [[],[]] .chain = true := by decide
def e2411630059062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2411630059062 : Closed e2411630059062 ∧ code e2411630059062 = 11207723081270 := by decide
theorem cert_e2411630059062 : check e2411630059062 [[],[]] .chain = true := by decide
def e2411630059066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2411630059066 : Closed e2411630059066 ∧ code e2411630059066 = 11207723081274 := by decide
theorem cert_e2411630059066 : check e2411630059066 [[],[]] .chain = true := by decide
def e2411630059150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2411630059150 : Closed e2411630059150 ∧ code e2411630059150 = 11207723081358 := by decide
theorem cert_e2411630059150 : check e2411630059150 [[],[]] .chain = true := by decide
def e2411630059206 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2411630059206 : Closed e2411630059206 ∧ code e2411630059206 = 11207723081414 := by decide
theorem cert_e2411630059206 : check e2411630059206 [[],[]] .chain = true := by decide
def e2411630061342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2411630061342 : Closed e2411630061342 ∧ code e2411630061342 = 11207723083550 := by decide
theorem cert_e2411630061342 : check e2411630061342 [[],[]] .chain = true := by decide
def e2411630061454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2411630061454 : Closed e2411630061454 ∧ code e2411630061454 = 11207723083662 := by decide
theorem cert_e2411630061454 : check e2411630061454 [[],[]] .chain = true := by decide
def e2411630063838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630063838 : Closed e2411630063838 ∧ code e2411630063838 = 11207723086046 := by decide
theorem cert_e2411630063838 : check e2411630063838 [[],[]] .chain = true := by decide
def e2411630063866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630063866 : Closed e2411630063866 ∧ code e2411630063866 = 11207723086074 := by decide
theorem cert_e2411630063866 : check e2411630063866 [[],[]] .chain = true := by decide
def e2411630064414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411630064414 : Closed e2411630064414 ∧ code e2411630064414 = 11207723086622 := by decide
theorem cert_e2411630064414 : check e2411630064414 [[],[]] .chain = true := by decide
def e2411630064582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411630064582 : Closed e2411630064582 ∧ code e2411630064582 = 11207723086790 := by decide
theorem cert_e2411630064582 : check e2411630064582 [[],[]] .chain = true := by decide
def e2411630065774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630065774 : Closed e2411630065774 ∧ code e2411630065774 = 11207723087982 := by decide
theorem cert_e2411630065774 : check e2411630065774 [[],[]] .chain = true := by decide
def e2411630065786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630065786 : Closed e2411630065786 ∧ code e2411630065786 = 11207723087994 := by decide
theorem cert_e2411630065786 : check e2411630065786 [[],[]] .chain = true := by decide
def e2411630066062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2411630066062 : Closed e2411630066062 ∧ code e2411630066062 = 11207723088270 := by decide
theorem cert_e2411630066062 : check e2411630066062 [[],[]] .chain = true := by decide
def e2411630066118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2411630066118 : Closed e2411630066118 ∧ code e2411630066118 = 11207723088326 := by decide
theorem cert_e2411630066118 : check e2411630066118 [[],[]] .chain = true := by decide
def e2411630103390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2411630103390 : Closed e2411630103390 ∧ code e2411630103390 = 11207723125598 := by decide
theorem cert_e2411630103390 : check e2411630103390 [[],[]] .chain = true := by decide
def e2411630103406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411630103406 : Closed e2411630103406 ∧ code e2411630103406 = 11207723125614 := by decide
theorem cert_e2411630103406 : check e2411630103406 [[],[]] .smaller = true := by decide
def e2411630103414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411630103414 : Closed e2411630103414 ∧ code e2411630103414 = 11207723125622 := by decide
theorem cert_e2411630103414 : check e2411630103414 [[],[]] .smaller = true := by decide
def e2411630103418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2411630103418 : Closed e2411630103418 ∧ code e2411630103418 = 11207723125626 := by decide
theorem cert_e2411630103418 : check e2411630103418 [[],[]] .chain = true := by decide
def e2411630103470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411630103470 : Closed e2411630103470 ∧ code e2411630103470 = 11207723125678 := by decide
theorem cert_e2411630103470 : check e2411630103470 [[],[]] .smaller = true := by decide
def e2411630103482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411630103482 : Closed e2411630103482 ∧ code e2411630103482 = 11207723125690 := by decide
theorem cert_e2411630103482 : check e2411630103482 [[],[]] .smaller = true := by decide
def e2411630103510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411630103510 : Closed e2411630103510 ∧ code e2411630103510 = 11207723125718 := by decide
theorem cert_e2411630103510 : check e2411630103510 [[],[]] .smaller = true := by decide
def e2411630103514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411630103514 : Closed e2411630103514 ∧ code e2411630103514 = 11207723125722 := by decide
theorem cert_e2411630103514 : check e2411630103514 [[],[]] .smaller = true := by decide
def e2411630103530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2411630103530 : Closed e2411630103530 ∧ code e2411630103530 = 11207723125738 := by decide
theorem cert_e2411630103530 : check e2411630103530 [[],[]] .chain = true := by decide
def e2411630103774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630103774 : Closed e2411630103774 ∧ code e2411630103774 = 11207723125982 := by decide
theorem cert_e2411630103774 : check e2411630103774 [[],[]] .chain = true := by decide
def e2411630103790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411630103790 : Closed e2411630103790 ∧ code e2411630103790 = 11207723125998 := by decide
theorem cert_e2411630103790 : check e2411630103790 [[],[]] .smaller = true := by decide
def e2411630103798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411630103798 : Closed e2411630103798 ∧ code e2411630103798 = 11207723126006 := by decide
theorem cert_e2411630103798 : check e2411630103798 [[],[]] .smaller = true := by decide
def e2411630103802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630103802 : Closed e2411630103802 ∧ code e2411630103802 = 11207723126010 := by decide
theorem cert_e2411630103802 : check e2411630103802 [[],[]] .chain = true := by decide
def e2411630104126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2411630104126 : Closed e2411630104126 ∧ code e2411630104126 = 11207723126334 := by decide
theorem cert_e2411630104126 : check e2411630104126 [[],[]] .chain = true := by decide
def e2411630104174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630104174 : Closed e2411630104174 ∧ code e2411630104174 = 11207723126382 := by decide
theorem cert_e2411630104174 : check e2411630104174 [[],[]] .smaller = true := by decide
def e2411630104186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630104186 : Closed e2411630104186 ∧ code e2411630104186 = 11207723126394 := by decide
theorem cert_e2411630104186 : check e2411630104186 [[],[]] .smaller = true := by decide
def e2411630104374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630104374 : Closed e2411630104374 ∧ code e2411630104374 = 11207723126582 := by decide
theorem cert_e2411630104374 : check e2411630104374 [[],[]] .smaller = true := by decide
def e2411630104378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630104378 : Closed e2411630104378 ∧ code e2411630104378 = 11207723126586 := by decide
theorem cert_e2411630104378 : check e2411630104378 [[],[]] .smaller = true := by decide
def e2411630104462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2411630104462 : Closed e2411630104462 ∧ code e2411630104462 = 11207723126670 := by decide
theorem cert_e2411630104462 : check e2411630104462 [[],[]] .chain = true := by decide
def e2411630104474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630104474 : Closed e2411630104474 ∧ code e2411630104474 = 11207723126682 := by decide
theorem cert_e2411630104474 : check e2411630104474 [[],[]] .chain = true := by decide
def e2411630111854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411630111854 : Closed e2411630111854 ∧ code e2411630111854 = 11207723134062 := by decide
theorem cert_e2411630111854 : check e2411630111854 [[],[]] .chain = true := by decide
def e2411630111866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411630111866 : Closed e2411630111866 ∧ code e2411630111866 = 11207723134074 := by decide
theorem cert_e2411630111866 : check e2411630111866 [[],[]] .chain = true := by decide
def e2411630112030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411630112030 : Closed e2411630112030 ∧ code e2411630112030 = 11207723134238 := by decide
theorem cert_e2411630112030 : check e2411630112030 [[],[]] .chain = true := by decide
def e2411630112198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411630112198 : Closed e2411630112198 ∧ code e2411630112198 = 11207723134406 := by decide
theorem cert_e2411630112198 : check e2411630112198 [[],[]] .chain = true := by decide
def e2411630112302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411630112302 : Closed e2411630112302 ∧ code e2411630112302 = 11207723134510 := by decide
theorem cert_e2411630112302 : check e2411630112302 [[],[]] .chain = true := by decide
def e2411630112482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411630112482 : Closed e2411630112482 ∧ code e2411630112482 = 11207723134690 := by decide
theorem cert_e2411630112482 : check e2411630112482 [[],[]] .chain = true := by decide
def e2411630112494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2411630112494 : Closed e2411630112494 ∧ code e2411630112494 = 11207723134702 := by decide
theorem cert_e2411630112494 : check e2411630112494 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630112534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630112534 : Closed e2411630112534 ∧ code e2411630112534 = 11207723134742 := by decide
theorem cert_e2411630112534 : check e2411630112534 [[],[]] .chain = true := by decide
def e2411630112538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630112538 : Closed e2411630112538 ∧ code e2411630112538 = 11207723134746 := by decide
theorem cert_e2411630112538 : check e2411630112538 [[],[]] .chain = true := by decide
def e2411630112582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630112582 : Closed e2411630112582 ∧ code e2411630112582 = 11207723134790 := by decide
theorem cert_e2411630112582 : check e2411630112582 [[],[]] .chain = true := by decide
def e2411630112610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630112610 : Closed e2411630112610 ∧ code e2411630112610 = 11207723134818 := by decide
theorem cert_e2411630112610 : check e2411630112610 [[],[]] .chain = true := by decide
def e2411630112622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2411630112622 : Closed e2411630112622 ∧ code e2411630112622 = 11207723134830 := by decide
theorem cert_e2411630112622 : check e2411630112622 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630112630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2411630112630 : Closed e2411630112630 ∧ code e2411630112630 = 11207723134838 := by decide
theorem cert_e2411630112630 : check e2411630112630 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2411630112990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630112990 : Closed e2411630112990 ∧ code e2411630112990 = 11207723135198 := by decide
theorem cert_e2411630112990 : check e2411630112990 [[],[]] .chain = true := by decide
def e2411630113018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630113018 : Closed e2411630113018 ∧ code e2411630113018 = 11207723135226 := by decide
theorem cert_e2411630113018 : check e2411630113018 [[],[]] .chain = true := by decide
def e2411630113566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411630113566 : Closed e2411630113566 ∧ code e2411630113566 = 11207723135774 := by decide
theorem cert_e2411630113566 : check e2411630113566 [[],[]] .chain = true := by decide
def e2411630113734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411630113734 : Closed e2411630113734 ∧ code e2411630113734 = 11207723135942 := by decide
theorem cert_e2411630113734 : check e2411630113734 [[],[]] .chain = true := by decide
def e2411630114878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2411630114878 : Closed e2411630114878 ∧ code e2411630114878 = 11207723137086 := by decide
theorem cert_e2411630114878 : check e2411630114878 [[],[]] .chain = true := by decide
end Blc.Floor43
