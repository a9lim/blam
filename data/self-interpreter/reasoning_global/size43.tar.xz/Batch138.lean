import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2215599380206 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2215599380206 : Closed e2215599380206 ∧ code e2215599380206 = 11011692402414 := by decide
theorem cert_e2215599380206 : check e2215599380206 [[],[.under,.under]] .three = true := by decide
def e2215599380398 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2215599380398 : Closed e2215599380398 ∧ code e2215599380398 = 11011692402606 := by decide
theorem cert_e2215599380398 : check e2215599380398 [[],[.under,.under]] .three = true := by decide
def e2215599380410 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2215599380410 : Closed e2215599380410 ∧ code e2215599380410 = 11011692402618 := by decide
theorem cert_e2215599380410 : check e2215599380410 [[],[.under,.under]] .three = true := by decide
def e2215599380974 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2215599380974 : Closed e2215599380974 ∧ code e2215599380974 = 11011692403182 := by decide
theorem cert_e2215599380974 : check e2215599380974 [[],[.under,.under]] .three = true := by decide
def e2215599382126 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2215599382126 : Closed e2215599382126 ∧ code e2215599382126 = 11011692404334 := by decide
theorem cert_e2215599382126 : check e2215599382126 [[],[.under,.under]] .three = true := by decide
def e2215599382138 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2215599382138 : Closed e2215599382138 ∧ code e2215599382138 = 11011692404346 := by decide
theorem cert_e2215599382138 : check e2215599382138 [[],[.under,.under]] .three = true := by decide
def e2215599393646 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2215599393646 : Closed e2215599393646 ∧ code e2215599393646 = 11011692415854 := by decide
theorem cert_e2215599393646 : check e2215599393646 [[],[.under,.under]] .three = true := by decide
def e2215599393654 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2215599393654 : Closed e2215599393654 ∧ code e2215599393654 = 11011692415862 := by decide
theorem cert_e2215599393654 : check e2215599393654 [[],[.under,.under]] .three = true := by decide
def e2215599393710 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2215599393710 : Closed e2215599393710 ∧ code e2215599393710 = 11011692415918 := by decide
theorem cert_e2215599393710 : check e2215599393710 [[],[.under,.under]] .three = true := by decide
def e2215599393722 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2215599393722 : Closed e2215599393722 ∧ code e2215599393722 = 11011692415930 := by decide
theorem cert_e2215599393722 : check e2215599393722 [[],[.under,.under]] .three = true := by decide
def e2215599393750 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2215599393750 : Closed e2215599393750 ∧ code e2215599393750 = 11011692415958 := by decide
theorem cert_e2215599393750 : check e2215599393750 [[],[.under,.under]] .three = true := by decide
def e2215599393754 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2215599393754 : Closed e2215599393754 ∧ code e2215599393754 = 11011692415962 := by decide
theorem cert_e2215599393754 : check e2215599393754 [[],[.under,.under]] .three = true := by decide
def e2215599394030 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2215599394030 : Closed e2215599394030 ∧ code e2215599394030 = 11011692416238 := by decide
theorem cert_e2215599394030 : check e2215599394030 [[],[.under,.under]] .three = true := by decide
def e2215599394038 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2215599394038 : Closed e2215599394038 ∧ code e2215599394038 = 11011692416246 := by decide
theorem cert_e2215599394038 : check e2215599394038 [[],[.under,.under]] .three = true := by decide
def e2215599394414 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2215599394414 : Closed e2215599394414 ∧ code e2215599394414 = 11011692416622 := by decide
theorem cert_e2215599394414 : check e2215599394414 [[],[.under,.under]] .three = true := by decide
def e2215599394426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2215599394426 : Closed e2215599394426 ∧ code e2215599394426 = 11011692416634 := by decide
theorem cert_e2215599394426 : check e2215599394426 [[],[.under,.under]] .three = true := by decide
def e2215599394614 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2215599394614 : Closed e2215599394614 ∧ code e2215599394614 = 11011692416822 := by decide
theorem cert_e2215599394614 : check e2215599394614 [[],[.under,.under]] .three = true := by decide
def e2215599394618 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2215599394618 : Closed e2215599394618 ∧ code e2215599394618 = 11011692416826 := by decide
theorem cert_e2215599394618 : check e2215599394618 [[],[.under,.under]] .three = true := by decide
def e2215599934318 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2215599934318 : Closed e2215599934318 ∧ code e2215599934318 = 11011692956526 := by decide
theorem cert_e2215599934318 : check e2215599934318 [[],[.under,.under]] .smaller = true := by decide
def e2215599934326 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2215599934326 : Closed e2215599934326 ∧ code e2215599934326 = 11011692956534 := by decide
theorem cert_e2215599934326 : check e2215599934326 [[],[.under,.under]] .smaller = true := by decide
def e2215599934382 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2215599934382 : Closed e2215599934382 ∧ code e2215599934382 = 11011692956590 := by decide
theorem cert_e2215599934382 : check e2215599934382 [[],[.under,.under]] .smaller = true := by decide
def e2215599934394 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2215599934394 : Closed e2215599934394 ∧ code e2215599934394 = 11011692956602 := by decide
theorem cert_e2215599934394 : check e2215599934394 [[],[.under,.under]] .smaller = true := by decide
def e2215599934422 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2215599934422 : Closed e2215599934422 ∧ code e2215599934422 = 11011692956630 := by decide
theorem cert_e2215599934422 : check e2215599934422 [[],[.under,.under]] .smaller = true := by decide
def e2215599934426 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2215599934426 : Closed e2215599934426 ∧ code e2215599934426 = 11011692956634 := by decide
theorem cert_e2215599934426 : check e2215599934426 [[],[.under,.under]] .smaller = true := by decide
def e2215599934702 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2215599934702 : Closed e2215599934702 ∧ code e2215599934702 = 11011692956910 := by decide
theorem cert_e2215599934702 : check e2215599934702 [[],[.under,.under]] .smaller = true := by decide
def e2215599934710 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2215599934710 : Closed e2215599934710 ∧ code e2215599934710 = 11011692956918 := by decide
theorem cert_e2215599934710 : check e2215599934710 [[],[.under,.under]] .smaller = true := by decide
def e2215599935086 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2215599935086 : Closed e2215599935086 ∧ code e2215599935086 = 11011692957294 := by decide
theorem cert_e2215599935086 : check e2215599935086 [[],[.under,.under]] .smaller = true := by decide
def e2215599935098 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2215599935098 : Closed e2215599935098 ∧ code e2215599935098 = 11011692957306 := by decide
theorem cert_e2215599935098 : check e2215599935098 [[],[.under,.under]] .smaller = true := by decide
def e2215599935286 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2215599935286 : Closed e2215599935286 ∧ code e2215599935286 = 11011692957494 := by decide
theorem cert_e2215599935286 : check e2215599935286 [[],[.under,.under]] .smaller = true := by decide
def e2215599935290 : Term := (.app (.lam (.lam (.lam (.app (.var 2) (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2215599935290 : Closed e2215599935290 ∧ code e2215599935290 = 11011692957498 := by decide
theorem cert_e2215599935290 : check e2215599935290 [[],[.under,.under]] .smaller = true := by decide
def e2245242107418 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245242107418 : Closed e2245242107418 ∧ code e2245242107418 = 11041335129626 := by decide
theorem cert_e2245242107418 : check e2245242107418 [[]] .width = true := by decide
def e2245242238490 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245242238490 : Closed e2245242238490 ∧ code e2245242238490 = 11041335260698 := by decide
theorem cert_e2245242238490 : check e2245242238490 [[]] .width = true := by decide
def e2245243155994 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245243155994 : Closed e2245243155994 ∧ code e2245243155994 = 11041336178202 := by decide
theorem cert_e2245243155994 : check e2245243155994 [[]] .width = true := by decide
def e2245243352602 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245243352602 : Closed e2245243352602 ∧ code e2245243352602 = 11041336374810 := by decide
theorem cert_e2245243352602 : check e2245243352602 [[]] .width = true := by decide
def e2245243811354 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245243811354 : Closed e2245243811354 ∧ code e2245243811354 = 11041336833562 := by decide
theorem cert_e2245243811354 : check e2245243811354 [[]] .width = true := by decide
def e2245243876890 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245243876890 : Closed e2245243876890 ∧ code e2245243876890 = 11041336899098 := by decide
theorem cert_e2245243876890 : check e2245243876890 [[]] .width = true := by decide
def e2245248398874 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245248398874 : Closed e2245248398874 ∧ code e2245248398874 = 11041341421082 := by decide
theorem cert_e2245248398874 : check e2245248398874 [[]] .width = true := by decide
def e2245248529946 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245248529946 : Closed e2245248529946 ∧ code e2245248529946 = 11041341552154 := by decide
theorem cert_e2245248529946 : check e2245248529946 [[]] .width = true := by decide
def e2245254690330 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245254690330 : Closed e2245254690330 ∧ code e2245254690330 = 11041347712538 := by decide
theorem cert_e2245254690330 : check e2245254690330 [[]] .width = true := by decide
def e2245254886938 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245254886938 : Closed e2245254886938 ∧ code e2245254886938 = 11041347909146 := by decide
theorem cert_e2245254886938 : check e2245254886938 [[]] .width = true := by decide
def e2245257967130 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245257967130 : Closed e2245257967130 ∧ code e2245257967130 = 11041350989338 := by decide
theorem cert_e2245257967130 : check e2245257967130 [[]] .width = true := by decide
def e2245258032666 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245258032666 : Closed e2245258032666 ∧ code e2245258032666 = 11041351054874 := by decide
theorem cert_e2245258032666 : check e2245258032666 [[]] .width = true := by decide
def e2245602801178 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245602801178 : Closed e2245602801178 ∧ code e2245602801178 = 11041695823386 := by decide
theorem cert_e2245602801178 : check e2245602801178 [[]] .width = true := by decide
def e2245602817562 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245602817562 : Closed e2245602817562 ∧ code e2245602817562 = 11041695839770 := by decide
theorem cert_e2245602817562 : check e2245602817562 [[]] .width = true := by decide
def e2245602932250 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245602932250 : Closed e2245602932250 ∧ code e2245602932250 = 11041695954458 := by decide
theorem cert_e2245602932250 : check e2245602932250 [[]] .width = true := by decide
def e2245602956826 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245602956826 : Closed e2245602956826 ∧ code e2245602956826 = 11041695979034 := by decide
theorem cert_e2245602956826 : check e2245602956826 [[]] .width = true := by decide
def e2245603014170 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245603014170 : Closed e2245603014170 ∧ code e2245603014170 = 11041696036378 := by decide
theorem cert_e2245603014170 : check e2245603014170 [[]] .width = true := by decide
def e2245603022362 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245603022362 : Closed e2245603022362 ∧ code e2245603022362 = 11041696044570 := by decide
theorem cert_e2245603022362 : check e2245603022362 [[]] .width = true := by decide
def e2245603587610 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245603587610 : Closed e2245603587610 ∧ code e2245603587610 = 11041696609818 := by decide
theorem cert_e2245603587610 : check e2245603587610 [[]] .width = true := by decide
def e2245603603994 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245603603994 : Closed e2245603603994 ∧ code e2245603603994 = 11041696626202 := by decide
theorem cert_e2245603603994 : check e2245603603994 [[]] .width = true := by decide
def e2245604374042 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245604374042 : Closed e2245604374042 ∧ code e2245604374042 = 11041697396250 := by decide
theorem cert_e2245604374042 : check e2245604374042 [[]] .width = true := by decide
def e2245604398618 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245604398618 : Closed e2245604398618 ∧ code e2245604398618 = 11041697420826 := by decide
theorem cert_e2245604398618 : check e2245604398618 [[]] .width = true := by decide
def e2245604783642 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245604783642 : Closed e2245604783642 ∧ code e2245604783642 = 11041697805850 := by decide
theorem cert_e2245604783642 : check e2245604783642 [[]] .width = true := by decide
def e2245604791834 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245604791834 : Closed e2245604791834 ∧ code e2245604791834 = 11041697814042 := by decide
theorem cert_e2245604791834 : check e2245604791834 [[]] .width = true := by decide
def e2245647887898 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647887898 : Closed e2245647887898 ∧ code e2245647887898 = 11041740910106 := by decide
theorem cert_e2245647887898 : check e2245647887898 [[]] .width = true := by decide
def e2245647889946 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647889946 : Closed e2245647889946 ∧ code e2245647889946 = 11041740912154 := by decide
theorem cert_e2245647889946 : check e2245647889946 [[]] .width = true := by decide
def e2245647904282 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647904282 : Closed e2245647904282 ∧ code e2245647904282 = 11041740926490 := by decide
theorem cert_e2245647904282 : check e2245647904282 [[]] .width = true := by decide
def e2245647907354 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647907354 : Closed e2245647907354 ∧ code e2245647907354 = 11041740929562 := by decide
theorem cert_e2245647907354 : check e2245647907354 [[]] .width = true := by decide
def e2245647914522 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647914522 : Closed e2245647914522 ∧ code e2245647914522 = 11041740936730 := by decide
theorem cert_e2245647914522 : check e2245647914522 [[]] .width = true := by decide
def e2245647915546 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647915546 : Closed e2245647915546 ∧ code e2245647915546 = 11041740937754 := by decide
theorem cert_e2245647915546 : check e2245647915546 [[]] .width = true := by decide
def e2245647986202 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647986202 : Closed e2245647986202 ∧ code e2245647986202 = 11041741008410 := by decide
theorem cert_e2245647986202 : check e2245647986202 [[]] .width = true := by decide
def e2245647988250 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245647988250 : Closed e2245647988250 ∧ code e2245647988250 = 11041741010458 := by decide
theorem cert_e2245647988250 : check e2245647988250 [[]] .width = true := by decide
def e2245648084506 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245648084506 : Closed e2245648084506 ∧ code e2245648084506 = 11041741106714 := by decide
theorem cert_e2245648084506 : check e2245648084506 [[]] .width = true := by decide
def e2245648087578 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245648087578 : Closed e2245648087578 ∧ code e2245648087578 = 11041741109786 := by decide
theorem cert_e2245648087578 : check e2245648087578 [[]] .width = true := by decide
def e2245648135706 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245648135706 : Closed e2245648135706 ∧ code e2245648135706 = 11041741157914 := by decide
theorem cert_e2245648135706 : check e2245648135706 [[]] .width = true := by decide
def e2245648136730 : Term := (.app (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245648136730 : Closed e2245648136730 ∧ code e2245648136730 = 11041741158938 := by decide
theorem cert_e2245648136730 : check e2245648136730 [[]] .width = true := by decide
def e2245755000346 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755000346 : Closed e2245755000346 ∧ code e2245755000346 = 11041848022554 := by decide
theorem cert_e2245755000346 : check e2245755000346 [[]] .width = true := by decide
def e2245755001370 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755001370 : Closed e2245755001370 ∧ code e2245755001370 = 11041848023578 := by decide
theorem cert_e2245755001370 : check e2245755001370 [[]] .width = true := by decide
def e2245755065882 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755065882 : Closed e2245755065882 ∧ code e2245755065882 = 11041848088090 := by decide
private def t_e2245755065882 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245755065882 : ¬ IsSelfInterpreter e2245755065882 :=
  wSource (t := t_e2245755065882) (replay_sound (ps := []) (t := e2245755065882) (by decide)) (by decide)
def e2245755066906 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755066906 : Closed e2245755066906 ∧ code e2245755066906 = 11041848089114 := by decide
private def t_e2245755066906 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245755066906 : ¬ IsSelfInterpreter e2245755066906 :=
  wSource (t := t_e2245755066906) (replay_sound (ps := []) (t := e2245755066906) (by decide)) (by decide)
def e2245755524634 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755524634 : Closed e2245755524634 ∧ code e2245755524634 = 11041848546842 := by decide
theorem cert_e2245755524634 : check e2245755524634 [[]] .width = true := by decide
def e2245755525658 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755525658 : Closed e2245755525658 ∧ code e2245755525658 = 11041848547866 := by decide
theorem cert_e2245755525658 : check e2245755525658 [[]] .width = true := by decide
def e2245755622938 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755622938 : Closed e2245755622938 ∧ code e2245755622938 = 11041848645146 := by decide
theorem cert_e2245755622938 : check e2245755622938 [[]] .width = true := by decide
def e2245755623962 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755623962 : Closed e2245755623962 ∧ code e2245755623962 = 11041848646170 := by decide
theorem cert_e2245755623962 : check e2245755623962 [[]] .width = true := by decide
def e2245755852314 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755852314 : Closed e2245755852314 ∧ code e2245755852314 = 11041848874522 := by decide
private def t_e2245755852314 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245755852314 : ¬ IsSelfInterpreter e2245755852314 :=
  wSource (t := t_e2245755852314) (replay_sound (ps := []) (t := e2245755852314) (by decide)) (by decide)
def e2245755853338 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755853338 : Closed e2245755853338 ∧ code e2245755853338 = 11041848875546 := by decide
private def t_e2245755853338 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245755853338 : ¬ IsSelfInterpreter e2245755853338 :=
  wSource (t := t_e2245755853338) (replay_sound (ps := []) (t := e2245755853338) (by decide)) (by decide)
def e2245755885082 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755885082 : Closed e2245755885082 ∧ code e2245755885082 = 11041848907290 := by decide
theorem cert_e2245755885082 : check e2245755885082 [[]] .width = true := by decide
def e2245755886106 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245755886106 : Closed e2245755886106 ∧ code e2245755886106 = 11041848908314 := by decide
theorem cert_e2245755886106 : check e2245755886106 [[]] .width = true := by decide
def e2245758146074 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245758146074 : Closed e2245758146074 ∧ code e2245758146074 = 11041851168282 := by decide
theorem cert_e2245758146074 : check e2245758146074 [[]] .width = true := by decide
def e2245758147098 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245758147098 : Closed e2245758147098 ∧ code e2245758147098 = 11041851169306 := by decide
theorem cert_e2245758147098 : check e2245758147098 [[]] .width = true := by decide
def e2245758211610 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245758211610 : Closed e2245758211610 ∧ code e2245758211610 = 11041851233818 := by decide
theorem cert_e2245758211610 : check e2245758211610 [[]] .width = true := by decide
def e2245758212634 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245758212634 : Closed e2245758212634 ∧ code e2245758212634 = 11041851234842 := by decide
theorem cert_e2245758212634 : check e2245758212634 [[]] .width = true := by decide
def e2245761291802 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245761291802 : Closed e2245761291802 ∧ code e2245761291802 = 11041854314010 := by decide
theorem cert_e2245761291802 : check e2245761291802 [[]] .width = true := by decide
def e2245761292826 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245761292826 : Closed e2245761292826 ∧ code e2245761292826 = 11041854315034 := by decide
theorem cert_e2245761292826 : check e2245761292826 [[]] .width = true := by decide
def e2245761390106 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245761390106 : Closed e2245761390106 ∧ code e2245761390106 = 11041854412314 := by decide
theorem cert_e2245761390106 : check e2245761390106 [[]] .width = true := by decide
def e2245761391130 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245761391130 : Closed e2245761391130 ∧ code e2245761391130 = 11041854413338 := by decide
theorem cert_e2245761391130 : check e2245761391130 [[]] .width = true := by decide
def e2245762930202 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245762930202 : Closed e2245762930202 ∧ code e2245762930202 = 11041855952410 := by decide
theorem cert_e2245762930202 : check e2245762930202 [[]] .width = true := by decide
def e2245762931226 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245762931226 : Closed e2245762931226 ∧ code e2245762931226 = 11041855953434 := by decide
theorem cert_e2245762931226 : check e2245762931226 [[]] .width = true := by decide
def e2245762962970 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245762962970 : Closed e2245762962970 ∧ code e2245762962970 = 11041855985178 := by decide
theorem cert_e2245762962970 : check e2245762962970 [[]] .width = true := by decide
def e2245762963994 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245762963994 : Closed e2245762963994 ∧ code e2245762963994 = 11041855986202 := by decide
theorem cert_e2245762963994 : check e2245762963994 [[]] .width = true := by decide
def e2245871236634 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245871236634 : Closed e2245871236634 ∧ code e2245871236634 = 11041964258842 := by decide
theorem cert_e2245871236634 : check e2245871236634 [[]] .width = true := by decide
def e2245871253018 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245871253018 : Closed e2245871253018 ∧ code e2245871253018 = 11041964275226 := by decide
theorem cert_e2245871253018 : check e2245871253018 [[]] .width = true := by decide
def e2245871367706 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245871367706 : Closed e2245871367706 ∧ code e2245871367706 = 11041964389914 := by decide
theorem cert_e2245871367706 : check e2245871367706 [[]] .width = true := by decide
def e2245871392282 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245871392282 : Closed e2245871392282 ∧ code e2245871392282 = 11041964414490 := by decide
theorem cert_e2245871392282 : check e2245871392282 [[]] .width = true := by decide
def e2245871449626 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245871449626 : Closed e2245871449626 ∧ code e2245871449626 = 11041964471834 := by decide
theorem cert_e2245871449626 : check e2245871449626 [[]] .width = true := by decide
def e2245871457818 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245871457818 : Closed e2245871457818 ∧ code e2245871457818 = 11041964480026 := by decide
theorem cert_e2245871457818 : check e2245871457818 [[]] .width = true := by decide
def e2245872023066 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245872023066 : Closed e2245872023066 ∧ code e2245872023066 = 11041965045274 := by decide
theorem cert_e2245872023066 : check e2245872023066 [[]] .width = true := by decide
def e2245872039450 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245872039450 : Closed e2245872039450 ∧ code e2245872039450 = 11041965061658 := by decide
theorem cert_e2245872039450 : check e2245872039450 [[]] .width = true := by decide
def e2245872809498 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245872809498 : Closed e2245872809498 ∧ code e2245872809498 = 11041965831706 := by decide
theorem cert_e2245872809498 : check e2245872809498 [[]] .width = true := by decide
def e2245872834074 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245872834074 : Closed e2245872834074 ∧ code e2245872834074 = 11041965856282 := by decide
theorem cert_e2245872834074 : check e2245872834074 [[]] .width = true := by decide
def e2245873219098 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245873219098 : Closed e2245873219098 ∧ code e2245873219098 = 11041966241306 := by decide
theorem cert_e2245873219098 : check e2245873219098 [[]] .width = true := by decide
def e2245873227290 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245873227290 : Closed e2245873227290 ∧ code e2245873227290 = 11041966249498 := by decide
theorem cert_e2245873227290 : check e2245873227290 [[]] .width = true := by decide
def e2245916323354 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916323354 : Closed e2245916323354 ∧ code e2245916323354 = 11042009345562 := by decide
theorem cert_e2245916323354 : check e2245916323354 [[]] .width = true := by decide
def e2245916325402 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916325402 : Closed e2245916325402 ∧ code e2245916325402 = 11042009347610 := by decide
theorem cert_e2245916325402 : check e2245916325402 [[]] .width = true := by decide
def e2245916339738 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916339738 : Closed e2245916339738 ∧ code e2245916339738 = 11042009361946 := by decide
theorem cert_e2245916339738 : check e2245916339738 [[]] .width = true := by decide
def e2245916342810 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916342810 : Closed e2245916342810 ∧ code e2245916342810 = 11042009365018 := by decide
theorem cert_e2245916342810 : check e2245916342810 [[]] .width = true := by decide
def e2245916349978 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916349978 : Closed e2245916349978 ∧ code e2245916349978 = 11042009372186 := by decide
theorem cert_e2245916349978 : check e2245916349978 [[]] .width = true := by decide
def e2245916351002 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916351002 : Closed e2245916351002 ∧ code e2245916351002 = 11042009373210 := by decide
theorem cert_e2245916351002 : check e2245916351002 [[]] .width = true := by decide
def e2245916421658 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916421658 : Closed e2245916421658 ∧ code e2245916421658 = 11042009443866 := by decide
theorem cert_e2245916421658 : check e2245916421658 [[]] .width = true := by decide
def e2245916423706 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916423706 : Closed e2245916423706 ∧ code e2245916423706 = 11042009445914 := by decide
theorem cert_e2245916423706 : check e2245916423706 [[]] .width = true := by decide
def e2245916519962 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916519962 : Closed e2245916519962 ∧ code e2245916519962 = 11042009542170 := by decide
theorem cert_e2245916519962 : check e2245916519962 [[]] .width = true := by decide
def e2245916523034 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916523034 : Closed e2245916523034 ∧ code e2245916523034 = 11042009545242 := by decide
theorem cert_e2245916523034 : check e2245916523034 [[]] .width = true := by decide
def e2245916571162 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916571162 : Closed e2245916571162 ∧ code e2245916571162 = 11042009593370 := by decide
theorem cert_e2245916571162 : check e2245916571162 [[]] .width = true := by decide
def e2245916572186 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245916572186 : Closed e2245916572186 ∧ code e2245916572186 = 11042009594394 := by decide
theorem cert_e2245916572186 : check e2245916572186 [[]] .width = true := by decide
def e2245935348250 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935348250 : Closed e2245935348250 ∧ code e2245935348250 = 11042028370458 := by decide
private def t_e2245935348250 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935348250 : ¬ IsSelfInterpreter e2245935348250 :=
  wSource (t := t_e2245935348250) (replay_sound (ps := []) (t := e2245935348250) (by decide)) (by decide)
def e2245935356442 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935356442 : Closed e2245935356442 ∧ code e2245935356442 = 11042028378650 := by decide
private def t_e2245935356442 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935356442 : ¬ IsSelfInterpreter e2245935356442 :=
  wSource (t := t_e2245935356442) (replay_sound (ps := []) (t := e2245935356442) (by decide)) (by decide)
def e2245935413786 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935413786 : Closed e2245935413786 ∧ code e2245935413786 = 11042028435994 := by decide
private def t_e2245935413786 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935413786 : ¬ IsSelfInterpreter e2245935413786 :=
  wSource (t := t_e2245935413786) (replay_sound (ps := []) (t := e2245935413786) (by decide)) (by decide)
def e2245935426074 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935426074 : Closed e2245935426074 ∧ code e2245935426074 = 11042028448282 := by decide
private def t_e2245935426074 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935426074 : ¬ IsSelfInterpreter e2245935426074 :=
  wSource (t := t_e2245935426074) (replay_sound (ps := []) (t := e2245935426074) (by decide)) (by decide)
def e2245935454746 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935454746 : Closed e2245935454746 ∧ code e2245935454746 = 11042028476954 := by decide
private def t_e2245935454746 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935454746 : ¬ IsSelfInterpreter e2245935454746 :=
  wSource (t := t_e2245935454746) (replay_sound (ps := []) (t := e2245935454746) (by decide)) (by decide)
def e2245935458842 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935458842 : Closed e2245935458842 ∧ code e2245935458842 = 11042028481050 := by decide
private def t_e2245935458842 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935458842 : ¬ IsSelfInterpreter e2245935458842 :=
  wSource (t := t_e2245935458842) (replay_sound (ps := []) (t := e2245935458842) (by decide)) (by decide)
def e2245935741466 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935741466 : Closed e2245935741466 ∧ code e2245935741466 = 11042028763674 := by decide
private def t_e2245935741466 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935741466 : ¬ IsSelfInterpreter e2245935741466 :=
  wSource (t := t_e2245935741466) (replay_sound (ps := []) (t := e2245935741466) (by decide)) (by decide)
def e2245935749658 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245935749658 : Closed e2245935749658 ∧ code e2245935749658 = 11042028771866 := by decide
private def t_e2245935749658 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245935749658 : ¬ IsSelfInterpreter e2245935749658 :=
  wSource (t := t_e2245935749658) (replay_sound (ps := []) (t := e2245935749658) (by decide)) (by decide)
def e2245936134682 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245936134682 : Closed e2245936134682 ∧ code e2245936134682 = 11042029156890 := by decide
private def t_e2245936134682 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245936134682 : ¬ IsSelfInterpreter e2245936134682 :=
  wSource (t := t_e2245936134682) (replay_sound (ps := []) (t := e2245936134682) (by decide)) (by decide)
def e2245936146970 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245936146970 : Closed e2245936146970 ∧ code e2245936146970 = 11042029169178 := by decide
private def t_e2245936146970 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245936146970 : ¬ IsSelfInterpreter e2245936146970 :=
  wSource (t := t_e2245936146970) (replay_sound (ps := []) (t := e2245936146970) (by decide)) (by decide)
def e2245936339482 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245936339482 : Closed e2245936339482 ∧ code e2245936339482 = 11042029361690 := by decide
private def t_e2245936339482 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245936339482 : ¬ IsSelfInterpreter e2245936339482 :=
  wSource (t := t_e2245936339482) (replay_sound (ps := []) (t := e2245936339482) (by decide)) (by decide)
def e2245936343578 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245936343578 : Closed e2245936343578 ∧ code e2245936343578 = 11042029365786 := by decide
private def t_e2245936343578 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245936343578 : ¬ IsSelfInterpreter e2245936343578 :=
  wSource (t := t_e2245936343578) (replay_sound (ps := []) (t := e2245936343578) (by decide)) (by decide)
def e2245949877786 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949877786 : Closed e2245949877786 ∧ code e2245949877786 = 11042042899994 := by decide
private def t_e2245949877786 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949877786 : ¬ IsSelfInterpreter e2245949877786 :=
  wSource (t := t_e2245949877786) (replay_sound (ps := []) (t := e2245949877786) (by decide)) (by decide)
def e2245949879834 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949879834 : Closed e2245949879834 ∧ code e2245949879834 = 11042042902042 := by decide
private def t_e2245949879834 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949879834 : ¬ IsSelfInterpreter e2245949879834 :=
  wSource (t := t_e2245949879834) (replay_sound (ps := []) (t := e2245949879834) (by decide)) (by decide)
def e2245949894170 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949894170 : Closed e2245949894170 ∧ code e2245949894170 = 11042042916378 := by decide
private def t_e2245949894170 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949894170 : ¬ IsSelfInterpreter e2245949894170 :=
  wSource (t := t_e2245949894170) (replay_sound (ps := []) (t := e2245949894170) (by decide)) (by decide)
def e2245949897242 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949897242 : Closed e2245949897242 ∧ code e2245949897242 = 11042042919450 := by decide
private def t_e2245949897242 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949897242 : ¬ IsSelfInterpreter e2245949897242 :=
  wSource (t := t_e2245949897242) (replay_sound (ps := []) (t := e2245949897242) (by decide)) (by decide)
def e2245949904410 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949904410 : Closed e2245949904410 ∧ code e2245949904410 = 11042042926618 := by decide
private def t_e2245949904410 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949904410 : ¬ IsSelfInterpreter e2245949904410 :=
  wSource (t := t_e2245949904410) (replay_sound (ps := []) (t := e2245949904410) (by decide)) (by decide)
def e2245949905434 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949905434 : Closed e2245949905434 ∧ code e2245949905434 = 11042042927642 := by decide
private def t_e2245949905434 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949905434 : ¬ IsSelfInterpreter e2245949905434 :=
  wSource (t := t_e2245949905434) (replay_sound (ps := []) (t := e2245949905434) (by decide)) (by decide)
def e2245949976090 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949976090 : Closed e2245949976090 ∧ code e2245949976090 = 11042042998298 := by decide
private def t_e2245949976090 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949976090 : ¬ IsSelfInterpreter e2245949976090 :=
  wSource (t := t_e2245949976090) (replay_sound (ps := []) (t := e2245949976090) (by decide)) (by decide)
def e2245949978138 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245949978138 : Closed e2245949978138 ∧ code e2245949978138 = 11042043000346 := by decide
private def t_e2245949978138 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245949978138 : ¬ IsSelfInterpreter e2245949978138 :=
  wSource (t := t_e2245949978138) (replay_sound (ps := []) (t := e2245949978138) (by decide)) (by decide)
def e2245950074394 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245950074394 : Closed e2245950074394 ∧ code e2245950074394 = 11042043096602 := by decide
private def t_e2245950074394 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245950074394 : ¬ IsSelfInterpreter e2245950074394 :=
  wSource (t := t_e2245950074394) (replay_sound (ps := []) (t := e2245950074394) (by decide)) (by decide)
def e2245950077466 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245950077466 : Closed e2245950077466 ∧ code e2245950077466 = 11042043099674 := by decide
private def t_e2245950077466 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245950077466 : ¬ IsSelfInterpreter e2245950077466 :=
  wSource (t := t_e2245950077466) (replay_sound (ps := []) (t := e2245950077466) (by decide)) (by decide)
def e2245950125594 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245950125594 : Closed e2245950125594 ∧ code e2245950125594 = 11042043147802 := by decide
private def t_e2245950125594 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245950125594 : ¬ IsSelfInterpreter e2245950125594 :=
  wSource (t := t_e2245950125594) (replay_sound (ps := []) (t := e2245950125594) (by decide)) (by decide)
def e2245950126618 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2245950126618 : Closed e2245950126618 ∧ code e2245950126618 = 11042043148826 := by decide
private def t_e2245950126618 : Term := (.app (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2245950126618 : ¬ IsSelfInterpreter e2245950126618 :=
  wSource (t := t_e2245950126618) (replay_sound (ps := []) (t := e2245950126618) (by decide)) (by decide)
def e2246459684378 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246459684378 : Closed e2246459684378 ∧ code e2246459684378 = 11042552706586 := by decide
theorem cert_e2246459684378 : check e2246459684378 [[]] .width = true := by decide
def e2246459703494 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246459703494 : Closed e2246459703494 ∧ code e2246459703494 = 11042552725702 := by decide
theorem cert_e2246459703494 : check e2246459703494 [[]] .width = true := by decide
def e2246460208666 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246460208666 : Closed e2246460208666 ∧ code e2246460208666 = 11042553230874 := by decide
theorem cert_e2246460208666 : check e2246460208666 [[]] .width = true := by decide
def e2246460227782 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246460227782 : Closed e2246460227782 ∧ code e2246460227782 = 11042553249990 := by decide
theorem cert_e2246460227782 : check e2246460227782 [[]] .width = true := by decide
def e2246463878682 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246463878682 : Closed e2246463878682 ∧ code e2246463878682 = 11042556900890 := by decide
theorem cert_e2246463878682 : check e2246463878682 [[]] .width = true := by decide
def e2246463897798 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246463897798 : Closed e2246463897798 ∧ code e2246463897798 = 11042556920006 := by decide
theorem cert_e2246463897798 : check e2246463897798 [[]] .width = true := by decide
def e2246464665114 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246464665114 : Closed e2246464665114 ∧ code e2246464665114 = 11042557687322 := by decide
theorem cert_e2246464665114 : check e2246464665114 [[]] .width = true := by decide
def e2246464684230 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246464684230 : Closed e2246464684230 ∧ code e2246464684230 = 11042557706438 := by decide
theorem cert_e2246464684230 : check e2246464684230 [[]] .width = true := by decide
def e2246466500122 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246466500122 : Closed e2246466500122 ∧ code e2246466500122 = 11042559522330 := by decide
theorem cert_e2246466500122 : check e2246466500122 [[]] .width = true := by decide
def e2246466519238 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246466519238 : Closed e2246466519238 ∧ code e2246466519238 = 11042559541446 := by decide
theorem cert_e2246466519238 : check e2246466519238 [[]] .width = true := by decide
def e2246466762266 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246466762266 : Closed e2246466762266 ∧ code e2246466762266 = 11042559784474 := by decide
theorem cert_e2246466762266 : check e2246466762266 [[]] .width = true := by decide
def e2246466781382 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246466781382 : Closed e2246466781382 ∧ code e2246466781382 = 11042559803590 := by decide
theorem cert_e2246466781382 : check e2246466781382 [[]] .width = true := by decide
def e2246484850202 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246484850202 : Closed e2246484850202 ∧ code e2246484850202 = 11042577872410 := by decide
theorem cert_e2246484850202 : check e2246484850202 [[]] .width = true := by decide
def e2246484869318 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246484869318 : Closed e2246484869318 ∧ code e2246484869318 = 11042577891526 := by decide
theorem cert_e2246484869318 : check e2246484869318 [[]] .width = true := by decide
def e2246485374490 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246485374490 : Closed e2246485374490 ∧ code e2246485374490 = 11042578396698 := by decide
theorem cert_e2246485374490 : check e2246485374490 [[]] .width = true := by decide
def e2246485393606 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246485393606 : Closed e2246485393606 ∧ code e2246485393606 = 11042578415814 := by decide
theorem cert_e2246485393606 : check e2246485393606 [[]] .width = true := by decide
def e2246510016026 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246510016026 : Closed e2246510016026 ∧ code e2246510016026 = 11042603038234 := by decide
theorem cert_e2246510016026 : check e2246510016026 [[]] .width = true := by decide
def e2246510035142 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246510035142 : Closed e2246510035142 ∧ code e2246510035142 = 11042603057350 := by decide
theorem cert_e2246510035142 : check e2246510035142 [[]] .width = true := by decide
def e2246510802458 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246510802458 : Closed e2246510802458 ∧ code e2246510802458 = 11042603824666 := by decide
theorem cert_e2246510802458 : check e2246510802458 [[]] .width = true := by decide
def e2246510821574 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246510821574 : Closed e2246510821574 ∧ code e2246510821574 = 11042603843782 := by decide
theorem cert_e2246510821574 : check e2246510821574 [[]] .width = true := by decide
def e2246523123226 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.app (.var 1) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2246523123226 : Closed e2246523123226 ∧ code e2246523123226 = 11042616145434 := by decide
theorem cert_e2246523123226 : check e2246523123226 [[]] .width = true := by decide
def e2246523142342 : Term := (.app (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2246523142342 : Closed e2246523142342 ∧ code e2246523142342 = 11042616164550 := by decide
theorem cert_e2246523142342 : check e2246523142342 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2245755065882
#print axioms Blc.Floor43.cert_e2245755066906
#print axioms Blc.Floor43.cert_e2245755852314
#print axioms Blc.Floor43.cert_e2245755853338
#print axioms Blc.Floor43.cert_e2245935348250
#print axioms Blc.Floor43.cert_e2245935356442
#print axioms Blc.Floor43.cert_e2245935413786
#print axioms Blc.Floor43.cert_e2245935426074
#print axioms Blc.Floor43.cert_e2245935454746
#print axioms Blc.Floor43.cert_e2245935458842
#print axioms Blc.Floor43.cert_e2245935741466
#print axioms Blc.Floor43.cert_e2245935749658
#print axioms Blc.Floor43.cert_e2245936134682
#print axioms Blc.Floor43.cert_e2245936146970
#print axioms Blc.Floor43.cert_e2245936339482
#print axioms Blc.Floor43.cert_e2245936343578
#print axioms Blc.Floor43.cert_e2245949877786
#print axioms Blc.Floor43.cert_e2245949879834
#print axioms Blc.Floor43.cert_e2245949894170
#print axioms Blc.Floor43.cert_e2245949897242
#print axioms Blc.Floor43.cert_e2245949904410
#print axioms Blc.Floor43.cert_e2245949905434
#print axioms Blc.Floor43.cert_e2245949976090
#print axioms Blc.Floor43.cert_e2245949978138
#print axioms Blc.Floor43.cert_e2245950074394
#print axioms Blc.Floor43.cert_e2245950077466
#print axioms Blc.Floor43.cert_e2245950125594
#print axioms Blc.Floor43.cert_e2245950126618
