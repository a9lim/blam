import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e604836204142 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604836204142 : Closed e604836204142 ∧ code e604836204142 = 9400929226350 := by decide
theorem cert_e604836204142 : check e604836204142 [[.under]] .sourceHead = true := by decide
def e604836204154 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604836204154 : Closed e604836204154 ∧ code e604836204154 = 9400929226362 := by decide
theorem cert_e604836204154 : check e604836204154 [[.under]] .sourceHead = true := by decide
def e604836204342 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604836204342 : Closed e604836204342 ∧ code e604836204342 = 9400929226550 := by decide
theorem cert_e604836204342 : check e604836204342 [[.under]] .sourceHead = true := by decide
def e604836204346 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604836204346 : Closed e604836204346 ∧ code e604836204346 = 9400929226554 := by decide
theorem cert_e604836204346 : check e604836204346 [[.under]] .sourceHead = true := by decide
def e604919388894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e604919388894 : Closed e604919388894 ∧ code e604919388894 = 9401012411102 := by decide
theorem cert_e604919388894 : check e604919388894 [[.under],[.under]] .three = true := by decide
def e604919388918 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e604919388918 : Closed e604919388918 ∧ code e604919388918 = 9401012411126 := by decide
theorem cert_e604919388918 : check e604919388918 [[.under],[.under]] .three = true := by decide
def e604919389022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e604919389022 : Closed e604919389022 ∧ code e604919389022 = 9401012411230 := by decide
theorem cert_e604919389022 : check e604919389022 [[.under],[.under]] .three = true := by decide
def e604919389038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e604919389038 : Closed e604919389038 ∧ code e604919389038 = 9401012411246 := by decide
theorem cert_e604919389038 : check e604919389038 [[.under],[.under]] .smaller = true := by decide
def e604919389046 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e604919389046 : Closed e604919389046 ∧ code e604919389046 = 9401012411254 := by decide
theorem cert_e604919389046 : check e604919389046 [[.under],[.under]] .smaller = true := by decide
def e604919389050 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e604919389050 : Closed e604919389050 ∧ code e604919389050 = 9401012411258 := by decide
theorem cert_e604919389050 : check e604919389050 [[.under],[.under]] .three = true := by decide
def e604919389110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e604919389110 : Closed e604919389110 ∧ code e604919389110 = 9401012411318 := by decide
theorem cert_e604919389110 : check e604919389110 [[.under],[.under]] .smaller = true := by decide
def e604919389142 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e604919389142 : Closed e604919389142 ∧ code e604919389142 = 9401012411350 := by decide
theorem cert_e604919389142 : check e604919389142 [[.under],[.under]] .three = true := by decide
def e604919389146 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e604919389146 : Closed e604919389146 ∧ code e604919389146 = 9401012411354 := by decide
theorem cert_e604919389146 : check e604919389146 [[.under],[.under]] .three = true := by decide
def e604919389534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e604919389534 : Closed e604919389534 ∧ code e604919389534 = 9401012411742 := by decide
theorem cert_e604919389534 : check e604919389534 [[.under],[.under]] .three = true := by decide
def e604919389550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e604919389550 : Closed e604919389550 ∧ code e604919389550 = 9401012411758 := by decide
theorem cert_e604919389550 : check e604919389550 [[.under],[.under]] .smaller = true := by decide
def e604919389558 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e604919389558 : Closed e604919389558 ∧ code e604919389558 = 9401012411766 := by decide
theorem cert_e604919389558 : check e604919389558 [[.under],[.under]] .smaller = true := by decide
def e604919389562 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e604919389562 : Closed e604919389562 ∧ code e604919389562 = 9401012411770 := by decide
theorem cert_e604919389562 : check e604919389562 [[.under],[.under]] .three = true := by decide
def e604919389614 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e604919389614 : Closed e604919389614 ∧ code e604919389614 = 9401012411822 := by decide
theorem cert_e604919389614 : check e604919389614 [[.under],[.under]] .smaller = true := by decide
def e604919389626 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e604919389626 : Closed e604919389626 ∧ code e604919389626 = 9401012411834 := by decide
theorem cert_e604919389626 : check e604919389626 [[.under],[.under]] .smaller = true := by decide
def e604919389654 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e604919389654 : Closed e604919389654 ∧ code e604919389654 = 9401012411862 := by decide
theorem cert_e604919389654 : check e604919389654 [[.under],[.under]] .smaller = true := by decide
def e604919389658 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e604919389658 : Closed e604919389658 ∧ code e604919389658 = 9401012411866 := by decide
theorem cert_e604919389658 : check e604919389658 [[.under],[.under]] .smaller = true := by decide
def e604919389674 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e604919389674 : Closed e604919389674 ∧ code e604919389674 = 9401012411882 := by decide
theorem cert_e604919389674 : check e604919389674 [[.under],[.under]] .three = true := by decide
def e604919389878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e604919389878 : Closed e604919389878 ∧ code e604919389878 = 9401012412086 := by decide
theorem cert_e604919389878 : check e604919389878 [[.under],[.under]] .smaller = true := by decide
def e604919389910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e604919389910 : Closed e604919389910 ∧ code e604919389910 = 9401012412118 := by decide
theorem cert_e604919389910 : check e604919389910 [[.under],[.under]] .smaller = true := by decide
def e604919389914 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e604919389914 : Closed e604919389914 ∧ code e604919389914 = 9401012412122 := by decide
theorem cert_e604919389914 : check e604919389914 [[.under],[.under]] .smaller = true := by decide
def e604919390038 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e604919390038 : Closed e604919390038 ∧ code e604919390038 = 9401012412246 := by decide
theorem cert_e604919390038 : check e604919390038 [[.under],[.under]] .three = true := by decide
def e604919390042 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e604919390042 : Closed e604919390042 ∧ code e604919390042 = 9401012412250 := by decide
theorem cert_e604919390042 : check e604919390042 [[.under],[.under]] .three = true := by decide
def e604919390058 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e604919390058 : Closed e604919390058 ∧ code e604919390058 = 9401012412266 := by decide
theorem cert_e604919390058 : check e604919390058 [[.under],[.under]] .three = true := by decide
def e604919391966 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e604919391966 : Closed e604919391966 ∧ code e604919391966 = 9401012414174 := by decide
theorem cert_e604919391966 : check e604919391966 [[.under],[.under]] .three = true := by decide
def e604919391990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e604919391990 : Closed e604919391990 ∧ code e604919391990 = 9401012414198 := by decide
theorem cert_e604919391990 : check e604919391990 [[.under],[.under]] .three = true := by decide
def e604919392094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e604919392094 : Closed e604919392094 ∧ code e604919392094 = 9401012414302 := by decide
theorem cert_e604919392094 : check e604919392094 [[.under],[.under]] .three = true := by decide
def e604919392110 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e604919392110 : Closed e604919392110 ∧ code e604919392110 = 9401012414318 := by decide
theorem cert_e604919392110 : check e604919392110 [[.under],[.under]] .smaller = true := by decide
def e604919392118 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e604919392118 : Closed e604919392118 ∧ code e604919392118 = 9401012414326 := by decide
theorem cert_e604919392118 : check e604919392118 [[.under],[.under]] .smaller = true := by decide
def e604919392122 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e604919392122 : Closed e604919392122 ∧ code e604919392122 = 9401012414330 := by decide
theorem cert_e604919392122 : check e604919392122 [[.under],[.under]] .three = true := by decide
def e604919392182 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e604919392182 : Closed e604919392182 ∧ code e604919392182 = 9401012414390 := by decide
theorem cert_e604919392182 : check e604919392182 [[.under],[.under]] .smaller = true := by decide
def e604919392214 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e604919392214 : Closed e604919392214 ∧ code e604919392214 = 9401012414422 := by decide
theorem cert_e604919392214 : check e604919392214 [[.under],[.under]] .three = true := by decide
def e604919392218 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e604919392218 : Closed e604919392218 ∧ code e604919392218 = 9401012414426 := by decide
theorem cert_e604919392218 : check e604919392218 [[.under],[.under]] .three = true := by decide
def e604919392734 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e604919392734 : Closed e604919392734 ∧ code e604919392734 = 9401012414942 := by decide
theorem cert_e604919392734 : check e604919392734 [[.under],[.under]] .three = true := by decide
def e604919392758 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e604919392758 : Closed e604919392758 ∧ code e604919392758 = 9401012414966 := by decide
theorem cert_e604919392758 : check e604919392758 [[.under],[.under]] .three = true := by decide
def e604919393502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e604919393502 : Closed e604919393502 ∧ code e604919393502 = 9401012415710 := by decide
theorem cert_e604919393502 : check e604919393502 [[.under],[.under]] .three = true := by decide
def e604919393518 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e604919393518 : Closed e604919393518 ∧ code e604919393518 = 9401012415726 := by decide
theorem cert_e604919393518 : check e604919393518 [[.under],[.under]] .smaller = true := by decide
def e604919393526 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e604919393526 : Closed e604919393526 ∧ code e604919393526 = 9401012415734 := by decide
theorem cert_e604919393526 : check e604919393526 [[.under],[.under]] .smaller = true := by decide
def e604919393530 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e604919393530 : Closed e604919393530 ∧ code e604919393530 = 9401012415738 := by decide
theorem cert_e604919393530 : check e604919393530 [[.under],[.under]] .three = true := by decide
def e604919393910 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e604919393910 : Closed e604919393910 ∧ code e604919393910 = 9401012416118 := by decide
theorem cert_e604919393910 : check e604919393910 [[.under],[.under]] .smaller = true := by decide
def e604919394102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604919394102 : Closed e604919394102 ∧ code e604919394102 = 9401012416310 := by decide
theorem cert_e604919394102 : check e604919394102 [[.under],[.under]] .three = true := by decide
def e604919394106 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604919394106 : Closed e604919394106 ∧ code e604919394106 = 9401012416314 := by decide
theorem cert_e604919394106 : check e604919394106 [[.under],[.under]] .three = true := by decide
def e604919395166 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e604919395166 : Closed e604919395166 ∧ code e604919395166 = 9401012417374 := by decide
theorem cert_e604919395166 : check e604919395166 [[.under],[.under]] .three = true := by decide
def e604919395182 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e604919395182 : Closed e604919395182 ∧ code e604919395182 = 9401012417390 := by decide
theorem cert_e604919395182 : check e604919395182 [[.under],[.under]] .smaller = true := by decide
def e604919395190 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e604919395190 : Closed e604919395190 ∧ code e604919395190 = 9401012417398 := by decide
theorem cert_e604919395190 : check e604919395190 [[.under],[.under]] .smaller = true := by decide
def e604919395194 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e604919395194 : Closed e604919395194 ∧ code e604919395194 = 9401012417402 := by decide
theorem cert_e604919395194 : check e604919395194 [[.under],[.under]] .three = true := by decide
def e604919395246 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e604919395246 : Closed e604919395246 ∧ code e604919395246 = 9401012417454 := by decide
theorem cert_e604919395246 : check e604919395246 [[.under],[.under]] .smaller = true := by decide
def e604919395258 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e604919395258 : Closed e604919395258 ∧ code e604919395258 = 9401012417466 := by decide
theorem cert_e604919395258 : check e604919395258 [[.under],[.under]] .smaller = true := by decide
def e604919395286 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e604919395286 : Closed e604919395286 ∧ code e604919395286 = 9401012417494 := by decide
theorem cert_e604919395286 : check e604919395286 [[.under],[.under]] .smaller = true := by decide
def e604919395290 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e604919395290 : Closed e604919395290 ∧ code e604919395290 = 9401012417498 := by decide
theorem cert_e604919395290 : check e604919395290 [[.under],[.under]] .smaller = true := by decide
def e604919395306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e604919395306 : Closed e604919395306 ∧ code e604919395306 = 9401012417514 := by decide
theorem cert_e604919395306 : check e604919395306 [[.under],[.under]] .three = true := by decide
def e604919395550 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e604919395550 : Closed e604919395550 ∧ code e604919395550 = 9401012417758 := by decide
theorem cert_e604919395550 : check e604919395550 [[.under],[.under]] .three = true := by decide
def e604919395566 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e604919395566 : Closed e604919395566 ∧ code e604919395566 = 9401012417774 := by decide
theorem cert_e604919395566 : check e604919395566 [[.under],[.under]] .smaller = true := by decide
def e604919395574 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e604919395574 : Closed e604919395574 ∧ code e604919395574 = 9401012417782 := by decide
theorem cert_e604919395574 : check e604919395574 [[.under],[.under]] .smaller = true := by decide
def e604919395578 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e604919395578 : Closed e604919395578 ∧ code e604919395578 = 9401012417786 := by decide
theorem cert_e604919395578 : check e604919395578 [[.under],[.under]] .three = true := by decide
def e604919395950 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e604919395950 : Closed e604919395950 ∧ code e604919395950 = 9401012418158 := by decide
theorem cert_e604919395950 : check e604919395950 [[.under],[.under]] .smaller = true := by decide
def e604919395962 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e604919395962 : Closed e604919395962 ∧ code e604919395962 = 9401012418170 := by decide
theorem cert_e604919395962 : check e604919395962 [[.under],[.under]] .smaller = true := by decide
def e604919396150 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604919396150 : Closed e604919396150 ∧ code e604919396150 = 9401012418358 := by decide
theorem cert_e604919396150 : check e604919396150 [[.under],[.under]] .smaller = true := by decide
def e604919396154 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604919396154 : Closed e604919396154 ∧ code e604919396154 = 9401012418362 := by decide
theorem cert_e604919396154 : check e604919396154 [[.under],[.under]] .smaller = true := by decide
def e604919396250 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e604919396250 : Closed e604919396250 ∧ code e604919396250 = 9401012418458 := by decide
theorem cert_e604919396250 : check e604919396250 [[.under],[.under]] .three = true := by decide
def e604919396790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e604919396790 : Closed e604919396790 ∧ code e604919396790 = 9401012418998 := by decide
theorem cert_e604919396790 : check e604919396790 [[.under],[.under]] .smaller = true := by decide
def e604919396822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e604919396822 : Closed e604919396822 ∧ code e604919396822 = 9401012419030 := by decide
theorem cert_e604919396822 : check e604919396822 [[.under],[.under]] .smaller = true := by decide
def e604919396826 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e604919396826 : Closed e604919396826 ∧ code e604919396826 = 9401012419034 := by decide
theorem cert_e604919396826 : check e604919396826 [[.under],[.under]] .smaller = true := by decide
def e604919396982 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e604919396982 : Closed e604919396982 ∧ code e604919396982 = 9401012419190 := by decide
theorem cert_e604919396982 : check e604919396982 [[.under],[.under]] .smaller = true := by decide
def e604919397174 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604919397174 : Closed e604919397174 ∧ code e604919397174 = 9401012419382 := by decide
theorem cert_e604919397174 : check e604919397174 [[.under],[.under]] .smaller = true := by decide
def e604919397178 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604919397178 : Closed e604919397178 ∧ code e604919397178 = 9401012419386 := by decide
theorem cert_e604919397178 : check e604919397178 [[.under],[.under]] .smaller = true := by decide
def e604919397590 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e604919397590 : Closed e604919397590 ∧ code e604919397590 = 9401012419798 := by decide
theorem cert_e604919397590 : check e604919397590 [[.under],[.under]] .three = true := by decide
def e604919397594 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e604919397594 : Closed e604919397594 ∧ code e604919397594 = 9401012419802 := by decide
theorem cert_e604919397594 : check e604919397594 [[.under],[.under]] .three = true := by decide
def e604919397610 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e604919397610 : Closed e604919397610 ∧ code e604919397610 = 9401012419818 := by decide
theorem cert_e604919397610 : check e604919397610 [[.under],[.under]] .three = true := by decide
def e604919397686 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e604919397686 : Closed e604919397686 ∧ code e604919397686 = 9401012419894 := by decide
theorem cert_e604919397686 : check e604919397686 [[.under],[.under]] .three = true := by decide
def e604919397690 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e604919397690 : Closed e604919397690 ∧ code e604919397690 = 9401012419898 := by decide
theorem cert_e604919397690 : check e604919397690 [[.under],[.under]] .three = true := by decide
def e604919397786 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e604919397786 : Closed e604919397786 ∧ code e604919397786 = 9401012419994 := by decide
theorem cert_e604919397786 : check e604919397786 [[.under],[.under]] .three = true := by decide
def e604919404254 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e604919404254 : Closed e604919404254 ∧ code e604919404254 = 9401012426462 := by decide
theorem cert_e604919404254 : check e604919404254 [[.under],[.under]] .three = true := by decide
def e604919404278 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e604919404278 : Closed e604919404278 ∧ code e604919404278 = 9401012426486 := by decide
theorem cert_e604919404278 : check e604919404278 [[.under],[.under]] .three = true := by decide
def e604919404382 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e604919404382 : Closed e604919404382 ∧ code e604919404382 = 9401012426590 := by decide
theorem cert_e604919404382 : check e604919404382 [[.under],[.under]] .three = true := by decide
def e604919404398 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e604919404398 : Closed e604919404398 ∧ code e604919404398 = 9401012426606 := by decide
theorem cert_e604919404398 : check e604919404398 [[.under],[.under]] .smaller = true := by decide
def e604919404406 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e604919404406 : Closed e604919404406 ∧ code e604919404406 = 9401012426614 := by decide
theorem cert_e604919404406 : check e604919404406 [[.under],[.under]] .smaller = true := by decide
def e604919404410 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e604919404410 : Closed e604919404410 ∧ code e604919404410 = 9401012426618 := by decide
theorem cert_e604919404410 : check e604919404410 [[.under],[.under]] .three = true := by decide
def e604919404470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e604919404470 : Closed e604919404470 ∧ code e604919404470 = 9401012426678 := by decide
theorem cert_e604919404470 : check e604919404470 [[.under],[.under]] .smaller = true := by decide
def e604919404502 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e604919404502 : Closed e604919404502 ∧ code e604919404502 = 9401012426710 := by decide
theorem cert_e604919404502 : check e604919404502 [[.under],[.under]] .three = true := by decide
def e604919404506 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e604919404506 : Closed e604919404506 ∧ code e604919404506 = 9401012426714 := by decide
theorem cert_e604919404506 : check e604919404506 [[.under],[.under]] .three = true := by decide
def e604919405022 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e604919405022 : Closed e604919405022 ∧ code e604919405022 = 9401012427230 := by decide
theorem cert_e604919405022 : check e604919405022 [[.under],[.under]] .three = true := by decide
def e604919405046 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e604919405046 : Closed e604919405046 ∧ code e604919405046 = 9401012427254 := by decide
theorem cert_e604919405046 : check e604919405046 [[.under],[.under]] .three = true := by decide
def e604919405790 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e604919405790 : Closed e604919405790 ∧ code e604919405790 = 9401012427998 := by decide
theorem cert_e604919405790 : check e604919405790 [[.under],[.under]] .three = true := by decide
def e604919405806 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e604919405806 : Closed e604919405806 ∧ code e604919405806 = 9401012428014 := by decide
theorem cert_e604919405806 : check e604919405806 [[.under],[.under]] .smaller = true := by decide
def e604919405814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e604919405814 : Closed e604919405814 ∧ code e604919405814 = 9401012428022 := by decide
theorem cert_e604919405814 : check e604919405814 [[.under],[.under]] .smaller = true := by decide
def e604919405818 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e604919405818 : Closed e604919405818 ∧ code e604919405818 = 9401012428026 := by decide
theorem cert_e604919405818 : check e604919405818 [[.under],[.under]] .three = true := by decide
def e604919406198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e604919406198 : Closed e604919406198 ∧ code e604919406198 = 9401012428406 := by decide
theorem cert_e604919406198 : check e604919406198 [[.under],[.under]] .smaller = true := by decide
def e604919406390 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e604919406390 : Closed e604919406390 ∧ code e604919406390 = 9401012428598 := by decide
theorem cert_e604919406390 : check e604919406390 [[.under],[.under]] .three = true := by decide
def e604919406394 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e604919406394 : Closed e604919406394 ∧ code e604919406394 = 9401012428602 := by decide
theorem cert_e604919406394 : check e604919406394 [[.under],[.under]] .three = true := by decide
def e604919417694 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e604919417694 : Closed e604919417694 ∧ code e604919417694 = 9401012439902 := by decide
theorem cert_e604919417694 : check e604919417694 [[.under],[.under]] .three = true := by decide
def e604919417710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e604919417710 : Closed e604919417710 ∧ code e604919417710 = 9401012439918 := by decide
theorem cert_e604919417710 : check e604919417710 [[.under],[.under]] .smaller = true := by decide
def e604919417718 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e604919417718 : Closed e604919417718 ∧ code e604919417718 = 9401012439926 := by decide
theorem cert_e604919417718 : check e604919417718 [[.under],[.under]] .smaller = true := by decide
def e604919417722 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e604919417722 : Closed e604919417722 ∧ code e604919417722 = 9401012439930 := by decide
theorem cert_e604919417722 : check e604919417722 [[.under],[.under]] .three = true := by decide
def e604919417774 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e604919417774 : Closed e604919417774 ∧ code e604919417774 = 9401012439982 := by decide
theorem cert_e604919417774 : check e604919417774 [[.under],[.under]] .smaller = true := by decide
def e604919417786 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e604919417786 : Closed e604919417786 ∧ code e604919417786 = 9401012439994 := by decide
theorem cert_e604919417786 : check e604919417786 [[.under],[.under]] .smaller = true := by decide
def e604919417814 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e604919417814 : Closed e604919417814 ∧ code e604919417814 = 9401012440022 := by decide
theorem cert_e604919417814 : check e604919417814 [[.under],[.under]] .smaller = true := by decide
def e604919417818 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e604919417818 : Closed e604919417818 ∧ code e604919417818 = 9401012440026 := by decide
theorem cert_e604919417818 : check e604919417818 [[.under],[.under]] .smaller = true := by decide
def e604919417834 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e604919417834 : Closed e604919417834 ∧ code e604919417834 = 9401012440042 := by decide
theorem cert_e604919417834 : check e604919417834 [[.under],[.under]] .three = true := by decide
def e604919418078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e604919418078 : Closed e604919418078 ∧ code e604919418078 = 9401012440286 := by decide
theorem cert_e604919418078 : check e604919418078 [[.under],[.under]] .three = true := by decide
def e604919418094 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e604919418094 : Closed e604919418094 ∧ code e604919418094 = 9401012440302 := by decide
theorem cert_e604919418094 : check e604919418094 [[.under],[.under]] .smaller = true := by decide
def e604919418102 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e604919418102 : Closed e604919418102 ∧ code e604919418102 = 9401012440310 := by decide
theorem cert_e604919418102 : check e604919418102 [[.under],[.under]] .smaller = true := by decide
def e604919418106 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e604919418106 : Closed e604919418106 ∧ code e604919418106 = 9401012440314 := by decide
theorem cert_e604919418106 : check e604919418106 [[.under],[.under]] .three = true := by decide
def e604919418478 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e604919418478 : Closed e604919418478 ∧ code e604919418478 = 9401012440686 := by decide
theorem cert_e604919418478 : check e604919418478 [[.under],[.under]] .smaller = true := by decide
def e604919418490 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e604919418490 : Closed e604919418490 ∧ code e604919418490 = 9401012440698 := by decide
theorem cert_e604919418490 : check e604919418490 [[.under],[.under]] .smaller = true := by decide
def e604919418678 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e604919418678 : Closed e604919418678 ∧ code e604919418678 = 9401012440886 := by decide
theorem cert_e604919418678 : check e604919418678 [[.under],[.under]] .smaller = true := by decide
def e604919418682 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e604919418682 : Closed e604919418682 ∧ code e604919418682 = 9401012440890 := by decide
theorem cert_e604919418682 : check e604919418682 [[.under],[.under]] .smaller = true := by decide
def e604919418778 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e604919418778 : Closed e604919418778 ∧ code e604919418778 = 9401012440986 := by decide
theorem cert_e604919418778 : check e604919418778 [[.under],[.under]] .three = true := by decide
def e604919424438 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e604919424438 : Closed e604919424438 ∧ code e604919424438 = 9401012446646 := by decide
theorem cert_e604919424438 : check e604919424438 [[.under],[.under]] .smaller = true := by decide
def e604919424470 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e604919424470 : Closed e604919424470 ∧ code e604919424470 = 9401012446678 := by decide
theorem cert_e604919424470 : check e604919424470 [[.under],[.under]] .smaller = true := by decide
def e604919424474 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e604919424474 : Closed e604919424474 ∧ code e604919424474 = 9401012446682 := by decide
theorem cert_e604919424474 : check e604919424474 [[.under],[.under]] .smaller = true := by decide
def e604919424630 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e604919424630 : Closed e604919424630 ∧ code e604919424630 = 9401012446838 := by decide
theorem cert_e604919424630 : check e604919424630 [[.under],[.under]] .smaller = true := by decide
def e604919424822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e604919424822 : Closed e604919424822 ∧ code e604919424822 = 9401012447030 := by decide
theorem cert_e604919424822 : check e604919424822 [[.under],[.under]] .smaller = true := by decide
def e604919424826 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e604919424826 : Closed e604919424826 ∧ code e604919424826 = 9401012447034 := by decide
theorem cert_e604919424826 : check e604919424826 [[.under],[.under]] .smaller = true := by decide
def e604919427798 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e604919427798 : Closed e604919427798 ∧ code e604919427798 = 9401012450006 := by decide
theorem cert_e604919427798 : check e604919427798 [[.under],[.under]] .three = true := by decide
def e604919427802 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e604919427802 : Closed e604919427802 ∧ code e604919427802 = 9401012450010 := by decide
theorem cert_e604919427802 : check e604919427802 [[.under],[.under]] .three = true := by decide
def e604919427818 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e604919427818 : Closed e604919427818 ∧ code e604919427818 = 9401012450026 := by decide
theorem cert_e604919427818 : check e604919427818 [[.under],[.under]] .three = true := by decide
def e604919427894 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e604919427894 : Closed e604919427894 ∧ code e604919427894 = 9401012450102 := by decide
theorem cert_e604919427894 : check e604919427894 [[.under],[.under]] .three = true := by decide
def e604919427898 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e604919427898 : Closed e604919427898 ∧ code e604919427898 = 9401012450106 := by decide
theorem cert_e604919427898 : check e604919427898 [[.under],[.under]] .three = true := by decide
def e604919427994 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e604919427994 : Closed e604919427994 ∧ code e604919427994 = 9401012450202 := by decide
theorem cert_e604919427994 : check e604919427994 [[.under],[.under]] .three = true := by decide
def e604919653230 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e604919653230 : Closed e604919653230 ∧ code e604919653230 = 9401012675438 := by decide
theorem cert_e604919653230 : check e604919653230 [[.under],[.under]] .three = true := by decide
def e604919653238 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e604919653238 : Closed e604919653238 ∧ code e604919653238 = 9401012675446 := by decide
theorem cert_e604919653238 : check e604919653238 [[.under],[.under]] .three = true := by decide
def e604919653294 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e604919653294 : Closed e604919653294 ∧ code e604919653294 = 9401012675502 := by decide
theorem cert_e604919653294 : check e604919653294 [[.under],[.under]] .three = true := by decide
def e604919653306 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e604919653306 : Closed e604919653306 ∧ code e604919653306 = 9401012675514 := by decide
theorem cert_e604919653306 : check e604919653306 [[.under],[.under]] .three = true := by decide
def e604919653334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e604919653334 : Closed e604919653334 ∧ code e604919653334 = 9401012675542 := by decide
theorem cert_e604919653334 : check e604919653334 [[.under],[.under]] .three = true := by decide
def e604919653338 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e604919653338 : Closed e604919653338 ∧ code e604919653338 = 9401012675546 := by decide
theorem cert_e604919653338 : check e604919653338 [[.under],[.under]] .three = true := by decide
def e604919654638 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e604919654638 : Closed e604919654638 ∧ code e604919654638 = 9401012676846 := by decide
theorem cert_e604919654638 : check e604919654638 [[.under],[.under]] .three = true := by decide
def e604919654646 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e604919654646 : Closed e604919654646 ∧ code e604919654646 = 9401012676854 := by decide
theorem cert_e604919654646 : check e604919654646 [[.under],[.under]] .three = true := by decide
def e604919655198 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e604919655198 : Closed e604919655198 ∧ code e604919655198 = 9401012677406 := by decide
theorem cert_e604919655198 : check e604919655198 [[.under],[.under]] .three = true := by decide
def e604919655310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e604919655310 : Closed e604919655310 ∧ code e604919655310 = 9401012677518 := by decide
theorem cert_e604919655310 : check e604919655310 [[.under],[.under]] .three = true := by decide
def e604919655534 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e604919655534 : Closed e604919655534 ∧ code e604919655534 = 9401012677742 := by decide
theorem cert_e604919655534 : check e604919655534 [[.under],[.under]] .three = true := by decide
def e604919655546 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e604919655546 : Closed e604919655546 ∧ code e604919655546 = 9401012677754 := by decide
theorem cert_e604919655546 : check e604919655546 [[.under],[.under]] .three = true := by decide
def e604919655710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e604919655710 : Closed e604919655710 ∧ code e604919655710 = 9401012677918 := by decide
theorem cert_e604919655710 : check e604919655710 [[.under],[.under]] .three = true := by decide
def e604919655878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e604919655878 : Closed e604919655878 ∧ code e604919655878 = 9401012678086 := by decide
theorem cert_e604919655878 : check e604919655878 [[.under],[.under]] .three = true := by decide
def e604919655990 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e604919655990 : Closed e604919655990 ∧ code e604919655990 = 9401012678198 := by decide
theorem cert_e604919655990 : check e604919655990 [[.under],[.under]] .three = true := by decide
def e604919655994 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e604919655994 : Closed e604919655994 ∧ code e604919655994 = 9401012678202 := by decide
theorem cert_e604919655994 : check e604919655994 [[.under],[.under]] .three = true := by decide
def e604919656078 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e604919656078 : Closed e604919656078 ∧ code e604919656078 = 9401012678286 := by decide
theorem cert_e604919656078 : check e604919656078 [[.under],[.under]] .three = true := by decide
def e604919656134 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e604919656134 : Closed e604919656134 ∧ code e604919656134 = 9401012678342 := by decide
theorem cert_e604919656134 : check e604919656134 [[.under],[.under]] .three = true := by decide
def e604919656878 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e604919656878 : Closed e604919656878 ∧ code e604919656878 = 9401012679086 := by decide
theorem cert_e604919656878 : check e604919656878 [[.under],[.under]] .three = true := by decide
def e604919656890 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e604919656890 : Closed e604919656890 ∧ code e604919656890 = 9401012679098 := by decide
theorem cert_e604919656890 : check e604919656890 [[.under],[.under]] .three = true := by decide
def e604919656938 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)))))))
theorem wire_e604919656938 : Closed e604919656938 ∧ code e604919656938 = 9401012679146 := by decide
theorem cert_e604919656938 : check e604919656938 [[.under],[.under]] .three = true := by decide
def e604919657582 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e604919657582 : Closed e604919657582 ∧ code e604919657582 = 9401012679790 := by decide
theorem cert_e604919657582 : check e604919657582 [[.under],[.under]] .three = true := by decide
def e604919657594 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e604919657594 : Closed e604919657594 ∧ code e604919657594 = 9401012679802 := by decide
theorem cert_e604919657594 : check e604919657594 [[.under],[.under]] .three = true := by decide
def e604919657758 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e604919657758 : Closed e604919657758 ∧ code e604919657758 = 9401012679966 := by decide
theorem cert_e604919657758 : check e604919657758 [[.under],[.under]] .three = true := by decide
def e604919657926 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e604919657926 : Closed e604919657926 ∧ code e604919657926 = 9401012680134 := by decide
theorem cert_e604919657926 : check e604919657926 [[.under],[.under]] .three = true := by decide
def e604919658266 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e604919658266 : Closed e604919658266 ∧ code e604919658266 = 9401012680474 := by decide
theorem cert_e604919658266 : check e604919658266 [[.under],[.under]] .three = true := by decide
def e604919658310 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e604919658310 : Closed e604919658310 ∧ code e604919658310 = 9401012680518 := by decide
theorem cert_e604919658310 : check e604919658310 [[.under],[.under]] .three = true := by decide
def e604919658710 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1)))))))
theorem wire_e604919658710 : Closed e604919658710 ∧ code e604919658710 = 9401012680918 := by decide
theorem cert_e604919658710 : check e604919658710 [[.under],[.under]] .three = true := by decide
def e604919658714 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0)))))))
theorem wire_e604919658714 : Closed e604919658714 ∧ code e604919658714 = 9401012680922 := by decide
theorem cert_e604919658714 : check e604919658714 [[.under],[.under]] .three = true := by decide
def e604919658730 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e604919658730 : Closed e604919658730 ∧ code e604919658730 = 9401012680938 := by decide
theorem cert_e604919658730 : check e604919658730 [[.under],[.under]] .three = true := by decide
def e604919659062 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e604919659062 : Closed e604919659062 ∧ code e604919659062 = 9401012681270 := by decide
theorem cert_e604919659062 : check e604919659062 [[.under],[.under]] .three = true := by decide
def e604919659066 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e604919659066 : Closed e604919659066 ∧ code e604919659066 = 9401012681274 := by decide
theorem cert_e604919659066 : check e604919659066 [[.under],[.under]] .three = true := by decide
def e604919659150 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e604919659150 : Closed e604919659150 ∧ code e604919659150 = 9401012681358 := by decide
theorem cert_e604919659150 : check e604919659150 [[.under],[.under]] .three = true := by decide
def e604919659206 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e604919659206 : Closed e604919659206 ∧ code e604919659206 = 9401012681414 := by decide
theorem cert_e604919659206 : check e604919659206 [[.under],[.under]] .three = true := by decide
def e604919659290 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 0)))))))
theorem wire_e604919659290 : Closed e604919659290 ∧ code e604919659290 = 9401012681498 := by decide
theorem cert_e604919659290 : check e604919659290 [[.under],[.under]] .three = true := by decide
def e604919659334 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 1))))))))
theorem wire_e604919659334 : Closed e604919659334 ∧ code e604919659334 = 9401012681542 := by decide
theorem cert_e604919659334 : check e604919659334 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
