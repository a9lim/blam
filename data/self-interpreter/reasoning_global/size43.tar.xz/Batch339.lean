import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418469702510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418469702510 : Closed e2418469702510 ∧ code e2418469702510 = 11214562724718 := by decide
theorem cert_e2418469702510 : check e2418469702510 [[],[]] .smaller = true := by decide
def e2418469702518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418469702518 : Closed e2418469702518 ∧ code e2418469702518 = 11214562724726 := by decide
theorem cert_e2418469702518 : check e2418469702518 [[],[]] .smaller = true := by decide
def e2418469702574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418469702574 : Closed e2418469702574 ∧ code e2418469702574 = 11214562724782 := by decide
theorem cert_e2418469702574 : check e2418469702574 [[],[]] .smaller = true := by decide
def e2418469702586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418469702586 : Closed e2418469702586 ∧ code e2418469702586 = 11214562724794 := by decide
theorem cert_e2418469702586 : check e2418469702586 [[],[]] .smaller = true := by decide
def e2418469702614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418469702614 : Closed e2418469702614 ∧ code e2418469702614 = 11214562724822 := by decide
theorem cert_e2418469702614 : check e2418469702614 [[],[]] .smaller = true := by decide
def e2418469702618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418469702618 : Closed e2418469702618 ∧ code e2418469702618 = 11214562724826 := by decide
theorem cert_e2418469702618 : check e2418469702618 [[],[]] .smaller = true := by decide
def e2418469702894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418469702894 : Closed e2418469702894 ∧ code e2418469702894 = 11214562725102 := by decide
theorem cert_e2418469702894 : check e2418469702894 [[],[]] .smaller = true := by decide
def e2418469702902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418469702902 : Closed e2418469702902 ∧ code e2418469702902 = 11214562725110 := by decide
theorem cert_e2418469702902 : check e2418469702902 [[],[]] .smaller = true := by decide
def e2418469703278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418469703278 : Closed e2418469703278 ∧ code e2418469703278 = 11214562725486 := by decide
theorem cert_e2418469703278 : check e2418469703278 [[],[]] .smaller = true := by decide
def e2418469703290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418469703290 : Closed e2418469703290 ∧ code e2418469703290 = 11214562725498 := by decide
theorem cert_e2418469703290 : check e2418469703290 [[],[]] .smaller = true := by decide
def e2418469703478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418469703478 : Closed e2418469703478 ∧ code e2418469703478 = 11214562725686 := by decide
theorem cert_e2418469703478 : check e2418469703478 [[],[]] .smaller = true := by decide
def e2418469703482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418469703482 : Closed e2418469703482 ∧ code e2418469703482 = 11214562725690 := by decide
theorem cert_e2418469703482 : check e2418469703482 [[],[]] .smaller = true := by decide
def e2418469710958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2418469710958 : Closed e2418469710958 ∧ code e2418469710958 = 11214562733166 := by decide
theorem cert_e2418469710958 : check e2418469710958 [[],[]] .sourceHead = true := by decide
def e2418469710970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2418469710970 : Closed e2418469710970 ∧ code e2418469710970 = 11214562733178 := by decide
theorem cert_e2418469710970 : check e2418469710970 [[],[]] .sourceHead = true := by decide
def e2418469711134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2418469711134 : Closed e2418469711134 ∧ code e2418469711134 = 11214562733342 := by decide
theorem cert_e2418469711134 : check e2418469711134 [[],[]] .sourceHead = true := by decide
def e2418469711302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2418469711302 : Closed e2418469711302 ∧ code e2418469711302 = 11214562733510 := by decide
theorem cert_e2418469711302 : check e2418469711302 [[],[]] .sourceHead = true := by decide
def e2418469711642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2418469711642 : Closed e2418469711642 ∧ code e2418469711642 = 11214562733850 := by decide
theorem cert_e2418469711642 : check e2418469711642 [[],[]] .sourceHead = true := by decide
def e2418469711686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2418469711686 : Closed e2418469711686 ∧ code e2418469711686 = 11214562733894 := by decide
theorem cert_e2418469711686 : check e2418469711686 [[],[]] .sourceHead = true := by decide
def e2418469712670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2418469712670 : Closed e2418469712670 ∧ code e2418469712670 = 11214562734878 := by decide
theorem cert_e2418469712670 : check e2418469712670 [[],[]] .sourceHead = true := by decide
def e2418469712838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2418469712838 : Closed e2418469712838 ∧ code e2418469712838 = 11214562735046 := by decide
theorem cert_e2418469712838 : check e2418469712838 [[],[]] .sourceHead = true := by decide
def e2418469715142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2418469715142 : Closed e2418469715142 ∧ code e2418469715142 = 11214562737350 := by decide
theorem cert_e2418469715142 : check e2418469715142 [[],[]] .sourceHead = true := by decide
def e2418469738038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2418469738038 : Closed e2418469738038 ∧ code e2418469738038 = 11214562760246 := by decide
theorem cert_e2418469738038 : check e2418469738038 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469738042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2418469738042 : Closed e2418469738042 ∧ code e2418469738042 = 11214562760250 := by decide
theorem cert_e2418469738042 : check e2418469738042 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469738126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2418469738126 : Closed e2418469738126 ∧ code e2418469738126 = 11214562760334 := by decide
theorem cert_e2418469738126 : check e2418469738126 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469738182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2418469738182 : Closed e2418469738182 ∧ code e2418469738182 = 11214562760390 := by decide
theorem cert_e2418469738182 : check e2418469738182 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469738266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2418469738266 : Closed e2418469738266 ∧ code e2418469738266 = 11214562760474 := by decide
theorem cert_e2418469738266 : check e2418469738266 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469738310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2418469738310 : Closed e2418469738310 ∧ code e2418469738310 = 11214562760518 := by decide
theorem cert_e2418469738310 : check e2418469738310 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469738894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2418469738894 : Closed e2418469738894 ∧ code e2418469738894 = 11214562761102 := by decide
theorem cert_e2418469738894 : check e2418469738894 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469738950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2418469738950 : Closed e2418469738950 ∧ code e2418469738950 = 11214562761158 := by decide
theorem cert_e2418469738950 : check e2418469738950 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418469739718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2418469739718 : Closed e2418469739718 ∧ code e2418469739718 = 11214562761926 := by decide
theorem cert_e2418469739718 : check e2418469739718 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418470836462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2418470836462 : Closed e2418470836462 ∧ code e2418470836462 = 11214563858670 := by decide
theorem cert_e2418470836462 : check e2418470836462 [[],[]] .sourceHead = true := by decide
def e2418470836470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2418470836470 : Closed e2418470836470 ∧ code e2418470836470 = 11214563858678 := by decide
theorem cert_e2418470836470 : check e2418470836470 [[],[]] .sourceHead = true := by decide
def e2418470837022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2418470837022 : Closed e2418470837022 ∧ code e2418470837022 = 11214563859230 := by decide
theorem cert_e2418470837022 : check e2418470837022 [[],[]] .sourceHead = true := by decide
def e2418470837134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2418470837134 : Closed e2418470837134 ∧ code e2418470837134 = 11214563859342 := by decide
theorem cert_e2418470837134 : check e2418470837134 [[],[]] .sourceHead = true := by decide
def e2418470837358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2418470837358 : Closed e2418470837358 ∧ code e2418470837358 = 11214563859566 := by decide
theorem cert_e2418470837358 : check e2418470837358 [[],[]] .sourceHead = true := by decide
def e2418470837370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2418470837370 : Closed e2418470837370 ∧ code e2418470837370 = 11214563859578 := by decide
theorem cert_e2418470837370 : check e2418470837370 [[],[]] .sourceHead = true := by decide
def e2418470837534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2418470837534 : Closed e2418470837534 ∧ code e2418470837534 = 11214563859742 := by decide
theorem cert_e2418470837534 : check e2418470837534 [[],[]] .sourceHead = true := by decide
def e2418470837702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2418470837702 : Closed e2418470837702 ∧ code e2418470837702 = 11214563859910 := by decide
theorem cert_e2418470837702 : check e2418470837702 [[],[]] .sourceHead = true := by decide
def e2418470837814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2418470837814 : Closed e2418470837814 ∧ code e2418470837814 = 11214563860022 := by decide
theorem cert_e2418470837814 : check e2418470837814 [[],[]] .sourceHead = true := by decide
def e2418470837818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2418470837818 : Closed e2418470837818 ∧ code e2418470837818 = 11214563860026 := by decide
theorem cert_e2418470837818 : check e2418470837818 [[],[]] .sourceHead = true := by decide
def e2418470837902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2418470837902 : Closed e2418470837902 ∧ code e2418470837902 = 11214563860110 := by decide
theorem cert_e2418470837902 : check e2418470837902 [[],[]] .sourceHead = true := by decide
def e2418470837958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2418470837958 : Closed e2418470837958 ∧ code e2418470837958 = 11214563860166 := by decide
theorem cert_e2418470837958 : check e2418470837958 [[],[]] .sourceHead = true := by decide
def e2418470840094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2418470840094 : Closed e2418470840094 ∧ code e2418470840094 = 11214563862302 := by decide
theorem cert_e2418470840094 : check e2418470840094 [[],[]] .sourceHead = true := by decide
def e2418470840206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2418470840206 : Closed e2418470840206 ∧ code e2418470840206 = 11214563862414 := by decide
theorem cert_e2418470840206 : check e2418470840206 [[],[]] .sourceHead = true := by decide
def e2418470843166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2418470843166 : Closed e2418470843166 ∧ code e2418470843166 = 11214563865374 := by decide
theorem cert_e2418470843166 : check e2418470843166 [[],[]] .sourceHead = true := by decide
def e2418470843334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2418470843334 : Closed e2418470843334 ∧ code e2418470843334 = 11214563865542 := by decide
theorem cert_e2418470843334 : check e2418470843334 [[],[]] .sourceHead = true := by decide
def e2418470844814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2418470844814 : Closed e2418470844814 ∧ code e2418470844814 = 11214563867022 := by decide
theorem cert_e2418470844814 : check e2418470844814 [[],[]] .sourceHead = true := by decide
def e2418470844870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2418470844870 : Closed e2418470844870 ∧ code e2418470844870 = 11214563867078 := by decide
theorem cert_e2418470844870 : check e2418470844870 [[],[]] .sourceHead = true := by decide
def e2418475538142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2418475538142 : Closed e2418475538142 ∧ code e2418475538142 = 11214568560350 := by decide
theorem cert_e2418475538142 : check e2418475538142 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418475538166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2418475538166 : Closed e2418475538166 ∧ code e2418475538166 = 11214568560374 := by decide
theorem cert_e2418475538166 : check e2418475538166 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418475538270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2418475538270 : Closed e2418475538270 ∧ code e2418475538270 = 11214568560478 := by decide
theorem cert_e2418475538270 : checkPay e2418475538270 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418475538298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2418475538298 : Closed e2418475538298 ∧ code e2418475538298 = 11214568560506 := by decide
theorem cert_e2418475538298 : checkPay e2418475538298 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] 0 [[],[]] = true := by decide
def e2418475538390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2418475538390 : Closed e2418475538390 ∧ code e2418475538390 = 11214568560598 := by decide
theorem cert_e2418475538390 : check e2418475538390 [[],[],[.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418475538394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2418475538394 : Closed e2418475538394 ∧ code e2418475538394 = 11214568560602 := by decide
theorem cert_e2418475538394 : check e2418475538394 [[],[],[.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left,.left]] .smaller = true := by decide
def e2418475538910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2418475538910 : Closed e2418475538910 ∧ code e2418475538910 = 11214568561118 := by decide
theorem cert_e2418475538910 : check e2418475538910 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418475538934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2418475538934 : Closed e2418475538934 ∧ code e2418475538934 = 11214568561142 := by decide
theorem cert_e2418475538934 : check e2418475538934 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418475539678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2418475539678 : Closed e2418475539678 ∧ code e2418475539678 = 11214568561886 := by decide
theorem cert_e2418475539678 : check e2418475539678 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475539706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2418475539706 : Closed e2418475539706 ∧ code e2418475539706 = 11214568561914 := by decide
theorem cert_e2418475539706 : check e2418475539706 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475540278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418475540278 : Closed e2418475540278 ∧ code e2418475540278 = 11214568562486 := by decide
theorem cert_e2418475540278 : check e2418475540278 [[],[],[.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left]] .smaller = true := by decide
def e2418475540282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418475540282 : Closed e2418475540282 ∧ code e2418475540282 = 11214568562490 := by decide
theorem cert_e2418475540282 : check e2418475540282 [[],[],[.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left]] .smaller = true := by decide
def e2418475555054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2418475555054 : Closed e2418475555054 ∧ code e2418475555054 = 11214568577262 := by decide
theorem cert_e2418475555054 : check e2418475555054 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475555062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2418475555062 : Closed e2418475555062 ∧ code e2418475555062 = 11214568577270 := by decide
theorem cert_e2418475555062 : check e2418475555062 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475555614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2418475555614 : Closed e2418475555614 ∧ code e2418475555614 = 11214568577822 := by decide
theorem cert_e2418475555614 : check e2418475555614 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475555726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2418475555726 : Closed e2418475555726 ∧ code e2418475555726 = 11214568577934 := by decide
theorem cert_e2418475555726 : check e2418475555726 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475555950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2418475555950 : Closed e2418475555950 ∧ code e2418475555950 = 11214568578158 := by decide
theorem cert_e2418475555950 : check e2418475555950 [[],[],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e2418475555962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2418475555962 : Closed e2418475555962 ∧ code e2418475555962 = 11214568578170 := by decide
theorem cert_e2418475555962 : check e2418475555962 [[],[],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left]] .smaller = true := by decide
def e2418475556126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2418475556126 : Closed e2418475556126 ∧ code e2418475556126 = 11214568578334 := by decide
theorem cert_e2418475556126 : check e2418475556126 [[],[],[.left],[.left],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418475556294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2418475556294 : Closed e2418475556294 ∧ code e2418475556294 = 11214568578502 := by decide
def e2418475556406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2418475556406 : Closed e2418475556406 ∧ code e2418475556406 = 11214568578614 := by decide
theorem cert_e2418475556406 : check e2418475556406 [[],[],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left]] .sourceHead = true := by decide
def e2418475556410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2418475556410 : Closed e2418475556410 ∧ code e2418475556410 = 11214568578618 := by decide
theorem cert_e2418475556410 : check e2418475556410 [[],[],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2418475556494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2418475556494 : Closed e2418475556494 ∧ code e2418475556494 = 11214568578702 := by decide
theorem cert_e2418475556494 : check e2418475556494 [[],[],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2418475556550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2418475556550 : Closed e2418475556550 ∧ code e2418475556550 = 11214568578758 := by decide
def e2418475558686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2418475558686 : Closed e2418475558686 ∧ code e2418475558686 = 11214568580894 := by decide
theorem cert_e2418475558686 : check e2418475558686 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475558798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2418475558798 : Closed e2418475558798 ∧ code e2418475558798 = 11214568581006 := by decide
theorem cert_e2418475558798 : check e2418475558798 [[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2418475561758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2418475561758 : Closed e2418475561758 ∧ code e2418475561758 = 11214568583966 := by decide
theorem cert_e2418475561758 : checkPay e2418475561758 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [[.under],[.under]] = true := by decide
def e2418475561926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2418475561926 : Closed e2418475561926 ∧ code e2418475561926 = 11214568584134 := by decide
theorem cert_e2418475561926 : check e2418475561926 [[],[],[.left],[.left],[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2418475563406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2418475563406 : Closed e2418475563406 ∧ code e2418475563406 = 11214568585614 := by decide
theorem cert_e2418475563406 : check e2418475563406 [[],[],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418475563462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2418475563462 : Closed e2418475563462 ∧ code e2418475563462 = 11214568585670 := by decide
theorem cert_e2418475563462 : checkPay e2418475563462 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left],[],[.left],[.left],[],[.left,.left]] 0 [] = true := by decide
def e2418872643098 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872643098 : Closed e2418872643098 ∧ code e2418872643098 = 11214965665306 := by decide
theorem cert_e2418872643098 : check e2418872643098 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .chain = true := by decide
def e2418872645146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872645146 : Closed e2418872645146 ∧ code e2418872645146 = 11214965667354 := by decide
theorem cert_e2418872645146 : check e2418872645146 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2418872659482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872659482 : Closed e2418872659482 ∧ code e2418872659482 = 11214965681690 := by decide
theorem cert_e2418872659482 : check e2418872659482 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .chain = true := by decide
def e2418872662554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872662554 : Closed e2418872662554 ∧ code e2418872662554 = 11214965684762 := by decide
theorem cert_e2418872662554 : check e2418872662554 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2418872669722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872669722 : Closed e2418872669722 ∧ code e2418872669722 = 11214965691930 := by decide
theorem cert_e2418872669722 : check e2418872669722 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2418872670746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872670746 : Closed e2418872670746 ∧ code e2418872670746 = 11214965692954 := by decide
theorem cert_e2418872670746 : check e2418872670746 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418872741402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872741402 : Closed e2418872741402 ∧ code e2418872741402 = 11214965763610 := by decide
theorem cert_e2418872741402 : check e2418872741402 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2418872743450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872743450 : Closed e2418872743450 ∧ code e2418872743450 = 11214965765658 := by decide
theorem cert_e2418872743450 : check e2418872743450 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2418872839706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872839706 : Closed e2418872839706 ∧ code e2418872839706 = 11214965861914 := by decide
theorem cert_e2418872839706 : check e2418872839706 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2418872842778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872842778 : Closed e2418872842778 ∧ code e2418872842778 = 11214965864986 := by decide
theorem cert_e2418872842778 : check e2418872842778 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418872890906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872890906 : Closed e2418872890906 ∧ code e2418872890906 = 11214965913114 := by decide
theorem cert_e2418872890906 : check e2418872890906 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418872891930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2418872891930 : Closed e2418872891930 ∧ code e2418872891930 = 11214965914138 := by decide
theorem cert_e2418872891930 : check e2418872891930 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2418874890266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418874890266 : Closed e2418874890266 ∧ code e2418874890266 = 11214967912474 := by decide
theorem cert_e2418874890266 : check e2418874890266 [[]] .width = true := by decide
def e2418874898458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418874898458 : Closed e2418874898458 ∧ code e2418874898458 = 11214967920666 := by decide
theorem cert_e2418874898458 : check e2418874898458 [[]] .width = true := by decide
def e2418874955802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418874955802 : Closed e2418874955802 ∧ code e2418874955802 = 11214967978010 := by decide
theorem cert_e2418874955802 : check e2418874955802 [[]] .width = true := by decide
def e2418874968090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418874968090 : Closed e2418874968090 ∧ code e2418874968090 = 11214967990298 := by decide
theorem cert_e2418874968090 : check e2418874968090 [[]] .width = true := by decide
def e2418874996762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418874996762 : Closed e2418874996762 ∧ code e2418874996762 = 11214968018970 := by decide
theorem cert_e2418874996762 : check e2418874996762 [[]] .width = true := by decide
def e2418875000858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418875000858 : Closed e2418875000858 ∧ code e2418875000858 = 11214968023066 := by decide
theorem cert_e2418875000858 : check e2418875000858 [[]] .width = true := by decide
def e2418875283482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418875283482 : Closed e2418875283482 ∧ code e2418875283482 = 11214968305690 := by decide
theorem cert_e2418875283482 : check e2418875283482 [[]] .width = true := by decide
def e2418875291674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418875291674 : Closed e2418875291674 ∧ code e2418875291674 = 11214968313882 := by decide
theorem cert_e2418875291674 : check e2418875291674 [[]] .width = true := by decide
def e2418875676698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418875676698 : Closed e2418875676698 ∧ code e2418875676698 = 11214968698906 := by decide
theorem cert_e2418875676698 : check e2418875676698 [[]] .width = true := by decide
def e2418875688986 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418875688986 : Closed e2418875688986 ∧ code e2418875688986 = 11214968711194 := by decide
theorem cert_e2418875688986 : check e2418875688986 [[]] .width = true := by decide
def e2418875881498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418875881498 : Closed e2418875881498 ∧ code e2418875881498 = 11214968903706 := by decide
theorem cert_e2418875881498 : check e2418875881498 [[]] .width = true := by decide
def e2418875885594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2418875885594 : Closed e2418875885594 ∧ code e2418875885594 = 11214968907802 := by decide
theorem cert_e2418875885594 : check e2418875885594 [[]] .width = true := by decide
def e2418888715630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418888715630 : Closed e2418888715630 ∧ code e2418888715630 = 11214981737838 := by decide
theorem cert_e2418888715630 : check e2418888715630 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418888715638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418888715638 : Closed e2418888715638 ∧ code e2418888715638 = 11214981737846 := by decide
theorem cert_e2418888715638 : checkPay e2418888715638 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418888715694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418888715694 : Closed e2418888715694 ∧ code e2418888715694 = 11214981737902 := by decide
theorem cert_e2418888715694 : check e2418888715694 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418888715706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418888715706 : Closed e2418888715706 ∧ code e2418888715706 = 11214981737914 := by decide
theorem cert_e2418888715706 : check e2418888715706 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418888715734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418888715734 : Closed e2418888715734 ∧ code e2418888715734 = 11214981737942 := by decide
theorem cert_e2418888715734 : check e2418888715734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418888715738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418888715738 : Closed e2418888715738 ∧ code e2418888715738 = 11214981737946 := by decide
theorem cert_e2418888715738 : check e2418888715738 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418888715950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2418888715950 : Closed e2418888715950 ∧ code e2418888715950 = 11214981738158 := by decide
theorem cert_e2418888715950 : check e2418888715950 [[],[]] .sourceHead = true := by decide
def e2418888715962 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2418888715962 : Closed e2418888715962 ∧ code e2418888715962 = 11214981738170 := by decide
theorem cert_e2418888715962 : check e2418888715962 [[],[]] .sourceHead = true := by decide
def e2418888716010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2418888716010 : Closed e2418888716010 ∧ code e2418888716010 = 11214981738218 := by decide
theorem cert_e2418888716010 : check e2418888716010 [[],[]] .sourceHead = true := by decide
def e2418888716118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2418888716118 : Closed e2418888716118 ∧ code e2418888716118 = 11214981738326 := by decide
theorem cert_e2418888716118 : check e2418888716118 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418888716122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2418888716122 : Closed e2418888716122 ∧ code e2418888716122 = 11214981738330 := by decide
theorem cert_e2418888716122 : check e2418888716122 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418888716138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2418888716138 : Closed e2418888716138 ∧ code e2418888716138 = 11214981738346 := by decide
theorem cert_e2418888716138 : check e2418888716138 [[],[],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418888717166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418888717166 : Closed e2418888717166 ∧ code e2418888717166 = 11214981739374 := by decide
theorem cert_e2418888717166 : check e2418888717166 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418888717174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418888717174 : Closed e2418888717174 ∧ code e2418888717174 = 11214981739382 := by decide
theorem cert_e2418888717174 : check e2418888717174 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418888717230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418888717230 : Closed e2418888717230 ∧ code e2418888717230 = 11214981739438 := by decide
theorem cert_e2418888717230 : check e2418888717230 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418888717242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418888717242 : Closed e2418888717242 ∧ code e2418888717242 = 11214981739450 := by decide
theorem cert_e2418888717242 : check e2418888717242 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418888717270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418888717270 : Closed e2418888717270 ∧ code e2418888717270 = 11214981739478 := by decide
theorem cert_e2418888717270 : checkPay e2418888717270 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2418888717274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418888717274 : Closed e2418888717274 ∧ code e2418888717274 = 11214981739482 := by decide
theorem cert_e2418888717274 : check e2418888717274 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2418888717550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418888717550 : Closed e2418888717550 ∧ code e2418888717550 = 11214981739758 := by decide
theorem cert_e2418888717550 : check e2418888717550 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418888717558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418888717558 : Closed e2418888717558 ∧ code e2418888717558 = 11214981739766 := by decide
theorem cert_e2418888717558 : check e2418888717558 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418888717934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418888717934 : Closed e2418888717934 ∧ code e2418888717934 = 11214981740142 := by decide
theorem cert_e2418888717934 : check e2418888717934 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418888717946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418888717946 : Closed e2418888717946 ∧ code e2418888717946 = 11214981740154 := by decide
theorem cert_e2418888717946 : check e2418888717946 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418888718134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418888718134 : Closed e2418888718134 ∧ code e2418888718134 = 11214981740342 := by decide
theorem cert_e2418888718134 : checkPay e2418888718134 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] 0 [] = true := by decide
def e2418888718138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418888718138 : Closed e2418888718138 ∧ code e2418888718138 = 11214981740346 := by decide
theorem cert_e2418888718138 : check e2418888718138 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418888718766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2418888718766 : Closed e2418888718766 ∧ code e2418888718766 = 11214981740974 := by decide
theorem cert_e2418888718766 : checkPay e2418888718766 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[.left,.left],[.left],[]] = true := by decide
def e2418888718778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2418888718778 : Closed e2418888718778 ∧ code e2418888718778 = 11214981740986 := by decide
theorem cert_e2418888718778 : checkPay e2418888718778 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left],[]] = true := by decide
def e2418888718826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2418888718826 : Closed e2418888718826 ∧ code e2418888718826 = 11214981741034 := by decide
theorem cert_e2418888718826 : checkPay e2418888718826 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e2418888718958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418888718958 : Closed e2418888718958 ∧ code e2418888718958 = 11214981741166 := by decide
theorem cert_e2418888718958 : checkPay e2418888718958 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418888718970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418888718970 : Closed e2418888718970 ∧ code e2418888718970 = 11214981741178 := by decide
theorem cert_e2418888718970 : checkPay e2418888718970 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418888719258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418888719258 : Closed e2418888719258 ∧ code e2418888719258 = 11214981741466 := by decide
theorem cert_e2418888719258 : checkPay e2418888719258 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right]] = true := by decide
def e2418888719574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2418888719574 : Closed e2418888719574 ∧ code e2418888719574 = 11214981741782 := by decide
theorem cert_e2418888719574 : check e2418888719574 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418888719578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2418888719578 : Closed e2418888719578 ∧ code e2418888719578 = 11214981741786 := by decide
theorem cert_e2418888719578 : check e2418888719578 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418888719594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2418888719594 : Closed e2418888719594 ∧ code e2418888719594 = 11214981741802 := by decide
theorem cert_e2418888719594 : check e2418888719594 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418888719670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418888719670 : Closed e2418888719670 ∧ code e2418888719670 = 11214981741878 := by decide
theorem cert_e2418888719670 : check e2418888719670 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418888719674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418888719674 : Closed e2418888719674 ∧ code e2418888719674 = 11214981741882 := by decide
theorem cert_e2418888719674 : check e2418888719674 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418888719770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2418888719770 : Closed e2418888719770 ∧ code e2418888719770 = 11214981741978 := by decide
theorem cert_e2418888719770 : check e2418888719770 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2418888723310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418888723310 : Closed e2418888723310 ∧ code e2418888723310 = 11214981745518 := by decide
theorem cert_e2418888723310 : check e2418888723310 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .identityHead = true := by decide
def e2418888723318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418888723318 : Closed e2418888723318 ∧ code e2418888723318 = 11214981745526 := by decide
theorem cert_e2418888723318 : check e2418888723318 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418888723374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418888723374 : Closed e2418888723374 ∧ code e2418888723374 = 11214981745582 := by decide
theorem cert_e2418888723374 : check e2418888723374 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418888723386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418888723386 : Closed e2418888723386 ∧ code e2418888723386 = 11214981745594 := by decide
theorem cert_e2418888723386 : check e2418888723386 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418888723414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418888723414 : Closed e2418888723414 ∧ code e2418888723414 = 11214981745622 := by decide
theorem cert_e2418888723414 : check e2418888723414 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418888723418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418888723418 : Closed e2418888723418 ∧ code e2418888723418 = 11214981745626 := by decide
theorem cert_e2418888723418 : check e2418888723418 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2418888723694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418888723694 : Closed e2418888723694 ∧ code e2418888723694 = 11214981745902 := by decide
theorem cert_e2418888723694 : check e2418888723694 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .identityHead = true := by decide
def e2418888723702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418888723702 : Closed e2418888723702 ∧ code e2418888723702 = 11214981745910 := by decide
theorem cert_e2418888723702 : check e2418888723702 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[],[.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2418888724078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418888724078 : Closed e2418888724078 ∧ code e2418888724078 = 11214981746286 := by decide
theorem cert_e2418888724078 : check e2418888724078 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418888724090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418888724090 : Closed e2418888724090 ∧ code e2418888724090 = 11214981746298 := by decide
theorem cert_e2418888724090 : check e2418888724090 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418888724278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418888724278 : Closed e2418888724278 ∧ code e2418888724278 = 11214981746486 := by decide
theorem cert_e2418888724278 : check e2418888724278 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418888724282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418888724282 : Closed e2418888724282 ∧ code e2418888724282 = 11214981746490 := by decide
theorem cert_e2418888724282 : check e2418888724282 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418888730030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2418888730030 : Closed e2418888730030 ∧ code e2418888730030 = 11214981752238 := by decide
theorem cert_e2418888730030 : check e2418888730030 [[],[]] .sourceHead = true := by decide
def e2418888730042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2418888730042 : Closed e2418888730042 ∧ code e2418888730042 = 11214981752250 := by decide
theorem cert_e2418888730042 : check e2418888730042 [[],[]] .sourceHead = true := by decide
def e2418888730090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2418888730090 : Closed e2418888730090 ∧ code e2418888730090 = 11214981752298 := by decide
theorem cert_e2418888730090 : check e2418888730090 [[],[]] .sourceHead = true := by decide
def e2418888730222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2418888730222 : Closed e2418888730222 ∧ code e2418888730222 = 11214981752430 := by decide
theorem cert_e2418888730222 : check e2418888730222 [[],[]] .sourceHead = true := by decide
def e2418888730234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2418888730234 : Closed e2418888730234 ∧ code e2418888730234 = 11214981752442 := by decide
theorem cert_e2418888730234 : check e2418888730234 [[],[]] .sourceHead = true := by decide
def e2418888730522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2418888730522 : Closed e2418888730522 ∧ code e2418888730522 = 11214981752730 := by decide
theorem cert_e2418888730522 : check e2418888730522 [[],[]] .sourceHead = true := by decide
def e2418888733398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2418888733398 : Closed e2418888733398 ∧ code e2418888733398 = 11214981755606 := by decide
theorem cert_e2418888733398 : check e2418888733398 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418888733402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2418888733402 : Closed e2418888733402 ∧ code e2418888733402 = 11214981755610 := by decide
theorem cert_e2418888733402 : check e2418888733402 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418888733418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2418888733418 : Closed e2418888733418 ∧ code e2418888733418 = 11214981755626 := by decide
theorem cert_e2418888733418 : check e2418888733418 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418888733494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2418888733494 : Closed e2418888733494 ∧ code e2418888733494 = 11214981755702 := by decide
theorem cert_e2418888733494 : check e2418888733494 [[],[],[.under,.under,.left]] .chain = true := by decide
end Blc.Floor43
