import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2408452621730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408452621730 : Closed e2408452621730 ∧ code e2408452621730 = 11204545643938 := by decide
private def t_e2408452621730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408452621730 : ¬ IsSelfInterpreter e2408452621730 :=
  wSource (t := t_e2408452621730) (replay_sound (ps := []) (t := e2408452621730) (by decide)) (by decide)
def e2408452621838 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408452621838 : Closed e2408452621838 ∧ code e2408452621838 = 11204545644046 := by decide
theorem cert_e2408452621838 : check e2408452621838 [[]] .width = true := by decide
def e2408452621850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408452621850 : Closed e2408452621850 ∧ code e2408452621850 = 11204545644058 := by decide
private def t_e2408452621850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408452621850 : ¬ IsSelfInterpreter e2408452621850 :=
  wSource (t := t_e2408452621850) (replay_sound (ps := []) (t := e2408452621850) (by decide)) (by decide)
def e2408452621922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408452621922 : Closed e2408452621922 ∧ code e2408452621922 = 11204545644130 := by decide
theorem cert_e2408452621922 : check e2408452621922 [[]] .width = true := by decide
def e2408452666906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452666906 : Closed e2408452666906 ∧ code e2408452666906 = 11204545689114 := by decide
private def t_e2408452666906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452666906 : ¬ IsSelfInterpreter e2408452666906 :=
  wSource (t := t_e2408452666906) (replay_sound (ps := []) (t := e2408452666906) (by decide)) (by decide)
def e2408452667930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408452667930 : Closed e2408452667930 ∧ code e2408452667930 = 11204545690138 := by decide
private def t_e2408452667930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408452667930 : ¬ IsSelfInterpreter e2408452667930 :=
  wSource (t := t_e2408452667930) (replay_sound (ps := []) (t := e2408452667930) (by decide)) (by decide)
def e2408456239130 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456239130 : Closed e2408456239130 ∧ code e2408456239130 = 11204549261338 := by decide
theorem cert_e2408456239130 : check e2408456239130 [[]] .width = true := by decide
def e2408456247322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456247322 : Closed e2408456247322 ∧ code e2408456247322 = 11204549269530 := by decide
theorem cert_e2408456247322 : check e2408456247322 [[]] .width = true := by decide
def e2408456304666 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456304666 : Closed e2408456304666 ∧ code e2408456304666 = 11204549326874 := by decide
theorem cert_e2408456304666 : check e2408456304666 [[]] .width = true := by decide
def e2408456316954 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456316954 : Closed e2408456316954 ∧ code e2408456316954 = 11204549339162 := by decide
theorem cert_e2408456316954 : check e2408456316954 [[]] .width = true := by decide
def e2408456318490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408456318490 : Closed e2408456318490 ∧ code e2408456318490 = 11204549340698 := by decide
private def t_e2408456318490 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408456318490 : ¬ IsSelfInterpreter e2408456318490 :=
  wSource (t := t_e2408456318490) (replay_sound (ps := []) (t := e2408456318490) (by decide)) (by decide)
def e2408456345626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456345626 : Closed e2408456345626 ∧ code e2408456345626 = 11204549367834 := by decide
theorem cert_e2408456345626 : check e2408456345626 [[]] .width = true := by decide
def e2408456349722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456349722 : Closed e2408456349722 ∧ code e2408456349722 = 11204549371930 := by decide
theorem cert_e2408456349722 : check e2408456349722 [[]] .width = true := by decide
def e2408456351258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408456351258 : Closed e2408456351258 ∧ code e2408456351258 = 11204549373466 := by decide
private def t_e2408456351258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408456351258 : ¬ IsSelfInterpreter e2408456351258 :=
  wSource (t := t_e2408456351258) (replay_sound (ps := []) (t := e2408456351258) (by decide)) (by decide)
def e2408456353306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408456353306 : Closed e2408456353306 ∧ code e2408456353306 = 11204549375514 := by decide
private def t_e2408456353306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408456353306 : ¬ IsSelfInterpreter e2408456353306 :=
  wSource (t := t_e2408456353306) (replay_sound (ps := []) (t := e2408456353306) (by decide)) (by decide)
def e2408456632346 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456632346 : Closed e2408456632346 ∧ code e2408456632346 = 11204549654554 := by decide
theorem cert_e2408456632346 : check e2408456632346 [[]] .width = true := by decide
def e2408456640538 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408456640538 : Closed e2408456640538 ∧ code e2408456640538 = 11204549662746 := by decide
theorem cert_e2408456640538 : check e2408456640538 [[]] .width = true := by decide
def e2408456974534 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408456974534 : Closed e2408456974534 ∧ code e2408456974534 = 11204549996742 := by decide
theorem cert_e2408456974534 : check e2408456974534 [[]] .width = true := by decide
def e2408457025562 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408457025562 : Closed e2408457025562 ∧ code e2408457025562 = 11204550047770 := by decide
theorem cert_e2408457025562 : check e2408457025562 [[]] .width = true := by decide
def e2408457037850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408457037850 : Closed e2408457037850 ∧ code e2408457037850 = 11204550060058 := by decide
theorem cert_e2408457037850 : check e2408457037850 [[]] .width = true := by decide
def e2408457039386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408457039386 : Closed e2408457039386 ∧ code e2408457039386 = 11204550061594 := by decide
private def t_e2408457039386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408457039386 : ¬ IsSelfInterpreter e2408457039386 :=
  wSource (t := t_e2408457039386) (replay_sound (ps := []) (t := e2408457039386) (by decide)) (by decide)
def e2408457142298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408457142298 : Closed e2408457142298 ∧ code e2408457142298 = 11204550164506 := by decide
theorem cert_e2408457142298 : check e2408457142298 [[]] .width = true := by decide
def e2408457142390 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408457142390 : Closed e2408457142390 ∧ code e2408457142390 = 11204550164598 := by decide
theorem cert_e2408457142390 : check e2408457142390 [[]] .width = true := by decide
def e2408457142634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408457142634 : Closed e2408457142634 ∧ code e2408457142634 = 11204550164842 := by decide
theorem cert_e2408457142634 : check e2408457142634 [[]] .width = true := by decide
def e2408457142682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408457142682 : Closed e2408457142682 ∧ code e2408457142682 = 11204550164890 := by decide
theorem cert_e2408457142682 : check e2408457142682 [[]] .width = true := by decide
def e2408457143690 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408457143690 : Closed e2408457143690 ∧ code e2408457143690 = 11204550165898 := by decide
theorem cert_e2408457143690 : check e2408457143690 [[]] .width = true := by decide
def e2408457143714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408457143714 : Closed e2408457143714 ∧ code e2408457143714 = 11204550165922 := by decide
private def t_e2408457143714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408457143714 : ¬ IsSelfInterpreter e2408457143714 :=
  wSource (t := t_e2408457143714) (replay_sound (ps := []) (t := e2408457143714) (by decide)) (by decide)
def e2408457143822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408457143822 : Closed e2408457143822 ∧ code e2408457143822 = 11204550166030 := by decide
theorem cert_e2408457143822 : check e2408457143822 [[]] .width = true := by decide
def e2408457143834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408457143834 : Closed e2408457143834 ∧ code e2408457143834 = 11204550166042 := by decide
private def t_e2408457143834 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408457143834 : ¬ IsSelfInterpreter e2408457143834 :=
  wSource (t := t_e2408457143834) (replay_sound (ps := []) (t := e2408457143834) (by decide)) (by decide)
def e2408457143906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408457143906 : Closed e2408457143906 ∧ code e2408457143906 = 11204550166114 := by decide
theorem cert_e2408457143906 : check e2408457143906 [[]] .width = true := by decide
def e2408457203910 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408457203910 : Closed e2408457203910 ∧ code e2408457203910 = 11204550226118 := by decide
theorem cert_e2408457203910 : check e2408457203910 [[]] .width = true := by decide
def e2408457230362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408457230362 : Closed e2408457230362 ∧ code e2408457230362 = 11204550252570 := by decide
theorem cert_e2408457230362 : check e2408457230362 [[]] .width = true := by decide
def e2408457234458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408457234458 : Closed e2408457234458 ∧ code e2408457234458 = 11204550256666 := by decide
theorem cert_e2408457234458 : check e2408457234458 [[]] .width = true := by decide
def e2408457235994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408457235994 : Closed e2408457235994 ∧ code e2408457235994 = 11204550258202 := by decide
private def t_e2408457235994 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408457235994 : ¬ IsSelfInterpreter e2408457235994 :=
  wSource (t := t_e2408457235994) (replay_sound (ps := []) (t := e2408457235994) (by decide)) (by decide)
def e2408457238042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408457238042 : Closed e2408457238042 ∧ code e2408457238042 = 11204550260250 := by decide
private def t_e2408457238042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408457238042 : ¬ IsSelfInterpreter e2408457238042 :=
  wSource (t := t_e2408457238042) (replay_sound (ps := []) (t := e2408457238042) (by decide)) (by decide)
def e2408457273370 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408457273370 : Closed e2408457273370 ∧ code e2408457273370 = 11204550295578 := by decide
theorem cert_e2408457273370 : check e2408457273370 [[]] .width = true := by decide
def e2408457273462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408457273462 : Closed e2408457273462 ∧ code e2408457273462 = 11204550295670 := by decide
theorem cert_e2408457273462 : check e2408457273462 [[]] .width = true := by decide
def e2408457273706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408457273706 : Closed e2408457273706 ∧ code e2408457273706 = 11204550295914 := by decide
theorem cert_e2408457273706 : check e2408457273706 [[]] .width = true := by decide
def e2408457273754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408457273754 : Closed e2408457273754 ∧ code e2408457273754 = 11204550295962 := by decide
theorem cert_e2408457273754 : check e2408457273754 [[]] .width = true := by decide
def e2408457274762 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408457274762 : Closed e2408457274762 ∧ code e2408457274762 = 11204550296970 := by decide
theorem cert_e2408457274762 : check e2408457274762 [[]] .width = true := by decide
def e2408457274786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408457274786 : Closed e2408457274786 ∧ code e2408457274786 = 11204550296994 := by decide
private def t_e2408457274786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408457274786 : ¬ IsSelfInterpreter e2408457274786 :=
  wSource (t := t_e2408457274786) (replay_sound (ps := []) (t := e2408457274786) (by decide)) (by decide)
def e2408457274894 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408457274894 : Closed e2408457274894 ∧ code e2408457274894 = 11204550297102 := by decide
theorem cert_e2408457274894 : check e2408457274894 [[]] .width = true := by decide
def e2408457274906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408457274906 : Closed e2408457274906 ∧ code e2408457274906 = 11204550297114 := by decide
private def t_e2408457274906 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408457274906 : ¬ IsSelfInterpreter e2408457274906 :=
  wSource (t := t_e2408457274906) (replay_sound (ps := []) (t := e2408457274906) (by decide)) (by decide)
def e2408457274978 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408457274978 : Closed e2408457274978 ∧ code e2408457274978 = 11204550297186 := by decide
theorem cert_e2408457274978 : check e2408457274978 [[]] .width = true := by decide
def e2408463120410 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408463120410 : Closed e2408463120410 ∧ code e2408463120410 = 11204556142618 := by decide
theorem cert_e2408463120410 : check e2408463120410 [[]] .width = true := by decide
def e2408463132698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408463132698 : Closed e2408463132698 ∧ code e2408463132698 = 11204556154906 := by decide
theorem cert_e2408463132698 : check e2408463132698 [[]] .width = true := by decide
def e2408463134234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408463134234 : Closed e2408463134234 ∧ code e2408463134234 = 11204556156442 := by decide
private def t_e2408463134234 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408463134234 : ¬ IsSelfInterpreter e2408463134234 :=
  wSource (t := t_e2408463134234) (replay_sound (ps := []) (t := e2408463134234) (by decide)) (by decide)
def e2408463181850 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408463181850 : Closed e2408463181850 ∧ code e2408463181850 = 11204556204058 := by decide
theorem cert_e2408463181850 : check e2408463181850 [[]] .width = true := by decide
def e2408463183386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408463183386 : Closed e2408463183386 ∧ code e2408463183386 = 11204556205594 := by decide
private def t_e2408463183386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408463183386 : ¬ IsSelfInterpreter e2408463183386 :=
  wSource (t := t_e2408463183386) (replay_sound (ps := []) (t := e2408463183386) (by decide)) (by decide)
def e2408463186458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408463186458 : Closed e2408463186458 ∧ code e2408463186458 = 11204556208666 := by decide
private def t_e2408463186458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408463186458 : ¬ IsSelfInterpreter e2408463186458 :=
  wSource (t := t_e2408463186458) (replay_sound (ps := []) (t := e2408463186458) (by decide)) (by decide)
def e2408463265990 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408463265990 : Closed e2408463265990 ∧ code e2408463265990 = 11204556288198 := by decide
theorem cert_e2408463265990 : check e2408463265990 [[]] .width = true := by decide
def e2408463317018 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408463317018 : Closed e2408463317018 ∧ code e2408463317018 = 11204556339226 := by decide
theorem cert_e2408463317018 : check e2408463317018 [[]] .width = true := by decide
def e2408463329306 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408463329306 : Closed e2408463329306 ∧ code e2408463329306 = 11204556351514 := by decide
theorem cert_e2408463329306 : check e2408463329306 [[]] .width = true := by decide
def e2408463330842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408463330842 : Closed e2408463330842 ∧ code e2408463330842 = 11204556353050 := by decide
private def t_e2408463330842 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408463330842 : ¬ IsSelfInterpreter e2408463330842 :=
  wSource (t := t_e2408463330842) (replay_sound (ps := []) (t := e2408463330842) (by decide)) (by decide)
def e2408463433754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408463433754 : Closed e2408463433754 ∧ code e2408463433754 = 11204556455962 := by decide
theorem cert_e2408463433754 : check e2408463433754 [[]] .width = true := by decide
def e2408463433846 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408463433846 : Closed e2408463433846 ∧ code e2408463433846 = 11204556456054 := by decide
theorem cert_e2408463433846 : check e2408463433846 [[]] .width = true := by decide
def e2408463434090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408463434090 : Closed e2408463434090 ∧ code e2408463434090 = 11204556456298 := by decide
theorem cert_e2408463434090 : check e2408463434090 [[]] .width = true := by decide
def e2408463434138 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408463434138 : Closed e2408463434138 ∧ code e2408463434138 = 11204556456346 := by decide
theorem cert_e2408463434138 : check e2408463434138 [[]] .width = true := by decide
def e2408463435146 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408463435146 : Closed e2408463435146 ∧ code e2408463435146 = 11204556457354 := by decide
theorem cert_e2408463435146 : check e2408463435146 [[]] .width = true := by decide
def e2408463435170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408463435170 : Closed e2408463435170 ∧ code e2408463435170 = 11204556457378 := by decide
private def t_e2408463435170 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408463435170 : ¬ IsSelfInterpreter e2408463435170 :=
  wSource (t := t_e2408463435170) (replay_sound (ps := []) (t := e2408463435170) (by decide)) (by decide)
def e2408463435278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408463435278 : Closed e2408463435278 ∧ code e2408463435278 = 11204556457486 := by decide
theorem cert_e2408463435278 : check e2408463435278 [[]] .width = true := by decide
def e2408463435290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408463435290 : Closed e2408463435290 ∧ code e2408463435290 = 11204556457498 := by decide
private def t_e2408463435290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408463435290 : ¬ IsSelfInterpreter e2408463435290 :=
  wSource (t := t_e2408463435290) (replay_sound (ps := []) (t := e2408463435290) (by decide)) (by decide)
def e2408463435362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408463435362 : Closed e2408463435362 ∧ code e2408463435362 = 11204556457570 := by decide
theorem cert_e2408463435362 : check e2408463435362 [[]] .width = true := by decide
def e2408463610054 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408463610054 : Closed e2408463610054 ∧ code e2408463610054 = 11204556632262 := by decide
theorem cert_e2408463610054 : check e2408463610054 [[]] .width = true := by decide
def e2408463624218 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408463624218 : Closed e2408463624218 ∧ code e2408463624218 = 11204556646426 := by decide
theorem cert_e2408463624218 : check e2408463624218 [[]] .width = true := by decide
def e2408463625754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408463625754 : Closed e2408463625754 ∧ code e2408463625754 = 11204556647962 := by decide
private def t_e2408463625754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408463625754 : ¬ IsSelfInterpreter e2408463625754 :=
  wSource (t := t_e2408463625754) (replay_sound (ps := []) (t := e2408463625754) (by decide)) (by decide)
def e2408463628826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408463628826 : Closed e2408463628826 ∧ code e2408463628826 = 11204556651034 := by decide
private def t_e2408463628826 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408463628826 : ¬ IsSelfInterpreter e2408463628826 :=
  wSource (t := t_e2408463628826) (replay_sound (ps := []) (t := e2408463628826) (by decide)) (by decide)
def e2408463630362 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408463630362 : Closed e2408463630362 ∧ code e2408463630362 = 11204556652570 := by decide
theorem cert_e2408463630362 : check e2408463630362 [[]] .width = true := by decide
def e2408463630454 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408463630454 : Closed e2408463630454 ∧ code e2408463630454 = 11204556652662 := by decide
theorem cert_e2408463630454 : check e2408463630454 [[]] .width = true := by decide
def e2408463630698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408463630698 : Closed e2408463630698 ∧ code e2408463630698 = 11204556652906 := by decide
theorem cert_e2408463630698 : check e2408463630698 [[]] .width = true := by decide
def e2408463630746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408463630746 : Closed e2408463630746 ∧ code e2408463630746 = 11204556652954 := by decide
theorem cert_e2408463630746 : check e2408463630746 [[]] .width = true := by decide
def e2408463631754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408463631754 : Closed e2408463631754 ∧ code e2408463631754 = 11204556653962 := by decide
theorem cert_e2408463631754 : check e2408463631754 [[]] .width = true := by decide
def e2408463631778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408463631778 : Closed e2408463631778 ∧ code e2408463631778 = 11204556653986 := by decide
private def t_e2408463631778 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408463631778 : ¬ IsSelfInterpreter e2408463631778 :=
  wSource (t := t_e2408463631778) (replay_sound (ps := []) (t := e2408463631778) (by decide)) (by decide)
def e2408463631886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408463631886 : Closed e2408463631886 ∧ code e2408463631886 = 11204556654094 := by decide
theorem cert_e2408463631886 : check e2408463631886 [[]] .width = true := by decide
def e2408463631898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408463631898 : Closed e2408463631898 ∧ code e2408463631898 = 11204556654106 := by decide
private def t_e2408463631898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408463631898 : ¬ IsSelfInterpreter e2408463631898 :=
  wSource (t := t_e2408463631898) (replay_sound (ps := []) (t := e2408463631898) (by decide)) (by decide)
def e2408463631970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408463631970 : Closed e2408463631970 ∧ code e2408463631970 = 11204556654178 := by decide
theorem cert_e2408463631970 : check e2408463631970 [[]] .width = true := by decide
def e2408466069530 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466069530 : Closed e2408466069530 ∧ code e2408466069530 = 11204559091738 := by decide
theorem cert_e2408466069530 : check e2408466069530 [[]] .width = true := by decide
def e2408466077722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466077722 : Closed e2408466077722 ∧ code e2408466077722 = 11204559099930 := by decide
theorem cert_e2408466077722 : check e2408466077722 [[]] .width = true := by decide
def e2408466569242 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466569242 : Closed e2408466569242 ∧ code e2408466569242 = 11204559591450 := by decide
theorem cert_e2408466569242 : check e2408466569242 [[]] .width = true := by decide
def e2408466573338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466573338 : Closed e2408466573338 ∧ code e2408466573338 = 11204559595546 := by decide
theorem cert_e2408466573338 : check e2408466573338 [[]] .width = true := by decide
def e2408466574874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466574874 : Closed e2408466574874 ∧ code e2408466574874 = 11204559597082 := by decide
private def t_e2408466574874 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466574874 : ¬ IsSelfInterpreter e2408466574874 :=
  wSource (t := t_e2408466574874) (replay_sound (ps := []) (t := e2408466574874) (by decide)) (by decide)
def e2408466576922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466576922 : Closed e2408466576922 ∧ code e2408466576922 = 11204559599130 := by decide
private def t_e2408466576922 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466576922 : ¬ IsSelfInterpreter e2408466576922 :=
  wSource (t := t_e2408466576922) (replay_sound (ps := []) (t := e2408466576922) (by decide)) (by decide)
def e2408466589722 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466589722 : Closed e2408466589722 ∧ code e2408466589722 = 11204559611930 := by decide
theorem cert_e2408466589722 : check e2408466589722 [[]] .width = true := by decide
def e2408466591258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466591258 : Closed e2408466591258 ∧ code e2408466591258 = 11204559613466 := by decide
private def t_e2408466591258 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466591258 : ¬ IsSelfInterpreter e2408466591258 :=
  wSource (t := t_e2408466591258) (replay_sound (ps := []) (t := e2408466591258) (by decide)) (by decide)
def e2408466594330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466594330 : Closed e2408466594330 ∧ code e2408466594330 = 11204559616538 := by decide
private def t_e2408466594330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466594330 : ¬ IsSelfInterpreter e2408466594330 :=
  wSource (t := t_e2408466594330) (replay_sound (ps := []) (t := e2408466594330) (by decide)) (by decide)
def e2408466601498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466601498 : Closed e2408466601498 ∧ code e2408466601498 = 11204559623706 := by decide
private def t_e2408466601498 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466601498 : ¬ IsSelfInterpreter e2408466601498 :=
  wSource (t := t_e2408466601498) (replay_sound (ps := []) (t := e2408466601498) (by decide)) (by decide)
def e2408466602522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466602522 : Closed e2408466602522 ∧ code e2408466602522 = 11204559624730 := by decide
private def t_e2408466602522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466602522 : ¬ IsSelfInterpreter e2408466602522 :=
  wSource (t := t_e2408466602522) (replay_sound (ps := []) (t := e2408466602522) (by decide)) (by decide)
def e2408466641094 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408466641094 : Closed e2408466641094 ∧ code e2408466641094 = 11204559663302 := by decide
theorem cert_e2408466641094 : check e2408466641094 [[]] .width = true := by decide
def e2408466667546 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466667546 : Closed e2408466667546 ∧ code e2408466667546 = 11204559689754 := by decide
theorem cert_e2408466667546 : check e2408466667546 [[]] .width = true := by decide
def e2408466671642 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466671642 : Closed e2408466671642 ∧ code e2408466671642 = 11204559693850 := by decide
theorem cert_e2408466671642 : check e2408466671642 [[]] .width = true := by decide
def e2408466673178 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466673178 : Closed e2408466673178 ∧ code e2408466673178 = 11204559695386 := by decide
private def t_e2408466673178 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466673178 : ¬ IsSelfInterpreter e2408466673178 :=
  wSource (t := t_e2408466673178) (replay_sound (ps := []) (t := e2408466673178) (by decide)) (by decide)
def e2408466675226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466675226 : Closed e2408466675226 ∧ code e2408466675226 = 11204559697434 := by decide
private def t_e2408466675226 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466675226 : ¬ IsSelfInterpreter e2408466675226 :=
  wSource (t := t_e2408466675226) (replay_sound (ps := []) (t := e2408466675226) (by decide)) (by decide)
def e2408466710554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408466710554 : Closed e2408466710554 ∧ code e2408466710554 = 11204559732762 := by decide
theorem cert_e2408466710554 : check e2408466710554 [[]] .width = true := by decide
def e2408466710646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408466710646 : Closed e2408466710646 ∧ code e2408466710646 = 11204559732854 := by decide
theorem cert_e2408466710646 : check e2408466710646 [[]] .width = true := by decide
def e2408466710890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408466710890 : Closed e2408466710890 ∧ code e2408466710890 = 11204559733098 := by decide
theorem cert_e2408466710890 : check e2408466710890 [[]] .width = true := by decide
def e2408466710938 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408466710938 : Closed e2408466710938 ∧ code e2408466710938 = 11204559733146 := by decide
theorem cert_e2408466710938 : check e2408466710938 [[]] .width = true := by decide
def e2408466711946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408466711946 : Closed e2408466711946 ∧ code e2408466711946 = 11204559734154 := by decide
theorem cert_e2408466711946 : check e2408466711946 [[]] .width = true := by decide
def e2408466711970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408466711970 : Closed e2408466711970 ∧ code e2408466711970 = 11204559734178 := by decide
private def t_e2408466711970 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408466711970 : ¬ IsSelfInterpreter e2408466711970 :=
  wSource (t := t_e2408466711970) (replay_sound (ps := []) (t := e2408466711970) (by decide)) (by decide)
def e2408466712078 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408466712078 : Closed e2408466712078 ∧ code e2408466712078 = 11204559734286 := by decide
theorem cert_e2408466712078 : check e2408466712078 [[]] .width = true := by decide
def e2408466712090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408466712090 : Closed e2408466712090 ∧ code e2408466712090 = 11204559734298 := by decide
private def t_e2408466712090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408466712090 : ¬ IsSelfInterpreter e2408466712090 :=
  wSource (t := t_e2408466712090) (replay_sound (ps := []) (t := e2408466712090) (by decide)) (by decide)
def e2408466712162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408466712162 : Closed e2408466712162 ∧ code e2408466712162 = 11204559734370 := by decide
theorem cert_e2408466712162 : check e2408466712162 [[]] .width = true := by decide
def e2408466755782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2408466755782 : Closed e2408466755782 ∧ code e2408466755782 = 11204559777990 := by decide
theorem cert_e2408466755782 : check e2408466755782 [[]] .width = true := by decide
def e2408466769946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408466769946 : Closed e2408466769946 ∧ code e2408466769946 = 11204559792154 := by decide
theorem cert_e2408466769946 : check e2408466769946 [[]] .width = true := by decide
def e2408466771482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466771482 : Closed e2408466771482 ∧ code e2408466771482 = 11204559793690 := by decide
private def t_e2408466771482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466771482 : ¬ IsSelfInterpreter e2408466771482 :=
  wSource (t := t_e2408466771482) (replay_sound (ps := []) (t := e2408466771482) (by decide)) (by decide)
def e2408466774554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466774554 : Closed e2408466774554 ∧ code e2408466774554 = 11204559796762 := by decide
private def t_e2408466774554 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466774554 : ¬ IsSelfInterpreter e2408466774554 :=
  wSource (t := t_e2408466774554) (replay_sound (ps := []) (t := e2408466774554) (by decide)) (by decide)
def e2408466776090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2408466776090 : Closed e2408466776090 ∧ code e2408466776090 = 11204559798298 := by decide
theorem cert_e2408466776090 : check e2408466776090 [[]] .width = true := by decide
def e2408466776182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2408466776182 : Closed e2408466776182 ∧ code e2408466776182 = 11204559798390 := by decide
theorem cert_e2408466776182 : check e2408466776182 [[]] .width = true := by decide
def e2408466776426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2408466776426 : Closed e2408466776426 ∧ code e2408466776426 = 11204559798634 := by decide
theorem cert_e2408466776426 : check e2408466776426 [[]] .width = true := by decide
def e2408466776474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2408466776474 : Closed e2408466776474 ∧ code e2408466776474 = 11204559798682 := by decide
theorem cert_e2408466776474 : check e2408466776474 [[]] .width = true := by decide
def e2408466777482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2408466777482 : Closed e2408466777482 ∧ code e2408466777482 = 11204559799690 := by decide
theorem cert_e2408466777482 : check e2408466777482 [[]] .width = true := by decide
def e2408466777506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2408466777506 : Closed e2408466777506 ∧ code e2408466777506 = 11204559799714 := by decide
private def t_e2408466777506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2408466777506 : ¬ IsSelfInterpreter e2408466777506 :=
  wSource (t := t_e2408466777506) (replay_sound (ps := []) (t := e2408466777506) (by decide)) (by decide)
def e2408466777614 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2408466777614 : Closed e2408466777614 ∧ code e2408466777614 = 11204559799822 := by decide
theorem cert_e2408466777614 : check e2408466777614 [[]] .width = true := by decide
def e2408466777626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2408466777626 : Closed e2408466777626 ∧ code e2408466777626 = 11204559799834 := by decide
private def t_e2408466777626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2408466777626 : ¬ IsSelfInterpreter e2408466777626 :=
  wSource (t := t_e2408466777626) (replay_sound (ps := []) (t := e2408466777626) (by decide)) (by decide)
def e2408466777698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2408466777698 : Closed e2408466777698 ∧ code e2408466777698 = 11204559799906 := by decide
theorem cert_e2408466777698 : check e2408466777698 [[]] .width = true := by decide
def e2408466822682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466822682 : Closed e2408466822682 ∧ code e2408466822682 = 11204559844890 := by decide
private def t_e2408466822682 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466822682 : ¬ IsSelfInterpreter e2408466822682 :=
  wSource (t := t_e2408466822682) (replay_sound (ps := []) (t := e2408466822682) (by decide)) (by decide)
def e2408466823706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408466823706 : Closed e2408466823706 ∧ code e2408466823706 = 11204559845914 := by decide
private def t_e2408466823706 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408466823706 : ¬ IsSelfInterpreter e2408466823706 :=
  wSource (t := t_e2408466823706) (replay_sound (ps := []) (t := e2408466823706) (by decide)) (by decide)
def e2408520396142 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2408520396142 : Closed e2408520396142 ∧ code e2408520396142 = 11204613418350 := by decide
theorem cert_e2408520396142 : check e2408520396142 [[],[]] .chain = true := by decide
def e2408520396150 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2408520396150 : Closed e2408520396150 ∧ code e2408520396150 = 11204613418358 := by decide
theorem cert_e2408520396150 : check e2408520396150 [[],[]] .chain = true := by decide
def e2408520396206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2408520396206 : Closed e2408520396206 ∧ code e2408520396206 = 11204613418414 := by decide
theorem cert_e2408520396206 : check e2408520396206 [[],[]] .chain = true := by decide
def e2408520396218 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2408520396218 : Closed e2408520396218 ∧ code e2408520396218 = 11204613418426 := by decide
theorem cert_e2408520396218 : check e2408520396218 [[],[]] .chain = true := by decide
def e2408520396246 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2408520396246 : Closed e2408520396246 ∧ code e2408520396246 = 11204613418454 := by decide
theorem cert_e2408520396246 : check e2408520396246 [[],[]] .chain = true := by decide
def e2408520396250 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2408520396250 : Closed e2408520396250 ∧ code e2408520396250 = 11204613418458 := by decide
theorem cert_e2408520396250 : check e2408520396250 [[],[]] .chain = true := by decide
def e2408520396462 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2408520396462 : Closed e2408520396462 ∧ code e2408520396462 = 11204613418670 := by decide
theorem cert_e2408520396462 : check e2408520396462 [[],[]] .chain = true := by decide
def e2408520396474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2408520396474 : Closed e2408520396474 ∧ code e2408520396474 = 11204613418682 := by decide
theorem cert_e2408520396474 : check e2408520396474 [[],[]] .chain = true := by decide
def e2408520396522 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2408520396522 : Closed e2408520396522 ∧ code e2408520396522 = 11204613418730 := by decide
theorem cert_e2408520396522 : check e2408520396522 [[],[]] .chain = true := by decide
def e2408520396630 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2408520396630 : Closed e2408520396630 ∧ code e2408520396630 = 11204613418838 := by decide
theorem cert_e2408520396630 : check e2408520396630 [[],[]] .chain = true := by decide
def e2408520396634 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2408520396634 : Closed e2408520396634 ∧ code e2408520396634 = 11204613418842 := by decide
theorem cert_e2408520396634 : check e2408520396634 [[],[]] .chain = true := by decide
def e2408520396650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2408520396650 : Closed e2408520396650 ∧ code e2408520396650 = 11204613418858 := by decide
theorem cert_e2408520396650 : check e2408520396650 [[],[]] .chain = true := by decide
def e2408520397678 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2408520397678 : Closed e2408520397678 ∧ code e2408520397678 = 11204613419886 := by decide
theorem cert_e2408520397678 : check e2408520397678 [[],[]] .chain = true := by decide
def e2408520397686 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2408520397686 : Closed e2408520397686 ∧ code e2408520397686 = 11204613419894 := by decide
theorem cert_e2408520397686 : check e2408520397686 [[],[]] .chain = true := by decide
def e2408520397742 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2408520397742 : Closed e2408520397742 ∧ code e2408520397742 = 11204613419950 := by decide
theorem cert_e2408520397742 : check e2408520397742 [[],[]] .chain = true := by decide
def e2408520397754 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2408520397754 : Closed e2408520397754 ∧ code e2408520397754 = 11204613419962 := by decide
theorem cert_e2408520397754 : check e2408520397754 [[],[]] .chain = true := by decide
def e2408520397782 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2408520397782 : Closed e2408520397782 ∧ code e2408520397782 = 11204613419990 := by decide
theorem cert_e2408520397782 : check e2408520397782 [[],[]] .chain = true := by decide
def e2408520397786 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2408520397786 : Closed e2408520397786 ∧ code e2408520397786 = 11204613419994 := by decide
theorem cert_e2408520397786 : check e2408520397786 [[],[]] .chain = true := by decide
def e2408520398062 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2408520398062 : Closed e2408520398062 ∧ code e2408520398062 = 11204613420270 := by decide
theorem cert_e2408520398062 : check e2408520398062 [[],[]] .chain = true := by decide
def e2408520398070 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2408520398070 : Closed e2408520398070 ∧ code e2408520398070 = 11204613420278 := by decide
theorem cert_e2408520398070 : check e2408520398070 [[],[]] .chain = true := by decide
def e2408520398446 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2408520398446 : Closed e2408520398446 ∧ code e2408520398446 = 11204613420654 := by decide
theorem cert_e2408520398446 : check e2408520398446 [[],[]] .chain = true := by decide
def e2408520398458 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2408520398458 : Closed e2408520398458 ∧ code e2408520398458 = 11204613420666 := by decide
theorem cert_e2408520398458 : check e2408520398458 [[],[]] .chain = true := by decide
def e2408520398646 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2408520398646 : Closed e2408520398646 ∧ code e2408520398646 = 11204613420854 := by decide
theorem cert_e2408520398646 : check e2408520398646 [[],[]] .chain = true := by decide
def e2408520398650 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2408520398650 : Closed e2408520398650 ∧ code e2408520398650 = 11204613420858 := by decide
theorem cert_e2408520398650 : check e2408520398650 [[],[]] .chain = true := by decide
def e2408520399278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2408520399278 : Closed e2408520399278 ∧ code e2408520399278 = 11204613421486 := by decide
theorem cert_e2408520399278 : check e2408520399278 [[],[]] .chain = true := by decide
def e2408520399290 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2408520399290 : Closed e2408520399290 ∧ code e2408520399290 = 11204613421498 := by decide
theorem cert_e2408520399290 : check e2408520399290 [[],[]] .chain = true := by decide
def e2408520399338 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2408520399338 : Closed e2408520399338 ∧ code e2408520399338 = 11204613421546 := by decide
theorem cert_e2408520399338 : check e2408520399338 [[],[]] .chain = true := by decide
def e2408520399470 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2408520399470 : Closed e2408520399470 ∧ code e2408520399470 = 11204613421678 := by decide
theorem cert_e2408520399470 : check e2408520399470 [[],[]] .chain = true := by decide
def e2408520399482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2408520399482 : Closed e2408520399482 ∧ code e2408520399482 = 11204613421690 := by decide
theorem cert_e2408520399482 : check e2408520399482 [[],[]] .chain = true := by decide
def e2408520399770 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2408520399770 : Closed e2408520399770 ∧ code e2408520399770 = 11204613421978 := by decide
theorem cert_e2408520399770 : check e2408520399770 [[],[]] .chain = true := by decide
def e2408520400086 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2408520400086 : Closed e2408520400086 ∧ code e2408520400086 = 11204613422294 := by decide
theorem cert_e2408520400086 : check e2408520400086 [[],[]] .chain = true := by decide
def e2408520400090 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2408520400090 : Closed e2408520400090 ∧ code e2408520400090 = 11204613422298 := by decide
theorem cert_e2408520400090 : check e2408520400090 [[],[]] .chain = true := by decide
def e2408520400106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2408520400106 : Closed e2408520400106 ∧ code e2408520400106 = 11204613422314 := by decide
theorem cert_e2408520400106 : check e2408520400106 [[],[]] .chain = true := by decide
def e2408520400182 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2408520400182 : Closed e2408520400182 ∧ code e2408520400182 = 11204613422390 := by decide
theorem cert_e2408520400182 : check e2408520400182 [[],[]] .chain = true := by decide
def e2408520400186 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2408520400186 : Closed e2408520400186 ∧ code e2408520400186 = 11204613422394 := by decide
theorem cert_e2408520400186 : check e2408520400186 [[],[]] .chain = true := by decide
def e2408520400282 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2408520400282 : Closed e2408520400282 ∧ code e2408520400282 = 11204613422490 := by decide
theorem cert_e2408520400282 : check e2408520400282 [[],[]] .chain = true := by decide
def e2408520403822 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2408520403822 : Closed e2408520403822 ∧ code e2408520403822 = 11204613426030 := by decide
theorem cert_e2408520403822 : check e2408520403822 [[],[]] .chain = true := by decide
def e2408520403830 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2408520403830 : Closed e2408520403830 ∧ code e2408520403830 = 11204613426038 := by decide
theorem cert_e2408520403830 : check e2408520403830 [[],[]] .chain = true := by decide
def e2408520403886 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2408520403886 : Closed e2408520403886 ∧ code e2408520403886 = 11204613426094 := by decide
theorem cert_e2408520403886 : check e2408520403886 [[],[]] .chain = true := by decide
def e2408520403898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2408520403898 : Closed e2408520403898 ∧ code e2408520403898 = 11204613426106 := by decide
theorem cert_e2408520403898 : check e2408520403898 [[],[]] .chain = true := by decide
def e2408520403926 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2408520403926 : Closed e2408520403926 ∧ code e2408520403926 = 11204613426134 := by decide
theorem cert_e2408520403926 : check e2408520403926 [[],[]] .chain = true := by decide
def e2408520403930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2408520403930 : Closed e2408520403930 ∧ code e2408520403930 = 11204613426138 := by decide
theorem cert_e2408520403930 : check e2408520403930 [[],[]] .chain = true := by decide
def e2408520404206 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2408520404206 : Closed e2408520404206 ∧ code e2408520404206 = 11204613426414 := by decide
theorem cert_e2408520404206 : check e2408520404206 [[],[]] .chain = true := by decide
def e2408520404214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2408520404214 : Closed e2408520404214 ∧ code e2408520404214 = 11204613426422 := by decide
theorem cert_e2408520404214 : check e2408520404214 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2408452621730
#print axioms Blc.Floor43.cert_e2408452621850
#print axioms Blc.Floor43.cert_e2408452666906
#print axioms Blc.Floor43.cert_e2408452667930
#print axioms Blc.Floor43.cert_e2408456318490
#print axioms Blc.Floor43.cert_e2408456351258
#print axioms Blc.Floor43.cert_e2408456353306
#print axioms Blc.Floor43.cert_e2408457039386
#print axioms Blc.Floor43.cert_e2408457143714
#print axioms Blc.Floor43.cert_e2408457143834
#print axioms Blc.Floor43.cert_e2408457235994
#print axioms Blc.Floor43.cert_e2408457238042
#print axioms Blc.Floor43.cert_e2408457274786
#print axioms Blc.Floor43.cert_e2408457274906
#print axioms Blc.Floor43.cert_e2408463134234
#print axioms Blc.Floor43.cert_e2408463183386
#print axioms Blc.Floor43.cert_e2408463186458
#print axioms Blc.Floor43.cert_e2408463330842
#print axioms Blc.Floor43.cert_e2408463435170
#print axioms Blc.Floor43.cert_e2408463435290
#print axioms Blc.Floor43.cert_e2408463625754
#print axioms Blc.Floor43.cert_e2408463628826
#print axioms Blc.Floor43.cert_e2408463631778
#print axioms Blc.Floor43.cert_e2408463631898
#print axioms Blc.Floor43.cert_e2408466574874
#print axioms Blc.Floor43.cert_e2408466576922
#print axioms Blc.Floor43.cert_e2408466591258
#print axioms Blc.Floor43.cert_e2408466594330
#print axioms Blc.Floor43.cert_e2408466601498
#print axioms Blc.Floor43.cert_e2408466602522
#print axioms Blc.Floor43.cert_e2408466673178
#print axioms Blc.Floor43.cert_e2408466675226
#print axioms Blc.Floor43.cert_e2408466711970
#print axioms Blc.Floor43.cert_e2408466712090
#print axioms Blc.Floor43.cert_e2408466771482
#print axioms Blc.Floor43.cert_e2408466774554
#print axioms Blc.Floor43.cert_e2408466777506
#print axioms Blc.Floor43.cert_e2408466777626
#print axioms Blc.Floor43.cert_e2408466822682
#print axioms Blc.Floor43.cert_e2408466823706
