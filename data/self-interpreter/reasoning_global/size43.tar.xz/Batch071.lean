import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759404083066 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e759404083066 : Closed e759404083066 ∧ code e759404083066 = 9555497105274 := by decide
theorem cert_e759404083066 : check e759404083066 [] .sourceHead = true := by decide
def e759404083118 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e759404083118 : Closed e759404083118 ∧ code e759404083118 = 9555497105326 := by decide
theorem cert_e759404083118 : check e759404083118 [] .sourceHead = true := by decide
def e759404083126 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e759404083126 : Closed e759404083126 ∧ code e759404083126 = 9555497105334 := by decide
theorem cert_e759404083126 : check e759404083126 [] .sourceHead = true := by decide
def e759404083130 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e759404083130 : Closed e759404083130 ∧ code e759404083130 = 9555497105338 := by decide
theorem cert_e759404083130 : check e759404083130 [] .sourceHead = true := by decide
def e759404083934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e759404083934 : Closed e759404083934 ∧ code e759404083934 = 9555497106142 := by decide
theorem cert_e759404083934 : check e759404083934 [] .sourceHead = true := by decide
def e759404083950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e759404083950 : Closed e759404083950 ∧ code e759404083950 = 9555497106158 := by decide
theorem cert_e759404083950 : check e759404083950 [] .sourceHead = true := by decide
def e759404083958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e759404083958 : Closed e759404083958 ∧ code e759404083958 = 9555497106166 := by decide
theorem cert_e759404083958 : check e759404083958 [] .sourceHead = true := by decide
def e759404084062 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e759404084062 : Closed e759404084062 ∧ code e759404084062 = 9555497106270 := by decide
theorem cert_e759404084062 : check e759404084062 [] .sourceHead = true := by decide
def e759404084090 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e759404084090 : Closed e759404084090 ∧ code e759404084090 = 9555497106298 := by decide
theorem cert_e759404084090 : check e759404084090 [] .sourceHead = true := by decide
def e759404084142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e759404084142 : Closed e759404084142 ∧ code e759404084142 = 9555497106350 := by decide
theorem cert_e759404084142 : check e759404084142 [] .sourceHead = true := by decide
def e759404084154 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e759404084154 : Closed e759404084154 ∧ code e759404084154 = 9555497106362 := by decide
theorem cert_e759404084154 : check e759404084154 [] .sourceHead = true := by decide
def e759404084182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e759404084182 : Closed e759404084182 ∧ code e759404084182 = 9555497106390 := by decide
theorem cert_e759404084182 : check e759404084182 [] .sourceHead = true := by decide
def e759404084186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e759404084186 : Closed e759404084186 ∧ code e759404084186 = 9555497106394 := by decide
theorem cert_e759404084186 : check e759404084186 [] .sourceHead = true := by decide
def e759404084574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e759404084574 : Closed e759404084574 ∧ code e759404084574 = 9555497106782 := by decide
theorem cert_e759404084574 : check e759404084574 [] .sourceHead = true := by decide
def e759404084590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e759404084590 : Closed e759404084590 ∧ code e759404084590 = 9555497106798 := by decide
theorem cert_e759404084590 : check e759404084590 [] .sourceHead = true := by decide
def e759404084598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e759404084598 : Closed e759404084598 ∧ code e759404084598 = 9555497106806 := by decide
theorem cert_e759404084598 : check e759404084598 [] .sourceHead = true := by decide
def e759404084602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e759404084602 : Closed e759404084602 ∧ code e759404084602 = 9555497106810 := by decide
theorem cert_e759404084602 : check e759404084602 [] .sourceHead = true := by decide
def e759404084654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e759404084654 : Closed e759404084654 ∧ code e759404084654 = 9555497106862 := by decide
theorem cert_e759404084654 : check e759404084654 [] .sourceHead = true := by decide
def e759404084666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e759404084666 : Closed e759404084666 ∧ code e759404084666 = 9555497106874 := by decide
theorem cert_e759404084666 : check e759404084666 [] .sourceHead = true := by decide
def e759404084694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e759404084694 : Closed e759404084694 ∧ code e759404084694 = 9555497106902 := by decide
theorem cert_e759404084694 : check e759404084694 [] .sourceHead = true := by decide
def e759404084698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e759404084698 : Closed e759404084698 ∧ code e759404084698 = 9555497106906 := by decide
theorem cert_e759404084698 : check e759404084698 [] .sourceHead = true := by decide
def e759404084714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e759404084714 : Closed e759404084714 ∧ code e759404084714 = 9555497106922 := by decide
theorem cert_e759404084714 : check e759404084714 [] .sourceHead = true := by decide
def e759404084910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e759404084910 : Closed e759404084910 ∧ code e759404084910 = 9555497107118 := by decide
theorem cert_e759404084910 : check e759404084910 [] .sourceHead = true := by decide
def e759404084918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e759404084918 : Closed e759404084918 ∧ code e759404084918 = 9555497107126 := by decide
theorem cert_e759404084918 : check e759404084918 [] .sourceHead = true := by decide
def e759404084922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e759404084922 : Closed e759404084922 ∧ code e759404084922 = 9555497107130 := by decide
theorem cert_e759404084922 : check e759404084922 [] .sourceHead = true := by decide
def e759404084950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e759404084950 : Closed e759404084950 ∧ code e759404084950 = 9555497107158 := by decide
theorem cert_e759404084950 : check e759404084950 [] .sourceHead = true := by decide
def e759404084954 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e759404084954 : Closed e759404084954 ∧ code e759404084954 = 9555497107162 := by decide
theorem cert_e759404084954 : check e759404084954 [] .sourceHead = true := by decide
def e759404084970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e759404084970 : Closed e759404084970 ∧ code e759404084970 = 9555497107178 := by decide
theorem cert_e759404084970 : check e759404084970 [] .sourceHead = true := by decide
def e759404088798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e759404088798 : Closed e759404088798 ∧ code e759404088798 = 9555497111006 := by decide
theorem cert_e759404088798 : check e759404088798 [] .sourceHead = true := by decide
def e759404088814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e759404088814 : Closed e759404088814 ∧ code e759404088814 = 9555497111022 := by decide
theorem cert_e759404088814 : check e759404088814 [] .sourceHead = true := by decide
def e759404089054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e759404089054 : Closed e759404089054 ∧ code e759404089054 = 9555497111262 := by decide
theorem cert_e759404089054 : check e759404089054 [] .sourceHead = true := by decide
def e759404089070 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e759404089070 : Closed e759404089070 ∧ code e759404089070 = 9555497111278 := by decide
theorem cert_e759404089070 : check e759404089070 [] .sourceHead = true := by decide
def e759404089078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e759404089078 : Closed e759404089078 ∧ code e759404089078 = 9555497111286 := by decide
theorem cert_e759404089078 : check e759404089078 [] .sourceHead = true := by decide
def e759404089182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e759404089182 : Closed e759404089182 ∧ code e759404089182 = 9555497111390 := by decide
theorem cert_e759404089182 : check e759404089182 [] .sourceHead = true := by decide
def e759404089198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e759404089198 : Closed e759404089198 ∧ code e759404089198 = 9555497111406 := by decide
theorem cert_e759404089198 : check e759404089198 [] .sourceHead = true := by decide
def e759404089206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e759404089206 : Closed e759404089206 ∧ code e759404089206 = 9555497111414 := by decide
theorem cert_e759404089206 : check e759404089206 [] .sourceHead = true := by decide
def e759404089210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e759404089210 : Closed e759404089210 ∧ code e759404089210 = 9555497111418 := by decide
theorem cert_e759404089210 : check e759404089210 [] .sourceHead = true := by decide
def e759404089262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e759404089262 : Closed e759404089262 ∧ code e759404089262 = 9555497111470 := by decide
theorem cert_e759404089262 : check e759404089262 [] .sourceHead = true := by decide
def e759404089270 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e759404089270 : Closed e759404089270 ∧ code e759404089270 = 9555497111478 := by decide
theorem cert_e759404089270 : check e759404089270 [] .sourceHead = true := by decide
def e759404089274 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e759404089274 : Closed e759404089274 ∧ code e759404089274 = 9555497111482 := by decide
theorem cert_e759404089274 : check e759404089274 [] .sourceHead = true := by decide
def e759404090334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e759404090334 : Closed e759404090334 ∧ code e759404090334 = 9555497112542 := by decide
theorem cert_e759404090334 : check e759404090334 [] .sourceHead = true := by decide
def e759404090350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e759404090350 : Closed e759404090350 ∧ code e759404090350 = 9555497112558 := by decide
theorem cert_e759404090350 : check e759404090350 [] .sourceHead = true := by decide
def e759404091870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e759404091870 : Closed e759404091870 ∧ code e759404091870 = 9555497114078 := by decide
theorem cert_e759404091870 : check e759404091870 [] .sourceHead = true := by decide
def e759404091886 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e759404091886 : Closed e759404091886 ∧ code e759404091886 = 9555497114094 := by decide
theorem cert_e759404091886 : check e759404091886 [] .sourceHead = true := by decide
def e759404091894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e759404091894 : Closed e759404091894 ∧ code e759404091894 = 9555497114102 := by decide
theorem cert_e759404091894 : check e759404091894 [] .sourceHead = true := by decide
def e759404092638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e759404092638 : Closed e759404092638 ∧ code e759404092638 = 9555497114846 := by decide
theorem cert_e759404092638 : check e759404092638 [] .sourceHead = true := by decide
def e759404092654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e759404092654 : Closed e759404092654 ∧ code e759404092654 = 9555497114862 := by decide
theorem cert_e759404092654 : check e759404092654 [] .sourceHead = true := by decide
def e759404092662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e759404092662 : Closed e759404092662 ∧ code e759404092662 = 9555497114870 := by decide
theorem cert_e759404092662 : check e759404092662 [] .sourceHead = true := by decide
def e759404092666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e759404092666 : Closed e759404092666 ∧ code e759404092666 = 9555497114874 := by decide
theorem cert_e759404092666 : check e759404092666 [] .sourceHead = true := by decide
def e759404093038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404093038 : Closed e759404093038 ∧ code e759404093038 = 9555497115246 := by decide
theorem cert_e759404093038 : check e759404093038 [] .sourceHead = true := by decide
def e759404093046 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e759404093046 : Closed e759404093046 ∧ code e759404093046 = 9555497115254 := by decide
theorem cert_e759404093046 : check e759404093046 [] .sourceHead = true := by decide
def e759404093050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404093050 : Closed e759404093050 ∧ code e759404093050 = 9555497115258 := by decide
theorem cert_e759404093050 : check e759404093050 [] .sourceHead = true := by decide
def e759404095198 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e759404095198 : Closed e759404095198 ∧ code e759404095198 = 9555497117406 := by decide
theorem cert_e759404095198 : check e759404095198 [] .sourceHead = true := by decide
def e759404095214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e759404095214 : Closed e759404095214 ∧ code e759404095214 = 9555497117422 := by decide
theorem cert_e759404095214 : check e759404095214 [] .sourceHead = true := by decide
def e759404095222 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e759404095222 : Closed e759404095222 ∧ code e759404095222 = 9555497117430 := by decide
theorem cert_e759404095222 : check e759404095222 [] .sourceHead = true := by decide
def e759404095326 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e759404095326 : Closed e759404095326 ∧ code e759404095326 = 9555497117534 := by decide
theorem cert_e759404095326 : check e759404095326 [] .sourceHead = true := by decide
def e759404095354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e759404095354 : Closed e759404095354 ∧ code e759404095354 = 9555497117562 := by decide
theorem cert_e759404095354 : check e759404095354 [] .sourceHead = true := by decide
def e759404095406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))))
theorem wire_e759404095406 : Closed e759404095406 ∧ code e759404095406 = 9555497117614 := by decide
theorem cert_e759404095406 : check e759404095406 [] .sourceHead = true := by decide
def e759404095418 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))))
theorem wire_e759404095418 : Closed e759404095418 ∧ code e759404095418 = 9555497117626 := by decide
theorem cert_e759404095418 : check e759404095418 [] .sourceHead = true := by decide
def e759404095446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e759404095446 : Closed e759404095446 ∧ code e759404095446 = 9555497117654 := by decide
theorem cert_e759404095446 : check e759404095446 [] .sourceHead = true := by decide
def e759404095450 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e759404095450 : Closed e759404095450 ∧ code e759404095450 = 9555497117658 := by decide
theorem cert_e759404095450 : check e759404095450 [] .sourceHead = true := by decide
def e759404095966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e759404095966 : Closed e759404095966 ∧ code e759404095966 = 9555497118174 := by decide
theorem cert_e759404095966 : check e759404095966 [] .sourceHead = true := by decide
def e759404095982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))))
theorem wire_e759404095982 : Closed e759404095982 ∧ code e759404095982 = 9555497118190 := by decide
theorem cert_e759404095982 : check e759404095982 [] .sourceHead = true := by decide
def e759404095990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e759404095990 : Closed e759404095990 ∧ code e759404095990 = 9555497118198 := by decide
theorem cert_e759404095990 : check e759404095990 [] .sourceHead = true := by decide
def e759404096734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e759404096734 : Closed e759404096734 ∧ code e759404096734 = 9555497118942 := by decide
theorem cert_e759404096734 : check e759404096734 [] .sourceHead = true := by decide
def e759404096762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e759404096762 : Closed e759404096762 ∧ code e759404096762 = 9555497118970 := by decide
theorem cert_e759404096762 : check e759404096762 [] .sourceHead = true := by decide
def e759404097134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404097134 : Closed e759404097134 ∧ code e759404097134 = 9555497119342 := by decide
theorem cert_e759404097134 : check e759404097134 [] .sourceHead = true := by decide
def e759404097146 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404097146 : Closed e759404097146 ∧ code e759404097146 = 9555497119354 := by decide
theorem cert_e759404097146 : check e759404097146 [] .sourceHead = true := by decide
def e759404097334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404097334 : Closed e759404097334 ∧ code e759404097334 = 9555497119542 := by decide
theorem cert_e759404097334 : check e759404097334 [] .sourceHead = true := by decide
def e759404097338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404097338 : Closed e759404097338 ∧ code e759404097338 = 9555497119546 := by decide
theorem cert_e759404097338 : check e759404097338 [] .sourceHead = true := by decide
def e759404098398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e759404098398 : Closed e759404098398 ∧ code e759404098398 = 9555497120606 := by decide
theorem cert_e759404098398 : check e759404098398 [] .sourceHead = true := by decide
def e759404098414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e759404098414 : Closed e759404098414 ∧ code e759404098414 = 9555497120622 := by decide
theorem cert_e759404098414 : check e759404098414 [] .sourceHead = true := by decide
def e759404098422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e759404098422 : Closed e759404098422 ∧ code e759404098422 = 9555497120630 := by decide
theorem cert_e759404098422 : check e759404098422 [] .sourceHead = true := by decide
def e759404098426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e759404098426 : Closed e759404098426 ∧ code e759404098426 = 9555497120634 := by decide
theorem cert_e759404098426 : check e759404098426 [] .sourceHead = true := by decide
def e759404098478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e759404098478 : Closed e759404098478 ∧ code e759404098478 = 9555497120686 := by decide
theorem cert_e759404098478 : check e759404098478 [] .sourceHead = true := by decide
def e759404098490 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e759404098490 : Closed e759404098490 ∧ code e759404098490 = 9555497120698 := by decide
theorem cert_e759404098490 : check e759404098490 [] .sourceHead = true := by decide
def e759404098518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e759404098518 : Closed e759404098518 ∧ code e759404098518 = 9555497120726 := by decide
theorem cert_e759404098518 : check e759404098518 [] .sourceHead = true := by decide
def e759404098522 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e759404098522 : Closed e759404098522 ∧ code e759404098522 = 9555497120730 := by decide
theorem cert_e759404098522 : check e759404098522 [] .sourceHead = true := by decide
def e759404098538 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e759404098538 : Closed e759404098538 ∧ code e759404098538 = 9555497120746 := by decide
theorem cert_e759404098538 : check e759404098538 [] .sourceHead = true := by decide
def e759404098782 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e759404098782 : Closed e759404098782 ∧ code e759404098782 = 9555497120990 := by decide
theorem cert_e759404098782 : check e759404098782 [] .sourceHead = true := by decide
def e759404098798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e759404098798 : Closed e759404098798 ∧ code e759404098798 = 9555497121006 := by decide
theorem cert_e759404098798 : check e759404098798 [] .sourceHead = true := by decide
def e759404098806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e759404098806 : Closed e759404098806 ∧ code e759404098806 = 9555497121014 := by decide
theorem cert_e759404098806 : check e759404098806 [] .sourceHead = true := by decide
def e759404098810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e759404098810 : Closed e759404098810 ∧ code e759404098810 = 9555497121018 := by decide
theorem cert_e759404098810 : check e759404098810 [] .sourceHead = true := by decide
def e759404099182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404099182 : Closed e759404099182 ∧ code e759404099182 = 9555497121390 := by decide
theorem cert_e759404099182 : check e759404099182 [] .sourceHead = true := by decide
def e759404099194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404099194 : Closed e759404099194 ∧ code e759404099194 = 9555497121402 := by decide
theorem cert_e759404099194 : check e759404099194 [] .sourceHead = true := by decide
def e759404099382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404099382 : Closed e759404099382 ∧ code e759404099382 = 9555497121590 := by decide
theorem cert_e759404099382 : check e759404099382 [] .sourceHead = true := by decide
def e759404099386 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404099386 : Closed e759404099386 ∧ code e759404099386 = 9555497121594 := by decide
theorem cert_e759404099386 : check e759404099386 [] .sourceHead = true := by decide
def e759404099482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404099482 : Closed e759404099482 ∧ code e759404099482 = 9555497121690 := by decide
theorem cert_e759404099482 : check e759404099482 [] .sourceHead = true := by decide
def e759404100014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e759404100014 : Closed e759404100014 ∧ code e759404100014 = 9555497122222 := by decide
theorem cert_e759404100014 : check e759404100014 [] .sourceHead = true := by decide
def e759404100022 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e759404100022 : Closed e759404100022 ∧ code e759404100022 = 9555497122230 := by decide
theorem cert_e759404100022 : check e759404100022 [] .sourceHead = true := by decide
def e759404100026 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e759404100026 : Closed e759404100026 ∧ code e759404100026 = 9555497122234 := by decide
theorem cert_e759404100026 : check e759404100026 [] .sourceHead = true := by decide
def e759404100054 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e759404100054 : Closed e759404100054 ∧ code e759404100054 = 9555497122262 := by decide
theorem cert_e759404100054 : check e759404100054 [] .sourceHead = true := by decide
def e759404100058 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e759404100058 : Closed e759404100058 ∧ code e759404100058 = 9555497122266 := by decide
theorem cert_e759404100058 : check e759404100058 [] .sourceHead = true := by decide
def e759404100074 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e759404100074 : Closed e759404100074 ∧ code e759404100074 = 9555497122282 := by decide
theorem cert_e759404100074 : check e759404100074 [] .sourceHead = true := by decide
def e759404100206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404100206 : Closed e759404100206 ∧ code e759404100206 = 9555497122414 := by decide
theorem cert_e759404100206 : check e759404100206 [] .sourceHead = true := by decide
def e759404100214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e759404100214 : Closed e759404100214 ∧ code e759404100214 = 9555497122422 := by decide
theorem cert_e759404100214 : check e759404100214 [] .sourceHead = true := by decide
def e759404100218 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404100218 : Closed e759404100218 ∧ code e759404100218 = 9555497122426 := by decide
theorem cert_e759404100218 : check e759404100218 [] .sourceHead = true := by decide
def e759404100406 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404100406 : Closed e759404100406 ∧ code e759404100406 = 9555497122614 := by decide
theorem cert_e759404100406 : check e759404100406 [] .sourceHead = true := by decide
def e759404100410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404100410 : Closed e759404100410 ∧ code e759404100410 = 9555497122618 := by decide
theorem cert_e759404100410 : check e759404100410 [] .sourceHead = true := by decide
def e759404100506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404100506 : Closed e759404100506 ∧ code e759404100506 = 9555497122714 := by decide
theorem cert_e759404100506 : check e759404100506 [] .sourceHead = true := by decide
def e759404104558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e759404104558 : Closed e759404104558 ∧ code e759404104558 = 9555497126766 := by decide
theorem cert_e759404104558 : check e759404104558 [] .sourceHead = true := by decide
def e759404104566 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e759404104566 : Closed e759404104566 ∧ code e759404104566 = 9555497126774 := by decide
theorem cert_e759404104566 : check e759404104566 [] .sourceHead = true := by decide
def e759404104622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e759404104622 : Closed e759404104622 ∧ code e759404104622 = 9555497126830 := by decide
theorem cert_e759404104622 : check e759404104622 [] .sourceHead = true := by decide
def e759404104634 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e759404104634 : Closed e759404104634 ∧ code e759404104634 = 9555497126842 := by decide
theorem cert_e759404104634 : check e759404104634 [] .sourceHead = true := by decide
def e759404104662 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e759404104662 : Closed e759404104662 ∧ code e759404104662 = 9555497126870 := by decide
theorem cert_e759404104662 : check e759404104662 [] .sourceHead = true := by decide
def e759404104666 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e759404104666 : Closed e759404104666 ∧ code e759404104666 = 9555497126874 := by decide
theorem cert_e759404104666 : check e759404104666 [] .sourceHead = true := by decide
def e759404104942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e759404104942 : Closed e759404104942 ∧ code e759404104942 = 9555497127150 := by decide
theorem cert_e759404104942 : check e759404104942 [] .sourceHead = true := by decide
def e759404104950 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e759404104950 : Closed e759404104950 ∧ code e759404104950 = 9555497127158 := by decide
theorem cert_e759404104950 : check e759404104950 [] .sourceHead = true := by decide
def e759404105326 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e759404105326 : Closed e759404105326 ∧ code e759404105326 = 9555497127534 := by decide
theorem cert_e759404105326 : check e759404105326 [] .sourceHead = true := by decide
def e759404105338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e759404105338 : Closed e759404105338 ∧ code e759404105338 = 9555497127546 := by decide
theorem cert_e759404105338 : check e759404105338 [] .sourceHead = true := by decide
def e759404105526 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e759404105526 : Closed e759404105526 ∧ code e759404105526 = 9555497127734 := by decide
theorem cert_e759404105526 : check e759404105526 [] .sourceHead = true := by decide
def e759404105530 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e759404105530 : Closed e759404105530 ∧ code e759404105530 = 9555497127738 := by decide
theorem cert_e759404105530 : check e759404105530 [] .sourceHead = true := by decide
def e759404113374 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e759404113374 : Closed e759404113374 ∧ code e759404113374 = 9555497135582 := by decide
theorem cert_e759404113374 : check e759404113374 [] .sourceHead = true := by decide
def e759404113390 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e759404113390 : Closed e759404113390 ∧ code e759404113390 = 9555497135598 := by decide
theorem cert_e759404113390 : check e759404113390 [] .sourceHead = true := by decide
def e759404113630 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))
theorem wire_e759404113630 : Closed e759404113630 ∧ code e759404113630 = 9555497135838 := by decide
theorem cert_e759404113630 : check e759404113630 [] .sourceHead = true := by decide
def e759404113646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))
theorem wire_e759404113646 : Closed e759404113646 ∧ code e759404113646 = 9555497135854 := by decide
theorem cert_e759404113646 : check e759404113646 [] .sourceHead = true := by decide
def e759404113654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))
theorem wire_e759404113654 : Closed e759404113654 ∧ code e759404113654 = 9555497135862 := by decide
theorem cert_e759404113654 : check e759404113654 [] .sourceHead = true := by decide
def e759404113758 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e759404113758 : Closed e759404113758 ∧ code e759404113758 = 9555497135966 := by decide
theorem cert_e759404113758 : check e759404113758 [] .sourceHead = true := by decide
def e759404113774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))
theorem wire_e759404113774 : Closed e759404113774 ∧ code e759404113774 = 9555497135982 := by decide
theorem cert_e759404113774 : check e759404113774 [] .sourceHead = true := by decide
def e759404113782 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))
theorem wire_e759404113782 : Closed e759404113782 ∧ code e759404113782 = 9555497135990 := by decide
theorem cert_e759404113782 : check e759404113782 [] .sourceHead = true := by decide
def e759404113786 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e759404113786 : Closed e759404113786 ∧ code e759404113786 = 9555497135994 := by decide
theorem cert_e759404113786 : check e759404113786 [] .sourceHead = true := by decide
def e759404113838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e759404113838 : Closed e759404113838 ∧ code e759404113838 = 9555497136046 := by decide
theorem cert_e759404113838 : check e759404113838 [] .sourceHead = true := by decide
def e759404113846 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))
theorem wire_e759404113846 : Closed e759404113846 ∧ code e759404113846 = 9555497136054 := by decide
theorem cert_e759404113846 : check e759404113846 [] .sourceHead = true := by decide
def e759404113850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e759404113850 : Closed e759404113850 ∧ code e759404113850 = 9555497136058 := by decide
theorem cert_e759404113850 : check e759404113850 [] .sourceHead = true := by decide
def e759404114910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e759404114910 : Closed e759404114910 ∧ code e759404114910 = 9555497137118 := by decide
theorem cert_e759404114910 : check e759404114910 [] .sourceHead = true := by decide
def e759404114926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e759404114926 : Closed e759404114926 ∧ code e759404114926 = 9555497137134 := by decide
theorem cert_e759404114926 : check e759404114926 [] .sourceHead = true := by decide
def e759404116446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))
theorem wire_e759404116446 : Closed e759404116446 ∧ code e759404116446 = 9555497138654 := by decide
theorem cert_e759404116446 : check e759404116446 [] .sourceHead = true := by decide
def e759404116462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))
theorem wire_e759404116462 : Closed e759404116462 ∧ code e759404116462 = 9555497138670 := by decide
theorem cert_e759404116462 : check e759404116462 [] .sourceHead = true := by decide
def e759404116470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))
theorem wire_e759404116470 : Closed e759404116470 ∧ code e759404116470 = 9555497138678 := by decide
theorem cert_e759404116470 : check e759404116470 [] .sourceHead = true := by decide
def e759404117214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e759404117214 : Closed e759404117214 ∧ code e759404117214 = 9555497139422 := by decide
theorem cert_e759404117214 : check e759404117214 [] .sourceHead = true := by decide
def e759404117230 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))
theorem wire_e759404117230 : Closed e759404117230 ∧ code e759404117230 = 9555497139438 := by decide
theorem cert_e759404117230 : check e759404117230 [] .sourceHead = true := by decide
def e759404117238 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))
theorem wire_e759404117238 : Closed e759404117238 ∧ code e759404117238 = 9555497139446 := by decide
theorem cert_e759404117238 : check e759404117238 [] .sourceHead = true := by decide
def e759404117242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e759404117242 : Closed e759404117242 ∧ code e759404117242 = 9555497139450 := by decide
theorem cert_e759404117242 : check e759404117242 [] .sourceHead = true := by decide
def e759404117614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e759404117614 : Closed e759404117614 ∧ code e759404117614 = 9555497139822 := by decide
theorem cert_e759404117614 : check e759404117614 [] .sourceHead = true := by decide
def e759404117622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))
theorem wire_e759404117622 : Closed e759404117622 ∧ code e759404117622 = 9555497139830 := by decide
theorem cert_e759404117622 : check e759404117622 [] .sourceHead = true := by decide
def e759404117626 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e759404117626 : Closed e759404117626 ∧ code e759404117626 = 9555497139834 := by decide
theorem cert_e759404117626 : check e759404117626 [] .sourceHead = true := by decide
def e759404140254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e759404140254 : Closed e759404140254 ∧ code e759404140254 = 9555497162462 := by decide
theorem cert_e759404140254 : check e759404140254 [] .sourceHead = true := by decide
def e759404140270 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))
theorem wire_e759404140270 : Closed e759404140270 ∧ code e759404140270 = 9555497162478 := by decide
theorem cert_e759404140270 : check e759404140270 [] .sourceHead = true := by decide
def e759404140278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e759404140278 : Closed e759404140278 ∧ code e759404140278 = 9555497162486 := by decide
theorem cert_e759404140278 : check e759404140278 [] .sourceHead = true := by decide
def e759404140382 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e759404140382 : Closed e759404140382 ∧ code e759404140382 = 9555497162590 := by decide
theorem cert_e759404140382 : check e759404140382 [] .sourceHead = true := by decide
def e759404140410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e759404140410 : Closed e759404140410 ∧ code e759404140410 = 9555497162618 := by decide
theorem cert_e759404140410 : check e759404140410 [] .sourceHead = true := by decide
def e759404140462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))
theorem wire_e759404140462 : Closed e759404140462 ∧ code e759404140462 = 9555497162670 := by decide
theorem cert_e759404140462 : check e759404140462 [] .sourceHead = true := by decide
def e759404140474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))
theorem wire_e759404140474 : Closed e759404140474 ∧ code e759404140474 = 9555497162682 := by decide
theorem cert_e759404140474 : check e759404140474 [] .sourceHead = true := by decide
def e759404140502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e759404140502 : Closed e759404140502 ∧ code e759404140502 = 9555497162710 := by decide
theorem cert_e759404140502 : check e759404140502 [] .sourceHead = true := by decide
def e759404140506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e759404140506 : Closed e759404140506 ∧ code e759404140506 = 9555497162714 := by decide
theorem cert_e759404140506 : check e759404140506 [] .sourceHead = true := by decide
def e759404141022 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e759404141022 : Closed e759404141022 ∧ code e759404141022 = 9555497163230 := by decide
theorem cert_e759404141022 : check e759404141022 [] .sourceHead = true := by decide
def e759404141038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))
theorem wire_e759404141038 : Closed e759404141038 ∧ code e759404141038 = 9555497163246 := by decide
theorem cert_e759404141038 : check e759404141038 [] .sourceHead = true := by decide
def e759404141046 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e759404141046 : Closed e759404141046 ∧ code e759404141046 = 9555497163254 := by decide
theorem cert_e759404141046 : check e759404141046 [] .sourceHead = true := by decide
def e759404141790 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e759404141790 : Closed e759404141790 ∧ code e759404141790 = 9555497163998 := by decide
theorem cert_e759404141790 : check e759404141790 [] .sourceHead = true := by decide
def e759404141818 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e759404141818 : Closed e759404141818 ∧ code e759404141818 = 9555497164026 := by decide
theorem cert_e759404141818 : check e759404141818 [] .sourceHead = true := by decide
def e759404142190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))
theorem wire_e759404142190 : Closed e759404142190 ∧ code e759404142190 = 9555497164398 := by decide
theorem cert_e759404142190 : check e759404142190 [] .sourceHead = true := by decide
def e759404142202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))
theorem wire_e759404142202 : Closed e759404142202 ∧ code e759404142202 = 9555497164410 := by decide
theorem cert_e759404142202 : check e759404142202 [] .sourceHead = true := by decide
def e759404142390 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e759404142390 : Closed e759404142390 ∧ code e759404142390 = 9555497164598 := by decide
theorem cert_e759404142390 : check e759404142390 [] .sourceHead = true := by decide
def e759404142394 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e759404142394 : Closed e759404142394 ∧ code e759404142394 = 9555497164602 := by decide
theorem cert_e759404142394 : check e759404142394 [] .sourceHead = true := by decide
def e759404153694 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e759404153694 : Closed e759404153694 ∧ code e759404153694 = 9555497175902 := by decide
theorem cert_e759404153694 : check e759404153694 [] .sourceHead = true := by decide
def e759404153710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759404153710 : Closed e759404153710 ∧ code e759404153710 = 9555497175918 := by decide
theorem cert_e759404153710 : check e759404153710 [] .sourceHead = true := by decide
def e759404153718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759404153718 : Closed e759404153718 ∧ code e759404153718 = 9555497175926 := by decide
theorem cert_e759404153718 : check e759404153718 [] .sourceHead = true := by decide
def e759404153722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e759404153722 : Closed e759404153722 ∧ code e759404153722 = 9555497175930 := by decide
theorem cert_e759404153722 : check e759404153722 [] .sourceHead = true := by decide
def e759404153774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759404153774 : Closed e759404153774 ∧ code e759404153774 = 9555497175982 := by decide
theorem cert_e759404153774 : check e759404153774 [] .sourceHead = true := by decide
def e759404153786 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759404153786 : Closed e759404153786 ∧ code e759404153786 = 9555497175994 := by decide
theorem cert_e759404153786 : check e759404153786 [] .sourceHead = true := by decide
end Blc.Floor43
