import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407337698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422407337698 : Closed e2422407337698 ∧ code e2422407337698 = 11218500359906 := by decide
theorem cert_e2422407337698 : check e2422407337698 [[],[]] .chain = true := by decide
def e2422407337710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2422407337710 : Closed e2422407337710 ∧ code e2422407337710 = 11218500359918 := by decide
theorem cert_e2422407337710 : check e2422407337710 [[],[]] .sourceHead = true := by decide
def e2422407337838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2422407337838 : Closed e2422407337838 ∧ code e2422407337838 = 11218500360046 := by decide
theorem cert_e2422407337838 : check e2422407337838 [[],[]] .chain = true := by decide
def e2422407337846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2422407337846 : Closed e2422407337846 ∧ code e2422407337846 = 11218500360054 := by decide
theorem cert_e2422407337846 : check e2422407337846 [[],[]] .chain = true := by decide
def e2422407337866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407337866 : Closed e2422407337866 ∧ code e2422407337866 = 11218500360074 := by decide
theorem cert_e2422407337866 : check e2422407337866 [[],[]] .chain = true := by decide
def e2422407337890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407337890 : Closed e2422407337890 ∧ code e2422407337890 = 11218500360098 := by decide
theorem cert_e2422407337890 : check e2422407337890 [[],[]] .chain = true := by decide
def e2422407337902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2422407337902 : Closed e2422407337902 ∧ code e2422407337902 = 11218500360110 := by decide
theorem cert_e2422407337902 : check e2422407337902 [[],[]] .sourceHead = true := by decide
def e2422407337910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2422407337910 : Closed e2422407337910 ∧ code e2422407337910 = 11218500360118 := by decide
theorem cert_e2422407337910 : check e2422407337910 [[],[]] .chain = true := by decide
def e2422407337914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2422407337914 : Closed e2422407337914 ∧ code e2422407337914 = 11218500360122 := by decide
theorem cert_e2422407337914 : check e2422407337914 [[],[]] .sourceHead = true := by decide
def e2422407338046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2422407338046 : Closed e2422407338046 ∧ code e2422407338046 = 11218500360254 := by decide
theorem cert_e2422407338046 : check e2422407338046 [[],[]] .chain = true := by decide
def e2422407338466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407338466 : Closed e2422407338466 ∧ code e2422407338466 = 11218500360674 := by decide
theorem cert_e2422407338466 : check e2422407338466 [[],[]] .chain = true := by decide
def e2422407338478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2422407338478 : Closed e2422407338478 ∧ code e2422407338478 = 11218500360686 := by decide
theorem cert_e2422407338478 : check e2422407338478 [[],[]] .sourceHead = true := by decide
def e2422407339246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407339246 : Closed e2422407339246 ∧ code e2422407339246 = 11218500361454 := by decide
theorem cert_e2422407339246 : check e2422407339246 [[],[]] .chain = true := by decide
def e2422407339254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407339254 : Closed e2422407339254 ∧ code e2422407339254 = 11218500361462 := by decide
theorem cert_e2422407339254 : check e2422407339254 [[],[]] .chain = true := by decide
def e2422407339522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407339522 : Closed e2422407339522 ∧ code e2422407339522 = 11218500361730 := by decide
theorem cert_e2422407339522 : check e2422407339522 [[],[]] .chain = true := by decide
def e2422407339534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407339534 : Closed e2422407339534 ∧ code e2422407339534 = 11218500361742 := by decide
theorem cert_e2422407339534 : check e2422407339534 [[],[]] .chain = true := by decide
def e2422407339546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407339546 : Closed e2422407339546 ∧ code e2422407339546 = 11218500361754 := by decide
theorem cert_e2422407339546 : check e2422407339546 [[],[]] .sourceHead = true := by decide
def e2422407339618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407339618 : Closed e2422407339618 ∧ code e2422407339618 = 11218500361826 := by decide
theorem cert_e2422407339618 : check e2422407339618 [[],[]] .chain = true := by decide
def e2422407339630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407339630 : Closed e2422407339630 ∧ code e2422407339630 = 11218500361838 := by decide
theorem cert_e2422407339630 : check e2422407339630 [[],[]] .sourceHead = true := by decide
def e2422407339638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407339638 : Closed e2422407339638 ∧ code e2422407339638 = 11218500361846 := by decide
theorem cert_e2422407339638 : check e2422407339638 [[],[]] .chain = true := by decide
def e2422407339642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407339642 : Closed e2422407339642 ∧ code e2422407339642 = 11218500361850 := by decide
theorem cert_e2422407339642 : check e2422407339642 [[],[]] .sourceHead = true := by decide
def e2422407348350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e2422407348350 : Closed e2422407348350 ∧ code e2422407348350 = 11218500370558 := by decide
theorem cert_e2422407348350 : check e2422407348350 [[],[]] .chain = true := by decide
def e2422407349214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407349214 : Closed e2422407349214 ∧ code e2422407349214 = 11218500371422 := by decide
theorem cert_e2422407349214 : check e2422407349214 [[],[]] .chain = true := by decide
def e2422407349218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422407349218 : Closed e2422407349218 ∧ code e2422407349218 = 11218500371426 := by decide
theorem cert_e2422407349218 : check e2422407349218 [[],[]] .chain = true := by decide
def e2422407349230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407349230 : Closed e2422407349230 ∧ code e2422407349230 = 11218500371438 := by decide
theorem cert_e2422407349230 : check e2422407349230 [[],[]] .chain = true := by decide
def e2422407351150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407351150 : Closed e2422407351150 ∧ code e2422407351150 = 11218500373358 := by decide
theorem cert_e2422407351150 : check e2422407351150 [[],[]] .chain = true := by decide
def e2422407351158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407351158 : Closed e2422407351158 ∧ code e2422407351158 = 11218500373366 := by decide
theorem cert_e2422407351158 : check e2422407351158 [[],[]] .chain = true := by decide
def e2422407351214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407351214 : Closed e2422407351214 ∧ code e2422407351214 = 11218500373422 := by decide
theorem cert_e2422407351214 : check e2422407351214 [[],[]] .chain = true := by decide
def e2422407351226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407351226 : Closed e2422407351226 ∧ code e2422407351226 = 11218500373434 := by decide
theorem cert_e2422407351226 : check e2422407351226 [[],[]] .chain = true := by decide
def e2422407351254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407351254 : Closed e2422407351254 ∧ code e2422407351254 = 11218500373462 := by decide
theorem cert_e2422407351254 : check e2422407351254 [[],[]] .chain = true := by decide
def e2422407351258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407351258 : Closed e2422407351258 ∧ code e2422407351258 = 11218500373466 := by decide
theorem cert_e2422407351258 : check e2422407351258 [[],[]] .chain = true := by decide
def e2422407351534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407351534 : Closed e2422407351534 ∧ code e2422407351534 = 11218500373742 := by decide
theorem cert_e2422407351534 : check e2422407351534 [[],[]] .chain = true := by decide
def e2422407351542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407351542 : Closed e2422407351542 ∧ code e2422407351542 = 11218500373750 := by decide
theorem cert_e2422407351542 : check e2422407351542 [[],[]] .chain = true := by decide
def e2422407351918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407351918 : Closed e2422407351918 ∧ code e2422407351918 = 11218500374126 := by decide
theorem cert_e2422407351918 : check e2422407351918 [[],[]] .chain = true := by decide
def e2422407351930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407351930 : Closed e2422407351930 ∧ code e2422407351930 = 11218500374138 := by decide
theorem cert_e2422407351930 : check e2422407351930 [[],[]] .chain = true := by decide
def e2422407352070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407352070 : Closed e2422407352070 ∧ code e2422407352070 = 11218500374278 := by decide
theorem cert_e2422407352070 : check e2422407352070 [[],[]] .chain = true := by decide
def e2422407352094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 3))))))))
theorem wire_e2422407352094 : Closed e2422407352094 ∧ code e2422407352094 = 11218500374302 := by decide
theorem cert_e2422407352094 : check e2422407352094 [[],[]] .sourceHead = true := by decide
def e2422407352118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407352118 : Closed e2422407352118 ∧ code e2422407352118 = 11218500374326 := by decide
theorem cert_e2422407352118 : check e2422407352118 [[],[]] .chain = true := by decide
def e2422407352122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407352122 : Closed e2422407352122 ∧ code e2422407352122 = 11218500374330 := by decide
theorem cert_e2422407352122 : check e2422407352122 [[],[]] .chain = true := by decide
def e2422407356442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422407356442 : Closed e2422407356442 ∧ code e2422407356442 = 11218500378650 := by decide
theorem cert_e2422407356442 : check e2422407356442 [[],[]] .sourceHead = true := by decide
def e2422407356478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 4)))))))))
theorem wire_e2422407356478 : Closed e2422407356478 ∧ code e2422407356478 = 11218500378686 := by decide
theorem cert_e2422407356478 : check e2422407356478 [[],[]] .chain = true := by decide
def e2422407356526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422407356526 : Closed e2422407356526 ∧ code e2422407356526 = 11218500378734 := by decide
theorem cert_e2422407356526 : check e2422407356526 [[],[]] .chain = true := by decide
def e2422407356534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422407356534 : Closed e2422407356534 ∧ code e2422407356534 = 11218500378742 := by decide
theorem cert_e2422407356534 : check e2422407356534 [[],[]] .sourceHead = true := by decide
def e2422407356538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422407356538 : Closed e2422407356538 ∧ code e2422407356538 = 11218500378746 := by decide
theorem cert_e2422407356538 : check e2422407356538 [[],[]] .chain = true := by decide
def e2422407356778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422407356778 : Closed e2422407356778 ∧ code e2422407356778 = 11218500378986 := by decide
theorem cert_e2422407356778 : check e2422407356778 [[],[]] .sourceHead = true := by decide
def e2422407356814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422407356814 : Closed e2422407356814 ∧ code e2422407356814 = 11218500379022 := by decide
theorem cert_e2422407356814 : check e2422407356814 [[],[]] .chain = true := by decide
def e2422407356826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407356826 : Closed e2422407356826 ∧ code e2422407356826 = 11218500379034 := by decide
theorem cert_e2422407356826 : check e2422407356826 [[],[]] .sourceHead = true := by decide
def e2422407356870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422407356870 : Closed e2422407356870 ∧ code e2422407356870 = 11218500379078 := by decide
theorem cert_e2422407356870 : check e2422407356870 [[],[]] .chain = true := by decide
def e2422407356894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2422407356894 : Closed e2422407356894 ∧ code e2422407356894 = 11218500379102 := by decide
theorem cert_e2422407356894 : check e2422407356894 [[],[]] .sourceHead = true := by decide
def e2422407356898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422407356898 : Closed e2422407356898 ∧ code e2422407356898 = 11218500379106 := by decide
theorem cert_e2422407356898 : check e2422407356898 [[],[]] .chain = true := by decide
def e2422407356910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 2))))))))
theorem wire_e2422407356910 : Closed e2422407356910 ∧ code e2422407356910 = 11218500379118 := by decide
theorem cert_e2422407356910 : check e2422407356910 [[],[]] .chain = true := by decide
def e2422407356918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2422407356918 : Closed e2422407356918 ∧ code e2422407356918 = 11218500379126 := by decide
theorem cert_e2422407356918 : check e2422407356918 [[],[]] .sourceHead = true := by decide
def e2422407357834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2422407357834 : Closed e2422407357834 ∧ code e2422407357834 = 11218500380042 := by decide
theorem cert_e2422407357834 : check e2422407357834 [[],[]] .chain = true := by decide
def e2422407357858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2422407357858 : Closed e2422407357858 ∧ code e2422407357858 = 11218500380066 := by decide
theorem cert_e2422407357858 : check e2422407357858 [[],[]] .chain = true := by decide
def e2422407357870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407357870 : Closed e2422407357870 ∧ code e2422407357870 = 11218500380078 := by decide
theorem cert_e2422407357870 : check e2422407357870 [[],[]] .sourceHead = true := by decide
def e2422407357878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2422407357878 : Closed e2422407357878 ∧ code e2422407357878 = 11218500380086 := by decide
theorem cert_e2422407357878 : check e2422407357878 [[],[]] .chain = true := by decide
def e2422407357882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407357882 : Closed e2422407357882 ∧ code e2422407357882 = 11218500380090 := by decide
theorem cert_e2422407357882 : check e2422407357882 [[],[]] .sourceHead = true := by decide
def e2422407357910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422407357910 : Closed e2422407357910 ∧ code e2422407357910 = 11218500380118 := by decide
theorem cert_e2422407357910 : check e2422407357910 [[],[]] .chain = true := by decide
def e2422407357914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422407357914 : Closed e2422407357914 ∧ code e2422407357914 = 11218500380122 := by decide
theorem cert_e2422407357914 : check e2422407357914 [[],[]] .chain = true := by decide
def e2422407357930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407357930 : Closed e2422407357930 ∧ code e2422407357930 = 11218500380138 := by decide
theorem cert_e2422407357930 : check e2422407357930 [[],[]] .sourceHead = true := by decide
def e2422407357954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407357954 : Closed e2422407357954 ∧ code e2422407357954 = 11218500380162 := by decide
theorem cert_e2422407357954 : check e2422407357954 [[],[]] .chain = true := by decide
def e2422407357966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407357966 : Closed e2422407357966 ∧ code e2422407357966 = 11218500380174 := by decide
theorem cert_e2422407357966 : check e2422407357966 [[],[]] .chain = true := by decide
def e2422407357978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407357978 : Closed e2422407357978 ∧ code e2422407357978 = 11218500380186 := by decide
theorem cert_e2422407357978 : check e2422407357978 [[],[]] .sourceHead = true := by decide
def e2422407358050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407358050 : Closed e2422407358050 ∧ code e2422407358050 = 11218500380258 := by decide
theorem cert_e2422407358050 : check e2422407358050 [[],[]] .chain = true := by decide
def e2422407358062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407358062 : Closed e2422407358062 ∧ code e2422407358062 = 11218500380270 := by decide
theorem cert_e2422407358062 : check e2422407358062 [[],[]] .sourceHead = true := by decide
def e2422407358070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407358070 : Closed e2422407358070 ∧ code e2422407358070 = 11218500380278 := by decide
theorem cert_e2422407358070 : check e2422407358070 [[],[]] .chain = true := by decide
def e2422407358074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407358074 : Closed e2422407358074 ∧ code e2422407358074 = 11218500380282 := by decide
theorem cert_e2422407358074 : check e2422407358074 [[],[]] .sourceHead = true := by decide
def e2422407358214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407358214 : Closed e2422407358214 ∧ code e2422407358214 = 11218500380422 := by decide
theorem cert_e2422407358214 : check e2422407358214 [[],[]] .chain = true := by decide
def e2422407358238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407358238 : Closed e2422407358238 ∧ code e2422407358238 = 11218500380446 := by decide
theorem cert_e2422407358238 : check e2422407358238 [[],[]] .sourceHead = true := by decide
def e2422407358262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407358262 : Closed e2422407358262 ∧ code e2422407358262 = 11218500380470 := by decide
theorem cert_e2422407358262 : check e2422407358262 [[],[]] .chain = true := by decide
def e2422407358266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407358266 : Closed e2422407358266 ∧ code e2422407358266 = 11218500380474 := by decide
theorem cert_e2422407358266 : check e2422407358266 [[],[]] .chain = true := by decide
def e2422407358338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407358338 : Closed e2422407358338 ∧ code e2422407358338 = 11218500380546 := by decide
theorem cert_e2422407358338 : check e2422407358338 [[],[]] .sourceHead = true := by decide
def e2422407358350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407358350 : Closed e2422407358350 ∧ code e2422407358350 = 11218500380558 := by decide
theorem cert_e2422407358350 : check e2422407358350 [[],[]] .sourceHead = true := by decide
def e2422407358362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407358362 : Closed e2422407358362 ∧ code e2422407358362 = 11218500380570 := by decide
theorem cert_e2422407358362 : check e2422407358362 [[],[]] .sourceHead = true := by decide
def e2422407365102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.var 3))))) (.var 2))))))
theorem wire_e2422407365102 : Closed e2422407365102 ∧ code e2422407365102 = 11218500387310 := by decide
theorem cert_e2422407365102 : check e2422407365102 [[],[]] .chain = true := by decide
def e2422407365114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.lam (.var 5))))) (.var 0))))))
theorem wire_e2422407365114 : Closed e2422407365114 ∧ code e2422407365114 = 11218500387322 := by decide
theorem cert_e2422407365114 : check e2422407365114 [[],[]] .chain = true := by decide
def e2422407366254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407366254 : Closed e2422407366254 ∧ code e2422407366254 = 11218500388462 := by decide
theorem cert_e2422407366254 : check e2422407366254 [[],[]] .chain = true := by decide
def e2422407366266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407366266 : Closed e2422407366266 ∧ code e2422407366266 = 11218500388474 := by decide
theorem cert_e2422407366266 : check e2422407366266 [[],[]] .chain = true := by decide
def e2422407366430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2422407366430 : Closed e2422407366430 ∧ code e2422407366430 = 11218500388638 := by decide
theorem cert_e2422407366430 : check e2422407366430 [[],[]] .chain = true := by decide
def e2422407366598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 4)))) (.lam (.var 1)))))))
theorem wire_e2422407366598 : Closed e2422407366598 ∧ code e2422407366598 = 11218500388806 := by decide
theorem cert_e2422407366598 : check e2422407366598 [[],[]] .chain = true := by decide
def e2422407368238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422407368238 : Closed e2422407368238 ∧ code e2422407368238 = 11218500390446 := by decide
theorem cert_e2422407368238 : check e2422407368238 [[],[]] .chain = true := by decide
def e2422407368430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2422407368430 : Closed e2422407368430 ∧ code e2422407368430 = 11218500390638 := by decide
theorem cert_e2422407368430 : check e2422407368430 [[],[]] .chain = true := by decide
def e2422407368438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2422407368438 : Closed e2422407368438 ∧ code e2422407368438 = 11218500390646 := by decide
theorem cert_e2422407368438 : check e2422407368438 [[],[]] .chain = true := by decide
def e2422407368558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2422407368558 : Closed e2422407368558 ∧ code e2422407368558 = 11218500390766 := by decide
theorem cert_e2422407368558 : check e2422407368558 [[],[]] .chain = true := by decide
def e2422407368570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2422407368570 : Closed e2422407368570 ∧ code e2422407368570 = 11218500390778 := by decide
theorem cert_e2422407368570 : check e2422407368570 [[],[]] .chain = true := by decide
def e2422407368586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422407368586 : Closed e2422407368586 ∧ code e2422407368586 = 11218500390794 := by decide
theorem cert_e2422407368586 : check e2422407368586 [[],[]] .chain = true := by decide
def e2422407368630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2422407368630 : Closed e2422407368630 ∧ code e2422407368630 = 11218500390838 := by decide
theorem cert_e2422407368630 : check e2422407368630 [[],[]] .chain = true := by decide
def e2422407368634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2422407368634 : Closed e2422407368634 ∧ code e2422407368634 = 11218500390842 := by decide
theorem cert_e2422407368634 : check e2422407368634 [[],[]] .chain = true := by decide
def e2422407369502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407369502 : Closed e2422407369502 ∧ code e2422407369502 = 11218500391710 := by decide
theorem cert_e2422407369502 : check e2422407369502 [[],[]] .chain = true := by decide
def e2422407369670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407369670 : Closed e2422407369670 ∧ code e2422407369670 = 11218500391878 := by decide
theorem cert_e2422407369670 : check e2422407369670 [[],[]] .chain = true := by decide
def e2422407370814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2422407370814 : Closed e2422407370814 ∧ code e2422407370814 = 11218500393022 := by decide
theorem cert_e2422407370814 : check e2422407370814 [[],[]] .chain = true := by decide
def e2422407371234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407371234 : Closed e2422407371234 ∧ code e2422407371234 = 11218500393442 := by decide
theorem cert_e2422407371234 : check e2422407371234 [[],[]] .chain = true := by decide
def e2422407371246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407371246 : Closed e2422407371246 ∧ code e2422407371246 = 11218500393454 := by decide
theorem cert_e2422407371246 : check e2422407371246 [[],[]] .sourceHead = true := by decide
def e2422407372302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.lam (.lam (.var 2))))))))
theorem wire_e2422407372302 : Closed e2422407372302 ∧ code e2422407372302 = 11218500394510 := by decide
theorem cert_e2422407372302 : check e2422407372302 [[],[]] .chain = true := by decide
def e2422407372386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407372386 : Closed e2422407372386 ∧ code e2422407372386 = 11218500394594 := by decide
theorem cert_e2422407372386 : check e2422407372386 [[],[]] .chain = true := by decide
def e2422407372398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407372398 : Closed e2422407372398 ∧ code e2422407372398 = 11218500394606 := by decide
theorem cert_e2422407372398 : check e2422407372398 [[],[]] .sourceHead = true := by decide
def e2422407372410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407372410 : Closed e2422407372410 ∧ code e2422407372410 = 11218500394618 := by decide
theorem cert_e2422407372410 : check e2422407372410 [[],[]] .sourceHead = true := by decide
def e2422407376238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2422407376238 : Closed e2422407376238 ∧ code e2422407376238 = 11218500398446 := by decide
theorem cert_e2422407376238 : check e2422407376238 [[],[]] .chain = true := by decide
def e2422407376246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2422407376246 : Closed e2422407376246 ∧ code e2422407376246 = 11218500398454 := by decide
theorem cert_e2422407376246 : check e2422407376246 [[],[]] .chain = true := by decide
def e2422407376302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2422407376302 : Closed e2422407376302 ∧ code e2422407376302 = 11218500398510 := by decide
theorem cert_e2422407376302 : check e2422407376302 [[],[]] .chain = true := by decide
def e2422407376314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2422407376314 : Closed e2422407376314 ∧ code e2422407376314 = 11218500398522 := by decide
theorem cert_e2422407376314 : check e2422407376314 [[],[]] .chain = true := by decide
def e2422407376342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2422407376342 : Closed e2422407376342 ∧ code e2422407376342 = 11218500398550 := by decide
theorem cert_e2422407376342 : check e2422407376342 [[],[]] .chain = true := by decide
def e2422407376346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2422407376346 : Closed e2422407376346 ∧ code e2422407376346 = 11218500398554 := by decide
theorem cert_e2422407376346 : check e2422407376346 [[],[]] .chain = true := by decide
def e2422407376558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2422407376558 : Closed e2422407376558 ∧ code e2422407376558 = 11218500398766 := by decide
theorem cert_e2422407376558 : check e2422407376558 [[],[]] .chain = true := by decide
def e2422407376570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2422407376570 : Closed e2422407376570 ∧ code e2422407376570 = 11218500398778 := by decide
theorem cert_e2422407376570 : check e2422407376570 [[],[]] .chain = true := by decide
def e2422407376618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2422407376618 : Closed e2422407376618 ∧ code e2422407376618 = 11218500398826 := by decide
theorem cert_e2422407376618 : check e2422407376618 [[],[]] .chain = true := by decide
def e2422407376726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422407376726 : Closed e2422407376726 ∧ code e2422407376726 = 11218500398934 := by decide
theorem cert_e2422407376726 : check e2422407376726 [[],[]] .chain = true := by decide
def e2422407376730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422407376730 : Closed e2422407376730 ∧ code e2422407376730 = 11218500398938 := by decide
theorem cert_e2422407376730 : check e2422407376730 [[],[]] .chain = true := by decide
def e2422407376746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422407376746 : Closed e2422407376746 ∧ code e2422407376746 = 11218500398954 := by decide
theorem cert_e2422407376746 : check e2422407376746 [[],[]] .chain = true := by decide
def e2422407377006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1))))) (.var 2))))))
theorem wire_e2422407377006 : Closed e2422407377006 ∧ code e2422407377006 = 11218500399214 := by decide
theorem cert_e2422407377006 : check e2422407377006 [[],[]] .chain = true := by decide
def e2422407377182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2422407377182 : Closed e2422407377182 ∧ code e2422407377182 = 11218500399390 := by decide
theorem cert_e2422407377182 : check e2422407377182 [[],[]] .chain = true := by decide
def e2422407377378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 0)))))))
theorem wire_e2422407377378 : Closed e2422407377378 ∧ code e2422407377378 = 11218500399586 := by decide
theorem cert_e2422407377378 : check e2422407377378 [[],[]] .chain = true := by decide
def e2422407377390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422407377390 : Closed e2422407377390 ∧ code e2422407377390 = 11218500399598 := by decide
theorem cert_e2422407377390 : check e2422407377390 [[],[]] .sourceHead = true := by decide
def e2422407377774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422407377774 : Closed e2422407377774 ∧ code e2422407377774 = 11218500399982 := by decide
theorem cert_e2422407377774 : check e2422407377774 [[],[]] .chain = true := by decide
def e2422407377782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2422407377782 : Closed e2422407377782 ∧ code e2422407377782 = 11218500399990 := by decide
theorem cert_e2422407377782 : check e2422407377782 [[],[]] .chain = true := by decide
def e2422407377838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422407377838 : Closed e2422407377838 ∧ code e2422407377838 = 11218500400046 := by decide
theorem cert_e2422407377838 : check e2422407377838 [[],[]] .chain = true := by decide
def e2422407377850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422407377850 : Closed e2422407377850 ∧ code e2422407377850 = 11218500400058 := by decide
theorem cert_e2422407377850 : check e2422407377850 [[],[]] .chain = true := by decide
def e2422407377878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2422407377878 : Closed e2422407377878 ∧ code e2422407377878 = 11218500400086 := by decide
theorem cert_e2422407377878 : check e2422407377878 [[],[]] .chain = true := by decide
def e2422407377882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422407377882 : Closed e2422407377882 ∧ code e2422407377882 = 11218500400090 := by decide
theorem cert_e2422407377882 : check e2422407377882 [[],[]] .chain = true := by decide
def e2422407378158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407378158 : Closed e2422407378158 ∧ code e2422407378158 = 11218500400366 := by decide
theorem cert_e2422407378158 : check e2422407378158 [[],[]] .chain = true := by decide
def e2422407378166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407378166 : Closed e2422407378166 ∧ code e2422407378166 = 11218500400374 := by decide
theorem cert_e2422407378166 : check e2422407378166 [[],[]] .chain = true := by decide
def e2422407378542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407378542 : Closed e2422407378542 ∧ code e2422407378542 = 11218500400750 := by decide
theorem cert_e2422407378542 : check e2422407378542 [[],[]] .chain = true := by decide
def e2422407378554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407378554 : Closed e2422407378554 ∧ code e2422407378554 = 11218500400762 := by decide
theorem cert_e2422407378554 : check e2422407378554 [[],[]] .chain = true := by decide
def e2422407378694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407378694 : Closed e2422407378694 ∧ code e2422407378694 = 11218500400902 := by decide
theorem cert_e2422407378694 : check e2422407378694 [[],[]] .chain = true := by decide
def e2422407378718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422407378718 : Closed e2422407378718 ∧ code e2422407378718 = 11218500400926 := by decide
theorem cert_e2422407378718 : check e2422407378718 [[],[]] .sourceHead = true := by decide
def e2422407378742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407378742 : Closed e2422407378742 ∧ code e2422407378742 = 11218500400950 := by decide
theorem cert_e2422407378742 : check e2422407378742 [[],[]] .chain = true := by decide
def e2422407378746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407378746 : Closed e2422407378746 ∧ code e2422407378746 = 11218500400954 := by decide
theorem cert_e2422407378746 : check e2422407378746 [[],[]] .chain = true := by decide
def e2422407379374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422407379374 : Closed e2422407379374 ∧ code e2422407379374 = 11218500401582 := by decide
theorem cert_e2422407379374 : check e2422407379374 [[],[]] .chain = true := by decide
def e2422407379386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2422407379386 : Closed e2422407379386 ∧ code e2422407379386 = 11218500401594 := by decide
theorem cert_e2422407379386 : check e2422407379386 [[],[]] .chain = true := by decide
def e2422407379434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2422407379434 : Closed e2422407379434 ∧ code e2422407379434 = 11218500401642 := by decide
theorem cert_e2422407379434 : check e2422407379434 [[],[]] .chain = true := by decide
def e2422407379566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407379566 : Closed e2422407379566 ∧ code e2422407379566 = 11218500401774 := by decide
theorem cert_e2422407379566 : check e2422407379566 [[],[]] .chain = true := by decide
def e2422407379578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407379578 : Closed e2422407379578 ∧ code e2422407379578 = 11218500401786 := by decide
theorem cert_e2422407379578 : check e2422407379578 [[],[]] .chain = true := by decide
def e2422407379866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407379866 : Closed e2422407379866 ∧ code e2422407379866 = 11218500402074 := by decide
theorem cert_e2422407379866 : check e2422407379866 [[],[]] .chain = true := by decide
def e2422407379994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.lam (.var 1))))) (.var 0))))))
theorem wire_e2422407379994 : Closed e2422407379994 ∧ code e2422407379994 = 11218500402202 := by decide
theorem cert_e2422407379994 : check e2422407379994 [[],[]] .chain = true := by decide
def e2422407380038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2422407380038 : Closed e2422407380038 ∧ code e2422407380038 = 11218500402246 := by decide
theorem cert_e2422407380038 : check e2422407380038 [[],[]] .chain = true := by decide
def e2422407380066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2422407380066 : Closed e2422407380066 ∧ code e2422407380066 = 11218500402274 := by decide
theorem cert_e2422407380066 : check e2422407380066 [[],[]] .chain = true := by decide
def e2422407380078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422407380078 : Closed e2422407380078 ∧ code e2422407380078 = 11218500402286 := by decide
theorem cert_e2422407380078 : check e2422407380078 [[],[]] .sourceHead = true := by decide
def e2422407380090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407380090 : Closed e2422407380090 ∧ code e2422407380090 = 11218500402298 := by decide
theorem cert_e2422407380090 : check e2422407380090 [[],[]] .sourceHead = true := by decide
def e2422407380182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407380182 : Closed e2422407380182 ∧ code e2422407380182 = 11218500402390 := by decide
theorem cert_e2422407380182 : check e2422407380182 [[],[]] .chain = true := by decide
def e2422407380186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407380186 : Closed e2422407380186 ∧ code e2422407380186 = 11218500402394 := by decide
theorem cert_e2422407380186 : check e2422407380186 [[],[]] .chain = true := by decide
def e2422407380202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407380202 : Closed e2422407380202 ∧ code e2422407380202 = 11218500402410 := by decide
theorem cert_e2422407380202 : check e2422407380202 [[],[]] .chain = true := by decide
def e2422407380230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.lam (.var 1))))))))
theorem wire_e2422407380230 : Closed e2422407380230 ∧ code e2422407380230 = 11218500402438 := by decide
theorem cert_e2422407380230 : check e2422407380230 [[],[]] .chain = true := by decide
def e2422407380254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422407380254 : Closed e2422407380254 ∧ code e2422407380254 = 11218500402462 := by decide
theorem cert_e2422407380254 : check e2422407380254 [[],[]] .sourceHead = true := by decide
def e2422407380278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407380278 : Closed e2422407380278 ∧ code e2422407380278 = 11218500402486 := by decide
theorem cert_e2422407380278 : check e2422407380278 [[],[]] .chain = true := by decide
def e2422407380282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407380282 : Closed e2422407380282 ∧ code e2422407380282 = 11218500402490 := by decide
theorem cert_e2422407380282 : check e2422407380282 [[],[]] .chain = true := by decide
def e2422407380378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407380378 : Closed e2422407380378 ∧ code e2422407380378 = 11218500402586 := by decide
theorem cert_e2422407380378 : check e2422407380378 [[],[]] .chain = true := by decide
def e2422407380422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407380422 : Closed e2422407380422 ∧ code e2422407380422 = 11218500402630 := by decide
theorem cert_e2422407380422 : check e2422407380422 [[],[]] .sourceHead = true := by decide
def e2422407381118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 5)))))))))
theorem wire_e2422407381118 : Closed e2422407381118 ∧ code e2422407381118 = 11218500403326 := by decide
theorem cert_e2422407381118 : check e2422407381118 [[],[]] .chain = true := by decide
def e2422407381982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2422407381982 : Closed e2422407381982 ∧ code e2422407381982 = 11218500404190 := by decide
theorem cert_e2422407381982 : check e2422407381982 [[],[]] .chain = true := by decide
def e2422407381986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422407381986 : Closed e2422407381986 ∧ code e2422407381986 = 11218500404194 := by decide
theorem cert_e2422407381986 : check e2422407381986 [[],[]] .chain = true := by decide
def e2422407381998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2422407381998 : Closed e2422407381998 ∧ code e2422407381998 = 11218500404206 := by decide
theorem cert_e2422407381998 : check e2422407381998 [[],[]] .chain = true := by decide
def e2422407383918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2422407383918 : Closed e2422407383918 ∧ code e2422407383918 = 11218500406126 := by decide
theorem cert_e2422407383918 : check e2422407383918 [[],[]] .chain = true := by decide
def e2422407383926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2422407383926 : Closed e2422407383926 ∧ code e2422407383926 = 11218500406134 := by decide
theorem cert_e2422407383926 : check e2422407383926 [[],[]] .chain = true := by decide
def e2422407383982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2422407383982 : Closed e2422407383982 ∧ code e2422407383982 = 11218500406190 := by decide
theorem cert_e2422407383982 : check e2422407383982 [[],[]] .chain = true := by decide
def e2422407383994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2422407383994 : Closed e2422407383994 ∧ code e2422407383994 = 11218500406202 := by decide
theorem cert_e2422407383994 : check e2422407383994 [[],[]] .chain = true := by decide
def e2422407384022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2422407384022 : Closed e2422407384022 ∧ code e2422407384022 = 11218500406230 := by decide
theorem cert_e2422407384022 : check e2422407384022 [[],[]] .chain = true := by decide
def e2422407384026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2422407384026 : Closed e2422407384026 ∧ code e2422407384026 = 11218500406234 := by decide
theorem cert_e2422407384026 : check e2422407384026 [[],[]] .chain = true := by decide
def e2422407384302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2422407384302 : Closed e2422407384302 ∧ code e2422407384302 = 11218500406510 := by decide
theorem cert_e2422407384302 : check e2422407384302 [[],[]] .chain = true := by decide
def e2422407384310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2422407384310 : Closed e2422407384310 ∧ code e2422407384310 = 11218500406518 := by decide
theorem cert_e2422407384310 : check e2422407384310 [[],[]] .chain = true := by decide
def e2422407384686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407384686 : Closed e2422407384686 ∧ code e2422407384686 = 11218500406894 := by decide
theorem cert_e2422407384686 : check e2422407384686 [[],[]] .chain = true := by decide
end Blc.Floor43
