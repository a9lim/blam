import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393374504474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393374504474 : Closed e2393374504474 ∧ code e2393374504474 = 11189467526682 := by decide
theorem cert_e2393374504474 : check e2393374504474 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393374504546 : Closed e2393374504546 ∧ code e2393374504546 = 11189467526754 := by decide
theorem cert_e2393374504546 : check e2393374504546 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393374504558 : Closed e2393374504558 ∧ code e2393374504558 = 11189467526766 := by decide
theorem cert_e2393374504558 : check e2393374504558 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393374504566 : Closed e2393374504566 ∧ code e2393374504566 = 11189467526774 := by decide
theorem cert_e2393374504566 : check e2393374504566 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393374504570 : Closed e2393374504570 ∧ code e2393374504570 = 11189467526778 := by decide
theorem cert_e2393374504570 : check e2393374504570 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393374504758 : Closed e2393374504758 ∧ code e2393374504758 = 11189467526966 := by decide
theorem cert_e2393374504758 : check e2393374504758 [[],[.left],[],[.under]] .three = true := by decide
def e2393374504762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393374504762 : Closed e2393374504762 ∧ code e2393374504762 = 11189467526970 := by decide
theorem cert_e2393374504762 : check e2393374504762 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2393374505018 : Closed e2393374505018 ∧ code e2393374505018 = 11189467527226 := by decide
theorem cert_e2393374505018 : check e2393374505018 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2393374505066 : Closed e2393374505066 ∧ code e2393374505066 = 11189467527274 := by decide
theorem cert_e2393374505066 : check e2393374505066 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393374505114 : Closed e2393374505114 ∧ code e2393374505114 = 11189467527322 := by decide
theorem cert_e2393374505114 : check e2393374505114 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2393374505158 : Closed e2393374505158 ∧ code e2393374505158 = 11189467527366 := by decide
theorem cert_e2393374505158 : check e2393374505158 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2393374505354 : Closed e2393374505354 ∧ code e2393374505354 = 11189467527562 := by decide
theorem cert_e2393374505354 : check e2393374505354 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2393374505378 : Closed e2393374505378 ∧ code e2393374505378 = 11189467527586 := by decide
theorem cert_e2393374505378 : check e2393374505378 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2393374505390 : Closed e2393374505390 ∧ code e2393374505390 = 11189467527598 := by decide
theorem cert_e2393374505390 : check e2393374505390 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2393374505398 : Closed e2393374505398 ∧ code e2393374505398 = 11189467527606 := by decide
theorem cert_e2393374505398 : check e2393374505398 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2393374505402 : Closed e2393374505402 ∧ code e2393374505402 = 11189467527610 := by decide
theorem cert_e2393374505402 : check e2393374505402 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2393374505430 : Closed e2393374505430 ∧ code e2393374505430 = 11189467527638 := by decide
theorem cert_e2393374505430 : check e2393374505430 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2393374505434 : Closed e2393374505434 ∧ code e2393374505434 = 11189467527642 := by decide
theorem cert_e2393374505434 : check e2393374505434 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2393374505450 : Closed e2393374505450 ∧ code e2393374505450 = 11189467527658 := by decide
theorem cert_e2393374505450 : check e2393374505450 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2393374505486 : Closed e2393374505486 ∧ code e2393374505486 = 11189467527694 := by decide
theorem cert_e2393374505486 : check e2393374505486 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393374505498 : Closed e2393374505498 ∧ code e2393374505498 = 11189467527706 := by decide
theorem cert_e2393374505498 : check e2393374505498 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393374505570 : Closed e2393374505570 ∧ code e2393374505570 = 11189467527778 := by decide
theorem cert_e2393374505570 : check e2393374505570 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393374505582 : Closed e2393374505582 ∧ code e2393374505582 = 11189467527790 := by decide
theorem cert_e2393374505582 : check e2393374505582 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393374505590 : Closed e2393374505590 ∧ code e2393374505590 = 11189467527798 := by decide
theorem cert_e2393374505590 : check e2393374505590 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393374505594 : Closed e2393374505594 ∧ code e2393374505594 = 11189467527802 := by decide
theorem cert_e2393374505594 : check e2393374505594 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393374505782 : Closed e2393374505782 ∧ code e2393374505782 = 11189467527990 := by decide
theorem cert_e2393374505782 : check e2393374505782 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393374505786 : Closed e2393374505786 ∧ code e2393374505786 = 11189467527994 := by decide
theorem cert_e2393374505786 : check e2393374505786 [[],[.left],[],[.under]] .three = true := by decide
def e2393374505882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393374505882 : Closed e2393374505882 ∧ code e2393374505882 = 11189467528090 := by decide
theorem cert_e2393374505882 : check e2393374505882 [[],[.left],[],[.under]] .three = true := by decide
def e2393374506198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2393374506198 : Closed e2393374506198 ∧ code e2393374506198 = 11189467528406 := by decide
theorem cert_e2393374506198 : check e2393374506198 [[],[.left],[],[.under]] .three = true := by decide
def e2393374506202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2393374506202 : Closed e2393374506202 ∧ code e2393374506202 = 11189467528410 := by decide
theorem cert_e2393374506202 : check e2393374506202 [[],[.left],[],[.under]] .three = true := by decide
def e2393374506218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2393374506218 : Closed e2393374506218 ∧ code e2393374506218 = 11189467528426 := by decide
theorem cert_e2393374506218 : check e2393374506218 [[],[.left],[],[.under]] .three = true := by decide
def e2393374506294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393374506294 : Closed e2393374506294 ∧ code e2393374506294 = 11189467528502 := by decide
theorem cert_e2393374506294 : check e2393374506294 [[],[.left],[],[.under]] .three = true := by decide
def e2393374506298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393374506298 : Closed e2393374506298 ∧ code e2393374506298 = 11189467528506 := by decide
theorem cert_e2393374506298 : check e2393374506298 [[],[.left],[],[.under]] .three = true := by decide
def e2393374506394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2393374506394 : Closed e2393374506394 ∧ code e2393374506394 = 11189467528602 := by decide
theorem cert_e2393374506394 : check e2393374506394 [[],[.left],[],[.under]] .three = true := by decide
def e2393374507998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2393374507998 : Closed e2393374507998 ∧ code e2393374507998 = 11189467530206 := by decide
theorem cert_e2393374507998 : check e2393374507998 [[],[.left],[],[.under]] .three = true := by decide
def e2393374508014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2393374508014 : Closed e2393374508014 ∧ code e2393374508014 = 11189467530222 := by decide
theorem cert_e2393374508014 : check e2393374508014 [[],[.left],[],[.under]] .three = true := by decide
def e2393374509846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2393374509846 : Closed e2393374509846 ∧ code e2393374509846 = 11189467532054 := by decide
theorem cert_e2393374509846 : check e2393374509846 [[],[.left],[],[.under]] .three = true := by decide
def e2393374509922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2393374509922 : Closed e2393374509922 ∧ code e2393374509922 = 11189467532130 := by decide
theorem cert_e2393374509922 : check e2393374509922 [[],[.left],[],[.under]] .three = true := by decide
def e2393374509934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393374509934 : Closed e2393374509934 ∧ code e2393374509934 = 11189467532142 := by decide
theorem cert_e2393374509934 : check e2393374509934 [[],[.left],[],[.under]] .three = true := by decide
def e2393374509942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393374509942 : Closed e2393374509942 ∧ code e2393374509942 = 11189467532150 := by decide
theorem cert_e2393374509942 : check e2393374509942 [[],[.left],[],[.under]] .three = true := by decide
def e2393374509962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393374509962 : Closed e2393374509962 ∧ code e2393374509962 = 11189467532170 := by decide
theorem cert_e2393374509962 : check e2393374509962 [[],[.left],[],[.under]] .three = true := by decide
def e2393374509986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393374509986 : Closed e2393374509986 ∧ code e2393374509986 = 11189467532194 := by decide
theorem cert_e2393374509986 : check e2393374509986 [[],[.left],[],[.under]] .three = true := by decide
def e2393374509998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393374509998 : Closed e2393374509998 ∧ code e2393374509998 = 11189467532206 := by decide
theorem cert_e2393374509998 : check e2393374509998 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e2393374510006 : Closed e2393374510006 ∧ code e2393374510006 = 11189467532214 := by decide
theorem cert_e2393374510006 : check e2393374510006 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393374510010 : Closed e2393374510010 ∧ code e2393374510010 = 11189467532218 := by decide
theorem cert_e2393374510010 : check e2393374510010 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393374510038 : Closed e2393374510038 ∧ code e2393374510038 = 11189467532246 := by decide
theorem cert_e2393374510038 : check e2393374510038 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393374510042 : Closed e2393374510042 ∧ code e2393374510042 = 11189467532250 := by decide
theorem cert_e2393374510042 : check e2393374510042 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2393374510110 : Closed e2393374510110 ∧ code e2393374510110 = 11189467532318 := by decide
theorem cert_e2393374510110 : check e2393374510110 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2393374510306 : Closed e2393374510306 ∧ code e2393374510306 = 11189467532514 := by decide
theorem cert_e2393374510306 : check e2393374510306 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393374510318 : Closed e2393374510318 ∧ code e2393374510318 = 11189467532526 := by decide
theorem cert_e2393374510318 : check e2393374510318 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393374510326 : Closed e2393374510326 ∧ code e2393374510326 = 11189467532534 := by decide
theorem cert_e2393374510326 : check e2393374510326 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2393374510606 : Closed e2393374510606 ∧ code e2393374510606 = 11189467532814 := by decide
theorem cert_e2393374510606 : check e2393374510606 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2393374510618 : Closed e2393374510618 ∧ code e2393374510618 = 11189467532826 := by decide
theorem cert_e2393374510618 : check e2393374510618 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393374510690 : Closed e2393374510690 ∧ code e2393374510690 = 11189467532898 := by decide
theorem cert_e2393374510690 : check e2393374510690 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393374510702 : Closed e2393374510702 ∧ code e2393374510702 = 11189467532910 := by decide
theorem cert_e2393374510702 : check e2393374510702 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393374510710 : Closed e2393374510710 ∧ code e2393374510710 = 11189467532918 := by decide
theorem cert_e2393374510710 : check e2393374510710 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393374510714 : Closed e2393374510714 ∧ code e2393374510714 = 11189467532922 := by decide
theorem cert_e2393374510714 : check e2393374510714 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393374510902 : Closed e2393374510902 ∧ code e2393374510902 = 11189467533110 := by decide
theorem cert_e2393374510902 : check e2393374510902 [[],[.left],[],[.under]] .three = true := by decide
def e2393374510906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393374510906 : Closed e2393374510906 ∧ code e2393374510906 = 11189467533114 := by decide
theorem cert_e2393374510906 : check e2393374510906 [[],[.left],[],[.under]] .three = true := by decide
def e2393374515678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2393374515678 : Closed e2393374515678 ∧ code e2393374515678 = 11189467537886 := by decide
theorem cert_e2393374515678 : check e2393374515678 [[],[.left],[],[.under]] .three = true := by decide
def e2393374515702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2393374515702 : Closed e2393374515702 ∧ code e2393374515702 = 11189467537910 := by decide
theorem cert_e2393374515702 : check e2393374515702 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2393374516618 : Closed e2393374516618 ∧ code e2393374516618 = 11189467538826 := by decide
theorem cert_e2393374516618 : check e2393374516618 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2393374516642 : Closed e2393374516642 ∧ code e2393374516642 = 11189467538850 := by decide
theorem cert_e2393374516642 : check e2393374516642 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2393374516654 : Closed e2393374516654 ∧ code e2393374516654 = 11189467538862 := by decide
theorem cert_e2393374516654 : check e2393374516654 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2393374516662 : Closed e2393374516662 ∧ code e2393374516662 = 11189467538870 := by decide
theorem cert_e2393374516662 : check e2393374516662 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2393374516666 : Closed e2393374516666 ∧ code e2393374516666 = 11189467538874 := by decide
theorem cert_e2393374516666 : check e2393374516666 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2393374516694 : Closed e2393374516694 ∧ code e2393374516694 = 11189467538902 := by decide
theorem cert_e2393374516694 : check e2393374516694 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2393374516698 : Closed e2393374516698 ∧ code e2393374516698 = 11189467538906 := by decide
theorem cert_e2393374516698 : check e2393374516698 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2393374516714 : Closed e2393374516714 ∧ code e2393374516714 = 11189467538922 := by decide
theorem cert_e2393374516714 : check e2393374516714 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2393374516750 : Closed e2393374516750 ∧ code e2393374516750 = 11189467538958 := by decide
theorem cert_e2393374516750 : check e2393374516750 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2393374516762 : Closed e2393374516762 ∧ code e2393374516762 = 11189467538970 := by decide
theorem cert_e2393374516762 : check e2393374516762 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393374516834 : Closed e2393374516834 ∧ code e2393374516834 = 11189467539042 := by decide
theorem cert_e2393374516834 : check e2393374516834 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393374516846 : Closed e2393374516846 ∧ code e2393374516846 = 11189467539054 := by decide
theorem cert_e2393374516846 : check e2393374516846 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2393374516854 : Closed e2393374516854 ∧ code e2393374516854 = 11189467539062 := by decide
theorem cert_e2393374516854 : check e2393374516854 [[],[.left],[],[.under]] .three = true := by decide
def e2393374516858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393374516858 : Closed e2393374516858 ∧ code e2393374516858 = 11189467539066 := by decide
theorem cert_e2393374516858 : check e2393374516858 [[],[.left],[],[.under]] .three = true := by decide
def e2393374517046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393374517046 : Closed e2393374517046 ∧ code e2393374517046 = 11189467539254 := by decide
theorem cert_e2393374517046 : check e2393374517046 [[],[.left],[],[.under]] .three = true := by decide
def e2393374517050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393374517050 : Closed e2393374517050 ∧ code e2393374517050 = 11189467539258 := by decide
theorem cert_e2393374517050 : check e2393374517050 [[],[.left],[],[.under]] .three = true := by decide
def e2393374517146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393374517146 : Closed e2393374517146 ∧ code e2393374517146 = 11189467539354 := by decide
theorem cert_e2393374517146 : check e2393374517146 [[],[.left],[],[.under]] .three = true := by decide
def e2393374519534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2393374519534 : Closed e2393374519534 ∧ code e2393374519534 = 11189467541742 := by decide
theorem cert_e2393374519534 : check e2393374519534 [[],[.left],[],[.under]] .three = true := by decide
def e2393374519542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2393374519542 : Closed e2393374519542 ∧ code e2393374519542 = 11189467541750 := by decide
theorem cert_e2393374519542 : check e2393374519542 [[],[.left],[],[.under]] .three = true := by decide
def e2393374520022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2393374520022 : Closed e2393374520022 ∧ code e2393374520022 = 11189467542230 := by decide
theorem cert_e2393374520022 : check e2393374520022 [[],[.left],[],[.under]] .three = true := by decide
def e2393374520026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2393374520026 : Closed e2393374520026 ∧ code e2393374520026 = 11189467542234 := by decide
theorem cert_e2393374520026 : check e2393374520026 [[],[.left],[],[.under]] .three = true := by decide
def e2393374520042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2393374520042 : Closed e2393374520042 ∧ code e2393374520042 = 11189467542250 := by decide
theorem cert_e2393374520042 : check e2393374520042 [[],[.left],[],[.under]] .three = true := by decide
def e2393374520118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393374520118 : Closed e2393374520118 ∧ code e2393374520118 = 11189467542326 := by decide
theorem cert_e2393374520118 : check e2393374520118 [[],[.left],[],[.under]] .three = true := by decide
def e2393374520122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393374520122 : Closed e2393374520122 ∧ code e2393374520122 = 11189467542330 := by decide
theorem cert_e2393374520122 : check e2393374520122 [[],[.left],[],[.under]] .three = true := by decide
def e2393374520218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393374520218 : Closed e2393374520218 ∧ code e2393374520218 = 11189467542426 := by decide
theorem cert_e2393374520218 : check e2393374520218 [[],[.left],[],[.under]] .three = true := by decide
def e2393379769198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393379769198 : Closed e2393379769198 ∧ code e2393379769198 = 11189472791406 := by decide
def e2393379769206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393379769206 : Closed e2393379769206 ∧ code e2393379769206 = 11189472791414 := by decide
private def t_e2393379769206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2393379769206 : ¬ IsSelfInterpreter e2393379769206 :=
  wSource (t := t_e2393379769206) (replay_sound (ps := []) (t := e2393379769206) (by decide)) (by decide)
def e2393379769262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393379769262 : Closed e2393379769262 ∧ code e2393379769262 = 11189472791470 := by decide
def e2393379769274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393379769274 : Closed e2393379769274 ∧ code e2393379769274 = 11189472791482 := by decide
def e2393379769302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393379769302 : Closed e2393379769302 ∧ code e2393379769302 = 11189472791510 := by decide
private def t_e2393379769302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2393379769302 : ¬ IsSelfInterpreter e2393379769302 :=
  wSource (t := t_e2393379769302) (replay_sound (ps := []) (t := e2393379769302) (by decide)) (by decide)
def e2393379769306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393379769306 : Closed e2393379769306 ∧ code e2393379769306 = 11189472791514 := by decide
def e2393379769582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393379769582 : Closed e2393379769582 ∧ code e2393379769582 = 11189472791790 := by decide
def e2393379769590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393379769590 : Closed e2393379769590 ∧ code e2393379769590 = 11189472791798 := by decide
def e2393379769966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393379769966 : Closed e2393379769966 ∧ code e2393379769966 = 11189472792174 := by decide
theorem cert_e2393379769966 : check e2393379769966 [[],[.left],[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e2393379769978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393379769978 : Closed e2393379769978 ∧ code e2393379769978 = 11189472792186 := by decide
theorem cert_e2393379769978 : check e2393379769978 [[],[.left],[],[],[],[],[.under],[.under]] .sourceHead = true := by decide
def e2393379770166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393379770166 : Closed e2393379770166 ∧ code e2393379770166 = 11189472792374 := by decide
def e2393379770170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393379770170 : Closed e2393379770170 ∧ code e2393379770170 = 11189472792378 := by decide
def e2393382071738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))))
theorem wire_e2393382071738 : Closed e2393382071738 ∧ code e2393382071738 = 11189475093946 := by decide
def e2393382071770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))))
theorem wire_e2393382071770 : Closed e2393382071770 ∧ code e2393382071770 = 11189475093978 := by decide
def e2393382071994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))))
theorem wire_e2393382071994 : Closed e2393382071994 ∧ code e2393382071994 = 11189475094202 := by decide
def e2393382072042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))))
theorem wire_e2393382072042 : Closed e2393382072042 ∧ code e2393382072042 = 11189475094250 := by decide
def e2393382072154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e2393382072154 : Closed e2393382072154 ∧ code e2393382072154 = 11189475094362 := by decide
def e2393382072170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e2393382072170 : Closed e2393382072170 ∧ code e2393382072170 = 11189475094378 := by decide
def e2393382073274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e2393382073274 : Closed e2393382073274 ∧ code e2393382073274 = 11189475095482 := by decide
def e2393382073306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e2393382073306 : Closed e2393382073306 ∧ code e2393382073306 = 11189475095514 := by decide
def e2393382074810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e2393382074810 : Closed e2393382074810 ∧ code e2393382074810 = 11189475097018 := by decide
def e2393382074858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e2393382074858 : Closed e2393382074858 ∧ code e2393382074858 = 11189475097066 := by decide
def e2393382075610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e2393382075610 : Closed e2393382075610 ∧ code e2393382075610 = 11189475097818 := by decide
def e2393382075626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e2393382075626 : Closed e2393382075626 ∧ code e2393382075626 = 11189475097834 := by decide
def e2393382106850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2393382106850 : Closed e2393382106850 ∧ code e2393382106850 = 11189475129058 := by decide
theorem cert_e2393382106850 : check e2393382106850 [[],[.left],[],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2393382106978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2393382106978 : Closed e2393382106978 ∧ code e2393382106978 = 11189475129186 := by decide
theorem cert_e2393382106978 : check e2393382106978 [[],[.left],[],[.left],[],[.left],[],[.left],[],[.left],[]] .chain = true := by decide
def e2393382107874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 0))))))
theorem wire_e2393382107874 : Closed e2393382107874 ∧ code e2393382107874 = 11189475130082 := by decide
theorem cert_e2393382107874 : check e2393382107874 [[],[.left],[],[.left],[],[.left],[],[.left],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2393382108066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2393382108066 : Closed e2393382108066 ∧ code e2393382108066 = 11189475130274 := by decide
theorem cert_e2393382108066 : check e2393382108066 [[],[.left],[],[.left],[],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e2393382108514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 0))))))
theorem wire_e2393382108514 : Closed e2393382108514 ∧ code e2393382108514 = 11189475130722 := by decide
theorem cert_e2393382108514 : check e2393382108514 [[],[.left],[],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left]] .chain = true := by decide
def e2393382108578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 0))))))
theorem wire_e2393382108578 : Closed e2393382108578 ∧ code e2393382108578 = 11189475130786 := by decide
theorem cert_e2393382108578 : check e2393382108578 [[],[.left],[],[.left],[],[.left],[],[.left],[.left,.left]] .chain = true := by decide
def e2393382112994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2393382112994 : Closed e2393382112994 ∧ code e2393382112994 = 11189475135202 := by decide
theorem cert_e2393382112994 : check e2393382112994 [[],[.left],[],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e2393382113122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2393382113122 : Closed e2393382113122 ∧ code e2393382113122 = 11189475135330 := by decide
theorem cert_e2393382113122 : check e2393382113122 [[],[.left],[],[.left],[],[.left],[],[],[],[],[]] .chain = true := by decide
def e2393382119138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 0))))))
theorem wire_e2393382119138 : Closed e2393382119138 ∧ code e2393382119138 = 11189475141346 := by decide
theorem cert_e2393382119138 : check e2393382119138 [[],[.left],[],[.left],[],[.left],[],[],[],[.under]] .chain = true := by decide
def e2393382119330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2393382119330 : Closed e2393382119330 ∧ code e2393382119330 = 11189475141538 := by decide
theorem cert_e2393382119330 : check e2393382119330 [[],[.left],[],[.left],[],[.left],[],[],[],[]] .chain = true := by decide
def e2393382122338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 0))))))
theorem wire_e2393382122338 : Closed e2393382122338 ∧ code e2393382122338 = 11189475144546 := by decide
theorem cert_e2393382122338 : check e2393382122338 [[],[.left],[],[.left],[],[.left],[],[],[]] .chain = true := by decide
def e2393382122402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 0))))))
theorem wire_e2393382122402 : Closed e2393382122402 ∧ code e2393382122402 = 11189475144610 := by decide
theorem cert_e2393382122402 : check e2393382122402 [[],[.left],[],[.left],[],[.left],[],[],[]] .chain = true := by decide
def e2393382128494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393382128494 : Closed e2393382128494 ∧ code e2393382128494 = 11189475150702 := by decide
def e2393382128502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393382128502 : Closed e2393382128502 ∧ code e2393382128502 = 11189475150710 := by decide
def e2393382128558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393382128558 : Closed e2393382128558 ∧ code e2393382128558 = 11189475150766 := by decide
theorem cert_e2393382128558 : check e2393382128558 [[],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393382128570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393382128570 : Closed e2393382128570 ∧ code e2393382128570 = 11189475150778 := by decide
theorem cert_e2393382128570 : check e2393382128570 [[],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2393382128598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393382128598 : Closed e2393382128598 ∧ code e2393382128598 = 11189475150806 := by decide
def e2393382128602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393382128602 : Closed e2393382128602 ∧ code e2393382128602 = 11189475150810 := by decide
def e2393382128878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393382128878 : Closed e2393382128878 ∧ code e2393382128878 = 11189475151086 := by decide
def e2393382128886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393382128886 : Closed e2393382128886 ∧ code e2393382128886 = 11189475151094 := by decide
def e2393382129262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393382129262 : Closed e2393382129262 ∧ code e2393382129262 = 11189475151470 := by decide
def e2393382129274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393382129274 : Closed e2393382129274 ∧ code e2393382129274 = 11189475151482 := by decide
def e2393382129462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393382129462 : Closed e2393382129462 ∧ code e2393382129462 = 11189475151670 := by decide
theorem cert_e2393382129462 : check e2393382129462 [[],[.left],[],[.left],[],[.left],[.left],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2393382129466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393382129466 : Closed e2393382129466 ∧ code e2393382129466 = 11189475151674 := by decide
def e2393382325102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2393382325102 : Closed e2393382325102 ∧ code e2393382325102 = 11189475347310 := by decide
def e2393382325110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2393382325110 : Closed e2393382325110 ∧ code e2393382325110 = 11189475347318 := by decide
def e2393382325166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2393382325166 : Closed e2393382325166 ∧ code e2393382325166 = 11189475347374 := by decide
def e2393382325178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2393382325178 : Closed e2393382325178 ∧ code e2393382325178 = 11189475347386 := by decide
def e2393382325206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2393382325206 : Closed e2393382325206 ∧ code e2393382325206 = 11189475347414 := by decide
def e2393382325210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2393382325210 : Closed e2393382325210 ∧ code e2393382325210 = 11189475347418 := by decide
def e2393382325486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393382325486 : Closed e2393382325486 ∧ code e2393382325486 = 11189475347694 := by decide
theorem cert_e2393382325486 : check e2393382325486 [[],[.left],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393382325494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393382325494 : Closed e2393382325494 ∧ code e2393382325494 = 11189475347702 := by decide
theorem cert_e2393382325494 : check e2393382325494 [[],[.left],[],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2393382325870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393382325870 : Closed e2393382325870 ∧ code e2393382325870 = 11189475348078 := by decide
theorem cert_e2393382325870 : check e2393382325870 [[],[.left],[],[.left],[],[.left],[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2393382325882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393382325882 : Closed e2393382325882 ∧ code e2393382325882 = 11189475348090 := by decide
def e2393382326070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393382326070 : Closed e2393382326070 ∧ code e2393382326070 = 11189475348278 := by decide
theorem cert_e2393382326070 : check e2393382326070 [[],[.left],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2393382326074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393382326074 : Closed e2393382326074 ∧ code e2393382326074 = 11189475348282 := by decide
theorem cert_e2393382326074 : check e2393382326074 [[],[.left],[],[.left],[],[.left],[],[]] .smaller = true := by decide
def e2393382607734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1)))))
theorem wire_e2393382607734 : Closed e2393382607734 ∧ code e2393382607734 = 11189475629942 := by decide
def e2393382607798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem wire_e2393382607798 : Closed e2393382607798 ∧ code e2393382607798 = 11189475630006 := by decide
private def t_e2393382607798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1)))))
theorem cert_e2393382607798 : ¬ IsSelfInterpreter e2393382607798 :=
  wSource (t := t_e2393382607798) (replay_sound (ps := []) (t := e2393382607798) (by decide)) (by decide)
def e2393382608246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1)))))
theorem wire_e2393382608246 : Closed e2393382608246 ∧ code e2393382608246 = 11189475630454 := by decide
def e2393382608342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1)))))
theorem wire_e2393382608342 : Closed e2393382608342 ∧ code e2393382608342 = 11189475630550 := by decide
def e2393382608566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem wire_e2393382608566 : Closed e2393382608566 ∧ code e2393382608566 = 11189475630774 := by decide
private def t_e2393382608566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1)))))
theorem cert_e2393382608566 : ¬ IsSelfInterpreter e2393382608566 :=
  wSource (t := t_e2393382608566) (replay_sound (ps := []) (t := e2393382608566) (by decide)) (by decide)
def e2393382608598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1)))))
theorem wire_e2393382608598 : Closed e2393382608598 ∧ code e2393382608598 = 11189475630806 := by decide
def e2393382610806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1)))))
theorem wire_e2393382610806 : Closed e2393382610806 ∧ code e2393382610806 = 11189475633014 := by decide
def e2393382610870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1)))))
theorem wire_e2393382610870 : Closed e2393382610870 ∧ code e2393382610870 = 11189475633078 := by decide
def e2393382613878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1)))))
theorem wire_e2393382613878 : Closed e2393382613878 ∧ code e2393382613878 = 11189475636086 := by decide
def e2393382613974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1)))))
theorem wire_e2393382613974 : Closed e2393382613974 ∧ code e2393382613974 = 11189475636182 := by decide
def e2393382615478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1)))))
theorem wire_e2393382615478 : Closed e2393382615478 ∧ code e2393382615478 = 11189475637686 := by decide
def e2393382615510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1)))))
theorem wire_e2393382615510 : Closed e2393382615510 ∧ code e2393382615510 = 11189475637718 := by decide
def e2393382783854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393382783854 : Closed e2393382783854 ∧ code e2393382783854 = 11189475806062 := by decide
private def t_e2393382783854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e2393382783854 : ¬ IsSelfInterpreter e2393382783854 :=
  wSource (t := t_e2393382783854) (replay_sound (ps := []) (t := e2393382783854) (by decide)) (by decide)
def e2393382783862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393382783862 : Closed e2393382783862 ∧ code e2393382783862 = 11189475806070 := by decide
private def t_e2393382783862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2393382783862 : ¬ IsSelfInterpreter e2393382783862 :=
  wSource (t := t_e2393382783862) (replay_sound (ps := []) (t := e2393382783862) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393379769206
#print axioms Blc.Floor43.cert_e2393379769302
#print axioms Blc.Floor43.cert_e2393382607798
#print axioms Blc.Floor43.cert_e2393382608566
#print axioms Blc.Floor43.cert_e2393382783854
#print axioms Blc.Floor43.cert_e2393382783862
