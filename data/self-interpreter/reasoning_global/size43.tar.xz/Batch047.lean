import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e701156258650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e701156258650 : Closed e701156258650 ∧ code e701156258650 = 9497249280858 := by decide
theorem cert_e701156258650 : check e701156258650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156258666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e701156258666 : Closed e701156258666 ∧ code e701156258666 = 9497249280874 := by decide
theorem cert_e701156258666 : check e701156258666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156258730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156258730 : Closed e701156258730 ∧ code e701156258730 = 9497249280938 := by decide
theorem cert_e701156258730 : check e701156258730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156259034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156259034 : Closed e701156259034 ∧ code e701156259034 = 9497249281242 := by decide
theorem cert_e701156259034 : check e701156259034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156259050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156259050 : Closed e701156259050 ∧ code e701156259050 = 9497249281258 := by decide
theorem cert_e701156259050 : check e701156259050 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156259226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156259226 : Closed e701156259226 ∧ code e701156259226 = 9497249281434 := by decide
theorem cert_e701156259226 : check e701156259226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156259386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156259386 : Closed e701156259386 ∧ code e701156259386 = 9497249281594 := by decide
theorem cert_e701156259386 : check e701156259386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156259434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156259434 : Closed e701156259434 ∧ code e701156259434 = 9497249281642 := by decide
theorem cert_e701156259434 : check e701156259434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156259482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156259482 : Closed e701156259482 ∧ code e701156259482 = 9497249281690 := by decide
theorem cert_e701156259482 : check e701156259482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156259526 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156259526 : Closed e701156259526 ∧ code e701156259526 = 9497249281734 := by decide
theorem cert_e701156259526 : check e701156259526 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156265402 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))) (.var 0)))
theorem wire_e701156265402 : Closed e701156265402 ∧ code e701156265402 = 9497249287610 := by decide
theorem cert_e701156265402 : check e701156265402 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156265434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))) (.var 0)))
theorem wire_e701156265434 : Closed e701156265434 ∧ code e701156265434 = 9497249287642 := by decide
theorem cert_e701156265434 : check e701156265434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156265658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e701156265658 : Closed e701156265658 ∧ code e701156265658 = 9497249287866 := by decide
theorem cert_e701156265658 : check e701156265658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156265706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e701156265706 : Closed e701156265706 ∧ code e701156265706 = 9497249287914 := by decide
theorem cert_e701156265706 : check e701156265706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156265818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156265818 : Closed e701156265818 ∧ code e701156265818 = 9497249288026 := by decide
theorem cert_e701156265818 : check e701156265818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156265834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156265834 : Closed e701156265834 ∧ code e701156265834 = 9497249288042 := by decide
theorem cert_e701156265834 : check e701156265834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156268730 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))) (.var 0)))
theorem wire_e701156268730 : Closed e701156268730 ∧ code e701156268730 = 9497249290938 := by decide
theorem cert_e701156268730 : check e701156268730 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156268778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))) (.var 0)))
theorem wire_e701156268778 : Closed e701156268778 ∧ code e701156268778 = 9497249290986 := by decide
theorem cert_e701156268778 : check e701156268778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156268970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156268970 : Closed e701156268970 ∧ code e701156268970 = 9497249291178 := by decide
theorem cert_e701156268970 : check e701156268970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156269738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156269738 : Closed e701156269738 ∧ code e701156269738 = 9497249291946 := by decide
theorem cert_e701156269738 : check e701156269738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156271034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))) (.var 0)))
theorem wire_e701156271034 : Closed e701156271034 ∧ code e701156271034 = 9497249293242 := by decide
theorem cert_e701156271034 : check e701156271034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156271066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))) (.var 0)))
theorem wire_e701156271066 : Closed e701156271066 ∧ code e701156271066 = 9497249293274 := by decide
theorem cert_e701156271066 : check e701156271066 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156271802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e701156271802 : Closed e701156271802 ∧ code e701156271802 = 9497249294010 := by decide
theorem cert_e701156271802 : check e701156271802 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156271850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156271850 : Closed e701156271850 ∧ code e701156271850 = 9497249294058 := by decide
theorem cert_e701156271850 : check e701156271850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156272042 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156272042 : Closed e701156272042 ∧ code e701156272042 = 9497249294250 := by decide
theorem cert_e701156272042 : check e701156272042 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156272570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e701156272570 : Closed e701156272570 ∧ code e701156272570 = 9497249294778 := by decide
theorem cert_e701156272570 : check e701156272570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156272618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e701156272618 : Closed e701156272618 ∧ code e701156272618 = 9497249294826 := by decide
theorem cert_e701156272618 : check e701156272618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156273050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156273050 : Closed e701156273050 ∧ code e701156273050 = 9497249295258 := by decide
theorem cert_e701156273050 : check e701156273050 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156273274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.var 0)))
theorem wire_e701156273274 : Closed e701156273274 ∧ code e701156273274 = 9497249295482 := by decide
theorem cert_e701156273274 : check e701156273274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156273606 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.var 1))))
theorem wire_e701156273606 : Closed e701156273606 ∧ code e701156273606 = 9497249295814 := by decide
theorem cert_e701156273606 : check e701156273606 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156273722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156273722 : Closed e701156273722 ∧ code e701156273722 = 9497249295930 := by decide
theorem cert_e701156273722 : check e701156273722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156273770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156273770 : Closed e701156273770 ∧ code e701156273770 = 9497249295978 := by decide
theorem cert_e701156273770 : check e701156273770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156273818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156273818 : Closed e701156273818 ∧ code e701156273818 = 9497249296026 := by decide
theorem cert_e701156273818 : check e701156273818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156273862 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156273862 : Closed e701156273862 ∧ code e701156273862 = 9497249296070 := by decide
theorem cert_e701156273862 : check e701156273862 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156274618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e701156274618 : Closed e701156274618 ∧ code e701156274618 = 9497249296826 := by decide
theorem cert_e701156274618 : check e701156274618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156274666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.var 0)))
theorem wire_e701156274666 : Closed e701156274666 ∧ code e701156274666 = 9497249296874 := by decide
theorem cert_e701156274666 : check e701156274666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156275322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.var 0)))
theorem wire_e701156275322 : Closed e701156275322 ∧ code e701156275322 = 9497249297530 := by decide
theorem cert_e701156275322 : check e701156275322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156275654 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.var 1))))
theorem wire_e701156275654 : Closed e701156275654 ∧ code e701156275654 = 9497249297862 := by decide
theorem cert_e701156275654 : check e701156275654 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156275994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e701156275994 : Closed e701156275994 ∧ code e701156275994 = 9497249298202 := by decide
theorem cert_e701156275994 : check e701156275994 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276038 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e701156276038 : Closed e701156276038 ∧ code e701156276038 = 9497249298246 := by decide
theorem cert_e701156276038 : check e701156276038 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e701156276442 : Closed e701156276442 ∧ code e701156276442 = 9497249298650 := by decide
theorem cert_e701156276442 : check e701156276442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156276458 : Closed e701156276458 ∧ code e701156276458 = 9497249298666 := by decide
theorem cert_e701156276458 : check e701156276458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156276650 : Closed e701156276650 ∧ code e701156276650 = 9497249298858 := by decide
theorem cert_e701156276650 : check e701156276650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156276794 : Closed e701156276794 ∧ code e701156276794 = 9497249299002 := by decide
theorem cert_e701156276794 : check e701156276794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156276842 : Closed e701156276842 ∧ code e701156276842 = 9497249299050 := by decide
theorem cert_e701156276842 : check e701156276842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156276890 : Closed e701156276890 ∧ code e701156276890 = 9497249299098 := by decide
theorem cert_e701156276890 : check e701156276890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156276934 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156276934 : Closed e701156276934 ∧ code e701156276934 = 9497249299142 := by decide
theorem cert_e701156276934 : check e701156276934 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156277018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e701156277018 : Closed e701156277018 ∧ code e701156277018 = 9497249299226 := by decide
theorem cert_e701156277018 : check e701156277018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156277062 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e701156277062 : Closed e701156277062 ∧ code e701156277062 = 9497249299270 := by decide
theorem cert_e701156277062 : check e701156277062 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156280026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))) (.var 0)))
theorem wire_e701156280026 : Closed e701156280026 ∧ code e701156280026 = 9497249302234 := by decide
theorem cert_e701156280026 : check e701156280026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156280154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156280154 : Closed e701156280154 ∧ code e701156280154 = 9497249302362 := by decide
theorem cert_e701156280154 : check e701156280154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156280170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156280170 : Closed e701156280170 ∧ code e701156280170 = 9497249302378 := by decide
theorem cert_e701156280170 : check e701156280170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156281690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))) (.var 0)))
theorem wire_e701156281690 : Closed e701156281690 ∧ code e701156281690 = 9497249303898 := by decide
theorem cert_e701156281690 : check e701156281690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156281706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))) (.var 0)))
theorem wire_e701156281706 : Closed e701156281706 ∧ code e701156281706 = 9497249303914 := by decide
theorem cert_e701156281706 : check e701156281706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156281770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156281770 : Closed e701156281770 ∧ code e701156281770 = 9497249303978 := by decide
theorem cert_e701156281770 : check e701156281770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156282026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))) (.var 0)))
theorem wire_e701156282026 : Closed e701156282026 ∧ code e701156282026 = 9497249304234 := by decide
theorem cert_e701156282026 : check e701156282026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156282842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e701156282842 : Closed e701156282842 ∧ code e701156282842 = 9497249305050 := by decide
theorem cert_e701156282842 : check e701156282842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156283226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e701156283226 : Closed e701156283226 ∧ code e701156283226 = 9497249305434 := by decide
theorem cert_e701156283226 : check e701156283226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156283242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e701156283242 : Closed e701156283242 ∧ code e701156283242 = 9497249305450 := by decide
theorem cert_e701156283242 : check e701156283242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156283306 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156283306 : Closed e701156283306 ∧ code e701156283306 = 9497249305514 := by decide
theorem cert_e701156283306 : check e701156283306 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156283610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156283610 : Closed e701156283610 ∧ code e701156283610 = 9497249305818 := by decide
theorem cert_e701156283610 : check e701156283610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156283626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156283626 : Closed e701156283626 ∧ code e701156283626 = 9497249305834 := by decide
theorem cert_e701156283626 : check e701156283626 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156283802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156283802 : Closed e701156283802 ∧ code e701156283802 = 9497249306010 := by decide
theorem cert_e701156283802 : check e701156283802 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156283962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156283962 : Closed e701156283962 ∧ code e701156283962 = 9497249306170 := by decide
theorem cert_e701156283962 : check e701156283962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156284010 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156284010 : Closed e701156284010 ∧ code e701156284010 = 9497249306218 := by decide
theorem cert_e701156284010 : check e701156284010 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156284058 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156284058 : Closed e701156284058 ∧ code e701156284058 = 9497249306266 := by decide
theorem cert_e701156284058 : check e701156284058 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156284102 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156284102 : Closed e701156284102 ∧ code e701156284102 = 9497249306310 := by decide
theorem cert_e701156284102 : check e701156284102 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156284634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))) (.var 0)))
theorem wire_e701156284634 : Closed e701156284634 ∧ code e701156284634 = 9497249306842 := by decide
theorem cert_e701156284634 : check e701156284634 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156284650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156284650 : Closed e701156284650 ∧ code e701156284650 = 9497249306858 := by decide
theorem cert_e701156284650 : check e701156284650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156284842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156284842 : Closed e701156284842 ∧ code e701156284842 = 9497249307050 := by decide
theorem cert_e701156284842 : check e701156284842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156284986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156284986 : Closed e701156284986 ∧ code e701156284986 = 9497249307194 := by decide
theorem cert_e701156284986 : check e701156284986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156285034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156285034 : Closed e701156285034 ∧ code e701156285034 = 9497249307242 := by decide
theorem cert_e701156285034 : check e701156285034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156285082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156285082 : Closed e701156285082 ∧ code e701156285082 = 9497249307290 := by decide
theorem cert_e701156285082 : check e701156285082 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156285126 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156285126 : Closed e701156285126 ∧ code e701156285126 = 9497249307334 := by decide
theorem cert_e701156285126 : check e701156285126 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156285210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))) (.var 0)))
theorem wire_e701156285210 : Closed e701156285210 ∧ code e701156285210 = 9497249307418 := by decide
theorem cert_e701156285210 : check e701156285210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156285254 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.var 1))))
theorem wire_e701156285254 : Closed e701156285254 ∧ code e701156285254 = 9497249307462 := by decide
theorem cert_e701156285254 : check e701156285254 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156309946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))) (.var 0)))
theorem wire_e701156309946 : Closed e701156309946 ∧ code e701156309946 = 9497249332154 := by decide
theorem cert_e701156309946 : check e701156309946 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156309978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))) (.var 0)))
theorem wire_e701156309978 : Closed e701156309978 ∧ code e701156309978 = 9497249332186 := by decide
theorem cert_e701156309978 : check e701156309978 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156310458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))) (.var 0)))
theorem wire_e701156310458 : Closed e701156310458 ∧ code e701156310458 = 9497249332666 := by decide
theorem cert_e701156310458 : check e701156310458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156310506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))) (.var 0)))
theorem wire_e701156310506 : Closed e701156310506 ∧ code e701156310506 = 9497249332714 := by decide
theorem cert_e701156310506 : check e701156310506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156310746 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))) (.var 0)))
theorem wire_e701156310746 : Closed e701156310746 ∧ code e701156310746 = 9497249332954 := by decide
theorem cert_e701156310746 : check e701156310746 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156310762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e701156310762 : Closed e701156310762 ∧ code e701156310762 = 9497249332970 := by decide
theorem cert_e701156310762 : check e701156310762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156324282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e701156324282 : Closed e701156324282 ∧ code e701156324282 = 9497249346490 := by decide
theorem cert_e701156324282 : check e701156324282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156324314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e701156324314 : Closed e701156324314 ∧ code e701156324314 = 9497249346522 := by decide
theorem cert_e701156324314 : check e701156324314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156325850 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))) (.var 0)))
theorem wire_e701156325850 : Closed e701156325850 ∧ code e701156325850 = 9497249348058 := by decide
theorem cert_e701156325850 : check e701156325850 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156341178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))) (.var 0)))
theorem wire_e701156341178 : Closed e701156341178 ∧ code e701156341178 = 9497249363386 := by decide
theorem cert_e701156341178 : check e701156341178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156341210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))) (.var 0)))
theorem wire_e701156341210 : Closed e701156341210 ∧ code e701156341210 = 9497249363418 := by decide
theorem cert_e701156341210 : check e701156341210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156341434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e701156341434 : Closed e701156341434 ∧ code e701156341434 = 9497249363642 := by decide
theorem cert_e701156341434 : check e701156341434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156341482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156341482 : Closed e701156341482 ∧ code e701156341482 = 9497249363690 := by decide
theorem cert_e701156341482 : check e701156341482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156341594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e701156341594 : Closed e701156341594 ∧ code e701156341594 = 9497249363802 := by decide
theorem cert_e701156341594 : check e701156341594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156341610 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e701156341610 : Closed e701156341610 ∧ code e701156341610 = 9497249363818 := by decide
theorem cert_e701156341610 : check e701156341610 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156342458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))) (.var 0)))
theorem wire_e701156342458 : Closed e701156342458 ∧ code e701156342458 = 9497249364666 := by decide
theorem cert_e701156342458 : check e701156342458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156342506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))) (.var 0)))
theorem wire_e701156342506 : Closed e701156342506 ∧ code e701156342506 = 9497249364714 := by decide
theorem cert_e701156342506 : check e701156342506 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156342698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156342698 : Closed e701156342698 ∧ code e701156342698 = 9497249364906 := by decide
theorem cert_e701156342698 : check e701156342698 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156343130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))) (.var 0)))
theorem wire_e701156343130 : Closed e701156343130 ∧ code e701156343130 = 9497249365338 := by decide
theorem cert_e701156343130 : check e701156343130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156343146 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))) (.var 0)))
theorem wire_e701156343146 : Closed e701156343146 ∧ code e701156343146 = 9497249365354 := by decide
theorem cert_e701156343146 : check e701156343146 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156343210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)))))) (.var 0)))
theorem wire_e701156343210 : Closed e701156343210 ∧ code e701156343210 = 9497249365418 := by decide
theorem cert_e701156343210 : check e701156343210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156347322 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)))))) (.var 0)))
theorem wire_e701156347322 : Closed e701156347322 ∧ code e701156347322 = 9497249369530 := by decide
theorem cert_e701156347322 : check e701156347322 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156347354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)))))) (.var 0)))
theorem wire_e701156347354 : Closed e701156347354 ∧ code e701156347354 = 9497249369562 := by decide
theorem cert_e701156347354 : check e701156347354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156347578 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)))))) (.var 0)))
theorem wire_e701156347578 : Closed e701156347578 ∧ code e701156347578 = 9497249369786 := by decide
theorem cert_e701156347578 : check e701156347578 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156347626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e701156347626 : Closed e701156347626 ∧ code e701156347626 = 9497249369834 := by decide
theorem cert_e701156347626 : check e701156347626 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156347738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)))))) (.var 0)))
theorem wire_e701156347738 : Closed e701156347738 ∧ code e701156347738 = 9497249369946 := by decide
theorem cert_e701156347738 : check e701156347738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156347754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)))))) (.var 0)))
theorem wire_e701156347754 : Closed e701156347754 ∧ code e701156347754 = 9497249369962 := by decide
theorem cert_e701156347754 : check e701156347754 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156348858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))) (.var 0)))
theorem wire_e701156348858 : Closed e701156348858 ∧ code e701156348858 = 9497249371066 := by decide
theorem cert_e701156348858 : check e701156348858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156348890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))) (.var 0)))
theorem wire_e701156348890 : Closed e701156348890 ∧ code e701156348890 = 9497249371098 := by decide
theorem cert_e701156348890 : check e701156348890 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156350394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e701156350394 : Closed e701156350394 ∧ code e701156350394 = 9497249372602 := by decide
theorem cert_e701156350394 : check e701156350394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156350442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e701156350442 : Closed e701156350442 ∧ code e701156350442 = 9497249372650 := by decide
theorem cert_e701156350442 : check e701156350442 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156350874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156350874 : Closed e701156350874 ∧ code e701156350874 = 9497249373082 := by decide
theorem cert_e701156350874 : check e701156350874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156351194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156351194 : Closed e701156351194 ∧ code e701156351194 = 9497249373402 := by decide
theorem cert_e701156351194 : check e701156351194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156351210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156351210 : Closed e701156351210 ∧ code e701156351210 = 9497249373418 := by decide
theorem cert_e701156351210 : check e701156351210 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156351386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156351386 : Closed e701156351386 ∧ code e701156351386 = 9497249373594 := by decide
theorem cert_e701156351386 : check e701156351386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156352954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)))))) (.var 0)))
theorem wire_e701156352954 : Closed e701156352954 ∧ code e701156352954 = 9497249375162 := by decide
theorem cert_e701156352954 : check e701156352954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156352986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)))))) (.var 0)))
theorem wire_e701156352986 : Closed e701156352986 ∧ code e701156352986 = 9497249375194 := by decide
theorem cert_e701156352986 : check e701156352986 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156353722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)))))) (.var 0)))
theorem wire_e701156353722 : Closed e701156353722 ∧ code e701156353722 = 9497249375930 := by decide
theorem cert_e701156353722 : check e701156353722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156353770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)))))) (.var 0)))
theorem wire_e701156353770 : Closed e701156353770 ∧ code e701156353770 = 9497249375978 := by decide
theorem cert_e701156353770 : check e701156353770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156353962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)))))) (.var 0)))
theorem wire_e701156353962 : Closed e701156353962 ∧ code e701156353962 = 9497249376170 := by decide
theorem cert_e701156353962 : check e701156353962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156354490 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2))))))) (.var 0)))
theorem wire_e701156354490 : Closed e701156354490 ∧ code e701156354490 = 9497249376698 := by decide
theorem cert_e701156354490 : check e701156354490 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156354538 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0))))))) (.var 0)))
theorem wire_e701156354538 : Closed e701156354538 ∧ code e701156354538 = 9497249376746 := by decide
theorem cert_e701156354538 : check e701156354538 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156354970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156354970 : Closed e701156354970 ∧ code e701156354970 = 9497249377178 := by decide
theorem cert_e701156354970 : check e701156354970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156355194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3))))))) (.var 0)))
theorem wire_e701156355194 : Closed e701156355194 ∧ code e701156355194 = 9497249377402 := by decide
theorem cert_e701156355194 : check e701156355194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156355526 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.var 1))))
theorem wire_e701156355526 : Closed e701156355526 ∧ code e701156355526 = 9497249377734 := by decide
theorem cert_e701156355526 : check e701156355526 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156355642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156355642 : Closed e701156355642 ∧ code e701156355642 = 9497249377850 := by decide
theorem cert_e701156355642 : check e701156355642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156355690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156355690 : Closed e701156355690 ∧ code e701156355690 = 9497249377898 := by decide
theorem cert_e701156355690 : check e701156355690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156355738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156355738 : Closed e701156355738 ∧ code e701156355738 = 9497249377946 := by decide
theorem cert_e701156355738 : check e701156355738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156355782 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156355782 : Closed e701156355782 ∧ code e701156355782 = 9497249377990 := by decide
theorem cert_e701156355782 : check e701156355782 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156356570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1)))))) (.var 0)))
theorem wire_e701156356570 : Closed e701156356570 ∧ code e701156356570 = 9497249378778 := by decide
theorem cert_e701156356570 : check e701156356570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156356954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1)))))) (.var 0)))
theorem wire_e701156356954 : Closed e701156356954 ∧ code e701156356954 = 9497249379162 := by decide
theorem cert_e701156356954 : check e701156356954 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156356970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0)))))) (.var 0)))
theorem wire_e701156356970 : Closed e701156356970 ∧ code e701156356970 = 9497249379178 := by decide
theorem cert_e701156356970 : check e701156356970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0)))))) (.var 0)))
theorem wire_e701156357034 : Closed e701156357034 ∧ code e701156357034 = 9497249379242 := by decide
theorem cert_e701156357034 : check e701156357034 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1))))))) (.var 0)))
theorem wire_e701156357338 : Closed e701156357338 ∧ code e701156357338 = 9497249379546 := by decide
theorem cert_e701156357338 : check e701156357338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357354 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0))))))) (.var 0)))
theorem wire_e701156357354 : Closed e701156357354 ∧ code e701156357354 = 9497249379562 := by decide
theorem cert_e701156357354 : check e701156357354 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156357530 : Closed e701156357530 ∧ code e701156357530 = 9497249379738 := by decide
theorem cert_e701156357530 : check e701156357530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2))))))) (.var 0)))
theorem wire_e701156357690 : Closed e701156357690 ∧ code e701156357690 = 9497249379898 := by decide
theorem cert_e701156357690 : check e701156357690 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0))))))) (.var 0)))
theorem wire_e701156357738 : Closed e701156357738 ∧ code e701156357738 = 9497249379946 := by decide
theorem cert_e701156357738 : check e701156357738 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.app (.var 0) (.var 0))))
theorem wire_e701156357786 : Closed e701156357786 ∧ code e701156357786 = 9497249379994 := by decide
theorem cert_e701156357786 : check e701156357786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156357830 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.var 1))))
theorem wire_e701156357830 : Closed e701156357830 ∧ code e701156357830 = 9497249380038 := by decide
theorem cert_e701156357830 : check e701156357830 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156364154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))) (.var 0)))
theorem wire_e701156364154 : Closed e701156364154 ∧ code e701156364154 = 9497249386362 := by decide
theorem cert_e701156364154 : check e701156364154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156364218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))) (.var 0)))
theorem wire_e701156364218 : Closed e701156364218 ∧ code e701156364218 = 9497249386426 := by decide
theorem cert_e701156364218 : check e701156364218 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156371898 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701156371898 : Closed e701156371898 ∧ code e701156371898 = 9497249394106 := by decide
theorem cert_e701156371898 : check e701156371898 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156371930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701156371930 : Closed e701156371930 ∧ code e701156371930 = 9497249394138 := by decide
theorem cert_e701156371930 : check e701156371930 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156372154 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701156372154 : Closed e701156372154 ∧ code e701156372154 = 9497249394362 := by decide
theorem cert_e701156372154 : check e701156372154 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156372202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701156372202 : Closed e701156372202 ∧ code e701156372202 = 9497249394410 := by decide
theorem cert_e701156372202 : check e701156372202 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156372314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701156372314 : Closed e701156372314 ∧ code e701156372314 = 9497249394522 := by decide
theorem cert_e701156372314 : check e701156372314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156372330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701156372330 : Closed e701156372330 ∧ code e701156372330 = 9497249394538 := by decide
theorem cert_e701156372330 : check e701156372330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156373434 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701156373434 : Closed e701156373434 ∧ code e701156373434 = 9497249395642 := by decide
theorem cert_e701156373434 : check e701156373434 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156373466 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701156373466 : Closed e701156373466 ∧ code e701156373466 = 9497249395674 := by decide
theorem cert_e701156373466 : check e701156373466 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156374970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701156374970 : Closed e701156374970 ∧ code e701156374970 = 9497249397178 := by decide
theorem cert_e701156374970 : check e701156374970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156375018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701156375018 : Closed e701156375018 ∧ code e701156375018 = 9497249397226 := by decide
theorem cert_e701156375018 : check e701156375018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156375450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156375450 : Closed e701156375450 ∧ code e701156375450 = 9497249397658 := by decide
theorem cert_e701156375450 : check e701156375450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156375770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701156375770 : Closed e701156375770 ∧ code e701156375770 = 9497249397978 := by decide
theorem cert_e701156375770 : check e701156375770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156375786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701156375786 : Closed e701156375786 ∧ code e701156375786 = 9497249397994 := by decide
theorem cert_e701156375786 : check e701156375786 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156375962 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156375962 : Closed e701156375962 ∧ code e701156375962 = 9497249398170 := by decide
theorem cert_e701156375962 : check e701156375962 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156394874 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))) (.var 0)))
theorem wire_e701156394874 : Closed e701156394874 ∧ code e701156394874 = 9497249417082 := by decide
theorem cert_e701156394874 : check e701156394874 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156394970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))) (.var 0)))
theorem wire_e701156394970 : Closed e701156394970 ∧ code e701156394970 = 9497249417178 := by decide
theorem cert_e701156394970 : check e701156394970 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156398778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701156398778 : Closed e701156398778 ∧ code e701156398778 = 9497249420986 := by decide
theorem cert_e701156398778 : check e701156398778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156398826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701156398826 : Closed e701156398826 ∧ code e701156398826 = 9497249421034 := by decide
theorem cert_e701156398826 : check e701156398826 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156399018 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701156399018 : Closed e701156399018 ∧ code e701156399018 = 9497249421226 := by decide
theorem cert_e701156399018 : check e701156399018 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156399546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701156399546 : Closed e701156399546 ∧ code e701156399546 = 9497249421754 := by decide
theorem cert_e701156399546 : check e701156399546 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156399594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701156399594 : Closed e701156399594 ∧ code e701156399594 = 9497249421802 := by decide
theorem cert_e701156399594 : check e701156399594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701156400026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.var 0))))
theorem wire_e701156400026 : Closed e701156400026 ∧ code e701156400026 = 9497249422234 := by decide
theorem cert_e701156400026 : check e701156400026 [[.under,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor43
