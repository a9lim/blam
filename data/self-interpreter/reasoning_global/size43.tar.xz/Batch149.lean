import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259250808334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259250808334 : Closed e2259250808334 ∧ code e2259250808334 = 11055343830542 := by decide
theorem cert_e2259250808334 : check e2259250808334 [[]] .width = true := by decide
def e2259250808346 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259250808346 : Closed e2259250808346 ∧ code e2259250808346 = 11055343830554 := by decide
theorem cert_e2259250808346 : check e2259250808346 [[]] .width = true := by decide
def e2259250808418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259250808418 : Closed e2259250808418 ∧ code e2259250808418 = 11055343830626 := by decide
theorem cert_e2259250808418 : check e2259250808418 [[]] .width = true := by decide
def e2259251224602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259251224602 : Closed e2259251224602 ∧ code e2259251224602 = 11055344246810 := by decide
theorem cert_e2259251224602 : check e2259251224602 [[]] .width = true := by decide
def e2259251224694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259251224694 : Closed e2259251224694 ∧ code e2259251224694 = 11055344246902 := by decide
theorem cert_e2259251224694 : check e2259251224694 [[]] .width = true := by decide
def e2259251224938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259251224938 : Closed e2259251224938 ∧ code e2259251224938 = 11055344247146 := by decide
theorem cert_e2259251224938 : check e2259251224938 [[]] .width = true := by decide
def e2259251224986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259251224986 : Closed e2259251224986 ∧ code e2259251224986 = 11055344247194 := by decide
theorem cert_e2259251224986 : check e2259251224986 [[]] .width = true := by decide
def e2259251265562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259251265562 : Closed e2259251265562 ∧ code e2259251265562 = 11055344287770 := by decide
theorem cert_e2259251265562 : check e2259251265562 [[]] .width = true := by decide
def e2259251265654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259251265654 : Closed e2259251265654 ∧ code e2259251265654 = 11055344287862 := by decide
theorem cert_e2259251265654 : check e2259251265654 [[]] .width = true := by decide
def e2259251265898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259251265898 : Closed e2259251265898 ∧ code e2259251265898 = 11055344288106 := by decide
theorem cert_e2259251265898 : check e2259251265898 [[]] .width = true := by decide
def e2259251265946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259251265946 : Closed e2259251265946 ∧ code e2259251265946 = 11055344288154 := by decide
theorem cert_e2259251265946 : check e2259251265946 [[]] .width = true := by decide
def e2259251266954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259251266954 : Closed e2259251266954 ∧ code e2259251266954 = 11055344289162 := by decide
theorem cert_e2259251266954 : check e2259251266954 [[]] .width = true := by decide
def e2259251266978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259251266978 : Closed e2259251266978 ∧ code e2259251266978 = 11055344289186 := by decide
private def t_e2259251266978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2259251266978 : ¬ IsSelfInterpreter e2259251266978 :=
  wSource (t := t_e2259251266978) (replay_sound (ps := []) (t := e2259251266978) (by decide)) (by decide)
def e2259251267086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259251267086 : Closed e2259251267086 ∧ code e2259251267086 = 11055344289294 := by decide
theorem cert_e2259251267086 : check e2259251267086 [[]] .width = true := by decide
def e2259251267098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259251267098 : Closed e2259251267098 ∧ code e2259251267098 = 11055344289306 := by decide
private def t_e2259251267098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2259251267098 : ¬ IsSelfInterpreter e2259251267098 :=
  wSource (t := t_e2259251267098) (replay_sound (ps := []) (t := e2259251267098) (by decide)) (by decide)
def e2259251267170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259251267170 : Closed e2259251267170 ∧ code e2259251267170 = 11055344289378 := by decide
theorem cert_e2259251267170 : check e2259251267170 [[]] .width = true := by decide
def e2259251290138 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259251290138 : Closed e2259251290138 ∧ code e2259251290138 = 11055344312346 := by decide
theorem cert_e2259251290138 : check e2259251290138 [[]] .width = true := by decide
def e2259251290230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259251290230 : Closed e2259251290230 ∧ code e2259251290230 = 11055344312438 := by decide
private def t_e2259251290230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2259251290230 : ¬ IsSelfInterpreter e2259251290230 :=
  wSource (t := t_e2259251290230) (replay_sound (ps := []) (t := e2259251290230) (by decide)) (by decide)
def e2259251290474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259251290474 : Closed e2259251290474 ∧ code e2259251290474 = 11055344312682 := by decide
private def t_e2259251290474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2259251290474 : ¬ IsSelfInterpreter e2259251290474 :=
  wSource (t := t_e2259251290474) (replay_sound (ps := []) (t := e2259251290474) (by decide)) (by decide)
def e2259251290522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259251290522 : Closed e2259251290522 ∧ code e2259251290522 = 11055344312730 := by decide
private def t_e2259251290522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2259251290522 : ¬ IsSelfInterpreter e2259251290522 :=
  wSource (t := t_e2259251290522) (replay_sound (ps := []) (t := e2259251290522) (by decide)) (by decide)
def e2259252134086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259252134086 : Closed e2259252134086 ∧ code e2259252134086 = 11055345156294 := by decide
theorem cert_e2259252134086 : check e2259252134086 [[]] .width = true := by decide
def e2259252273178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259252273178 : Closed e2259252273178 ∧ code e2259252273178 = 11055345295386 := by decide
theorem cert_e2259252273178 : check e2259252273178 [[]] .width = true := by decide
def e2259252273270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259252273270 : Closed e2259252273270 ∧ code e2259252273270 = 11055345295478 := by decide
theorem cert_e2259252273270 : check e2259252273270 [[]] .width = true := by decide
def e2259252273514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259252273514 : Closed e2259252273514 ∧ code e2259252273514 = 11055345295722 := by decide
theorem cert_e2259252273514 : check e2259252273514 [[]] .width = true := by decide
def e2259252273562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259252273562 : Closed e2259252273562 ∧ code e2259252273562 = 11055345295770 := by decide
theorem cert_e2259252273562 : check e2259252273562 [[]] .width = true := by decide
def e2259252363462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259252363462 : Closed e2259252363462 ∧ code e2259252363462 = 11055345385670 := by decide
theorem cert_e2259252363462 : check e2259252363462 [[]] .width = true := by decide
def e2259252371482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259252371482 : Closed e2259252371482 ∧ code e2259252371482 = 11055345393690 := by decide
theorem cert_e2259252371482 : check e2259252371482 [[]] .width = true := by decide
def e2259252371574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259252371574 : Closed e2259252371574 ∧ code e2259252371574 = 11055345393782 := by decide
theorem cert_e2259252371574 : check e2259252371574 [[]] .width = true := by decide
def e2259252371818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259252371818 : Closed e2259252371818 ∧ code e2259252371818 = 11055345394026 := by decide
theorem cert_e2259252371818 : check e2259252371818 [[]] .width = true := by decide
def e2259252371866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259252371866 : Closed e2259252371866 ∧ code e2259252371866 = 11055345394074 := by decide
theorem cert_e2259252371866 : check e2259252371866 [[]] .width = true := by decide
def e2259252772890 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259252772890 : Closed e2259252772890 ∧ code e2259252772890 = 11055345795098 := by decide
theorem cert_e2259252772890 : check e2259252772890 [[]] .width = true := by decide
def e2259252772982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259252772982 : Closed e2259252772982 ∧ code e2259252772982 = 11055345795190 := by decide
theorem cert_e2259252772982 : check e2259252772982 [[]] .width = true := by decide
def e2259252773226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259252773226 : Closed e2259252773226 ∧ code e2259252773226 = 11055345795434 := by decide
theorem cert_e2259252773226 : check e2259252773226 [[]] .width = true := by decide
def e2259252773274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259252773274 : Closed e2259252773274 ∧ code e2259252773274 = 11055345795482 := by decide
theorem cert_e2259252773274 : check e2259252773274 [[]] .width = true := by decide
def e2259252774282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259252774282 : Closed e2259252774282 ∧ code e2259252774282 = 11055345796490 := by decide
theorem cert_e2259252774282 : check e2259252774282 [[]] .width = true := by decide
def e2259252774306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259252774306 : Closed e2259252774306 ∧ code e2259252774306 = 11055345796514 := by decide
theorem cert_e2259252774306 : check e2259252774306 [[]] .width = true := by decide
def e2259252774414 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259252774414 : Closed e2259252774414 ∧ code e2259252774414 = 11055345796622 := by decide
theorem cert_e2259252774414 : check e2259252774414 [[]] .width = true := by decide
def e2259252774426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259252774426 : Closed e2259252774426 ∧ code e2259252774426 = 11055345796634 := by decide
theorem cert_e2259252774426 : check e2259252774426 [[]] .width = true := by decide
def e2259252774498 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259252774498 : Closed e2259252774498 ∧ code e2259252774498 = 11055345796706 := by decide
theorem cert_e2259252774498 : check e2259252774498 [[]] .width = true := by decide
def e2259252789446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259252789446 : Closed e2259252789446 ∧ code e2259252789446 = 11055345811654 := by decide
theorem cert_e2259252789446 : check e2259252789446 [[]] .width = true := by decide
def e2259252838426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259252838426 : Closed e2259252838426 ∧ code e2259252838426 = 11055345860634 := by decide
theorem cert_e2259252838426 : check e2259252838426 [[]] .width = true := by decide
def e2259252838518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259252838518 : Closed e2259252838518 ∧ code e2259252838518 = 11055345860726 := by decide
theorem cert_e2259252838518 : check e2259252838518 [[]] .width = true := by decide
def e2259252838762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259252838762 : Closed e2259252838762 ∧ code e2259252838762 = 11055345860970 := by decide
theorem cert_e2259252838762 : check e2259252838762 [[]] .width = true := by decide
def e2259252838810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259252838810 : Closed e2259252838810 ∧ code e2259252838810 = 11055345861018 := by decide
theorem cert_e2259252838810 : check e2259252838810 [[]] .width = true := by decide
def e2259252839818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259252839818 : Closed e2259252839818 ∧ code e2259252839818 = 11055345862026 := by decide
theorem cert_e2259252839818 : check e2259252839818 [[]] .width = true := by decide
def e2259252839842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259252839842 : Closed e2259252839842 ∧ code e2259252839842 = 11055345862050 := by decide
private def t_e2259252839842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2259252839842 : ¬ IsSelfInterpreter e2259252839842 :=
  wSource (t := t_e2259252839842) (replay_sound (ps := []) (t := e2259252839842) (by decide)) (by decide)
def e2259252839950 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259252839950 : Closed e2259252839950 ∧ code e2259252839950 = 11055345862158 := by decide
theorem cert_e2259252839950 : check e2259252839950 [[]] .width = true := by decide
def e2259252839962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259252839962 : Closed e2259252839962 ∧ code e2259252839962 = 11055345862170 := by decide
private def t_e2259252839962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2259252839962 : ¬ IsSelfInterpreter e2259252839962 :=
  wSource (t := t_e2259252839962) (replay_sound (ps := []) (t := e2259252839962) (by decide)) (by decide)
def e2259252840034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259252840034 : Closed e2259252840034 ∧ code e2259252840034 = 11055345862242 := by decide
theorem cert_e2259252840034 : check e2259252840034 [[]] .width = true := by decide
def e2259252863002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259252863002 : Closed e2259252863002 ∧ code e2259252863002 = 11055345885210 := by decide
theorem cert_e2259252863002 : check e2259252863002 [[]] .width = true := by decide
def e2259252863094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259252863094 : Closed e2259252863094 ∧ code e2259252863094 = 11055345885302 := by decide
private def t_e2259252863094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2259252863094 : ¬ IsSelfInterpreter e2259252863094 :=
  wSource (t := t_e2259252863094) (replay_sound (ps := []) (t := e2259252863094) (by decide)) (by decide)
def e2259252863338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259252863338 : Closed e2259252863338 ∧ code e2259252863338 = 11055345885546 := by decide
private def t_e2259252863338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2259252863338 : ¬ IsSelfInterpreter e2259252863338 :=
  wSource (t := t_e2259252863338) (replay_sound (ps := []) (t := e2259252863338) (by decide)) (by decide)
def e2259252863386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259252863386 : Closed e2259252863386 ∧ code e2259252863386 = 11055345885594 := by decide
private def t_e2259252863386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2259252863386 : ¬ IsSelfInterpreter e2259252863386 :=
  wSource (t := t_e2259252863386) (replay_sound (ps := []) (t := e2259252863386) (by decide)) (by decide)
def e2259252887750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259252887750 : Closed e2259252887750 ∧ code e2259252887750 = 11055345909958 := by decide
theorem cert_e2259252887750 : check e2259252887750 [[]] .width = true := by decide
def e2259252895770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259252895770 : Closed e2259252895770 ∧ code e2259252895770 = 11055345917978 := by decide
theorem cert_e2259252895770 : check e2259252895770 [[]] .width = true := by decide
def e2259252895862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259252895862 : Closed e2259252895862 ∧ code e2259252895862 = 11055345918070 := by decide
theorem cert_e2259252895862 : check e2259252895862 [[]] .width = true := by decide
def e2259252896106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259252896106 : Closed e2259252896106 ∧ code e2259252896106 = 11055345918314 := by decide
theorem cert_e2259252896106 : check e2259252896106 [[]] .width = true := by decide
def e2259252896154 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259252896154 : Closed e2259252896154 ∧ code e2259252896154 = 11055345918362 := by decide
theorem cert_e2259252896154 : check e2259252896154 [[]] .width = true := by decide
def e2259261292570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259261292570 : Closed e2259261292570 ∧ code e2259261292570 = 11055354314778 := by decide
theorem cert_e2259261292570 : check e2259261292570 [[]] .width = true := by decide
def e2259261292662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259261292662 : Closed e2259261292662 ∧ code e2259261292662 = 11055354314870 := by decide
theorem cert_e2259261292662 : check e2259261292662 [[]] .width = true := by decide
def e2259261292906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259261292906 : Closed e2259261292906 ∧ code e2259261292906 = 11055354315114 := by decide
theorem cert_e2259261292906 : check e2259261292906 [[]] .width = true := by decide
def e2259261292954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259261292954 : Closed e2259261292954 ∧ code e2259261292954 = 11055354315162 := by decide
theorem cert_e2259261292954 : check e2259261292954 [[]] .width = true := by decide
def e2259261293962 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259261293962 : Closed e2259261293962 ∧ code e2259261293962 = 11055354316170 := by decide
theorem cert_e2259261293962 : check e2259261293962 [[]] .width = true := by decide
def e2259261293986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259261293986 : Closed e2259261293986 ∧ code e2259261293986 = 11055354316194 := by decide
theorem cert_e2259261293986 : check e2259261293986 [[]] .width = true := by decide
def e2259261294094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259261294094 : Closed e2259261294094 ∧ code e2259261294094 = 11055354316302 := by decide
theorem cert_e2259261294094 : check e2259261294094 [[]] .width = true := by decide
def e2259261294106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259261294106 : Closed e2259261294106 ∧ code e2259261294106 = 11055354316314 := by decide
theorem cert_e2259261294106 : check e2259261294106 [[]] .width = true := by decide
def e2259261294178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259261294178 : Closed e2259261294178 ∧ code e2259261294178 = 11055354316386 := by decide
theorem cert_e2259261294178 : check e2259261294178 [[]] .width = true := by decide
def e2259261571270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259261571270 : Closed e2259261571270 ∧ code e2259261571270 = 11055354593478 := by decide
theorem cert_e2259261571270 : check e2259261571270 [[]] .width = true := by decide
def e2259261685786 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259261685786 : Closed e2259261685786 ∧ code e2259261685786 = 11055354707994 := by decide
theorem cert_e2259261685786 : check e2259261685786 [[]] .width = true := by decide
def e2259261685878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259261685878 : Closed e2259261685878 ∧ code e2259261685878 = 11055354708086 := by decide
theorem cert_e2259261685878 : check e2259261685878 [[]] .width = true := by decide
def e2259261686122 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259261686122 : Closed e2259261686122 ∧ code e2259261686122 = 11055354708330 := by decide
theorem cert_e2259261686122 : check e2259261686122 [[]] .width = true := by decide
def e2259261686170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259261686170 : Closed e2259261686170 ∧ code e2259261686170 = 11055354708378 := by decide
theorem cert_e2259261686170 : check e2259261686170 [[]] .width = true := by decide
def e2259261687178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259261687178 : Closed e2259261687178 ∧ code e2259261687178 = 11055354709386 := by decide
theorem cert_e2259261687178 : check e2259261687178 [[]] .width = true := by decide
def e2259261687202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259261687202 : Closed e2259261687202 ∧ code e2259261687202 = 11055354709410 := by decide
theorem cert_e2259261687202 : check e2259261687202 [[]] .width = true := by decide
def e2259261687310 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259261687310 : Closed e2259261687310 ∧ code e2259261687310 = 11055354709518 := by decide
theorem cert_e2259261687310 : check e2259261687310 [[]] .width = true := by decide
def e2259261687322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259261687322 : Closed e2259261687322 ∧ code e2259261687322 = 11055354709530 := by decide
theorem cert_e2259261687322 : check e2259261687322 [[]] .width = true := by decide
def e2259261687394 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259261687394 : Closed e2259261687394 ∧ code e2259261687394 = 11055354709602 := by decide
theorem cert_e2259261687394 : check e2259261687394 [[]] .width = true := by decide
def e2259261702342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259261702342 : Closed e2259261702342 ∧ code e2259261702342 = 11055354724550 := by decide
theorem cert_e2259261702342 : check e2259261702342 [[]] .width = true := by decide
def e2259273875482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259273875482 : Closed e2259273875482 ∧ code e2259273875482 = 11055366897690 := by decide
theorem cert_e2259273875482 : check e2259273875482 [[]] .width = true := by decide
def e2259273875574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259273875574 : Closed e2259273875574 ∧ code e2259273875574 = 11055366897782 := by decide
theorem cert_e2259273875574 : check e2259273875574 [[]] .width = true := by decide
def e2259273875818 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259273875818 : Closed e2259273875818 ∧ code e2259273875818 = 11055366898026 := by decide
theorem cert_e2259273875818 : check e2259273875818 [[]] .width = true := by decide
def e2259273875866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259273875866 : Closed e2259273875866 ∧ code e2259273875866 = 11055366898074 := by decide
theorem cert_e2259273875866 : check e2259273875866 [[]] .width = true := by decide
def e2259273876874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259273876874 : Closed e2259273876874 ∧ code e2259273876874 = 11055366899082 := by decide
theorem cert_e2259273876874 : check e2259273876874 [[]] .width = true := by decide
def e2259273876898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259273876898 : Closed e2259273876898 ∧ code e2259273876898 = 11055366899106 := by decide
theorem cert_e2259273876898 : check e2259273876898 [[]] .width = true := by decide
def e2259273877006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259273877006 : Closed e2259273877006 ∧ code e2259273877006 = 11055366899214 := by decide
theorem cert_e2259273877006 : check e2259273877006 [[]] .width = true := by decide
def e2259273877018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259273877018 : Closed e2259273877018 ∧ code e2259273877018 = 11055366899226 := by decide
theorem cert_e2259273877018 : check e2259273877018 [[]] .width = true := by decide
def e2259273877090 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259273877090 : Closed e2259273877090 ∧ code e2259273877090 = 11055366899298 := by decide
theorem cert_e2259273877090 : check e2259273877090 [[]] .width = true := by decide
def e2259274293274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259274293274 : Closed e2259274293274 ∧ code e2259274293274 = 11055367315482 := by decide
theorem cert_e2259274293274 : check e2259274293274 [[]] .width = true := by decide
def e2259274293366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259274293366 : Closed e2259274293366 ∧ code e2259274293366 = 11055367315574 := by decide
theorem cert_e2259274293366 : check e2259274293366 [[]] .width = true := by decide
def e2259274293610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259274293610 : Closed e2259274293610 ∧ code e2259274293610 = 11055367315818 := by decide
theorem cert_e2259274293610 : check e2259274293610 [[]] .width = true := by decide
def e2259274293658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259274293658 : Closed e2259274293658 ∧ code e2259274293658 = 11055367315866 := by decide
theorem cert_e2259274293658 : check e2259274293658 [[]] .width = true := by decide
def e2259274334234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259274334234 : Closed e2259274334234 ∧ code e2259274334234 = 11055367356442 := by decide
theorem cert_e2259274334234 : check e2259274334234 [[]] .width = true := by decide
def e2259274334326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259274334326 : Closed e2259274334326 ∧ code e2259274334326 = 11055367356534 := by decide
theorem cert_e2259274334326 : check e2259274334326 [[]] .width = true := by decide
def e2259274334570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259274334570 : Closed e2259274334570 ∧ code e2259274334570 = 11055367356778 := by decide
theorem cert_e2259274334570 : check e2259274334570 [[]] .width = true := by decide
def e2259274334618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259274334618 : Closed e2259274334618 ∧ code e2259274334618 = 11055367356826 := by decide
theorem cert_e2259274334618 : check e2259274334618 [[]] .width = true := by decide
def e2259274335626 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259274335626 : Closed e2259274335626 ∧ code e2259274335626 = 11055367357834 := by decide
theorem cert_e2259274335626 : check e2259274335626 [[]] .width = true := by decide
def e2259274335650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259274335650 : Closed e2259274335650 ∧ code e2259274335650 = 11055367357858 := by decide
theorem cert_e2259274335650 : check e2259274335650 [[]] .width = true := by decide
def e2259274335758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259274335758 : Closed e2259274335758 ∧ code e2259274335758 = 11055367357966 := by decide
theorem cert_e2259274335758 : check e2259274335758 [[]] .width = true := by decide
def e2259274335770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259274335770 : Closed e2259274335770 ∧ code e2259274335770 = 11055367357978 := by decide
theorem cert_e2259274335770 : check e2259274335770 [[]] .width = true := by decide
def e2259274335842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259274335842 : Closed e2259274335842 ∧ code e2259274335842 = 11055367358050 := by decide
theorem cert_e2259274335842 : check e2259274335842 [[]] .width = true := by decide
def e2259274358810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259274358810 : Closed e2259274358810 ∧ code e2259274358810 = 11055367381018 := by decide
theorem cert_e2259274358810 : check e2259274358810 [[]] .width = true := by decide
def e2259274358902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259274358902 : Closed e2259274358902 ∧ code e2259274358902 = 11055367381110 := by decide
theorem cert_e2259274358902 : check e2259274358902 [[]] .width = true := by decide
def e2259274359146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259274359146 : Closed e2259274359146 ∧ code e2259274359146 = 11055367381354 := by decide
theorem cert_e2259274359146 : check e2259274359146 [[]] .width = true := by decide
def e2259274359194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259274359194 : Closed e2259274359194 ∧ code e2259274359194 = 11055367381402 := by decide
theorem cert_e2259274359194 : check e2259274359194 [[]] .width = true := by decide
def e2259280445638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259280445638 : Closed e2259280445638 ∧ code e2259280445638 = 11055373467846 := by decide
theorem cert_e2259280445638 : check e2259280445638 [[]] .width = true := by decide
def e2259280584730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259280584730 : Closed e2259280584730 ∧ code e2259280584730 = 11055373606938 := by decide
theorem cert_e2259280584730 : check e2259280584730 [[]] .width = true := by decide
def e2259280584822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259280584822 : Closed e2259280584822 ∧ code e2259280584822 = 11055373607030 := by decide
theorem cert_e2259280584822 : check e2259280584822 [[]] .width = true := by decide
def e2259280585066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259280585066 : Closed e2259280585066 ∧ code e2259280585066 = 11055373607274 := by decide
theorem cert_e2259280585066 : check e2259280585066 [[]] .width = true := by decide
def e2259280585114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259280585114 : Closed e2259280585114 ∧ code e2259280585114 = 11055373607322 := by decide
theorem cert_e2259280585114 : check e2259280585114 [[]] .width = true := by decide
def e2259280675014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259280675014 : Closed e2259280675014 ∧ code e2259280675014 = 11055373697222 := by decide
theorem cert_e2259280675014 : check e2259280675014 [[]] .width = true := by decide
def e2259280683034 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259280683034 : Closed e2259280683034 ∧ code e2259280683034 = 11055373705242 := by decide
theorem cert_e2259280683034 : check e2259280683034 [[]] .width = true := by decide
def e2259280683126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259280683126 : Closed e2259280683126 ∧ code e2259280683126 = 11055373705334 := by decide
theorem cert_e2259280683126 : check e2259280683126 [[]] .width = true := by decide
def e2259280683370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259280683370 : Closed e2259280683370 ∧ code e2259280683370 = 11055373705578 := by decide
theorem cert_e2259280683370 : check e2259280683370 [[]] .width = true := by decide
def e2259280683418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259280683418 : Closed e2259280683418 ∧ code e2259280683418 = 11055373705626 := by decide
theorem cert_e2259280683418 : check e2259280683418 [[]] .width = true := by decide
def e2259283705882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259283705882 : Closed e2259283705882 ∧ code e2259283705882 = 11055376728090 := by decide
theorem cert_e2259283705882 : check e2259283705882 [[]] .width = true := by decide
def e2259283705974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259283705974 : Closed e2259283705974 ∧ code e2259283705974 = 11055376728182 := by decide
theorem cert_e2259283705974 : check e2259283705974 [[]] .width = true := by decide
def e2259283706218 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259283706218 : Closed e2259283706218 ∧ code e2259283706218 = 11055376728426 := by decide
theorem cert_e2259283706218 : check e2259283706218 [[]] .width = true := by decide
def e2259283706266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259283706266 : Closed e2259283706266 ∧ code e2259283706266 = 11055376728474 := by decide
theorem cert_e2259283706266 : check e2259283706266 [[]] .width = true := by decide
def e2259283707274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259283707274 : Closed e2259283707274 ∧ code e2259283707274 = 11055376729482 := by decide
theorem cert_e2259283707274 : check e2259283707274 [[]] .width = true := by decide
def e2259283707298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259283707298 : Closed e2259283707298 ∧ code e2259283707298 = 11055376729506 := by decide
theorem cert_e2259283707298 : check e2259283707298 [[]] .width = true := by decide
def e2259283707406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259283707406 : Closed e2259283707406 ∧ code e2259283707406 = 11055376729614 := by decide
theorem cert_e2259283707406 : check e2259283707406 [[]] .width = true := by decide
def e2259283707418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259283707418 : Closed e2259283707418 ∧ code e2259283707418 = 11055376729626 := by decide
theorem cert_e2259283707418 : check e2259283707418 [[]] .width = true := by decide
def e2259283707490 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259283707490 : Closed e2259283707490 ∧ code e2259283707490 = 11055376729698 := by decide
theorem cert_e2259283707490 : check e2259283707490 [[]] .width = true := by decide
def e2259283722438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259283722438 : Closed e2259283722438 ∧ code e2259283722438 = 11055376744646 := by decide
theorem cert_e2259283722438 : check e2259283722438 [[]] .width = true := by decide
def e2259283771418 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259283771418 : Closed e2259283771418 ∧ code e2259283771418 = 11055376793626 := by decide
theorem cert_e2259283771418 : check e2259283771418 [[]] .width = true := by decide
def e2259283771510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259283771510 : Closed e2259283771510 ∧ code e2259283771510 = 11055376793718 := by decide
theorem cert_e2259283771510 : check e2259283771510 [[]] .width = true := by decide
def e2259283771754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259283771754 : Closed e2259283771754 ∧ code e2259283771754 = 11055376793962 := by decide
theorem cert_e2259283771754 : check e2259283771754 [[]] .width = true := by decide
def e2259283771802 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259283771802 : Closed e2259283771802 ∧ code e2259283771802 = 11055376794010 := by decide
theorem cert_e2259283771802 : check e2259283771802 [[]] .width = true := by decide
def e2259283772810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259283772810 : Closed e2259283772810 ∧ code e2259283772810 = 11055376795018 := by decide
theorem cert_e2259283772810 : check e2259283772810 [[]] .width = true := by decide
def e2259283772834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259283772834 : Closed e2259283772834 ∧ code e2259283772834 = 11055376795042 := by decide
theorem cert_e2259283772834 : check e2259283772834 [[]] .width = true := by decide
def e2259283772942 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259283772942 : Closed e2259283772942 ∧ code e2259283772942 = 11055376795150 := by decide
theorem cert_e2259283772942 : check e2259283772942 [[]] .width = true := by decide
def e2259283772954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259283772954 : Closed e2259283772954 ∧ code e2259283772954 = 11055376795162 := by decide
theorem cert_e2259283772954 : check e2259283772954 [[]] .width = true := by decide
def e2259283773026 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259283773026 : Closed e2259283773026 ∧ code e2259283773026 = 11055376795234 := by decide
theorem cert_e2259283773026 : check e2259283773026 [[]] .width = true := by decide
def e2259283795994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259283795994 : Closed e2259283795994 ∧ code e2259283795994 = 11055376818202 := by decide
theorem cert_e2259283795994 : check e2259283795994 [[]] .width = true := by decide
def e2259283796086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259283796086 : Closed e2259283796086 ∧ code e2259283796086 = 11055376818294 := by decide
theorem cert_e2259283796086 : check e2259283796086 [[]] .width = true := by decide
def e2259283796330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259283796330 : Closed e2259283796330 ∧ code e2259283796330 = 11055376818538 := by decide
theorem cert_e2259283796330 : check e2259283796330 [[]] .width = true := by decide
def e2259283796378 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259283796378 : Closed e2259283796378 ∧ code e2259283796378 = 11055376818586 := by decide
theorem cert_e2259283796378 : check e2259283796378 [[]] .width = true := by decide
def e2259283820742 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259283820742 : Closed e2259283820742 ∧ code e2259283820742 = 11055376842950 := by decide
theorem cert_e2259283820742 : check e2259283820742 [[]] .width = true := by decide
def e2259283828762 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259283828762 : Closed e2259283828762 ∧ code e2259283828762 = 11055376850970 := by decide
theorem cert_e2259283828762 : check e2259283828762 [[]] .width = true := by decide
def e2259283828854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259283828854 : Closed e2259283828854 ∧ code e2259283828854 = 11055376851062 := by decide
theorem cert_e2259283828854 : check e2259283828854 [[]] .width = true := by decide
def e2259283829098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259283829098 : Closed e2259283829098 ∧ code e2259283829098 = 11055376851306 := by decide
theorem cert_e2259283829098 : check e2259283829098 [[]] .width = true := by decide
def e2259283829146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259283829146 : Closed e2259283829146 ∧ code e2259283829146 = 11055376851354 := by decide
theorem cert_e2259283829146 : check e2259283829146 [[]] .width = true := by decide
def e2259404500334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2259404500334 : Closed e2259404500334 ∧ code e2259404500334 = 11055497522542 := by decide
theorem cert_e2259404500334 : check e2259404500334 [[],[.under]] .three = true := by decide
def e2259404500342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2259404500342 : Closed e2259404500342 ∧ code e2259404500342 = 11055497522550 := by decide
theorem cert_e2259404500342 : check e2259404500342 [[],[.under]] .three = true := by decide
def e2259404500398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2259404500398 : Closed e2259404500398 ∧ code e2259404500398 = 11055497522606 := by decide
theorem cert_e2259404500398 : check e2259404500398 [[],[.under]] .three = true := by decide
def e2259404500410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2259404500410 : Closed e2259404500410 ∧ code e2259404500410 = 11055497522618 := by decide
theorem cert_e2259404500410 : check e2259404500410 [[],[.under]] .three = true := by decide
def e2259404500438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2259404500438 : Closed e2259404500438 ∧ code e2259404500438 = 11055497522646 := by decide
theorem cert_e2259404500438 : check e2259404500438 [[],[.under]] .three = true := by decide
def e2259404500442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2259404500442 : Closed e2259404500442 ∧ code e2259404500442 = 11055497522650 := by decide
theorem cert_e2259404500442 : check e2259404500442 [[],[.under]] .three = true := by decide
def e2259404500654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2259404500654 : Closed e2259404500654 ∧ code e2259404500654 = 11055497522862 := by decide
theorem cert_e2259404500654 : check e2259404500654 [[],[.under]] .three = true := by decide
def e2259404500666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2259404500666 : Closed e2259404500666 ∧ code e2259404500666 = 11055497522874 := by decide
theorem cert_e2259404500666 : check e2259404500666 [[],[.under]] .three = true := by decide
def e2259404500714 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2259404500714 : Closed e2259404500714 ∧ code e2259404500714 = 11055497522922 := by decide
theorem cert_e2259404500714 : check e2259404500714 [[],[.under]] .three = true := by decide
def e2259404500822 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2259404500822 : Closed e2259404500822 ∧ code e2259404500822 = 11055497523030 := by decide
theorem cert_e2259404500822 : check e2259404500822 [[],[.under]] .three = true := by decide
def e2259404500826 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2259404500826 : Closed e2259404500826 ∧ code e2259404500826 = 11055497523034 := by decide
theorem cert_e2259404500826 : check e2259404500826 [[],[.under]] .three = true := by decide
def e2259404500842 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2259404500842 : Closed e2259404500842 ∧ code e2259404500842 = 11055497523050 := by decide
theorem cert_e2259404500842 : check e2259404500842 [[],[.under]] .three = true := by decide
def e2259404501870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2259404501870 : Closed e2259404501870 ∧ code e2259404501870 = 11055497524078 := by decide
theorem cert_e2259404501870 : check e2259404501870 [[],[.under]] .three = true := by decide
def e2259404501878 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2259404501878 : Closed e2259404501878 ∧ code e2259404501878 = 11055497524086 := by decide
theorem cert_e2259404501878 : check e2259404501878 [[],[.under]] .three = true := by decide
def e2259404501934 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2259404501934 : Closed e2259404501934 ∧ code e2259404501934 = 11055497524142 := by decide
theorem cert_e2259404501934 : check e2259404501934 [[],[.under]] .three = true := by decide
def e2259404501946 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2259404501946 : Closed e2259404501946 ∧ code e2259404501946 = 11055497524154 := by decide
theorem cert_e2259404501946 : check e2259404501946 [[],[.under]] .three = true := by decide
def e2259404501974 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2259404501974 : Closed e2259404501974 ∧ code e2259404501974 = 11055497524182 := by decide
theorem cert_e2259404501974 : check e2259404501974 [[],[.under]] .three = true := by decide
def e2259404501978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2259404501978 : Closed e2259404501978 ∧ code e2259404501978 = 11055497524186 := by decide
theorem cert_e2259404501978 : check e2259404501978 [[],[.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259251266978
#print axioms Blc.Floor43.cert_e2259251267098
#print axioms Blc.Floor43.cert_e2259251290230
#print axioms Blc.Floor43.cert_e2259251290474
#print axioms Blc.Floor43.cert_e2259251290522
#print axioms Blc.Floor43.cert_e2259252839842
#print axioms Blc.Floor43.cert_e2259252839962
#print axioms Blc.Floor43.cert_e2259252863094
#print axioms Blc.Floor43.cert_e2259252863338
#print axioms Blc.Floor43.cert_e2259252863386
