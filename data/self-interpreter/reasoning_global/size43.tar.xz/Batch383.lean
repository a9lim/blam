import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364690910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364690910 : Closed e2422364690910 ∧ code e2422364690910 = 11218457713118 := by decide
theorem cert_e2422364690910 : check e2422364690910 [[],[]] .three = true := by decide
def e2422364690926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364690926 : Closed e2422364690926 ∧ code e2422364690926 = 11218457713134 := by decide
theorem cert_e2422364690926 : check e2422364690926 [[],[]] .three = true := by decide
def e2422364690934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364690934 : Closed e2422364690934 ∧ code e2422364690934 = 11218457713142 := by decide
theorem cert_e2422364690934 : check e2422364690934 [[],[]] .three = true := by decide
def e2422364690938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364690938 : Closed e2422364690938 ∧ code e2422364690938 = 11218457713146 := by decide
theorem cert_e2422364690938 : check e2422364690938 [[],[]] .three = true := by decide
def e2422364691654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422364691654 : Closed e2422364691654 ∧ code e2422364691654 = 11218457713862 := by decide
theorem cert_e2422364691654 : check e2422364691654 [[],[]] .three = true := by decide
def e2422364691694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364691694 : Closed e2422364691694 ∧ code e2422364691694 = 11218457713902 := by decide
theorem cert_e2422364691694 : check e2422364691694 [[],[]] .three = true := by decide
def e2422364691702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364691702 : Closed e2422364691702 ∧ code e2422364691702 = 11218457713910 := by decide
theorem cert_e2422364691702 : check e2422364691702 [[],[]] .three = true := by decide
def e2422364692086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364692086 : Closed e2422364692086 ∧ code e2422364692086 = 11218457714294 := by decide
theorem cert_e2422364692086 : check e2422364692086 [[],[]] .three = true := by decide
def e2422364692278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364692278 : Closed e2422364692278 ∧ code e2422364692278 = 11218457714486 := by decide
private def t_e2422364692278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem cert_e2422364692278 : ¬ IsSelfInterpreter e2422364692278 :=
  wSource (t := t_e2422364692278) (replay_sound (ps := []) (t := e2422364692278) (by decide)) (by decide)
def e2422364692282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364692282 : Closed e2422364692282 ∧ code e2422364692282 = 11218457714490 := by decide
private def t_e2422364692282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem cert_e2422364692282 : ¬ IsSelfInterpreter e2422364692282 :=
  wSource (t := t_e2422364692282) (replay_sound (ps := []) (t := e2422364692282) (by decide)) (by decide)
def e2422364712414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))))
theorem wire_e2422364712414 : Closed e2422364712414 ∧ code e2422364712414 = 11218457734622 := by decide
theorem cert_e2422364712414 : check e2422364712414 [[],[]] .smaller = true := by decide
def e2422364712430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))))
theorem wire_e2422364712430 : Closed e2422364712430 ∧ code e2422364712430 = 11218457734638 := by decide
theorem cert_e2422364712430 : check e2422364712430 [[],[]] .smaller = true := by decide
def e2422364712798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))))
theorem wire_e2422364712798 : Closed e2422364712798 ∧ code e2422364712798 = 11218457735006 := by decide
theorem cert_e2422364712798 : check e2422364712798 [[],[]] .smaller = true := by decide
def e2422364712826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))))
theorem wire_e2422364712826 : Closed e2422364712826 ∧ code e2422364712826 = 11218457735034 := by decide
theorem cert_e2422364712826 : check e2422364712826 [[],[]] .smaller = true := by decide
def e2422364712878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))))
theorem wire_e2422364712878 : Closed e2422364712878 ∧ code e2422364712878 = 11218457735086 := by decide
theorem cert_e2422364712878 : check e2422364712878 [[],[]] .smaller = true := by decide
def e2422364712890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))))
theorem wire_e2422364712890 : Closed e2422364712890 ∧ code e2422364712890 = 11218457735098 := by decide
theorem cert_e2422364712890 : check e2422364712890 [[],[]] .smaller = true := by decide
def e2422364713950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))))
theorem wire_e2422364713950 : Closed e2422364713950 ∧ code e2422364713950 = 11218457736158 := by decide
theorem cert_e2422364713950 : check e2422364713950 [[],[]] .smaller = true := by decide
def e2422364713966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))))
theorem wire_e2422364713966 : Closed e2422364713966 ∧ code e2422364713966 = 11218457736174 := by decide
theorem cert_e2422364713966 : check e2422364713966 [[],[]] .smaller = true := by decide
def e2422364716254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))))
theorem wire_e2422364716254 : Closed e2422364716254 ∧ code e2422364716254 = 11218457738462 := by decide
theorem cert_e2422364716254 : check e2422364716254 [[],[]] .smaller = true := by decide
def e2422364716282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))))
theorem wire_e2422364716282 : Closed e2422364716282 ∧ code e2422364716282 = 11218457738490 := by decide
theorem cert_e2422364716282 : check e2422364716282 [[],[]] .smaller = true := by decide
def e2422364716654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422364716654 : Closed e2422364716654 ∧ code e2422364716654 = 11218457738862 := by decide
theorem cert_e2422364716654 : check e2422364716654 [[],[]] .smaller = true := by decide
def e2422364716666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422364716666 : Closed e2422364716666 ∧ code e2422364716666 = 11218457738874 := by decide
theorem cert_e2422364716666 : check e2422364716666 [[],[]] .smaller = true := by decide
def e2422364745070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e2422364745070 : Closed e2422364745070 ∧ code e2422364745070 = 11218457767278 := by decide
theorem cert_e2422364745070 : check e2422364745070 [[],[]] .smaller = true := by decide
def e2422364745078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e2422364745078 : Closed e2422364745078 ∧ code e2422364745078 = 11218457767286 := by decide
theorem cert_e2422364745078 : check e2422364745078 [[],[]] .smaller = true := by decide
def e2422364745134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e2422364745134 : Closed e2422364745134 ∧ code e2422364745134 = 11218457767342 := by decide
theorem cert_e2422364745134 : check e2422364745134 [[],[]] .smaller = true := by decide
def e2422364745146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e2422364745146 : Closed e2422364745146 ∧ code e2422364745146 = 11218457767354 := by decide
theorem cert_e2422364745146 : check e2422364745146 [[],[]] .smaller = true := by decide
def e2422364745174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e2422364745174 : Closed e2422364745174 ∧ code e2422364745174 = 11218457767382 := by decide
theorem cert_e2422364745174 : check e2422364745174 [[],[]] .smaller = true := by decide
def e2422364745178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e2422364745178 : Closed e2422364745178 ∧ code e2422364745178 = 11218457767386 := by decide
theorem cert_e2422364745178 : check e2422364745178 [[],[]] .smaller = true := by decide
def e2422364745390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e2422364745390 : Closed e2422364745390 ∧ code e2422364745390 = 11218457767598 := by decide
theorem cert_e2422364745390 : check e2422364745390 [[],[]] .smaller = true := by decide
def e2422364745402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e2422364745402 : Closed e2422364745402 ∧ code e2422364745402 = 11218457767610 := by decide
theorem cert_e2422364745402 : check e2422364745402 [[],[]] .smaller = true := by decide
def e2422364745450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e2422364745450 : Closed e2422364745450 ∧ code e2422364745450 = 11218457767658 := by decide
theorem cert_e2422364745450 : check e2422364745450 [[],[]] .smaller = true := by decide
def e2422364745558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e2422364745558 : Closed e2422364745558 ∧ code e2422364745558 = 11218457767766 := by decide
theorem cert_e2422364745558 : check e2422364745558 [[],[]] .smaller = true := by decide
def e2422364745562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e2422364745562 : Closed e2422364745562 ∧ code e2422364745562 = 11218457767770 := by decide
theorem cert_e2422364745562 : check e2422364745562 [[],[]] .smaller = true := by decide
def e2422364745578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e2422364745578 : Closed e2422364745578 ∧ code e2422364745578 = 11218457767786 := by decide
theorem cert_e2422364745578 : check e2422364745578 [[],[]] .smaller = true := by decide
def e2422364746206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))))
theorem wire_e2422364746206 : Closed e2422364746206 ∧ code e2422364746206 = 11218457768414 := by decide
theorem cert_e2422364746206 : check e2422364746206 [[],[]] .smaller = true := by decide
def e2422364746230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))))
theorem wire_e2422364746230 : Closed e2422364746230 ∧ code e2422364746230 = 11218457768438 := by decide
theorem cert_e2422364746230 : check e2422364746230 [[],[]] .smaller = true := by decide
def e2422364746606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e2422364746606 : Closed e2422364746606 ∧ code e2422364746606 = 11218457768814 := by decide
theorem cert_e2422364746606 : check e2422364746606 [[],[]] .smaller = true := by decide
def e2422364746614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e2422364746614 : Closed e2422364746614 ∧ code e2422364746614 = 11218457768822 := by decide
theorem cert_e2422364746614 : check e2422364746614 [[],[]] .smaller = true := by decide
def e2422364746670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e2422364746670 : Closed e2422364746670 ∧ code e2422364746670 = 11218457768878 := by decide
theorem cert_e2422364746670 : check e2422364746670 [[],[]] .smaller = true := by decide
def e2422364746682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e2422364746682 : Closed e2422364746682 ∧ code e2422364746682 = 11218457768890 := by decide
theorem cert_e2422364746682 : check e2422364746682 [[],[]] .smaller = true := by decide
def e2422364746710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e2422364746710 : Closed e2422364746710 ∧ code e2422364746710 = 11218457768918 := by decide
theorem cert_e2422364746710 : check e2422364746710 [[],[]] .smaller = true := by decide
def e2422364746714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e2422364746714 : Closed e2422364746714 ∧ code e2422364746714 = 11218457768922 := by decide
theorem cert_e2422364746714 : check e2422364746714 [[],[]] .smaller = true := by decide
def e2422364746990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422364746990 : Closed e2422364746990 ∧ code e2422364746990 = 11218457769198 := by decide
theorem cert_e2422364746990 : check e2422364746990 [[],[]] .smaller = true := by decide
def e2422364746998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422364746998 : Closed e2422364746998 ∧ code e2422364746998 = 11218457769206 := by decide
theorem cert_e2422364746998 : check e2422364746998 [[],[]] .smaller = true := by decide
def e2422364747326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))))
theorem wire_e2422364747326 : Closed e2422364747326 ∧ code e2422364747326 = 11218457769534 := by decide
theorem cert_e2422364747326 : check e2422364747326 [[],[]] .smaller = true := by decide
def e2422364747374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422364747374 : Closed e2422364747374 ∧ code e2422364747374 = 11218457769582 := by decide
theorem cert_e2422364747374 : check e2422364747374 [[],[]] .smaller = true := by decide
def e2422364747386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422364747386 : Closed e2422364747386 ∧ code e2422364747386 = 11218457769594 := by decide
theorem cert_e2422364747386 : check e2422364747386 [[],[]] .smaller = true := by decide
def e2422364747574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364747574 : Closed e2422364747574 ∧ code e2422364747574 = 11218457769782 := by decide
theorem cert_e2422364747574 : check e2422364747574 [[],[]] .smaller = true := by decide
def e2422364747578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364747578 : Closed e2422364747578 ∧ code e2422364747578 = 11218457769786 := by decide
theorem cert_e2422364747578 : check e2422364747578 [[],[]] .smaller = true := by decide
def e2422364747662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))))
theorem wire_e2422364747662 : Closed e2422364747662 ∧ code e2422364747662 = 11218457769870 := by decide
theorem cert_e2422364747662 : check e2422364747662 [[],[]] .smaller = true := by decide
def e2422364747998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))))
theorem wire_e2422364747998 : Closed e2422364747998 ∧ code e2422364747998 = 11218457770206 := by decide
theorem cert_e2422364747998 : check e2422364747998 [[],[]] .smaller = true := by decide
def e2422364748026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))))
theorem wire_e2422364748026 : Closed e2422364748026 ∧ code e2422364748026 = 11218457770234 := by decide
theorem cert_e2422364748026 : check e2422364748026 [[],[]] .smaller = true := by decide
def e2422364748206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e2422364748206 : Closed e2422364748206 ∧ code e2422364748206 = 11218457770414 := by decide
theorem cert_e2422364748206 : check e2422364748206 [[],[]] .smaller = true := by decide
def e2422364748218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e2422364748218 : Closed e2422364748218 ∧ code e2422364748218 = 11218457770426 := by decide
theorem cert_e2422364748218 : check e2422364748218 [[],[]] .smaller = true := by decide
def e2422364748266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e2422364748266 : Closed e2422364748266 ∧ code e2422364748266 = 11218457770474 := by decide
theorem cert_e2422364748266 : check e2422364748266 [[],[]] .smaller = true := by decide
def e2422364748350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))))
theorem wire_e2422364748350 : Closed e2422364748350 ∧ code e2422364748350 = 11218457770558 := by decide
theorem cert_e2422364748350 : check e2422364748350 [[],[]] .smaller = true := by decide
def e2422364748398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422364748398 : Closed e2422364748398 ∧ code e2422364748398 = 11218457770606 := by decide
theorem cert_e2422364748398 : check e2422364748398 [[],[]] .smaller = true := by decide
def e2422364748410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422364748410 : Closed e2422364748410 ∧ code e2422364748410 = 11218457770618 := by decide
theorem cert_e2422364748410 : check e2422364748410 [[],[]] .smaller = true := by decide
def e2422364748698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364748698 : Closed e2422364748698 ∧ code e2422364748698 = 11218457770906 := by decide
theorem cert_e2422364748698 : check e2422364748698 [[],[]] .smaller = true := by decide
def e2422364748734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 4))))))))))
theorem wire_e2422364748734 : Closed e2422364748734 ∧ code e2422364748734 = 11218457770942 := by decide
theorem cert_e2422364748734 : check e2422364748734 [[],[]] .smaller = true := by decide
def e2422364748742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))))
theorem wire_e2422364748742 : Closed e2422364748742 ∧ code e2422364748742 = 11218457770950 := by decide
theorem cert_e2422364748742 : check e2422364748742 [[],[]] .smaller = true := by decide
def e2422364748782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 2))))))))))
theorem wire_e2422364748782 : Closed e2422364748782 ∧ code e2422364748782 = 11218457770990 := by decide
theorem cert_e2422364748782 : check e2422364748782 [[],[]] .smaller = true := by decide
def e2422364749014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e2422364749014 : Closed e2422364749014 ∧ code e2422364749014 = 11218457771222 := by decide
theorem cert_e2422364749014 : check e2422364749014 [[],[]] .smaller = true := by decide
def e2422364749018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e2422364749018 : Closed e2422364749018 ∧ code e2422364749018 = 11218457771226 := by decide
theorem cert_e2422364749018 : check e2422364749018 [[],[]] .smaller = true := by decide
def e2422364749034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e2422364749034 : Closed e2422364749034 ∧ code e2422364749034 = 11218457771242 := by decide
theorem cert_e2422364749034 : check e2422364749034 [[],[]] .smaller = true := by decide
def e2422364749110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422364749110 : Closed e2422364749110 ∧ code e2422364749110 = 11218457771318 := by decide
theorem cert_e2422364749110 : check e2422364749110 [[],[]] .smaller = true := by decide
def e2422364749114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422364749114 : Closed e2422364749114 ∧ code e2422364749114 = 11218457771322 := by decide
theorem cert_e2422364749114 : check e2422364749114 [[],[]] .smaller = true := by decide
def e2422364749210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422364749210 : Closed e2422364749210 ∧ code e2422364749210 = 11218457771418 := by decide
theorem cert_e2422364749210 : check e2422364749210 [[],[]] .smaller = true := by decide
def e2422364749246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 4))))))))))
theorem wire_e2422364749246 : Closed e2422364749246 ∧ code e2422364749246 = 11218457771454 := by decide
theorem cert_e2422364749246 : check e2422364749246 [[],[]] .smaller = true := by decide
def e2422364749278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))))))
theorem wire_e2422364749278 : Closed e2422364749278 ∧ code e2422364749278 = 11218457771486 := by decide
theorem cert_e2422364749278 : check e2422364749278 [[],[]] .smaller = true := by decide
def e2422364749294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 2))))))))))
theorem wire_e2422364749294 : Closed e2422364749294 ∧ code e2422364749294 = 11218457771502 := by decide
theorem cert_e2422364749294 : check e2422364749294 [[],[]] .smaller = true := by decide
def e2422364749302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 4)) (.var 1))))))))))
theorem wire_e2422364749302 : Closed e2422364749302 ∧ code e2422364749302 = 11218457771510 := by decide
theorem cert_e2422364749302 : check e2422364749302 [[],[]] .smaller = true := by decide
def e2422364749366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))))
theorem wire_e2422364749366 : Closed e2422364749366 ∧ code e2422364749366 = 11218457771574 := by decide
theorem cert_e2422364749366 : check e2422364749366 [[],[]] .smaller = true := by decide
def e2422364749370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))))
theorem wire_e2422364749370 : Closed e2422364749370 ∧ code e2422364749370 = 11218457771578 := by decide
theorem cert_e2422364749370 : check e2422364749370 [[],[]] .smaller = true := by decide
def e2422364749454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 2)))))))))))
theorem wire_e2422364749454 : Closed e2422364749454 ∧ code e2422364749454 = 11218457771662 := by decide
theorem cert_e2422364749454 : check e2422364749454 [[],[]] .smaller = true := by decide
def e2422364749510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 1)))))))))))
theorem wire_e2422364749510 : Closed e2422364749510 ∧ code e2422364749510 = 11218457771718 := by decide
theorem cert_e2422364749510 : check e2422364749510 [[],[]] .smaller = true := by decide
def e2422364749550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 2)) (.var 2))))))))))
theorem wire_e2422364749550 : Closed e2422364749550 ∧ code e2422364749550 = 11218457771758 := by decide
theorem cert_e2422364749550 : check e2422364749550 [[],[]] .smaller = true := by decide
def e2422364749678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 2))))))))))
theorem wire_e2422364749678 : Closed e2422364749678 ∧ code e2422364749678 = 11218457771886 := by decide
theorem cert_e2422364749678 : check e2422364749678 [[],[]] .smaller = true := by decide
def e2422364749686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 2)) (.var 1))))))))))
theorem wire_e2422364749686 : Closed e2422364749686 ∧ code e2422364749686 = 11218457771894 := by decide
theorem cert_e2422364749686 : check e2422364749686 [[],[]] .smaller = true := by decide
def e2422364750814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))))
theorem wire_e2422364750814 : Closed e2422364750814 ∧ code e2422364750814 = 11218457773022 := by decide
theorem cert_e2422364750814 : check e2422364750814 [[],[]] .smaller = true := by decide
def e2422364750830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))))
theorem wire_e2422364750830 : Closed e2422364750830 ∧ code e2422364750830 = 11218457773038 := by decide
theorem cert_e2422364750830 : check e2422364750830 [[],[]] .smaller = true := by decide
def e2422364752750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e2422364752750 : Closed e2422364752750 ∧ code e2422364752750 = 11218457774958 := by decide
theorem cert_e2422364752750 : check e2422364752750 [[],[]] .smaller = true := by decide
def e2422364752758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e2422364752758 : Closed e2422364752758 ∧ code e2422364752758 = 11218457774966 := by decide
theorem cert_e2422364752758 : check e2422364752758 [[],[]] .smaller = true := by decide
def e2422364752814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e2422364752814 : Closed e2422364752814 ∧ code e2422364752814 = 11218457775022 := by decide
theorem cert_e2422364752814 : check e2422364752814 [[],[]] .smaller = true := by decide
def e2422364752826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e2422364752826 : Closed e2422364752826 ∧ code e2422364752826 = 11218457775034 := by decide
theorem cert_e2422364752826 : check e2422364752826 [[],[]] .smaller = true := by decide
def e2422364752854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e2422364752854 : Closed e2422364752854 ∧ code e2422364752854 = 11218457775062 := by decide
theorem cert_e2422364752854 : check e2422364752854 [[],[]] .smaller = true := by decide
def e2422364752858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e2422364752858 : Closed e2422364752858 ∧ code e2422364752858 = 11218457775066 := by decide
theorem cert_e2422364752858 : check e2422364752858 [[],[]] .smaller = true := by decide
def e2422364753134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422364753134 : Closed e2422364753134 ∧ code e2422364753134 = 11218457775342 := by decide
theorem cert_e2422364753134 : check e2422364753134 [[],[]] .smaller = true := by decide
def e2422364753142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422364753142 : Closed e2422364753142 ∧ code e2422364753142 = 11218457775350 := by decide
theorem cert_e2422364753142 : check e2422364753142 [[],[]] .smaller = true := by decide
def e2422364753470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 4))))))))))))
theorem wire_e2422364753470 : Closed e2422364753470 ∧ code e2422364753470 = 11218457775678 := by decide
theorem cert_e2422364753470 : check e2422364753470 [[],[]] .smaller = true := by decide
def e2422364753518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422364753518 : Closed e2422364753518 ∧ code e2422364753518 = 11218457775726 := by decide
theorem cert_e2422364753518 : check e2422364753518 [[],[]] .smaller = true := by decide
def e2422364753530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422364753530 : Closed e2422364753530 ∧ code e2422364753530 = 11218457775738 := by decide
theorem cert_e2422364753530 : check e2422364753530 [[],[]] .smaller = true := by decide
def e2422364753718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422364753718 : Closed e2422364753718 ∧ code e2422364753718 = 11218457775926 := by decide
theorem cert_e2422364753718 : check e2422364753718 [[],[]] .smaller = true := by decide
def e2422364753722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422364753722 : Closed e2422364753722 ∧ code e2422364753722 = 11218457775930 := by decide
theorem cert_e2422364753722 : check e2422364753722 [[],[]] .smaller = true := by decide
def e2422364753806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 2))))))))))))
theorem wire_e2422364753806 : Closed e2422364753806 ∧ code e2422364753806 = 11218457776014 := by decide
theorem cert_e2422364753806 : check e2422364753806 [[],[]] .smaller = true := by decide
def e2422364758494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))))
theorem wire_e2422364758494 : Closed e2422364758494 ∧ code e2422364758494 = 11218457780702 := by decide
theorem cert_e2422364758494 : check e2422364758494 [[],[]] .smaller = true := by decide
def e2422364758518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))))
theorem wire_e2422364758518 : Closed e2422364758518 ∧ code e2422364758518 = 11218457780726 := by decide
theorem cert_e2422364758518 : check e2422364758518 [[],[]] .smaller = true := by decide
def e2422364759470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e2422364759470 : Closed e2422364759470 ∧ code e2422364759470 = 11218457781678 := by decide
theorem cert_e2422364759470 : check e2422364759470 [[],[]] .smaller = true := by decide
def e2422364759482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e2422364759482 : Closed e2422364759482 ∧ code e2422364759482 = 11218457781690 := by decide
theorem cert_e2422364759482 : check e2422364759482 [[],[]] .smaller = true := by decide
def e2422364759530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e2422364759530 : Closed e2422364759530 ∧ code e2422364759530 = 11218457781738 := by decide
theorem cert_e2422364759530 : check e2422364759530 [[],[]] .smaller = true := by decide
def e2422364759614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 4))))))))))))
theorem wire_e2422364759614 : Closed e2422364759614 ∧ code e2422364759614 = 11218457781822 := by decide
theorem cert_e2422364759614 : check e2422364759614 [[],[]] .smaller = true := by decide
def e2422364759662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422364759662 : Closed e2422364759662 ∧ code e2422364759662 = 11218457781870 := by decide
theorem cert_e2422364759662 : check e2422364759662 [[],[]] .smaller = true := by decide
def e2422364759674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422364759674 : Closed e2422364759674 ∧ code e2422364759674 = 11218457781882 := by decide
theorem cert_e2422364759674 : check e2422364759674 [[],[]] .smaller = true := by decide
def e2422364759962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422364759962 : Closed e2422364759962 ∧ code e2422364759962 = 11218457782170 := by decide
theorem cert_e2422364759962 : check e2422364759962 [[],[]] .smaller = true := by decide
def e2422364759998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 4)))))))))))
theorem wire_e2422364759998 : Closed e2422364759998 ∧ code e2422364759998 = 11218457782206 := by decide
theorem cert_e2422364759998 : check e2422364759998 [[],[]] .smaller = true := by decide
def e2422364760006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 1))))))))))))
theorem wire_e2422364760006 : Closed e2422364760006 ∧ code e2422364760006 = 11218457782214 := by decide
theorem cert_e2422364760006 : check e2422364760006 [[],[]] .smaller = true := by decide
def e2422364760046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 2)))))))))))
theorem wire_e2422364760046 : Closed e2422364760046 ∧ code e2422364760046 = 11218457782254 := by decide
theorem cert_e2422364760046 : check e2422364760046 [[],[]] .smaller = true := by decide
def e2422364762350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422364762350 : Closed e2422364762350 ∧ code e2422364762350 = 11218457784558 := by decide
theorem cert_e2422364762350 : check e2422364762350 [[],[]] .smaller = true := by decide
def e2422364762358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422364762358 : Closed e2422364762358 ∧ code e2422364762358 = 11218457784566 := by decide
theorem cert_e2422364762358 : check e2422364762358 [[],[]] .smaller = true := by decide
def e2422364762838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e2422364762838 : Closed e2422364762838 ∧ code e2422364762838 = 11218457785046 := by decide
theorem cert_e2422364762838 : check e2422364762838 [[],[]] .smaller = true := by decide
def e2422364762842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e2422364762842 : Closed e2422364762842 ∧ code e2422364762842 = 11218457785050 := by decide
theorem cert_e2422364762842 : check e2422364762842 [[],[]] .smaller = true := by decide
def e2422364762858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e2422364762858 : Closed e2422364762858 ∧ code e2422364762858 = 11218457785066 := by decide
theorem cert_e2422364762858 : check e2422364762858 [[],[]] .smaller = true := by decide
def e2422364762934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422364762934 : Closed e2422364762934 ∧ code e2422364762934 = 11218457785142 := by decide
theorem cert_e2422364762934 : check e2422364762934 [[],[]] .smaller = true := by decide
def e2422364762938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422364762938 : Closed e2422364762938 ∧ code e2422364762938 = 11218457785146 := by decide
theorem cert_e2422364762938 : check e2422364762938 [[],[]] .smaller = true := by decide
def e2422364763034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422364763034 : Closed e2422364763034 ∧ code e2422364763034 = 11218457785242 := by decide
theorem cert_e2422364763034 : check e2422364763034 [[],[]] .smaller = true := by decide
def e2422364763070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 4)))))))))))
theorem wire_e2422364763070 : Closed e2422364763070 ∧ code e2422364763070 = 11218457785278 := by decide
theorem cert_e2422364763070 : check e2422364763070 [[],[]] .smaller = true := by decide
def e2422364763102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 2) (.var 3)))))))))))
theorem wire_e2422364763102 : Closed e2422364763102 ∧ code e2422364763102 = 11218457785310 := by decide
theorem cert_e2422364763102 : check e2422364763102 [[],[]] .smaller = true := by decide
def e2422364763118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 3) (.var 2)))))))))))
theorem wire_e2422364763118 : Closed e2422364763118 ∧ code e2422364763118 = 11218457785326 := by decide
theorem cert_e2422364763118 : check e2422364763118 [[],[]] .smaller = true := by decide
def e2422364763126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 4) (.var 1)))))))))))
theorem wire_e2422364763126 : Closed e2422364763126 ∧ code e2422364763126 = 11218457785334 := by decide
theorem cert_e2422364763126 : check e2422364763126 [[],[]] .smaller = true := by decide
def e2422364764558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))))))
theorem wire_e2422364764558 : Closed e2422364764558 ∧ code e2422364764558 = 11218457786766 := by decide
theorem cert_e2422364764558 : check e2422364764558 [[],[]] .smaller = true := by decide
def e2422364764614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))))))
theorem wire_e2422364764614 : Closed e2422364764614 ∧ code e2422364764614 = 11218457786822 := by decide
theorem cert_e2422364764614 : check e2422364764614 [[],[]] .smaller = true := by decide
def e2422364764654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 2) (.var 2)))))))))))
theorem wire_e2422364764654 : Closed e2422364764654 ∧ code e2422364764654 = 11218457786862 := by decide
theorem cert_e2422364764654 : check e2422364764654 [[],[]] .smaller = true := by decide
def e2422364765422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422364765422 : Closed e2422364765422 ∧ code e2422364765422 = 11218457787630 := by decide
theorem cert_e2422364765422 : check e2422364765422 [[],[]] .smaller = true := by decide
def e2422364765430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422364765430 : Closed e2422364765430 ∧ code e2422364765430 = 11218457787638 := by decide
theorem cert_e2422364765430 : check e2422364765430 [[],[]] .smaller = true := by decide
def e2422364845294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422364845294 : Closed e2422364845294 ∧ code e2422364845294 = 11218457867502 := by decide
theorem cert_e2422364845294 : check e2422364845294 [[],[]] .smaller = true := by decide
def e2422364845302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422364845302 : Closed e2422364845302 ∧ code e2422364845302 = 11218457867510 := by decide
theorem cert_e2422364845302 : check e2422364845302 [[],[]] .smaller = true := by decide
def e2422364877166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2)))))))))
theorem wire_e2422364877166 : Closed e2422364877166 ∧ code e2422364877166 = 11218457899374 := by decide
theorem cert_e2422364877166 : check e2422364877166 [[],[]] .smaller = true := by decide
def e2422364877174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1)))))))))
theorem wire_e2422364877174 : Closed e2422364877174 ∧ code e2422364877174 = 11218457899382 := by decide
theorem cert_e2422364877174 : check e2422364877174 [[],[]] .smaller = true := by decide
def e2422364878270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4)))))))))
theorem wire_e2422364878270 : Closed e2422364878270 ∧ code e2422364878270 = 11218457900478 := by decide
theorem cert_e2422364878270 : check e2422364878270 [[],[]] .three = true := by decide
def e2422364878302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3)))))))))
theorem wire_e2422364878302 : Closed e2422364878302 ∧ code e2422364878302 = 11218457900510 := by decide
theorem cert_e2422364878302 : check e2422364878302 [[],[]] .smaller = true := by decide
def e2422364878318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2)))))))))
theorem wire_e2422364878318 : Closed e2422364878318 ∧ code e2422364878318 = 11218457900526 := by decide
theorem cert_e2422364878318 : check e2422364878318 [[],[]] .smaller = true := by decide
def e2422364878326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1)))))))))
theorem wire_e2422364878326 : Closed e2422364878326 ∧ code e2422364878326 = 11218457900534 := by decide
theorem cert_e2422364878326 : check e2422364878326 [[],[]] .three = true := by decide
def e2422364878382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422364878382 : Closed e2422364878382 ∧ code e2422364878382 = 11218457900590 := by decide
theorem cert_e2422364878382 : check e2422364878382 [[],[]] .smaller = true := by decide
def e2422364878526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4)))))))))
theorem wire_e2422364878526 : Closed e2422364878526 ∧ code e2422364878526 = 11218457900734 := by decide
theorem cert_e2422364878526 : check e2422364878526 [[],[]] .three = true := by decide
def e2422364878558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3)))))))))
theorem wire_e2422364878558 : Closed e2422364878558 ∧ code e2422364878558 = 11218457900766 := by decide
theorem cert_e2422364878558 : check e2422364878558 [[],[]] .smaller = true := by decide
def e2422364878562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422364878562 : Closed e2422364878562 ∧ code e2422364878562 = 11218457900770 := by decide
theorem cert_e2422364878562 : check e2422364878562 [[],[]] .smaller = true := by decide
def e2422364878574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2)))))))))
theorem wire_e2422364878574 : Closed e2422364878574 ∧ code e2422364878574 = 11218457900782 := by decide
theorem cert_e2422364878574 : check e2422364878574 [[],[]] .smaller = true := by decide
def e2422364878582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1)))))))))
theorem wire_e2422364878582 : Closed e2422364878582 ∧ code e2422364878582 = 11218457900790 := by decide
theorem cert_e2422364878582 : check e2422364878582 [[],[]] .smaller = true := by decide
def e2422364878586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0)))))))))
theorem wire_e2422364878586 : Closed e2422364878586 ∧ code e2422364878586 = 11218457900794 := by decide
theorem cert_e2422364878586 : check e2422364878586 [[],[]] .three = true := by decide
def e2422364878614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1)))))))))
theorem wire_e2422364878614 : Closed e2422364878614 ∧ code e2422364878614 = 11218457900822 := by decide
theorem cert_e2422364878614 : check e2422364878614 [[],[]] .smaller = true := by decide
def e2422364878686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3)))))))))
theorem wire_e2422364878686 : Closed e2422364878686 ∧ code e2422364878686 = 11218457900894 := by decide
theorem cert_e2422364878686 : check e2422364878686 [[],[]] .smaller = true := by decide
def e2422364878690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0))))))))))
theorem wire_e2422364878690 : Closed e2422364878690 ∧ code e2422364878690 = 11218457900898 := by decide
theorem cert_e2422364878690 : check e2422364878690 [[],[]] .smaller = true := by decide
def e2422364878702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2)))))))))
theorem wire_e2422364878702 : Closed e2422364878702 ∧ code e2422364878702 = 11218457900910 := by decide
theorem cert_e2422364878702 : check e2422364878702 [[],[]] .smaller = true := by decide
def e2422364878710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1)))))))))
theorem wire_e2422364878710 : Closed e2422364878710 ∧ code e2422364878710 = 11218457900918 := by decide
theorem cert_e2422364878710 : check e2422364878710 [[],[]] .smaller = true := by decide
def e2422364878714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0)))))))))
theorem wire_e2422364878714 : Closed e2422364878714 ∧ code e2422364878714 = 11218457900922 := by decide
theorem cert_e2422364878714 : check e2422364878714 [[],[]] .smaller = true := by decide
def e2422364878766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2)))))))))
theorem wire_e2422364878766 : Closed e2422364878766 ∧ code e2422364878766 = 11218457900974 := by decide
theorem cert_e2422364878766 : check e2422364878766 [[],[]] .smaller = true := by decide
def e2422364878774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1)))))))))
theorem wire_e2422364878774 : Closed e2422364878774 ∧ code e2422364878774 = 11218457900982 := by decide
theorem cert_e2422364878774 : check e2422364878774 [[],[]] .smaller = true := by decide
def e2422364878778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0)))))))))
theorem wire_e2422364878778 : Closed e2422364878778 ∧ code e2422364878778 = 11218457900986 := by decide
theorem cert_e2422364878778 : check e2422364878778 [[],[]] .smaller = true := by decide
def e2422364878806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1)))))))))
theorem wire_e2422364878806 : Closed e2422364878806 ∧ code e2422364878806 = 11218457901014 := by decide
theorem cert_e2422364878806 : check e2422364878806 [[],[]] .three = true := by decide
def e2422364878810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0)))))))))
theorem wire_e2422364878810 : Closed e2422364878810 ∧ code e2422364878810 = 11218457901018 := by decide
theorem cert_e2422364878810 : check e2422364878810 [[],[]] .three = true := by decide
def e2422364879022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)))))))))
theorem wire_e2422364879022 : Closed e2422364879022 ∧ code e2422364879022 = 11218457901230 := by decide
theorem cert_e2422364879022 : check e2422364879022 [[],[]] .smaller = true := by decide
def e2422364879034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)))))))))
theorem wire_e2422364879034 : Closed e2422364879034 ∧ code e2422364879034 = 11218457901242 := by decide
theorem cert_e2422364879034 : check e2422364879034 [[],[]] .smaller = true := by decide
def e2422364879406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)))))))))
theorem wire_e2422364879406 : Closed e2422364879406 ∧ code e2422364879406 = 11218457901614 := by decide
theorem cert_e2422364879406 : check e2422364879406 [[],[]] .smaller = true := by decide
def e2422364879550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4)))))))))
theorem wire_e2422364879550 : Closed e2422364879550 ∧ code e2422364879550 = 11218457901758 := by decide
theorem cert_e2422364879550 : check e2422364879550 [[],[]] .three = true := by decide
def e2422364879582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e2422364879582 : Closed e2422364879582 ∧ code e2422364879582 = 11218457901790 := by decide
theorem cert_e2422364879582 : check e2422364879582 [[],[]] .smaller = true := by decide
def e2422364879586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0))))))))))
theorem wire_e2422364879586 : Closed e2422364879586 ∧ code e2422364879586 = 11218457901794 := by decide
theorem cert_e2422364879586 : check e2422364879586 [[],[]] .smaller = true := by decide
def e2422364879598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2)))))))))
theorem wire_e2422364879598 : Closed e2422364879598 ∧ code e2422364879598 = 11218457901806 := by decide
theorem cert_e2422364879598 : check e2422364879598 [[],[]] .smaller = true := by decide
def e2422364879606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e2422364879606 : Closed e2422364879606 ∧ code e2422364879606 = 11218457901814 := by decide
theorem cert_e2422364879606 : check e2422364879606 [[],[]] .smaller = true := by decide
def e2422364879610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0)))))))))
theorem wire_e2422364879610 : Closed e2422364879610 ∧ code e2422364879610 = 11218457901818 := by decide
theorem cert_e2422364879610 : check e2422364879610 [[],[]] .three = true := by decide
def e2422364879710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e2422364879710 : Closed e2422364879710 ∧ code e2422364879710 = 11218457901918 := by decide
theorem cert_e2422364879710 : check e2422364879710 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422364692278
#print axioms Blc.Floor43.cert_e2422364692282
