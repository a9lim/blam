import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392568422878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2392568422878 : Closed e2392568422878 ∧ code e2392568422878 = 11188661445086 := by decide
theorem cert_e2392568422878 : check e2392568422878 [[],[.left]] .chain = true := by decide
def e2392568422902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2392568422902 : Closed e2392568422902 ∧ code e2392568422902 = 11188661445110 := by decide
theorem cert_e2392568422902 : check e2392568422902 [[],[.left]] .chain = true := by decide
def e2392568423854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2392568423854 : Closed e2392568423854 ∧ code e2392568423854 = 11188661446062 := by decide
theorem cert_e2392568423854 : check e2392568423854 [[],[.left]] .chain = true := by decide
def e2392568423866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2392568423866 : Closed e2392568423866 ∧ code e2392568423866 = 11188661446074 := by decide
theorem cert_e2392568423866 : check e2392568423866 [[],[.left]] .chain = true := by decide
def e2392568423914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2392568423914 : Closed e2392568423914 ∧ code e2392568423914 = 11188661446122 := by decide
theorem cert_e2392568423914 : check e2392568423914 [[],[.left]] .chain = true := by decide
def e2392568424046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392568424046 : Closed e2392568424046 ∧ code e2392568424046 = 11188661446254 := by decide
theorem cert_e2392568424046 : check e2392568424046 [[],[.left]] .chain = true := by decide
def e2392568424058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392568424058 : Closed e2392568424058 ∧ code e2392568424058 = 11188661446266 := by decide
theorem cert_e2392568424058 : check e2392568424058 [[],[.left]] .chain = true := by decide
def e2392568424346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392568424346 : Closed e2392568424346 ∧ code e2392568424346 = 11188661446554 := by decide
theorem cert_e2392568424346 : check e2392568424346 [[],[.left]] .chain = true := by decide
def e2392568426734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2392568426734 : Closed e2392568426734 ∧ code e2392568426734 = 11188661448942 := by decide
theorem cert_e2392568426734 : check e2392568426734 [[],[.left]] .chain = true := by decide
def e2392568426742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2392568426742 : Closed e2392568426742 ∧ code e2392568426742 = 11188661448950 := by decide
theorem cert_e2392568426742 : check e2392568426742 [[],[.left]] .chain = true := by decide
def e2392568427222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2392568427222 : Closed e2392568427222 ∧ code e2392568427222 = 11188661449430 := by decide
theorem cert_e2392568427222 : check e2392568427222 [[],[.left]] .chain = true := by decide
def e2392568427226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2392568427226 : Closed e2392568427226 ∧ code e2392568427226 = 11188661449434 := by decide
theorem cert_e2392568427226 : check e2392568427226 [[],[.left]] .chain = true := by decide
def e2392568427242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2392568427242 : Closed e2392568427242 ∧ code e2392568427242 = 11188661449450 := by decide
theorem cert_e2392568427242 : check e2392568427242 [[],[.left]] .chain = true := by decide
def e2392568427318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392568427318 : Closed e2392568427318 ∧ code e2392568427318 = 11188661449526 := by decide
theorem cert_e2392568427318 : check e2392568427318 [[],[.left]] .chain = true := by decide
def e2392568427322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392568427322 : Closed e2392568427322 ∧ code e2392568427322 = 11188661449530 := by decide
theorem cert_e2392568427322 : check e2392568427322 [[],[.left]] .chain = true := by decide
def e2392568427418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392568427418 : Closed e2392568427418 ∧ code e2392568427418 = 11188661449626 := by decide
theorem cert_e2392568427418 : check e2392568427418 [[],[.left]] .chain = true := by decide
def e2392568564590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392568564590 : Closed e2392568564590 ∧ code e2392568564590 = 11188661586798 := by decide
theorem cert_e2392568564590 : check e2392568564590 [[],[.left]] .chain = true := by decide
def e2392568564598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392568564598 : Closed e2392568564598 ∧ code e2392568564598 = 11188661586806 := by decide
theorem cert_e2392568564598 : check e2392568564598 [[],[.left]] .chain = true := by decide
def e2392568564654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392568564654 : Closed e2392568564654 ∧ code e2392568564654 = 11188661586862 := by decide
theorem cert_e2392568564654 : check e2392568564654 [[],[.left]] .chain = true := by decide
def e2392568564666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392568564666 : Closed e2392568564666 ∧ code e2392568564666 = 11188661586874 := by decide
theorem cert_e2392568564666 : check e2392568564666 [[],[.left]] .chain = true := by decide
def e2392568564694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392568564694 : Closed e2392568564694 ∧ code e2392568564694 = 11188661586902 := by decide
theorem cert_e2392568564694 : check e2392568564694 [[],[.left]] .chain = true := by decide
def e2392568564698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392568564698 : Closed e2392568564698 ∧ code e2392568564698 = 11188661586906 := by decide
theorem cert_e2392568564698 : check e2392568564698 [[],[.left]] .chain = true := by decide
def e2392568564974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392568564974 : Closed e2392568564974 ∧ code e2392568564974 = 11188661587182 := by decide
theorem cert_e2392568564974 : check e2392568564974 [[],[.left]] .chain = true := by decide
def e2392568564982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392568564982 : Closed e2392568564982 ∧ code e2392568564982 = 11188661587190 := by decide
theorem cert_e2392568564982 : check e2392568564982 [[],[.left]] .chain = true := by decide
def e2392568565358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392568565358 : Closed e2392568565358 ∧ code e2392568565358 = 11188661587566 := by decide
theorem cert_e2392568565358 : check e2392568565358 [[],[.left]] .chain = true := by decide
def e2392568565370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392568565370 : Closed e2392568565370 ∧ code e2392568565370 = 11188661587578 := by decide
theorem cert_e2392568565370 : check e2392568565370 [[],[.left]] .chain = true := by decide
def e2392568565558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392568565558 : Closed e2392568565558 ∧ code e2392568565558 = 11188661587766 := by decide
theorem cert_e2392568565558 : check e2392568565558 [[],[.left]] .chain = true := by decide
def e2392568565562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392568565562 : Closed e2392568565562 ∧ code e2392568565562 = 11188661587770 := by decide
theorem cert_e2392568565562 : check e2392568565562 [[],[.left]] .chain = true := by decide
def e2392568895198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2392568895198 : Closed e2392568895198 ∧ code e2392568895198 = 11188661917406 := by decide
theorem cert_e2392568895198 : check e2392568895198 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2392568895222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2392568895222 : Closed e2392568895222 ∧ code e2392568895222 = 11188661917430 := by decide
theorem cert_e2392568895222 : check e2392568895222 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2392568895326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2392568895326 : Closed e2392568895326 ∧ code e2392568895326 = 11188661917534 := by decide
theorem cert_e2392568895326 : check e2392568895326 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[],[.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2392568895354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2392568895354 : Closed e2392568895354 ∧ code e2392568895354 = 11188661917562 := by decide
private def t_e2392568895354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem cert_e2392568895354 : ¬ IsSelfInterpreter e2392568895354 :=
  wSource (t := t_e2392568895354) (replay_sound (ps := []) (t := e2392568895354) (by decide)) (by decide)
def e2392568895446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2392568895446 : Closed e2392568895446 ∧ code e2392568895446 = 11188661917654 := by decide
theorem cert_e2392568895446 : check e2392568895446 [[],[.left],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e2392568895450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2392568895450 : Closed e2392568895450 ∧ code e2392568895450 = 11188661917658 := by decide
private def t_e2392568895450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem cert_e2392568895450 : ¬ IsSelfInterpreter e2392568895450 :=
  wSource (t := t_e2392568895450) (replay_sound (ps := []) (t := e2392568895450) (by decide)) (by decide)
def e2392568895966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2392568895966 : Closed e2392568895966 ∧ code e2392568895966 = 11188661918174 := by decide
theorem cert_e2392568895966 : check e2392568895966 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e2392568895990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2392568895990 : Closed e2392568895990 ∧ code e2392568895990 = 11188661918198 := by decide
theorem cert_e2392568895990 : check e2392568895990 [[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left],[.left],[],[],[.under]] .identityHead = true := by decide
def e2392568896734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392568896734 : Closed e2392568896734 ∧ code e2392568896734 = 11188661918942 := by decide
theorem cert_e2392568896734 : check e2392568896734 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2392568896762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392568896762 : Closed e2392568896762 ∧ code e2392568896762 = 11188661918970 := by decide
theorem cert_e2392568896762 : check e2392568896762 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2392568897334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392568897334 : Closed e2392568897334 ∧ code e2392568897334 = 11188661919542 := by decide
theorem cert_e2392568897334 : check e2392568897334 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2392568897338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392568897338 : Closed e2392568897338 ∧ code e2392568897338 = 11188661919546 := by decide
theorem cert_e2392568897338 : check e2392568897338 [[],[.left],[],[],[.under],[.under,.under]] .three = true := by decide
def e2392568912110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2392568912110 : Closed e2392568912110 ∧ code e2392568912110 = 11188661934318 := by decide
theorem cert_e2392568912110 : check e2392568912110 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2392568912118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2392568912118 : Closed e2392568912118 ∧ code e2392568912118 = 11188661934326 := by decide
theorem cert_e2392568912118 : check e2392568912118 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left]] .smaller = true := by decide
def e2392568912670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2392568912670 : Closed e2392568912670 ∧ code e2392568912670 = 11188661934878 := by decide
theorem cert_e2392568912670 : check e2392568912670 [[],[.left],[],[],[.under],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2392568912782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2392568912782 : Closed e2392568912782 ∧ code e2392568912782 = 11188661934990 := by decide
private def t_e2392568912782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem cert_e2392568912782 : ¬ IsSelfInterpreter e2392568912782 :=
  wSource (t := t_e2392568912782) (replay_sound (ps := []) (t := e2392568912782) (by decide)) (by decide)
def e2392568913006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2392568913006 : Closed e2392568913006 ∧ code e2392568913006 = 11188661935214 := by decide
theorem cert_e2392568913006 : check e2392568913006 [[],[.left],[],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e2392568913018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2392568913018 : Closed e2392568913018 ∧ code e2392568913018 = 11188661935226 := by decide
theorem cert_e2392568913018 : check e2392568913018 [[],[.left],[],[],[.under],[.under,.left],[.under]] .smaller = true := by decide
def e2392568913182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2392568913182 : Closed e2392568913182 ∧ code e2392568913182 = 11188661935390 := by decide
theorem cert_e2392568913182 : check e2392568913182 [[],[.left],[],[],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392568913350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2392568913350 : Closed e2392568913350 ∧ code e2392568913350 = 11188661935558 := by decide
theorem cert_e2392568913350 : check e2392568913350 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under,.under]] .three = true := by decide
def e2392568913462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2392568913462 : Closed e2392568913462 ∧ code e2392568913462 = 11188661935670 := by decide
theorem cert_e2392568913462 : check e2392568913462 [[],[.left],[],[],[.under],[.under,.left],[.under],[.under]] .chain = true := by decide
def e2392568913466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2392568913466 : Closed e2392568913466 ∧ code e2392568913466 = 11188661935674 := by decide
theorem cert_e2392568913466 : check e2392568913466 [[],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e2392568913550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2392568913550 : Closed e2392568913550 ∧ code e2392568913550 = 11188661935758 := by decide
private def t_e2392568913550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem cert_e2392568913550 : ¬ IsSelfInterpreter e2392568913550 :=
  wSource (t := t_e2392568913550) (replay_sound (ps := []) (t := e2392568913550) (by decide)) (by decide)
def e2392568913606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2392568913606 : Closed e2392568913606 ∧ code e2392568913606 = 11188661935814 := by decide
theorem cert_e2392568913606 : check e2392568913606 [[],[.left],[],[],[.under],[.under,.left]] .chain = true := by decide
def e2392568915742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2392568915742 : Closed e2392568915742 ∧ code e2392568915742 = 11188661937950 := by decide
theorem cert_e2392568915742 : check e2392568915742 [[],[.left],[],[],[.under],[.under],[.under,.left],[.under]] .smaller = true := by decide
def e2392568915854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2392568915854 : Closed e2392568915854 ∧ code e2392568915854 = 11188661938062 := by decide
theorem cert_e2392568915854 : check e2392568915854 [[],[.left],[],[],[.under],[.under],[.under,.left]] .chain = true := by decide
def e2392568918814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2392568918814 : Closed e2392568918814 ∧ code e2392568918814 = 11188661941022 := by decide
theorem cert_e2392568918814 : check e2392568918814 [[],[.left],[],[],[.under],[.under],[.under]] .sourceHead = true := by decide
def e2392568918982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2392568918982 : Closed e2392568918982 ∧ code e2392568918982 = 11188661941190 := by decide
theorem cert_e2392568918982 : check e2392568918982 [[],[.left],[],[],[.under],[.under],[.under],[.under,.under]] .three = true := by decide
def e2392568920462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2392568920462 : Closed e2392568920462 ∧ code e2392568920462 = 11188661942670 := by decide
theorem cert_e2392568920462 : check e2392568920462 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2392568920518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2392568920518 : Closed e2392568920518 ∧ code e2392568920518 = 11188661942726 := by decide
theorem cert_e2392568920518 : check e2392568920518 [[],[.left],[],[],[.under],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2392576765370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e2392576765370 : Closed e2392576765370 ∧ code e2392576765370 = 11188669787578 := by decide
def e2392576765402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e2392576765402 : Closed e2392576765402 ∧ code e2392576765402 = 11188669787610 := by decide
def e2392576765626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e2392576765626 : Closed e2392576765626 ∧ code e2392576765626 = 11188669787834 := by decide
def e2392576765674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e2392576765674 : Closed e2392576765674 ∧ code e2392576765674 = 11188669787882 := by decide
private def t_e2392576765674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem cert_e2392576765674 : ¬ IsSelfInterpreter e2392576765674 :=
  wSource (t := t_e2392576765674) (replay_sound (ps := []) (t := e2392576765674) (by decide)) (by decide)
def e2392576765786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e2392576765786 : Closed e2392576765786 ∧ code e2392576765786 = 11188669787994 := by decide
def e2392576765802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e2392576765802 : Closed e2392576765802 ∧ code e2392576765802 = 11188669788010 := by decide
private def t_e2392576765802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem cert_e2392576765802 : ¬ IsSelfInterpreter e2392576765802 :=
  wSource (t := t_e2392576765802) (replay_sound (ps := []) (t := e2392576765802) (by decide)) (by decide)
def e2392576766906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e2392576766906 : Closed e2392576766906 ∧ code e2392576766906 = 11188669789114 := by decide
def e2392576766938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e2392576766938 : Closed e2392576766938 ∧ code e2392576766938 = 11188669789146 := by decide
def e2392576768442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e2392576768442 : Closed e2392576768442 ∧ code e2392576768442 = 11188669790650 := by decide
def e2392576768490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e2392576768490 : Closed e2392576768490 ∧ code e2392576768490 = 11188669790698 := by decide
def e2392576769242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e2392576769242 : Closed e2392576769242 ∧ code e2392576769242 = 11188669791450 := by decide
def e2392576769258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e2392576769258 : Closed e2392576769258 ∧ code e2392576769258 = 11188669791466 := by decide
def e2392577018734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392577018734 : Closed e2392577018734 ∧ code e2392577018734 = 11188670040942 := by decide
private def t_e2392577018734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem cert_e2392577018734 : ¬ IsSelfInterpreter e2392577018734 :=
  wSource (t := t_e2392577018734) (replay_sound (ps := []) (t := e2392577018734) (by decide)) (by decide)
def e2392577018742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392577018742 : Closed e2392577018742 ∧ code e2392577018742 = 11188670040950 := by decide
private def t_e2392577018742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem cert_e2392577018742 : ¬ IsSelfInterpreter e2392577018742 :=
  wSource (t := t_e2392577018742) (replay_sound (ps := []) (t := e2392577018742) (by decide)) (by decide)
def e2392577018798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392577018798 : Closed e2392577018798 ∧ code e2392577018798 = 11188670041006 := by decide
private def t_e2392577018798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem cert_e2392577018798 : ¬ IsSelfInterpreter e2392577018798 :=
  wSource (t := t_e2392577018798) (replay_sound (ps := []) (t := e2392577018798) (by decide)) (by decide)
def e2392577018810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392577018810 : Closed e2392577018810 ∧ code e2392577018810 = 11188670041018 := by decide
private def t_e2392577018810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2392577018810 : ¬ IsSelfInterpreter e2392577018810 :=
  wSource (t := t_e2392577018810) (replay_sound (ps := []) (t := e2392577018810) (by decide)) (by decide)
def e2392577018838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392577018838 : Closed e2392577018838 ∧ code e2392577018838 = 11188670041046 := by decide
private def t_e2392577018838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem cert_e2392577018838 : ¬ IsSelfInterpreter e2392577018838 :=
  wSource (t := t_e2392577018838) (replay_sound (ps := []) (t := e2392577018838) (by decide)) (by decide)
def e2392577018842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392577018842 : Closed e2392577018842 ∧ code e2392577018842 = 11188670041050 := by decide
private def t_e2392577018842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2392577018842 : ¬ IsSelfInterpreter e2392577018842 :=
  wSource (t := t_e2392577018842) (replay_sound (ps := []) (t := e2392577018842) (by decide)) (by decide)
def e2392577019118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392577019118 : Closed e2392577019118 ∧ code e2392577019118 = 11188670041326 := by decide
private def t_e2392577019118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem cert_e2392577019118 : ¬ IsSelfInterpreter e2392577019118 :=
  wSource (t := t_e2392577019118) (replay_sound (ps := []) (t := e2392577019118) (by decide)) (by decide)
def e2392577019126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392577019126 : Closed e2392577019126 ∧ code e2392577019126 = 11188670041334 := by decide
private def t_e2392577019126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem cert_e2392577019126 : ¬ IsSelfInterpreter e2392577019126 :=
  wSource (t := t_e2392577019126) (replay_sound (ps := []) (t := e2392577019126) (by decide)) (by decide)
def e2392577019502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392577019502 : Closed e2392577019502 ∧ code e2392577019502 = 11188670041710 := by decide
private def t_e2392577019502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem cert_e2392577019502 : ¬ IsSelfInterpreter e2392577019502 :=
  wSource (t := t_e2392577019502) (replay_sound (ps := []) (t := e2392577019502) (by decide)) (by decide)
def e2392577019514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392577019514 : Closed e2392577019514 ∧ code e2392577019514 = 11188670041722 := by decide
private def t_e2392577019514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem cert_e2392577019514 : ¬ IsSelfInterpreter e2392577019514 :=
  wSource (t := t_e2392577019514) (replay_sound (ps := []) (t := e2392577019514) (by decide)) (by decide)
def e2392577019702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392577019702 : Closed e2392577019702 ∧ code e2392577019702 = 11188670041910 := by decide
private def t_e2392577019702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem cert_e2392577019702 : ¬ IsSelfInterpreter e2392577019702 :=
  wSource (t := t_e2392577019702) (replay_sound (ps := []) (t := e2392577019702) (by decide)) (by decide)
def e2392577019706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392577019706 : Closed e2392577019706 ∧ code e2392577019706 = 11188670041914 := by decide
private def t_e2392577019706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem cert_e2392577019706 : ¬ IsSelfInterpreter e2392577019706 :=
  wSource (t := t_e2392577019706) (replay_sound (ps := []) (t := e2392577019706) (by decide)) (by decide)
def e2392577813982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2392577813982 : Closed e2392577813982 ∧ code e2392577813982 = 11188670836190 := by decide
theorem cert_e2392577813982 : check e2392577813982 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392577813998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2392577813998 : Closed e2392577813998 ∧ code e2392577813998 = 11188670836206 := by decide
theorem cert_e2392577813998 : check e2392577813998 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392577814366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2392577814366 : Closed e2392577814366 ∧ code e2392577814366 = 11188670836574 := by decide
theorem cert_e2392577814366 : check e2392577814366 [[],[.left],[.left],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392577814394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2392577814394 : Closed e2392577814394 ∧ code e2392577814394 = 11188670836602 := by decide
private def t_e2392577814394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem cert_e2392577814394 : ¬ IsSelfInterpreter e2392577814394 :=
  wSource (t := t_e2392577814394) (replay_sound (ps := []) (t := e2392577814394) (by decide)) (by decide)
def e2392577814446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2392577814446 : Closed e2392577814446 ∧ code e2392577814446 = 11188670836654 := by decide
theorem cert_e2392577814446 : check e2392577814446 [[],[.left],[.left],[.left],[],[.under,.left]] .chain = true := by decide
def e2392577814458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2392577814458 : Closed e2392577814458 ∧ code e2392577814458 = 11188670836666 := by decide
private def t_e2392577814458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem cert_e2392577814458 : ¬ IsSelfInterpreter e2392577814458 :=
  wSource (t := t_e2392577814458) (replay_sound (ps := []) (t := e2392577814458) (by decide)) (by decide)
def e2392577815518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2392577815518 : Closed e2392577815518 ∧ code e2392577815518 = 11188670837726 := by decide
theorem cert_e2392577815518 : check e2392577815518 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392577815534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2392577815534 : Closed e2392577815534 ∧ code e2392577815534 = 11188670837742 := by decide
theorem cert_e2392577815534 : check e2392577815534 [[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2392577817822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2392577817822 : Closed e2392577817822 ∧ code e2392577817822 = 11188670840030 := by decide
theorem cert_e2392577817822 : check e2392577817822 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2392577817850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2392577817850 : Closed e2392577817850 ∧ code e2392577817850 = 11188670840058 := by decide
theorem cert_e2392577817850 : check e2392577817850 [[],[.left],[.left],[.left],[],[.under]] .three = true := by decide
def e2392577818222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392577818222 : Closed e2392577818222 ∧ code e2392577818222 = 11188670840430 := by decide
theorem cert_e2392577818222 : check e2392577818222 [[],[.left],[.left],[.left],[],[.under]] .sourceHead = true := by decide
def e2392577818234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392577818234 : Closed e2392577818234 ∧ code e2392577818234 = 11188670840442 := by decide
theorem cert_e2392577818234 : check e2392577818234 [[],[.left],[.left],[.left],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e2392577846638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2392577846638 : Closed e2392577846638 ∧ code e2392577846638 = 11188670868846 := by decide
theorem cert_e2392577846638 : check e2392577846638 [[],[.left],[.left],[.left],[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2392577846646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2392577846646 : Closed e2392577846646 ∧ code e2392577846646 = 11188670868854 := by decide
theorem cert_e2392577846646 : check e2392577846646 [[],[.left],[.left],[.left],[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2392577846702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2392577846702 : Closed e2392577846702 ∧ code e2392577846702 = 11188670868910 := by decide
def e2392577846714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2392577846714 : Closed e2392577846714 ∧ code e2392577846714 = 11188670868922 := by decide
def e2392577846742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2392577846742 : Closed e2392577846742 ∧ code e2392577846742 = 11188670868950 := by decide
theorem cert_e2392577846742 : check e2392577846742 [[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left],[]] .chain = true := by decide
def e2392577846746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2392577846746 : Closed e2392577846746 ∧ code e2392577846746 = 11188670868954 := by decide
def e2392577846958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2392577846958 : Closed e2392577846958 ∧ code e2392577846958 = 11188670869166 := by decide
theorem cert_e2392577846958 : check e2392577846958 [[],[.left],[.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[.under,.left,.left]] .sourceHead = true := by decide
def e2392577846970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2392577846970 : Closed e2392577846970 ∧ code e2392577846970 = 11188670869178 := by decide
def e2392577847018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2392577847018 : Closed e2392577847018 ∧ code e2392577847018 = 11188670869226 := by decide
private def t_e2392577847018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem cert_e2392577847018 : ¬ IsSelfInterpreter e2392577847018 :=
  wSource (t := t_e2392577847018) (replay_sound (ps := []) (t := e2392577847018) (by decide)) (by decide)
def e2392577847126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2392577847126 : Closed e2392577847126 ∧ code e2392577847126 = 11188670869334 := by decide
theorem cert_e2392577847126 : check e2392577847126 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .chain = true := by decide
def e2392577847130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2392577847130 : Closed e2392577847130 ∧ code e2392577847130 = 11188670869338 := by decide
theorem cert_e2392577847130 : check e2392577847130 [[],[.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left]] .chain = true := by decide
def e2392577847146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2392577847146 : Closed e2392577847146 ∧ code e2392577847146 = 11188670869354 := by decide
private def t_e2392577847146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem cert_e2392577847146 : ¬ IsSelfInterpreter e2392577847146 :=
  wSource (t := t_e2392577847146) (replay_sound (ps := []) (t := e2392577847146) (by decide)) (by decide)
def e2392577848174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2392577848174 : Closed e2392577848174 ∧ code e2392577848174 = 11188670870382 := by decide
theorem cert_e2392577848174 : check e2392577848174 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .sourceHead = true := by decide
def e2392577848182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2392577848182 : Closed e2392577848182 ∧ code e2392577848182 = 11188670870390 := by decide
theorem cert_e2392577848182 : check e2392577848182 [[],[.left],[.left],[.left],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2392577848238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2392577848238 : Closed e2392577848238 ∧ code e2392577848238 = 11188670870446 := by decide
def e2392577848250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2392577848250 : Closed e2392577848250 ∧ code e2392577848250 = 11188670870458 := by decide
def e2392577848278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2392577848278 : Closed e2392577848278 ∧ code e2392577848278 = 11188670870486 := by decide
theorem cert_e2392577848278 : check e2392577848278 [[],[.left],[.left],[.left],[],[.left],[.left],[.left],[]] .chain = true := by decide
def e2392577848282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2392577848282 : Closed e2392577848282 ∧ code e2392577848282 = 11188670870490 := by decide
def e2392577848558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392577848558 : Closed e2392577848558 ∧ code e2392577848558 = 11188670870766 := by decide
theorem cert_e2392577848558 : check e2392577848558 [[],[.left],[.left],[.left],[],[.left],[],[]] .sourceHead = true := by decide
def e2392577848566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392577848566 : Closed e2392577848566 ∧ code e2392577848566 = 11188670870774 := by decide
theorem cert_e2392577848566 : check e2392577848566 [[],[.left],[.left],[.left],[],[.left],[],[],[]] .sourceHead = true := by decide
def e2392577848942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392577848942 : Closed e2392577848942 ∧ code e2392577848942 = 11188670871150 := by decide
theorem cert_e2392577848942 : check e2392577848942 [[],[.left],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2392577848954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392577848954 : Closed e2392577848954 ∧ code e2392577848954 = 11188670871162 := by decide
theorem cert_e2392577848954 : check e2392577848954 [[],[.left],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2392577849142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392577849142 : Closed e2392577849142 ∧ code e2392577849142 = 11188670871350 := by decide
theorem cert_e2392577849142 : check e2392577849142 [[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2392577849146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392577849146 : Closed e2392577849146 ∧ code e2392577849146 = 11188670871354 := by decide
def e2392577849774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2392577849774 : Closed e2392577849774 ∧ code e2392577849774 = 11188670871982 := by decide
def e2392577849786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2392577849786 : Closed e2392577849786 ∧ code e2392577849786 = 11188670871994 := by decide
def e2392577849834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2392577849834 : Closed e2392577849834 ∧ code e2392577849834 = 11188670872042 := by decide
theorem cert_e2392577849834 : check e2392577849834 [[],[.left],[.left],[.left],[],[.left],[],[.left,.left],[.left,.left],[.left]] .chain = true := by decide
def e2392577849966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392577849966 : Closed e2392577849966 ∧ code e2392577849966 = 11188670872174 := by decide
def e2392577849978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392577849978 : Closed e2392577849978 ∧ code e2392577849978 = 11188670872186 := by decide
theorem cert_e2392577849978 : check e2392577849978 [[],[.left],[.left],[.left],[],[.left],[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2392577850266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392577850266 : Closed e2392577850266 ∧ code e2392577850266 = 11188670872474 := by decide
private def t_e2392577850266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem cert_e2392577850266 : ¬ IsSelfInterpreter e2392577850266 :=
  wSource (t := t_e2392577850266) (replay_sound (ps := []) (t := e2392577850266) (by decide)) (by decide)
def e2392577850582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2392577850582 : Closed e2392577850582 ∧ code e2392577850582 = 11188670872790 := by decide
theorem cert_e2392577850582 : check e2392577850582 [[],[.left],[.left],[.left],[],[.left],[.left,.left],[.left],[]] .chain = true := by decide
def e2392577850586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2392577850586 : Closed e2392577850586 ∧ code e2392577850586 = 11188670872794 := by decide
def e2392577850602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2392577850602 : Closed e2392577850602 ∧ code e2392577850602 = 11188670872810 := by decide
def e2392577850678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392577850678 : Closed e2392577850678 ∧ code e2392577850678 = 11188670872886 := by decide
theorem cert_e2392577850678 : check e2392577850678 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e2392577850682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392577850682 : Closed e2392577850682 ∧ code e2392577850682 = 11188670872890 := by decide
theorem cert_e2392577850682 : check e2392577850682 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .chain = true := by decide
def e2392577850778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392577850778 : Closed e2392577850778 ∧ code e2392577850778 = 11188670872986 := by decide
private def t_e2392577850778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem cert_e2392577850778 : ¬ IsSelfInterpreter e2392577850778 :=
  wSource (t := t_e2392577850778) (replay_sound (ps := []) (t := e2392577850778) (by decide)) (by decide)
def e2392577852382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2392577852382 : Closed e2392577852382 ∧ code e2392577852382 = 11188670874590 := by decide
theorem cert_e2392577852382 : check e2392577852382 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2392577852398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2392577852398 : Closed e2392577852398 ∧ code e2392577852398 = 11188670874606 := by decide
theorem cert_e2392577852398 : check e2392577852398 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[.left],[]] .identityHead = true := by decide
def e2392577854318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392577854318 : Closed e2392577854318 ∧ code e2392577854318 = 11188670876526 := by decide
theorem cert_e2392577854318 : check e2392577854318 [[],[.left],[.left],[.left],[],[],[.left],[]] .sourceHead = true := by decide
def e2392577854326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392577854326 : Closed e2392577854326 ∧ code e2392577854326 = 11188670876534 := by decide
theorem cert_e2392577854326 : check e2392577854326 [[],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2392577854382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392577854382 : Closed e2392577854382 ∧ code e2392577854382 = 11188670876590 := by decide
theorem cert_e2392577854382 : check e2392577854382 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.left,.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2392577854394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392577854394 : Closed e2392577854394 ∧ code e2392577854394 = 11188670876602 := by decide
def e2392577854422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392577854422 : Closed e2392577854422 ∧ code e2392577854422 = 11188670876630 := by decide
theorem cert_e2392577854422 : check e2392577854422 [[],[.left],[.left],[.left],[],[],[.left],[.left],[]] .chain = true := by decide
def e2392577854426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392577854426 : Closed e2392577854426 ∧ code e2392577854426 = 11188670876634 := by decide
def e2392577854702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392577854702 : Closed e2392577854702 ∧ code e2392577854702 = 11188670876910 := by decide
theorem cert_e2392577854702 : check e2392577854702 [[],[.left],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2392577854710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392577854710 : Closed e2392577854710 ∧ code e2392577854710 = 11188670876918 := by decide
theorem cert_e2392577854710 : check e2392577854710 [[],[.left],[.left],[.left],[],[],[],[],[]] .sourceHead = true := by decide
def e2392577855086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392577855086 : Closed e2392577855086 ∧ code e2392577855086 = 11188670877294 := by decide
theorem cert_e2392577855086 : check e2392577855086 [[],[.left],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2392577855098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392577855098 : Closed e2392577855098 ∧ code e2392577855098 = 11188670877306 := by decide
theorem cert_e2392577855098 : check e2392577855098 [[],[.left],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2392577855286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392577855286 : Closed e2392577855286 ∧ code e2392577855286 = 11188670877494 := by decide
theorem cert_e2392577855286 : check e2392577855286 [[],[.left],[.left],[.left],[],[],[],[.left],[]] .sourceHead = true := by decide
def e2392577855290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392577855290 : Closed e2392577855290 ∧ code e2392577855290 = 11188670877498 := by decide
theorem cert_e2392577855290 : check e2392577855290 [[],[.left],[.left],[.left],[],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2392577860062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2392577860062 : Closed e2392577860062 ∧ code e2392577860062 = 11188670882270 := by decide
theorem cert_e2392577860062 : check e2392577860062 [[],[.left],[.left],[.left],[],[],[.under]] .smaller = true := by decide
def e2392577860086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2392577860086 : Closed e2392577860086 ∧ code e2392577860086 = 11188670882294 := by decide
theorem cert_e2392577860086 : check e2392577860086 [[],[.left],[.left],[.left],[],[],[.under]] .smaller = true := by decide
def e2392577861038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2392577861038 : Closed e2392577861038 ∧ code e2392577861038 = 11188670883246 := by decide
theorem cert_e2392577861038 : check e2392577861038 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392577861050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2392577861050 : Closed e2392577861050 ∧ code e2392577861050 = 11188670883258 := by decide
theorem cert_e2392577861050 : check e2392577861050 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .chain = true := by decide
def e2392577861098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2392577861098 : Closed e2392577861098 ∧ code e2392577861098 = 11188670883306 := by decide
theorem cert_e2392577861098 : check e2392577861098 [[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2392577861230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392577861230 : Closed e2392577861230 ∧ code e2392577861230 = 11188670883438 := by decide
theorem cert_e2392577861230 : check e2392577861230 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392577861242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392577861242 : Closed e2392577861242 ∧ code e2392577861242 = 11188670883450 := by decide
theorem cert_e2392577861242 : check e2392577861242 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under]] .chain = true := by decide
def e2392577861530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392577861530 : Closed e2392577861530 ∧ code e2392577861530 = 11188670883738 := by decide
theorem cert_e2392577861530 : check e2392577861530 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left,.left],[.under,.left],[.under]] .chain = true := by decide
def e2392577863918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2392577863918 : Closed e2392577863918 ∧ code e2392577863918 = 11188670886126 := by decide
theorem cert_e2392577863918 : check e2392577863918 [[],[.left],[.left],[.left],[],[],[]] .chain = true := by decide
def e2392577863926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2392577863926 : Closed e2392577863926 ∧ code e2392577863926 = 11188670886134 := by decide
theorem cert_e2392577863926 : check e2392577863926 [[],[.left],[.left],[.left],[],[],[]] .chain = true := by decide
def e2392577864406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2392577864406 : Closed e2392577864406 ∧ code e2392577864406 = 11188670886614 := by decide
theorem cert_e2392577864406 : check e2392577864406 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2392577864410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2392577864410 : Closed e2392577864410 ∧ code e2392577864410 = 11188670886618 := by decide
theorem cert_e2392577864410 : check e2392577864410 [[],[.left],[.left],[.left],[],[],[.left,.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2392577864426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2392577864426 : Closed e2392577864426 ∧ code e2392577864426 = 11188670886634 := by decide
def e2392577864502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392577864502 : Closed e2392577864502 ∧ code e2392577864502 = 11188670886710 := by decide
theorem cert_e2392577864502 : check e2392577864502 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2392577864506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392577864506 : Closed e2392577864506 ∧ code e2392577864506 = 11188670886714 := by decide
theorem cert_e2392577864506 : check e2392577864506 [[],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2392577864602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392577864602 : Closed e2392577864602 ∧ code e2392577864602 = 11188670886810 := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392568895354
#print axioms Blc.Floor43.cert_e2392568895450
#print axioms Blc.Floor43.cert_e2392568912782
#print axioms Blc.Floor43.cert_e2392568913550
#print axioms Blc.Floor43.cert_e2392576765674
#print axioms Blc.Floor43.cert_e2392576765802
#print axioms Blc.Floor43.cert_e2392577018734
#print axioms Blc.Floor43.cert_e2392577018742
#print axioms Blc.Floor43.cert_e2392577018798
#print axioms Blc.Floor43.cert_e2392577018810
#print axioms Blc.Floor43.cert_e2392577018838
#print axioms Blc.Floor43.cert_e2392577018842
#print axioms Blc.Floor43.cert_e2392577019118
#print axioms Blc.Floor43.cert_e2392577019126
#print axioms Blc.Floor43.cert_e2392577019502
#print axioms Blc.Floor43.cert_e2392577019514
#print axioms Blc.Floor43.cert_e2392577019702
#print axioms Blc.Floor43.cert_e2392577019706
#print axioms Blc.Floor43.cert_e2392577814394
#print axioms Blc.Floor43.cert_e2392577814458
#print axioms Blc.Floor43.cert_e2392577847018
#print axioms Blc.Floor43.cert_e2392577847146
#print axioms Blc.Floor43.cert_e2392577850266
#print axioms Blc.Floor43.cert_e2392577850778
