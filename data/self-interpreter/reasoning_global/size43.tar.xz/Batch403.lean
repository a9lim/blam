import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373007838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2422373007838 : Closed e2422373007838 ∧ code e2422373007838 = 11218466030046 := by decide
theorem cert_e2422373007838 : check e2422373007838 [[],[]] .three = true := by decide
def e2422373007866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.lam (.var 5)))) (.var 0)))))))
theorem wire_e2422373007866 : Closed e2422373007866 ∧ code e2422373007866 = 11218466030074 := by decide
theorem cert_e2422373007866 : check e2422373007866 [[],[]] .three = true := by decide
def e2422373008238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2422373008238 : Closed e2422373008238 ∧ code e2422373008238 = 11218466030446 := by decide
theorem cert_e2422373008238 : check e2422373008238 [[],[]] .smaller = true := by decide
def e2422373008250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2422373008250 : Closed e2422373008250 ∧ code e2422373008250 = 11218466030458 := by decide
theorem cert_e2422373008250 : check e2422373008250 [[],[]] .smaller = true := by decide
def e2422373008302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2422373008302 : Closed e2422373008302 ∧ code e2422373008302 = 11218466030510 := by decide
theorem cert_e2422373008302 : check e2422373008302 [[],[]] .smaller = true := by decide
def e2422373008362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2422373008362 : Closed e2422373008362 ∧ code e2422373008362 = 11218466030570 := by decide
theorem cert_e2422373008362 : check e2422373008362 [[],[]] .smaller = true := by decide
def e2422373008606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373008606 : Closed e2422373008606 ∧ code e2422373008606 = 11218466030814 := by decide
theorem cert_e2422373008606 : check e2422373008606 [[],[]] .three = true := by decide
def e2422373008634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373008634 : Closed e2422373008634 ∧ code e2422373008634 = 11218466030842 := by decide
theorem cert_e2422373008634 : check e2422373008634 [[],[]] .three = true := by decide
def e2422373008958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.lam (.var 4))))))))
theorem wire_e2422373008958 : Closed e2422373008958 ∧ code e2422373008958 = 11218466031166 := by decide
theorem cert_e2422373008958 : check e2422373008958 [[],[]] .three = true := by decide
def e2422373009006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373009006 : Closed e2422373009006 ∧ code e2422373009006 = 11218466031214 := by decide
theorem cert_e2422373009006 : check e2422373009006 [[],[]] .smaller = true := by decide
def e2422373009018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373009018 : Closed e2422373009018 ∧ code e2422373009018 = 11218466031226 := by decide
theorem cert_e2422373009018 : check e2422373009018 [[],[]] .smaller = true := by decide
def e2422373009306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373009306 : Closed e2422373009306 ∧ code e2422373009306 = 11218466031514 := by decide
theorem cert_e2422373009306 : check e2422373009306 [[],[]] .smaller = true := by decide
def e2422373009350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 4))) (.lam (.var 1))))))))
theorem wire_e2422373009350 : Closed e2422373009350 ∧ code e2422373009350 = 11218466031558 := by decide
theorem cert_e2422373009350 : check e2422373009350 [[],[]] .three = true := by decide
def e2422373010526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 3)))))))
theorem wire_e2422373010526 : Closed e2422373010526 ∧ code e2422373010526 = 11218466032734 := by decide
theorem cert_e2422373010526 : check e2422373010526 [[],[]] .three = true := by decide
def e2422373010542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 2)))))))
theorem wire_e2422373010542 : Closed e2422373010542 ∧ code e2422373010542 = 11218466032750 := by decide
theorem cert_e2422373010542 : check e2422373010542 [[],[]] .smaller = true := by decide
def e2422373010554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422373010554 : Closed e2422373010554 ∧ code e2422373010554 = 11218466032762 := by decide
theorem cert_e2422373010554 : check e2422373010554 [[],[]] .smaller = true := by decide
def e2422373010718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 3))))))))
theorem wire_e2422373010718 : Closed e2422373010718 ∧ code e2422373010718 = 11218466032926 := by decide
theorem cert_e2422373010718 : check e2422373010718 [[],[]] .smaller = true := by decide
def e2422373010886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422373010886 : Closed e2422373010886 ∧ code e2422373010886 = 11218466033094 := by decide
theorem cert_e2422373010886 : check e2422373010886 [[],[]] .smaller = true := by decide
def e2422373010910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2422373010910 : Closed e2422373010910 ∧ code e2422373010910 = 11218466033118 := by decide
theorem cert_e2422373010910 : check e2422373010910 [[],[]] .three = true := by decide
def e2422373010914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))) (.lam (.var 0))))))))
theorem wire_e2422373010914 : Closed e2422373010914 ∧ code e2422373010914 = 11218466033122 := by decide
theorem cert_e2422373010914 : check e2422373010914 [[],[]] .three = true := by decide
def e2422373010926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2422373010926 : Closed e2422373010926 ∧ code e2422373010926 = 11218466033134 := by decide
theorem cert_e2422373010926 : check e2422373010926 [[],[]] .three = true := by decide
def e2422373011226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373011226 : Closed e2422373011226 ∧ code e2422373011226 = 11218466033434 := by decide
theorem cert_e2422373011226 : check e2422373011226 [[],[]] .smaller = true := by decide
def e2422373011270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373011270 : Closed e2422373011270 ∧ code e2422373011270 = 11218466033478 := by decide
theorem cert_e2422373011270 : check e2422373011270 [[],[]] .smaller = true := by decide
def e2422373011294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2422373011294 : Closed e2422373011294 ∧ code e2422373011294 = 11218466033502 := by decide
theorem cert_e2422373011294 : check e2422373011294 [[],[]] .three = true := by decide
def e2422373011322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2422373011322 : Closed e2422373011322 ∧ code e2422373011322 = 11218466033530 := by decide
theorem cert_e2422373011322 : check e2422373011322 [[],[]] .three = true := by decide
def e2422373011338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373011338 : Closed e2422373011338 ∧ code e2422373011338 = 11218466033546 := by decide
theorem cert_e2422373011338 : check e2422373011338 [[],[]] .three = true := by decide
def e2422373011362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373011362 : Closed e2422373011362 ∧ code e2422373011362 = 11218466033570 := by decide
theorem cert_e2422373011362 : check e2422373011362 [[],[]] .three = true := by decide
def e2422373011374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2422373011374 : Closed e2422373011374 ∧ code e2422373011374 = 11218466033582 := by decide
theorem cert_e2422373011374 : check e2422373011374 [[],[]] .three = true := by decide
def e2422373011386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2422373011386 : Closed e2422373011386 ∧ code e2422373011386 = 11218466033594 := by decide
theorem cert_e2422373011386 : check e2422373011386 [[],[]] .three = true := by decide
def e2422373011582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.lam (.var 5)))))))))
theorem wire_e2422373011582 : Closed e2422373011582 ∧ code e2422373011582 = 11218466033790 := by decide
theorem cert_e2422373011582 : check e2422373011582 [[],[]] .three = true := by decide
def e2422373011678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373011678 : Closed e2422373011678 ∧ code e2422373011678 = 11218466033886 := by decide
theorem cert_e2422373011678 : check e2422373011678 [[],[]] .smaller = true := by decide
def e2422373011706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373011706 : Closed e2422373011706 ∧ code e2422373011706 = 11218466033914 := by decide
theorem cert_e2422373011706 : check e2422373011706 [[],[]] .smaller = true := by decide
def e2422373012254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2422373012254 : Closed e2422373012254 ∧ code e2422373012254 = 11218466034462 := by decide
theorem cert_e2422373012254 : check e2422373012254 [[],[]] .smaller = true := by decide
def e2422373012422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2422373012422 : Closed e2422373012422 ∧ code e2422373012422 = 11218466034630 := by decide
theorem cert_e2422373012422 : check e2422373012422 [[],[]] .smaller = true := by decide
def e2422373012446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2422373012446 : Closed e2422373012446 ∧ code e2422373012446 = 11218466034654 := by decide
theorem cert_e2422373012446 : check e2422373012446 [[],[]] .three = true := by decide
def e2422373012450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 3) (.lam (.var 0)))))))))
theorem wire_e2422373012450 : Closed e2422373012450 ∧ code e2422373012450 = 11218466034658 := by decide
theorem cert_e2422373012450 : check e2422373012450 [[],[]] .three = true := by decide
def e2422373012462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2422373012462 : Closed e2422373012462 ∧ code e2422373012462 = 11218466034670 := by decide
theorem cert_e2422373012462 : check e2422373012462 [[],[]] .three = true := by decide
def e2422373014582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373014582 : Closed e2422373014582 ∧ code e2422373014582 = 11218466036790 := by decide
theorem cert_e2422373014582 : check e2422373014582 [[],[]] .smaller = true := by decide
def e2422373014586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373014586 : Closed e2422373014586 ∧ code e2422373014586 = 11218466036794 := by decide
theorem cert_e2422373014586 : check e2422373014586 [[],[]] .smaller = true := by decide
def e2422373014726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373014726 : Closed e2422373014726 ∧ code e2422373014726 = 11218466036934 := by decide
theorem cert_e2422373014726 : check e2422373014726 [[],[]] .smaller = true := by decide
def e2422373014750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373014750 : Closed e2422373014750 ∧ code e2422373014750 = 11218466036958 := by decide
theorem cert_e2422373014750 : check e2422373014750 [[],[]] .three = true := by decide
def e2422373014778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373014778 : Closed e2422373014778 ∧ code e2422373014778 = 11218466036986 := by decide
theorem cert_e2422373014778 : check e2422373014778 [[],[]] .three = true := by decide
def e2422373015054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373015054 : Closed e2422373015054 ∧ code e2422373015054 = 11218466037262 := by decide
theorem cert_e2422373015054 : check e2422373015054 [[],[]] .three = true := by decide
def e2422373015138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373015138 : Closed e2422373015138 ∧ code e2422373015138 = 11218466037346 := by decide
theorem cert_e2422373015138 : check e2422373015138 [[],[]] .three = true := by decide
def e2422373015150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373015150 : Closed e2422373015150 ∧ code e2422373015150 = 11218466037358 := by decide
theorem cert_e2422373015150 : check e2422373015150 [[],[]] .three = true := by decide
def e2422373015162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373015162 : Closed e2422373015162 ∧ code e2422373015162 = 11218466037370 := by decide
theorem cert_e2422373015162 : check e2422373015162 [[],[]] .three = true := by decide
def e2422373015658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373015658 : Closed e2422373015658 ∧ code e2422373015658 = 11218466037866 := by decide
theorem cert_e2422373015658 : check e2422373015658 [[],[]] .smaller = true := by decide
def e2422373015706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373015706 : Closed e2422373015706 ∧ code e2422373015706 = 11218466037914 := by decide
theorem cert_e2422373015706 : check e2422373015706 [[],[]] .smaller = true := by decide
def e2422373015790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422373015790 : Closed e2422373015790 ∧ code e2422373015790 = 11218466037998 := by decide
theorem cert_e2422373015790 : check e2422373015790 [[],[]] .smaller = true := by decide
def e2422373015802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422373015802 : Closed e2422373015802 ∧ code e2422373015802 = 11218466038010 := by decide
theorem cert_e2422373015802 : check e2422373015802 [[],[]] .smaller = true := by decide
def e2422373015990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2422373015990 : Closed e2422373015990 ∧ code e2422373015990 = 11218466038198 := by decide
theorem cert_e2422373015990 : check e2422373015990 [[],[]] .smaller = true := by decide
def e2422373015994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422373015994 : Closed e2422373015994 ∧ code e2422373015994 = 11218466038202 := by decide
theorem cert_e2422373015994 : check e2422373015994 [[],[]] .smaller = true := by decide
def e2422373016022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2422373016022 : Closed e2422373016022 ∧ code e2422373016022 = 11218466038230 := by decide
theorem cert_e2422373016022 : check e2422373016022 [[],[]] .smaller = true := by decide
def e2422373016026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e2422373016026 : Closed e2422373016026 ∧ code e2422373016026 = 11218466038234 := by decide
theorem cert_e2422373016026 : check e2422373016026 [[],[]] .smaller = true := by decide
def e2422373016042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422373016042 : Closed e2422373016042 ∧ code e2422373016042 = 11218466038250 := by decide
theorem cert_e2422373016042 : check e2422373016042 [[],[]] .smaller = true := by decide
def e2422373016174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373016174 : Closed e2422373016174 ∧ code e2422373016174 = 11218466038382 := by decide
theorem cert_e2422373016174 : check e2422373016174 [[],[]] .smaller = true := by decide
def e2422373016186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373016186 : Closed e2422373016186 ∧ code e2422373016186 = 11218466038394 := by decide
theorem cert_e2422373016186 : check e2422373016186 [[],[]] .smaller = true := by decide
def e2422373016350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422373016350 : Closed e2422373016350 ∧ code e2422373016350 = 11218466038558 := by decide
theorem cert_e2422373016350 : check e2422373016350 [[],[]] .smaller = true := by decide
def e2422373016374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373016374 : Closed e2422373016374 ∧ code e2422373016374 = 11218466038582 := by decide
theorem cert_e2422373016374 : check e2422373016374 [[],[]] .smaller = true := by decide
def e2422373016378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373016378 : Closed e2422373016378 ∧ code e2422373016378 = 11218466038586 := by decide
theorem cert_e2422373016378 : check e2422373016378 [[],[]] .smaller = true := by decide
def e2422373016474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373016474 : Closed e2422373016474 ∧ code e2422373016474 = 11218466038682 := by decide
theorem cert_e2422373016474 : check e2422373016474 [[],[]] .smaller = true := by decide
def e2422373016518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422373016518 : Closed e2422373016518 ∧ code e2422373016518 = 11218466038726 := by decide
theorem cert_e2422373016518 : check e2422373016518 [[],[]] .smaller = true := by decide
def e2422373016542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 3))) (.var 3)))))))
theorem wire_e2422373016542 : Closed e2422373016542 ∧ code e2422373016542 = 11218466038750 := by decide
theorem cert_e2422373016542 : check e2422373016542 [[],[]] .three = true := by decide
def e2422373016558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 4))) (.var 2)))))))
theorem wire_e2422373016558 : Closed e2422373016558 ∧ code e2422373016558 = 11218466038766 := by decide
theorem cert_e2422373016558 : check e2422373016558 [[],[]] .three = true := by decide
def e2422373017002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2422373017002 : Closed e2422373017002 ∧ code e2422373017002 = 11218466039210 := by decide
theorem cert_e2422373017002 : check e2422373017002 [[],[]] .smaller = true := by decide
def e2422373017098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373017098 : Closed e2422373017098 ∧ code e2422373017098 = 11218466039306 := by decide
theorem cert_e2422373017098 : check e2422373017098 [[],[]] .smaller = true := by decide
def e2422373017134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422373017134 : Closed e2422373017134 ∧ code e2422373017134 = 11218466039342 := by decide
theorem cert_e2422373017134 : check e2422373017134 [[],[]] .smaller = true := by decide
def e2422373017142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2422373017142 : Closed e2422373017142 ∧ code e2422373017142 = 11218466039350 := by decide
theorem cert_e2422373017142 : check e2422373017142 [[],[]] .smaller = true := by decide
def e2422373017146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2422373017146 : Closed e2422373017146 ∧ code e2422373017146 = 11218466039354 := by decide
theorem cert_e2422373017146 : check e2422373017146 [[],[]] .smaller = true := by decide
def e2422373017194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2422373017194 : Closed e2422373017194 ∧ code e2422373017194 = 11218466039402 := by decide
theorem cert_e2422373017194 : check e2422373017194 [[],[]] .smaller = true := by decide
def e2422373017218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373017218 : Closed e2422373017218 ∧ code e2422373017218 = 11218466039426 := by decide
theorem cert_e2422373017218 : check e2422373017218 [[],[]] .smaller = true := by decide
def e2422373017230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2422373017230 : Closed e2422373017230 ∧ code e2422373017230 = 11218466039438 := by decide
theorem cert_e2422373017230 : check e2422373017230 [[],[]] .smaller = true := by decide
def e2422373017242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373017242 : Closed e2422373017242 ∧ code e2422373017242 = 11218466039450 := by decide
theorem cert_e2422373017242 : check e2422373017242 [[],[]] .smaller = true := by decide
def e2422373017286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2422373017286 : Closed e2422373017286 ∧ code e2422373017286 = 11218466039494 := by decide
theorem cert_e2422373017286 : check e2422373017286 [[],[]] .smaller = true := by decide
def e2422373017310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2422373017310 : Closed e2422373017310 ∧ code e2422373017310 = 11218466039518 := by decide
theorem cert_e2422373017310 : check e2422373017310 [[],[]] .three = true := by decide
def e2422373017314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2422373017314 : Closed e2422373017314 ∧ code e2422373017314 = 11218466039522 := by decide
theorem cert_e2422373017314 : check e2422373017314 [[],[]] .smaller = true := by decide
def e2422373017326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2422373017326 : Closed e2422373017326 ∧ code e2422373017326 = 11218466039534 := by decide
theorem cert_e2422373017326 : check e2422373017326 [[],[]] .smaller = true := by decide
def e2422373017334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2422373017334 : Closed e2422373017334 ∧ code e2422373017334 = 11218466039542 := by decide
theorem cert_e2422373017334 : check e2422373017334 [[],[]] .three = true := by decide
def e2422373017370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373017370 : Closed e2422373017370 ∧ code e2422373017370 = 11218466039578 := by decide
theorem cert_e2422373017370 : check e2422373017370 [[],[]] .smaller = true := by decide
def e2422373017414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373017414 : Closed e2422373017414 ∧ code e2422373017414 = 11218466039622 := by decide
theorem cert_e2422373017414 : check e2422373017414 [[],[]] .smaller = true := by decide
def e2422373017438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2422373017438 : Closed e2422373017438 ∧ code e2422373017438 = 11218466039646 := by decide
theorem cert_e2422373017438 : check e2422373017438 [[],[]] .three = true := by decide
def e2422373017466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2422373017466 : Closed e2422373017466 ∧ code e2422373017466 = 11218466039674 := by decide
theorem cert_e2422373017466 : check e2422373017466 [[],[]] .three = true := by decide
def e2422373017482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373017482 : Closed e2422373017482 ∧ code e2422373017482 = 11218466039690 := by decide
theorem cert_e2422373017482 : check e2422373017482 [[],[]] .smaller = true := by decide
def e2422373017506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373017506 : Closed e2422373017506 ∧ code e2422373017506 = 11218466039714 := by decide
theorem cert_e2422373017506 : check e2422373017506 [[],[]] .smaller = true := by decide
def e2422373017518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2422373017518 : Closed e2422373017518 ∧ code e2422373017518 = 11218466039726 := by decide
theorem cert_e2422373017518 : check e2422373017518 [[],[]] .smaller = true := by decide
def e2422373017530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2422373017530 : Closed e2422373017530 ∧ code e2422373017530 = 11218466039738 := by decide
theorem cert_e2422373017530 : check e2422373017530 [[],[]] .smaller = true := by decide
def e2422373017558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2422373017558 : Closed e2422373017558 ∧ code e2422373017558 = 11218466039766 := by decide
theorem cert_e2422373017558 : check e2422373017558 [[],[]] .three = true := by decide
def e2422373017562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2422373017562 : Closed e2422373017562 ∧ code e2422373017562 = 11218466039770 := by decide
theorem cert_e2422373017562 : check e2422373017562 [[],[]] .three = true := by decide
def e2422373017626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373017626 : Closed e2422373017626 ∧ code e2422373017626 = 11218466039834 := by decide
theorem cert_e2422373017626 : check e2422373017626 [[],[]] .smaller = true := by decide
def e2422373017662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373017662 : Closed e2422373017662 ∧ code e2422373017662 = 11218466039870 := by decide
theorem cert_e2422373017662 : check e2422373017662 [[],[]] .smaller = true := by decide
def e2422373017710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373017710 : Closed e2422373017710 ∧ code e2422373017710 = 11218466039918 := by decide
theorem cert_e2422373017710 : check e2422373017710 [[],[]] .smaller = true := by decide
def e2422373017718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373017718 : Closed e2422373017718 ∧ code e2422373017718 = 11218466039926 := by decide
theorem cert_e2422373017718 : check e2422373017718 [[],[]] .smaller = true := by decide
def e2422373017722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373017722 : Closed e2422373017722 ∧ code e2422373017722 = 11218466039930 := by decide
theorem cert_e2422373017722 : check e2422373017722 [[],[]] .smaller = true := by decide
def e2422373017962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373017962 : Closed e2422373017962 ∧ code e2422373017962 = 11218466040170 := by decide
theorem cert_e2422373017962 : check e2422373017962 [[],[]] .smaller = true := by decide
def e2422373017986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373017986 : Closed e2422373017986 ∧ code e2422373017986 = 11218466040194 := by decide
theorem cert_e2422373017986 : check e2422373017986 [[],[]] .smaller = true := by decide
def e2422373017998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373017998 : Closed e2422373017998 ∧ code e2422373017998 = 11218466040206 := by decide
theorem cert_e2422373017998 : check e2422373017998 [[],[]] .smaller = true := by decide
def e2422373018010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373018010 : Closed e2422373018010 ∧ code e2422373018010 = 11218466040218 := by decide
theorem cert_e2422373018010 : check e2422373018010 [[],[]] .smaller = true := by decide
def e2422373018054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373018054 : Closed e2422373018054 ∧ code e2422373018054 = 11218466040262 := by decide
theorem cert_e2422373018054 : check e2422373018054 [[],[]] .smaller = true := by decide
def e2422373018078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373018078 : Closed e2422373018078 ∧ code e2422373018078 = 11218466040286 := by decide
theorem cert_e2422373018078 : check e2422373018078 [[],[]] .three = true := by decide
def e2422373018082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373018082 : Closed e2422373018082 ∧ code e2422373018082 = 11218466040290 := by decide
theorem cert_e2422373018082 : check e2422373018082 [[],[]] .smaller = true := by decide
def e2422373018094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373018094 : Closed e2422373018094 ∧ code e2422373018094 = 11218466040302 := by decide
theorem cert_e2422373018094 : check e2422373018094 [[],[]] .smaller = true := by decide
def e2422373018102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373018102 : Closed e2422373018102 ∧ code e2422373018102 = 11218466040310 := by decide
theorem cert_e2422373018102 : check e2422373018102 [[],[]] .three = true := by decide
def e2422373018678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373018678 : Closed e2422373018678 ∧ code e2422373018678 = 11218466040886 := by decide
theorem cert_e2422373018678 : check e2422373018678 [[],[]] .smaller = true := by decide
def e2422373018682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373018682 : Closed e2422373018682 ∧ code e2422373018682 = 11218466040890 := by decide
theorem cert_e2422373018682 : check e2422373018682 [[],[]] .smaller = true := by decide
def e2422373018822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373018822 : Closed e2422373018822 ∧ code e2422373018822 = 11218466041030 := by decide
theorem cert_e2422373018822 : check e2422373018822 [[],[]] .smaller = true := by decide
def e2422373018846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373018846 : Closed e2422373018846 ∧ code e2422373018846 = 11218466041054 := by decide
theorem cert_e2422373018846 : check e2422373018846 [[],[]] .three = true := by decide
def e2422373018874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373018874 : Closed e2422373018874 ∧ code e2422373018874 = 11218466041082 := by decide
theorem cert_e2422373018874 : check e2422373018874 [[],[]] .three = true := by decide
def e2422373019150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373019150 : Closed e2422373019150 ∧ code e2422373019150 = 11218466041358 := by decide
theorem cert_e2422373019150 : check e2422373019150 [[],[]] .smaller = true := by decide
def e2422373019198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 4))))))))
theorem wire_e2422373019198 : Closed e2422373019198 ∧ code e2422373019198 = 11218466041406 := by decide
theorem cert_e2422373019198 : check e2422373019198 [[],[]] .three = true := by decide
def e2422373019234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373019234 : Closed e2422373019234 ∧ code e2422373019234 = 11218466041442 := by decide
theorem cert_e2422373019234 : check e2422373019234 [[],[]] .smaller = true := by decide
def e2422373019246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373019246 : Closed e2422373019246 ∧ code e2422373019246 = 11218466041454 := by decide
theorem cert_e2422373019246 : check e2422373019246 [[],[]] .smaller = true := by decide
def e2422373019258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373019258 : Closed e2422373019258 ∧ code e2422373019258 = 11218466041466 := by decide
theorem cert_e2422373019258 : check e2422373019258 [[],[]] .smaller = true := by decide
def e2422373019422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.lam (.var 3))))))))
theorem wire_e2422373019422 : Closed e2422373019422 ∧ code e2422373019422 = 11218466041630 := by decide
theorem cert_e2422373019422 : check e2422373019422 [[],[]] .three = true := by decide
def e2422373019446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373019446 : Closed e2422373019446 ∧ code e2422373019446 = 11218466041654 := by decide
theorem cert_e2422373019446 : check e2422373019446 [[],[]] .three = true := by decide
def e2422373019450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373019450 : Closed e2422373019450 ∧ code e2422373019450 = 11218466041658 := by decide
theorem cert_e2422373019450 : check e2422373019450 [[],[]] .three = true := by decide
def e2422373019766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2422373019766 : Closed e2422373019766 ∧ code e2422373019766 = 11218466041974 := by decide
theorem cert_e2422373019766 : check e2422373019766 [[],[]] .three = true := by decide
def e2422373019770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2422373019770 : Closed e2422373019770 ∧ code e2422373019770 = 11218466041978 := by decide
theorem cert_e2422373019770 : check e2422373019770 [[],[]] .three = true := by decide
def e2422373019866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2422373019866 : Closed e2422373019866 ∧ code e2422373019866 = 11218466042074 := by decide
theorem cert_e2422373019866 : check e2422373019866 [[],[]] .three = true := by decide
def e2422373019882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2422373019882 : Closed e2422373019882 ∧ code e2422373019882 = 11218466042090 := by decide
theorem cert_e2422373019882 : check e2422373019882 [[],[]] .three = true := by decide
def e2422373019958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373019958 : Closed e2422373019958 ∧ code e2422373019958 = 11218466042166 := by decide
theorem cert_e2422373019958 : check e2422373019958 [[],[]] .three = true := by decide
def e2422373019962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373019962 : Closed e2422373019962 ∧ code e2422373019962 = 11218466042170 := by decide
theorem cert_e2422373019962 : check e2422373019962 [[],[]] .three = true := by decide
def e2422373020046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2422373020046 : Closed e2422373020046 ∧ code e2422373020046 = 11218466042254 := by decide
theorem cert_e2422373020046 : check e2422373020046 [[],[]] .three = true := by decide
def e2422373020058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373020058 : Closed e2422373020058 ∧ code e2422373020058 = 11218466042266 := by decide
theorem cert_e2422373020058 : check e2422373020058 [[],[]] .three = true := by decide
def e2422373020102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2422373020102 : Closed e2422373020102 ∧ code e2422373020102 = 11218466042310 := by decide
theorem cert_e2422373020102 : check e2422373020102 [[],[]] .three = true := by decide
def e2422373020142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 3))) (.var 2)))))))
theorem wire_e2422373020142 : Closed e2422373020142 ∧ code e2422373020142 = 11218466042350 := by decide
theorem cert_e2422373020142 : check e2422373020142 [[],[]] .three = true := by decide
def e2422373020438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422373020438 : Closed e2422373020438 ∧ code e2422373020438 = 11218466042646 := by decide
theorem cert_e2422373020438 : check e2422373020438 [[],[]] .three = true := by decide
def e2422373020442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2422373020442 : Closed e2422373020442 ∧ code e2422373020442 = 11218466042650 := by decide
theorem cert_e2422373020442 : check e2422373020442 [[],[]] .three = true := by decide
def e2422373020486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2422373020486 : Closed e2422373020486 ∧ code e2422373020486 = 11218466042694 := by decide
theorem cert_e2422373020486 : check e2422373020486 [[],[]] .three = true := by decide
def e2422373020510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))) (.var 3)))))))
theorem wire_e2422373020510 : Closed e2422373020510 ∧ code e2422373020510 = 11218466042718 := by decide
theorem cert_e2422373020510 : check e2422373020510 [[],[]] .three = true := by decide
def e2422373020514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2422373020514 : Closed e2422373020514 ∧ code e2422373020514 = 11218466042722 := by decide
theorem cert_e2422373020514 : check e2422373020514 [[],[]] .three = true := by decide
def e2422373020526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422373020526 : Closed e2422373020526 ∧ code e2422373020526 = 11218466042734 := by decide
theorem cert_e2422373020526 : check e2422373020526 [[],[]] .three = true := by decide
def e2422373020534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422373020534 : Closed e2422373020534 ∧ code e2422373020534 = 11218466042742 := by decide
theorem cert_e2422373020534 : check e2422373020534 [[],[]] .three = true := by decide
def e2422373020538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3))) (.var 0)))))))
theorem wire_e2422373020538 : Closed e2422373020538 ∧ code e2422373020538 = 11218466042746 := by decide
theorem cert_e2422373020538 : check e2422373020538 [[],[]] .three = true := by decide
def e2422373020554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2422373020554 : Closed e2422373020554 ∧ code e2422373020554 = 11218466042762 := by decide
theorem cert_e2422373020554 : check e2422373020554 [[],[]] .three = true := by decide
def e2422373020578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2422373020578 : Closed e2422373020578 ∧ code e2422373020578 = 11218466042786 := by decide
theorem cert_e2422373020578 : check e2422373020578 [[],[]] .three = true := by decide
def e2422373020590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422373020590 : Closed e2422373020590 ∧ code e2422373020590 = 11218466042798 := by decide
theorem cert_e2422373020590 : check e2422373020590 [[],[]] .three = true := by decide
def e2422373020602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422373020602 : Closed e2422373020602 ∧ code e2422373020602 = 11218466042810 := by decide
theorem cert_e2422373020602 : check e2422373020602 [[],[]] .three = true := by decide
def e2422373020630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422373020630 : Closed e2422373020630 ∧ code e2422373020630 = 11218466042838 := by decide
theorem cert_e2422373020630 : check e2422373020630 [[],[]] .three = true := by decide
def e2422373020634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422373020634 : Closed e2422373020634 ∧ code e2422373020634 = 11218466042842 := by decide
theorem cert_e2422373020634 : check e2422373020634 [[],[]] .three = true := by decide
def e2422373020650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0))) (.var 0)))))))
theorem wire_e2422373020650 : Closed e2422373020650 ∧ code e2422373020650 = 11218466042858 := by decide
theorem cert_e2422373020650 : check e2422373020650 [[],[]] .three = true := by decide
def e2422373020702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373020702 : Closed e2422373020702 ∧ code e2422373020702 = 11218466042910 := by decide
theorem cert_e2422373020702 : check e2422373020702 [[],[]] .three = true := by decide
def e2422373020726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373020726 : Closed e2422373020726 ∧ code e2422373020726 = 11218466042934 := by decide
theorem cert_e2422373020726 : check e2422373020726 [[],[]] .three = true := by decide
def e2422373020730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373020730 : Closed e2422373020730 ∧ code e2422373020730 = 11218466042938 := by decide
theorem cert_e2422373020730 : check e2422373020730 [[],[]] .three = true := by decide
def e2422373020870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373020870 : Closed e2422373020870 ∧ code e2422373020870 = 11218466043078 := by decide
theorem cert_e2422373020870 : check e2422373020870 [[],[]] .three = true := by decide
def e2422373020894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373020894 : Closed e2422373020894 ∧ code e2422373020894 = 11218466043102 := by decide
theorem cert_e2422373020894 : check e2422373020894 [[],[]] .three = true := by decide
def e2422373020898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373020898 : Closed e2422373020898 ∧ code e2422373020898 = 11218466043106 := by decide
theorem cert_e2422373020898 : check e2422373020898 [[],[]] .three = true := by decide
def e2422373020910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373020910 : Closed e2422373020910 ∧ code e2422373020910 = 11218466043118 := by decide
theorem cert_e2422373020910 : check e2422373020910 [[],[]] .three = true := by decide
def e2422373020918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373020918 : Closed e2422373020918 ∧ code e2422373020918 = 11218466043126 := by decide
theorem cert_e2422373020918 : check e2422373020918 [[],[]] .three = true := by decide
def e2422373020922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373020922 : Closed e2422373020922 ∧ code e2422373020922 = 11218466043130 := by decide
theorem cert_e2422373020922 : check e2422373020922 [[],[]] .three = true := by decide
def e2422373021198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373021198 : Closed e2422373021198 ∧ code e2422373021198 = 11218466043406 := by decide
theorem cert_e2422373021198 : check e2422373021198 [[],[]] .three = true := by decide
def e2422373021282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373021282 : Closed e2422373021282 ∧ code e2422373021282 = 11218466043490 := by decide
theorem cert_e2422373021282 : check e2422373021282 [[],[]] .three = true := by decide
def e2422373021294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373021294 : Closed e2422373021294 ∧ code e2422373021294 = 11218466043502 := by decide
theorem cert_e2422373021294 : check e2422373021294 [[],[]] .three = true := by decide
def e2422373021306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373021306 : Closed e2422373021306 ∧ code e2422373021306 = 11218466043514 := by decide
theorem cert_e2422373021306 : check e2422373021306 [[],[]] .three = true := by decide
def e2422373021470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.lam (.var 3))))))))
theorem wire_e2422373021470 : Closed e2422373021470 ∧ code e2422373021470 = 11218466043678 := by decide
theorem cert_e2422373021470 : check e2422373021470 [[],[]] .three = true := by decide
def e2422373021494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373021494 : Closed e2422373021494 ∧ code e2422373021494 = 11218466043702 := by decide
theorem cert_e2422373021494 : check e2422373021494 [[],[]] .three = true := by decide
def e2422373021498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373021498 : Closed e2422373021498 ∧ code e2422373021498 = 11218466043706 := by decide
theorem cert_e2422373021498 : check e2422373021498 [[],[]] .three = true := by decide
def e2422373021594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373021594 : Closed e2422373021594 ∧ code e2422373021594 = 11218466043802 := by decide
theorem cert_e2422373021594 : check e2422373021594 [[],[]] .three = true := by decide
def e2422373024598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0)) (.var 1)))))))
theorem wire_e2422373024598 : Closed e2422373024598 ∧ code e2422373024598 = 11218466046806 := by decide
theorem cert_e2422373024598 : check e2422373024598 [[],[]] .smaller = true := by decide
def e2422373024602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 0)))))))
theorem wire_e2422373024602 : Closed e2422373024602 ∧ code e2422373024602 = 11218466046810 := by decide
theorem cert_e2422373024602 : check e2422373024602 [[],[]] .smaller = true := by decide
def e2422373024982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422373024982 : Closed e2422373024982 ∧ code e2422373024982 = 11218466047190 := by decide
theorem cert_e2422373024982 : check e2422373024982 [[],[]] .smaller = true := by decide
end Blc.Floor43
