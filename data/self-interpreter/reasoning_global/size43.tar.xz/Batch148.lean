import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2254522330970 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2254522330970 : Closed e2254522330970 ∧ code e2254522330970 = 11050615353178 := by decide
theorem cert_e2254522330970 : check e2254522330970 [[]] .sourceHead = true := by decide
def e2254522330986 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2254522330986 : Closed e2254522330986 ∧ code e2254522330986 = 11050615353194 := by decide
theorem cert_e2254522330986 : check e2254522330986 [[]] .sourceHead = true := by decide
def e2254522332014 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2254522332014 : Closed e2254522332014 ∧ code e2254522332014 = 11050615354222 := by decide
theorem cert_e2254522332014 : check e2254522332014 [[]] .sourceHead = true := by decide
def e2254522332022 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2254522332022 : Closed e2254522332022 ∧ code e2254522332022 = 11050615354230 := by decide
theorem cert_e2254522332022 : check e2254522332022 [[]] .sourceHead = true := by decide
def e2254522332078 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2254522332078 : Closed e2254522332078 ∧ code e2254522332078 = 11050615354286 := by decide
theorem cert_e2254522332078 : check e2254522332078 [[]] .sourceHead = true := by decide
def e2254522332090 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2254522332090 : Closed e2254522332090 ∧ code e2254522332090 = 11050615354298 := by decide
theorem cert_e2254522332090 : check e2254522332090 [[]] .sourceHead = true := by decide
def e2254522332118 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2254522332118 : Closed e2254522332118 ∧ code e2254522332118 = 11050615354326 := by decide
theorem cert_e2254522332118 : check e2254522332118 [[]] .sourceHead = true := by decide
def e2254522332122 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2254522332122 : Closed e2254522332122 ∧ code e2254522332122 = 11050615354330 := by decide
theorem cert_e2254522332122 : check e2254522332122 [[]] .sourceHead = true := by decide
def e2254522332398 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2254522332398 : Closed e2254522332398 ∧ code e2254522332398 = 11050615354606 := by decide
theorem cert_e2254522332398 : check e2254522332398 [[]] .sourceHead = true := by decide
def e2254522332406 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2254522332406 : Closed e2254522332406 ∧ code e2254522332406 = 11050615354614 := by decide
theorem cert_e2254522332406 : check e2254522332406 [[]] .sourceHead = true := by decide
def e2254522332782 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2254522332782 : Closed e2254522332782 ∧ code e2254522332782 = 11050615354990 := by decide
theorem cert_e2254522332782 : check e2254522332782 [[]] .sourceHead = true := by decide
def e2254522332794 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2254522332794 : Closed e2254522332794 ∧ code e2254522332794 = 11050615355002 := by decide
theorem cert_e2254522332794 : check e2254522332794 [[]] .sourceHead = true := by decide
def e2254522332982 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2254522332982 : Closed e2254522332982 ∧ code e2254522332982 = 11050615355190 := by decide
theorem cert_e2254522332982 : check e2254522332982 [[]] .sourceHead = true := by decide
def e2254522332986 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2254522332986 : Closed e2254522332986 ∧ code e2254522332986 = 11050615355194 := by decide
theorem cert_e2254522332986 : check e2254522332986 [[]] .sourceHead = true := by decide
def e2254522333614 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2254522333614 : Closed e2254522333614 ∧ code e2254522333614 = 11050615355822 := by decide
theorem cert_e2254522333614 : check e2254522333614 [[]] .sourceHead = true := by decide
def e2254522333626 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2254522333626 : Closed e2254522333626 ∧ code e2254522333626 = 11050615355834 := by decide
theorem cert_e2254522333626 : check e2254522333626 [[]] .sourceHead = true := by decide
def e2254522333674 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2254522333674 : Closed e2254522333674 ∧ code e2254522333674 = 11050615355882 := by decide
theorem cert_e2254522333674 : check e2254522333674 [[]] .sourceHead = true := by decide
def e2254522333806 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2254522333806 : Closed e2254522333806 ∧ code e2254522333806 = 11050615356014 := by decide
theorem cert_e2254522333806 : check e2254522333806 [[]] .sourceHead = true := by decide
def e2254522333818 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2254522333818 : Closed e2254522333818 ∧ code e2254522333818 = 11050615356026 := by decide
theorem cert_e2254522333818 : check e2254522333818 [[]] .sourceHead = true := by decide
def e2254522334106 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2254522334106 : Closed e2254522334106 ∧ code e2254522334106 = 11050615356314 := by decide
theorem cert_e2254522334106 : check e2254522334106 [[]] .sourceHead = true := by decide
def e2254522334422 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2254522334422 : Closed e2254522334422 ∧ code e2254522334422 = 11050615356630 := by decide
theorem cert_e2254522334422 : check e2254522334422 [[]] .sourceHead = true := by decide
def e2254522334426 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2254522334426 : Closed e2254522334426 ∧ code e2254522334426 = 11050615356634 := by decide
theorem cert_e2254522334426 : check e2254522334426 [[]] .sourceHead = true := by decide
def e2254522334442 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2254522334442 : Closed e2254522334442 ∧ code e2254522334442 = 11050615356650 := by decide
theorem cert_e2254522334442 : check e2254522334442 [[]] .sourceHead = true := by decide
def e2254522334518 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2254522334518 : Closed e2254522334518 ∧ code e2254522334518 = 11050615356726 := by decide
theorem cert_e2254522334518 : check e2254522334518 [[]] .sourceHead = true := by decide
def e2254522334522 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2254522334522 : Closed e2254522334522 ∧ code e2254522334522 = 11050615356730 := by decide
theorem cert_e2254522334522 : check e2254522334522 [[]] .sourceHead = true := by decide
def e2254522334618 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2254522334618 : Closed e2254522334618 ∧ code e2254522334618 = 11050615356826 := by decide
theorem cert_e2254522334618 : check e2254522334618 [[]] .sourceHead = true := by decide
def e2254522338158 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2254522338158 : Closed e2254522338158 ∧ code e2254522338158 = 11050615360366 := by decide
theorem cert_e2254522338158 : check e2254522338158 [[]] .sourceHead = true := by decide
def e2254522338166 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2254522338166 : Closed e2254522338166 ∧ code e2254522338166 = 11050615360374 := by decide
theorem cert_e2254522338166 : check e2254522338166 [[]] .sourceHead = true := by decide
def e2254522338222 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2254522338222 : Closed e2254522338222 ∧ code e2254522338222 = 11050615360430 := by decide
theorem cert_e2254522338222 : check e2254522338222 [[]] .sourceHead = true := by decide
def e2254522338234 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2254522338234 : Closed e2254522338234 ∧ code e2254522338234 = 11050615360442 := by decide
theorem cert_e2254522338234 : check e2254522338234 [[]] .sourceHead = true := by decide
def e2254522338262 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2254522338262 : Closed e2254522338262 ∧ code e2254522338262 = 11050615360470 := by decide
theorem cert_e2254522338262 : check e2254522338262 [[]] .sourceHead = true := by decide
def e2254522338266 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2254522338266 : Closed e2254522338266 ∧ code e2254522338266 = 11050615360474 := by decide
theorem cert_e2254522338266 : check e2254522338266 [[]] .sourceHead = true := by decide
def e2254522338542 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2254522338542 : Closed e2254522338542 ∧ code e2254522338542 = 11050615360750 := by decide
theorem cert_e2254522338542 : check e2254522338542 [[]] .sourceHead = true := by decide
def e2254522338550 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2254522338550 : Closed e2254522338550 ∧ code e2254522338550 = 11050615360758 := by decide
theorem cert_e2254522338550 : check e2254522338550 [[]] .sourceHead = true := by decide
def e2254522338926 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2254522338926 : Closed e2254522338926 ∧ code e2254522338926 = 11050615361134 := by decide
theorem cert_e2254522338926 : check e2254522338926 [[]] .sourceHead = true := by decide
def e2254522338938 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2254522338938 : Closed e2254522338938 ∧ code e2254522338938 = 11050615361146 := by decide
theorem cert_e2254522338938 : check e2254522338938 [[]] .sourceHead = true := by decide
def e2254522339126 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2254522339126 : Closed e2254522339126 ∧ code e2254522339126 = 11050615361334 := by decide
theorem cert_e2254522339126 : check e2254522339126 [[]] .sourceHead = true := by decide
def e2254522339130 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2254522339130 : Closed e2254522339130 ∧ code e2254522339130 = 11050615361338 := by decide
theorem cert_e2254522339130 : check e2254522339130 [[]] .sourceHead = true := by decide
def e2254522344878 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2254522344878 : Closed e2254522344878 ∧ code e2254522344878 = 11050615367086 := by decide
theorem cert_e2254522344878 : check e2254522344878 [[]] .sourceHead = true := by decide
def e2254522344890 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2254522344890 : Closed e2254522344890 ∧ code e2254522344890 = 11050615367098 := by decide
theorem cert_e2254522344890 : check e2254522344890 [[]] .sourceHead = true := by decide
def e2254522344938 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2254522344938 : Closed e2254522344938 ∧ code e2254522344938 = 11050615367146 := by decide
theorem cert_e2254522344938 : check e2254522344938 [[]] .sourceHead = true := by decide
def e2254522345070 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2254522345070 : Closed e2254522345070 ∧ code e2254522345070 = 11050615367278 := by decide
theorem cert_e2254522345070 : check e2254522345070 [[]] .sourceHead = true := by decide
def e2254522345082 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2254522345082 : Closed e2254522345082 ∧ code e2254522345082 = 11050615367290 := by decide
theorem cert_e2254522345082 : check e2254522345082 [[]] .sourceHead = true := by decide
def e2254522345370 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2254522345370 : Closed e2254522345370 ∧ code e2254522345370 = 11050615367578 := by decide
theorem cert_e2254522345370 : check e2254522345370 [[]] .sourceHead = true := by decide
def e2254522348246 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2254522348246 : Closed e2254522348246 ∧ code e2254522348246 = 11050615370454 := by decide
theorem cert_e2254522348246 : check e2254522348246 [[]] .sourceHead = true := by decide
def e2254522348250 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2254522348250 : Closed e2254522348250 ∧ code e2254522348250 = 11050615370458 := by decide
theorem cert_e2254522348250 : check e2254522348250 [[]] .sourceHead = true := by decide
def e2254522348266 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2254522348266 : Closed e2254522348266 ∧ code e2254522348266 = 11050615370474 := by decide
theorem cert_e2254522348266 : check e2254522348266 [[]] .sourceHead = true := by decide
def e2254522348342 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2254522348342 : Closed e2254522348342 ∧ code e2254522348342 = 11050615370550 := by decide
theorem cert_e2254522348342 : check e2254522348342 [[]] .sourceHead = true := by decide
def e2254522348346 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2254522348346 : Closed e2254522348346 ∧ code e2254522348346 = 11050615370554 := by decide
theorem cert_e2254522348346 : check e2254522348346 [[]] .sourceHead = true := by decide
def e2254522348442 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2254522348442 : Closed e2254522348442 ∧ code e2254522348442 = 11050615370650 := by decide
theorem cert_e2254522348442 : check e2254522348442 [[]] .sourceHead = true := by decide
def e2254522463982 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2254522463982 : Closed e2254522463982 ∧ code e2254522463982 = 11050615486190 := by decide
theorem cert_e2254522463982 : check e2254522463982 [[]] .sourceHead = true := by decide
def e2254522464110 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2254522464110 : Closed e2254522464110 ∧ code e2254522464110 = 11050615486318 := by decide
theorem cert_e2254522464110 : check e2254522464110 [[]] .sourceHead = true := by decide
def e2254522464118 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2254522464118 : Closed e2254522464118 ∧ code e2254522464118 = 11050615486326 := by decide
theorem cert_e2254522464118 : check e2254522464118 [[]] .sourceHead = true := by decide
def e2254522465006 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2254522465006 : Closed e2254522465006 ∧ code e2254522465006 = 11050615487214 := by decide
theorem cert_e2254522465006 : check e2254522465006 [[]] .sourceHead = true := by decide
def e2254522465198 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2254522465198 : Closed e2254522465198 ∧ code e2254522465198 = 11050615487406 := by decide
theorem cert_e2254522465198 : check e2254522465198 [[]] .sourceHead = true := by decide
def e2254522465210 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2254522465210 : Closed e2254522465210 ∧ code e2254522465210 = 11050615487418 := by decide
theorem cert_e2254522465210 : check e2254522465210 [[]] .sourceHead = true := by decide
def e2254522465646 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2254522465646 : Closed e2254522465646 ∧ code e2254522465646 = 11050615487854 := by decide
theorem cert_e2254522465646 : check e2254522465646 [[]] .sourceHead = true := by decide
def e2254522465654 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2254522465654 : Closed e2254522465654 ∧ code e2254522465654 = 11050615487862 := by decide
theorem cert_e2254522465654 : check e2254522465654 [[]] .sourceHead = true := by decide
def e2254522465710 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2254522465710 : Closed e2254522465710 ∧ code e2254522465710 = 11050615487918 := by decide
theorem cert_e2254522465710 : check e2254522465710 [[]] .sourceHead = true := by decide
def e2254522465722 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2254522465722 : Closed e2254522465722 ∧ code e2254522465722 = 11050615487930 := by decide
theorem cert_e2254522465722 : check e2254522465722 [[]] .sourceHead = true := by decide
def e2254522465750 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2254522465750 : Closed e2254522465750 ∧ code e2254522465750 = 11050615487958 := by decide
theorem cert_e2254522465750 : check e2254522465750 [[]] .sourceHead = true := by decide
def e2254522465754 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2254522465754 : Closed e2254522465754 ∧ code e2254522465754 = 11050615487962 := by decide
theorem cert_e2254522465754 : check e2254522465754 [[]] .sourceHead = true := by decide
def e2254522470126 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2254522470126 : Closed e2254522470126 ∧ code e2254522470126 = 11050615492334 := by decide
theorem cert_e2254522470126 : check e2254522470126 [[]] .sourceHead = true := by decide
def e2254522470254 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2254522470254 : Closed e2254522470254 ∧ code e2254522470254 = 11050615492462 := by decide
theorem cert_e2254522470254 : check e2254522470254 [[]] .sourceHead = true := by decide
def e2254522470262 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2254522470262 : Closed e2254522470262 ∧ code e2254522470262 = 11050615492470 := by decide
theorem cert_e2254522470262 : check e2254522470262 [[]] .sourceHead = true := by decide
def e2254522472942 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2254522472942 : Closed e2254522472942 ∧ code e2254522472942 = 11050615495150 := by decide
theorem cert_e2254522472942 : check e2254522472942 [[]] .sourceHead = true := by decide
def e2254522473710 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2254522473710 : Closed e2254522473710 ∧ code e2254522473710 = 11050615495918 := by decide
theorem cert_e2254522473710 : check e2254522473710 [[]] .sourceHead = true := by decide
def e2254522473718 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2254522473718 : Closed e2254522473718 ∧ code e2254522473718 = 11050615495926 := by decide
theorem cert_e2254522473718 : check e2254522473718 [[]] .sourceHead = true := by decide
def e2254522476270 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2254522476270 : Closed e2254522476270 ∧ code e2254522476270 = 11050615498478 := by decide
theorem cert_e2254522476270 : check e2254522476270 [[]] .sourceHead = true := by decide
def e2254522476462 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2254522476462 : Closed e2254522476462 ∧ code e2254522476462 = 11050615498670 := by decide
theorem cert_e2254522476462 : check e2254522476462 [[]] .sourceHead = true := by decide
def e2254522476474 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2254522476474 : Closed e2254522476474 ∧ code e2254522476474 = 11050615498682 := by decide
theorem cert_e2254522476474 : check e2254522476474 [[]] .sourceHead = true := by decide
def e2254522477038 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2254522477038 : Closed e2254522477038 ∧ code e2254522477038 = 11050615499246 := by decide
theorem cert_e2254522477038 : check e2254522477038 [[]] .sourceHead = true := by decide
def e2254522478190 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2254522478190 : Closed e2254522478190 ∧ code e2254522478190 = 11050615500398 := by decide
theorem cert_e2254522478190 : check e2254522478190 [[]] .sourceHead = true := by decide
def e2254522478202 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2254522478202 : Closed e2254522478202 ∧ code e2254522478202 = 11050615500410 := by decide
theorem cert_e2254522478202 : check e2254522478202 [[]] .sourceHead = true := by decide
def e2254522479470 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2254522479470 : Closed e2254522479470 ∧ code e2254522479470 = 11050615501678 := by decide
theorem cert_e2254522479470 : check e2254522479470 [[]] .sourceHead = true := by decide
def e2254522479478 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2254522479478 : Closed e2254522479478 ∧ code e2254522479478 = 11050615501686 := by decide
theorem cert_e2254522479478 : check e2254522479478 [[]] .sourceHead = true := by decide
def e2254522479534 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2254522479534 : Closed e2254522479534 ∧ code e2254522479534 = 11050615501742 := by decide
theorem cert_e2254522479534 : check e2254522479534 [[]] .sourceHead = true := by decide
def e2254522479546 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2254522479546 : Closed e2254522479546 ∧ code e2254522479546 = 11050615501754 := by decide
theorem cert_e2254522479546 : check e2254522479546 [[]] .sourceHead = true := by decide
def e2254522479574 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2254522479574 : Closed e2254522479574 ∧ code e2254522479574 = 11050615501782 := by decide
theorem cert_e2254522479574 : check e2254522479574 [[]] .sourceHead = true := by decide
def e2254522479578 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2254522479578 : Closed e2254522479578 ∧ code e2254522479578 = 11050615501786 := by decide
theorem cert_e2254522479578 : check e2254522479578 [[]] .sourceHead = true := by decide
def e2254522479854 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2254522479854 : Closed e2254522479854 ∧ code e2254522479854 = 11050615502062 := by decide
theorem cert_e2254522479854 : check e2254522479854 [[]] .sourceHead = true := by decide
def e2254522479862 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2254522479862 : Closed e2254522479862 ∧ code e2254522479862 = 11050615502070 := by decide
theorem cert_e2254522479862 : check e2254522479862 [[]] .sourceHead = true := by decide
def e2254522480238 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2254522480238 : Closed e2254522480238 ∧ code e2254522480238 = 11050615502446 := by decide
theorem cert_e2254522480238 : check e2254522480238 [[]] .sourceHead = true := by decide
def e2254522480250 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2254522480250 : Closed e2254522480250 ∧ code e2254522480250 = 11050615502458 := by decide
theorem cert_e2254522480250 : check e2254522480250 [[]] .sourceHead = true := by decide
def e2254522480438 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2254522480438 : Closed e2254522480438 ∧ code e2254522480438 = 11050615502646 := by decide
theorem cert_e2254522480438 : check e2254522480438 [[]] .sourceHead = true := by decide
def e2254522480442 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2254522480442 : Closed e2254522480442 ∧ code e2254522480442 = 11050615502650 := by decide
theorem cert_e2254522480442 : check e2254522480442 [[]] .sourceHead = true := by decide
def e2254522485614 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2254522485614 : Closed e2254522485614 ∧ code e2254522485614 = 11050615507822 := by decide
theorem cert_e2254522485614 : check e2254522485614 [[]] .sourceHead = true := by decide
def e2254522485622 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2254522485622 : Closed e2254522485622 ∧ code e2254522485622 = 11050615507830 := by decide
theorem cert_e2254522485622 : check e2254522485622 [[]] .sourceHead = true := by decide
def e2254522485678 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2254522485678 : Closed e2254522485678 ∧ code e2254522485678 = 11050615507886 := by decide
theorem cert_e2254522485678 : check e2254522485678 [[]] .sourceHead = true := by decide
def e2254522485690 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2254522485690 : Closed e2254522485690 ∧ code e2254522485690 = 11050615507898 := by decide
theorem cert_e2254522485690 : check e2254522485690 [[]] .sourceHead = true := by decide
def e2254522485718 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2254522485718 : Closed e2254522485718 ∧ code e2254522485718 = 11050615507926 := by decide
theorem cert_e2254522485718 : check e2254522485718 [[]] .sourceHead = true := by decide
def e2254522485722 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2254522485722 : Closed e2254522485722 ∧ code e2254522485722 = 11050615507930 := by decide
theorem cert_e2254522485722 : check e2254522485722 [[]] .sourceHead = true := by decide
def e2254522485998 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2254522485998 : Closed e2254522485998 ∧ code e2254522485998 = 11050615508206 := by decide
theorem cert_e2254522485998 : check e2254522485998 [[]] .sourceHead = true := by decide
def e2254522486006 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2254522486006 : Closed e2254522486006 ∧ code e2254522486006 = 11050615508214 := by decide
theorem cert_e2254522486006 : check e2254522486006 [[]] .sourceHead = true := by decide
def e2254522486382 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2254522486382 : Closed e2254522486382 ∧ code e2254522486382 = 11050615508590 := by decide
theorem cert_e2254522486382 : check e2254522486382 [[]] .sourceHead = true := by decide
def e2254522486394 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2254522486394 : Closed e2254522486394 ∧ code e2254522486394 = 11050615508602 := by decide
theorem cert_e2254522486394 : check e2254522486394 [[]] .sourceHead = true := by decide
def e2254522486582 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2254522486582 : Closed e2254522486582 ∧ code e2254522486582 = 11050615508790 := by decide
theorem cert_e2254522486582 : check e2254522486582 [[]] .sourceHead = true := by decide
def e2254522486586 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2254522486586 : Closed e2254522486586 ∧ code e2254522486586 = 11050615508794 := by decide
theorem cert_e2254522486586 : check e2254522486586 [[]] .sourceHead = true := by decide
def e2254522494702 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2254522494702 : Closed e2254522494702 ∧ code e2254522494702 = 11050615516910 := by decide
theorem cert_e2254522494702 : check e2254522494702 [[]] .sourceHead = true := by decide
def e2254522494830 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2254522494830 : Closed e2254522494830 ∧ code e2254522494830 = 11050615517038 := by decide
theorem cert_e2254522494830 : check e2254522494830 [[]] .sourceHead = true := by decide
def e2254522494838 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2254522494838 : Closed e2254522494838 ∧ code e2254522494838 = 11050615517046 := by decide
theorem cert_e2254522494838 : check e2254522494838 [[]] .sourceHead = true := by decide
def e2254522497518 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2254522497518 : Closed e2254522497518 ∧ code e2254522497518 = 11050615519726 := by decide
theorem cert_e2254522497518 : check e2254522497518 [[]] .sourceHead = true := by decide
def e2254522498286 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2254522498286 : Closed e2254522498286 ∧ code e2254522498286 = 11050615520494 := by decide
theorem cert_e2254522498286 : check e2254522498286 [[]] .sourceHead = true := by decide
def e2254522498294 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2254522498294 : Closed e2254522498294 ∧ code e2254522498294 = 11050615520502 := by decide
theorem cert_e2254522498294 : check e2254522498294 [[]] .sourceHead = true := by decide
def e2254522521326 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2254522521326 : Closed e2254522521326 ∧ code e2254522521326 = 11050615543534 := by decide
theorem cert_e2254522521326 : check e2254522521326 [[]] .sourceHead = true := by decide
def e2254522521518 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2254522521518 : Closed e2254522521518 ∧ code e2254522521518 = 11050615543726 := by decide
theorem cert_e2254522521518 : check e2254522521518 [[]] .sourceHead = true := by decide
def e2254522521530 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2254522521530 : Closed e2254522521530 ∧ code e2254522521530 = 11050615543738 := by decide
theorem cert_e2254522521530 : check e2254522521530 [[]] .sourceHead = true := by decide
def e2254522522094 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2254522522094 : Closed e2254522522094 ∧ code e2254522522094 = 11050615544302 := by decide
theorem cert_e2254522522094 : check e2254522522094 [[]] .sourceHead = true := by decide
def e2254522523246 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2254522523246 : Closed e2254522523246 ∧ code e2254522523246 = 11050615545454 := by decide
theorem cert_e2254522523246 : check e2254522523246 [[]] .sourceHead = true := by decide
def e2254522523258 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2254522523258 : Closed e2254522523258 ∧ code e2254522523258 = 11050615545466 := by decide
theorem cert_e2254522523258 : check e2254522523258 [[]] .sourceHead = true := by decide
def e2254522534766 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2254522534766 : Closed e2254522534766 ∧ code e2254522534766 = 11050615556974 := by decide
theorem cert_e2254522534766 : check e2254522534766 [[]] .sourceHead = true := by decide
def e2254522534774 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2254522534774 : Closed e2254522534774 ∧ code e2254522534774 = 11050615556982 := by decide
theorem cert_e2254522534774 : check e2254522534774 [[]] .sourceHead = true := by decide
def e2254522534830 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2254522534830 : Closed e2254522534830 ∧ code e2254522534830 = 11050615557038 := by decide
theorem cert_e2254522534830 : check e2254522534830 [[]] .sourceHead = true := by decide
def e2254522534842 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2254522534842 : Closed e2254522534842 ∧ code e2254522534842 = 11050615557050 := by decide
theorem cert_e2254522534842 : check e2254522534842 [[]] .sourceHead = true := by decide
def e2254522534870 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2254522534870 : Closed e2254522534870 ∧ code e2254522534870 = 11050615557078 := by decide
theorem cert_e2254522534870 : check e2254522534870 [[]] .sourceHead = true := by decide
def e2254522534874 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2254522534874 : Closed e2254522534874 ∧ code e2254522534874 = 11050615557082 := by decide
theorem cert_e2254522534874 : check e2254522534874 [[]] .sourceHead = true := by decide
def e2254522535150 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2254522535150 : Closed e2254522535150 ∧ code e2254522535150 = 11050615557358 := by decide
theorem cert_e2254522535150 : check e2254522535150 [[]] .sourceHead = true := by decide
def e2254522535158 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2254522535158 : Closed e2254522535158 ∧ code e2254522535158 = 11050615557366 := by decide
theorem cert_e2254522535158 : check e2254522535158 [[]] .sourceHead = true := by decide
def e2254522535534 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2254522535534 : Closed e2254522535534 ∧ code e2254522535534 = 11050615557742 := by decide
theorem cert_e2254522535534 : check e2254522535534 [[]] .sourceHead = true := by decide
def e2254522535546 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2254522535546 : Closed e2254522535546 ∧ code e2254522535546 = 11050615557754 := by decide
theorem cert_e2254522535546 : check e2254522535546 [[]] .sourceHead = true := by decide
def e2254522535734 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2254522535734 : Closed e2254522535734 ∧ code e2254522535734 = 11050615557942 := by decide
theorem cert_e2254522535734 : check e2254522535734 [[]] .sourceHead = true := by decide
def e2254522535738 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2254522535738 : Closed e2254522535738 ∧ code e2254522535738 = 11050615557946 := by decide
theorem cert_e2254522535738 : check e2254522535738 [[]] .sourceHead = true := by decide
def e2254523075438 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2254523075438 : Closed e2254523075438 ∧ code e2254523075438 = 11050616097646 := by decide
theorem cert_e2254523075438 : check e2254523075438 [[]] .sourceHead = true := by decide
def e2254523075446 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2254523075446 : Closed e2254523075446 ∧ code e2254523075446 = 11050616097654 := by decide
theorem cert_e2254523075446 : check e2254523075446 [[]] .sourceHead = true := by decide
def e2254523075502 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2254523075502 : Closed e2254523075502 ∧ code e2254523075502 = 11050616097710 := by decide
theorem cert_e2254523075502 : check e2254523075502 [[]] .sourceHead = true := by decide
def e2254523075514 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2254523075514 : Closed e2254523075514 ∧ code e2254523075514 = 11050616097722 := by decide
theorem cert_e2254523075514 : check e2254523075514 [[]] .sourceHead = true := by decide
def e2254523075542 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2254523075542 : Closed e2254523075542 ∧ code e2254523075542 = 11050616097750 := by decide
theorem cert_e2254523075542 : check e2254523075542 [[]] .sourceHead = true := by decide
def e2254523075546 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2254523075546 : Closed e2254523075546 ∧ code e2254523075546 = 11050616097754 := by decide
theorem cert_e2254523075546 : check e2254523075546 [[]] .sourceHead = true := by decide
def e2254523075822 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2254523075822 : Closed e2254523075822 ∧ code e2254523075822 = 11050616098030 := by decide
theorem cert_e2254523075822 : check e2254523075822 [[]] .sourceHead = true := by decide
def e2254523075830 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2254523075830 : Closed e2254523075830 ∧ code e2254523075830 = 11050616098038 := by decide
theorem cert_e2254523075830 : check e2254523075830 [[]] .sourceHead = true := by decide
def e2254523076206 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2254523076206 : Closed e2254523076206 ∧ code e2254523076206 = 11050616098414 := by decide
theorem cert_e2254523076206 : check e2254523076206 [[]] .sourceHead = true := by decide
def e2254523076218 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2254523076218 : Closed e2254523076218 ∧ code e2254523076218 = 11050616098426 := by decide
theorem cert_e2254523076218 : check e2254523076218 [[]] .sourceHead = true := by decide
def e2254523076406 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2254523076406 : Closed e2254523076406 ∧ code e2254523076406 = 11050616098614 := by decide
theorem cert_e2254523076406 : check e2254523076406 [[]] .sourceHead = true := by decide
def e2254523076410 : Term := (.app (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2254523076410 : Closed e2254523076410 ∧ code e2254523076410 = 11050616098618 := by decide
theorem cert_e2254523076410 : check e2254523076410 [[]] .sourceHead = true := by decide
def e2259248709658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259248709658 : Closed e2259248709658 ∧ code e2259248709658 = 11055341731866 := by decide
theorem cert_e2259248709658 : check e2259248709658 [[]] .width = true := by decide
def e2259248709750 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259248709750 : Closed e2259248709750 ∧ code e2259248709750 = 11055341731958 := by decide
theorem cert_e2259248709750 : check e2259248709750 [[]] .width = true := by decide
def e2259248709994 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259248709994 : Closed e2259248709994 ∧ code e2259248709994 = 11055341732202 := by decide
theorem cert_e2259248709994 : check e2259248709994 [[]] .width = true := by decide
def e2259248710042 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259248710042 : Closed e2259248710042 ∧ code e2259248710042 = 11055341732250 := by decide
theorem cert_e2259248710042 : check e2259248710042 [[]] .width = true := by decide
def e2259248711050 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259248711050 : Closed e2259248711050 ∧ code e2259248711050 = 11055341733258 := by decide
theorem cert_e2259248711050 : check e2259248711050 [[]] .width = true := by decide
def e2259248711074 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259248711074 : Closed e2259248711074 ∧ code e2259248711074 = 11055341733282 := by decide
theorem cert_e2259248711074 : check e2259248711074 [[]] .width = true := by decide
def e2259248711182 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259248711182 : Closed e2259248711182 ∧ code e2259248711182 = 11055341733390 := by decide
theorem cert_e2259248711182 : check e2259248711182 [[]] .width = true := by decide
def e2259248711194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259248711194 : Closed e2259248711194 ∧ code e2259248711194 = 11055341733402 := by decide
theorem cert_e2259248711194 : check e2259248711194 [[]] .width = true := by decide
def e2259248711266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259248711266 : Closed e2259248711266 ∧ code e2259248711266 = 11055341733474 := by decide
theorem cert_e2259248711266 : check e2259248711266 [[]] .width = true := by decide
def e2259248988358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259248988358 : Closed e2259248988358 ∧ code e2259248988358 = 11055342010566 := by decide
theorem cert_e2259248988358 : check e2259248988358 [[]] .width = true := by decide
def e2259249102874 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259249102874 : Closed e2259249102874 ∧ code e2259249102874 = 11055342125082 := by decide
theorem cert_e2259249102874 : check e2259249102874 [[]] .width = true := by decide
def e2259249102966 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259249102966 : Closed e2259249102966 ∧ code e2259249102966 = 11055342125174 := by decide
theorem cert_e2259249102966 : check e2259249102966 [[]] .width = true := by decide
def e2259249103210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259249103210 : Closed e2259249103210 ∧ code e2259249103210 = 11055342125418 := by decide
theorem cert_e2259249103210 : check e2259249103210 [[]] .width = true := by decide
def e2259249103258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259249103258 : Closed e2259249103258 ∧ code e2259249103258 = 11055342125466 := by decide
theorem cert_e2259249103258 : check e2259249103258 [[]] .width = true := by decide
def e2259249104266 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259249104266 : Closed e2259249104266 ∧ code e2259249104266 = 11055342126474 := by decide
theorem cert_e2259249104266 : check e2259249104266 [[]] .width = true := by decide
def e2259249104290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259249104290 : Closed e2259249104290 ∧ code e2259249104290 = 11055342126498 := by decide
theorem cert_e2259249104290 : check e2259249104290 [[]] .width = true := by decide
def e2259249104398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259249104398 : Closed e2259249104398 ∧ code e2259249104398 = 11055342126606 := by decide
theorem cert_e2259249104398 : check e2259249104398 [[]] .width = true := by decide
def e2259249104410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259249104410 : Closed e2259249104410 ∧ code e2259249104410 = 11055342126618 := by decide
theorem cert_e2259249104410 : check e2259249104410 [[]] .width = true := by decide
def e2259249104482 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259249104482 : Closed e2259249104482 ∧ code e2259249104482 = 11055342126690 := by decide
theorem cert_e2259249104482 : check e2259249104482 [[]] .width = true := by decide
def e2259249119430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259249119430 : Closed e2259249119430 ∧ code e2259249119430 = 11055342141638 := by decide
theorem cert_e2259249119430 : check e2259249119430 [[]] .width = true := by decide
def e2259250806810 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259250806810 : Closed e2259250806810 ∧ code e2259250806810 = 11055343829018 := by decide
theorem cert_e2259250806810 : check e2259250806810 [[]] .width = true := by decide
def e2259250806902 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259250806902 : Closed e2259250806902 ∧ code e2259250806902 = 11055343829110 := by decide
theorem cert_e2259250806902 : check e2259250806902 [[]] .width = true := by decide
def e2259250807146 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259250807146 : Closed e2259250807146 ∧ code e2259250807146 = 11055343829354 := by decide
theorem cert_e2259250807146 : check e2259250807146 [[]] .width = true := by decide
def e2259250807194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259250807194 : Closed e2259250807194 ∧ code e2259250807194 = 11055343829402 := by decide
theorem cert_e2259250807194 : check e2259250807194 [[]] .width = true := by decide
def e2259250808202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259250808202 : Closed e2259250808202 ∧ code e2259250808202 = 11055343830410 := by decide
theorem cert_e2259250808202 : check e2259250808202 [[]] .width = true := by decide
def e2259250808226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259250808226 : Closed e2259250808226 ∧ code e2259250808226 = 11055343830434 := by decide
theorem cert_e2259250808226 : check e2259250808226 [[]] .width = true := by decide
end Blc.Floor43
