import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374846294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422374846294 : Closed e2422374846294 ∧ code e2422374846294 = 11218467868502 := by decide
theorem cert_e2422374846294 : check e2422374846294 [[],[]] .smaller = true := by decide
def e2422374846298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422374846298 : Closed e2422374846298 ∧ code e2422374846298 = 11218467868506 := by decide
theorem cert_e2422374846298 : check e2422374846298 [[],[]] .smaller = true := by decide
def e2422374846314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422374846314 : Closed e2422374846314 ∧ code e2422374846314 = 11218467868522 := by decide
theorem cert_e2422374846314 : check e2422374846314 [[],[]] .smaller = true := by decide
def e2422374846942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2422374846942 : Closed e2422374846942 ∧ code e2422374846942 = 11218467869150 := by decide
theorem cert_e2422374846942 : check e2422374846942 [[],[]] .three = true := by decide
def e2422374846966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2422374846966 : Closed e2422374846966 ∧ code e2422374846966 = 11218467869174 := by decide
theorem cert_e2422374846966 : check e2422374846966 [[],[]] .three = true := by decide
def e2422374847342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2422374847342 : Closed e2422374847342 ∧ code e2422374847342 = 11218467869550 := by decide
theorem cert_e2422374847342 : check e2422374847342 [[],[]] .smaller = true := by decide
def e2422374847350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2422374847350 : Closed e2422374847350 ∧ code e2422374847350 = 11218467869558 := by decide
theorem cert_e2422374847350 : check e2422374847350 [[],[]] .smaller = true := by decide
def e2422374847406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2422374847406 : Closed e2422374847406 ∧ code e2422374847406 = 11218467869614 := by decide
theorem cert_e2422374847406 : check e2422374847406 [[],[]] .smaller = true := by decide
def e2422374847418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2422374847418 : Closed e2422374847418 ∧ code e2422374847418 = 11218467869626 := by decide
theorem cert_e2422374847418 : check e2422374847418 [[],[]] .smaller = true := by decide
def e2422374847446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2422374847446 : Closed e2422374847446 ∧ code e2422374847446 = 11218467869654 := by decide
theorem cert_e2422374847446 : check e2422374847446 [[],[]] .smaller = true := by decide
def e2422374847450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2422374847450 : Closed e2422374847450 ∧ code e2422374847450 = 11218467869658 := by decide
theorem cert_e2422374847450 : check e2422374847450 [[],[]] .smaller = true := by decide
def e2422374847726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374847726 : Closed e2422374847726 ∧ code e2422374847726 = 11218467869934 := by decide
theorem cert_e2422374847726 : check e2422374847726 [[],[]] .smaller = true := by decide
def e2422374847734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374847734 : Closed e2422374847734 ∧ code e2422374847734 = 11218467869942 := by decide
theorem cert_e2422374847734 : check e2422374847734 [[],[]] .smaller = true := by decide
def e2422374848062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2422374848062 : Closed e2422374848062 ∧ code e2422374848062 = 11218467870270 := by decide
theorem cert_e2422374848062 : check e2422374848062 [[],[]] .three = true := by decide
def e2422374848110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374848110 : Closed e2422374848110 ∧ code e2422374848110 = 11218467870318 := by decide
theorem cert_e2422374848110 : check e2422374848110 [[],[]] .smaller = true := by decide
def e2422374848122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374848122 : Closed e2422374848122 ∧ code e2422374848122 = 11218467870330 := by decide
theorem cert_e2422374848122 : check e2422374848122 [[],[]] .smaller = true := by decide
def e2422374848310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374848310 : Closed e2422374848310 ∧ code e2422374848310 = 11218467870518 := by decide
theorem cert_e2422374848310 : check e2422374848310 [[],[]] .smaller = true := by decide
def e2422374848314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374848314 : Closed e2422374848314 ∧ code e2422374848314 = 11218467870522 := by decide
theorem cert_e2422374848314 : check e2422374848314 [[],[]] .smaller = true := by decide
def e2422374848398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2422374848398 : Closed e2422374848398 ∧ code e2422374848398 = 11218467870606 := by decide
theorem cert_e2422374848398 : check e2422374848398 [[],[]] .three = true := by decide
def e2422374848558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422374848558 : Closed e2422374848558 ∧ code e2422374848558 = 11218467870766 := by decide
theorem cert_e2422374848558 : check e2422374848558 [[],[]] .smaller = true := by decide
def e2422374848734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422374848734 : Closed e2422374848734 ∧ code e2422374848734 = 11218467870942 := by decide
theorem cert_e2422374848734 : check e2422374848734 [[],[]] .three = true := by decide
def e2422374848750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422374848750 : Closed e2422374848750 ∧ code e2422374848750 = 11218467870958 := by decide
theorem cert_e2422374848750 : check e2422374848750 [[],[]] .smaller = true := by decide
def e2422374848758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422374848758 : Closed e2422374848758 ∧ code e2422374848758 = 11218467870966 := by decide
theorem cert_e2422374848758 : check e2422374848758 [[],[]] .smaller = true := by decide
def e2422374848762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422374848762 : Closed e2422374848762 ∧ code e2422374848762 = 11218467870970 := by decide
theorem cert_e2422374848762 : check e2422374848762 [[],[]] .three = true := by decide
def e2422374848942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422374848942 : Closed e2422374848942 ∧ code e2422374848942 = 11218467871150 := by decide
theorem cert_e2422374848942 : check e2422374848942 [[],[]] .smaller = true := by decide
def e2422374848954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422374848954 : Closed e2422374848954 ∧ code e2422374848954 = 11218467871162 := by decide
theorem cert_e2422374848954 : check e2422374848954 [[],[]] .smaller = true := by decide
def e2422374849002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422374849002 : Closed e2422374849002 ∧ code e2422374849002 = 11218467871210 := by decide
theorem cert_e2422374849002 : check e2422374849002 [[],[]] .smaller = true := by decide
def e2422374849086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422374849086 : Closed e2422374849086 ∧ code e2422374849086 = 11218467871294 := by decide
theorem cert_e2422374849086 : check e2422374849086 [[],[]] .three = true := by decide
def e2422374849134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374849134 : Closed e2422374849134 ∧ code e2422374849134 = 11218467871342 := by decide
theorem cert_e2422374849134 : check e2422374849134 [[],[]] .smaller = true := by decide
def e2422374849146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374849146 : Closed e2422374849146 ∧ code e2422374849146 = 11218467871354 := by decide
theorem cert_e2422374849146 : check e2422374849146 [[],[]] .smaller = true := by decide
def e2422374849310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422374849310 : Closed e2422374849310 ∧ code e2422374849310 = 11218467871518 := by decide
theorem cert_e2422374849310 : check e2422374849310 [[],[]] .smaller = true := by decide
def e2422374849410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374849410 : Closed e2422374849410 ∧ code e2422374849410 = 11218467871618 := by decide
theorem cert_e2422374849410 : check e2422374849410 [[],[]] .smaller = true := by decide
def e2422374849422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422374849422 : Closed e2422374849422 ∧ code e2422374849422 = 11218467871630 := by decide
theorem cert_e2422374849422 : check e2422374849422 [[],[]] .smaller = true := by decide
def e2422374849434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374849434 : Closed e2422374849434 ∧ code e2422374849434 = 11218467871642 := by decide
theorem cert_e2422374849434 : check e2422374849434 [[],[]] .smaller = true := by decide
def e2422374849478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422374849478 : Closed e2422374849478 ∧ code e2422374849478 = 11218467871686 := by decide
theorem cert_e2422374849478 : check e2422374849478 [[],[]] .three = true := by decide
def e2422374849502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3))))))))
theorem wire_e2422374849502 : Closed e2422374849502 ∧ code e2422374849502 = 11218467871710 := by decide
theorem cert_e2422374849502 : check e2422374849502 [[],[]] .three = true := by decide
def e2422374849558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422374849558 : Closed e2422374849558 ∧ code e2422374849558 = 11218467871766 := by decide
theorem cert_e2422374849558 : check e2422374849558 [[],[]] .smaller = true := by decide
def e2422374849630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422374849630 : Closed e2422374849630 ∧ code e2422374849630 = 11218467871838 := by decide
theorem cert_e2422374849630 : check e2422374849630 [[],[]] .three = true := by decide
def e2422374849654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422374849654 : Closed e2422374849654 ∧ code e2422374849654 = 11218467871862 := by decide
theorem cert_e2422374849654 : check e2422374849654 [[],[]] .smaller = true := by decide
def e2422374849750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422374849750 : Closed e2422374849750 ∧ code e2422374849750 = 11218467871958 := by decide
theorem cert_e2422374849750 : check e2422374849750 [[],[]] .smaller = true := by decide
def e2422374849754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422374849754 : Closed e2422374849754 ∧ code e2422374849754 = 11218467871962 := by decide
theorem cert_e2422374849754 : check e2422374849754 [[],[]] .smaller = true := by decide
def e2422374849770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422374849770 : Closed e2422374849770 ∧ code e2422374849770 = 11218467871978 := by decide
theorem cert_e2422374849770 : check e2422374849770 [[],[]] .smaller = true := by decide
def e2422374849846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374849846 : Closed e2422374849846 ∧ code e2422374849846 = 11218467872054 := by decide
theorem cert_e2422374849846 : check e2422374849846 [[],[]] .smaller = true := by decide
def e2422374849850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374849850 : Closed e2422374849850 ∧ code e2422374849850 = 11218467872058 := by decide
theorem cert_e2422374849850 : check e2422374849850 [[],[]] .smaller = true := by decide
def e2422374849922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374849922 : Closed e2422374849922 ∧ code e2422374849922 = 11218467872130 := by decide
theorem cert_e2422374849922 : check e2422374849922 [[],[]] .smaller = true := by decide
def e2422374849934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422374849934 : Closed e2422374849934 ∧ code e2422374849934 = 11218467872142 := by decide
theorem cert_e2422374849934 : check e2422374849934 [[],[]] .smaller = true := by decide
def e2422374849946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374849946 : Closed e2422374849946 ∧ code e2422374849946 = 11218467872154 := by decide
theorem cert_e2422374849946 : check e2422374849946 [[],[]] .smaller = true := by decide
def e2422374850014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 3))))))))
theorem wire_e2422374850014 : Closed e2422374850014 ∧ code e2422374850014 = 11218467872222 := by decide
theorem cert_e2422374850014 : check e2422374850014 [[],[]] .three = true := by decide
def e2422374850018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422374850018 : Closed e2422374850018 ∧ code e2422374850018 = 11218467872226 := by decide
theorem cert_e2422374850018 : check e2422374850018 [[],[]] .three = true := by decide
def e2422374850030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 2))))))))
theorem wire_e2422374850030 : Closed e2422374850030 ∧ code e2422374850030 = 11218467872238 := by decide
theorem cert_e2422374850030 : check e2422374850030 [[],[]] .three = true := by decide
def e2422374850094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422374850094 : Closed e2422374850094 ∧ code e2422374850094 = 11218467872302 := by decide
theorem cert_e2422374850094 : check e2422374850094 [[],[]] .three = true := by decide
def e2422374850102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422374850102 : Closed e2422374850102 ∧ code e2422374850102 = 11218467872310 := by decide
theorem cert_e2422374850102 : check e2422374850102 [[],[]] .three = true := by decide
def e2422374850106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422374850106 : Closed e2422374850106 ∧ code e2422374850106 = 11218467872314 := by decide
theorem cert_e2422374850106 : check e2422374850106 [[],[]] .three = true := by decide
def e2422374850190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422374850190 : Closed e2422374850190 ∧ code e2422374850190 = 11218467872398 := by decide
theorem cert_e2422374850190 : check e2422374850190 [[],[]] .three = true := by decide
def e2422374850246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422374850246 : Closed e2422374850246 ∧ code e2422374850246 = 11218467872454 := by decide
theorem cert_e2422374850246 : check e2422374850246 [[],[]] .three = true := by decide
def e2422374850270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3))))))))
theorem wire_e2422374850270 : Closed e2422374850270 ∧ code e2422374850270 = 11218467872478 := by decide
theorem cert_e2422374850270 : check e2422374850270 [[],[]] .three = true := by decide
def e2422374850274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422374850274 : Closed e2422374850274 ∧ code e2422374850274 = 11218467872482 := by decide
theorem cert_e2422374850274 : check e2422374850274 [[],[]] .three = true := by decide
def e2422374850286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 2))))))))
theorem wire_e2422374850286 : Closed e2422374850286 ∧ code e2422374850286 = 11218467872494 := by decide
theorem cert_e2422374850286 : check e2422374850286 [[],[]] .three = true := by decide
def e2422374850294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1))))))))
theorem wire_e2422374850294 : Closed e2422374850294 ∧ code e2422374850294 = 11218467872502 := by decide
theorem cert_e2422374850294 : check e2422374850294 [[],[]] .three = true := by decide
def e2422374850734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))))))))
theorem wire_e2422374850734 : Closed e2422374850734 ∧ code e2422374850734 = 11218467872942 := by decide
theorem cert_e2422374850734 : check e2422374850734 [[],[]] .smaller = true := by decide
def e2422374850746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))))))
theorem wire_e2422374850746 : Closed e2422374850746 ∧ code e2422374850746 = 11218467872954 := by decide
theorem cert_e2422374850746 : check e2422374850746 [[],[]] .smaller = true := by decide
def e2422374851294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e2422374851294 : Closed e2422374851294 ∧ code e2422374851294 = 11218467873502 := by decide
theorem cert_e2422374851294 : check e2422374851294 [[],[]] .three = true := by decide
def e2422374851310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 2))))))))
theorem wire_e2422374851310 : Closed e2422374851310 ∧ code e2422374851310 = 11218467873518 := by decide
theorem cert_e2422374851310 : check e2422374851310 [[],[]] .smaller = true := by decide
def e2422374851318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e2422374851318 : Closed e2422374851318 ∧ code e2422374851318 = 11218467873526 := by decide
theorem cert_e2422374851318 : check e2422374851318 [[],[]] .three = true := by decide
def e2422374851422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 3))))))))
theorem wire_e2422374851422 : Closed e2422374851422 ∧ code e2422374851422 = 11218467873630 := by decide
theorem cert_e2422374851422 : check e2422374851422 [[],[]] .three = true := by decide
def e2422374851438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e2422374851438 : Closed e2422374851438 ∧ code e2422374851438 = 11218467873646 := by decide
theorem cert_e2422374851438 : check e2422374851438 [[],[]] .smaller = true := by decide
def e2422374851446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e2422374851446 : Closed e2422374851446 ∧ code e2422374851446 = 11218467873654 := by decide
theorem cert_e2422374851446 : check e2422374851446 [[],[]] .smaller = true := by decide
def e2422374851450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 3)) (.var 0))))))))
theorem wire_e2422374851450 : Closed e2422374851450 ∧ code e2422374851450 = 11218467873658 := by decide
theorem cert_e2422374851450 : check e2422374851450 [[],[]] .three = true := by decide
def e2422374851502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e2422374851502 : Closed e2422374851502 ∧ code e2422374851502 = 11218467873710 := by decide
theorem cert_e2422374851502 : check e2422374851502 [[],[]] .smaller = true := by decide
def e2422374851514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e2422374851514 : Closed e2422374851514 ∧ code e2422374851514 = 11218467873722 := by decide
theorem cert_e2422374851514 : check e2422374851514 [[],[]] .smaller = true := by decide
def e2422374851542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e2422374851542 : Closed e2422374851542 ∧ code e2422374851542 = 11218467873750 := by decide
theorem cert_e2422374851542 : check e2422374851542 [[],[]] .smaller = true := by decide
def e2422374851546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e2422374851546 : Closed e2422374851546 ∧ code e2422374851546 = 11218467873754 := by decide
theorem cert_e2422374851546 : check e2422374851546 [[],[]] .smaller = true := by decide
def e2422374851562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.lam (.var 4))) (.var 0)) (.var 0))))))))
theorem wire_e2422374851562 : Closed e2422374851562 ∧ code e2422374851562 = 11218467873770 := by decide
theorem cert_e2422374851562 : check e2422374851562 [[],[]] .three = true := by decide
def e2422374852270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422374852270 : Closed e2422374852270 ∧ code e2422374852270 = 11218467874478 := by decide
theorem cert_e2422374852270 : check e2422374852270 [[],[]] .smaller = true := by decide
def e2422374852282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422374852282 : Closed e2422374852282 ∧ code e2422374852282 = 11218467874490 := by decide
theorem cert_e2422374852282 : check e2422374852282 [[],[]] .smaller = true := by decide
def e2422374852330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422374852330 : Closed e2422374852330 ∧ code e2422374852330 = 11218467874538 := by decide
theorem cert_e2422374852330 : check e2422374852330 [[],[]] .smaller = true := by decide
def e2422374852522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422374852522 : Closed e2422374852522 ∧ code e2422374852522 = 11218467874730 := by decide
theorem cert_e2422374852522 : check e2422374852522 [[],[]] .smaller = true := by decide
def e2422374852654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422374852654 : Closed e2422374852654 ∧ code e2422374852654 = 11218467874862 := by decide
theorem cert_e2422374852654 : check e2422374852654 [[],[]] .smaller = true := by decide
def e2422374852830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2422374852830 : Closed e2422374852830 ∧ code e2422374852830 = 11218467875038 := by decide
theorem cert_e2422374852830 : check e2422374852830 [[],[]] .three = true := by decide
def e2422374852846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2422374852846 : Closed e2422374852846 ∧ code e2422374852846 = 11218467875054 := by decide
theorem cert_e2422374852846 : check e2422374852846 [[],[]] .smaller = true := by decide
def e2422374852854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2422374852854 : Closed e2422374852854 ∧ code e2422374852854 = 11218467875062 := by decide
theorem cert_e2422374852854 : check e2422374852854 [[],[]] .smaller = true := by decide
def e2422374852858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2422374852858 : Closed e2422374852858 ∧ code e2422374852858 = 11218467875066 := by decide
theorem cert_e2422374852858 : check e2422374852858 [[],[]] .three = true := by decide
def e2422374853038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2422374853038 : Closed e2422374853038 ∧ code e2422374853038 = 11218467875246 := by decide
theorem cert_e2422374853038 : check e2422374853038 [[],[]] .smaller = true := by decide
def e2422374853050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2422374853050 : Closed e2422374853050 ∧ code e2422374853050 = 11218467875258 := by decide
theorem cert_e2422374853050 : check e2422374853050 [[],[]] .smaller = true := by decide
def e2422374853098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2422374853098 : Closed e2422374853098 ∧ code e2422374853098 = 11218467875306 := by decide
theorem cert_e2422374853098 : check e2422374853098 [[],[]] .smaller = true := by decide
def e2422374853182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2422374853182 : Closed e2422374853182 ∧ code e2422374853182 = 11218467875390 := by decide
theorem cert_e2422374853182 : check e2422374853182 [[],[]] .three = true := by decide
def e2422374853230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374853230 : Closed e2422374853230 ∧ code e2422374853230 = 11218467875438 := by decide
theorem cert_e2422374853230 : check e2422374853230 [[],[]] .smaller = true := by decide
def e2422374853242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374853242 : Closed e2422374853242 ∧ code e2422374853242 = 11218467875450 := by decide
theorem cert_e2422374853242 : check e2422374853242 [[],[]] .smaller = true := by decide
def e2422374853406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2422374853406 : Closed e2422374853406 ∧ code e2422374853406 = 11218467875614 := by decide
theorem cert_e2422374853406 : check e2422374853406 [[],[]] .smaller = true := by decide
def e2422374853506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374853506 : Closed e2422374853506 ∧ code e2422374853506 = 11218467875714 := by decide
theorem cert_e2422374853506 : check e2422374853506 [[],[]] .smaller = true := by decide
def e2422374853518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2422374853518 : Closed e2422374853518 ∧ code e2422374853518 = 11218467875726 := by decide
theorem cert_e2422374853518 : check e2422374853518 [[],[]] .smaller = true := by decide
def e2422374853530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374853530 : Closed e2422374853530 ∧ code e2422374853530 = 11218467875738 := by decide
theorem cert_e2422374853530 : check e2422374853530 [[],[]] .smaller = true := by decide
def e2422374853574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2422374853574 : Closed e2422374853574 ∧ code e2422374853574 = 11218467875782 := by decide
theorem cert_e2422374853574 : check e2422374853574 [[],[]] .three = true := by decide
def e2422374853598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3))))))))
theorem wire_e2422374853598 : Closed e2422374853598 ∧ code e2422374853598 = 11218467875806 := by decide
theorem cert_e2422374853598 : check e2422374853598 [[],[]] .three = true := by decide
def e2422374853726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422374853726 : Closed e2422374853726 ∧ code e2422374853726 = 11218467875934 := by decide
theorem cert_e2422374853726 : check e2422374853726 [[],[]] .three = true := by decide
def e2422374853742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2422374853742 : Closed e2422374853742 ∧ code e2422374853742 = 11218467875950 := by decide
theorem cert_e2422374853742 : check e2422374853742 [[],[]] .smaller = true := by decide
def e2422374853754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422374853754 : Closed e2422374853754 ∧ code e2422374853754 = 11218467875962 := by decide
theorem cert_e2422374853754 : check e2422374853754 [[],[]] .smaller = true := by decide
def e2422374853918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422374853918 : Closed e2422374853918 ∧ code e2422374853918 = 11218467876126 := by decide
theorem cert_e2422374853918 : check e2422374853918 [[],[]] .smaller = true := by decide
def e2422374854086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422374854086 : Closed e2422374854086 ∧ code e2422374854086 = 11218467876294 := by decide
theorem cert_e2422374854086 : check e2422374854086 [[],[]] .smaller = true := by decide
def e2422374854110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 3))))))))
theorem wire_e2422374854110 : Closed e2422374854110 ∧ code e2422374854110 = 11218467876318 := by decide
theorem cert_e2422374854110 : check e2422374854110 [[],[]] .three = true := by decide
def e2422374854114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422374854114 : Closed e2422374854114 ∧ code e2422374854114 = 11218467876322 := by decide
theorem cert_e2422374854114 : check e2422374854114 [[],[]] .three = true := by decide
def e2422374854126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 2))))))))
theorem wire_e2422374854126 : Closed e2422374854126 ∧ code e2422374854126 = 11218467876334 := by decide
theorem cert_e2422374854126 : check e2422374854126 [[],[]] .three = true := by decide
def e2422374854154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422374854154 : Closed e2422374854154 ∧ code e2422374854154 = 11218467876362 := by decide
theorem cert_e2422374854154 : check e2422374854154 [[],[]] .smaller = true := by decide
def e2422374854190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422374854190 : Closed e2422374854190 ∧ code e2422374854190 = 11218467876398 := by decide
theorem cert_e2422374854190 : check e2422374854190 [[],[]] .smaller = true := by decide
def e2422374854198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422374854198 : Closed e2422374854198 ∧ code e2422374854198 = 11218467876406 := by decide
theorem cert_e2422374854198 : check e2422374854198 [[],[]] .smaller = true := by decide
def e2422374854202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422374854202 : Closed e2422374854202 ∧ code e2422374854202 = 11218467876410 := by decide
theorem cert_e2422374854202 : check e2422374854202 [[],[]] .smaller = true := by decide
def e2422374854250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422374854250 : Closed e2422374854250 ∧ code e2422374854250 = 11218467876458 := by decide
theorem cert_e2422374854250 : check e2422374854250 [[],[]] .smaller = true := by decide
def e2422374854274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374854274 : Closed e2422374854274 ∧ code e2422374854274 = 11218467876482 := by decide
theorem cert_e2422374854274 : check e2422374854274 [[],[]] .smaller = true := by decide
def e2422374854286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422374854286 : Closed e2422374854286 ∧ code e2422374854286 = 11218467876494 := by decide
theorem cert_e2422374854286 : check e2422374854286 [[],[]] .smaller = true := by decide
def e2422374854298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374854298 : Closed e2422374854298 ∧ code e2422374854298 = 11218467876506 := by decide
theorem cert_e2422374854298 : check e2422374854298 [[],[]] .smaller = true := by decide
def e2422374854342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422374854342 : Closed e2422374854342 ∧ code e2422374854342 = 11218467876550 := by decide
theorem cert_e2422374854342 : check e2422374854342 [[],[]] .smaller = true := by decide
def e2422374854366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 3))))))))
theorem wire_e2422374854366 : Closed e2422374854366 ∧ code e2422374854366 = 11218467876574 := by decide
theorem cert_e2422374854366 : check e2422374854366 [[],[]] .three = true := by decide
def e2422374854370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422374854370 : Closed e2422374854370 ∧ code e2422374854370 = 11218467876578 := by decide
theorem cert_e2422374854370 : check e2422374854370 [[],[]] .smaller = true := by decide
def e2422374854382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 2))))))))
theorem wire_e2422374854382 : Closed e2422374854382 ∧ code e2422374854382 = 11218467876590 := by decide
theorem cert_e2422374854382 : check e2422374854382 [[],[]] .smaller = true := by decide
def e2422374854390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 3)) (.var 1))))))))
theorem wire_e2422374854390 : Closed e2422374854390 ∧ code e2422374854390 = 11218467876598 := by decide
theorem cert_e2422374854390 : check e2422374854390 [[],[]] .three = true := by decide
def e2422374854422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422374854422 : Closed e2422374854422 ∧ code e2422374854422 = 11218467876630 := by decide
theorem cert_e2422374854422 : check e2422374854422 [[],[]] .three = true := by decide
def e2422374854426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422374854426 : Closed e2422374854426 ∧ code e2422374854426 = 11218467876634 := by decide
theorem cert_e2422374854426 : check e2422374854426 [[],[]] .three = true := by decide
def e2422374854470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422374854470 : Closed e2422374854470 ∧ code e2422374854470 = 11218467876678 := by decide
theorem cert_e2422374854470 : check e2422374854470 [[],[]] .three = true := by decide
def e2422374854494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3))))))))
theorem wire_e2422374854494 : Closed e2422374854494 ∧ code e2422374854494 = 11218467876702 := by decide
theorem cert_e2422374854494 : check e2422374854494 [[],[]] .three = true := by decide
def e2422374854498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422374854498 : Closed e2422374854498 ∧ code e2422374854498 = 11218467876706 := by decide
theorem cert_e2422374854498 : check e2422374854498 [[],[]] .three = true := by decide
def e2422374854510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 2))))))))
theorem wire_e2422374854510 : Closed e2422374854510 ∧ code e2422374854510 = 11218467876718 := by decide
theorem cert_e2422374854510 : check e2422374854510 [[],[]] .three = true := by decide
def e2422374854518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 2)) (.var 1))))))))
theorem wire_e2422374854518 : Closed e2422374854518 ∧ code e2422374854518 = 11218467876726 := by decide
theorem cert_e2422374854518 : check e2422374854518 [[],[]] .three = true := by decide
def e2422374854522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0))))))))
theorem wire_e2422374854522 : Closed e2422374854522 ∧ code e2422374854522 = 11218467876730 := by decide
theorem cert_e2422374854522 : check e2422374854522 [[],[]] .three = true := by decide
def e2422374854742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))))
theorem wire_e2422374854742 : Closed e2422374854742 ∧ code e2422374854742 = 11218467876950 := by decide
theorem cert_e2422374854742 : check e2422374854742 [[],[]] .smaller = true := by decide
def e2422374854746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))))
theorem wire_e2422374854746 : Closed e2422374854746 ∧ code e2422374854746 = 11218467876954 := by decide
theorem cert_e2422374854746 : check e2422374854746 [[],[]] .smaller = true := by decide
def e2422374855006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e2422374855006 : Closed e2422374855006 ∧ code e2422374855006 = 11218467877214 := by decide
theorem cert_e2422374855006 : check e2422374855006 [[],[]] .three = true := by decide
def e2422374855022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e2422374855022 : Closed e2422374855022 ∧ code e2422374855022 = 11218467877230 := by decide
theorem cert_e2422374855022 : check e2422374855022 [[],[]] .smaller = true := by decide
def e2422374855030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e2422374855030 : Closed e2422374855030 ∧ code e2422374855030 = 11218467877238 := by decide
theorem cert_e2422374855030 : check e2422374855030 [[],[]] .smaller = true := by decide
def e2422374855034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e2422374855034 : Closed e2422374855034 ∧ code e2422374855034 = 11218467877242 := by decide
theorem cert_e2422374855034 : check e2422374855034 [[],[]] .three = true := by decide
def e2422374855094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e2422374855094 : Closed e2422374855094 ∧ code e2422374855094 = 11218467877302 := by decide
theorem cert_e2422374855094 : check e2422374855094 [[],[]] .smaller = true := by decide
def e2422374855126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e2422374855126 : Closed e2422374855126 ∧ code e2422374855126 = 11218467877334 := by decide
theorem cert_e2422374855126 : check e2422374855126 [[],[]] .smaller = true := by decide
def e2422374855130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e2422374855130 : Closed e2422374855130 ∧ code e2422374855130 = 11218467877338 := by decide
theorem cert_e2422374855130 : check e2422374855130 [[],[]] .smaller = true := by decide
def e2422374855510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422374855510 : Closed e2422374855510 ∧ code e2422374855510 = 11218467877718 := by decide
theorem cert_e2422374855510 : check e2422374855510 [[],[]] .smaller = true := by decide
def e2422374855514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422374855514 : Closed e2422374855514 ∧ code e2422374855514 = 11218467877722 := by decide
theorem cert_e2422374855514 : check e2422374855514 [[],[]] .smaller = true := by decide
def e2422374855530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422374855530 : Closed e2422374855530 ∧ code e2422374855530 = 11218467877738 := by decide
theorem cert_e2422374855530 : check e2422374855530 [[],[]] .smaller = true := by decide
def e2422374855594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422374855594 : Closed e2422374855594 ∧ code e2422374855594 = 11218467877802 := by decide
theorem cert_e2422374855594 : check e2422374855594 [[],[]] .smaller = true := by decide
def e2422374855702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422374855702 : Closed e2422374855702 ∧ code e2422374855702 = 11218467877910 := by decide
theorem cert_e2422374855702 : check e2422374855702 [[],[]] .smaller = true := by decide
def e2422374855774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422374855774 : Closed e2422374855774 ∧ code e2422374855774 = 11218467877982 := by decide
theorem cert_e2422374855774 : check e2422374855774 [[],[]] .three = true := by decide
def e2422374855798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422374855798 : Closed e2422374855798 ∧ code e2422374855798 = 11218467878006 := by decide
theorem cert_e2422374855798 : check e2422374855798 [[],[]] .smaller = true := by decide
def e2422374855894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422374855894 : Closed e2422374855894 ∧ code e2422374855894 = 11218467878102 := by decide
theorem cert_e2422374855894 : check e2422374855894 [[],[]] .smaller = true := by decide
def e2422374855898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422374855898 : Closed e2422374855898 ∧ code e2422374855898 = 11218467878106 := by decide
theorem cert_e2422374855898 : check e2422374855898 [[],[]] .smaller = true := by decide
def e2422374855914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422374855914 : Closed e2422374855914 ∧ code e2422374855914 = 11218467878122 := by decide
theorem cert_e2422374855914 : check e2422374855914 [[],[]] .smaller = true := by decide
def e2422374855990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374855990 : Closed e2422374855990 ∧ code e2422374855990 = 11218467878198 := by decide
theorem cert_e2422374855990 : check e2422374855990 [[],[]] .smaller = true := by decide
def e2422374855994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374855994 : Closed e2422374855994 ∧ code e2422374855994 = 11218467878202 := by decide
theorem cert_e2422374855994 : check e2422374855994 [[],[]] .smaller = true := by decide
def e2422374856066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374856066 : Closed e2422374856066 ∧ code e2422374856066 = 11218467878274 := by decide
theorem cert_e2422374856066 : check e2422374856066 [[],[]] .smaller = true := by decide
def e2422374856078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422374856078 : Closed e2422374856078 ∧ code e2422374856078 = 11218467878286 := by decide
theorem cert_e2422374856078 : check e2422374856078 [[],[]] .smaller = true := by decide
def e2422374856090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374856090 : Closed e2422374856090 ∧ code e2422374856090 = 11218467878298 := by decide
theorem cert_e2422374856090 : check e2422374856090 [[],[]] .smaller = true := by decide
def e2422374856158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e2422374856158 : Closed e2422374856158 ∧ code e2422374856158 = 11218467878366 := by decide
theorem cert_e2422374856158 : check e2422374856158 [[],[]] .three = true := by decide
def e2422374856162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422374856162 : Closed e2422374856162 ∧ code e2422374856162 = 11218467878370 := by decide
theorem cert_e2422374856162 : check e2422374856162 [[],[]] .three = true := by decide
def e2422374856174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e2422374856174 : Closed e2422374856174 ∧ code e2422374856174 = 11218467878382 := by decide
theorem cert_e2422374856174 : check e2422374856174 [[],[]] .three = true := by decide
def e2422374856202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422374856202 : Closed e2422374856202 ∧ code e2422374856202 = 11218467878410 := by decide
theorem cert_e2422374856202 : check e2422374856202 [[],[]] .smaller = true := by decide
def e2422374856238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422374856238 : Closed e2422374856238 ∧ code e2422374856238 = 11218467878446 := by decide
theorem cert_e2422374856238 : check e2422374856238 [[],[]] .smaller = true := by decide
def e2422374856246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422374856246 : Closed e2422374856246 ∧ code e2422374856246 = 11218467878454 := by decide
theorem cert_e2422374856246 : check e2422374856246 [[],[]] .smaller = true := by decide
def e2422374856250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422374856250 : Closed e2422374856250 ∧ code e2422374856250 = 11218467878458 := by decide
theorem cert_e2422374856250 : check e2422374856250 [[],[]] .smaller = true := by decide
def e2422374856298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422374856298 : Closed e2422374856298 ∧ code e2422374856298 = 11218467878506 := by decide
theorem cert_e2422374856298 : check e2422374856298 [[],[]] .smaller = true := by decide
def e2422374856322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374856322 : Closed e2422374856322 ∧ code e2422374856322 = 11218467878530 := by decide
theorem cert_e2422374856322 : check e2422374856322 [[],[]] .smaller = true := by decide
def e2422374856334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422374856334 : Closed e2422374856334 ∧ code e2422374856334 = 11218467878542 := by decide
theorem cert_e2422374856334 : check e2422374856334 [[],[]] .smaller = true := by decide
def e2422374856346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374856346 : Closed e2422374856346 ∧ code e2422374856346 = 11218467878554 := by decide
theorem cert_e2422374856346 : check e2422374856346 [[],[]] .smaller = true := by decide
def e2422374856390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422374856390 : Closed e2422374856390 ∧ code e2422374856390 = 11218467878598 := by decide
theorem cert_e2422374856390 : check e2422374856390 [[],[]] .smaller = true := by decide
def e2422374856414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e2422374856414 : Closed e2422374856414 ∧ code e2422374856414 = 11218467878622 := by decide
theorem cert_e2422374856414 : check e2422374856414 [[],[]] .three = true := by decide
end Blc.Floor43
