import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422374856418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422374856418 : Closed e2422374856418 ∧ code e2422374856418 = 11218467878626 := by decide
theorem cert_e2422374856418 : check e2422374856418 [[],[]] .smaller = true := by decide
def e2422374856430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e2422374856430 : Closed e2422374856430 ∧ code e2422374856430 = 11218467878638 := by decide
theorem cert_e2422374856430 : check e2422374856430 [[],[]] .smaller = true := by decide
def e2422374856438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e2422374856438 : Closed e2422374856438 ∧ code e2422374856438 = 11218467878646 := by decide
theorem cert_e2422374856438 : check e2422374856438 [[],[]] .three = true := by decide
def e2422374856470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422374856470 : Closed e2422374856470 ∧ code e2422374856470 = 11218467878678 := by decide
theorem cert_e2422374856470 : check e2422374856470 [[],[]] .smaller = true := by decide
def e2422374856542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e2422374856542 : Closed e2422374856542 ∧ code e2422374856542 = 11218467878750 := by decide
theorem cert_e2422374856542 : check e2422374856542 [[],[]] .three = true := by decide
def e2422374856546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422374856546 : Closed e2422374856546 ∧ code e2422374856546 = 11218467878754 := by decide
theorem cert_e2422374856546 : check e2422374856546 [[],[]] .smaller = true := by decide
def e2422374856558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e2422374856558 : Closed e2422374856558 ∧ code e2422374856558 = 11218467878766 := by decide
theorem cert_e2422374856558 : check e2422374856558 [[],[]] .smaller = true := by decide
def e2422374856566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e2422374856566 : Closed e2422374856566 ∧ code e2422374856566 = 11218467878774 := by decide
theorem cert_e2422374856566 : check e2422374856566 [[],[]] .smaller = true := by decide
def e2422374856570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e2422374856570 : Closed e2422374856570 ∧ code e2422374856570 = 11218467878778 := by decide
theorem cert_e2422374856570 : check e2422374856570 [[],[]] .three = true := by decide
def e2422374856586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422374856586 : Closed e2422374856586 ∧ code e2422374856586 = 11218467878794 := by decide
theorem cert_e2422374856586 : check e2422374856586 [[],[]] .three = true := by decide
def e2422374856610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422374856610 : Closed e2422374856610 ∧ code e2422374856610 = 11218467878818 := by decide
theorem cert_e2422374856610 : check e2422374856610 [[],[]] .three = true := by decide
def e2422374856622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e2422374856622 : Closed e2422374856622 ∧ code e2422374856622 = 11218467878830 := by decide
theorem cert_e2422374856622 : check e2422374856622 [[],[]] .three = true := by decide
def e2422374856630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e2422374856630 : Closed e2422374856630 ∧ code e2422374856630 = 11218467878838 := by decide
theorem cert_e2422374856630 : check e2422374856630 [[],[]] .three = true := by decide
def e2422374856634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e2422374856634 : Closed e2422374856634 ∧ code e2422374856634 = 11218467878842 := by decide
theorem cert_e2422374856634 : check e2422374856634 [[],[]] .three = true := by decide
def e2422374856878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422374856878 : Closed e2422374856878 ∧ code e2422374856878 = 11218467879086 := by decide
theorem cert_e2422374856878 : check e2422374856878 [[],[]] .three = true := by decide
def e2422374856886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 1)) (.var 1))))))))
theorem wire_e2422374856886 : Closed e2422374856886 ∧ code e2422374856886 = 11218467879094 := by decide
theorem cert_e2422374856886 : check e2422374856886 [[],[]] .three = true := by decide
def e2422374856890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422374856890 : Closed e2422374856890 ∧ code e2422374856890 = 11218467879098 := by decide
theorem cert_e2422374856890 : check e2422374856890 [[],[]] .three = true := by decide
def e2422374856918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422374856918 : Closed e2422374856918 ∧ code e2422374856918 = 11218467879126 := by decide
theorem cert_e2422374856918 : check e2422374856918 [[],[]] .three = true := by decide
def e2422374856922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422374856922 : Closed e2422374856922 ∧ code e2422374856922 = 11218467879130 := by decide
theorem cert_e2422374856922 : check e2422374856922 [[],[]] .three = true := by decide
def e2422374856938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422374856938 : Closed e2422374856938 ∧ code e2422374856938 = 11218467879146 := by decide
theorem cert_e2422374856938 : check e2422374856938 [[],[]] .three = true := by decide
def e2422374857262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422374857262 : Closed e2422374857262 ∧ code e2422374857262 = 11218467879470 := by decide
theorem cert_e2422374857262 : check e2422374857262 [[],[]] .three = true := by decide
def e2422374857270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422374857270 : Closed e2422374857270 ∧ code e2422374857270 = 11218467879478 := by decide
theorem cert_e2422374857270 : check e2422374857270 [[],[]] .three = true := by decide
def e2422374857274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422374857274 : Closed e2422374857274 ∧ code e2422374857274 = 11218467879482 := by decide
theorem cert_e2422374857274 : check e2422374857274 [[],[]] .three = true := by decide
def e2422374857358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422374857358 : Closed e2422374857358 ∧ code e2422374857358 = 11218467879566 := by decide
theorem cert_e2422374857358 : check e2422374857358 [[],[]] .three = true := by decide
def e2422374857414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422374857414 : Closed e2422374857414 ∧ code e2422374857414 = 11218467879622 := by decide
theorem cert_e2422374857414 : check e2422374857414 [[],[]] .three = true := by decide
def e2422374857438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2422374857438 : Closed e2422374857438 ∧ code e2422374857438 = 11218467879646 := by decide
theorem cert_e2422374857438 : check e2422374857438 [[],[]] .three = true := by decide
def e2422374857442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422374857442 : Closed e2422374857442 ∧ code e2422374857442 = 11218467879650 := by decide
theorem cert_e2422374857442 : check e2422374857442 [[],[]] .three = true := by decide
def e2422374857454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2422374857454 : Closed e2422374857454 ∧ code e2422374857454 = 11218467879662 := by decide
theorem cert_e2422374857454 : check e2422374857454 [[],[]] .three = true := by decide
def e2422374857462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2422374857462 : Closed e2422374857462 ∧ code e2422374857462 = 11218467879670 := by decide
theorem cert_e2422374857462 : check e2422374857462 [[],[]] .three = true := by decide
def e2422374857494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422374857494 : Closed e2422374857494 ∧ code e2422374857494 = 11218467879702 := by decide
theorem cert_e2422374857494 : check e2422374857494 [[],[]] .three = true := by decide
def e2422374857498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422374857498 : Closed e2422374857498 ∧ code e2422374857498 = 11218467879706 := by decide
theorem cert_e2422374857498 : check e2422374857498 [[],[]] .three = true := by decide
def e2422374857542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422374857542 : Closed e2422374857542 ∧ code e2422374857542 = 11218467879750 := by decide
theorem cert_e2422374857542 : check e2422374857542 [[],[]] .three = true := by decide
def e2422374857566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2422374857566 : Closed e2422374857566 ∧ code e2422374857566 = 11218467879774 := by decide
theorem cert_e2422374857566 : check e2422374857566 [[],[]] .three = true := by decide
def e2422374857570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422374857570 : Closed e2422374857570 ∧ code e2422374857570 = 11218467879778 := by decide
theorem cert_e2422374857570 : check e2422374857570 [[],[]] .three = true := by decide
def e2422374857582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e2422374857582 : Closed e2422374857582 ∧ code e2422374857582 = 11218467879790 := by decide
theorem cert_e2422374857582 : check e2422374857582 [[],[]] .three = true := by decide
def e2422374857590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e2422374857590 : Closed e2422374857590 ∧ code e2422374857590 = 11218467879798 := by decide
theorem cert_e2422374857590 : check e2422374857590 [[],[]] .three = true := by decide
def e2422374857594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2422374857594 : Closed e2422374857594 ∧ code e2422374857594 = 11218467879802 := by decide
theorem cert_e2422374857594 : check e2422374857594 [[],[]] .three = true := by decide
def e2422374857610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422374857610 : Closed e2422374857610 ∧ code e2422374857610 = 11218467879818 := by decide
theorem cert_e2422374857610 : check e2422374857610 [[],[]] .three = true := by decide
def e2422374857634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422374857634 : Closed e2422374857634 ∧ code e2422374857634 = 11218467879842 := by decide
theorem cert_e2422374857634 : check e2422374857634 [[],[]] .three = true := by decide
def e2422374857646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2422374857646 : Closed e2422374857646 ∧ code e2422374857646 = 11218467879854 := by decide
theorem cert_e2422374857646 : check e2422374857646 [[],[]] .three = true := by decide
def e2422374857654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e2422374857654 : Closed e2422374857654 ∧ code e2422374857654 = 11218467879862 := by decide
theorem cert_e2422374857654 : check e2422374857654 [[],[]] .three = true := by decide
def e2422374857658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2422374857658 : Closed e2422374857658 ∧ code e2422374857658 = 11218467879866 := by decide
theorem cert_e2422374857658 : check e2422374857658 [[],[]] .three = true := by decide
def e2422374857686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2422374857686 : Closed e2422374857686 ∧ code e2422374857686 = 11218467879894 := by decide
theorem cert_e2422374857686 : check e2422374857686 [[],[]] .three = true := by decide
def e2422374857690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2422374857690 : Closed e2422374857690 ∧ code e2422374857690 = 11218467879898 := by decide
theorem cert_e2422374857690 : check e2422374857690 [[],[]] .three = true := by decide
def e2422374860014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374860014 : Closed e2422374860014 ∧ code e2422374860014 = 11218467882222 := by decide
theorem cert_e2422374860014 : check e2422374860014 [[],[]] .smaller = true := by decide
def e2422374860022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374860022 : Closed e2422374860022 ∧ code e2422374860022 = 11218467882230 := by decide
theorem cert_e2422374860022 : check e2422374860022 [[],[]] .smaller = true := by decide
def e2422374860766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 3))))))))
theorem wire_e2422374860766 : Closed e2422374860766 ∧ code e2422374860766 = 11218467882974 := by decide
theorem cert_e2422374860766 : check e2422374860766 [[],[]] .three = true := by decide
def e2422374860782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 2))))))))
theorem wire_e2422374860782 : Closed e2422374860782 ∧ code e2422374860782 = 11218467882990 := by decide
theorem cert_e2422374860782 : check e2422374860782 [[],[]] .three = true := by decide
def e2422374862302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 3))))))))
theorem wire_e2422374862302 : Closed e2422374862302 ∧ code e2422374862302 = 11218467884510 := by decide
theorem cert_e2422374862302 : check e2422374862302 [[],[]] .three = true := by decide
def e2422374862326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 4)))) (.var 1))))))))
theorem wire_e2422374862326 : Closed e2422374862326 ∧ code e2422374862326 = 11218467884534 := by decide
theorem cert_e2422374862326 : check e2422374862326 [[],[]] .three = true := by decide
def e2422374862574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e2422374862574 : Closed e2422374862574 ∧ code e2422374862574 = 11218467884782 := by decide
theorem cert_e2422374862574 : check e2422374862574 [[],[]] .smaller = true := by decide
def e2422374862582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e2422374862582 : Closed e2422374862582 ∧ code e2422374862582 = 11218467884790 := by decide
theorem cert_e2422374862582 : check e2422374862582 [[],[]] .smaller = true := by decide
def e2422374862686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 3))))))))
theorem wire_e2422374862686 : Closed e2422374862686 ∧ code e2422374862686 = 11218467884894 := by decide
theorem cert_e2422374862686 : check e2422374862686 [[],[]] .three = true := by decide
def e2422374862702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e2422374862702 : Closed e2422374862702 ∧ code e2422374862702 = 11218467884910 := by decide
theorem cert_e2422374862702 : check e2422374862702 [[],[]] .smaller = true := by decide
def e2422374862714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e2422374862714 : Closed e2422374862714 ∧ code e2422374862714 = 11218467884922 := by decide
theorem cert_e2422374862714 : check e2422374862714 [[],[]] .smaller = true := by decide
def e2422374862774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e2422374862774 : Closed e2422374862774 ∧ code e2422374862774 = 11218467884982 := by decide
theorem cert_e2422374862774 : check e2422374862774 [[],[]] .smaller = true := by decide
def e2422374862778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e2422374862778 : Closed e2422374862778 ∧ code e2422374862778 = 11218467884986 := by decide
theorem cert_e2422374862778 : check e2422374862778 [[],[]] .smaller = true := by decide
def e2422374862806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.app (.var 4) (.var 0)))) (.var 1))))))))
theorem wire_e2422374862806 : Closed e2422374862806 ∧ code e2422374862806 = 11218467885014 := by decide
theorem cert_e2422374862806 : check e2422374862806 [[],[]] .three = true := by decide
def e2422374863838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422374863838 : Closed e2422374863838 ∧ code e2422374863838 = 11218467886046 := by decide
theorem cert_e2422374863838 : check e2422374863838 [[],[]] .three = true := by decide
def e2422374863854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422374863854 : Closed e2422374863854 ∧ code e2422374863854 = 11218467886062 := by decide
theorem cert_e2422374863854 : check e2422374863854 [[],[]] .three = true := by decide
def e2422374865374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422374865374 : Closed e2422374865374 ∧ code e2422374865374 = 11218467887582 := by decide
theorem cert_e2422374865374 : check e2422374865374 [[],[]] .three = true := by decide
def e2422374865398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422374865398 : Closed e2422374865398 ∧ code e2422374865398 = 11218467887606 := by decide
theorem cert_e2422374865398 : check e2422374865398 [[],[]] .three = true := by decide
def e2422374866142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422374866142 : Closed e2422374866142 ∧ code e2422374866142 = 11218467888350 := by decide
theorem cert_e2422374866142 : check e2422374866142 [[],[]] .three = true := by decide
def e2422374866158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374866158 : Closed e2422374866158 ∧ code e2422374866158 = 11218467888366 := by decide
theorem cert_e2422374866158 : check e2422374866158 [[],[]] .smaller = true := by decide
def e2422374866166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374866166 : Closed e2422374866166 ∧ code e2422374866166 = 11218467888374 := by decide
theorem cert_e2422374866166 : check e2422374866166 [[],[]] .smaller = true := by decide
def e2422374866170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422374866170 : Closed e2422374866170 ∧ code e2422374866170 = 11218467888378 := by decide
theorem cert_e2422374866170 : check e2422374866170 [[],[]] .three = true := by decide
def e2422374866494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 4)))))))))
theorem wire_e2422374866494 : Closed e2422374866494 ∧ code e2422374866494 = 11218467888702 := by decide
theorem cert_e2422374866494 : check e2422374866494 [[],[]] .three = true := by decide
def e2422374866550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422374866550 : Closed e2422374866550 ∧ code e2422374866550 = 11218467888758 := by decide
theorem cert_e2422374866550 : check e2422374866550 [[],[]] .smaller = true := by decide
def e2422374866718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 3)))))))))
theorem wire_e2422374866718 : Closed e2422374866718 ∧ code e2422374866718 = 11218467888926 := by decide
theorem cert_e2422374866718 : check e2422374866718 [[],[]] .three = true := by decide
def e2422374866742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374866742 : Closed e2422374866742 ∧ code e2422374866742 = 11218467888950 := by decide
theorem cert_e2422374866742 : check e2422374866742 [[],[]] .three = true := by decide
def e2422374866746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374866746 : Closed e2422374866746 ∧ code e2422374866746 = 11218467888954 := by decide
theorem cert_e2422374866746 : check e2422374866746 [[],[]] .three = true := by decide
def e2422374870382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e2422374870382 : Closed e2422374870382 ∧ code e2422374870382 = 11218467892590 := by decide
theorem cert_e2422374870382 : check e2422374870382 [[],[]] .smaller = true := by decide
def e2422374870390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e2422374870390 : Closed e2422374870390 ∧ code e2422374870390 = 11218467892598 := by decide
theorem cert_e2422374870390 : check e2422374870390 [[],[]] .smaller = true := by decide
def e2422374870446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e2422374870446 : Closed e2422374870446 ∧ code e2422374870446 = 11218467892654 := by decide
theorem cert_e2422374870446 : check e2422374870446 [[],[]] .smaller = true := by decide
def e2422374870458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e2422374870458 : Closed e2422374870458 ∧ code e2422374870458 = 11218467892666 := by decide
theorem cert_e2422374870458 : check e2422374870458 [[],[]] .smaller = true := by decide
def e2422374870486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e2422374870486 : Closed e2422374870486 ∧ code e2422374870486 = 11218467892694 := by decide
theorem cert_e2422374870486 : check e2422374870486 [[],[]] .smaller = true := by decide
def e2422374870490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e2422374870490 : Closed e2422374870490 ∧ code e2422374870490 = 11218467892698 := by decide
theorem cert_e2422374870490 : check e2422374870490 [[],[]] .smaller = true := by decide
def e2422374870702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e2422374870702 : Closed e2422374870702 ∧ code e2422374870702 = 11218467892910 := by decide
theorem cert_e2422374870702 : check e2422374870702 [[],[]] .smaller = true := by decide
def e2422374870714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e2422374870714 : Closed e2422374870714 ∧ code e2422374870714 = 11218467892922 := by decide
theorem cert_e2422374870714 : check e2422374870714 [[],[]] .smaller = true := by decide
def e2422374870762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e2422374870762 : Closed e2422374870762 ∧ code e2422374870762 = 11218467892970 := by decide
theorem cert_e2422374870762 : check e2422374870762 [[],[]] .smaller = true := by decide
def e2422374870870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422374870870 : Closed e2422374870870 ∧ code e2422374870870 = 11218467893078 := by decide
theorem cert_e2422374870870 : check e2422374870870 [[],[]] .smaller = true := by decide
def e2422374870874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422374870874 : Closed e2422374870874 ∧ code e2422374870874 = 11218467893082 := by decide
theorem cert_e2422374870874 : check e2422374870874 [[],[]] .smaller = true := by decide
def e2422374870890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422374870890 : Closed e2422374870890 ∧ code e2422374870890 = 11218467893098 := by decide
theorem cert_e2422374870890 : check e2422374870890 [[],[]] .smaller = true := by decide
def e2422374871518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3))))))))
theorem wire_e2422374871518 : Closed e2422374871518 ∧ code e2422374871518 = 11218467893726 := by decide
theorem cert_e2422374871518 : check e2422374871518 [[],[]] .three = true := by decide
def e2422374871542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1))))))))
theorem wire_e2422374871542 : Closed e2422374871542 ∧ code e2422374871542 = 11218467893750 := by decide
theorem cert_e2422374871542 : check e2422374871542 [[],[]] .three = true := by decide
def e2422374871918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e2422374871918 : Closed e2422374871918 ∧ code e2422374871918 = 11218467894126 := by decide
theorem cert_e2422374871918 : check e2422374871918 [[],[]] .smaller = true := by decide
def e2422374871926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e2422374871926 : Closed e2422374871926 ∧ code e2422374871926 = 11218467894134 := by decide
theorem cert_e2422374871926 : check e2422374871926 [[],[]] .smaller = true := by decide
def e2422374871982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e2422374871982 : Closed e2422374871982 ∧ code e2422374871982 = 11218467894190 := by decide
theorem cert_e2422374871982 : check e2422374871982 [[],[]] .smaller = true := by decide
def e2422374871994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e2422374871994 : Closed e2422374871994 ∧ code e2422374871994 = 11218467894202 := by decide
theorem cert_e2422374871994 : check e2422374871994 [[],[]] .smaller = true := by decide
def e2422374872022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e2422374872022 : Closed e2422374872022 ∧ code e2422374872022 = 11218467894230 := by decide
theorem cert_e2422374872022 : check e2422374872022 [[],[]] .smaller = true := by decide
def e2422374872026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e2422374872026 : Closed e2422374872026 ∧ code e2422374872026 = 11218467894234 := by decide
theorem cert_e2422374872026 : check e2422374872026 [[],[]] .smaller = true := by decide
def e2422374872302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422374872302 : Closed e2422374872302 ∧ code e2422374872302 = 11218467894510 := by decide
theorem cert_e2422374872302 : check e2422374872302 [[],[]] .smaller = true := by decide
def e2422374872310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422374872310 : Closed e2422374872310 ∧ code e2422374872310 = 11218467894518 := by decide
theorem cert_e2422374872310 : check e2422374872310 [[],[]] .smaller = true := by decide
def e2422374872638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4)))))))))
theorem wire_e2422374872638 : Closed e2422374872638 ∧ code e2422374872638 = 11218467894846 := by decide
theorem cert_e2422374872638 : check e2422374872638 [[],[]] .three = true := by decide
def e2422374872686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374872686 : Closed e2422374872686 ∧ code e2422374872686 = 11218467894894 := by decide
theorem cert_e2422374872686 : check e2422374872686 [[],[]] .smaller = true := by decide
def e2422374872698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374872698 : Closed e2422374872698 ∧ code e2422374872698 = 11218467894906 := by decide
theorem cert_e2422374872698 : check e2422374872698 [[],[]] .smaller = true := by decide
def e2422374872886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374872886 : Closed e2422374872886 ∧ code e2422374872886 = 11218467895094 := by decide
theorem cert_e2422374872886 : check e2422374872886 [[],[]] .smaller = true := by decide
def e2422374872890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374872890 : Closed e2422374872890 ∧ code e2422374872890 = 11218467895098 := by decide
theorem cert_e2422374872890 : check e2422374872890 [[],[]] .smaller = true := by decide
def e2422374872974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2)))))))))
theorem wire_e2422374872974 : Closed e2422374872974 ∧ code e2422374872974 = 11218467895182 := by decide
theorem cert_e2422374872974 : check e2422374872974 [[],[]] .three = true := by decide
def e2422374873134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2))))))))
theorem wire_e2422374873134 : Closed e2422374873134 ∧ code e2422374873134 = 11218467895342 := by decide
theorem cert_e2422374873134 : check e2422374873134 [[],[]] .smaller = true := by decide
def e2422374873310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e2422374873310 : Closed e2422374873310 ∧ code e2422374873310 = 11218467895518 := by decide
theorem cert_e2422374873310 : check e2422374873310 [[],[]] .three = true := by decide
def e2422374873326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422374873326 : Closed e2422374873326 ∧ code e2422374873326 = 11218467895534 := by decide
theorem cert_e2422374873326 : check e2422374873326 [[],[]] .smaller = true := by decide
def e2422374873334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e2422374873334 : Closed e2422374873334 ∧ code e2422374873334 = 11218467895542 := by decide
theorem cert_e2422374873334 : check e2422374873334 [[],[]] .smaller = true := by decide
def e2422374873338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422374873338 : Closed e2422374873338 ∧ code e2422374873338 = 11218467895546 := by decide
theorem cert_e2422374873338 : check e2422374873338 [[],[]] .three = true := by decide
def e2422374873518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422374873518 : Closed e2422374873518 ∧ code e2422374873518 = 11218467895726 := by decide
theorem cert_e2422374873518 : check e2422374873518 [[],[]] .smaller = true := by decide
def e2422374873530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422374873530 : Closed e2422374873530 ∧ code e2422374873530 = 11218467895738 := by decide
theorem cert_e2422374873530 : check e2422374873530 [[],[]] .smaller = true := by decide
def e2422374873578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422374873578 : Closed e2422374873578 ∧ code e2422374873578 = 11218467895786 := by decide
theorem cert_e2422374873578 : check e2422374873578 [[],[]] .smaller = true := by decide
def e2422374873662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e2422374873662 : Closed e2422374873662 ∧ code e2422374873662 = 11218467895870 := by decide
theorem cert_e2422374873662 : check e2422374873662 [[],[]] .three = true := by decide
def e2422374873710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422374873710 : Closed e2422374873710 ∧ code e2422374873710 = 11218467895918 := by decide
theorem cert_e2422374873710 : check e2422374873710 [[],[]] .smaller = true := by decide
def e2422374873722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422374873722 : Closed e2422374873722 ∧ code e2422374873722 = 11218467895930 := by decide
theorem cert_e2422374873722 : check e2422374873722 [[],[]] .smaller = true := by decide
def e2422374873886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422374873886 : Closed e2422374873886 ∧ code e2422374873886 = 11218467896094 := by decide
theorem cert_e2422374873886 : check e2422374873886 [[],[]] .smaller = true := by decide
def e2422374873986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374873986 : Closed e2422374873986 ∧ code e2422374873986 = 11218467896194 := by decide
theorem cert_e2422374873986 : check e2422374873986 [[],[]] .smaller = true := by decide
def e2422374873998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e2422374873998 : Closed e2422374873998 ∧ code e2422374873998 = 11218467896206 := by decide
theorem cert_e2422374873998 : check e2422374873998 [[],[]] .smaller = true := by decide
def e2422374874010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374874010 : Closed e2422374874010 ∧ code e2422374874010 = 11218467896218 := by decide
theorem cert_e2422374874010 : check e2422374874010 [[],[]] .smaller = true := by decide
def e2422374874054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422374874054 : Closed e2422374874054 ∧ code e2422374874054 = 11218467896262 := by decide
theorem cert_e2422374874054 : check e2422374874054 [[],[]] .three = true := by decide
def e2422374874078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3))))))))
theorem wire_e2422374874078 : Closed e2422374874078 ∧ code e2422374874078 = 11218467896286 := by decide
theorem cert_e2422374874078 : check e2422374874078 [[],[]] .three = true := by decide
def e2422374874134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 1))))))))
theorem wire_e2422374874134 : Closed e2422374874134 ∧ code e2422374874134 = 11218467896342 := by decide
theorem cert_e2422374874134 : check e2422374874134 [[],[]] .smaller = true := by decide
def e2422374874206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e2422374874206 : Closed e2422374874206 ∧ code e2422374874206 = 11218467896414 := by decide
theorem cert_e2422374874206 : check e2422374874206 [[],[]] .three = true := by decide
def e2422374874230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422374874230 : Closed e2422374874230 ∧ code e2422374874230 = 11218467896438 := by decide
theorem cert_e2422374874230 : check e2422374874230 [[],[]] .smaller = true := by decide
def e2422374874326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422374874326 : Closed e2422374874326 ∧ code e2422374874326 = 11218467896534 := by decide
theorem cert_e2422374874326 : check e2422374874326 [[],[]] .smaller = true := by decide
def e2422374874330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422374874330 : Closed e2422374874330 ∧ code e2422374874330 = 11218467896538 := by decide
theorem cert_e2422374874330 : check e2422374874330 [[],[]] .smaller = true := by decide
def e2422374874346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422374874346 : Closed e2422374874346 ∧ code e2422374874346 = 11218467896554 := by decide
theorem cert_e2422374874346 : check e2422374874346 [[],[]] .smaller = true := by decide
def e2422374874422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422374874422 : Closed e2422374874422 ∧ code e2422374874422 = 11218467896630 := by decide
theorem cert_e2422374874422 : check e2422374874422 [[],[]] .smaller = true := by decide
def e2422374874426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422374874426 : Closed e2422374874426 ∧ code e2422374874426 = 11218467896634 := by decide
theorem cert_e2422374874426 : check e2422374874426 [[],[]] .smaller = true := by decide
def e2422374874498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422374874498 : Closed e2422374874498 ∧ code e2422374874498 = 11218467896706 := by decide
theorem cert_e2422374874498 : check e2422374874498 [[],[]] .smaller = true := by decide
def e2422374874510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422374874510 : Closed e2422374874510 ∧ code e2422374874510 = 11218467896718 := by decide
theorem cert_e2422374874510 : check e2422374874510 [[],[]] .smaller = true := by decide
def e2422374874522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422374874522 : Closed e2422374874522 ∧ code e2422374874522 = 11218467896730 := by decide
theorem cert_e2422374874522 : check e2422374874522 [[],[]] .smaller = true := by decide
def e2422374874590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 3))))))))
theorem wire_e2422374874590 : Closed e2422374874590 ∧ code e2422374874590 = 11218467896798 := by decide
theorem cert_e2422374874590 : check e2422374874590 [[],[]] .three = true := by decide
def e2422374874594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e2422374874594 : Closed e2422374874594 ∧ code e2422374874594 = 11218467896802 := by decide
theorem cert_e2422374874594 : check e2422374874594 [[],[]] .three = true := by decide
def e2422374874606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 2))))))))
theorem wire_e2422374874606 : Closed e2422374874606 ∧ code e2422374874606 = 11218467896814 := by decide
theorem cert_e2422374874606 : check e2422374874606 [[],[]] .three = true := by decide
def e2422374874670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422374874670 : Closed e2422374874670 ∧ code e2422374874670 = 11218467896878 := by decide
theorem cert_e2422374874670 : check e2422374874670 [[],[]] .three = true := by decide
def e2422374874678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422374874678 : Closed e2422374874678 ∧ code e2422374874678 = 11218467896886 := by decide
theorem cert_e2422374874678 : check e2422374874678 [[],[]] .three = true := by decide
def e2422374874682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422374874682 : Closed e2422374874682 ∧ code e2422374874682 = 11218467896890 := by decide
theorem cert_e2422374874682 : check e2422374874682 [[],[]] .three = true := by decide
def e2422374874766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422374874766 : Closed e2422374874766 ∧ code e2422374874766 = 11218467896974 := by decide
theorem cert_e2422374874766 : check e2422374874766 [[],[]] .three = true := by decide
def e2422374874822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422374874822 : Closed e2422374874822 ∧ code e2422374874822 = 11218467897030 := by decide
theorem cert_e2422374874822 : check e2422374874822 [[],[]] .three = true := by decide
def e2422374874846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3))))))))
theorem wire_e2422374874846 : Closed e2422374874846 ∧ code e2422374874846 = 11218467897054 := by decide
theorem cert_e2422374874846 : check e2422374874846 [[],[]] .three = true := by decide
def e2422374874850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422374874850 : Closed e2422374874850 ∧ code e2422374874850 = 11218467897058 := by decide
theorem cert_e2422374874850 : check e2422374874850 [[],[]] .three = true := by decide
def e2422374874862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 2))))))))
theorem wire_e2422374874862 : Closed e2422374874862 ∧ code e2422374874862 = 11218467897070 := by decide
theorem cert_e2422374874862 : check e2422374874862 [[],[]] .three = true := by decide
def e2422374874870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1))))))))
theorem wire_e2422374874870 : Closed e2422374874870 ∧ code e2422374874870 = 11218467897078 := by decide
theorem cert_e2422374874870 : check e2422374874870 [[],[]] .three = true := by decide
def e2422374876126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422374876126 : Closed e2422374876126 ∧ code e2422374876126 = 11218467898334 := by decide
theorem cert_e2422374876126 : check e2422374876126 [[],[]] .smaller = true := by decide
def e2422374876142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422374876142 : Closed e2422374876142 ∧ code e2422374876142 = 11218467898350 := by decide
theorem cert_e2422374876142 : check e2422374876142 [[],[]] .smaller = true := by decide
def e2422374878062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422374878062 : Closed e2422374878062 ∧ code e2422374878062 = 11218467900270 := by decide
theorem cert_e2422374878062 : check e2422374878062 [[],[]] .smaller = true := by decide
def e2422374878070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422374878070 : Closed e2422374878070 ∧ code e2422374878070 = 11218467900278 := by decide
theorem cert_e2422374878070 : check e2422374878070 [[],[]] .smaller = true := by decide
def e2422374878126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422374878126 : Closed e2422374878126 ∧ code e2422374878126 = 11218467900334 := by decide
theorem cert_e2422374878126 : check e2422374878126 [[],[]] .smaller = true := by decide
def e2422374878138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422374878138 : Closed e2422374878138 ∧ code e2422374878138 = 11218467900346 := by decide
theorem cert_e2422374878138 : check e2422374878138 [[],[]] .smaller = true := by decide
def e2422374878166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422374878166 : Closed e2422374878166 ∧ code e2422374878166 = 11218467900374 := by decide
theorem cert_e2422374878166 : check e2422374878166 [[],[]] .smaller = true := by decide
def e2422374878170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422374878170 : Closed e2422374878170 ∧ code e2422374878170 = 11218467900378 := by decide
theorem cert_e2422374878170 : check e2422374878170 [[],[]] .smaller = true := by decide
def e2422374878446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422374878446 : Closed e2422374878446 ∧ code e2422374878446 = 11218467900654 := by decide
theorem cert_e2422374878446 : check e2422374878446 [[],[]] .smaller = true := by decide
def e2422374878454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422374878454 : Closed e2422374878454 ∧ code e2422374878454 = 11218467900662 := by decide
theorem cert_e2422374878454 : check e2422374878454 [[],[]] .smaller = true := by decide
def e2422374878782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 4))))))))))
theorem wire_e2422374878782 : Closed e2422374878782 ∧ code e2422374878782 = 11218467900990 := by decide
theorem cert_e2422374878782 : check e2422374878782 [[],[]] .three = true := by decide
def e2422374878830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422374878830 : Closed e2422374878830 ∧ code e2422374878830 = 11218467901038 := by decide
theorem cert_e2422374878830 : check e2422374878830 [[],[]] .smaller = true := by decide
def e2422374878842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422374878842 : Closed e2422374878842 ∧ code e2422374878842 = 11218467901050 := by decide
theorem cert_e2422374878842 : check e2422374878842 [[],[]] .smaller = true := by decide
def e2422374879030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422374879030 : Closed e2422374879030 ∧ code e2422374879030 = 11218467901238 := by decide
theorem cert_e2422374879030 : check e2422374879030 [[],[]] .smaller = true := by decide
def e2422374879034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422374879034 : Closed e2422374879034 ∧ code e2422374879034 = 11218467901242 := by decide
theorem cert_e2422374879034 : check e2422374879034 [[],[]] .smaller = true := by decide
def e2422374879118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 2))))))))))
theorem wire_e2422374879118 : Closed e2422374879118 ∧ code e2422374879118 = 11218467901326 := by decide
theorem cert_e2422374879118 : check e2422374879118 [[],[]] .three = true := by decide
def e2422374883774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 4))))))))))
theorem wire_e2422374883774 : Closed e2422374883774 ∧ code e2422374883774 = 11218467905982 := by decide
theorem cert_e2422374883774 : check e2422374883774 [[],[]] .three = true := by decide
def e2422374883806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422374883806 : Closed e2422374883806 ∧ code e2422374883806 = 11218467906014 := by decide
theorem cert_e2422374883806 : check e2422374883806 [[],[]] .smaller = true := by decide
def e2422374883830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422374883830 : Closed e2422374883830 ∧ code e2422374883830 = 11218467906038 := by decide
theorem cert_e2422374883830 : check e2422374883830 [[],[]] .smaller = true := by decide
def e2422374883834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 4) (.var 0))))))))))
theorem wire_e2422374883834 : Closed e2422374883834 ∧ code e2422374883834 = 11218467906042 := by decide
theorem cert_e2422374883834 : check e2422374883834 [[],[]] .three = true := by decide
def e2422374884782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422374884782 : Closed e2422374884782 ∧ code e2422374884782 = 11218467906990 := by decide
theorem cert_e2422374884782 : check e2422374884782 [[],[]] .smaller = true := by decide
end Blc.Floor43
