import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2248824239642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824239642 : Closed e2248824239642 ∧ code e2248824239642 = 11044917261850 := by decide
theorem cert_e2248824239642 : check e2248824239642 [[]] .width = true := by decide
def e2248824247834 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824247834 : Closed e2248824247834 ∧ code e2248824247834 = 11044917270042 := by decide
theorem cert_e2248824247834 : check e2248824247834 [[]] .width = true := by decide
def e2248824813082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824813082 : Closed e2248824813082 ∧ code e2248824813082 = 11044917835290 := by decide
theorem cert_e2248824813082 : check e2248824813082 [[]] .width = true := by decide
def e2248824829466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248824829466 : Closed e2248824829466 ∧ code e2248824829466 = 11044917851674 := by decide
theorem cert_e2248824829466 : check e2248824829466 [[]] .width = true := by decide
def e2248825599514 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248825599514 : Closed e2248825599514 ∧ code e2248825599514 = 11044918621722 := by decide
theorem cert_e2248825599514 : check e2248825599514 [[]] .width = true := by decide
def e2248825624090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248825624090 : Closed e2248825624090 ∧ code e2248825624090 = 11044918646298 := by decide
theorem cert_e2248825624090 : check e2248825624090 [[]] .width = true := by decide
def e2248826009114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248826009114 : Closed e2248826009114 ∧ code e2248826009114 = 11044919031322 := by decide
theorem cert_e2248826009114 : check e2248826009114 [[]] .width = true := by decide
def e2248826017306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248826017306 : Closed e2248826017306 ∧ code e2248826017306 = 11044919039514 := by decide
theorem cert_e2248826017306 : check e2248826017306 [[]] .width = true := by decide
def e2248869113370 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869113370 : Closed e2248869113370 ∧ code e2248869113370 = 11044962135578 := by decide
theorem cert_e2248869113370 : check e2248869113370 [[]] .width = true := by decide
def e2248869115418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869115418 : Closed e2248869115418 ∧ code e2248869115418 = 11044962137626 := by decide
theorem cert_e2248869115418 : check e2248869115418 [[]] .width = true := by decide
def e2248869129754 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869129754 : Closed e2248869129754 ∧ code e2248869129754 = 11044962151962 := by decide
theorem cert_e2248869129754 : check e2248869129754 [[]] .width = true := by decide
def e2248869132826 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869132826 : Closed e2248869132826 ∧ code e2248869132826 = 11044962155034 := by decide
theorem cert_e2248869132826 : check e2248869132826 [[]] .width = true := by decide
def e2248869139994 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869139994 : Closed e2248869139994 ∧ code e2248869139994 = 11044962162202 := by decide
theorem cert_e2248869139994 : check e2248869139994 [[]] .width = true := by decide
def e2248869141018 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869141018 : Closed e2248869141018 ∧ code e2248869141018 = 11044962163226 := by decide
theorem cert_e2248869141018 : check e2248869141018 [[]] .width = true := by decide
def e2248869211674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869211674 : Closed e2248869211674 ∧ code e2248869211674 = 11044962233882 := by decide
theorem cert_e2248869211674 : check e2248869211674 [[]] .width = true := by decide
def e2248869213722 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869213722 : Closed e2248869213722 ∧ code e2248869213722 = 11044962235930 := by decide
theorem cert_e2248869213722 : check e2248869213722 [[]] .width = true := by decide
def e2248869309978 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869309978 : Closed e2248869309978 ∧ code e2248869309978 = 11044962332186 := by decide
theorem cert_e2248869309978 : check e2248869309978 [[]] .width = true := by decide
def e2248869313050 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869313050 : Closed e2248869313050 ∧ code e2248869313050 = 11044962335258 := by decide
theorem cert_e2248869313050 : check e2248869313050 [[]] .width = true := by decide
def e2248869361178 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869361178 : Closed e2248869361178 ∧ code e2248869361178 = 11044962383386 := by decide
theorem cert_e2248869361178 : check e2248869361178 [[]] .width = true := by decide
def e2248869362202 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248869362202 : Closed e2248869362202 ∧ code e2248869362202 = 11044962384410 := by decide
theorem cert_e2248869362202 : check e2248869362202 [[]] .width = true := by decide
def e2248888138266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888138266 : Closed e2248888138266 ∧ code e2248888138266 = 11044981160474 := by decide
theorem cert_e2248888138266 : check e2248888138266 [[]] .width = true := by decide
def e2248888146458 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888146458 : Closed e2248888146458 ∧ code e2248888146458 = 11044981168666 := by decide
private def t_e2248888146458 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248888146458 : ¬ IsSelfInterpreter e2248888146458 :=
  wSource (t := t_e2248888146458) (replay_sound (ps := []) (t := e2248888146458) (by decide)) (by decide)
def e2248888203802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888203802 : Closed e2248888203802 ∧ code e2248888203802 = 11044981226010 := by decide
theorem cert_e2248888203802 : check e2248888203802 [[]] .width = true := by decide
def e2248888216090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888216090 : Closed e2248888216090 ∧ code e2248888216090 = 11044981238298 := by decide
theorem cert_e2248888216090 : check e2248888216090 [[]] .width = true := by decide
def e2248888244762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888244762 : Closed e2248888244762 ∧ code e2248888244762 = 11044981266970 := by decide
private def t_e2248888244762 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2248888244762 : ¬ IsSelfInterpreter e2248888244762 :=
  wSource (t := t_e2248888244762) (replay_sound (ps := []) (t := e2248888244762) (by decide)) (by decide)
def e2248888248858 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888248858 : Closed e2248888248858 ∧ code e2248888248858 = 11044981271066 := by decide
theorem cert_e2248888248858 : check e2248888248858 [[]] .width = true := by decide
def e2248888531482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888531482 : Closed e2248888531482 ∧ code e2248888531482 = 11044981553690 := by decide
theorem cert_e2248888531482 : check e2248888531482 [[]] .width = true := by decide
def e2248888539674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888539674 : Closed e2248888539674 ∧ code e2248888539674 = 11044981561882 := by decide
theorem cert_e2248888539674 : check e2248888539674 [[]] .width = true := by decide
def e2248888924698 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888924698 : Closed e2248888924698 ∧ code e2248888924698 = 11044981946906 := by decide
theorem cert_e2248888924698 : check e2248888924698 [[]] .width = true := by decide
def e2248888936986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248888936986 : Closed e2248888936986 ∧ code e2248888936986 = 11044981959194 := by decide
theorem cert_e2248888936986 : check e2248888936986 [[]] .width = true := by decide
def e2248889129498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248889129498 : Closed e2248889129498 ∧ code e2248889129498 = 11044982151706 := by decide
theorem cert_e2248889129498 : check e2248889129498 [[]] .width = true := by decide
def e2248889133594 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248889133594 : Closed e2248889133594 ∧ code e2248889133594 = 11044982155802 := by decide
theorem cert_e2248889133594 : check e2248889133594 [[]] .width = true := by decide
def e2248902667802 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902667802 : Closed e2248902667802 ∧ code e2248902667802 = 11044995690010 := by decide
theorem cert_e2248902667802 : check e2248902667802 [[]] .width = true := by decide
def e2248902669850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902669850 : Closed e2248902669850 ∧ code e2248902669850 = 11044995692058 := by decide
theorem cert_e2248902669850 : check e2248902669850 [[]] .width = true := by decide
def e2248902684186 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902684186 : Closed e2248902684186 ∧ code e2248902684186 = 11044995706394 := by decide
theorem cert_e2248902684186 : check e2248902684186 [[]] .width = true := by decide
def e2248902687258 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902687258 : Closed e2248902687258 ∧ code e2248902687258 = 11044995709466 := by decide
theorem cert_e2248902687258 : check e2248902687258 [[]] .width = true := by decide
def e2248902694426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902694426 : Closed e2248902694426 ∧ code e2248902694426 = 11044995716634 := by decide
theorem cert_e2248902694426 : check e2248902694426 [[]] .width = true := by decide
def e2248902695450 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902695450 : Closed e2248902695450 ∧ code e2248902695450 = 11044995717658 := by decide
theorem cert_e2248902695450 : check e2248902695450 [[]] .width = true := by decide
def e2248902766106 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902766106 : Closed e2248902766106 ∧ code e2248902766106 = 11044995788314 := by decide
theorem cert_e2248902766106 : check e2248902766106 [[]] .width = true := by decide
def e2248902768154 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902768154 : Closed e2248902768154 ∧ code e2248902768154 = 11044995790362 := by decide
theorem cert_e2248902768154 : check e2248902768154 [[]] .width = true := by decide
def e2248902864410 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902864410 : Closed e2248902864410 ∧ code e2248902864410 = 11044995886618 := by decide
theorem cert_e2248902864410 : check e2248902864410 [[]] .width = true := by decide
def e2248902867482 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902867482 : Closed e2248902867482 ∧ code e2248902867482 = 11044995889690 := by decide
theorem cert_e2248902867482 : check e2248902867482 [[]] .width = true := by decide
def e2248902915610 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902915610 : Closed e2248902915610 ∧ code e2248902915610 = 11044995937818 := by decide
theorem cert_e2248902915610 : check e2248902915610 [[]] .width = true := by decide
def e2248902916634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2248902916634 : Closed e2248902916634 ∧ code e2248902916634 = 11044995938842 := by decide
theorem cert_e2248902916634 : check e2248902916634 [[]] .width = true := by decide
def e2248976220358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248976220358 : Closed e2248976220358 ∧ code e2248976220358 = 11045069242566 := by decide
theorem cert_e2248976220358 : check e2248976220358 [[]] .width = true := by decide
def e2248976285894 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248976285894 : Closed e2248976285894 ∧ code e2248976285894 = 11045069308102 := by decide
theorem cert_e2248976285894 : check e2248976285894 [[]] .width = true := by decide
def e2248976744646 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248976744646 : Closed e2248976744646 ∧ code e2248976744646 = 11045069766854 := by decide
theorem cert_e2248976744646 : check e2248976744646 [[]] .width = true := by decide
def e2248976842950 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248976842950 : Closed e2248976842950 ∧ code e2248976842950 = 11045069865158 := by decide
theorem cert_e2248976842950 : check e2248976842950 [[]] .width = true := by decide
def e2248977072326 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248977072326 : Closed e2248977072326 ∧ code e2248977072326 = 11045070094534 := by decide
theorem cert_e2248977072326 : check e2248977072326 [[]] .width = true := by decide
def e2248977105094 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248977105094 : Closed e2248977105094 ∧ code e2248977105094 = 11045070127302 := by decide
theorem cert_e2248977105094 : check e2248977105094 [[]] .width = true := by decide
def e2248979366086 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248979366086 : Closed e2248979366086 ∧ code e2248979366086 = 11045072388294 := by decide
theorem cert_e2248979366086 : check e2248979366086 [[]] .width = true := by decide
def e2248979431622 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248979431622 : Closed e2248979431622 ∧ code e2248979431622 = 11045072453830 := by decide
theorem cert_e2248979431622 : check e2248979431622 [[]] .width = true := by decide
def e2248982511814 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248982511814 : Closed e2248982511814 ∧ code e2248982511814 = 11045075534022 := by decide
theorem cert_e2248982511814 : check e2248982511814 [[]] .width = true := by decide
def e2248982610118 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248982610118 : Closed e2248982610118 ∧ code e2248982610118 = 11045075632326 := by decide
theorem cert_e2248982610118 : check e2248982610118 [[]] .width = true := by decide
def e2248984150214 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248984150214 : Closed e2248984150214 ∧ code e2248984150214 = 11045077172422 := by decide
theorem cert_e2248984150214 : check e2248984150214 [[]] .width = true := by decide
def e2248984182982 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2248984182982 : Closed e2248984182982 ∧ code e2248984182982 = 11045077205190 := by decide
theorem cert_e2248984182982 : check e2248984182982 [[]] .width = true := by decide
def e2249070439962 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070439962 : Closed e2249070439962 ∧ code e2249070439962 = 11045163462170 := by decide
theorem cert_e2249070439962 : check e2249070439962 [[]] .width = true := by decide
def e2249070442010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070442010 : Closed e2249070442010 ∧ code e2249070442010 = 11045163464218 := by decide
theorem cert_e2249070442010 : check e2249070442010 [[]] .width = true := by decide
def e2249070456346 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070456346 : Closed e2249070456346 ∧ code e2249070456346 = 11045163478554 := by decide
theorem cert_e2249070456346 : check e2249070456346 [[]] .width = true := by decide
def e2249070459418 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070459418 : Closed e2249070459418 ∧ code e2249070459418 = 11045163481626 := by decide
theorem cert_e2249070459418 : check e2249070459418 [[]] .width = true := by decide
def e2249070466586 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070466586 : Closed e2249070466586 ∧ code e2249070466586 = 11045163488794 := by decide
theorem cert_e2249070466586 : check e2249070466586 [[]] .width = true := by decide
def e2249070467610 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070467610 : Closed e2249070467610 ∧ code e2249070467610 = 11045163489818 := by decide
theorem cert_e2249070467610 : check e2249070467610 [[]] .width = true := by decide
def e2249070538266 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070538266 : Closed e2249070538266 ∧ code e2249070538266 = 11045163560474 := by decide
theorem cert_e2249070538266 : check e2249070538266 [[]] .width = true := by decide
def e2249070540314 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070540314 : Closed e2249070540314 ∧ code e2249070540314 = 11045163562522 := by decide
theorem cert_e2249070540314 : check e2249070540314 [[]] .width = true := by decide
def e2249070636570 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070636570 : Closed e2249070636570 ∧ code e2249070636570 = 11045163658778 := by decide
theorem cert_e2249070636570 : check e2249070636570 [[]] .width = true := by decide
def e2249070639642 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070639642 : Closed e2249070639642 ∧ code e2249070639642 = 11045163661850 := by decide
theorem cert_e2249070639642 : check e2249070639642 [[]] .width = true := by decide
def e2249070687770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070687770 : Closed e2249070687770 ∧ code e2249070687770 = 11045163709978 := by decide
theorem cert_e2249070687770 : check e2249070687770 [[]] .width = true := by decide
def e2249070688794 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2249070688794 : Closed e2249070688794 ∧ code e2249070688794 = 11045163711002 := by decide
theorem cert_e2249070688794 : check e2249070688794 [[]] .width = true := by decide
def e2249153621358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2249153621358 : Closed e2249153621358 ∧ code e2249153621358 = 11045246643566 := by decide
theorem cert_e2249153621358 : check e2249153621358 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621366 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2249153621366 : Closed e2249153621366 ∧ code e2249153621366 = 11045246643574 := by decide
theorem cert_e2249153621366 : check e2249153621366 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2249153621422 : Closed e2249153621422 ∧ code e2249153621422 = 11045246643630 := by decide
theorem cert_e2249153621422 : check e2249153621422 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621434 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2249153621434 : Closed e2249153621434 ∧ code e2249153621434 = 11045246643642 := by decide
theorem cert_e2249153621434 : check e2249153621434 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621462 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2249153621462 : Closed e2249153621462 ∧ code e2249153621462 = 11045246643670 := by decide
theorem cert_e2249153621462 : check e2249153621462 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621466 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2249153621466 : Closed e2249153621466 ∧ code e2249153621466 = 11045246643674 := by decide
theorem cert_e2249153621466 : check e2249153621466 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621678 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2249153621678 : Closed e2249153621678 ∧ code e2249153621678 = 11045246643886 := by decide
theorem cert_e2249153621678 : check e2249153621678 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621690 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2249153621690 : Closed e2249153621690 ∧ code e2249153621690 = 11045246643898 := by decide
theorem cert_e2249153621690 : check e2249153621690 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621738 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2249153621738 : Closed e2249153621738 ∧ code e2249153621738 = 11045246643946 := by decide
theorem cert_e2249153621738 : check e2249153621738 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621846 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2249153621846 : Closed e2249153621846 ∧ code e2249153621846 = 11045246644054 := by decide
theorem cert_e2249153621846 : check e2249153621846 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621850 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2249153621850 : Closed e2249153621850 ∧ code e2249153621850 = 11045246644058 := by decide
theorem cert_e2249153621850 : check e2249153621850 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153621866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2249153621866 : Closed e2249153621866 ∧ code e2249153621866 = 11045246644074 := by decide
theorem cert_e2249153621866 : check e2249153621866 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153622894 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2249153622894 : Closed e2249153622894 ∧ code e2249153622894 = 11045246645102 := by decide
theorem cert_e2249153622894 : check e2249153622894 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153622902 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2249153622902 : Closed e2249153622902 ∧ code e2249153622902 = 11045246645110 := by decide
theorem cert_e2249153622902 : check e2249153622902 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153622958 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2249153622958 : Closed e2249153622958 ∧ code e2249153622958 = 11045246645166 := by decide
theorem cert_e2249153622958 : check e2249153622958 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153622970 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2249153622970 : Closed e2249153622970 ∧ code e2249153622970 = 11045246645178 := by decide
theorem cert_e2249153622970 : check e2249153622970 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153622998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2249153622998 : Closed e2249153622998 ∧ code e2249153622998 = 11045246645206 := by decide
theorem cert_e2249153622998 : check e2249153622998 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153623002 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2249153623002 : Closed e2249153623002 ∧ code e2249153623002 = 11045246645210 := by decide
theorem cert_e2249153623002 : check e2249153623002 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153623278 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2249153623278 : Closed e2249153623278 ∧ code e2249153623278 = 11045246645486 := by decide
theorem cert_e2249153623278 : check e2249153623278 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153623286 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2249153623286 : Closed e2249153623286 ∧ code e2249153623286 = 11045246645494 := by decide
theorem cert_e2249153623286 : check e2249153623286 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153623662 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2249153623662 : Closed e2249153623662 ∧ code e2249153623662 = 11045246645870 := by decide
theorem cert_e2249153623662 : check e2249153623662 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153623674 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2249153623674 : Closed e2249153623674 ∧ code e2249153623674 = 11045246645882 := by decide
theorem cert_e2249153623674 : check e2249153623674 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153623862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2249153623862 : Closed e2249153623862 ∧ code e2249153623862 = 11045246646070 := by decide
theorem cert_e2249153623862 : check e2249153623862 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153623866 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2249153623866 : Closed e2249153623866 ∧ code e2249153623866 = 11045246646074 := by decide
theorem cert_e2249153623866 : check e2249153623866 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153624494 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2249153624494 : Closed e2249153624494 ∧ code e2249153624494 = 11045246646702 := by decide
theorem cert_e2249153624494 : check e2249153624494 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153624506 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2249153624506 : Closed e2249153624506 ∧ code e2249153624506 = 11045246646714 := by decide
theorem cert_e2249153624506 : check e2249153624506 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153624554 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2249153624554 : Closed e2249153624554 ∧ code e2249153624554 = 11045246646762 := by decide
theorem cert_e2249153624554 : check e2249153624554 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153624686 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2249153624686 : Closed e2249153624686 ∧ code e2249153624686 = 11045246646894 := by decide
theorem cert_e2249153624686 : check e2249153624686 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153624698 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2249153624698 : Closed e2249153624698 ∧ code e2249153624698 = 11045246646906 := by decide
theorem cert_e2249153624698 : check e2249153624698 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153624986 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2249153624986 : Closed e2249153624986 ∧ code e2249153624986 = 11045246647194 := by decide
theorem cert_e2249153624986 : check e2249153624986 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153625302 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2249153625302 : Closed e2249153625302 ∧ code e2249153625302 = 11045246647510 := by decide
theorem cert_e2249153625302 : check e2249153625302 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153625306 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2249153625306 : Closed e2249153625306 ∧ code e2249153625306 = 11045246647514 := by decide
theorem cert_e2249153625306 : check e2249153625306 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153625322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2249153625322 : Closed e2249153625322 ∧ code e2249153625322 = 11045246647530 := by decide
theorem cert_e2249153625322 : check e2249153625322 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153625398 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2249153625398 : Closed e2249153625398 ∧ code e2249153625398 = 11045246647606 := by decide
theorem cert_e2249153625398 : check e2249153625398 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153625402 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2249153625402 : Closed e2249153625402 ∧ code e2249153625402 = 11045246647610 := by decide
theorem cert_e2249153625402 : check e2249153625402 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153625498 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2249153625498 : Closed e2249153625498 ∧ code e2249153625498 = 11045246647706 := by decide
theorem cert_e2249153625498 : check e2249153625498 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629038 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2249153629038 : Closed e2249153629038 ∧ code e2249153629038 = 11045246651246 := by decide
theorem cert_e2249153629038 : check e2249153629038 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629046 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2249153629046 : Closed e2249153629046 ∧ code e2249153629046 = 11045246651254 := by decide
theorem cert_e2249153629046 : check e2249153629046 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629102 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2249153629102 : Closed e2249153629102 ∧ code e2249153629102 = 11045246651310 := by decide
theorem cert_e2249153629102 : check e2249153629102 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629114 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2249153629114 : Closed e2249153629114 ∧ code e2249153629114 = 11045246651322 := by decide
theorem cert_e2249153629114 : check e2249153629114 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2249153629142 : Closed e2249153629142 ∧ code e2249153629142 = 11045246651350 := by decide
theorem cert_e2249153629142 : check e2249153629142 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2249153629146 : Closed e2249153629146 ∧ code e2249153629146 = 11045246651354 := by decide
theorem cert_e2249153629146 : check e2249153629146 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629422 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2249153629422 : Closed e2249153629422 ∧ code e2249153629422 = 11045246651630 := by decide
theorem cert_e2249153629422 : check e2249153629422 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629430 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2249153629430 : Closed e2249153629430 ∧ code e2249153629430 = 11045246651638 := by decide
theorem cert_e2249153629430 : check e2249153629430 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629806 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249153629806 : Closed e2249153629806 ∧ code e2249153629806 = 11045246652014 := by decide
theorem cert_e2249153629806 : check e2249153629806 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153629818 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249153629818 : Closed e2249153629818 ∧ code e2249153629818 = 11045246652026 := by decide
theorem cert_e2249153629818 : check e2249153629818 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153630006 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249153630006 : Closed e2249153630006 ∧ code e2249153630006 = 11045246652214 := by decide
theorem cert_e2249153630006 : check e2249153630006 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153630010 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249153630010 : Closed e2249153630010 ∧ code e2249153630010 = 11045246652218 := by decide
theorem cert_e2249153630010 : check e2249153630010 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153635758 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2249153635758 : Closed e2249153635758 ∧ code e2249153635758 = 11045246657966 := by decide
theorem cert_e2249153635758 : check e2249153635758 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153635770 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2249153635770 : Closed e2249153635770 ∧ code e2249153635770 = 11045246657978 := by decide
theorem cert_e2249153635770 : check e2249153635770 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153635818 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2249153635818 : Closed e2249153635818 ∧ code e2249153635818 = 11045246658026 := by decide
theorem cert_e2249153635818 : check e2249153635818 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153635950 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2249153635950 : Closed e2249153635950 ∧ code e2249153635950 = 11045246658158 := by decide
theorem cert_e2249153635950 : check e2249153635950 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153635962 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2249153635962 : Closed e2249153635962 ∧ code e2249153635962 = 11045246658170 := by decide
theorem cert_e2249153635962 : check e2249153635962 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153636250 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2249153636250 : Closed e2249153636250 ∧ code e2249153636250 = 11045246658458 := by decide
theorem cert_e2249153636250 : check e2249153636250 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153639126 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2249153639126 : Closed e2249153639126 ∧ code e2249153639126 = 11045246661334 := by decide
theorem cert_e2249153639126 : check e2249153639126 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153639130 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2249153639130 : Closed e2249153639130 ∧ code e2249153639130 = 11045246661338 := by decide
theorem cert_e2249153639130 : check e2249153639130 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153639146 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2249153639146 : Closed e2249153639146 ∧ code e2249153639146 = 11045246661354 := by decide
theorem cert_e2249153639146 : check e2249153639146 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153639222 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2249153639222 : Closed e2249153639222 ∧ code e2249153639222 = 11045246661430 := by decide
theorem cert_e2249153639222 : check e2249153639222 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153639226 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2249153639226 : Closed e2249153639226 ∧ code e2249153639226 = 11045246661434 := by decide
theorem cert_e2249153639226 : check e2249153639226 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153639322 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2249153639322 : Closed e2249153639322 ∧ code e2249153639322 = 11045246661530 := by decide
theorem cert_e2249153639322 : check e2249153639322 [[],[.under,.left],[.under]] .three = true := by decide
def e2249153754862 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2249153754862 : Closed e2249153754862 ∧ code e2249153754862 = 11045246777070 := by decide
theorem cert_e2249153754862 : check e2249153754862 [[],[.under,.left]] .chain = true := by decide
def e2249153754990 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2249153754990 : Closed e2249153754990 ∧ code e2249153754990 = 11045246777198 := by decide
theorem cert_e2249153754990 : check e2249153754990 [[],[.under,.left]] .chain = true := by decide
def e2249153754998 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2249153754998 : Closed e2249153754998 ∧ code e2249153754998 = 11045246777206 := by decide
theorem cert_e2249153754998 : check e2249153754998 [[],[.under,.left]] .chain = true := by decide
def e2249153755886 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2249153755886 : Closed e2249153755886 ∧ code e2249153755886 = 11045246778094 := by decide
theorem cert_e2249153755886 : check e2249153755886 [[],[.under,.left]] .chain = true := by decide
def e2249153756078 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2249153756078 : Closed e2249153756078 ∧ code e2249153756078 = 11045246778286 := by decide
theorem cert_e2249153756078 : check e2249153756078 [[],[.under,.left]] .chain = true := by decide
def e2249153756090 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2249153756090 : Closed e2249153756090 ∧ code e2249153756090 = 11045246778298 := by decide
theorem cert_e2249153756090 : check e2249153756090 [[],[.under,.left]] .chain = true := by decide
def e2249153756526 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2249153756526 : Closed e2249153756526 ∧ code e2249153756526 = 11045246778734 := by decide
theorem cert_e2249153756526 : check e2249153756526 [[],[.under,.left]] .chain = true := by decide
def e2249153756534 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2249153756534 : Closed e2249153756534 ∧ code e2249153756534 = 11045246778742 := by decide
theorem cert_e2249153756534 : check e2249153756534 [[],[.under,.left]] .chain = true := by decide
def e2249153756590 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2249153756590 : Closed e2249153756590 ∧ code e2249153756590 = 11045246778798 := by decide
theorem cert_e2249153756590 : check e2249153756590 [[],[.under,.left]] .chain = true := by decide
def e2249153756602 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2249153756602 : Closed e2249153756602 ∧ code e2249153756602 = 11045246778810 := by decide
theorem cert_e2249153756602 : check e2249153756602 [[],[.under,.left]] .chain = true := by decide
def e2249153756630 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2249153756630 : Closed e2249153756630 ∧ code e2249153756630 = 11045246778838 := by decide
theorem cert_e2249153756630 : check e2249153756630 [[],[.under,.left]] .chain = true := by decide
def e2249153756634 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2249153756634 : Closed e2249153756634 ∧ code e2249153756634 = 11045246778842 := by decide
theorem cert_e2249153756634 : check e2249153756634 [[],[.under,.left]] .chain = true := by decide
def e2249153761006 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2249153761006 : Closed e2249153761006 ∧ code e2249153761006 = 11045246783214 := by decide
theorem cert_e2249153761006 : check e2249153761006 [[],[.under,.left]] .chain = true := by decide
def e2249153761134 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2249153761134 : Closed e2249153761134 ∧ code e2249153761134 = 11045246783342 := by decide
theorem cert_e2249153761134 : check e2249153761134 [[],[.under,.left]] .chain = true := by decide
def e2249153761142 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2249153761142 : Closed e2249153761142 ∧ code e2249153761142 = 11045246783350 := by decide
theorem cert_e2249153761142 : check e2249153761142 [[],[.under,.left]] .chain = true := by decide
def e2249153763822 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2249153763822 : Closed e2249153763822 ∧ code e2249153763822 = 11045246786030 := by decide
theorem cert_e2249153763822 : check e2249153763822 [[],[.under,.left]] .chain = true := by decide
def e2249153764590 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2249153764590 : Closed e2249153764590 ∧ code e2249153764590 = 11045246786798 := by decide
theorem cert_e2249153764590 : check e2249153764590 [[],[.under,.left]] .chain = true := by decide
def e2249153764598 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2249153764598 : Closed e2249153764598 ∧ code e2249153764598 = 11045246786806 := by decide
theorem cert_e2249153764598 : check e2249153764598 [[],[.under,.left]] .chain = true := by decide
def e2249153767150 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2249153767150 : Closed e2249153767150 ∧ code e2249153767150 = 11045246789358 := by decide
theorem cert_e2249153767150 : check e2249153767150 [[],[.under,.left]] .chain = true := by decide
def e2249153767342 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2249153767342 : Closed e2249153767342 ∧ code e2249153767342 = 11045246789550 := by decide
theorem cert_e2249153767342 : check e2249153767342 [[],[.under,.left]] .chain = true := by decide
def e2249153767354 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2249153767354 : Closed e2249153767354 ∧ code e2249153767354 = 11045246789562 := by decide
theorem cert_e2249153767354 : check e2249153767354 [[],[.under,.left]] .chain = true := by decide
def e2249153767918 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2249153767918 : Closed e2249153767918 ∧ code e2249153767918 = 11045246790126 := by decide
theorem cert_e2249153767918 : check e2249153767918 [[],[.under,.left]] .chain = true := by decide
def e2249153769070 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2249153769070 : Closed e2249153769070 ∧ code e2249153769070 = 11045246791278 := by decide
theorem cert_e2249153769070 : check e2249153769070 [[],[.under,.left]] .chain = true := by decide
def e2249153769082 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2249153769082 : Closed e2249153769082 ∧ code e2249153769082 = 11045246791290 := by decide
theorem cert_e2249153769082 : check e2249153769082 [[],[.under,.left]] .chain = true := by decide
def e2249153770350 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2249153770350 : Closed e2249153770350 ∧ code e2249153770350 = 11045246792558 := by decide
theorem cert_e2249153770350 : check e2249153770350 [[],[.under,.left]] .chain = true := by decide
def e2249153770358 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2249153770358 : Closed e2249153770358 ∧ code e2249153770358 = 11045246792566 := by decide
theorem cert_e2249153770358 : check e2249153770358 [[],[.under,.left]] .chain = true := by decide
def e2249153770414 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2249153770414 : Closed e2249153770414 ∧ code e2249153770414 = 11045246792622 := by decide
theorem cert_e2249153770414 : check e2249153770414 [[],[.under,.left]] .chain = true := by decide
def e2249153770426 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2249153770426 : Closed e2249153770426 ∧ code e2249153770426 = 11045246792634 := by decide
theorem cert_e2249153770426 : check e2249153770426 [[],[.under,.left]] .chain = true := by decide
def e2249153770454 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2249153770454 : Closed e2249153770454 ∧ code e2249153770454 = 11045246792662 := by decide
theorem cert_e2249153770454 : check e2249153770454 [[],[.under,.left]] .chain = true := by decide
def e2249153770458 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2249153770458 : Closed e2249153770458 ∧ code e2249153770458 = 11045246792666 := by decide
theorem cert_e2249153770458 : check e2249153770458 [[],[.under,.left]] .chain = true := by decide
def e2249153770734 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2249153770734 : Closed e2249153770734 ∧ code e2249153770734 = 11045246792942 := by decide
theorem cert_e2249153770734 : check e2249153770734 [[],[.under,.left]] .chain = true := by decide
def e2249153770742 : Term := (.app (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2249153770742 : Closed e2249153770742 ∧ code e2249153770742 = 11045246792950 := by decide
theorem cert_e2249153770742 : check e2249153770742 [[],[.under,.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2248888146458
#print axioms Blc.Floor43.cert_e2248888244762
