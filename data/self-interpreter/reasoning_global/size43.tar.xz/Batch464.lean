import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406651830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.lam (.var 5))))) (.var 1)) (.var 1))))))
theorem wire_e2422406651830 : Closed e2422406651830 ∧ code e2422406651830 = 11218499674038 := by decide
theorem cert_e2422406651830 : check e2422406651830 [[],[]] .chain = true := by decide
def e2422406657902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 1)) (.var 2))))))
theorem wire_e2422406657902 : Closed e2422406657902 ∧ code e2422406657902 = 11218499680110 := by decide
theorem cert_e2422406657902 : check e2422406657902 [[],[]] .chain = true := by decide
def e2422406657910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 2)) (.var 1))))))
theorem wire_e2422406657910 : Closed e2422406657910 ∧ code e2422406657910 = 11218499680118 := by decide
theorem cert_e2422406657910 : check e2422406657910 [[],[]] .chain = true := by decide
def e2422406657966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 3))))) (.var 0)) (.var 2))))))
theorem wire_e2422406657966 : Closed e2422406657966 ∧ code e2422406657966 = 11218499680174 := by decide
theorem cert_e2422406657966 : check e2422406657966 [[],[]] .chain = true := by decide
def e2422406657978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 3))))) (.var 2)) (.var 0))))))
theorem wire_e2422406657978 : Closed e2422406657978 ∧ code e2422406657978 = 11218499680186 := by decide
theorem cert_e2422406657978 : check e2422406657978 [[],[]] .chain = true := by decide
def e2422406658006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 4))))) (.var 0)) (.var 1))))))
theorem wire_e2422406658006 : Closed e2422406658006 ∧ code e2422406658006 = 11218499680214 := by decide
theorem cert_e2422406658006 : check e2422406658006 [[],[]] .chain = true := by decide
def e2422406658010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 4))))) (.var 1)) (.var 0))))))
theorem wire_e2422406658010 : Closed e2422406658010 ∧ code e2422406658010 = 11218499680218 := by decide
theorem cert_e2422406658010 : check e2422406658010 [[],[]] .chain = true := by decide
def e2422406658926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.var 2))))))
theorem wire_e2422406658926 : Closed e2422406658926 ∧ code e2422406658926 = 11218499681134 := by decide
theorem cert_e2422406658926 : check e2422406658926 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406658934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 2)) (.var 1))))))
theorem wire_e2422406658934 : Closed e2422406658934 ∧ code e2422406658934 = 11218499681142 := by decide
theorem cert_e2422406658934 : check e2422406658934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406659438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422406659438 : Closed e2422406659438 ∧ code e2422406659438 = 11218499681646 := by decide
theorem cert_e2422406659438 : check e2422406659438 [[],[]] .chain = true := by decide
def e2422406659446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422406659446 : Closed e2422406659446 ∧ code e2422406659446 = 11218499681654 := by decide
theorem cert_e2422406659446 : check e2422406659446 [[],[]] .chain = true := by decide
def e2422406659758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422406659758 : Closed e2422406659758 ∧ code e2422406659758 = 11218499681966 := by decide
theorem cert_e2422406659758 : check e2422406659758 [[],[]] .chain = true := by decide
def e2422406659770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422406659770 : Closed e2422406659770 ∧ code e2422406659770 = 11218499681978 := by decide
theorem cert_e2422406659770 : check e2422406659770 [[],[]] .chain = true := by decide
def e2422406659926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422406659926 : Closed e2422406659926 ∧ code e2422406659926 = 11218499682134 := by decide
theorem cert_e2422406659926 : check e2422406659926 [[],[]] .chain = true := by decide
def e2422406659930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.app (.var 4) (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422406659930 : Closed e2422406659930 ∧ code e2422406659930 = 11218499682138 := by decide
theorem cert_e2422406659930 : check e2422406659930 [[],[]] .chain = true := by decide
def e2422406663918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2422406663918 : Closed e2422406663918 ∧ code e2422406663918 = 11218499686126 := by decide
theorem cert_e2422406663918 : check e2422406663918 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406664046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2422406664046 : Closed e2422406664046 ∧ code e2422406664046 = 11218499686254 := by decide
theorem cert_e2422406664046 : check e2422406664046 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406664054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2422406664054 : Closed e2422406664054 ∧ code e2422406664054 = 11218499686262 := by decide
theorem cert_e2422406664054 : check e2422406664054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406666734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406666734 : Closed e2422406666734 ∧ code e2422406666734 = 11218499688942 := by decide
theorem cert_e2422406666734 : check e2422406666734 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406667502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406667502 : Closed e2422406667502 ∧ code e2422406667502 = 11218499689710 := by decide
theorem cert_e2422406667502 : check e2422406667502 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406667510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406667510 : Closed e2422406667510 ∧ code e2422406667510 = 11218499689718 := by decide
theorem cert_e2422406667510 : check e2422406667510 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422406670190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422406670190 : Closed e2422406670190 ∧ code e2422406670190 = 11218499692398 := by decide
theorem cert_e2422406670190 : check e2422406670190 [[],[]] .chain = true := by decide
def e2422406670198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422406670198 : Closed e2422406670198 ∧ code e2422406670198 = 11218499692406 := by decide
theorem cert_e2422406670198 : check e2422406670198 [[],[]] .chain = true := by decide
def e2422406670262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422406670262 : Closed e2422406670262 ∧ code e2422406670262 = 11218499692470 := by decide
theorem cert_e2422406670262 : check e2422406670262 [[],[]] .chain = true := by decide
def e2422406671598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406671598 : Closed e2422406671598 ∧ code e2422406671598 = 11218499693806 := by decide
theorem cert_e2422406671598 : check e2422406671598 [[],[]] .chain = true := by decide
def e2422406671606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406671606 : Closed e2422406671606 ∧ code e2422406671606 = 11218499693814 := by decide
theorem cert_e2422406671606 : check e2422406671606 [[],[]] .chain = true := by decide
def e2422406671990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406671990 : Closed e2422406671990 ∧ code e2422406671990 = 11218499694198 := by decide
theorem cert_e2422406671990 : check e2422406671990 [[],[]] .chain = true := by decide
def e2422406673262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406673262 : Closed e2422406673262 ∧ code e2422406673262 = 11218499695470 := by decide
theorem cert_e2422406673262 : check e2422406673262 [[],[]] .chain = true := by decide
def e2422406673270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406673270 : Closed e2422406673270 ∧ code e2422406673270 = 11218499695478 := by decide
theorem cert_e2422406673270 : check e2422406673270 [[],[]] .chain = true := by decide
def e2422406673326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406673326 : Closed e2422406673326 ∧ code e2422406673326 = 11218499695534 := by decide
theorem cert_e2422406673326 : check e2422406673326 [[],[]] .chain = true := by decide
def e2422406673338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406673338 : Closed e2422406673338 ∧ code e2422406673338 = 11218499695546 := by decide
theorem cert_e2422406673338 : check e2422406673338 [[],[]] .chain = true := by decide
def e2422406673366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406673366 : Closed e2422406673366 ∧ code e2422406673366 = 11218499695574 := by decide
theorem cert_e2422406673366 : check e2422406673366 [[],[]] .chain = true := by decide
def e2422406673370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406673370 : Closed e2422406673370 ∧ code e2422406673370 = 11218499695578 := by decide
theorem cert_e2422406673370 : check e2422406673370 [[],[]] .chain = true := by decide
def e2422406673646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406673646 : Closed e2422406673646 ∧ code e2422406673646 = 11218499695854 := by decide
theorem cert_e2422406673646 : check e2422406673646 [[],[]] .chain = true := by decide
def e2422406673654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406673654 : Closed e2422406673654 ∧ code e2422406673654 = 11218499695862 := by decide
theorem cert_e2422406673654 : check e2422406673654 [[],[]] .chain = true := by decide
def e2422406674030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406674030 : Closed e2422406674030 ∧ code e2422406674030 = 11218499696238 := by decide
theorem cert_e2422406674030 : check e2422406674030 [[],[]] .chain = true := by decide
def e2422406674042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406674042 : Closed e2422406674042 ∧ code e2422406674042 = 11218499696250 := by decide
theorem cert_e2422406674042 : check e2422406674042 [[],[]] .chain = true := by decide
def e2422406674230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406674230 : Closed e2422406674230 ∧ code e2422406674230 = 11218499696438 := by decide
theorem cert_e2422406674230 : check e2422406674230 [[],[]] .chain = true := by decide
def e2422406674234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406674234 : Closed e2422406674234 ∧ code e2422406674234 = 11218499696442 := by decide
theorem cert_e2422406674234 : check e2422406674234 [[],[]] .chain = true := by decide
def e2422406674670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406674670 : Closed e2422406674670 ∧ code e2422406674670 = 11218499696878 := by decide
theorem cert_e2422406674670 : check e2422406674670 [[],[]] .chain = true := by decide
def e2422406674678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406674678 : Closed e2422406674678 ∧ code e2422406674678 = 11218499696886 := by decide
theorem cert_e2422406674678 : check e2422406674678 [[],[]] .chain = true := by decide
def e2422406674862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406674862 : Closed e2422406674862 ∧ code e2422406674862 = 11218499697070 := by decide
theorem cert_e2422406674862 : check e2422406674862 [[],[]] .chain = true := by decide
def e2422406674874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406674874 : Closed e2422406674874 ∧ code e2422406674874 = 11218499697082 := by decide
theorem cert_e2422406674874 : check e2422406674874 [[],[]] .chain = true := by decide
def e2422406674922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406674922 : Closed e2422406674922 ∧ code e2422406674922 = 11218499697130 := by decide
theorem cert_e2422406674922 : check e2422406674922 [[],[]] .chain = true := by decide
def e2422406675054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406675054 : Closed e2422406675054 ∧ code e2422406675054 = 11218499697262 := by decide
theorem cert_e2422406675054 : check e2422406675054 [[],[]] .chain = true := by decide
def e2422406675066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406675066 : Closed e2422406675066 ∧ code e2422406675066 = 11218499697274 := by decide
theorem cert_e2422406675066 : check e2422406675066 [[],[]] .chain = true := by decide
def e2422406675230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406675230 : Closed e2422406675230 ∧ code e2422406675230 = 11218499697438 := by decide
theorem cert_e2422406675230 : check e2422406675230 [[],[]] .chain = true := by decide
def e2422406675342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406675342 : Closed e2422406675342 ∧ code e2422406675342 = 11218499697550 := by decide
theorem cert_e2422406675342 : check e2422406675342 [[],[]] .chain = true := by decide
def e2422406675354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406675354 : Closed e2422406675354 ∧ code e2422406675354 = 11218499697562 := by decide
theorem cert_e2422406675354 : check e2422406675354 [[],[]] .chain = true := by decide
def e2422406675574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422406675574 : Closed e2422406675574 ∧ code e2422406675574 = 11218499697782 := by decide
theorem cert_e2422406675574 : check e2422406675574 [[],[]] .chain = true := by decide
def e2422406675670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422406675670 : Closed e2422406675670 ∧ code e2422406675670 = 11218499697878 := by decide
theorem cert_e2422406675670 : check e2422406675670 [[],[]] .chain = true := by decide
def e2422406675674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422406675674 : Closed e2422406675674 ∧ code e2422406675674 = 11218499697882 := by decide
theorem cert_e2422406675674 : check e2422406675674 [[],[]] .chain = true := by decide
def e2422406675690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422406675690 : Closed e2422406675690 ∧ code e2422406675690 = 11218499697898 := by decide
theorem cert_e2422406675690 : check e2422406675690 [[],[]] .chain = true := by decide
def e2422406675766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406675766 : Closed e2422406675766 ∧ code e2422406675766 = 11218499697974 := by decide
theorem cert_e2422406675766 : check e2422406675766 [[],[]] .chain = true := by decide
def e2422406675770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406675770 : Closed e2422406675770 ∧ code e2422406675770 = 11218499697978 := by decide
theorem cert_e2422406675770 : check e2422406675770 [[],[]] .chain = true := by decide
def e2422406675854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422406675854 : Closed e2422406675854 ∧ code e2422406675854 = 11218499698062 := by decide
theorem cert_e2422406675854 : check e2422406675854 [[],[]] .chain = true := by decide
def e2422406675866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406675866 : Closed e2422406675866 ∧ code e2422406675866 = 11218499698074 := by decide
theorem cert_e2422406675866 : check e2422406675866 [[],[]] .chain = true := by decide
def e2422406690158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406690158 : Closed e2422406690158 ∧ code e2422406690158 = 11218499712366 := by decide
theorem cert_e2422406690158 : check e2422406690158 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406690166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406690166 : Closed e2422406690166 ∧ code e2422406690166 = 11218499712374 := by decide
theorem cert_e2422406690166 : checkPay e2422406690166 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406690538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422406690538 : Closed e2422406690538 ∧ code e2422406690538 = 11218499712746 := by decide
theorem cert_e2422406690538 : check e2422406690538 [[],[]] .smaller = true := by decide
def e2422406690666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422406690666 : Closed e2422406690666 ∧ code e2422406690666 = 11218499712874 := by decide
theorem cert_e2422406690666 : check e2422406690666 [[],[]] .smaller = true := by decide
def e2422406691562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422406691562 : Closed e2422406691562 ∧ code e2422406691562 = 11218499713770 := by decide
theorem cert_e2422406691562 : check e2422406691562 [[],[]] .smaller = true := by decide
def e2422406691754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406691754 : Closed e2422406691754 ∧ code e2422406691754 = 11218499713962 := by decide
theorem cert_e2422406691754 : check e2422406691754 [[],[]] .smaller = true := by decide
def e2422406692202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0)) (.var 0))))))
theorem wire_e2422406692202 : Closed e2422406692202 ∧ code e2422406692202 = 11218499714410 := by decide
theorem cert_e2422406692202 : check e2422406692202 [[],[]] .smaller = true := by decide
def e2422406692266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406692266 : Closed e2422406692266 ∧ code e2422406692266 = 11218499714474 := by decide
theorem cert_e2422406692266 : check e2422406692266 [[],[]] .smaller = true := by decide
def e2422406694766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 1)) (.var 2))))))
theorem wire_e2422406694766 : Closed e2422406694766 ∧ code e2422406694766 = 11218499716974 := by decide
theorem cert_e2422406694766 : check e2422406694766 [[],[]] .chain = true := by decide
def e2422406694774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 2)) (.var 1))))))
theorem wire_e2422406694774 : Closed e2422406694774 ∧ code e2422406694774 = 11218499716982 := by decide
theorem cert_e2422406694774 : check e2422406694774 [[],[]] .chain = true := by decide
def e2422406694830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 3))))) (.var 0)) (.var 2))))))
theorem wire_e2422406694830 : Closed e2422406694830 ∧ code e2422406694830 = 11218499717038 := by decide
theorem cert_e2422406694830 : check e2422406694830 [[],[]] .chain = true := by decide
def e2422406694842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 3))))) (.var 2)) (.var 0))))))
theorem wire_e2422406694842 : Closed e2422406694842 ∧ code e2422406694842 = 11218499717050 := by decide
theorem cert_e2422406694842 : check e2422406694842 [[],[]] .chain = true := by decide
def e2422406694870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 4))))) (.var 0)) (.var 1))))))
theorem wire_e2422406694870 : Closed e2422406694870 ∧ code e2422406694870 = 11218499717078 := by decide
theorem cert_e2422406694870 : check e2422406694870 [[],[]] .chain = true := by decide
def e2422406694874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 4))))) (.var 1)) (.var 0))))))
theorem wire_e2422406694874 : Closed e2422406694874 ∧ code e2422406694874 = 11218499717082 := by decide
theorem cert_e2422406694874 : check e2422406694874 [[],[]] .chain = true := by decide
def e2422406696302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422406696302 : Closed e2422406696302 ∧ code e2422406696302 = 11218499718510 := by decide
theorem cert_e2422406696302 : check e2422406696302 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406696310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422406696310 : Closed e2422406696310 ∧ code e2422406696310 = 11218499718518 := by decide
theorem cert_e2422406696310 : check e2422406696310 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406696682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0)) (.var 0))))))
theorem wire_e2422406696682 : Closed e2422406696682 ∧ code e2422406696682 = 11218499718890 := by decide
theorem cert_e2422406696682 : check e2422406696682 [[],[]] .smaller = true := by decide
def e2422406696810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0)) (.var 0))))))
theorem wire_e2422406696810 : Closed e2422406696810 ∧ code e2422406696810 = 11218499719018 := by decide
theorem cert_e2422406696810 : check e2422406696810 [[],[]] .smaller = true := by decide
def e2422406697838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406697838 : Closed e2422406697838 ∧ code e2422406697838 = 11218499720046 := by decide
theorem cert_e2422406697838 : checkPay e2422406697838 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] 0 [] = true := by decide
def e2422406697846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406697846 : Closed e2422406697846 ∧ code e2422406697846 = 11218499720054 := by decide
theorem cert_e2422406697846 : check e2422406697846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[],[.left],[]] .identityHead = true := by decide
def e2422406697902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406697902 : Closed e2422406697902 ∧ code e2422406697902 = 11218499720110 := by decide
theorem cert_e2422406697902 : check e2422406697902 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406697914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406697914 : Closed e2422406697914 ∧ code e2422406697914 = 11218499720122 := by decide
theorem cert_e2422406697914 : check e2422406697914 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406697942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406697942 : Closed e2422406697942 ∧ code e2422406697942 = 11218499720150 := by decide
theorem cert_e2422406697942 : check e2422406697942 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422406697946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406697946 : Closed e2422406697946 ∧ code e2422406697946 = 11218499720154 := by decide
theorem cert_e2422406697946 : check e2422406697946 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2422406698222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406698222 : Closed e2422406698222 ∧ code e2422406698222 = 11218499720430 := by decide
theorem cert_e2422406698222 : check e2422406698222 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406698230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406698230 : Closed e2422406698230 ∧ code e2422406698230 = 11218499720438 := by decide
theorem cert_e2422406698230 : check e2422406698230 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406698606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406698606 : Closed e2422406698606 ∧ code e2422406698606 = 11218499720814 := by decide
theorem cert_e2422406698606 : check e2422406698606 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406698618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406698618 : Closed e2422406698618 ∧ code e2422406698618 = 11218499720826 := by decide
theorem cert_e2422406698618 : check e2422406698618 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406698806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406698806 : Closed e2422406698806 ∧ code e2422406698806 = 11218499721014 := by decide
theorem cert_e2422406698806 : check e2422406698806 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406698810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406698810 : Closed e2422406698810 ∧ code e2422406698810 = 11218499721018 := by decide
theorem cert_e2422406698810 : check e2422406698810 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406699246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406699246 : Closed e2422406699246 ∧ code e2422406699246 = 11218499721454 := by decide
theorem cert_e2422406699246 : check e2422406699246 [[],[]] .chain = true := by decide
def e2422406699254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406699254 : Closed e2422406699254 ∧ code e2422406699254 = 11218499721462 := by decide
theorem cert_e2422406699254 : check e2422406699254 [[],[]] .chain = true := by decide
def e2422406699806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406699806 : Closed e2422406699806 ∧ code e2422406699806 = 11218499722014 := by decide
theorem cert_e2422406699806 : check e2422406699806 [[],[]] .chain = true := by decide
def e2422406699918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 1)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406699918 : Closed e2422406699918 ∧ code e2422406699918 = 11218499722126 := by decide
theorem cert_e2422406699918 : check e2422406699918 [[],[]] .chain = true := by decide
def e2422406700142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406700142 : Closed e2422406700142 ∧ code e2422406700142 = 11218499722350 := by decide
theorem cert_e2422406700142 : check e2422406700142 [[],[]] .chain = true := by decide
def e2422406700154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406700154 : Closed e2422406700154 ∧ code e2422406700154 = 11218499722362 := by decide
theorem cert_e2422406700154 : check e2422406700154 [[],[]] .chain = true := by decide
def e2422406700318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406700318 : Closed e2422406700318 ∧ code e2422406700318 = 11218499722526 := by decide
theorem cert_e2422406700318 : check e2422406700318 [[],[]] .chain = true := by decide
def e2422406700486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406700486 : Closed e2422406700486 ∧ code e2422406700486 = 11218499722694 := by decide
theorem cert_e2422406700486 : check e2422406700486 [[],[]] .chain = true := by decide
def e2422406700598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406700598 : Closed e2422406700598 ∧ code e2422406700598 = 11218499722806 := by decide
theorem cert_e2422406700598 : check e2422406700598 [[],[]] .chain = true := by decide
def e2422406700602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406700602 : Closed e2422406700602 ∧ code e2422406700602 = 11218499722810 := by decide
theorem cert_e2422406700602 : check e2422406700602 [[],[]] .chain = true := by decide
def e2422406700686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406700686 : Closed e2422406700686 ∧ code e2422406700686 = 11218499722894 := by decide
theorem cert_e2422406700686 : check e2422406700686 [[],[]] .chain = true := by decide
def e2422406700742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 0) (.var 3)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406700742 : Closed e2422406700742 ∧ code e2422406700742 = 11218499722950 := by decide
theorem cert_e2422406700742 : check e2422406700742 [[],[]] .chain = true := by decide
def e2422406701934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 1)) (.var 2))))))
theorem wire_e2422406701934 : Closed e2422406701934 ∧ code e2422406701934 = 11218499724142 := by decide
theorem cert_e2422406701934 : check e2422406701934 [[],[]] .chain = true := by decide
def e2422406701942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 2)) (.var 1))))))
theorem wire_e2422406701942 : Closed e2422406701942 ∧ code e2422406701942 = 11218499724150 := by decide
theorem cert_e2422406701942 : check e2422406701942 [[],[]] .chain = true := by decide
def e2422406702826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0)) (.var 0))))))
theorem wire_e2422406702826 : Closed e2422406702826 ∧ code e2422406702826 = 11218499725034 := by decide
theorem cert_e2422406702826 : check e2422406702826 [[],[]] .smaller = true := by decide
def e2422406703018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422406703018 : Closed e2422406703018 ∧ code e2422406703018 = 11218499725226 := by decide
theorem cert_e2422406703018 : check e2422406703018 [[],[]] .smaller = true := by decide
def e2422406703342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406703342 : Closed e2422406703342 ∧ code e2422406703342 = 11218499725550 := by decide
theorem cert_e2422406703342 : check e2422406703342 [[],[]] .chain = true := by decide
def e2422406703350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406703350 : Closed e2422406703350 ∧ code e2422406703350 = 11218499725558 := by decide
theorem cert_e2422406703350 : check e2422406703350 [[],[]] .chain = true := by decide
def e2422406703902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406703902 : Closed e2422406703902 ∧ code e2422406703902 = 11218499726110 := by decide
theorem cert_e2422406703902 : check e2422406703902 [[],[]] .chain = true := by decide
def e2422406704014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 0)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406704014 : Closed e2422406704014 ∧ code e2422406704014 = 11218499726222 := by decide
theorem cert_e2422406704014 : check e2422406704014 [[],[]] .chain = true := by decide
def e2422406704686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406704686 : Closed e2422406704686 ∧ code e2422406704686 = 11218499726894 := by decide
theorem cert_e2422406704686 : check e2422406704686 [[],[]] .chain = true := by decide
def e2422406704866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406704866 : Closed e2422406704866 ∧ code e2422406704866 = 11218499727074 := by decide
theorem cert_e2422406704866 : check e2422406704866 [[],[]] .chain = true := by decide
def e2422406704878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.var 2))))))
theorem wire_e2422406704878 : Closed e2422406704878 ∧ code e2422406704878 = 11218499727086 := by decide
theorem cert_e2422406704878 : check e2422406704878 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406704918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406704918 : Closed e2422406704918 ∧ code e2422406704918 = 11218499727126 := by decide
theorem cert_e2422406704918 : check e2422406704918 [[],[]] .chain = true := by decide
def e2422406704994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406704994 : Closed e2422406704994 ∧ code e2422406704994 = 11218499727202 := by decide
theorem cert_e2422406704994 : check e2422406704994 [[],[]] .chain = true := by decide
def e2422406705006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.var 2))))))
theorem wire_e2422406705006 : Closed e2422406705006 ∧ code e2422406705006 = 11218499727214 := by decide
theorem cert_e2422406705006 : check e2422406705006 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406705014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 2)) (.var 1))))))
theorem wire_e2422406705014 : Closed e2422406705014 ∧ code e2422406705014 = 11218499727222 := by decide
theorem cert_e2422406705014 : check e2422406705014 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406705518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422406705518 : Closed e2422406705518 ∧ code e2422406705518 = 11218499727726 := by decide
theorem cert_e2422406705518 : check e2422406705518 [[],[]] .chain = true := by decide
def e2422406705526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422406705526 : Closed e2422406705526 ∧ code e2422406705526 = 11218499727734 := by decide
theorem cert_e2422406705526 : check e2422406705526 [[],[]] .chain = true := by decide
def e2422406705582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 1))))) (.var 0)) (.var 2))))))
theorem wire_e2422406705582 : Closed e2422406705582 ∧ code e2422406705582 = 11218499727790 := by decide
theorem cert_e2422406705582 : check e2422406705582 [[],[]] .chain = true := by decide
def e2422406705594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 1))))) (.var 2)) (.var 0))))))
theorem wire_e2422406705594 : Closed e2422406705594 ∧ code e2422406705594 = 11218499727802 := by decide
theorem cert_e2422406705594 : check e2422406705594 [[],[]] .chain = true := by decide
def e2422406706026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0)) (.var 0))))))
theorem wire_e2422406706026 : Closed e2422406706026 ∧ code e2422406706026 = 11218499728234 := by decide
theorem cert_e2422406706026 : check e2422406706026 [[],[]] .smaller = true := by decide
def e2422406706090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422406706090 : Closed e2422406706090 ∧ code e2422406706090 = 11218499728298 := by decide
theorem cert_e2422406706090 : check e2422406706090 [[],[]] .smaller = true := by decide
def e2422406706286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406706286 : Closed e2422406706286 ∧ code e2422406706286 = 11218499728494 := by decide
theorem cert_e2422406706286 : check e2422406706286 [[],[]] .chain = true := by decide
def e2422406706298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406706298 : Closed e2422406706298 ∧ code e2422406706298 = 11218499728506 := by decide
theorem cert_e2422406706298 : check e2422406706298 [[],[]] .chain = true := by decide
def e2422406706462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406706462 : Closed e2422406706462 ∧ code e2422406706462 = 11218499728670 := by decide
theorem cert_e2422406706462 : check e2422406706462 [[],[]] .chain = true := by decide
def e2422406706630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406706630 : Closed e2422406706630 ∧ code e2422406706630 = 11218499728838 := by decide
theorem cert_e2422406706630 : check e2422406706630 [[],[]] .chain = true := by decide
def e2422406706734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406706734 : Closed e2422406706734 ∧ code e2422406706734 = 11218499728942 := by decide
theorem cert_e2422406706734 : check e2422406706734 [[],[]] .chain = true := by decide
def e2422406706914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406706914 : Closed e2422406706914 ∧ code e2422406706914 = 11218499729122 := by decide
theorem cert_e2422406706914 : check e2422406706914 [[],[]] .chain = true := by decide
def e2422406706926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.var 2))))))
theorem wire_e2422406706926 : Closed e2422406706926 ∧ code e2422406706926 = 11218499729134 := by decide
theorem cert_e2422406706926 : check e2422406706926 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406707054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2422406707054 : Closed e2422406707054 ∧ code e2422406707054 = 11218499729262 := by decide
theorem cert_e2422406707054 : check e2422406707054 [[],[]] .chain = true := by decide
def e2422406707062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2422406707062 : Closed e2422406707062 ∧ code e2422406707062 = 11218499729270 := by decide
theorem cert_e2422406707062 : check e2422406707062 [[],[]] .chain = true := by decide
def e2422406707082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406707082 : Closed e2422406707082 ∧ code e2422406707082 = 11218499729290 := by decide
theorem cert_e2422406707082 : check e2422406707082 [[],[]] .chain = true := by decide
def e2422406707106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406707106 : Closed e2422406707106 ∧ code e2422406707106 = 11218499729314 := by decide
theorem cert_e2422406707106 : check e2422406707106 [[],[]] .chain = true := by decide
def e2422406707118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e2422406707118 : Closed e2422406707118 ∧ code e2422406707118 = 11218499729326 := by decide
theorem cert_e2422406707118 : check e2422406707118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406707126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 1)) (.var 1))))))
theorem wire_e2422406707126 : Closed e2422406707126 ∧ code e2422406707126 = 11218499729334 := by decide
theorem cert_e2422406707126 : check e2422406707126 [[],[]] .chain = true := by decide
def e2422406707130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e2422406707130 : Closed e2422406707130 ∧ code e2422406707130 = 11218499729338 := by decide
theorem cert_e2422406707130 : check e2422406707130 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406707382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 0))))) (.var 1)) (.var 1))))))
theorem wire_e2422406707382 : Closed e2422406707382 ∧ code e2422406707382 = 11218499729590 := by decide
theorem cert_e2422406707382 : check e2422406707382 [[],[]] .chain = true := by decide
def e2422406707414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e2422406707414 : Closed e2422406707414 ∧ code e2422406707414 = 11218499729622 := by decide
theorem cert_e2422406707414 : check e2422406707414 [[],[]] .chain = true := by decide
def e2422406707418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.lam (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e2422406707418 : Closed e2422406707418 ∧ code e2422406707418 = 11218499729626 := by decide
theorem cert_e2422406707418 : check e2422406707418 [[],[]] .chain = true := by decide
def e2422406707766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406707766 : Closed e2422406707766 ∧ code e2422406707766 = 11218499729974 := by decide
theorem cert_e2422406707766 : check e2422406707766 [[],[]] .chain = true := by decide
def e2422406707770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406707770 : Closed e2422406707770 ∧ code e2422406707770 = 11218499729978 := by decide
theorem cert_e2422406707770 : check e2422406707770 [[],[]] .chain = true := by decide
def e2422406707854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406707854 : Closed e2422406707854 ∧ code e2422406707854 = 11218499730062 := by decide
theorem cert_e2422406707854 : check e2422406707854 [[],[]] .chain = true := by decide
def e2422406707910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406707910 : Closed e2422406707910 ∧ code e2422406707910 = 11218499730118 := by decide
theorem cert_e2422406707910 : check e2422406707910 [[],[]] .chain = true := by decide
def e2422406707990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406707990 : Closed e2422406707990 ∧ code e2422406707990 = 11218499730198 := by decide
theorem cert_e2422406707990 : check e2422406707990 [[],[]] .chain = true := by decide
def e2422406708066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406708066 : Closed e2422406708066 ∧ code e2422406708066 = 11218499730274 := by decide
theorem cert_e2422406708066 : check e2422406708066 [[],[]] .chain = true := by decide
def e2422406708078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422406708078 : Closed e2422406708078 ∧ code e2422406708078 = 11218499730286 := by decide
theorem cert_e2422406708078 : check e2422406708078 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406708086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422406708086 : Closed e2422406708086 ∧ code e2422406708086 = 11218499730294 := by decide
theorem cert_e2422406708086 : check e2422406708086 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406708106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406708106 : Closed e2422406708106 ∧ code e2422406708106 = 11218499730314 := by decide
theorem cert_e2422406708106 : check e2422406708106 [[],[]] .chain = true := by decide
def e2422406708130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406708130 : Closed e2422406708130 ∧ code e2422406708130 = 11218499730338 := by decide
theorem cert_e2422406708130 : check e2422406708130 [[],[]] .chain = true := by decide
def e2422406708142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422406708142 : Closed e2422406708142 ∧ code e2422406708142 = 11218499730350 := by decide
theorem cert_e2422406708142 : check e2422406708142 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406708150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e2422406708150 : Closed e2422406708150 ∧ code e2422406708150 = 11218499730358 := by decide
theorem cert_e2422406708150 : check e2422406708150 [[],[]] .chain = true := by decide
def e2422406708154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422406708154 : Closed e2422406708154 ∧ code e2422406708154 = 11218499730362 := by decide
def e2422406708182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2422406708182 : Closed e2422406708182 ∧ code e2422406708182 = 11218499730390 := by decide
def e2422406708186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.app (.var 3) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2422406708186 : Closed e2422406708186 ∧ code e2422406708186 = 11218499730394 := by decide
theorem cert_e2422406708186 : check e2422406708186 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406713070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2422406713070 : Closed e2422406713070 ∧ code e2422406713070 = 11218499735278 := by decide
theorem cert_e2422406713070 : check e2422406713070 [[],[]] .chain = true := by decide
def e2422406713078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2422406713078 : Closed e2422406713078 ∧ code e2422406713078 = 11218499735286 := by decide
theorem cert_e2422406713078 : check e2422406713078 [[],[]] .chain = true := by decide
def e2422406713198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2422406713198 : Closed e2422406713198 ∧ code e2422406713198 = 11218499735406 := by decide
theorem cert_e2422406713198 : check e2422406713198 [[],[]] .chain = true := by decide
def e2422406713210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2422406713210 : Closed e2422406713210 ∧ code e2422406713210 = 11218499735418 := by decide
theorem cert_e2422406713210 : check e2422406713210 [[],[]] .chain = true := by decide
def e2422406713270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2422406713270 : Closed e2422406713270 ∧ code e2422406713270 = 11218499735478 := by decide
theorem cert_e2422406713270 : check e2422406713270 [[],[]] .chain = true := by decide
def e2422406713274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2422406713274 : Closed e2422406713274 ∧ code e2422406713274 = 11218499735482 := by decide
theorem cert_e2422406713274 : check e2422406713274 [[],[]] .chain = true := by decide
def e2422406716654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406716654 : Closed e2422406716654 ∧ code e2422406716654 = 11218499738862 := by decide
theorem cert_e2422406716654 : check e2422406716654 [[],[]] .chain = true := by decide
def e2422406716662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406716662 : Closed e2422406716662 ∧ code e2422406716662 = 11218499738870 := by decide
theorem cert_e2422406716662 : check e2422406716662 [[],[]] .chain = true := by decide
end Blc.Floor43
