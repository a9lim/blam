import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393371294150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2393371294150 : Closed e2393371294150 ∧ code e2393371294150 = 11189464316358 := by decide
theorem cert_e2393371294150 : check e2393371294150 [[],[.left],[]] .chain = true := by decide
def e2393371294174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 3))))))))
theorem wire_e2393371294174 : Closed e2393371294174 ∧ code e2393371294174 = 11189464316382 := by decide
theorem cert_e2393371294174 : checkPay e2393371294174 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371294198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 1))))))))
theorem wire_e2393371294198 : Closed e2393371294198 ∧ code e2393371294198 = 11189464316406 := by decide
theorem cert_e2393371294198 : checkPay e2393371294198 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371294918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2393371294918 : Closed e2393371294918 ∧ code e2393371294918 = 11189464317126 := by decide
theorem cert_e2393371294918 : check e2393371294918 [[],[.left],[]] .chain = true := by decide
def e2393371294942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 3))))))))
theorem wire_e2393371294942 : Closed e2393371294942 ∧ code e2393371294942 = 11189464317150 := by decide
theorem cert_e2393371294942 : checkPay e2393371294942 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371294958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393371294958 : Closed e2393371294958 ∧ code e2393371294958 = 11189464317166 := by decide
theorem cert_e2393371294958 : checkPay e2393371294958 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371294966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393371294966 : Closed e2393371294966 ∧ code e2393371294966 = 11189464317174 := by decide
theorem cert_e2393371294966 : checkPay e2393371294966 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371294970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.var 0))))))))
theorem wire_e2393371294970 : Closed e2393371294970 ∧ code e2393371294970 = 11189464317178 := by decide
theorem cert_e2393371294970 : checkPay e2393371294970 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393371296694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)))))))
theorem wire_e2393371296694 : Closed e2393371296694 ∧ code e2393371296694 = 11189464318902 := by decide
theorem cert_e2393371296694 : check e2393371296694 [[],[.left],[]] .chain = true := by decide
def e2393371296698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2393371296698 : Closed e2393371296698 ∧ code e2393371296698 = 11189464318906 := by decide
theorem cert_e2393371296698 : check e2393371296698 [[],[.left],[]] .chain = true := by decide
def e2393371296730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2393371296730 : Closed e2393371296730 ∧ code e2393371296730 = 11189464318938 := by decide
theorem cert_e2393371296730 : check e2393371296730 [[],[.left],[]] .chain = true := by decide
def e2393371297398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1))))))))
theorem wire_e2393371297398 : Closed e2393371297398 ∧ code e2393371297398 = 11189464319606 := by decide
theorem cert_e2393371297398 : check e2393371297398 [[],[.left],[]] .chain = true := by decide
def e2393371297590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371297590 : Closed e2393371297590 ∧ code e2393371297590 = 11189464319798 := by decide
theorem cert_e2393371297590 : check e2393371297590 [[],[.left],[]] .chain = true := by decide
def e2393371297594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371297594 : Closed e2393371297594 ∧ code e2393371297594 = 11189464319802 := by decide
theorem cert_e2393371297594 : check e2393371297594 [[],[.left],[]] .chain = true := by decide
def e2393371298646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e2393371298646 : Closed e2393371298646 ∧ code e2393371298646 = 11189464320854 := by decide
theorem cert_e2393371298646 : check e2393371298646 [[],[.left],[]] .chain = true := by decide
def e2393371298650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e2393371298650 : Closed e2393371298650 ∧ code e2393371298650 = 11189464320858 := by decide
theorem cert_e2393371298650 : check e2393371298650 [[],[.left],[]] .chain = true := by decide
def e2393371298666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)))))))
theorem wire_e2393371298666 : Closed e2393371298666 ∧ code e2393371298666 = 11189464320874 := by decide
theorem cert_e2393371298666 : check e2393371298666 [[],[.left],[]] .chain = true := by decide
def e2393371298730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)))))))
theorem wire_e2393371298730 : Closed e2393371298730 ∧ code e2393371298730 = 11189464320938 := by decide
theorem cert_e2393371298730 : check e2393371298730 [[],[.left],[]] .chain = true := by decide
def e2393371298934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2393371298934 : Closed e2393371298934 ∧ code e2393371298934 = 11189464321142 := by decide
theorem cert_e2393371298934 : check e2393371298934 [[],[.left],[]] .chain = true := by decide
def e2393371299030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2393371299030 : Closed e2393371299030 ∧ code e2393371299030 = 11189464321238 := by decide
theorem cert_e2393371299030 : check e2393371299030 [[],[.left],[]] .chain = true := by decide
def e2393371299034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)))))))
theorem wire_e2393371299034 : Closed e2393371299034 ∧ code e2393371299034 = 11189464321242 := by decide
theorem cert_e2393371299034 : check e2393371299034 [[],[.left],[]] .chain = true := by decide
def e2393371299050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)))))))
theorem wire_e2393371299050 : Closed e2393371299050 ∧ code e2393371299050 = 11189464321258 := by decide
theorem cert_e2393371299050 : check e2393371299050 [[],[.left],[]] .chain = true := by decide
def e2393371299126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371299126 : Closed e2393371299126 ∧ code e2393371299126 = 11189464321334 := by decide
theorem cert_e2393371299126 : check e2393371299126 [[],[.left],[]] .chain = true := by decide
def e2393371299130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371299130 : Closed e2393371299130 ∧ code e2393371299130 = 11189464321338 := by decide
theorem cert_e2393371299130 : check e2393371299130 [[],[.left],[]] .chain = true := by decide
def e2393371299214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2))))))))
theorem wire_e2393371299214 : Closed e2393371299214 ∧ code e2393371299214 = 11189464321422 := by decide
theorem cert_e2393371299214 : check e2393371299214 [[],[.left],[]] .chain = true := by decide
def e2393371299226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371299226 : Closed e2393371299226 ∧ code e2393371299226 = 11189464321434 := by decide
theorem cert_e2393371299226 : check e2393371299226 [[],[.left],[]] .chain = true := by decide
def e2393371299294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 3)))))))
theorem wire_e2393371299294 : Closed e2393371299294 ∧ code e2393371299294 = 11189464321502 := by decide
theorem cert_e2393371299294 : check e2393371299294 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371299310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 2)))))))
theorem wire_e2393371299310 : Closed e2393371299310 ∧ code e2393371299310 = 11189464321518 := by decide
theorem cert_e2393371299310 : check e2393371299310 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371299382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2393371299382 : Closed e2393371299382 ∧ code e2393371299382 = 11189464321590 := by decide
theorem cert_e2393371299382 : check e2393371299382 [[],[.left],[]] .chain = true := by decide
def e2393371299386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2393371299386 : Closed e2393371299386 ∧ code e2393371299386 = 11189464321594 := by decide
theorem cert_e2393371299386 : check e2393371299386 [[],[.left],[]] .chain = true := by decide
def e2393371299434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2393371299434 : Closed e2393371299434 ∧ code e2393371299434 = 11189464321642 := by decide
theorem cert_e2393371299434 : check e2393371299434 [[],[.left],[]] .chain = true := by decide
def e2393371299470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2393371299470 : Closed e2393371299470 ∧ code e2393371299470 = 11189464321678 := by decide
theorem cert_e2393371299470 : check e2393371299470 [[],[.left],[]] .chain = true := by decide
def e2393371299482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371299482 : Closed e2393371299482 ∧ code e2393371299482 = 11189464321690 := by decide
theorem cert_e2393371299482 : check e2393371299482 [[],[.left],[]] .chain = true := by decide
def e2393371299526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2393371299526 : Closed e2393371299526 ∧ code e2393371299526 = 11189464321734 := by decide
theorem cert_e2393371299526 : check e2393371299526 [[],[.left],[]] .chain = true := by decide
def e2393371299550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 3)))))))
theorem wire_e2393371299550 : Closed e2393371299550 ∧ code e2393371299550 = 11189464321758 := by decide
theorem cert_e2393371299550 : check e2393371299550 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371299574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.var 1)))))))
theorem wire_e2393371299574 : Closed e2393371299574 ∧ code e2393371299574 = 11189464321782 := by decide
theorem cert_e2393371299574 : check e2393371299574 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371299678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 3)))))))
theorem wire_e2393371299678 : Closed e2393371299678 ∧ code e2393371299678 = 11189464321886 := by decide
theorem cert_e2393371299678 : check e2393371299678 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371299706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.var 0)))))))
theorem wire_e2393371299706 : Closed e2393371299706 ∧ code e2393371299706 = 11189464321914 := by decide
theorem cert_e2393371299706 : check e2393371299706 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371299758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 2)))))))
theorem wire_e2393371299758 : Closed e2393371299758 ∧ code e2393371299758 = 11189464321966 := by decide
theorem cert_e2393371299758 : check e2393371299758 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371299766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.var 1)))))))
theorem wire_e2393371299766 : Closed e2393371299766 ∧ code e2393371299766 = 11189464321974 := by decide
theorem cert_e2393371299766 : check e2393371299766 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371299770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.var 0)))))))
theorem wire_e2393371299770 : Closed e2393371299770 ∧ code e2393371299770 = 11189464321978 := by decide
theorem cert_e2393371299770 : check e2393371299770 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371300078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2393371300078 : Closed e2393371300078 ∧ code e2393371300078 = 11189464322286 := by decide
theorem cert_e2393371300078 : check e2393371300078 [[],[.left],[]] .chain = true := by decide
def e2393371300086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2393371300086 : Closed e2393371300086 ∧ code e2393371300086 = 11189464322294 := by decide
theorem cert_e2393371300086 : check e2393371300086 [[],[.left],[]] .chain = true := by decide
def e2393371300566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2393371300566 : Closed e2393371300566 ∧ code e2393371300566 = 11189464322774 := by decide
theorem cert_e2393371300566 : check e2393371300566 [[],[.left],[]] .chain = true := by decide
def e2393371300570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2393371300570 : Closed e2393371300570 ∧ code e2393371300570 = 11189464322778 := by decide
theorem cert_e2393371300570 : check e2393371300570 [[],[.left],[]] .chain = true := by decide
def e2393371300586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2393371300586 : Closed e2393371300586 ∧ code e2393371300586 = 11189464322794 := by decide
theorem cert_e2393371300586 : check e2393371300586 [[],[.left],[]] .chain = true := by decide
def e2393371300662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393371300662 : Closed e2393371300662 ∧ code e2393371300662 = 11189464322870 := by decide
theorem cert_e2393371300662 : check e2393371300662 [[],[.left],[]] .chain = true := by decide
def e2393371300666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393371300666 : Closed e2393371300666 ∧ code e2393371300666 = 11189464322874 := by decide
theorem cert_e2393371300666 : check e2393371300666 [[],[.left],[]] .chain = true := by decide
def e2393371300750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2393371300750 : Closed e2393371300750 ∧ code e2393371300750 = 11189464322958 := by decide
theorem cert_e2393371300750 : check e2393371300750 [[],[.left],[]] .chain = true := by decide
def e2393371300762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371300762 : Closed e2393371300762 ∧ code e2393371300762 = 11189464322970 := by decide
theorem cert_e2393371300762 : check e2393371300762 [[],[.left],[]] .chain = true := by decide
def e2393371300830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 3))))))))
theorem wire_e2393371300830 : Closed e2393371300830 ∧ code e2393371300830 = 11189464323038 := by decide
theorem cert_e2393371300830 : check e2393371300830 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371300846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 2))))))))
theorem wire_e2393371300846 : Closed e2393371300846 ∧ code e2393371300846 = 11189464323054 := by decide
theorem cert_e2393371300846 : check e2393371300846 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371302006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2393371302006 : Closed e2393371302006 ∧ code e2393371302006 = 11189464324214 := by decide
theorem cert_e2393371302006 : check e2393371302006 [[],[.left],[]] .chain = true := by decide
def e2393371302250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2393371302250 : Closed e2393371302250 ∧ code e2393371302250 = 11189464324458 := by decide
theorem cert_e2393371302250 : check e2393371302250 [[],[.left],[]] .chain = true := by decide
def e2393371302286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2393371302286 : Closed e2393371302286 ∧ code e2393371302286 = 11189464324494 := by decide
theorem cert_e2393371302286 : check e2393371302286 [[],[.left],[]] .chain = true := by decide
def e2393371302298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393371302298 : Closed e2393371302298 ∧ code e2393371302298 = 11189464324506 := by decide
theorem cert_e2393371302298 : check e2393371302298 [[],[.left],[]] .chain = true := by decide
def e2393371302342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2393371302342 : Closed e2393371302342 ∧ code e2393371302342 = 11189464324550 := by decide
theorem cert_e2393371302342 : check e2393371302342 [[],[.left],[]] .chain = true := by decide
def e2393371302366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 3))))))))
theorem wire_e2393371302366 : Closed e2393371302366 ∧ code e2393371302366 = 11189464324574 := by decide
theorem cert_e2393371302366 : check e2393371302366 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371302390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 3) (.var 1))))))))
theorem wire_e2393371302390 : Closed e2393371302390 ∧ code e2393371302390 = 11189464324598 := by decide
theorem cert_e2393371302390 : check e2393371302390 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371303134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 3))))))))
theorem wire_e2393371303134 : Closed e2393371303134 ∧ code e2393371303134 = 11189464325342 := by decide
theorem cert_e2393371303134 : check e2393371303134 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371303162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 3) (.var 0))))))))
theorem wire_e2393371303162 : Closed e2393371303162 ∧ code e2393371303162 = 11189464325370 := by decide
theorem cert_e2393371303162 : check e2393371303162 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371303534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371303534 : Closed e2393371303534 ∧ code e2393371303534 = 11189464325742 := by decide
theorem cert_e2393371303534 : check e2393371303534 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371303542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393371303542 : Closed e2393371303542 ∧ code e2393371303542 = 11189464325750 := by decide
theorem cert_e2393371303542 : check e2393371303542 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371303546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371303546 : Closed e2393371303546 ∧ code e2393371303546 = 11189464325754 := by decide
theorem cert_e2393371303546 : check e2393371303546 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371304758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371304758 : Closed e2393371304758 ∧ code e2393371304758 = 11189464326966 := by decide
theorem cert_e2393371304758 : check e2393371304758 [[],[.left],[]] .chain = true := by decide
def e2393371304762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371304762 : Closed e2393371304762 ∧ code e2393371304762 = 11189464326970 := by decide
theorem cert_e2393371304762 : check e2393371304762 [[],[.left],[]] .chain = true := by decide
def e2393371304858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.lam (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2393371304858 : Closed e2393371304858 ∧ code e2393371304858 = 11189464327066 := by decide
theorem cert_e2393371304858 : check e2393371304858 [[],[.left],[]] .chain = true := by decide
def e2393371305526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 1)))) (.var 1)))))))
theorem wire_e2393371305526 : Closed e2393371305526 ∧ code e2393371305526 = 11189464327734 := by decide
theorem cert_e2393371305526 : check e2393371305526 [[],[.left],[]] .chain = true := by decide
def e2393371305530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2393371305530 : Closed e2393371305530 ∧ code e2393371305530 = 11189464327738 := by decide
theorem cert_e2393371305530 : check e2393371305530 [[],[.left],[]] .chain = true := by decide
def e2393371305614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.lam (.var 2))))))))
theorem wire_e2393371305614 : Closed e2393371305614 ∧ code e2393371305614 = 11189464327822 := by decide
theorem cert_e2393371305614 : check e2393371305614 [[],[.left],[]] .chain = true := by decide
def e2393371305670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.lam (.var 1))))))))
theorem wire_e2393371305670 : Closed e2393371305670 ∧ code e2393371305670 = 11189464327878 := by decide
theorem cert_e2393371305670 : check e2393371305670 [[],[.left],[]] .chain = true := by decide
def e2393371305694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 3)))))))
theorem wire_e2393371305694 : Closed e2393371305694 ∧ code e2393371305694 = 11189464327902 := by decide
theorem cert_e2393371305694 : check e2393371305694 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371305710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2393371305710 : Closed e2393371305710 ∧ code e2393371305710 = 11189464327918 := by decide
theorem cert_e2393371305710 : check e2393371305710 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371305718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 3))) (.var 1)))))))
theorem wire_e2393371305718 : Closed e2393371305718 ∧ code e2393371305718 = 11189464327926 := by decide
theorem cert_e2393371305718 : check e2393371305718 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371305754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.lam (.var 1)))) (.var 0)))))))
theorem wire_e2393371305754 : Closed e2393371305754 ∧ code e2393371305754 = 11189464327962 := by decide
theorem cert_e2393371305754 : check e2393371305754 [[],[.left],[]] .chain = true := by decide
def e2393371305798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.lam (.var 1))))))))
theorem wire_e2393371305798 : Closed e2393371305798 ∧ code e2393371305798 = 11189464328006 := by decide
theorem cert_e2393371305798 : check e2393371305798 [[],[.left],[]] .chain = true := by decide
def e2393371305822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 3)))))))
theorem wire_e2393371305822 : Closed e2393371305822 ∧ code e2393371305822 = 11189464328030 := by decide
theorem cert_e2393371305822 : check e2393371305822 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371305838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2393371305838 : Closed e2393371305838 ∧ code e2393371305838 = 11189464328046 := by decide
theorem cert_e2393371305838 : check e2393371305838 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371305846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2393371305846 : Closed e2393371305846 ∧ code e2393371305846 = 11189464328054 := by decide
theorem cert_e2393371305846 : check e2393371305846 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371305850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 3))) (.var 0)))))))
theorem wire_e2393371305850 : Closed e2393371305850 ∧ code e2393371305850 = 11189464328058 := by decide
theorem cert_e2393371305850 : check e2393371305850 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371305902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2393371305902 : Closed e2393371305902 ∧ code e2393371305902 = 11189464328110 := by decide
theorem cert_e2393371305902 : check e2393371305902 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371305910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2393371305910 : Closed e2393371305910 ∧ code e2393371305910 = 11189464328118 := by decide
theorem cert_e2393371305910 : check e2393371305910 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371305914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2393371305914 : Closed e2393371305914 ∧ code e2393371305914 = 11189464328122 := by decide
theorem cert_e2393371305914 : check e2393371305914 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371305942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 0))) (.var 1)))))))
theorem wire_e2393371305942 : Closed e2393371305942 ∧ code e2393371305942 = 11189464328150 := by decide
theorem cert_e2393371305942 : check e2393371305942 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371305946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 3) (.var 1))) (.var 0)))))))
theorem wire_e2393371305946 : Closed e2393371305946 ∧ code e2393371305946 = 11189464328154 := by decide
theorem cert_e2393371305946 : check e2393371305946 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371306382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2393371306382 : Closed e2393371306382 ∧ code e2393371306382 = 11189464328590 := by decide
theorem cert_e2393371306382 : check e2393371306382 [[],[.left],[]] .chain = true := by decide
def e2393371306438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2393371306438 : Closed e2393371306438 ∧ code e2393371306438 = 11189464328646 := by decide
theorem cert_e2393371306438 : check e2393371306438 [[],[.left],[]] .chain = true := by decide
def e2393371306462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 3))))))))
theorem wire_e2393371306462 : Closed e2393371306462 ∧ code e2393371306462 = 11189464328670 := by decide
theorem cert_e2393371306462 : check e2393371306462 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371306478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2393371306478 : Closed e2393371306478 ∧ code e2393371306478 = 11189464328686 := by decide
theorem cert_e2393371306478 : check e2393371306478 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371306486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 3) (.var 1))))))))
theorem wire_e2393371306486 : Closed e2393371306486 ∧ code e2393371306486 = 11189464328694 := by decide
theorem cert_e2393371306486 : check e2393371306486 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371307206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2393371307206 : Closed e2393371307206 ∧ code e2393371307206 = 11189464329414 := by decide
theorem cert_e2393371307206 : check e2393371307206 [[],[.left],[]] .chain = true := by decide
def e2393371307230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 3))))))))
theorem wire_e2393371307230 : Closed e2393371307230 ∧ code e2393371307230 = 11189464329438 := by decide
theorem cert_e2393371307230 : check e2393371307230 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371307246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2393371307246 : Closed e2393371307246 ∧ code e2393371307246 = 11189464329454 := by decide
theorem cert_e2393371307246 : check e2393371307246 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371307254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2393371307254 : Closed e2393371307254 ∧ code e2393371307254 = 11189464329462 := by decide
theorem cert_e2393371307254 : check e2393371307254 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371307258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 3) (.var 0))))))))
theorem wire_e2393371307258 : Closed e2393371307258 ∧ code e2393371307258 = 11189464329466 := by decide
theorem cert_e2393371307258 : check e2393371307258 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371307630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2393371307630 : Closed e2393371307630 ∧ code e2393371307630 = 11189464329838 := by decide
theorem cert_e2393371307630 : check e2393371307630 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371307638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2393371307638 : Closed e2393371307638 ∧ code e2393371307638 = 11189464329846 := by decide
theorem cert_e2393371307638 : check e2393371307638 [[],[.left],[],[.under,.under,.left]] .chain = true := by decide
def e2393371307642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2393371307642 : Closed e2393371307642 ∧ code e2393371307642 = 11189464329850 := by decide
theorem cert_e2393371307642 : check e2393371307642 [[],[.left],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393371307830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem wire_e2393371307830 : Closed e2393371307830 ∧ code e2393371307830 = 11189464330038 := by decide
private def t_e2393371307830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 0) (.var 1))))))))
theorem cert_e2393371307830 : ¬ IsSelfInterpreter e2393371307830 :=
  wSource (t := t_e2393371307830) (replay_sound (ps := []) (t := e2393371307830) (by decide)) (by decide)
def e2393371307834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem wire_e2393371307834 : Closed e2393371307834 ∧ code e2393371307834 = 11189464330042 := by decide
private def t_e2393371307834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 3)) (.app (.var 1) (.var 0))))))))
theorem cert_e2393371307834 : ¬ IsSelfInterpreter e2393371307834 :=
  wSource (t := t_e2393371307834) (replay_sound (ps := []) (t := e2393371307834) (by decide)) (by decide)
def e2393371315054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2393371315054 : Closed e2393371315054 ∧ code e2393371315054 = 11189464337262 := by decide
theorem cert_e2393371315054 : check e2393371315054 [[],[.left],[]] .smaller = true := by decide
def e2393371315062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2393371315062 : Closed e2393371315062 ∧ code e2393371315062 = 11189464337270 := by decide
theorem cert_e2393371315062 : check e2393371315062 [[],[.left],[]] .smaller = true := by decide
def e2393371315118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2393371315118 : Closed e2393371315118 ∧ code e2393371315118 = 11189464337326 := by decide
theorem cert_e2393371315118 : check e2393371315118 [[],[.left],[]] .smaller = true := by decide
def e2393371315130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2393371315130 : Closed e2393371315130 ∧ code e2393371315130 = 11189464337338 := by decide
theorem cert_e2393371315130 : check e2393371315130 [[],[.left],[]] .smaller = true := by decide
def e2393371315158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2393371315158 : Closed e2393371315158 ∧ code e2393371315158 = 11189464337366 := by decide
theorem cert_e2393371315158 : check e2393371315158 [[],[.left],[]] .smaller = true := by decide
def e2393371315162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2393371315162 : Closed e2393371315162 ∧ code e2393371315162 = 11189464337370 := by decide
theorem cert_e2393371315162 : check e2393371315162 [[],[.left],[]] .smaller = true := by decide
def e2393371315438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2393371315438 : Closed e2393371315438 ∧ code e2393371315438 = 11189464337646 := by decide
theorem cert_e2393371315438 : check e2393371315438 [[],[.left],[]] .smaller = true := by decide
def e2393371315446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2393371315446 : Closed e2393371315446 ∧ code e2393371315446 = 11189464337654 := by decide
theorem cert_e2393371315446 : check e2393371315446 [[],[.left],[]] .smaller = true := by decide
def e2393371315822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2393371315822 : Closed e2393371315822 ∧ code e2393371315822 = 11189464338030 := by decide
theorem cert_e2393371315822 : check e2393371315822 [[],[.left],[]] .smaller = true := by decide
def e2393371315834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2393371315834 : Closed e2393371315834 ∧ code e2393371315834 = 11189464338042 := by decide
theorem cert_e2393371315834 : check e2393371315834 [[],[.left],[]] .smaller = true := by decide
def e2393371316022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2393371316022 : Closed e2393371316022 ∧ code e2393371316022 = 11189464338230 := by decide
theorem cert_e2393371316022 : check e2393371316022 [[],[.left],[]] .smaller = true := by decide
def e2393371316026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2393371316026 : Closed e2393371316026 ∧ code e2393371316026 = 11189464338234 := by decide
theorem cert_e2393371316026 : check e2393371316026 [[],[.left],[]] .smaller = true := by decide
def e2393371323838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))))
theorem wire_e2393371323838 : Closed e2393371323838 ∧ code e2393371323838 = 11189464346046 := by decide
theorem cert_e2393371323838 : check e2393371323838 [[],[.left],[]] .chain = true := by decide
def e2393371323894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))))
theorem wire_e2393371323894 : Closed e2393371323894 ∧ code e2393371323894 = 11189464346102 := by decide
theorem cert_e2393371323894 : check e2393371323894 [[],[.left],[]] .chain = true := by decide
def e2393371324094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))))
theorem wire_e2393371324094 : Closed e2393371324094 ∧ code e2393371324094 = 11189464346302 := by decide
theorem cert_e2393371324094 : check e2393371324094 [[],[.left],[]] .chain = true := by decide
def e2393371324154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))))
theorem wire_e2393371324154 : Closed e2393371324154 ∧ code e2393371324154 = 11189464346362 := by decide
theorem cert_e2393371324154 : check e2393371324154 [[],[.left],[]] .chain = true := by decide
def e2393371324374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))))
theorem wire_e2393371324374 : Closed e2393371324374 ∧ code e2393371324374 = 11189464346582 := by decide
theorem cert_e2393371324374 : check e2393371324374 [[],[.left],[]] .chain = true := by decide
def e2393371324378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))))
theorem wire_e2393371324378 : Closed e2393371324378 ∧ code e2393371324378 = 11189464346586 := by decide
theorem cert_e2393371324378 : check e2393371324378 [[],[.left],[]] .chain = true := by decide
def e2393371325374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))))
theorem wire_e2393371325374 : Closed e2393371325374 ∧ code e2393371325374 = 11189464347582 := by decide
theorem cert_e2393371325374 : check e2393371325374 [[],[.left],[]] .chain = true := by decide
def e2393371325430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))))
theorem wire_e2393371325430 : Closed e2393371325430 ∧ code e2393371325430 = 11189464347638 := by decide
theorem cert_e2393371325430 : check e2393371325430 [[],[.left],[]] .chain = true := by decide
def e2393371326910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))))
theorem wire_e2393371326910 : Closed e2393371326910 ∧ code e2393371326910 = 11189464349118 := by decide
theorem cert_e2393371326910 : check e2393371326910 [[],[.left],[]] .chain = true := by decide
def e2393371326970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))))
theorem wire_e2393371326970 : Closed e2393371326970 ∧ code e2393371326970 = 11189464349178 := by decide
theorem cert_e2393371326970 : check e2393371326970 [[],[.left],[]] .chain = true := by decide
def e2393371328310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393371328310 : Closed e2393371328310 ∧ code e2393371328310 = 11189464350518 := by decide
theorem cert_e2393371328310 : check e2393371328310 [[],[.left],[]] .chain = true := by decide
def e2393371328314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393371328314 : Closed e2393371328314 ∧ code e2393371328314 = 11189464350522 := by decide
theorem cert_e2393371328314 : check e2393371328314 [[],[.left],[]] .chain = true := by decide
def e2393371356526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2393371356526 : Closed e2393371356526 ∧ code e2393371356526 = 11189464378734 := by decide
theorem cert_e2393371356526 : check e2393371356526 [[],[.left],[]] .chain = true := by decide
def e2393371356534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2393371356534 : Closed e2393371356534 ∧ code e2393371356534 = 11189464378742 := by decide
theorem cert_e2393371356534 : check e2393371356534 [[],[.left],[]] .chain = true := by decide
def e2393371356590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2393371356590 : Closed e2393371356590 ∧ code e2393371356590 = 11189464378798 := by decide
theorem cert_e2393371356590 : check e2393371356590 [[],[.left],[]] .chain = true := by decide
def e2393371356602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2393371356602 : Closed e2393371356602 ∧ code e2393371356602 = 11189464378810 := by decide
theorem cert_e2393371356602 : check e2393371356602 [[],[.left],[]] .chain = true := by decide
def e2393371356630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2393371356630 : Closed e2393371356630 ∧ code e2393371356630 = 11189464378838 := by decide
theorem cert_e2393371356630 : check e2393371356630 [[],[.left],[]] .chain = true := by decide
def e2393371356634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2393371356634 : Closed e2393371356634 ∧ code e2393371356634 = 11189464378842 := by decide
theorem cert_e2393371356634 : check e2393371356634 [[],[.left],[]] .chain = true := by decide
def e2393371356846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2393371356846 : Closed e2393371356846 ∧ code e2393371356846 = 11189464379054 := by decide
theorem cert_e2393371356846 : check e2393371356846 [[],[.left],[]] .chain = true := by decide
def e2393371356858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2393371356858 : Closed e2393371356858 ∧ code e2393371356858 = 11189464379066 := by decide
theorem cert_e2393371356858 : check e2393371356858 [[],[.left],[]] .chain = true := by decide
def e2393371356906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2393371356906 : Closed e2393371356906 ∧ code e2393371356906 = 11189464379114 := by decide
theorem cert_e2393371356906 : check e2393371356906 [[],[.left],[]] .chain = true := by decide
def e2393371357014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2393371357014 : Closed e2393371357014 ∧ code e2393371357014 = 11189464379222 := by decide
theorem cert_e2393371357014 : check e2393371357014 [[],[.left],[]] .chain = true := by decide
def e2393371357018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2393371357018 : Closed e2393371357018 ∧ code e2393371357018 = 11189464379226 := by decide
theorem cert_e2393371357018 : check e2393371357018 [[],[.left],[]] .chain = true := by decide
def e2393371357034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2393371357034 : Closed e2393371357034 ∧ code e2393371357034 = 11189464379242 := by decide
theorem cert_e2393371357034 : check e2393371357034 [[],[.left],[]] .chain = true := by decide
def e2393371357662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2393371357662 : Closed e2393371357662 ∧ code e2393371357662 = 11189464379870 := by decide
theorem cert_e2393371357662 : check e2393371357662 [[],[.left],[]] .chain = true := by decide
def e2393371357686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2393371357686 : Closed e2393371357686 ∧ code e2393371357686 = 11189464379894 := by decide
theorem cert_e2393371357686 : check e2393371357686 [[],[.left],[]] .chain = true := by decide
def e2393371358062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2393371358062 : Closed e2393371358062 ∧ code e2393371358062 = 11189464380270 := by decide
theorem cert_e2393371358062 : check e2393371358062 [[],[.left],[]] .chain = true := by decide
def e2393371358070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2393371358070 : Closed e2393371358070 ∧ code e2393371358070 = 11189464380278 := by decide
theorem cert_e2393371358070 : check e2393371358070 [[],[.left],[]] .chain = true := by decide
def e2393371358126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2393371358126 : Closed e2393371358126 ∧ code e2393371358126 = 11189464380334 := by decide
theorem cert_e2393371358126 : check e2393371358126 [[],[.left],[]] .chain = true := by decide
def e2393371358138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2393371358138 : Closed e2393371358138 ∧ code e2393371358138 = 11189464380346 := by decide
theorem cert_e2393371358138 : check e2393371358138 [[],[.left],[]] .chain = true := by decide
def e2393371358166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2393371358166 : Closed e2393371358166 ∧ code e2393371358166 = 11189464380374 := by decide
theorem cert_e2393371358166 : check e2393371358166 [[],[.left],[]] .chain = true := by decide
def e2393371358170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2393371358170 : Closed e2393371358170 ∧ code e2393371358170 = 11189464380378 := by decide
theorem cert_e2393371358170 : check e2393371358170 [[],[.left],[]] .chain = true := by decide
def e2393371358446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393371358446 : Closed e2393371358446 ∧ code e2393371358446 = 11189464380654 := by decide
theorem cert_e2393371358446 : check e2393371358446 [[],[.left],[]] .chain = true := by decide
def e2393371358454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393371358454 : Closed e2393371358454 ∧ code e2393371358454 = 11189464380662 := by decide
theorem cert_e2393371358454 : check e2393371358454 [[],[.left],[]] .chain = true := by decide
def e2393371358782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2393371358782 : Closed e2393371358782 ∧ code e2393371358782 = 11189464380990 := by decide
theorem cert_e2393371358782 : check e2393371358782 [[],[.left],[]] .chain = true := by decide
def e2393371358830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393371358830 : Closed e2393371358830 ∧ code e2393371358830 = 11189464381038 := by decide
theorem cert_e2393371358830 : check e2393371358830 [[],[.left],[]] .chain = true := by decide
def e2393371358842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393371358842 : Closed e2393371358842 ∧ code e2393371358842 = 11189464381050 := by decide
theorem cert_e2393371358842 : check e2393371358842 [[],[.left],[]] .chain = true := by decide
def e2393371359030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393371359030 : Closed e2393371359030 ∧ code e2393371359030 = 11189464381238 := by decide
theorem cert_e2393371359030 : check e2393371359030 [[],[.left],[]] .chain = true := by decide
def e2393371359034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393371359034 : Closed e2393371359034 ∧ code e2393371359034 = 11189464381242 := by decide
theorem cert_e2393371359034 : check e2393371359034 [[],[.left],[]] .chain = true := by decide
def e2393371359118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2393371359118 : Closed e2393371359118 ∧ code e2393371359118 = 11189464381326 := by decide
theorem cert_e2393371359118 : check e2393371359118 [[],[.left],[]] .chain = true := by decide
def e2393371359454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2393371359454 : Closed e2393371359454 ∧ code e2393371359454 = 11189464381662 := by decide
theorem cert_e2393371359454 : check e2393371359454 [[],[.left],[]] .chain = true := by decide
def e2393371359470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2393371359470 : Closed e2393371359470 ∧ code e2393371359470 = 11189464381678 := by decide
theorem cert_e2393371359470 : check e2393371359470 [[],[.left],[]] .chain = true := by decide
def e2393371359478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2393371359478 : Closed e2393371359478 ∧ code e2393371359478 = 11189464381686 := by decide
theorem cert_e2393371359478 : check e2393371359478 [[],[.left],[]] .chain = true := by decide
def e2393371359482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2393371359482 : Closed e2393371359482 ∧ code e2393371359482 = 11189464381690 := by decide
theorem cert_e2393371359482 : check e2393371359482 [[],[.left],[]] .chain = true := by decide
def e2393371359662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2393371359662 : Closed e2393371359662 ∧ code e2393371359662 = 11189464381870 := by decide
theorem cert_e2393371359662 : check e2393371359662 [[],[.left],[]] .chain = true := by decide
def e2393371359674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2393371359674 : Closed e2393371359674 ∧ code e2393371359674 = 11189464381882 := by decide
theorem cert_e2393371359674 : check e2393371359674 [[],[.left],[]] .chain = true := by decide
def e2393371359722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2393371359722 : Closed e2393371359722 ∧ code e2393371359722 = 11189464381930 := by decide
theorem cert_e2393371359722 : check e2393371359722 [[],[.left],[]] .chain = true := by decide
def e2393371359806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2393371359806 : Closed e2393371359806 ∧ code e2393371359806 = 11189464382014 := by decide
theorem cert_e2393371359806 : check e2393371359806 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393371307830
#print axioms Blc.Floor43.cert_e2393371307834
