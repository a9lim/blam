import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407210414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2422407210414 : Closed e2422407210414 ∧ code e2422407210414 = 11218500232622 := by decide
theorem cert_e2422407210414 : check e2422407210414 [[],[]] .chain = true := by decide
def e2422407210426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2422407210426 : Closed e2422407210426 ∧ code e2422407210426 = 11218500232634 := by decide
theorem cert_e2422407210426 : check e2422407210426 [[],[]] .chain = true := by decide
def e2422407210474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407210474 : Closed e2422407210474 ∧ code e2422407210474 = 11218500232682 := by decide
theorem cert_e2422407210474 : check e2422407210474 [[],[]] .chain = true := by decide
def e2422407210606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407210606 : Closed e2422407210606 ∧ code e2422407210606 = 11218500232814 := by decide
theorem cert_e2422407210606 : check e2422407210606 [[],[]] .chain = true := by decide
def e2422407210618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407210618 : Closed e2422407210618 ∧ code e2422407210618 = 11218500232826 := by decide
theorem cert_e2422407210618 : check e2422407210618 [[],[]] .chain = true := by decide
def e2422407210782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407210782 : Closed e2422407210782 ∧ code e2422407210782 = 11218500232990 := by decide
theorem cert_e2422407210782 : check e2422407210782 [[],[]] .chain = true := by decide
def e2422407210894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407210894 : Closed e2422407210894 ∧ code e2422407210894 = 11218500233102 := by decide
theorem cert_e2422407210894 : check e2422407210894 [[],[]] .chain = true := by decide
def e2422407210906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407210906 : Closed e2422407210906 ∧ code e2422407210906 = 11218500233114 := by decide
theorem cert_e2422407210906 : check e2422407210906 [[],[]] .chain = true := by decide
def e2422407213854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407213854 : Closed e2422407213854 ∧ code e2422407213854 = 11218500236062 := by decide
theorem cert_e2422407213854 : check e2422407213854 [[],[]] .chain = true := by decide
def e2422407214022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407214022 : Closed e2422407214022 ∧ code e2422407214022 = 11218500236230 := by decide
theorem cert_e2422407214022 : check e2422407214022 [[],[]] .chain = true := by decide
def e2422407215222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2422407215222 : Closed e2422407215222 ∧ code e2422407215222 = 11218500237430 := by decide
theorem cert_e2422407215222 : check e2422407215222 [[],[]] .chain = true := by decide
def e2422407215466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2422407215466 : Closed e2422407215466 ∧ code e2422407215466 = 11218500237674 := by decide
theorem cert_e2422407215466 : check e2422407215466 [[],[]] .chain = true := by decide
def e2422407215502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407215502 : Closed e2422407215502 ∧ code e2422407215502 = 11218500237710 := by decide
theorem cert_e2422407215502 : check e2422407215502 [[],[]] .chain = true := by decide
def e2422407215514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407215514 : Closed e2422407215514 ∧ code e2422407215514 = 11218500237722 := by decide
theorem cert_e2422407215514 : check e2422407215514 [[],[]] .chain = true := by decide
def e2422407215558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407215558 : Closed e2422407215558 ∧ code e2422407215558 = 11218500237766 := by decide
theorem cert_e2422407215558 : check e2422407215558 [[],[]] .chain = true := by decide
def e2422407217646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422407217646 : Closed e2422407217646 ∧ code e2422407217646 = 11218500239854 := by decide
theorem cert_e2422407217646 : check e2422407217646 [[],[]] .chain = true := by decide
def e2422407217654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2422407217654 : Closed e2422407217654 ∧ code e2422407217654 = 11218500239862 := by decide
theorem cert_e2422407217654 : check e2422407217654 [[],[]] .chain = true := by decide
def e2422407218030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2422407218030 : Closed e2422407218030 ∧ code e2422407218030 = 11218500240238 := by decide
theorem cert_e2422407218030 : check e2422407218030 [[],[]] .chain = true := by decide
def e2422407218042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e2422407218042 : Closed e2422407218042 ∧ code e2422407218042 = 11218500240250 := by decide
theorem cert_e2422407218042 : check e2422407218042 [[],[]] .chain = true := by decide
def e2422407218094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2422407218094 : Closed e2422407218094 ∧ code e2422407218094 = 11218500240302 := by decide
theorem cert_e2422407218094 : check e2422407218094 [[],[]] .chain = true := by decide
def e2422407218154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e2422407218154 : Closed e2422407218154 ∧ code e2422407218154 = 11218500240362 := by decide
theorem cert_e2422407218154 : check e2422407218154 [[],[]] .chain = true := by decide
def e2422407218414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407218414 : Closed e2422407218414 ∧ code e2422407218414 = 11218500240622 := by decide
theorem cert_e2422407218414 : check e2422407218414 [[],[]] .chain = true := by decide
def e2422407218422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407218422 : Closed e2422407218422 ∧ code e2422407218422 = 11218500240630 := by decide
theorem cert_e2422407218422 : check e2422407218422 [[],[]] .chain = true := by decide
def e2422407218798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407218798 : Closed e2422407218798 ∧ code e2422407218798 = 11218500241006 := by decide
theorem cert_e2422407218798 : check e2422407218798 [[],[]] .chain = true := by decide
def e2422407218810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407218810 : Closed e2422407218810 ∧ code e2422407218810 = 11218500241018 := by decide
theorem cert_e2422407218810 : check e2422407218810 [[],[]] .chain = true := by decide
def e2422407218974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422407218974 : Closed e2422407218974 ∧ code e2422407218974 = 11218500241182 := by decide
theorem cert_e2422407218974 : check e2422407218974 [[],[]] .chain = true := by decide
def e2422407219086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2422407219086 : Closed e2422407219086 ∧ code e2422407219086 = 11218500241294 := by decide
theorem cert_e2422407219086 : check e2422407219086 [[],[]] .chain = true := by decide
def e2422407219098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407219098 : Closed e2422407219098 ∧ code e2422407219098 = 11218500241306 := by decide
theorem cert_e2422407219098 : check e2422407219098 [[],[]] .chain = true := by decide
def e2422407220334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422407220334 : Closed e2422407220334 ∧ code e2422407220334 = 11218500242542 := by decide
theorem cert_e2422407220334 : check e2422407220334 [[],[]] .chain = true := by decide
def e2422407220346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407220346 : Closed e2422407220346 ∧ code e2422407220346 = 11218500242554 := by decide
theorem cert_e2422407220346 : check e2422407220346 [[],[]] .chain = true := by decide
def e2422407220510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422407220510 : Closed e2422407220510 ∧ code e2422407220510 = 11218500242718 := by decide
theorem cert_e2422407220510 : check e2422407220510 [[],[]] .chain = true := by decide
def e2422407220678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407220678 : Closed e2422407220678 ∧ code e2422407220678 = 11218500242886 := by decide
theorem cert_e2422407220678 : check e2422407220678 [[],[]] .chain = true := by decide
def e2422407220782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407220782 : Closed e2422407220782 ∧ code e2422407220782 = 11218500242990 := by decide
theorem cert_e2422407220782 : check e2422407220782 [[],[]] .chain = true := by decide
def e2422407220962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407220962 : Closed e2422407220962 ∧ code e2422407220962 = 11218500243170 := by decide
theorem cert_e2422407220962 : check e2422407220962 [[],[]] .chain = true := by decide
def e2422407220974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2422407220974 : Closed e2422407220974 ∧ code e2422407220974 = 11218500243182 := by decide
theorem cert_e2422407220974 : check e2422407220974 [[],[]] .sourceHead = true := by decide
def e2422407221014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407221014 : Closed e2422407221014 ∧ code e2422407221014 = 11218500243222 := by decide
theorem cert_e2422407221014 : check e2422407221014 [[],[]] .chain = true := by decide
def e2422407221018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422407221018 : Closed e2422407221018 ∧ code e2422407221018 = 11218500243226 := by decide
theorem cert_e2422407221018 : check e2422407221018 [[],[]] .chain = true := by decide
def e2422407221062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422407221062 : Closed e2422407221062 ∧ code e2422407221062 = 11218500243270 := by decide
theorem cert_e2422407221062 : check e2422407221062 [[],[]] .chain = true := by decide
def e2422407221090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407221090 : Closed e2422407221090 ∧ code e2422407221090 = 11218500243298 := by decide
theorem cert_e2422407221090 : check e2422407221090 [[],[]] .chain = true := by decide
def e2422407221102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2422407221102 : Closed e2422407221102 ∧ code e2422407221102 = 11218500243310 := by decide
theorem cert_e2422407221102 : check e2422407221102 [[],[]] .sourceHead = true := by decide
def e2422407221110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2422407221110 : Closed e2422407221110 ∧ code e2422407221110 = 11218500243318 := by decide
theorem cert_e2422407221110 : check e2422407221110 [[],[]] .sourceHead = true := by decide
def e2422407221470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2422407221470 : Closed e2422407221470 ∧ code e2422407221470 = 11218500243678 := by decide
theorem cert_e2422407221470 : check e2422407221470 [[],[]] .chain = true := by decide
def e2422407221498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2422407221498 : Closed e2422407221498 ∧ code e2422407221498 = 11218500243706 := by decide
theorem cert_e2422407221498 : check e2422407221498 [[],[]] .chain = true := by decide
def e2422407222046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407222046 : Closed e2422407222046 ∧ code e2422407222046 = 11218500244254 := by decide
theorem cert_e2422407222046 : check e2422407222046 [[],[]] .chain = true := by decide
def e2422407222214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407222214 : Closed e2422407222214 ∧ code e2422407222214 = 11218500244422 := by decide
theorem cert_e2422407222214 : check e2422407222214 [[],[]] .chain = true := by decide
def e2422407223358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2422407223358 : Closed e2422407223358 ∧ code e2422407223358 = 11218500245566 := by decide
theorem cert_e2422407223358 : check e2422407223358 [[],[]] .chain = true := by decide
def e2422407223778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407223778 : Closed e2422407223778 ∧ code e2422407223778 = 11218500245986 := by decide
theorem cert_e2422407223778 : check e2422407223778 [[],[]] .chain = true := by decide
def e2422407223790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407223790 : Closed e2422407223790 ∧ code e2422407223790 = 11218500245998 := by decide
theorem cert_e2422407223790 : check e2422407223790 [[],[]] .sourceHead = true := by decide
def e2422407224350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2422407224350 : Closed e2422407224350 ∧ code e2422407224350 = 11218500246558 := by decide
theorem cert_e2422407224350 : check e2422407224350 [[],[]] .chain = true := by decide
def e2422407224374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407224374 : Closed e2422407224374 ∧ code e2422407224374 = 11218500246582 := by decide
theorem cert_e2422407224374 : check e2422407224374 [[],[]] .chain = true := by decide
def e2422407224378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407224378 : Closed e2422407224378 ∧ code e2422407224378 = 11218500246586 := by decide
theorem cert_e2422407224378 : check e2422407224378 [[],[]] .chain = true := by decide
def e2422407224518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407224518 : Closed e2422407224518 ∧ code e2422407224518 = 11218500246726 := by decide
theorem cert_e2422407224518 : check e2422407224518 [[],[]] .chain = true := by decide
def e2422407224546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407224546 : Closed e2422407224546 ∧ code e2422407224546 = 11218500246754 := by decide
theorem cert_e2422407224546 : check e2422407224546 [[],[]] .chain = true := by decide
def e2422407224558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407224558 : Closed e2422407224558 ∧ code e2422407224558 = 11218500246766 := by decide
theorem cert_e2422407224558 : check e2422407224558 [[],[]] .sourceHead = true := by decide
def e2422407224566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407224566 : Closed e2422407224566 ∧ code e2422407224566 = 11218500246774 := by decide
theorem cert_e2422407224566 : check e2422407224566 [[],[]] .sourceHead = true := by decide
def e2422407225582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422407225582 : Closed e2422407225582 ∧ code e2422407225582 = 11218500247790 := by decide
theorem cert_e2422407225582 : check e2422407225582 [[],[]] .chain = true := by decide
def e2422407225594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2422407225594 : Closed e2422407225594 ∧ code e2422407225594 = 11218500247802 := by decide
theorem cert_e2422407225594 : check e2422407225594 [[],[]] .chain = true := by decide
def e2422407225966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407225966 : Closed e2422407225966 ∧ code e2422407225966 = 11218500248174 := by decide
theorem cert_e2422407225966 : check e2422407225966 [[],[]] .chain = true := by decide
def e2422407225978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407225978 : Closed e2422407225978 ∧ code e2422407225978 = 11218500248186 := by decide
theorem cert_e2422407225978 : check e2422407225978 [[],[]] .chain = true := by decide
def e2422407226142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422407226142 : Closed e2422407226142 ∧ code e2422407226142 = 11218500248350 := by decide
theorem cert_e2422407226142 : check e2422407226142 [[],[]] .chain = true := by decide
def e2422407226310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2422407226310 : Closed e2422407226310 ∧ code e2422407226310 = 11218500248518 := by decide
theorem cert_e2422407226310 : check e2422407226310 [[],[]] .chain = true := by decide
def e2422407226926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422407226926 : Closed e2422407226926 ∧ code e2422407226926 = 11218500249134 := by decide
theorem cert_e2422407226926 : check e2422407226926 [[],[]] .chain = true := by decide
def e2422407227106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422407227106 : Closed e2422407227106 ∧ code e2422407227106 = 11218500249314 := by decide
theorem cert_e2422407227106 : check e2422407227106 [[],[]] .chain = true := by decide
def e2422407227118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422407227118 : Closed e2422407227118 ∧ code e2422407227118 = 11218500249326 := by decide
theorem cert_e2422407227118 : check e2422407227118 [[],[]] .sourceHead = true := by decide
def e2422407227274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407227274 : Closed e2422407227274 ∧ code e2422407227274 = 11218500249482 := by decide
theorem cert_e2422407227274 : check e2422407227274 [[],[]] .chain = true := by decide
def e2422407227298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407227298 : Closed e2422407227298 ∧ code e2422407227298 = 11218500249506 := by decide
theorem cert_e2422407227298 : check e2422407227298 [[],[]] .chain = true := by decide
def e2422407227310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422407227310 : Closed e2422407227310 ∧ code e2422407227310 = 11218500249518 := by decide
theorem cert_e2422407227310 : check e2422407227310 [[],[]] .sourceHead = true := by decide
def e2422407227322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422407227322 : Closed e2422407227322 ∧ code e2422407227322 = 11218500249530 := by decide
theorem cert_e2422407227322 : check e2422407227322 [[],[]] .sourceHead = true := by decide
def e2422407227454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2422407227454 : Closed e2422407227454 ∧ code e2422407227454 = 11218500249662 := by decide
theorem cert_e2422407227454 : check e2422407227454 [[],[]] .chain = true := by decide
def e2422407227874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422407227874 : Closed e2422407227874 ∧ code e2422407227874 = 11218500250082 := by decide
theorem cert_e2422407227874 : check e2422407227874 [[],[]] .chain = true := by decide
def e2422407227886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422407227886 : Closed e2422407227886 ∧ code e2422407227886 = 11218500250094 := by decide
theorem cert_e2422407227886 : check e2422407227886 [[],[]] .sourceHead = true := by decide
def e2422407228942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407228942 : Closed e2422407228942 ∧ code e2422407228942 = 11218500251150 := by decide
theorem cert_e2422407228942 : check e2422407228942 [[],[]] .chain = true := by decide
def e2422407229026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407229026 : Closed e2422407229026 ∧ code e2422407229026 = 11218500251234 := by decide
theorem cert_e2422407229026 : check e2422407229026 [[],[]] .chain = true := by decide
def e2422407229038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407229038 : Closed e2422407229038 ∧ code e2422407229038 = 11218500251246 := by decide
theorem cert_e2422407229038 : check e2422407229038 [[],[]] .sourceHead = true := by decide
def e2422407229050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407229050 : Closed e2422407229050 ∧ code e2422407229050 = 11218500251258 := by decide
theorem cert_e2422407229050 : check e2422407229050 [[],[]] .sourceHead = true := by decide
def e2422407229558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422407229558 : Closed e2422407229558 ∧ code e2422407229558 = 11218500251766 := by decide
theorem cert_e2422407229558 : check e2422407229558 [[],[]] .chain = true := by decide
def e2422407229562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422407229562 : Closed e2422407229562 ∧ code e2422407229562 = 11218500251770 := by decide
theorem cert_e2422407229562 : check e2422407229562 [[],[]] .chain = true := by decide
def e2422407229658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407229658 : Closed e2422407229658 ∧ code e2422407229658 = 11218500251866 := by decide
theorem cert_e2422407229658 : check e2422407229658 [[],[]] .chain = true := by decide
def e2422407229674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407229674 : Closed e2422407229674 ∧ code e2422407229674 = 11218500251882 := by decide
theorem cert_e2422407229674 : check e2422407229674 [[],[]] .chain = true := by decide
def e2422407229750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407229750 : Closed e2422407229750 ∧ code e2422407229750 = 11218500251958 := by decide
theorem cert_e2422407229750 : check e2422407229750 [[],[]] .chain = true := by decide
def e2422407229754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407229754 : Closed e2422407229754 ∧ code e2422407229754 = 11218500251962 := by decide
theorem cert_e2422407229754 : check e2422407229754 [[],[]] .chain = true := by decide
def e2422407229838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422407229838 : Closed e2422407229838 ∧ code e2422407229838 = 11218500252046 := by decide
theorem cert_e2422407229838 : check e2422407229838 [[],[]] .chain = true := by decide
def e2422407229850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407229850 : Closed e2422407229850 ∧ code e2422407229850 = 11218500252058 := by decide
theorem cert_e2422407229850 : check e2422407229850 [[],[]] .chain = true := by decide
def e2422407229894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422407229894 : Closed e2422407229894 ∧ code e2422407229894 = 11218500252102 := by decide
theorem cert_e2422407229894 : check e2422407229894 [[],[]] .chain = true := by decide
def e2422407230230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422407230230 : Closed e2422407230230 ∧ code e2422407230230 = 11218500252438 := by decide
theorem cert_e2422407230230 : check e2422407230230 [[],[]] .chain = true := by decide
def e2422407230234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422407230234 : Closed e2422407230234 ∧ code e2422407230234 = 11218500252442 := by decide
theorem cert_e2422407230234 : check e2422407230234 [[],[]] .chain = true := by decide
def e2422407230278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422407230278 : Closed e2422407230278 ∧ code e2422407230278 = 11218500252486 := by decide
theorem cert_e2422407230278 : check e2422407230278 [[],[]] .chain = true := by decide
def e2422407230306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422407230306 : Closed e2422407230306 ∧ code e2422407230306 = 11218500252514 := by decide
theorem cert_e2422407230306 : check e2422407230306 [[],[]] .chain = true := by decide
def e2422407230318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422407230318 : Closed e2422407230318 ∧ code e2422407230318 = 11218500252526 := by decide
theorem cert_e2422407230318 : check e2422407230318 [[],[]] .sourceHead = true := by decide
def e2422407230326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422407230326 : Closed e2422407230326 ∧ code e2422407230326 = 11218500252534 := by decide
theorem cert_e2422407230326 : check e2422407230326 [[],[]] .sourceHead = true := by decide
def e2422407230346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422407230346 : Closed e2422407230346 ∧ code e2422407230346 = 11218500252554 := by decide
theorem cert_e2422407230346 : check e2422407230346 [[],[]] .chain = true := by decide
def e2422407230370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422407230370 : Closed e2422407230370 ∧ code e2422407230370 = 11218500252578 := by decide
theorem cert_e2422407230370 : check e2422407230370 [[],[]] .chain = true := by decide
def e2422407230382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422407230382 : Closed e2422407230382 ∧ code e2422407230382 = 11218500252590 := by decide
theorem cert_e2422407230382 : check e2422407230382 [[],[]] .sourceHead = true := by decide
def e2422407230394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422407230394 : Closed e2422407230394 ∧ code e2422407230394 = 11218500252602 := by decide
theorem cert_e2422407230394 : check e2422407230394 [[],[]] .sourceHead = true := by decide
def e2422407230422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422407230422 : Closed e2422407230422 ∧ code e2422407230422 = 11218500252630 := by decide
theorem cert_e2422407230422 : check e2422407230422 [[],[]] .sourceHead = true := by decide
def e2422407230426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422407230426 : Closed e2422407230426 ∧ code e2422407230426 = 11218500252634 := by decide
theorem cert_e2422407230426 : check e2422407230426 [[],[]] .sourceHead = true := by decide
def e2422407230494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422407230494 : Closed e2422407230494 ∧ code e2422407230494 = 11218500252702 := by decide
theorem cert_e2422407230494 : check e2422407230494 [[],[]] .chain = true := by decide
def e2422407230518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422407230518 : Closed e2422407230518 ∧ code e2422407230518 = 11218500252726 := by decide
theorem cert_e2422407230518 : check e2422407230518 [[],[]] .chain = true := by decide
def e2422407230522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422407230522 : Closed e2422407230522 ∧ code e2422407230522 = 11218500252730 := by decide
theorem cert_e2422407230522 : check e2422407230522 [[],[]] .chain = true := by decide
def e2422407230662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422407230662 : Closed e2422407230662 ∧ code e2422407230662 = 11218500252870 := by decide
theorem cert_e2422407230662 : check e2422407230662 [[],[]] .chain = true := by decide
def e2422407230690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422407230690 : Closed e2422407230690 ∧ code e2422407230690 = 11218500252898 := by decide
theorem cert_e2422407230690 : check e2422407230690 [[],[]] .chain = true := by decide
def e2422407230702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407230702 : Closed e2422407230702 ∧ code e2422407230702 = 11218500252910 := by decide
theorem cert_e2422407230702 : check e2422407230702 [[],[]] .sourceHead = true := by decide
def e2422407230710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407230710 : Closed e2422407230710 ∧ code e2422407230710 = 11218500252918 := by decide
theorem cert_e2422407230710 : check e2422407230710 [[],[]] .sourceHead = true := by decide
def e2422407230990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422407230990 : Closed e2422407230990 ∧ code e2422407230990 = 11218500253198 := by decide
theorem cert_e2422407230990 : check e2422407230990 [[],[]] .chain = true := by decide
def e2422407231074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422407231074 : Closed e2422407231074 ∧ code e2422407231074 = 11218500253282 := by decide
theorem cert_e2422407231074 : check e2422407231074 [[],[]] .chain = true := by decide
def e2422407231086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407231086 : Closed e2422407231086 ∧ code e2422407231086 = 11218500253294 := by decide
theorem cert_e2422407231086 : check e2422407231086 [[],[]] .sourceHead = true := by decide
def e2422407231098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407231098 : Closed e2422407231098 ∧ code e2422407231098 = 11218500253306 := by decide
theorem cert_e2422407231098 : check e2422407231098 [[],[]] .sourceHead = true := by decide
def e2422407231286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407231286 : Closed e2422407231286 ∧ code e2422407231286 = 11218500253494 := by decide
theorem cert_e2422407231286 : check e2422407231286 [[],[]] .sourceHead = true := by decide
def e2422407231290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407231290 : Closed e2422407231290 ∧ code e2422407231290 = 11218500253498 := by decide
theorem cert_e2422407231290 : check e2422407231290 [[],[]] .sourceHead = true := by decide
def e2422407258798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422407258798 : Closed e2422407258798 ∧ code e2422407258798 = 11218500281006 := by decide
theorem cert_e2422407258798 : check e2422407258798 [[],[]] .chain = true := by decide
def e2422407258810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422407258810 : Closed e2422407258810 ∧ code e2422407258810 = 11218500281018 := by decide
theorem cert_e2422407258810 : check e2422407258810 [[],[]] .chain = true := by decide
def e2422407258858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422407258858 : Closed e2422407258858 ∧ code e2422407258858 = 11218500281066 := by decide
theorem cert_e2422407258858 : check e2422407258858 [[],[]] .chain = true := by decide
def e2422407260334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422407260334 : Closed e2422407260334 ∧ code e2422407260334 = 11218500282542 := by decide
theorem cert_e2422407260334 : check e2422407260334 [[],[]] .chain = true := by decide
def e2422407260346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422407260346 : Closed e2422407260346 ∧ code e2422407260346 = 11218500282554 := by decide
theorem cert_e2422407260346 : check e2422407260346 [[],[]] .chain = true := by decide
def e2422407260718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422407260718 : Closed e2422407260718 ∧ code e2422407260718 = 11218500282926 := by decide
theorem cert_e2422407260718 : check e2422407260718 [[],[]] .chain = true := by decide
def e2422407260898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422407260898 : Closed e2422407260898 ∧ code e2422407260898 = 11218500283106 := by decide
theorem cert_e2422407260898 : check e2422407260898 [[],[]] .chain = true := by decide
def e2422407260910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2422407260910 : Closed e2422407260910 ∧ code e2422407260910 = 11218500283118 := by decide
theorem cert_e2422407260910 : check e2422407260910 [[],[]] .sourceHead = true := by decide
def e2422407261038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422407261038 : Closed e2422407261038 ∧ code e2422407261038 = 11218500283246 := by decide
theorem cert_e2422407261038 : check e2422407261038 [[],[]] .chain = true := by decide
def e2422407261046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422407261046 : Closed e2422407261046 ∧ code e2422407261046 = 11218500283254 := by decide
theorem cert_e2422407261046 : check e2422407261046 [[],[]] .chain = true := by decide
def e2422407261066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407261066 : Closed e2422407261066 ∧ code e2422407261066 = 11218500283274 := by decide
theorem cert_e2422407261066 : check e2422407261066 [[],[]] .chain = true := by decide
def e2422407261090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407261090 : Closed e2422407261090 ∧ code e2422407261090 = 11218500283298 := by decide
theorem cert_e2422407261090 : check e2422407261090 [[],[]] .chain = true := by decide
def e2422407261102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422407261102 : Closed e2422407261102 ∧ code e2422407261102 = 11218500283310 := by decide
theorem cert_e2422407261102 : check e2422407261102 [[],[]] .sourceHead = true := by decide
def e2422407261110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2422407261110 : Closed e2422407261110 ∧ code e2422407261110 = 11218500283318 := by decide
theorem cert_e2422407261110 : check e2422407261110 [[],[]] .chain = true := by decide
def e2422407261114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422407261114 : Closed e2422407261114 ∧ code e2422407261114 = 11218500283322 := by decide
theorem cert_e2422407261114 : check e2422407261114 [[],[]] .sourceHead = true := by decide
def e2422407261550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422407261550 : Closed e2422407261550 ∧ code e2422407261550 = 11218500283758 := by decide
theorem cert_e2422407261550 : check e2422407261550 [[],[]] .chain = true := by decide
def e2422407261558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422407261558 : Closed e2422407261558 ∧ code e2422407261558 = 11218500283766 := by decide
theorem cert_e2422407261558 : check e2422407261558 [[],[]] .chain = true := by decide
def e2422407261614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422407261614 : Closed e2422407261614 ∧ code e2422407261614 = 11218500283822 := by decide
theorem cert_e2422407261614 : check e2422407261614 [[],[]] .chain = true := by decide
def e2422407261626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422407261626 : Closed e2422407261626 ∧ code e2422407261626 = 11218500283834 := by decide
theorem cert_e2422407261626 : check e2422407261626 [[],[]] .chain = true := by decide
def e2422407261654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422407261654 : Closed e2422407261654 ∧ code e2422407261654 = 11218500283862 := by decide
theorem cert_e2422407261654 : check e2422407261654 [[],[]] .chain = true := by decide
def e2422407261658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422407261658 : Closed e2422407261658 ∧ code e2422407261658 = 11218500283866 := by decide
theorem cert_e2422407261658 : check e2422407261658 [[],[]] .chain = true := by decide
def e2422407261738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422407261738 : Closed e2422407261738 ∧ code e2422407261738 = 11218500283946 := by decide
theorem cert_e2422407261738 : check e2422407261738 [[],[]] .chain = true := by decide
def e2422407261834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407261834 : Closed e2422407261834 ∧ code e2422407261834 = 11218500284042 := by decide
theorem cert_e2422407261834 : check e2422407261834 [[],[]] .chain = true := by decide
def e2422407261858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407261858 : Closed e2422407261858 ∧ code e2422407261858 = 11218500284066 := by decide
theorem cert_e2422407261858 : check e2422407261858 [[],[]] .chain = true := by decide
def e2422407261870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422407261870 : Closed e2422407261870 ∧ code e2422407261870 = 11218500284078 := by decide
theorem cert_e2422407261870 : check e2422407261870 [[],[]] .sourceHead = true := by decide
def e2422407261878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422407261878 : Closed e2422407261878 ∧ code e2422407261878 = 11218500284086 := by decide
theorem cert_e2422407261878 : check e2422407261878 [[],[]] .chain = true := by decide
def e2422407261882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422407261882 : Closed e2422407261882 ∧ code e2422407261882 = 11218500284090 := by decide
theorem cert_e2422407261882 : check e2422407261882 [[],[]] .sourceHead = true := by decide
def e2422407261910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422407261910 : Closed e2422407261910 ∧ code e2422407261910 = 11218500284118 := by decide
theorem cert_e2422407261910 : check e2422407261910 [[],[]] .chain = true := by decide
def e2422407261914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422407261914 : Closed e2422407261914 ∧ code e2422407261914 = 11218500284122 := by decide
theorem cert_e2422407261914 : check e2422407261914 [[],[]] .chain = true := by decide
def e2422407261930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422407261930 : Closed e2422407261930 ∧ code e2422407261930 = 11218500284138 := by decide
theorem cert_e2422407261930 : check e2422407261930 [[],[]] .sourceHead = true := by decide
def e2422407263598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422407263598 : Closed e2422407263598 ∧ code e2422407263598 = 11218500285806 := by decide
theorem cert_e2422407263598 : check e2422407263598 [[],[]] .chain = true := by decide
def e2422407263606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422407263606 : Closed e2422407263606 ∧ code e2422407263606 = 11218500285814 := by decide
theorem cert_e2422407263606 : check e2422407263606 [[],[]] .chain = true := by decide
def e2422407263662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422407263662 : Closed e2422407263662 ∧ code e2422407263662 = 11218500285870 := by decide
theorem cert_e2422407263662 : check e2422407263662 [[],[]] .chain = true := by decide
def e2422407263674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422407263674 : Closed e2422407263674 ∧ code e2422407263674 = 11218500285882 := by decide
theorem cert_e2422407263674 : check e2422407263674 [[],[]] .chain = true := by decide
def e2422407263702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422407263702 : Closed e2422407263702 ∧ code e2422407263702 = 11218500285910 := by decide
theorem cert_e2422407263702 : check e2422407263702 [[],[]] .chain = true := by decide
def e2422407263706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422407263706 : Closed e2422407263706 ∧ code e2422407263706 = 11218500285914 := by decide
theorem cert_e2422407263706 : check e2422407263706 [[],[]] .chain = true := by decide
def e2422407263918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422407263918 : Closed e2422407263918 ∧ code e2422407263918 = 11218500286126 := by decide
theorem cert_e2422407263918 : check e2422407263918 [[],[]] .chain = true := by decide
def e2422407263930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422407263930 : Closed e2422407263930 ∧ code e2422407263930 = 11218500286138 := by decide
theorem cert_e2422407263930 : check e2422407263930 [[],[]] .chain = true := by decide
def e2422407263978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422407263978 : Closed e2422407263978 ∧ code e2422407263978 = 11218500286186 := by decide
theorem cert_e2422407263978 : check e2422407263978 [[],[]] .chain = true := by decide
def e2422407264086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422407264086 : Closed e2422407264086 ∧ code e2422407264086 = 11218500286294 := by decide
theorem cert_e2422407264086 : check e2422407264086 [[],[]] .chain = true := by decide
def e2422407264090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422407264090 : Closed e2422407264090 ∧ code e2422407264090 = 11218500286298 := by decide
theorem cert_e2422407264090 : check e2422407264090 [[],[]] .chain = true := by decide
def e2422407264106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422407264106 : Closed e2422407264106 ∧ code e2422407264106 = 11218500286314 := by decide
theorem cert_e2422407264106 : check e2422407264106 [[],[]] .chain = true := by decide
def e2422407264426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422407264426 : Closed e2422407264426 ∧ code e2422407264426 = 11218500286634 := by decide
theorem cert_e2422407264426 : check e2422407264426 [[],[]] .chain = true := by decide
def e2422407264810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422407264810 : Closed e2422407264810 ∧ code e2422407264810 = 11218500287018 := by decide
theorem cert_e2422407264810 : check e2422407264810 [[],[]] .chain = true := by decide
def e2422407264906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407264906 : Closed e2422407264906 ∧ code e2422407264906 = 11218500287114 := by decide
theorem cert_e2422407264906 : check e2422407264906 [[],[]] .chain = true := by decide
def e2422407264930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407264930 : Closed e2422407264930 ∧ code e2422407264930 = 11218500287138 := by decide
theorem cert_e2422407264930 : check e2422407264930 [[],[]] .chain = true := by decide
def e2422407264942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422407264942 : Closed e2422407264942 ∧ code e2422407264942 = 11218500287150 := by decide
theorem cert_e2422407264942 : check e2422407264942 [[],[]] .sourceHead = true := by decide
def e2422407264950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422407264950 : Closed e2422407264950 ∧ code e2422407264950 = 11218500287158 := by decide
theorem cert_e2422407264950 : check e2422407264950 [[],[]] .chain = true := by decide
def e2422407264954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422407264954 : Closed e2422407264954 ∧ code e2422407264954 = 11218500287162 := by decide
theorem cert_e2422407264954 : check e2422407264954 [[],[]] .sourceHead = true := by decide
def e2422407264982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422407264982 : Closed e2422407264982 ∧ code e2422407264982 = 11218500287190 := by decide
theorem cert_e2422407264982 : check e2422407264982 [[],[]] .chain = true := by decide
def e2422407264986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422407264986 : Closed e2422407264986 ∧ code e2422407264986 = 11218500287194 := by decide
theorem cert_e2422407264986 : check e2422407264986 [[],[]] .chain = true := by decide
end Blc.Floor43
