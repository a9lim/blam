import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e601494002118 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601494002118 : Closed e601494002118 ∧ code e601494002118 = 9397587024326 := by decide
theorem cert_e601494002118 : check e601494002118 [[.under]] .width = true := by decide
def e601494002886 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601494002886 : Closed e601494002886 ∧ code e601494002886 = 9397587025094 := by decide
theorem cert_e601494002886 : check e601494002886 [[.under]] .width = true := by decide
def e601494018154 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601494018154 : Closed e601494018154 ∧ code e601494018154 = 9397587040362 := by decide
theorem cert_e601494018154 : check e601494018154 [[.under]] .width = true := by decide
def e601494018586 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601494018586 : Closed e601494018586 ∧ code e601494018586 = 9397587040794 := by decide
theorem cert_e601494018586 : check e601494018586 [[.under]] .width = true := by decide
def e601494020122 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601494020122 : Closed e601494020122 ∧ code e601494020122 = 9397587042330 := by decide
theorem cert_e601494020122 : check e601494020122 [[.under]] .width = true := by decide
def e601494020214 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601494020214 : Closed e601494020214 ∧ code e601494020214 = 9397587042422 := by decide
theorem cert_e601494020214 : check e601494020214 [[.under]] .width = true := by decide
def e601494020458 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601494020458 : Closed e601494020458 ∧ code e601494020458 = 9397587042666 := by decide
theorem cert_e601494020458 : check e601494020458 [[.under]] .width = true := by decide
def e601494020506 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601494020506 : Closed e601494020506 ∧ code e601494020506 = 9397587042714 := by decide
theorem cert_e601494020506 : check e601494020506 [[.under]] .width = true := by decide
def e601494021658 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601494021658 : Closed e601494021658 ∧ code e601494021658 = 9397587043866 := by decide
theorem cert_e601494021658 : check e601494021658 [[.under]] .width = true := by decide
def e601494176470 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601494176470 : Closed e601494176470 ∧ code e601494176470 = 9397587198678 := by decide
private def t_e601494176470 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem cert_e601494176470 : ¬ IsSelfInterpreter e601494176470 :=
  wSource (t := t_e601494176470) (replay_sound (ps := []) (t := e601494176470) (by decide)) (by decide)
def e601494176474 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601494176474 : Closed e601494176474 ∧ code e601494176474 = 9397587198682 := by decide
theorem cert_e601494176474 : check e601494176474 [[.under]] .width = true := by decide
def e601494176490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601494176490 : Closed e601494176490 ∧ code e601494176490 = 9397587198698 := by decide
theorem cert_e601494176490 : check e601494176490 [[.under]] .width = true := by decide
def e601494176566 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601494176566 : Closed e601494176566 ∧ code e601494176566 = 9397587198774 := by decide
theorem cert_e601494176566 : check e601494176566 [[.under]] .width = true := by decide
def e601494176570 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601494176570 : Closed e601494176570 ∧ code e601494176570 = 9397587198778 := by decide
theorem cert_e601494176570 : check e601494176570 [[.under]] .width = true := by decide
def e601494176666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601494176666 : Closed e601494176666 ∧ code e601494176666 = 9397587198874 := by decide
theorem cert_e601494176666 : check e601494176666 [[.under]] .width = true := by decide
def e601494234650 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601494234650 : Closed e601494234650 ∧ code e601494234650 = 9397587256858 := by decide
theorem cert_e601494234650 : check e601494234650 [[.under]] .width = true := by decide
def e601494259118 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601494259118 : Closed e601494259118 ∧ code e601494259118 = 9397587281326 := by decide
theorem cert_e601494259118 : check e601494259118 [[.under]] .width = true := by decide
def e601494259130 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601494259130 : Closed e601494259130 ∧ code e601494259130 = 9397587281338 := by decide
theorem cert_e601494259130 : check e601494259130 [[.under]] .width = true := by decide
def e601494259178 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601494259178 : Closed e601494259178 ∧ code e601494259178 = 9397587281386 := by decide
theorem cert_e601494259178 : check e601494259178 [[.under]] .width = true := by decide
def e601494259310 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601494259310 : Closed e601494259310 ∧ code e601494259310 = 9397587281518 := by decide
theorem cert_e601494259310 : check e601494259310 [[.under]] .width = true := by decide
def e601494259322 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601494259322 : Closed e601494259322 ∧ code e601494259322 = 9397587281530 := by decide
theorem cert_e601494259322 : check e601494259322 [[.under]] .width = true := by decide
def e601494259610 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601494259610 : Closed e601494259610 ∧ code e601494259610 = 9397587281818 := by decide
theorem cert_e601494259610 : check e601494259610 [[.under]] .width = true := by decide
def e601494263350 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601494263350 : Closed e601494263350 ∧ code e601494263350 = 9397587285558 := by decide
theorem cert_e601494263350 : check e601494263350 [[.under]] .width = true := by decide
def e601494263354 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601494263354 : Closed e601494263354 ∧ code e601494263354 = 9397587285562 := by decide
theorem cert_e601494263354 : check e601494263354 [[.under]] .width = true := by decide
def e601494263438 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601494263438 : Closed e601494263438 ∧ code e601494263438 = 9397587285646 := by decide
private def t_e601494263438 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem cert_e601494263438 : ¬ IsSelfInterpreter e601494263438 :=
  wSource (t := t_e601494263438) (replay_sound (ps := []) (t := e601494263438) (by decide)) (by decide)
def e601494263494 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601494263494 : Closed e601494263494 ∧ code e601494263494 = 9397587285702 := by decide
theorem cert_e601494263494 : check e601494263494 [[.under]] .width = true := by decide
def e601494263578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601494263578 : Closed e601494263578 ∧ code e601494263578 = 9397587285786 := by decide
theorem cert_e601494263578 : check e601494263578 [[.under]] .width = true := by decide
def e601494263622 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601494263622 : Closed e601494263622 ∧ code e601494263622 = 9397587285830 := by decide
theorem cert_e601494263622 : check e601494263622 [[.under]] .width = true := by decide
def e601494264206 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601494264206 : Closed e601494264206 ∧ code e601494264206 = 9397587286414 := by decide
theorem cert_e601494264206 : check e601494264206 [[.under]] .width = true := by decide
def e601494264262 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601494264262 : Closed e601494264262 ∧ code e601494264262 = 9397587286470 := by decide
theorem cert_e601494264262 : check e601494264262 [[.under]] .width = true := by decide
def e601494265030 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601494265030 : Closed e601494265030 ∧ code e601494265030 = 9397587287238 := by decide
theorem cert_e601494265030 : check e601494265030 [[.under]] .width = true := by decide
def e601494280298 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601494280298 : Closed e601494280298 ∧ code e601494280298 = 9397587302506 := by decide
theorem cert_e601494280298 : check e601494280298 [[.under]] .width = true := by decide
def e601494280730 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601494280730 : Closed e601494280730 ∧ code e601494280730 = 9397587302938 := by decide
theorem cert_e601494280730 : check e601494280730 [[.under]] .width = true := by decide
def e601494282266 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601494282266 : Closed e601494282266 ∧ code e601494282266 = 9397587304474 := by decide
theorem cert_e601494282266 : check e601494282266 [[.under]] .width = true := by decide
def e601494282358 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601494282358 : Closed e601494282358 ∧ code e601494282358 = 9397587304566 := by decide
theorem cert_e601494282358 : check e601494282358 [[.under]] .width = true := by decide
def e601494282602 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601494282602 : Closed e601494282602 ∧ code e601494282602 = 9397587304810 := by decide
theorem cert_e601494282602 : check e601494282602 [[.under]] .width = true := by decide
def e601494282650 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601494282650 : Closed e601494282650 ∧ code e601494282650 = 9397587304858 := by decide
theorem cert_e601494282650 : check e601494282650 [[.under]] .width = true := by decide
def e601494283802 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601494283802 : Closed e601494283802 ∧ code e601494283802 = 9397587306010 := by decide
theorem cert_e601494283802 : check e601494283802 [[.under]] .width = true := by decide
def e601500804634 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601500804634 : Closed e601500804634 ∧ code e601500804634 = 9397593826842 := by decide
theorem cert_e601500804634 : check e601500804634 [[.under]] .width = true := by decide
def e601500870170 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601500870170 : Closed e601500870170 ∧ code e601500870170 = 9397593892378 := by decide
theorem cert_e601500870170 : check e601500870170 [[.under]] .width = true := by decide
def e601508734490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601508734490 : Closed e601508734490 ∧ code e601508734490 = 9397601756698 := by decide
theorem cert_e601508734490 : check e601508734490 [[.under]] .width = true := by decide
def e601508767258 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601508767258 : Closed e601508767258 ∧ code e601508767258 = 9397601789466 := by decide
theorem cert_e601508767258 : check e601508767258 [[.under]] .width = true := by decide
def e601508996634 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601508996634 : Closed e601508996634 ∧ code e601508996634 = 9397602018842 := by decide
theorem cert_e601508996634 : check e601508996634 [[.under]] .width = true := by decide
def e601509045786 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601509045786 : Closed e601509045786 ∧ code e601509045786 = 9397602067994 := by decide
theorem cert_e601509045786 : check e601509045786 [[.under]] .width = true := by decide
def e601509160474 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601509160474 : Closed e601509160474 ∧ code e601509160474 = 9397602182682 := by decide
theorem cert_e601509160474 : check e601509160474 [[.under]] .width = true := by decide
def e601509176858 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601509176858 : Closed e601509176858 ∧ code e601509176858 = 9397602199066 := by decide
theorem cert_e601509176858 : check e601509176858 [[.under]] .width = true := by decide
def e601510307354 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601510307354 : Closed e601510307354 ∧ code e601510307354 = 9397603329562 := by decide
theorem cert_e601510307354 : check e601510307354 [[.under]] .width = true := by decide
def e601510340122 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601510340122 : Closed e601510340122 ∧ code e601510340122 = 9397603362330 := by decide
theorem cert_e601510340122 : check e601510340122 [[.under]] .width = true := by decide
def e601511674582 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601511674582 : Closed e601511674582 ∧ code e601511674582 = 9397604696790 := by decide
theorem cert_e601511674582 : check e601511674582 [[.under]] .width = true := by decide
def e601511674586 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601511674586 : Closed e601511674586 ∧ code e601511674586 = 9397604696794 := by decide
theorem cert_e601511674586 : check e601511674586 [[.under]] .width = true := by decide
def e601511674602 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601511674602 : Closed e601511674602 ∧ code e601511674602 = 9397604696810 := by decide
theorem cert_e601511674602 : check e601511674602 [[.under]] .width = true := by decide
def e601511674678 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601511674678 : Closed e601511674678 ∧ code e601511674678 = 9397604696886 := by decide
theorem cert_e601511674678 : check e601511674678 [[.under]] .width = true := by decide
def e601511674682 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601511674682 : Closed e601511674682 ∧ code e601511674682 = 9397604696890 := by decide
theorem cert_e601511674682 : check e601511674682 [[.under]] .width = true := by decide
def e601511674778 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601511674778 : Closed e601511674778 ∧ code e601511674778 = 9397604696986 := by decide
theorem cert_e601511674778 : check e601511674778 [[.under]] .width = true := by decide
def e601511880218 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601511880218 : Closed e601511880218 ∧ code e601511880218 = 9397604902426 := by decide
theorem cert_e601511880218 : check e601511880218 [[.under]] .width = true := by decide
def e601511929370 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601511929370 : Closed e601511929370 ∧ code e601511929370 = 9397604951578 := by decide
theorem cert_e601511929370 : check e601511929370 [[.under]] .width = true := by decide
def e601512347054 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601512347054 : Closed e601512347054 ∧ code e601512347054 = 9397605369262 := by decide
theorem cert_e601512347054 : check e601512347054 [[.under]] .width = true := by decide
def e601512347066 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601512347066 : Closed e601512347066 ∧ code e601512347066 = 9397605369274 := by decide
theorem cert_e601512347066 : check e601512347066 [[.under]] .width = true := by decide
def e601512347114 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601512347114 : Closed e601512347114 ∧ code e601512347114 = 9397605369322 := by decide
theorem cert_e601512347114 : check e601512347114 [[.under]] .width = true := by decide
def e601512347246 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601512347246 : Closed e601512347246 ∧ code e601512347246 = 9397605369454 := by decide
theorem cert_e601512347246 : check e601512347246 [[.under]] .width = true := by decide
def e601512347258 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601512347258 : Closed e601512347258 ∧ code e601512347258 = 9397605369466 := by decide
theorem cert_e601512347258 : check e601512347258 [[.under]] .width = true := by decide
def e601512347546 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601512347546 : Closed e601512347546 ∧ code e601512347546 = 9397605369754 := by decide
theorem cert_e601512347546 : check e601512347546 [[.under]] .width = true := by decide
def e601512351286 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601512351286 : Closed e601512351286 ∧ code e601512351286 = 9397605373494 := by decide
theorem cert_e601512351286 : check e601512351286 [[.under]] .width = true := by decide
def e601512351290 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601512351290 : Closed e601512351290 ∧ code e601512351290 = 9397605373498 := by decide
theorem cert_e601512351290 : check e601512351290 [[.under]] .width = true := by decide
def e601512351374 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601512351374 : Closed e601512351374 ∧ code e601512351374 = 9397605373582 := by decide
theorem cert_e601512351374 : check e601512351374 [[.under]] .width = true := by decide
def e601512351430 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601512351430 : Closed e601512351430 ∧ code e601512351430 = 9397605373638 := by decide
theorem cert_e601512351430 : check e601512351430 [[.under]] .width = true := by decide
def e601512351514 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601512351514 : Closed e601512351514 ∧ code e601512351514 = 9397605373722 := by decide
theorem cert_e601512351514 : check e601512351514 [[.under]] .width = true := by decide
def e601512351558 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601512351558 : Closed e601512351558 ∧ code e601512351558 = 9397605373766 := by decide
theorem cert_e601512351558 : check e601512351558 [[.under]] .width = true := by decide
def e601512352142 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601512352142 : Closed e601512352142 ∧ code e601512352142 = 9397605374350 := by decide
theorem cert_e601512352142 : check e601512352142 [[.under]] .width = true := by decide
def e601512352198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601512352198 : Closed e601512352198 ∧ code e601512352198 = 9397605374406 := by decide
theorem cert_e601512352198 : check e601512352198 [[.under]] .width = true := by decide
def e601512352966 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601512352966 : Closed e601512352966 ∧ code e601512352966 = 9397605375174 := by decide
theorem cert_e601512352966 : check e601512352966 [[.under]] .width = true := by decide
def e601512368234 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601512368234 : Closed e601512368234 ∧ code e601512368234 = 9397605390442 := by decide
theorem cert_e601512368234 : check e601512368234 [[.under]] .width = true := by decide
def e601512368666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601512368666 : Closed e601512368666 ∧ code e601512368666 = 9397605390874 := by decide
theorem cert_e601512368666 : check e601512368666 [[.under]] .width = true := by decide
def e601512370202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601512370202 : Closed e601512370202 ∧ code e601512370202 = 9397605392410 := by decide
theorem cert_e601512370202 : check e601512370202 [[.under]] .width = true := by decide
def e601512370294 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601512370294 : Closed e601512370294 ∧ code e601512370294 = 9397605392502 := by decide
theorem cert_e601512370294 : check e601512370294 [[.under]] .width = true := by decide
def e601512370538 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601512370538 : Closed e601512370538 ∧ code e601512370538 = 9397605392746 := by decide
theorem cert_e601512370538 : check e601512370538 [[.under]] .width = true := by decide
def e601512370586 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601512370586 : Closed e601512370586 ∧ code e601512370586 = 9397605392794 := by decide
theorem cert_e601512370586 : check e601512370586 [[.under]] .width = true := by decide
def e601512371738 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601512371738 : Closed e601512371738 ∧ code e601512371738 = 9397605393946 := by decide
theorem cert_e601512371738 : check e601512371738 [[.under]] .width = true := by decide
def e601512592086 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601512592086 : Closed e601512592086 ∧ code e601512592086 = 9397605614294 := by decide
theorem cert_e601512592086 : check e601512592086 [[.under]] .width = true := by decide
def e601512592090 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601512592090 : Closed e601512592090 ∧ code e601512592090 = 9397605614298 := by decide
theorem cert_e601512592090 : check e601512592090 [[.under]] .width = true := by decide
def e601512592106 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601512592106 : Closed e601512592106 ∧ code e601512592106 = 9397605614314 := by decide
theorem cert_e601512592106 : check e601512592106 [[.under]] .width = true := by decide
def e601512592182 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601512592182 : Closed e601512592182 ∧ code e601512592182 = 9397605614390 := by decide
theorem cert_e601512592182 : check e601512592182 [[.under]] .width = true := by decide
def e601512592186 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601512592186 : Closed e601512592186 ∧ code e601512592186 = 9397605614394 := by decide
theorem cert_e601512592186 : check e601512592186 [[.under]] .width = true := by decide
def e601512592282 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601512592282 : Closed e601512592282 ∧ code e601512592282 = 9397605614490 := by decide
theorem cert_e601512592282 : check e601512592282 [[.under]] .width = true := by decide
def e601512699418 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601512699418 : Closed e601512699418 ∧ code e601512699418 = 9397605721626 := by decide
theorem cert_e601512699418 : check e601512699418 [[.under]] .width = true := by decide
def e601512715802 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601512715802 : Closed e601512715802 ∧ code e601512715802 = 9397605738010 := by decide
theorem cert_e601512715802 : check e601512715802 [[.under]] .width = true := by decide
def e601512871342 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601512871342 : Closed e601512871342 ∧ code e601512871342 = 9397605893550 := by decide
theorem cert_e601512871342 : check e601512871342 [[.under]] .width = true := by decide
def e601512871354 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601512871354 : Closed e601512871354 ∧ code e601512871354 = 9397605893562 := by decide
theorem cert_e601512871354 : check e601512871354 [[.under]] .width = true := by decide
def e601512871402 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601512871402 : Closed e601512871402 ∧ code e601512871402 = 9397605893610 := by decide
theorem cert_e601512871402 : check e601512871402 [[.under]] .width = true := by decide
def e601512871534 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601512871534 : Closed e601512871534 ∧ code e601512871534 = 9397605893742 := by decide
theorem cert_e601512871534 : check e601512871534 [[.under]] .width = true := by decide
def e601512871546 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601512871546 : Closed e601512871546 ∧ code e601512871546 = 9397605893754 := by decide
theorem cert_e601512871546 : check e601512871546 [[.under]] .width = true := by decide
def e601512871834 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601512871834 : Closed e601512871834 ∧ code e601512871834 = 9397605894042 := by decide
theorem cert_e601512871834 : check e601512871834 [[.under]] .width = true := by decide
def e601512875574 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601512875574 : Closed e601512875574 ∧ code e601512875574 = 9397605897782 := by decide
theorem cert_e601512875574 : check e601512875574 [[.under]] .width = true := by decide
def e601512875578 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601512875578 : Closed e601512875578 ∧ code e601512875578 = 9397605897786 := by decide
theorem cert_e601512875578 : check e601512875578 [[.under]] .width = true := by decide
def e601512875662 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601512875662 : Closed e601512875662 ∧ code e601512875662 = 9397605897870 := by decide
theorem cert_e601512875662 : check e601512875662 [[.under]] .width = true := by decide
def e601512875718 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601512875718 : Closed e601512875718 ∧ code e601512875718 = 9397605897926 := by decide
theorem cert_e601512875718 : check e601512875718 [[.under]] .width = true := by decide
def e601512875802 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601512875802 : Closed e601512875802 ∧ code e601512875802 = 9397605898010 := by decide
theorem cert_e601512875802 : check e601512875802 [[.under]] .width = true := by decide
def e601512875846 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601512875846 : Closed e601512875846 ∧ code e601512875846 = 9397605898054 := by decide
theorem cert_e601512875846 : check e601512875846 [[.under]] .width = true := by decide
def e601512876430 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601512876430 : Closed e601512876430 ∧ code e601512876430 = 9397605898638 := by decide
theorem cert_e601512876430 : check e601512876430 [[.under]] .width = true := by decide
def e601512876486 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601512876486 : Closed e601512876486 ∧ code e601512876486 = 9397605898694 := by decide
theorem cert_e601512876486 : check e601512876486 [[.under]] .width = true := by decide
def e601512877254 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601512877254 : Closed e601512877254 ∧ code e601512877254 = 9397605899462 := by decide
theorem cert_e601512877254 : check e601512877254 [[.under]] .width = true := by decide
def e601512892522 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601512892522 : Closed e601512892522 ∧ code e601512892522 = 9397605914730 := by decide
theorem cert_e601512892522 : check e601512892522 [[.under]] .width = true := by decide
def e601512892954 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601512892954 : Closed e601512892954 ∧ code e601512892954 = 9397605915162 := by decide
theorem cert_e601512892954 : check e601512892954 [[.under]] .width = true := by decide
def e601512894490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601512894490 : Closed e601512894490 ∧ code e601512894490 = 9397605916698 := by decide
theorem cert_e601512894490 : check e601512894490 [[.under]] .width = true := by decide
def e601512894582 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601512894582 : Closed e601512894582 ∧ code e601512894582 = 9397605916790 := by decide
theorem cert_e601512894582 : check e601512894582 [[.under]] .width = true := by decide
def e601512894826 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601512894826 : Closed e601512894826 ∧ code e601512894826 = 9397605917034 := by decide
theorem cert_e601512894826 : check e601512894826 [[.under]] .width = true := by decide
def e601512894874 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601512894874 : Closed e601512894874 ∧ code e601512894874 = 9397605917082 := by decide
theorem cert_e601512894874 : check e601512894874 [[.under]] .width = true := by decide
def e601512896026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601512896026 : Closed e601512896026 ∧ code e601512896026 = 9397605918234 := by decide
theorem cert_e601512896026 : check e601512896026 [[.under]] .width = true := by decide
def e601532261914 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601532261914 : Closed e601532261914 ∧ code e601532261914 = 9397625284122 := by decide
theorem cert_e601532261914 : check e601532261914 [[.under]] .width = true := by decide
def e601532360218 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601532360218 : Closed e601532360218 ∧ code e601532360218 = 9397625382426 := by decide
theorem cert_e601532360218 : check e601532360218 [[.under]] .width = true := by decide
def e601536259610 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601536259610 : Closed e601536259610 ∧ code e601536259610 = 9397629281818 := by decide
theorem cert_e601536259610 : check e601536259610 [[.under]] .width = true := by decide
def e601536308762 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601536308762 : Closed e601536308762 ∧ code e601536308762 = 9397629330970 := by decide
theorem cert_e601536308762 : check e601536308762 [[.under]] .width = true := by decide
def e601536505370 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601536505370 : Closed e601536505370 ∧ code e601536505370 = 9397629527578 := by decide
theorem cert_e601536505370 : check e601536505370 [[.under]] .width = true := by decide
def e601536840406 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601536840406 : Closed e601536840406 ∧ code e601536840406 = 9397629862614 := by decide
theorem cert_e601536840406 : check e601536840406 [[.under]] .width = true := by decide
def e601536840410 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601536840410 : Closed e601536840410 ∧ code e601536840410 = 9397629862618 := by decide
theorem cert_e601536840410 : check e601536840410 [[.under]] .width = true := by decide
def e601536840426 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601536840426 : Closed e601536840426 ∧ code e601536840426 = 9397629862634 := by decide
theorem cert_e601536840426 : check e601536840426 [[.under]] .width = true := by decide
def e601536840502 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601536840502 : Closed e601536840502 ∧ code e601536840502 = 9397629862710 := by decide
theorem cert_e601536840502 : check e601536840502 [[.under]] .width = true := by decide
def e601536840506 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601536840506 : Closed e601536840506 ∧ code e601536840506 = 9397629862714 := by decide
theorem cert_e601536840506 : check e601536840506 [[.under]] .width = true := by decide
def e601536840602 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601536840602 : Closed e601536840602 ∧ code e601536840602 = 9397629862810 := by decide
theorem cert_e601536840602 : check e601536840602 [[.under]] .width = true := by decide
def e601537046042 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601537046042 : Closed e601537046042 ∧ code e601537046042 = 9397630068250 := by decide
theorem cert_e601537046042 : check e601537046042 [[.under]] .width = true := by decide
def e601537095194 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601537095194 : Closed e601537095194 ∧ code e601537095194 = 9397630117402 := by decide
theorem cert_e601537095194 : check e601537095194 [[.under]] .width = true := by decide
def e601537512878 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601537512878 : Closed e601537512878 ∧ code e601537512878 = 9397630535086 := by decide
theorem cert_e601537512878 : check e601537512878 [[.under]] .width = true := by decide
def e601537512890 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601537512890 : Closed e601537512890 ∧ code e601537512890 = 9397630535098 := by decide
theorem cert_e601537512890 : check e601537512890 [[.under]] .width = true := by decide
def e601537512938 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601537512938 : Closed e601537512938 ∧ code e601537512938 = 9397630535146 := by decide
theorem cert_e601537512938 : check e601537512938 [[.under]] .width = true := by decide
def e601537513070 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601537513070 : Closed e601537513070 ∧ code e601537513070 = 9397630535278 := by decide
theorem cert_e601537513070 : check e601537513070 [[.under]] .width = true := by decide
def e601537513082 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601537513082 : Closed e601537513082 ∧ code e601537513082 = 9397630535290 := by decide
theorem cert_e601537513082 : check e601537513082 [[.under]] .width = true := by decide
def e601537513370 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601537513370 : Closed e601537513370 ∧ code e601537513370 = 9397630535578 := by decide
theorem cert_e601537513370 : check e601537513370 [[.under]] .width = true := by decide
def e601537517110 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601537517110 : Closed e601537517110 ∧ code e601537517110 = 9397630539318 := by decide
theorem cert_e601537517110 : check e601537517110 [[.under]] .width = true := by decide
def e601537517114 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601537517114 : Closed e601537517114 ∧ code e601537517114 = 9397630539322 := by decide
theorem cert_e601537517114 : check e601537517114 [[.under]] .width = true := by decide
def e601537517198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601537517198 : Closed e601537517198 ∧ code e601537517198 = 9397630539406 := by decide
theorem cert_e601537517198 : check e601537517198 [[.under]] .width = true := by decide
def e601537517254 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601537517254 : Closed e601537517254 ∧ code e601537517254 = 9397630539462 := by decide
theorem cert_e601537517254 : check e601537517254 [[.under]] .width = true := by decide
def e601537517338 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))
theorem wire_e601537517338 : Closed e601537517338 ∧ code e601537517338 = 9397630539546 := by decide
theorem cert_e601537517338 : check e601537517338 [[.under]] .width = true := by decide
def e601537517382 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))
theorem wire_e601537517382 : Closed e601537517382 ∧ code e601537517382 = 9397630539590 := by decide
theorem cert_e601537517382 : check e601537517382 [[.under]] .width = true := by decide
def e601537517966 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e601537517966 : Closed e601537517966 ∧ code e601537517966 = 9397630540174 := by decide
theorem cert_e601537517966 : check e601537517966 [[.under]] .width = true := by decide
def e601537518022 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e601537518022 : Closed e601537518022 ∧ code e601537518022 = 9397630540230 := by decide
theorem cert_e601537518022 : check e601537518022 [[.under]] .width = true := by decide
def e601537518790 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e601537518790 : Closed e601537518790 ∧ code e601537518790 = 9397630540998 := by decide
theorem cert_e601537518790 : check e601537518790 [[.under]] .width = true := by decide
def e601537534058 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e601537534058 : Closed e601537534058 ∧ code e601537534058 = 9397630556266 := by decide
theorem cert_e601537534058 : check e601537534058 [[.under]] .width = true := by decide
def e601537534490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601537534490 : Closed e601537534490 ∧ code e601537534490 = 9397630556698 := by decide
theorem cert_e601537534490 : check e601537534490 [[.under]] .width = true := by decide
def e601537536026 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e601537536026 : Closed e601537536026 ∧ code e601537536026 = 9397630558234 := by decide
theorem cert_e601537536026 : check e601537536026 [[.under]] .width = true := by decide
def e601537536118 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e601537536118 : Closed e601537536118 ∧ code e601537536118 = 9397630558326 := by decide
theorem cert_e601537536118 : check e601537536118 [[.under]] .width = true := by decide
def e601537536362 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e601537536362 : Closed e601537536362 ∧ code e601537536362 = 9397630558570 := by decide
theorem cert_e601537536362 : check e601537536362 [[.under]] .width = true := by decide
def e601537536410 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e601537536410 : Closed e601537536410 ∧ code e601537536410 = 9397630558618 := by decide
theorem cert_e601537536410 : check e601537536410 [[.under]] .width = true := by decide
def e601537537562 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e601537537562 : Closed e601537537562 ∧ code e601537537562 = 9397630559770 := by decide
theorem cert_e601537537562 : check e601537537562 [[.under]] .width = true := by decide
def e601538216662 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e601538216662 : Closed e601538216662 ∧ code e601538216662 = 9397631238870 := by decide
theorem cert_e601538216662 : check e601538216662 [[.under]] .width = true := by decide
def e601538216666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e601538216666 : Closed e601538216666 ∧ code e601538216666 = 9397631238874 := by decide
theorem cert_e601538216666 : check e601538216666 [[.under]] .width = true := by decide
def e601538216682 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e601538216682 : Closed e601538216682 ∧ code e601538216682 = 9397631238890 := by decide
theorem cert_e601538216682 : check e601538216682 [[.under]] .width = true := by decide
def e601538216758 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e601538216758 : Closed e601538216758 ∧ code e601538216758 = 9397631238966 := by decide
theorem cert_e601538216758 : check e601538216758 [[.under]] .width = true := by decide
def e601538216762 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e601538216762 : Closed e601538216762 ∧ code e601538216762 = 9397631238970 := by decide
theorem cert_e601538216762 : check e601538216762 [[.under]] .width = true := by decide
def e601538216858 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e601538216858 : Closed e601538216858 ∧ code e601538216858 = 9397631239066 := by decide
theorem cert_e601538216858 : check e601538216858 [[.under]] .width = true := by decide
def e601538274842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e601538274842 : Closed e601538274842 ∧ code e601538274842 = 9397631297050 := by decide
theorem cert_e601538274842 : check e601538274842 [[.under]] .width = true := by decide
def e601538299310 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 2))))))
theorem wire_e601538299310 : Closed e601538299310 ∧ code e601538299310 = 9397631321518 := by decide
theorem cert_e601538299310 : check e601538299310 [[.under]] .width = true := by decide
def e601538299322 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 0))))))
theorem wire_e601538299322 : Closed e601538299322 ∧ code e601538299322 = 9397631321530 := by decide
theorem cert_e601538299322 : check e601538299322 [[.under]] .width = true := by decide
def e601538299370 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 0))))))
theorem wire_e601538299370 : Closed e601538299370 ∧ code e601538299370 = 9397631321578 := by decide
theorem cert_e601538299370 : check e601538299370 [[.under]] .width = true := by decide
def e601538299502 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 2)))))))
theorem wire_e601538299502 : Closed e601538299502 ∧ code e601538299502 = 9397631321710 := by decide
theorem cert_e601538299502 : check e601538299502 [[.under]] .width = true := by decide
def e601538299514 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 0)))))))
theorem wire_e601538299514 : Closed e601538299514 ∧ code e601538299514 = 9397631321722 := by decide
theorem cert_e601538299514 : check e601538299514 [[.under]] .width = true := by decide
def e601538299802 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 0)))))))
theorem wire_e601538299802 : Closed e601538299802 ∧ code e601538299802 = 9397631322010 := by decide
theorem cert_e601538299802 : check e601538299802 [[.under]] .width = true := by decide
def e601538303542 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))
theorem wire_e601538303542 : Closed e601538303542 ∧ code e601538303542 = 9397631325750 := by decide
theorem cert_e601538303542 : check e601538303542 [[.under]] .width = true := by decide
def e601538303546 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))
theorem wire_e601538303546 : Closed e601538303546 ∧ code e601538303546 = 9397631325754 := by decide
theorem cert_e601538303546 : check e601538303546 [[.under]] .width = true := by decide
def e601538303630 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))
theorem wire_e601538303630 : Closed e601538303630 ∧ code e601538303630 = 9397631325838 := by decide
theorem cert_e601538303630 : check e601538303630 [[.under]] .width = true := by decide
def e601538303686 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))
theorem wire_e601538303686 : Closed e601538303686 ∧ code e601538303686 = 9397631325894 := by decide
theorem cert_e601538303686 : check e601538303686 [[.under]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e601494176470
#print axioms Blc.Floor43.cert_e601494263438
