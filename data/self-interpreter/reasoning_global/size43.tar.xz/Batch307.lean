import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630283638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2411630283638 : Closed e2411630283638 ∧ code e2411630283638 = 11207723305846 := by decide
theorem cert_e2411630283638 : checkPay e2411630283638 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630283658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411630283658 : Closed e2411630283658 ∧ code e2411630283658 = 11207723305866 := by decide
theorem cert_e2411630283658 : check e2411630283658 [[],[]] .chain = true := by decide
def e2411630283682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411630283682 : Closed e2411630283682 ∧ code e2411630283682 = 11207723305890 := by decide
theorem cert_e2411630283682 : check e2411630283682 [[],[]] .chain = true := by decide
def e2411630283694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2411630283694 : Closed e2411630283694 ∧ code e2411630283694 = 11207723305902 := by decide
theorem cert_e2411630283694 : checkPay e2411630283694 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630283706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2411630283706 : Closed e2411630283706 ∧ code e2411630283706 = 11207723305914 := by decide
theorem cert_e2411630283706 : checkPay e2411630283706 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630283734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2411630283734 : Closed e2411630283734 ∧ code e2411630283734 = 11207723305942 := by decide
theorem cert_e2411630283734 : checkPay e2411630283734 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630283738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2411630283738 : Closed e2411630283738 ∧ code e2411630283738 = 11207723305946 := by decide
theorem cert_e2411630283738 : checkPay e2411630283738 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630283806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630283806 : Closed e2411630283806 ∧ code e2411630283806 = 11207723306014 := by decide
theorem cert_e2411630283806 : check e2411630283806 [[],[]] .chain = true := by decide
def e2411630283830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630283830 : Closed e2411630283830 ∧ code e2411630283830 = 11207723306038 := by decide
theorem cert_e2411630283830 : check e2411630283830 [[],[]] .chain = true := by decide
def e2411630283834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630283834 : Closed e2411630283834 ∧ code e2411630283834 = 11207723306042 := by decide
theorem cert_e2411630283834 : check e2411630283834 [[],[]] .chain = true := by decide
def e2411630283974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630283974 : Closed e2411630283974 ∧ code e2411630283974 = 11207723306182 := by decide
theorem cert_e2411630283974 : check e2411630283974 [[],[]] .chain = true := by decide
def e2411630284002 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630284002 : Closed e2411630284002 ∧ code e2411630284002 = 11207723306210 := by decide
theorem cert_e2411630284002 : check e2411630284002 [[],[]] .chain = true := by decide
def e2411630284014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630284014 : Closed e2411630284014 ∧ code e2411630284014 = 11207723306222 := by decide
theorem cert_e2411630284014 : checkPay e2411630284014 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630284022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630284022 : Closed e2411630284022 ∧ code e2411630284022 = 11207723306230 := by decide
theorem cert_e2411630284022 : checkPay e2411630284022 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630284302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2411630284302 : Closed e2411630284302 ∧ code e2411630284302 = 11207723306510 := by decide
theorem cert_e2411630284302 : check e2411630284302 [[],[]] .chain = true := by decide
def e2411630284386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411630284386 : Closed e2411630284386 ∧ code e2411630284386 = 11207723306594 := by decide
theorem cert_e2411630284386 : check e2411630284386 [[],[]] .chain = true := by decide
def e2411630284398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2411630284398 : Closed e2411630284398 ∧ code e2411630284398 = 11207723306606 := by decide
theorem cert_e2411630284398 : checkPay e2411630284398 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630284410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2411630284410 : Closed e2411630284410 ∧ code e2411630284410 = 11207723306618 := by decide
theorem cert_e2411630284410 : checkPay e2411630284410 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630284598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630284598 : Closed e2411630284598 ∧ code e2411630284598 = 11207723306806 := by decide
theorem cert_e2411630284598 : checkPay e2411630284598 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630284602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630284602 : Closed e2411630284602 ∧ code e2411630284602 = 11207723306810 := by decide
theorem cert_e2411630284602 : checkPay e2411630284602 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630300790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411630300790 : Closed e2411630300790 ∧ code e2411630300790 = 11207723322998 := by decide
theorem cert_e2411630300790 : check e2411630300790 [[],[]] .chain = true := by decide
def e2411630300982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630300982 : Closed e2411630300982 ∧ code e2411630300982 = 11207723323190 := by decide
theorem cert_e2411630300982 : check e2411630300982 [[],[]] .chain = true := by decide
def e2411630300986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630300986 : Closed e2411630300986 ∧ code e2411630300986 = 11207723323194 := by decide
theorem cert_e2411630300986 : check e2411630300986 [[],[]] .chain = true := by decide
def e2411630302902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))) (.var 1))))))
theorem wire_e2411630302902 : Closed e2411630302902 ∧ code e2411630302902 = 11207723325110 := by decide
theorem cert_e2411630302902 : check e2411630302902 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630302906 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e2411630302906 : Closed e2411630302906 ∧ code e2411630302906 = 11207723325114 := by decide
theorem cert_e2411630302906 : check e2411630302906 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630302934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))) (.var 1))))))
theorem wire_e2411630302934 : Closed e2411630302934 ∧ code e2411630302934 = 11207723325142 := by decide
theorem cert_e2411630302934 : check e2411630302934 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630302954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e2411630302954 : Closed e2411630302954 ∧ code e2411630302954 = 11207723325162 := by decide
theorem cert_e2411630302954 : check e2411630302954 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630303062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))) (.var 1))))))
theorem wire_e2411630303062 : Closed e2411630303062 ∧ code e2411630303062 = 11207723325270 := by decide
theorem cert_e2411630303062 : check e2411630303062 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630303146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))) (.var 0))))))
theorem wire_e2411630303146 : Closed e2411630303146 ∧ code e2411630303146 = 11207723325354 := by decide
theorem cert_e2411630303146 : check e2411630303146 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630303670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e2411630303670 : Closed e2411630303670 ∧ code e2411630303670 = 11207723325878 := by decide
theorem cert_e2411630303670 : check e2411630303670 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630303674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2411630303674 : Closed e2411630303674 ∧ code e2411630303674 = 11207723325882 := by decide
theorem cert_e2411630303674 : check e2411630303674 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630303702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e2411630303702 : Closed e2411630303702 ∧ code e2411630303702 = 11207723325910 := by decide
theorem cert_e2411630303702 : check e2411630303702 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630303722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2411630303722 : Closed e2411630303722 ∧ code e2411630303722 = 11207723325930 := by decide
theorem cert_e2411630303722 : check e2411630303722 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630304054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630304054 : Closed e2411630304054 ∧ code e2411630304054 = 11207723326262 := by decide
theorem cert_e2411630304054 : check e2411630304054 [[],[]] .chain = true := by decide
def e2411630304058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630304058 : Closed e2411630304058 ∧ code e2411630304058 = 11207723326266 := by decide
theorem cert_e2411630304058 : check e2411630304058 [[],[]] .chain = true := by decide
def e2411630304154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630304154 : Closed e2411630304154 ∧ code e2411630304154 = 11207723326362 := by decide
theorem cert_e2411630304154 : check e2411630304154 [[],[]] .chain = true := by decide
def e2411630304374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 2))))) (.var 1))))))
theorem wire_e2411630304374 : Closed e2411630304374 ∧ code e2411630304374 = 11207723326582 := by decide
theorem cert_e2411630304374 : check e2411630304374 [[],[]] .chain = true := by decide
def e2411630304378 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 3))))) (.var 0))))))
theorem wire_e2411630304378 : Closed e2411630304378 ∧ code e2411630304378 = 11207723326586 := by decide
theorem cert_e2411630304378 : check e2411630304378 [[],[]] .chain = true := by decide
def e2411630304470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2411630304470 : Closed e2411630304470 ∧ code e2411630304470 = 11207723326678 := by decide
theorem cert_e2411630304470 : check e2411630304470 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630304566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630304566 : Closed e2411630304566 ∧ code e2411630304566 = 11207723326774 := by decide
theorem cert_e2411630304566 : check e2411630304566 [[],[]] .chain = true := by decide
def e2411630304570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630304570 : Closed e2411630304570 ∧ code e2411630304570 = 11207723326778 := by decide
theorem cert_e2411630304570 : check e2411630304570 [[],[]] .chain = true := by decide
def e2411630304654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2411630304654 : Closed e2411630304654 ∧ code e2411630304654 = 11207723326862 := by decide
theorem cert_e2411630304654 : check e2411630304654 [[],[]] .chain = true := by decide
def e2411630304710 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2411630304710 : Closed e2411630304710 ∧ code e2411630304710 = 11207723326918 := by decide
theorem cert_e2411630304710 : check e2411630304710 [[],[]] .chain = true := by decide
def e2411630304826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2411630304826 : Closed e2411630304826 ∧ code e2411630304826 = 11207723327034 := by decide
theorem cert_e2411630304826 : check e2411630304826 [[],[]] .chain = true := by decide
def e2411630304874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2411630304874 : Closed e2411630304874 ∧ code e2411630304874 = 11207723327082 := by decide
theorem cert_e2411630304874 : check e2411630304874 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630304922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630304922 : Closed e2411630304922 ∧ code e2411630304922 = 11207723327130 := by decide
theorem cert_e2411630304922 : check e2411630304922 [[],[]] .chain = true := by decide
def e2411630304966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2411630304966 : Closed e2411630304966 ∧ code e2411630304966 = 11207723327174 := by decide
theorem cert_e2411630304966 : check e2411630304966 [[],[]] .chain = true := by decide
def e2411630306742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2411630306742 : Closed e2411630306742 ∧ code e2411630306742 = 11207723328950 := by decide
theorem cert_e2411630306742 : check e2411630306742 [[],[]] .chain = true := by decide
def e2411630306774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2411630306774 : Closed e2411630306774 ∧ code e2411630306774 = 11207723328982 := by decide
theorem cert_e2411630306774 : check e2411630306774 [[],[]] .chain = true := by decide
def e2411630306778 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2411630306778 : Closed e2411630306778 ∧ code e2411630306778 = 11207723328986 := by decide
theorem cert_e2411630306778 : check e2411630306778 [[],[]] .chain = true := by decide
def e2411630306934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2411630306934 : Closed e2411630306934 ∧ code e2411630306934 = 11207723329142 := by decide
theorem cert_e2411630306934 : check e2411630306934 [[],[]] .chain = true := by decide
def e2411630307126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630307126 : Closed e2411630307126 ∧ code e2411630307126 = 11207723329334 := by decide
theorem cert_e2411630307126 : check e2411630307126 [[],[]] .chain = true := by decide
def e2411630307130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630307130 : Closed e2411630307130 ∧ code e2411630307130 = 11207723329338 := by decide
theorem cert_e2411630307130 : check e2411630307130 [[],[]] .chain = true := by decide
def e2411630309614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2411630309614 : Closed e2411630309614 ∧ code e2411630309614 = 11207723331822 := by decide
theorem cert_e2411630309614 : check e2411630309614 [[],[]] .chain = true := by decide
def e2411630309622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2411630309622 : Closed e2411630309622 ∧ code e2411630309622 = 11207723331830 := by decide
theorem cert_e2411630309622 : check e2411630309622 [[],[]] .chain = true := by decide
def e2411630310102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2411630310102 : Closed e2411630310102 ∧ code e2411630310102 = 11207723332310 := by decide
theorem cert_e2411630310102 : check e2411630310102 [[],[]] .chain = true := by decide
def e2411630310106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2411630310106 : Closed e2411630310106 ∧ code e2411630310106 = 11207723332314 := by decide
theorem cert_e2411630310106 : check e2411630310106 [[],[]] .chain = true := by decide
def e2411630310122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2411630310122 : Closed e2411630310122 ∧ code e2411630310122 = 11207723332330 := by decide
theorem cert_e2411630310122 : check e2411630310122 [[],[]] .chain = true := by decide
def e2411630310198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2411630310198 : Closed e2411630310198 ∧ code e2411630310198 = 11207723332406 := by decide
theorem cert_e2411630310198 : check e2411630310198 [[],[]] .chain = true := by decide
def e2411630310202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2411630310202 : Closed e2411630310202 ∧ code e2411630310202 = 11207723332410 := by decide
theorem cert_e2411630310202 : check e2411630310202 [[],[]] .chain = true := by decide
def e2411630310286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2411630310286 : Closed e2411630310286 ∧ code e2411630310286 = 11207723332494 := by decide
theorem cert_e2411630310286 : check e2411630310286 [[],[]] .chain = true := by decide
def e2411630310298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2411630310298 : Closed e2411630310298 ∧ code e2411630310298 = 11207723332506 := by decide
theorem cert_e2411630310298 : check e2411630310298 [[],[]] .chain = true := by decide
def e2411630311542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2411630311542 : Closed e2411630311542 ∧ code e2411630311542 = 11207723333750 := by decide
theorem cert_e2411630311542 : check e2411630311542 [[],[]] .chain = true := by decide
def e2411630311786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2411630311786 : Closed e2411630311786 ∧ code e2411630311786 = 11207723333994 := by decide
theorem cert_e2411630311786 : check e2411630311786 [[],[]] .chain = true := by decide
def e2411630311822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411630311822 : Closed e2411630311822 ∧ code e2411630311822 = 11207723334030 := by decide
theorem cert_e2411630311822 : check e2411630311822 [[],[]] .chain = true := by decide
def e2411630311834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2411630311834 : Closed e2411630311834 ∧ code e2411630311834 = 11207723334042 := by decide
theorem cert_e2411630311834 : check e2411630311834 [[],[]] .chain = true := by decide
def e2411630311878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411630311878 : Closed e2411630311878 ∧ code e2411630311878 = 11207723334086 := by decide
theorem cert_e2411630311878 : check e2411630311878 [[],[]] .chain = true := by decide
def e2411630319798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 1))))))
theorem wire_e2411630319798 : Closed e2411630319798 ∧ code e2411630319798 = 11207723342006 := by decide
theorem cert_e2411630319798 : check e2411630319798 [[],[]] .chain = true := by decide
def e2411630319830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.var 1))))))
theorem wire_e2411630319830 : Closed e2411630319830 ∧ code e2411630319830 = 11207723342038 := by decide
theorem cert_e2411630319830 : check e2411630319830 [[],[]] .chain = true := by decide
def e2411630319834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.var 0))))))
theorem wire_e2411630319834 : Closed e2411630319834 ∧ code e2411630319834 = 11207723342042 := by decide
theorem cert_e2411630319834 : check e2411630319834 [[],[]] .chain = true := by decide
def e2411630319850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.var 0))))))
theorem wire_e2411630319850 : Closed e2411630319850 ∧ code e2411630319850 = 11207723342058 := by decide
theorem cert_e2411630319850 : check e2411630319850 [[],[]] .chain = true := by decide
def e2411630320182 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2411630320182 : Closed e2411630320182 ∧ code e2411630320182 = 11207723342390 := by decide
theorem cert_e2411630320182 : check e2411630320182 [[],[]] .chain = true := by decide
def e2411630320186 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2411630320186 : Closed e2411630320186 ∧ code e2411630320186 = 11207723342394 := by decide
theorem cert_e2411630320186 : check e2411630320186 [[],[]] .chain = true := by decide
def e2411630320270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2411630320270 : Closed e2411630320270 ∧ code e2411630320270 = 11207723342478 := by decide
theorem cert_e2411630320270 : check e2411630320270 [[],[]] .chain = true := by decide
def e2411630320326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2411630320326 : Closed e2411630320326 ∧ code e2411630320326 = 11207723342534 := by decide
theorem cert_e2411630320326 : check e2411630320326 [[],[]] .chain = true := by decide
def e2411630320406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411630320406 : Closed e2411630320406 ∧ code e2411630320406 = 11207723342614 := by decide
theorem cert_e2411630320406 : check e2411630320406 [[],[]] .chain = true := by decide
def e2411630320410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411630320410 : Closed e2411630320410 ∧ code e2411630320410 = 11207723342618 := by decide
theorem cert_e2411630320410 : check e2411630320410 [[],[]] .chain = true := by decide
def e2411630320454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411630320454 : Closed e2411630320454 ∧ code e2411630320454 = 11207723342662 := by decide
theorem cert_e2411630320454 : check e2411630320454 [[],[]] .chain = true := by decide
def e2411630320482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411630320482 : Closed e2411630320482 ∧ code e2411630320482 = 11207723342690 := by decide
theorem cert_e2411630320482 : check e2411630320482 [[],[]] .chain = true := by decide
def e2411630320494 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))
theorem wire_e2411630320494 : Closed e2411630320494 ∧ code e2411630320494 = 11207723342702 := by decide
theorem cert_e2411630320494 : check e2411630320494 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630320502 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))
theorem wire_e2411630320502 : Closed e2411630320502 ∧ code e2411630320502 = 11207723342710 := by decide
theorem cert_e2411630320502 : check e2411630320502 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630320566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))
theorem wire_e2411630320566 : Closed e2411630320566 ∧ code e2411630320566 = 11207723342774 := by decide
theorem cert_e2411630320566 : check e2411630320566 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630320726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2411630320726 : Closed e2411630320726 ∧ code e2411630320726 = 11207723342934 := by decide
theorem cert_e2411630320726 : check e2411630320726 [[],[]] .chain = true := by decide
def e2411630320730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2411630320730 : Closed e2411630320730 ∧ code e2411630320730 = 11207723342938 := by decide
theorem cert_e2411630320730 : check e2411630320730 [[],[]] .chain = true := by decide
def e2411630320746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.var 0))))))
theorem wire_e2411630320746 : Closed e2411630320746 ∧ code e2411630320746 = 11207723342954 := by decide
theorem cert_e2411630320746 : check e2411630320746 [[],[]] .chain = true := by decide
def e2411630320918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411630320918 : Closed e2411630320918 ∧ code e2411630320918 = 11207723343126 := by decide
theorem cert_e2411630320918 : check e2411630320918 [[],[]] .chain = true := by decide
def e2411630320922 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411630320922 : Closed e2411630320922 ∧ code e2411630320922 = 11207723343130 := by decide
theorem cert_e2411630320922 : check e2411630320922 [[],[]] .chain = true := by decide
def e2411630320966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411630320966 : Closed e2411630320966 ∧ code e2411630320966 = 11207723343174 := by decide
theorem cert_e2411630320966 : check e2411630320966 [[],[]] .chain = true := by decide
def e2411630320994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411630320994 : Closed e2411630320994 ∧ code e2411630320994 = 11207723343202 := by decide
theorem cert_e2411630320994 : check e2411630320994 [[],[]] .chain = true := by decide
def e2411630321006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2411630321006 : Closed e2411630321006 ∧ code e2411630321006 = 11207723343214 := by decide
theorem cert_e2411630321006 : check e2411630321006 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630321014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2411630321014 : Closed e2411630321014 ∧ code e2411630321014 = 11207723343222 := by decide
theorem cert_e2411630321014 : check e2411630321014 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630321034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2411630321034 : Closed e2411630321034 ∧ code e2411630321034 = 11207723343242 := by decide
theorem cert_e2411630321034 : check e2411630321034 [[],[]] .chain = true := by decide
def e2411630321058 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2411630321058 : Closed e2411630321058 ∧ code e2411630321058 = 11207723343266 := by decide
theorem cert_e2411630321058 : check e2411630321058 [[],[]] .chain = true := by decide
def e2411630321070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2411630321070 : Closed e2411630321070 ∧ code e2411630321070 = 11207723343278 := by decide
theorem cert_e2411630321070 : check e2411630321070 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630321082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2411630321082 : Closed e2411630321082 ∧ code e2411630321082 = 11207723343290 := by decide
theorem cert_e2411630321082 : check e2411630321082 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630321110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2411630321110 : Closed e2411630321110 ∧ code e2411630321110 = 11207723343318 := by decide
theorem cert_e2411630321110 : check e2411630321110 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630321114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2411630321114 : Closed e2411630321114 ∧ code e2411630321114 = 11207723343322 := by decide
theorem cert_e2411630321114 : check e2411630321114 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630321334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2411630321334 : Closed e2411630321334 ∧ code e2411630321334 = 11207723343542 := by decide
theorem cert_e2411630321334 : check e2411630321334 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630321366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2411630321366 : Closed e2411630321366 ∧ code e2411630321366 = 11207723343574 := by decide
theorem cert_e2411630321366 : check e2411630321366 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630321370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2411630321370 : Closed e2411630321370 ∧ code e2411630321370 = 11207723343578 := by decide
theorem cert_e2411630321370 : check e2411630321370 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630321910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 1))))))
theorem wire_e2411630321910 : Closed e2411630321910 ∧ code e2411630321910 = 11207723344118 := by decide
theorem cert_e2411630321910 : check e2411630321910 [[],[]] .chain = true := by decide
def e2411630322102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))) (.var 1))))))
theorem wire_e2411630322102 : Closed e2411630322102 ∧ code e2411630322102 = 11207723344310 := by decide
theorem cert_e2411630322102 : check e2411630322102 [[],[]] .chain = true := by decide
def e2411630322106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))) (.var 0))))))
theorem wire_e2411630322106 : Closed e2411630322106 ∧ code e2411630322106 = 11207723344314 := by decide
theorem cert_e2411630322106 : check e2411630322106 [[],[]] .chain = true := by decide
def e2411630322134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))) (.var 1))))))
theorem wire_e2411630322134 : Closed e2411630322134 ∧ code e2411630322134 = 11207723344342 := by decide
theorem cert_e2411630322134 : check e2411630322134 [[],[]] .chain = true := by decide
def e2411630322154 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))) (.var 0))))))
theorem wire_e2411630322154 : Closed e2411630322154 ∧ code e2411630322154 = 11207723344362 := by decide
theorem cert_e2411630322154 : check e2411630322154 [[],[]] .chain = true := by decide
def e2411630322294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411630322294 : Closed e2411630322294 ∧ code e2411630322294 = 11207723344502 := by decide
theorem cert_e2411630322294 : check e2411630322294 [[],[]] .chain = true := by decide
def e2411630322486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630322486 : Closed e2411630322486 ∧ code e2411630322486 = 11207723344694 := by decide
theorem cert_e2411630322486 : check e2411630322486 [[],[]] .chain = true := by decide
def e2411630322490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630322490 : Closed e2411630322490 ∧ code e2411630322490 = 11207723344698 := by decide
theorem cert_e2411630322490 : check e2411630322490 [[],[]] .chain = true := by decide
def e2411630322574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 2)))))))
theorem wire_e2411630322574 : Closed e2411630322574 ∧ code e2411630322574 = 11207723344782 := by decide
theorem cert_e2411630322574 : check e2411630322574 [[],[]] .chain = true := by decide
def e2411630322586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630322586 : Closed e2411630322586 ∧ code e2411630322586 = 11207723344794 := by decide
theorem cert_e2411630322586 : check e2411630322586 [[],[]] .chain = true := by decide
def e2411630323254 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 1))))))
theorem wire_e2411630323254 : Closed e2411630323254 ∧ code e2411630323254 = 11207723345462 := by decide
theorem cert_e2411630323254 : check e2411630323254 [[],[]] .chain = true := by decide
def e2411630323258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.var 0))))))
theorem wire_e2411630323258 : Closed e2411630323258 ∧ code e2411630323258 = 11207723345466 := by decide
theorem cert_e2411630323258 : check e2411630323258 [[],[]] .chain = true := by decide
def e2411630323342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 2)))))))
theorem wire_e2411630323342 : Closed e2411630323342 ∧ code e2411630323342 = 11207723345550 := by decide
theorem cert_e2411630323342 : check e2411630323342 [[],[]] .chain = true := by decide
def e2411630323398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2411630323398 : Closed e2411630323398 ∧ code e2411630323398 = 11207723345606 := by decide
theorem cert_e2411630323398 : check e2411630323398 [[],[]] .chain = true := by decide
def e2411630323478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2411630323478 : Closed e2411630323478 ∧ code e2411630323478 = 11207723345686 := by decide
theorem cert_e2411630323478 : check e2411630323478 [[],[]] .chain = true := by decide
def e2411630323482 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2411630323482 : Closed e2411630323482 ∧ code e2411630323482 = 11207723345690 := by decide
theorem cert_e2411630323482 : check e2411630323482 [[],[]] .chain = true := by decide
def e2411630323526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2411630323526 : Closed e2411630323526 ∧ code e2411630323526 = 11207723345734 := by decide
theorem cert_e2411630323526 : check e2411630323526 [[],[]] .chain = true := by decide
def e2411630323554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2411630323554 : Closed e2411630323554 ∧ code e2411630323554 = 11207723345762 := by decide
theorem cert_e2411630323554 : check e2411630323554 [[],[]] .chain = true := by decide
def e2411630323566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2411630323566 : Closed e2411630323566 ∧ code e2411630323566 = 11207723345774 := by decide
theorem cert_e2411630323566 : check e2411630323566 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630323574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2411630323574 : Closed e2411630323574 ∧ code e2411630323574 = 11207723345782 := by decide
theorem cert_e2411630323574 : check e2411630323574 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630323638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2411630323638 : Closed e2411630323638 ∧ code e2411630323638 = 11207723345846 := by decide
theorem cert_e2411630323638 : check e2411630323638 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630323822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2411630323822 : Closed e2411630323822 ∧ code e2411630323822 = 11207723346030 := by decide
theorem cert_e2411630323822 : check e2411630323822 [[],[]] .chain = true := by decide
def e2411630323834 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2411630323834 : Closed e2411630323834 ∧ code e2411630323834 = 11207723346042 := by decide
theorem cert_e2411630323834 : check e2411630323834 [[],[]] .chain = true := by decide
def e2411630324110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411630324110 : Closed e2411630324110 ∧ code e2411630324110 = 11207723346318 := by decide
theorem cert_e2411630324110 : check e2411630324110 [[],[]] .chain = true := by decide
def e2411630324166 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411630324166 : Closed e2411630324166 ∧ code e2411630324166 = 11207723346374 := by decide
theorem cert_e2411630324166 : check e2411630324166 [[],[]] .chain = true := by decide
def e2411630324766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 3))))))))
theorem wire_e2411630324766 : Closed e2411630324766 ∧ code e2411630324766 = 11207723346974 := by decide
theorem cert_e2411630324766 : check e2411630324766 [[],[]] .chain = true := by decide
def e2411630324790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411630324790 : Closed e2411630324790 ∧ code e2411630324790 = 11207723346998 := by decide
theorem cert_e2411630324790 : check e2411630324790 [[],[]] .chain = true := by decide
def e2411630324794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411630324794 : Closed e2411630324794 ∧ code e2411630324794 = 11207723347002 := by decide
theorem cert_e2411630324794 : check e2411630324794 [[],[]] .chain = true := by decide
def e2411630324934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411630324934 : Closed e2411630324934 ∧ code e2411630324934 = 11207723347142 := by decide
theorem cert_e2411630324934 : check e2411630324934 [[],[]] .chain = true := by decide
def e2411630324962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411630324962 : Closed e2411630324962 ∧ code e2411630324962 = 11207723347170 := by decide
theorem cert_e2411630324962 : check e2411630324962 [[],[]] .chain = true := by decide
def e2411630324974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630324974 : Closed e2411630324974 ∧ code e2411630324974 = 11207723347182 := by decide
theorem cert_e2411630324974 : check e2411630324974 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630324982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630324982 : Closed e2411630324982 ∧ code e2411630324982 = 11207723347190 := by decide
theorem cert_e2411630324982 : check e2411630324982 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630325366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411630325366 : Closed e2411630325366 ∧ code e2411630325366 = 11207723347574 := by decide
theorem cert_e2411630325366 : check e2411630325366 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2411630325878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2411630325878 : Closed e2411630325878 ∧ code e2411630325878 = 11207723348086 := by decide
theorem cert_e2411630325878 : check e2411630325878 [[],[]] .chain = true := by decide
def e2411630325882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2411630325882 : Closed e2411630325882 ∧ code e2411630325882 = 11207723348090 := by decide
theorem cert_e2411630325882 : check e2411630325882 [[],[]] .chain = true := by decide
def e2411630325978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2411630325978 : Closed e2411630325978 ∧ code e2411630325978 = 11207723348186 := by decide
theorem cert_e2411630325978 : check e2411630325978 [[],[]] .chain = true := by decide
def e2411630325994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2411630325994 : Closed e2411630325994 ∧ code e2411630325994 = 11207723348202 := by decide
theorem cert_e2411630325994 : check e2411630325994 [[],[]] .chain = true := by decide
def e2411630326070 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630326070 : Closed e2411630326070 ∧ code e2411630326070 = 11207723348278 := by decide
theorem cert_e2411630326070 : check e2411630326070 [[],[]] .chain = true := by decide
def e2411630326074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630326074 : Closed e2411630326074 ∧ code e2411630326074 = 11207723348282 := by decide
theorem cert_e2411630326074 : check e2411630326074 [[],[]] .chain = true := by decide
def e2411630326158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2411630326158 : Closed e2411630326158 ∧ code e2411630326158 = 11207723348366 := by decide
theorem cert_e2411630326158 : check e2411630326158 [[],[]] .chain = true := by decide
def e2411630326170 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630326170 : Closed e2411630326170 ∧ code e2411630326170 = 11207723348378 := by decide
theorem cert_e2411630326170 : check e2411630326170 [[],[]] .chain = true := by decide
def e2411630326214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2411630326214 : Closed e2411630326214 ∧ code e2411630326214 = 11207723348422 := by decide
theorem cert_e2411630326214 : check e2411630326214 [[],[]] .chain = true := by decide
def e2411630326550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2411630326550 : Closed e2411630326550 ∧ code e2411630326550 = 11207723348758 := by decide
theorem cert_e2411630326550 : check e2411630326550 [[],[]] .chain = true := by decide
def e2411630326554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2411630326554 : Closed e2411630326554 ∧ code e2411630326554 = 11207723348762 := by decide
theorem cert_e2411630326554 : check e2411630326554 [[],[]] .chain = true := by decide
def e2411630326598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2411630326598 : Closed e2411630326598 ∧ code e2411630326598 = 11207723348806 := by decide
theorem cert_e2411630326598 : check e2411630326598 [[],[]] .chain = true := by decide
def e2411630326626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2411630326626 : Closed e2411630326626 ∧ code e2411630326626 = 11207723348834 := by decide
theorem cert_e2411630326626 : check e2411630326626 [[],[]] .chain = true := by decide
def e2411630326638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2411630326638 : Closed e2411630326638 ∧ code e2411630326638 = 11207723348846 := by decide
theorem cert_e2411630326638 : check e2411630326638 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630326646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2411630326646 : Closed e2411630326646 ∧ code e2411630326646 = 11207723348854 := by decide
theorem cert_e2411630326646 : check e2411630326646 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630326666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2411630326666 : Closed e2411630326666 ∧ code e2411630326666 = 11207723348874 := by decide
theorem cert_e2411630326666 : check e2411630326666 [[],[]] .chain = true := by decide
def e2411630326690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2411630326690 : Closed e2411630326690 ∧ code e2411630326690 = 11207723348898 := by decide
theorem cert_e2411630326690 : check e2411630326690 [[],[]] .chain = true := by decide
def e2411630326702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2411630326702 : Closed e2411630326702 ∧ code e2411630326702 = 11207723348910 := by decide
theorem cert_e2411630326702 : check e2411630326702 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2411630326714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2411630326714 : Closed e2411630326714 ∧ code e2411630326714 = 11207723348922 := by decide
theorem cert_e2411630326714 : check e2411630326714 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630326742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2411630326742 : Closed e2411630326742 ∧ code e2411630326742 = 11207723348950 := by decide
theorem cert_e2411630326742 : check e2411630326742 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630326746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2411630326746 : Closed e2411630326746 ∧ code e2411630326746 = 11207723348954 := by decide
theorem cert_e2411630326746 : check e2411630326746 [[],[],[.under,.under,.left]] .smaller = true := by decide
def e2411630326814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2411630326814 : Closed e2411630326814 ∧ code e2411630326814 = 11207723349022 := by decide
theorem cert_e2411630326814 : check e2411630326814 [[],[]] .chain = true := by decide
def e2411630326838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411630326838 : Closed e2411630326838 ∧ code e2411630326838 = 11207723349046 := by decide
theorem cert_e2411630326838 : check e2411630326838 [[],[]] .chain = true := by decide
def e2411630326842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411630326842 : Closed e2411630326842 ∧ code e2411630326842 = 11207723349050 := by decide
theorem cert_e2411630326842 : check e2411630326842 [[],[]] .chain = true := by decide
def e2411630326982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411630326982 : Closed e2411630326982 ∧ code e2411630326982 = 11207723349190 := by decide
theorem cert_e2411630326982 : check e2411630326982 [[],[]] .chain = true := by decide
def e2411630327010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411630327010 : Closed e2411630327010 ∧ code e2411630327010 = 11207723349218 := by decide
theorem cert_e2411630327010 : check e2411630327010 [[],[]] .chain = true := by decide
def e2411630327022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630327022 : Closed e2411630327022 ∧ code e2411630327022 = 11207723349230 := by decide
theorem cert_e2411630327022 : check e2411630327022 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
end Blc.Floor43
