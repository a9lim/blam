import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759404153814 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759404153814 : Closed e759404153814 ∧ code e759404153814 = 9555497176022 := by decide
theorem cert_e759404153814 : check e759404153814 [] .sourceHead = true := by decide
def e759404153818 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759404153818 : Closed e759404153818 ∧ code e759404153818 = 9555497176026 := by decide
theorem cert_e759404153818 : check e759404153818 [] .sourceHead = true := by decide
def e759404153834 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e759404153834 : Closed e759404153834 ∧ code e759404153834 = 9555497176042 := by decide
theorem cert_e759404153834 : check e759404153834 [] .sourceHead = true := by decide
def e759404154078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e759404154078 : Closed e759404154078 ∧ code e759404154078 = 9555497176286 := by decide
theorem cert_e759404154078 : check e759404154078 [] .sourceHead = true := by decide
def e759404154094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759404154094 : Closed e759404154094 ∧ code e759404154094 = 9555497176302 := by decide
theorem cert_e759404154094 : check e759404154094 [] .sourceHead = true := by decide
def e759404154102 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759404154102 : Closed e759404154102 ∧ code e759404154102 = 9555497176310 := by decide
theorem cert_e759404154102 : check e759404154102 [] .sourceHead = true := by decide
def e759404154106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e759404154106 : Closed e759404154106 ∧ code e759404154106 = 9555497176314 := by decide
theorem cert_e759404154106 : check e759404154106 [] .sourceHead = true := by decide
def e759404154478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759404154478 : Closed e759404154478 ∧ code e759404154478 = 9555497176686 := by decide
theorem cert_e759404154478 : check e759404154478 [] .sourceHead = true := by decide
def e759404154490 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759404154490 : Closed e759404154490 ∧ code e759404154490 = 9555497176698 := by decide
theorem cert_e759404154490 : check e759404154490 [] .sourceHead = true := by decide
def e759404154678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759404154678 : Closed e759404154678 ∧ code e759404154678 = 9555497176886 := by decide
theorem cert_e759404154678 : check e759404154678 [] .sourceHead = true := by decide
def e759404154682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759404154682 : Closed e759404154682 ∧ code e759404154682 = 9555497176890 := by decide
theorem cert_e759404154682 : check e759404154682 [] .sourceHead = true := by decide
def e759404154778 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404154778 : Closed e759404154778 ∧ code e759404154778 = 9555497176986 := by decide
theorem cert_e759404154778 : check e759404154778 [] .sourceHead = true := by decide
def e759404160430 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e759404160430 : Closed e759404160430 ∧ code e759404160430 = 9555497182638 := by decide
theorem cert_e759404160430 : check e759404160430 [] .sourceHead = true := by decide
def e759404160438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e759404160438 : Closed e759404160438 ∧ code e759404160438 = 9555497182646 := by decide
theorem cert_e759404160438 : check e759404160438 [] .sourceHead = true := by decide
def e759404160442 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e759404160442 : Closed e759404160442 ∧ code e759404160442 = 9555497182650 := by decide
theorem cert_e759404160442 : check e759404160442 [] .sourceHead = true := by decide
def e759404160470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e759404160470 : Closed e759404160470 ∧ code e759404160470 = 9555497182678 := by decide
theorem cert_e759404160470 : check e759404160470 [] .sourceHead = true := by decide
def e759404160474 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e759404160474 : Closed e759404160474 ∧ code e759404160474 = 9555497182682 := by decide
theorem cert_e759404160474 : check e759404160474 [] .sourceHead = true := by decide
def e759404160490 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e759404160490 : Closed e759404160490 ∧ code e759404160490 = 9555497182698 := by decide
theorem cert_e759404160490 : check e759404160490 [] .sourceHead = true := by decide
def e759404160622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e759404160622 : Closed e759404160622 ∧ code e759404160622 = 9555497182830 := by decide
theorem cert_e759404160622 : check e759404160622 [] .sourceHead = true := by decide
def e759404160630 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e759404160630 : Closed e759404160630 ∧ code e759404160630 = 9555497182838 := by decide
theorem cert_e759404160630 : check e759404160630 [] .sourceHead = true := by decide
def e759404160634 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e759404160634 : Closed e759404160634 ∧ code e759404160634 = 9555497182842 := by decide
theorem cert_e759404160634 : check e759404160634 [] .sourceHead = true := by decide
def e759404160822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e759404160822 : Closed e759404160822 ∧ code e759404160822 = 9555497183030 := by decide
theorem cert_e759404160822 : check e759404160822 [] .sourceHead = true := by decide
def e759404160826 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e759404160826 : Closed e759404160826 ∧ code e759404160826 = 9555497183034 := by decide
theorem cert_e759404160826 : check e759404160826 [] .sourceHead = true := by decide
def e759404160922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404160922 : Closed e759404160922 ∧ code e759404160922 = 9555497183130 := by decide
theorem cert_e759404160922 : check e759404160922 [] .sourceHead = true := by decide
def e759404606830 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e759404606830 : Closed e759404606830 ∧ code e759404606830 = 9555497629038 := by decide
theorem cert_e759404606830 : check e759404606830 [] .sourceHead = true := by decide
def e759404606838 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e759404606838 : Closed e759404606838 ∧ code e759404606838 = 9555497629046 := by decide
theorem cert_e759404606838 : check e759404606838 [] .sourceHead = true := by decide
def e759404606894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e759404606894 : Closed e759404606894 ∧ code e759404606894 = 9555497629102 := by decide
theorem cert_e759404606894 : check e759404606894 [] .sourceHead = true := by decide
def e759404606906 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e759404606906 : Closed e759404606906 ∧ code e759404606906 = 9555497629114 := by decide
theorem cert_e759404606906 : check e759404606906 [] .sourceHead = true := by decide
def e759404606934 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e759404606934 : Closed e759404606934 ∧ code e759404606934 = 9555497629142 := by decide
theorem cert_e759404606934 : check e759404606934 [] .sourceHead = true := by decide
def e759404606938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e759404606938 : Closed e759404606938 ∧ code e759404606938 = 9555497629146 := by decide
theorem cert_e759404606938 : check e759404606938 [] .sourceHead = true := by decide
def e759404607150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e759404607150 : Closed e759404607150 ∧ code e759404607150 = 9555497629358 := by decide
theorem cert_e759404607150 : check e759404607150 [] .sourceHead = true := by decide
def e759404607162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e759404607162 : Closed e759404607162 ∧ code e759404607162 = 9555497629370 := by decide
theorem cert_e759404607162 : check e759404607162 [] .sourceHead = true := by decide
def e759404607210 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e759404607210 : Closed e759404607210 ∧ code e759404607210 = 9555497629418 := by decide
theorem cert_e759404607210 : check e759404607210 [] .sourceHead = true := by decide
def e759404607318 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e759404607318 : Closed e759404607318 ∧ code e759404607318 = 9555497629526 := by decide
theorem cert_e759404607318 : check e759404607318 [] .sourceHead = true := by decide
def e759404607322 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e759404607322 : Closed e759404607322 ∧ code e759404607322 = 9555497629530 := by decide
theorem cert_e759404607322 : check e759404607322 [] .sourceHead = true := by decide
def e759404607338 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e759404607338 : Closed e759404607338 ∧ code e759404607338 = 9555497629546 := by decide
theorem cert_e759404607338 : check e759404607338 [] .sourceHead = true := by decide
def e759404608174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e759404608174 : Closed e759404608174 ∧ code e759404608174 = 9555497630382 := by decide
theorem cert_e759404608174 : check e759404608174 [] .sourceHead = true := by decide
def e759404608186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e759404608186 : Closed e759404608186 ∧ code e759404608186 = 9555497630394 := by decide
theorem cert_e759404608186 : check e759404608186 [] .sourceHead = true := by decide
def e759404608234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e759404608234 : Closed e759404608234 ∧ code e759404608234 = 9555497630442 := by decide
theorem cert_e759404608234 : check e759404608234 [] .sourceHead = true := by decide
def e759404608426 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e759404608426 : Closed e759404608426 ∧ code e759404608426 = 9555497630634 := by decide
theorem cert_e759404608426 : check e759404608426 [] .sourceHead = true := by decide
def e759404608854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e759404608854 : Closed e759404608854 ∧ code e759404608854 = 9555497631062 := by decide
theorem cert_e759404608854 : check e759404608854 [] .sourceHead = true := by decide
def e759404608858 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e759404608858 : Closed e759404608858 ∧ code e759404608858 = 9555497631066 := by decide
theorem cert_e759404608858 : check e759404608858 [] .sourceHead = true := by decide
def e759404608874 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e759404608874 : Closed e759404608874 ∧ code e759404608874 = 9555497631082 := by decide
theorem cert_e759404608874 : check e759404608874 [] .sourceHead = true := by decide
def e759404608938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e759404608938 : Closed e759404608938 ∧ code e759404608938 = 9555497631146 := by decide
theorem cert_e759404608938 : check e759404608938 [] .sourceHead = true := by decide
def e759404611438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))
theorem wire_e759404611438 : Closed e759404611438 ∧ code e759404611438 = 9555497633646 := by decide
theorem cert_e759404611438 : check e759404611438 [] .sourceHead = true := by decide
def e759404611446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))
theorem wire_e759404611446 : Closed e759404611446 ∧ code e759404611446 = 9555497633654 := by decide
theorem cert_e759404611446 : check e759404611446 [] .sourceHead = true := by decide
def e759404611510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))
theorem wire_e759404611510 : Closed e759404611510 ∧ code e759404611510 = 9555497633718 := by decide
theorem cert_e759404611510 : check e759404611510 [] .sourceHead = true := by decide
def e759404612974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e759404612974 : Closed e759404612974 ∧ code e759404612974 = 9555497635182 := by decide
theorem cert_e759404612974 : check e759404612974 [] .sourceHead = true := by decide
def e759404612982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e759404612982 : Closed e759404612982 ∧ code e759404612982 = 9555497635190 := by decide
theorem cert_e759404612982 : check e759404612982 [] .sourceHead = true := by decide
def e759404613038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e759404613038 : Closed e759404613038 ∧ code e759404613038 = 9555497635246 := by decide
theorem cert_e759404613038 : check e759404613038 [] .sourceHead = true := by decide
def e759404613050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e759404613050 : Closed e759404613050 ∧ code e759404613050 = 9555497635258 := by decide
theorem cert_e759404613050 : check e759404613050 [] .sourceHead = true := by decide
def e759404613078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e759404613078 : Closed e759404613078 ∧ code e759404613078 = 9555497635286 := by decide
theorem cert_e759404613078 : check e759404613078 [] .sourceHead = true := by decide
def e759404613082 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e759404613082 : Closed e759404613082 ∧ code e759404613082 = 9555497635290 := by decide
theorem cert_e759404613082 : check e759404613082 [] .sourceHead = true := by decide
def e759404613294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e759404613294 : Closed e759404613294 ∧ code e759404613294 = 9555497635502 := by decide
theorem cert_e759404613294 : check e759404613294 [] .sourceHead = true := by decide
def e759404613306 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e759404613306 : Closed e759404613306 ∧ code e759404613306 = 9555497635514 := by decide
theorem cert_e759404613306 : check e759404613306 [] .sourceHead = true := by decide
def e759404613354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e759404613354 : Closed e759404613354 ∧ code e759404613354 = 9555497635562 := by decide
theorem cert_e759404613354 : check e759404613354 [] .sourceHead = true := by decide
def e759404613462 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e759404613462 : Closed e759404613462 ∧ code e759404613462 = 9555497635670 := by decide
theorem cert_e759404613462 : check e759404613462 [] .sourceHead = true := by decide
def e759404613466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e759404613466 : Closed e759404613466 ∧ code e759404613466 = 9555497635674 := by decide
theorem cert_e759404613466 : check e759404613466 [] .sourceHead = true := by decide
def e759404613482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e759404613482 : Closed e759404613482 ∧ code e759404613482 = 9555497635690 := by decide
theorem cert_e759404613482 : check e759404613482 [] .sourceHead = true := by decide
def e759404614510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e759404614510 : Closed e759404614510 ∧ code e759404614510 = 9555497636718 := by decide
theorem cert_e759404614510 : check e759404614510 [] .sourceHead = true := by decide
def e759404614518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e759404614518 : Closed e759404614518 ∧ code e759404614518 = 9555497636726 := by decide
theorem cert_e759404614518 : check e759404614518 [] .sourceHead = true := by decide
def e759404614574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e759404614574 : Closed e759404614574 ∧ code e759404614574 = 9555497636782 := by decide
theorem cert_e759404614574 : check e759404614574 [] .sourceHead = true := by decide
def e759404614586 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e759404614586 : Closed e759404614586 ∧ code e759404614586 = 9555497636794 := by decide
theorem cert_e759404614586 : check e759404614586 [] .sourceHead = true := by decide
def e759404614614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e759404614614 : Closed e759404614614 ∧ code e759404614614 = 9555497636822 := by decide
theorem cert_e759404614614 : check e759404614614 [] .sourceHead = true := by decide
def e759404614618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e759404614618 : Closed e759404614618 ∧ code e759404614618 = 9555497636826 := by decide
theorem cert_e759404614618 : check e759404614618 [] .sourceHead = true := by decide
def e759404614894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e759404614894 : Closed e759404614894 ∧ code e759404614894 = 9555497637102 := by decide
theorem cert_e759404614894 : check e759404614894 [] .sourceHead = true := by decide
def e759404614902 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e759404614902 : Closed e759404614902 ∧ code e759404614902 = 9555497637110 := by decide
theorem cert_e759404614902 : check e759404614902 [] .sourceHead = true := by decide
def e759404615278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e759404615278 : Closed e759404615278 ∧ code e759404615278 = 9555497637486 := by decide
theorem cert_e759404615278 : check e759404615278 [] .sourceHead = true := by decide
def e759404615290 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e759404615290 : Closed e759404615290 ∧ code e759404615290 = 9555497637498 := by decide
theorem cert_e759404615290 : check e759404615290 [] .sourceHead = true := by decide
def e759404615478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e759404615478 : Closed e759404615478 ∧ code e759404615478 = 9555497637686 := by decide
theorem cert_e759404615478 : check e759404615478 [] .sourceHead = true := by decide
def e759404615482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e759404615482 : Closed e759404615482 ∧ code e759404615482 = 9555497637690 := by decide
theorem cert_e759404615482 : check e759404615482 [] .sourceHead = true := by decide
def e759404615918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e759404615918 : Closed e759404615918 ∧ code e759404615918 = 9555497638126 := by decide
theorem cert_e759404615918 : check e759404615918 [] .sourceHead = true := by decide
def e759404615926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e759404615926 : Closed e759404615926 ∧ code e759404615926 = 9555497638134 := by decide
theorem cert_e759404615926 : check e759404615926 [] .sourceHead = true := by decide
def e759404616110 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e759404616110 : Closed e759404616110 ∧ code e759404616110 = 9555497638318 := by decide
theorem cert_e759404616110 : check e759404616110 [] .sourceHead = true := by decide
def e759404616122 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e759404616122 : Closed e759404616122 ∧ code e759404616122 = 9555497638330 := by decide
theorem cert_e759404616122 : check e759404616122 [] .sourceHead = true := by decide
def e759404616170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e759404616170 : Closed e759404616170 ∧ code e759404616170 = 9555497638378 := by decide
theorem cert_e759404616170 : check e759404616170 [] .sourceHead = true := by decide
def e759404616302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e759404616302 : Closed e759404616302 ∧ code e759404616302 = 9555497638510 := by decide
theorem cert_e759404616302 : check e759404616302 [] .sourceHead = true := by decide
def e759404616314 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e759404616314 : Closed e759404616314 ∧ code e759404616314 = 9555497638522 := by decide
theorem cert_e759404616314 : check e759404616314 [] .sourceHead = true := by decide
def e759404616478 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e759404616478 : Closed e759404616478 ∧ code e759404616478 = 9555497638686 := by decide
theorem cert_e759404616478 : check e759404616478 [] .sourceHead = true := by decide
def e759404616590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e759404616590 : Closed e759404616590 ∧ code e759404616590 = 9555497638798 := by decide
theorem cert_e759404616590 : check e759404616590 [] .sourceHead = true := by decide
def e759404616602 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e759404616602 : Closed e759404616602 ∧ code e759404616602 = 9555497638810 := by decide
theorem cert_e759404616602 : check e759404616602 [] .sourceHead = true := by decide
def e759404616822 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e759404616822 : Closed e759404616822 ∧ code e759404616822 = 9555497639030 := by decide
theorem cert_e759404616822 : check e759404616822 [] .sourceHead = true := by decide
def e759404616918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e759404616918 : Closed e759404616918 ∧ code e759404616918 = 9555497639126 := by decide
theorem cert_e759404616918 : check e759404616918 [] .sourceHead = true := by decide
def e759404616922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e759404616922 : Closed e759404616922 ∧ code e759404616922 = 9555497639130 := by decide
theorem cert_e759404616922 : check e759404616922 [] .sourceHead = true := by decide
def e759404616938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e759404616938 : Closed e759404616938 ∧ code e759404616938 = 9555497639146 := by decide
theorem cert_e759404616938 : check e759404616938 [] .sourceHead = true := by decide
def e759404617014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e759404617014 : Closed e759404617014 ∧ code e759404617014 = 9555497639222 := by decide
theorem cert_e759404617014 : check e759404617014 [] .sourceHead = true := by decide
def e759404617018 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e759404617018 : Closed e759404617018 ∧ code e759404617018 = 9555497639226 := by decide
theorem cert_e759404617018 : check e759404617018 [] .sourceHead = true := by decide
def e759404617102 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e759404617102 : Closed e759404617102 ∧ code e759404617102 = 9555497639310 := by decide
theorem cert_e759404617102 : check e759404617102 [] .sourceHead = true := by decide
def e759404617114 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e759404617114 : Closed e759404617114 ∧ code e759404617114 = 9555497639322 := by decide
theorem cert_e759404617114 : check e759404617114 [] .sourceHead = true := by decide
def e759404618606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)))))))
theorem wire_e759404618606 : Closed e759404618606 ∧ code e759404618606 = 9555497640814 := by decide
theorem cert_e759404618606 : check e759404618606 [] .sourceHead = true := by decide
def e759404618614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)))))))
theorem wire_e759404618614 : Closed e759404618614 ∧ code e759404618614 = 9555497640822 := by decide
theorem cert_e759404618614 : check e759404618614 [] .sourceHead = true := by decide
def e759404618670 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)))))))
theorem wire_e759404618670 : Closed e759404618670 ∧ code e759404618670 = 9555497640878 := by decide
theorem cert_e759404618670 : check e759404618670 [] .sourceHead = true := by decide
def e759404618682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)))))))
theorem wire_e759404618682 : Closed e759404618682 ∧ code e759404618682 = 9555497640890 := by decide
theorem cert_e759404618682 : check e759404618682 [] .sourceHead = true := by decide
def e759404618710 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)))))))
theorem wire_e759404618710 : Closed e759404618710 ∧ code e759404618710 = 9555497640918 := by decide
theorem cert_e759404618710 : check e759404618710 [] .sourceHead = true := by decide
def e759404618714 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)))))))
theorem wire_e759404618714 : Closed e759404618714 ∧ code e759404618714 = 9555497640922 := by decide
theorem cert_e759404618714 : check e759404618714 [] .sourceHead = true := by decide
def e759404619438 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e759404619438 : Closed e759404619438 ∧ code e759404619438 = 9555497641646 := by decide
theorem cert_e759404619438 : check e759404619438 [] .sourceHead = true := by decide
def e759404619450 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e759404619450 : Closed e759404619450 ∧ code e759404619450 = 9555497641658 := by decide
theorem cert_e759404619450 : check e759404619450 [] .sourceHead = true := by decide
def e759404619498 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e759404619498 : Closed e759404619498 ∧ code e759404619498 = 9555497641706 := by decide
theorem cert_e759404619498 : check e759404619498 [] .sourceHead = true := by decide
def e759404619690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e759404619690 : Closed e759404619690 ∧ code e759404619690 = 9555497641898 := by decide
theorem cert_e759404619690 : check e759404619690 [] .sourceHead = true := by decide
def e759404620014 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)))))))
theorem wire_e759404620014 : Closed e759404620014 ∧ code e759404620014 = 9555497642222 := by decide
theorem cert_e759404620014 : check e759404620014 [] .sourceHead = true := by decide
def e759404620022 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)))))))
theorem wire_e759404620022 : Closed e759404620022 ∧ code e759404620022 = 9555497642230 := by decide
theorem cert_e759404620022 : check e759404620022 [] .sourceHead = true := by decide
def e759404620206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e759404620206 : Closed e759404620206 ∧ code e759404620206 = 9555497642414 := by decide
theorem cert_e759404620206 : check e759404620206 [] .sourceHead = true := by decide
def e759404620218 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e759404620218 : Closed e759404620218 ∧ code e759404620218 = 9555497642426 := by decide
theorem cert_e759404620218 : check e759404620218 [] .sourceHead = true := by decide
def e759404620266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e759404620266 : Closed e759404620266 ∧ code e759404620266 = 9555497642474 := by decide
theorem cert_e759404620266 : check e759404620266 [] .sourceHead = true := by decide
def e759404620398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e759404620398 : Closed e759404620398 ∧ code e759404620398 = 9555497642606 := by decide
theorem cert_e759404620398 : check e759404620398 [] .sourceHead = true := by decide
def e759404620410 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e759404620410 : Closed e759404620410 ∧ code e759404620410 = 9555497642618 := by decide
theorem cert_e759404620410 : check e759404620410 [] .sourceHead = true := by decide
def e759404620574 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3))))))))
theorem wire_e759404620574 : Closed e759404620574 ∧ code e759404620574 = 9555497642782 := by decide
theorem cert_e759404620574 : check e759404620574 [] .sourceHead = true := by decide
def e759404620686 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2))))))))
theorem wire_e759404620686 : Closed e759404620686 ∧ code e759404620686 = 9555497642894 := by decide
theorem cert_e759404620686 : check e759404620686 [] .sourceHead = true := by decide
def e759404620698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e759404620698 : Closed e759404620698 ∧ code e759404620698 = 9555497642906 := by decide
theorem cert_e759404620698 : check e759404620698 [] .sourceHead = true := by decide
def e759404620910 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2)))))))
theorem wire_e759404620910 : Closed e759404620910 ∧ code e759404620910 = 9555497643118 := by decide
theorem cert_e759404620910 : check e759404620910 [] .sourceHead = true := by decide
def e759404620922 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0)))))))
theorem wire_e759404620922 : Closed e759404620922 ∧ code e759404620922 = 9555497643130 := by decide
theorem cert_e759404620922 : check e759404620922 [] .sourceHead = true := by decide
def e759404621086 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3))))))))
theorem wire_e759404621086 : Closed e759404621086 ∧ code e759404621086 = 9555497643294 := by decide
theorem cert_e759404621086 : check e759404621086 [] .sourceHead = true := by decide
def e759404621254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1))))))))
theorem wire_e759404621254 : Closed e759404621254 ∧ code e759404621254 = 9555497643462 := by decide
theorem cert_e759404621254 : check e759404621254 [] .sourceHead = true := by decide
def e759404621366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e759404621366 : Closed e759404621366 ∧ code e759404621366 = 9555497643574 := by decide
theorem cert_e759404621366 : check e759404621366 [] .sourceHead = true := by decide
def e759404621370 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e759404621370 : Closed e759404621370 ∧ code e759404621370 = 9555497643578 := by decide
theorem cert_e759404621370 : check e759404621370 [] .sourceHead = true := by decide
def e759404621418 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e759404621418 : Closed e759404621418 ∧ code e759404621418 = 9555497643626 := by decide
theorem cert_e759404621418 : check e759404621418 [] .sourceHead = true := by decide
def e759404621454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e759404621454 : Closed e759404621454 ∧ code e759404621454 = 9555497643662 := by decide
theorem cert_e759404621454 : check e759404621454 [] .sourceHead = true := by decide
def e759404621466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e759404621466 : Closed e759404621466 ∧ code e759404621466 = 9555497643674 := by decide
theorem cert_e759404621466 : check e759404621466 [] .sourceHead = true := by decide
def e759404621510 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e759404621510 : Closed e759404621510 ∧ code e759404621510 = 9555497643718 := by decide
theorem cert_e759404621510 : check e759404621510 [] .sourceHead = true := by decide
def e759404622262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1)))))))
theorem wire_e759404622262 : Closed e759404622262 ∧ code e759404622262 = 9555497644470 := by decide
theorem cert_e759404622262 : check e759404622262 [] .sourceHead = true := by decide
def e759404622294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e759404622294 : Closed e759404622294 ∧ code e759404622294 = 9555497644502 := by decide
theorem cert_e759404622294 : check e759404622294 [] .sourceHead = true := by decide
def e759404622298 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e759404622298 : Closed e759404622298 ∧ code e759404622298 = 9555497644506 := by decide
theorem cert_e759404622298 : check e759404622298 [] .sourceHead = true := by decide
def e759404622678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e759404622678 : Closed e759404622678 ∧ code e759404622678 = 9555497644886 := by decide
theorem cert_e759404622678 : check e759404622678 [] .sourceHead = true := by decide
def e759404622682 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e759404622682 : Closed e759404622682 ∧ code e759404622682 = 9555497644890 := by decide
theorem cert_e759404622682 : check e759404622682 [] .sourceHead = true := by decide
def e759404622698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e759404622698 : Closed e759404622698 ∧ code e759404622698 = 9555497644906 := by decide
theorem cert_e759404622698 : check e759404622698 [] .sourceHead = true := by decide
def e759404622762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e759404622762 : Closed e759404622762 ∧ code e759404622762 = 9555497644970 := by decide
theorem cert_e759404622762 : check e759404622762 [] .sourceHead = true := by decide
def e759404622966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1)))))))
theorem wire_e759404622966 : Closed e759404622966 ∧ code e759404622966 = 9555497645174 := by decide
theorem cert_e759404622966 : check e759404622966 [] .sourceHead = true := by decide
def e759404623062 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e759404623062 : Closed e759404623062 ∧ code e759404623062 = 9555497645270 := by decide
theorem cert_e759404623062 : check e759404623062 [] .sourceHead = true := by decide
def e759404623066 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e759404623066 : Closed e759404623066 ∧ code e759404623066 = 9555497645274 := by decide
theorem cert_e759404623066 : check e759404623066 [] .sourceHead = true := by decide
def e759404623082 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e759404623082 : Closed e759404623082 ∧ code e759404623082 = 9555497645290 := by decide
theorem cert_e759404623082 : check e759404623082 [] .sourceHead = true := by decide
def e759404623158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e759404623158 : Closed e759404623158 ∧ code e759404623158 = 9555497645366 := by decide
theorem cert_e759404623158 : check e759404623158 [] .sourceHead = true := by decide
def e759404623162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e759404623162 : Closed e759404623162 ∧ code e759404623162 = 9555497645370 := by decide
theorem cert_e759404623162 : check e759404623162 [] .sourceHead = true := by decide
def e759404623246 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2))))))))
theorem wire_e759404623246 : Closed e759404623246 ∧ code e759404623246 = 9555497645454 := by decide
theorem cert_e759404623246 : check e759404623246 [] .sourceHead = true := by decide
def e759404623258 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e759404623258 : Closed e759404623258 ∧ code e759404623258 = 9555497645466 := by decide
theorem cert_e759404623258 : check e759404623258 [] .sourceHead = true := by decide
def e759404623414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1)))))))
theorem wire_e759404623414 : Closed e759404623414 ∧ code e759404623414 = 9555497645622 := by decide
theorem cert_e759404623414 : check e759404623414 [] .sourceHead = true := by decide
def e759404623418 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0)))))))
theorem wire_e759404623418 : Closed e759404623418 ∧ code e759404623418 = 9555497645626 := by decide
theorem cert_e759404623418 : check e759404623418 [] .sourceHead = true := by decide
def e759404623466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e759404623466 : Closed e759404623466 ∧ code e759404623466 = 9555497645674 := by decide
theorem cert_e759404623466 : check e759404623466 [] .sourceHead = true := by decide
def e759404623502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2))))))))
theorem wire_e759404623502 : Closed e759404623502 ∧ code e759404623502 = 9555497645710 := by decide
theorem cert_e759404623502 : check e759404623502 [] .sourceHead = true := by decide
def e759404623514 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e759404623514 : Closed e759404623514 ∧ code e759404623514 = 9555497645722 := by decide
theorem cert_e759404623514 : check e759404623514 [] .sourceHead = true := by decide
def e759404623558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1))))))))
theorem wire_e759404623558 : Closed e759404623558 ∧ code e759404623558 = 9555497645766 := by decide
theorem cert_e759404623558 : check e759404623558 [] .sourceHead = true := by decide
def e759404629742 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2)))))))
theorem wire_e759404629742 : Closed e759404629742 ∧ code e759404629742 = 9555497651950 := by decide
theorem cert_e759404629742 : check e759404629742 [] .sourceHead = true := by decide
def e759404629750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1)))))))
theorem wire_e759404629750 : Closed e759404629750 ∧ code e759404629750 = 9555497651958 := by decide
theorem cert_e759404629750 : check e759404629750 [] .sourceHead = true := by decide
def e759404629870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2)))))))
theorem wire_e759404629870 : Closed e759404629870 ∧ code e759404629870 = 9555497652078 := by decide
theorem cert_e759404629870 : check e759404629870 [] .sourceHead = true := by decide
def e759404629882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0)))))))
theorem wire_e759404629882 : Closed e759404629882 ∧ code e759404629882 = 9555497652090 := by decide
theorem cert_e759404629882 : check e759404629882 [] .sourceHead = true := by decide
def e759404629942 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1)))))))
theorem wire_e759404629942 : Closed e759404629942 ∧ code e759404629942 = 9555497652150 := by decide
theorem cert_e759404629942 : check e759404629942 [] .sourceHead = true := by decide
def e759404629946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0)))))))
theorem wire_e759404629946 : Closed e759404629946 ∧ code e759404629946 = 9555497652154 := by decide
theorem cert_e759404629946 : check e759404629946 [] .sourceHead = true := by decide
def e759404633326 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2))))))))
theorem wire_e759404633326 : Closed e759404633326 ∧ code e759404633326 = 9555497655534 := by decide
theorem cert_e759404633326 : check e759404633326 [] .sourceHead = true := by decide
def e759404633334 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1))))))))
theorem wire_e759404633334 : Closed e759404633334 ∧ code e759404633334 = 9555497655542 := by decide
theorem cert_e759404633334 : check e759404633334 [] .sourceHead = true := by decide
def e759404633718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))))))))
theorem wire_e759404633718 : Closed e759404633718 ∧ code e759404633718 = 9555497655926 := by decide
theorem cert_e759404633718 : check e759404633718 [] .sourceHead = true := by decide
def e759404637550 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)))))))
theorem wire_e759404637550 : Closed e759404637550 ∧ code e759404637550 = 9555497659758 := by decide
theorem cert_e759404637550 : check e759404637550 [] .sourceHead = true := by decide
def e759404637558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)))))))
theorem wire_e759404637558 : Closed e759404637558 ∧ code e759404637558 = 9555497659766 := by decide
theorem cert_e759404637558 : check e759404637558 [] .sourceHead = true := by decide
def e759404637614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)))))))
theorem wire_e759404637614 : Closed e759404637614 ∧ code e759404637614 = 9555497659822 := by decide
theorem cert_e759404637614 : check e759404637614 [] .sourceHead = true := by decide
def e759404637626 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)))))))
theorem wire_e759404637626 : Closed e759404637626 ∧ code e759404637626 = 9555497659834 := by decide
theorem cert_e759404637626 : check e759404637626 [] .sourceHead = true := by decide
def e759404637654 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)))))))
theorem wire_e759404637654 : Closed e759404637654 ∧ code e759404637654 = 9555497659862 := by decide
theorem cert_e759404637654 : check e759404637654 [] .sourceHead = true := by decide
def e759404637658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)))))))
theorem wire_e759404637658 : Closed e759404637658 ∧ code e759404637658 = 9555497659866 := by decide
theorem cert_e759404637658 : check e759404637658 [] .sourceHead = true := by decide
def e759404637870 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)))))))
theorem wire_e759404637870 : Closed e759404637870 ∧ code e759404637870 = 9555497660078 := by decide
theorem cert_e759404637870 : check e759404637870 [] .sourceHead = true := by decide
def e759404637882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)))))))
theorem wire_e759404637882 : Closed e759404637882 ∧ code e759404637882 = 9555497660090 := by decide
theorem cert_e759404637882 : check e759404637882 [] .sourceHead = true := by decide
def e759404637930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)))))))
theorem wire_e759404637930 : Closed e759404637930 ∧ code e759404637930 = 9555497660138 := by decide
theorem cert_e759404637930 : check e759404637930 [] .sourceHead = true := by decide
def e759404638038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)))))))
theorem wire_e759404638038 : Closed e759404638038 ∧ code e759404638038 = 9555497660246 := by decide
theorem cert_e759404638038 : check e759404638038 [] .sourceHead = true := by decide
def e759404638042 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)))))))
theorem wire_e759404638042 : Closed e759404638042 ∧ code e759404638042 = 9555497660250 := by decide
theorem cert_e759404638042 : check e759404638042 [] .sourceHead = true := by decide
end Blc.Floor43
