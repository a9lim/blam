import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422361763262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 4)))))))))))
theorem wire_e2422361763262 : Closed e2422361763262 ∧ code e2422361763262 = 11218454785470 := by decide
theorem cert_e2422361763262 : check e2422361763262 [[],[]] .smaller = true := by decide
def e2422361763294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 3)))))))))))
theorem wire_e2422361763294 : Closed e2422361763294 ∧ code e2422361763294 = 11218454785502 := by decide
theorem cert_e2422361763294 : check e2422361763294 [[],[]] .smaller = true := by decide
def e2422361763310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 2)))))))))))
theorem wire_e2422361763310 : Closed e2422361763310 ∧ code e2422361763310 = 11218454785518 := by decide
theorem cert_e2422361763310 : check e2422361763310 [[],[]] .smaller = true := by decide
def e2422361763318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 4)) (.var 1)))))))))))
theorem wire_e2422361763318 : Closed e2422361763318 ∧ code e2422361763318 = 11218454785526 := by decide
theorem cert_e2422361763318 : check e2422361763318 [[],[]] .smaller = true := by decide
def e2422361763518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 4)))))))))))
theorem wire_e2422361763518 : Closed e2422361763518 ∧ code e2422361763518 = 11218454785726 := by decide
theorem cert_e2422361763518 : check e2422361763518 [[],[]] .smaller = true := by decide
def e2422361763550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 3)))))))))))
theorem wire_e2422361763550 : Closed e2422361763550 ∧ code e2422361763550 = 11218454785758 := by decide
theorem cert_e2422361763550 : check e2422361763550 [[],[]] .smaller = true := by decide
def e2422361763566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))))))
theorem wire_e2422361763566 : Closed e2422361763566 ∧ code e2422361763566 = 11218454785774 := by decide
theorem cert_e2422361763566 : check e2422361763566 [[],[]] .smaller = true := by decide
def e2422361763574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 1)))))))))))
theorem wire_e2422361763574 : Closed e2422361763574 ∧ code e2422361763574 = 11218454785782 := by decide
theorem cert_e2422361763574 : check e2422361763574 [[],[]] .smaller = true := by decide
def e2422361763578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 4)) (.var 0)))))))))))
theorem wire_e2422361763578 : Closed e2422361763578 ∧ code e2422361763578 = 11218454785786 := by decide
theorem cert_e2422361763578 : check e2422361763578 [[],[]] .smaller = true := by decide
def e2422361763678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 3)))))))))))
theorem wire_e2422361763678 : Closed e2422361763678 ∧ code e2422361763678 = 11218454785886 := by decide
theorem cert_e2422361763678 : check e2422361763678 [[],[]] .smaller = true := by decide
def e2422361763694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))))))
theorem wire_e2422361763694 : Closed e2422361763694 ∧ code e2422361763694 = 11218454785902 := by decide
theorem cert_e2422361763694 : check e2422361763694 [[],[]] .smaller = true := by decide
def e2422361763702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))))))
theorem wire_e2422361763702 : Closed e2422361763702 ∧ code e2422361763702 = 11218454785910 := by decide
theorem cert_e2422361763702 : check e2422361763702 [[],[]] .smaller = true := by decide
def e2422361763706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 3)) (.var 0)))))))))))
theorem wire_e2422361763706 : Closed e2422361763706 ∧ code e2422361763706 = 11218454785914 := by decide
theorem cert_e2422361763706 : check e2422361763706 [[],[]] .smaller = true := by decide
def e2422361763758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 2)))))))))))
theorem wire_e2422361763758 : Closed e2422361763758 ∧ code e2422361763758 = 11218454785966 := by decide
theorem cert_e2422361763758 : check e2422361763758 [[],[]] .smaller = true := by decide
def e2422361763766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 1)))))))))))
theorem wire_e2422361763766 : Closed e2422361763766 ∧ code e2422361763766 = 11218454785974 := by decide
theorem cert_e2422361763766 : check e2422361763766 [[],[]] .smaller = true := by decide
def e2422361763770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 2)) (.var 0)))))))))))
theorem wire_e2422361763770 : Closed e2422361763770 ∧ code e2422361763770 = 11218454785978 := by decide
theorem cert_e2422361763770 : check e2422361763770 [[],[]] .smaller = true := by decide
def e2422361763798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 0)) (.var 1)))))))))))
theorem wire_e2422361763798 : Closed e2422361763798 ∧ code e2422361763798 = 11218454786006 := by decide
theorem cert_e2422361763798 : check e2422361763798 [[],[]] .smaller = true := by decide
def e2422361763802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 4) (.var 1)) (.var 0)))))))))))
theorem wire_e2422361763802 : Closed e2422361763802 ∧ code e2422361763802 = 11218454786010 := by decide
theorem cert_e2422361763802 : check e2422361763802 [[],[]] .smaller = true := by decide
def e2422361764798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 4))))))))))))
theorem wire_e2422361764798 : Closed e2422361764798 ∧ code e2422361764798 = 11218454787006 := by decide
theorem cert_e2422361764798 : check e2422361764798 [[],[]] .smaller = true := by decide
def e2422361764830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 3))))))))))))
theorem wire_e2422361764830 : Closed e2422361764830 ∧ code e2422361764830 = 11218454787038 := by decide
theorem cert_e2422361764830 : check e2422361764830 [[],[]] .smaller = true := by decide
def e2422361764846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 2))))))))))))
theorem wire_e2422361764846 : Closed e2422361764846 ∧ code e2422361764846 = 11218454787054 := by decide
theorem cert_e2422361764846 : check e2422361764846 [[],[]] .smaller = true := by decide
def e2422361764854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 4) (.var 1))))))))))))
theorem wire_e2422361764854 : Closed e2422361764854 ∧ code e2422361764854 = 11218454787062 := by decide
theorem cert_e2422361764854 : check e2422361764854 [[],[]] .smaller = true := by decide
def e2422361766334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 4))))))))))))
theorem wire_e2422361766334 : Closed e2422361766334 ∧ code e2422361766334 = 11218454788542 := by decide
theorem cert_e2422361766334 : check e2422361766334 [[],[]] .smaller = true := by decide
def e2422361766366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 3))))))))))))
theorem wire_e2422361766366 : Closed e2422361766366 ∧ code e2422361766366 = 11218454788574 := by decide
theorem cert_e2422361766366 : check e2422361766366 [[],[]] .smaller = true := by decide
def e2422361766382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))))))
theorem wire_e2422361766382 : Closed e2422361766382 ∧ code e2422361766382 = 11218454788590 := by decide
theorem cert_e2422361766382 : check e2422361766382 [[],[]] .smaller = true := by decide
def e2422361766390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 1))))))))))))
theorem wire_e2422361766390 : Closed e2422361766390 ∧ code e2422361766390 = 11218454788598 := by decide
theorem cert_e2422361766390 : check e2422361766390 [[],[]] .smaller = true := by decide
def e2422361766394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 4) (.var 0))))))))))))
theorem wire_e2422361766394 : Closed e2422361766394 ∧ code e2422361766394 = 11218454788602 := by decide
theorem cert_e2422361766394 : check e2422361766394 [[],[]] .smaller = true := by decide
def e2422361767134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 3))))))))))))
theorem wire_e2422361767134 : Closed e2422361767134 ∧ code e2422361767134 = 11218454789342 := by decide
theorem cert_e2422361767134 : check e2422361767134 [[],[]] .smaller = true := by decide
def e2422361767150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422361767150 : Closed e2422361767150 ∧ code e2422361767150 = 11218454789358 := by decide
theorem cert_e2422361767150 : check e2422361767150 [[],[]] .smaller = true := by decide
def e2422361767158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422361767158 : Closed e2422361767158 ∧ code e2422361767158 = 11218454789366 := by decide
theorem cert_e2422361767158 : check e2422361767158 [[],[]] .smaller = true := by decide
def e2422361767162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 3) (.var 0))))))))))))
theorem wire_e2422361767162 : Closed e2422361767162 ∧ code e2422361767162 = 11218454789370 := by decide
theorem cert_e2422361767162 : check e2422361767162 [[],[]] .smaller = true := by decide
def e2422361767534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422361767534 : Closed e2422361767534 ∧ code e2422361767534 = 11218454789742 := by decide
theorem cert_e2422361767534 : check e2422361767534 [[],[]] .smaller = true := by decide
def e2422361767542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 1))))))))))))
theorem wire_e2422361767542 : Closed e2422361767542 ∧ code e2422361767542 = 11218454789750 := by decide
theorem cert_e2422361767542 : check e2422361767542 [[],[]] .smaller = true := by decide
def e2422361767546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422361767546 : Closed e2422361767546 ∧ code e2422361767546 = 11218454789754 := by decide
theorem cert_e2422361767546 : check e2422361767546 [[],[]] .smaller = true := by decide
def e2422361767734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422361767734 : Closed e2422361767734 ∧ code e2422361767734 = 11218454789942 := by decide
theorem cert_e2422361767734 : check e2422361767734 [[],[]] .smaller = true := by decide
def e2422361767738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422361767738 : Closed e2422361767738 ∧ code e2422361767738 = 11218454789946 := by decide
theorem cert_e2422361767738 : check e2422361767738 [[],[]] .smaller = true := by decide
def e2422361790142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4)))))))))))
theorem wire_e2422361790142 : Closed e2422361790142 ∧ code e2422361790142 = 11218454812350 := by decide
theorem cert_e2422361790142 : check e2422361790142 [[],[]] .smaller = true := by decide
def e2422361790174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))))
theorem wire_e2422361790174 : Closed e2422361790174 ∧ code e2422361790174 = 11218454812382 := by decide
theorem cert_e2422361790174 : check e2422361790174 [[],[]] .smaller = true := by decide
def e2422361790190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))))))
theorem wire_e2422361790190 : Closed e2422361790190 ∧ code e2422361790190 = 11218454812398 := by decide
theorem cert_e2422361790190 : check e2422361790190 [[],[]] .smaller = true := by decide
def e2422361790198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))))
theorem wire_e2422361790198 : Closed e2422361790198 ∧ code e2422361790198 = 11218454812406 := by decide
theorem cert_e2422361790198 : check e2422361790198 [[],[]] .smaller = true := by decide
def e2422361790202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0)))))))))))
theorem wire_e2422361790202 : Closed e2422361790202 ∧ code e2422361790202 = 11218454812410 := by decide
theorem cert_e2422361790202 : check e2422361790202 [[],[]] .smaller = true := by decide
def e2422361790302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))))
theorem wire_e2422361790302 : Closed e2422361790302 ∧ code e2422361790302 = 11218454812510 := by decide
theorem cert_e2422361790302 : check e2422361790302 [[],[]] .smaller = true := by decide
def e2422361790330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))))
theorem wire_e2422361790330 : Closed e2422361790330 ∧ code e2422361790330 = 11218454812538 := by decide
theorem cert_e2422361790330 : check e2422361790330 [[],[]] .smaller = true := by decide
def e2422361790382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))))))
theorem wire_e2422361790382 : Closed e2422361790382 ∧ code e2422361790382 = 11218454812590 := by decide
theorem cert_e2422361790382 : check e2422361790382 [[],[]] .smaller = true := by decide
def e2422361790394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))))))
theorem wire_e2422361790394 : Closed e2422361790394 ∧ code e2422361790394 = 11218454812602 := by decide
theorem cert_e2422361790394 : check e2422361790394 [[],[]] .smaller = true := by decide
def e2422361790422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))))
theorem wire_e2422361790422 : Closed e2422361790422 ∧ code e2422361790422 = 11218454812630 := by decide
theorem cert_e2422361790422 : check e2422361790422 [[],[]] .smaller = true := by decide
def e2422361790426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))))
theorem wire_e2422361790426 : Closed e2422361790426 ∧ code e2422361790426 = 11218454812634 := by decide
theorem cert_e2422361790426 : check e2422361790426 [[],[]] .smaller = true := by decide
def e2422361790442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0)))))))))))
theorem wire_e2422361790442 : Closed e2422361790442 ∧ code e2422361790442 = 11218454812650 := by decide
theorem cert_e2422361790442 : check e2422361790442 [[],[]] .smaller = true := by decide
def e2422361790910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4))))))))))))
theorem wire_e2422361790910 : Closed e2422361790910 ∧ code e2422361790910 = 11218454813118 := by decide
theorem cert_e2422361790910 : check e2422361790910 [[],[]] .smaller = true := by decide
def e2422361790942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3))))))))))))
theorem wire_e2422361790942 : Closed e2422361790942 ∧ code e2422361790942 = 11218454813150 := by decide
theorem cert_e2422361790942 : check e2422361790942 [[],[]] .smaller = true := by decide
def e2422361790958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))))))
theorem wire_e2422361790958 : Closed e2422361790958 ∧ code e2422361790958 = 11218454813166 := by decide
theorem cert_e2422361790958 : check e2422361790958 [[],[]] .smaller = true := by decide
def e2422361790966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1))))))))))))
theorem wire_e2422361790966 : Closed e2422361790966 ∧ code e2422361790966 = 11218454813174 := by decide
theorem cert_e2422361790966 : check e2422361790966 [[],[]] .smaller = true := by decide
def e2422361790970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0))))))))))))
theorem wire_e2422361790970 : Closed e2422361790970 ∧ code e2422361790970 = 11218454813178 := by decide
theorem cert_e2422361790970 : check e2422361790970 [[],[]] .smaller = true := by decide
def e2422361791710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3))))))))))))
theorem wire_e2422361791710 : Closed e2422361791710 ∧ code e2422361791710 = 11218454813918 := by decide
theorem cert_e2422361791710 : check e2422361791710 [[],[]] .smaller = true := by decide
def e2422361791738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0))))))))))))
theorem wire_e2422361791738 : Closed e2422361791738 ∧ code e2422361791738 = 11218454813946 := by decide
theorem cert_e2422361791738 : check e2422361791738 [[],[]] .smaller = true := by decide
def e2422361792110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422361792110 : Closed e2422361792110 ∧ code e2422361792110 = 11218454814318 := by decide
theorem cert_e2422361792110 : check e2422361792110 [[],[]] .smaller = true := by decide
def e2422361792122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422361792122 : Closed e2422361792122 ∧ code e2422361792122 = 11218454814330 := by decide
theorem cert_e2422361792122 : check e2422361792122 [[],[]] .smaller = true := by decide
def e2422361792310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422361792310 : Closed e2422361792310 ∧ code e2422361792310 = 11218454814518 := by decide
theorem cert_e2422361792310 : check e2422361792310 [[],[]] .smaller = true := by decide
def e2422361792314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422361792314 : Closed e2422361792314 ∧ code e2422361792314 = 11218454814522 := by decide
theorem cert_e2422361792314 : check e2422361792314 [[],[]] .smaller = true := by decide
def e2422361792410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422361792410 : Closed e2422361792410 ∧ code e2422361792410 = 11218454814618 := by decide
theorem cert_e2422361792410 : check e2422361792410 [[],[]] .smaller = true := by decide
def e2422361803614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))))
theorem wire_e2422361803614 : Closed e2422361803614 ∧ code e2422361803614 = 11218454825822 := by decide
theorem cert_e2422361803614 : check e2422361803614 [[],[]] .smaller = true := by decide
def e2422361803630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e2422361803630 : Closed e2422361803630 ∧ code e2422361803630 = 11218454825838 := by decide
theorem cert_e2422361803630 : check e2422361803630 [[],[]] .smaller = true := by decide
def e2422361803638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e2422361803638 : Closed e2422361803638 ∧ code e2422361803638 = 11218454825846 := by decide
theorem cert_e2422361803638 : check e2422361803638 [[],[]] .smaller = true := by decide
def e2422361803642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))))
theorem wire_e2422361803642 : Closed e2422361803642 ∧ code e2422361803642 = 11218454825850 := by decide
theorem cert_e2422361803642 : check e2422361803642 [[],[]] .smaller = true := by decide
def e2422361803694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e2422361803694 : Closed e2422361803694 ∧ code e2422361803694 = 11218454825902 := by decide
theorem cert_e2422361803694 : check e2422361803694 [[],[]] .smaller = true := by decide
def e2422361803706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e2422361803706 : Closed e2422361803706 ∧ code e2422361803706 = 11218454825914 := by decide
theorem cert_e2422361803706 : check e2422361803706 [[],[]] .smaller = true := by decide
def e2422361803734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e2422361803734 : Closed e2422361803734 ∧ code e2422361803734 = 11218454825942 := by decide
theorem cert_e2422361803734 : check e2422361803734 [[],[]] .smaller = true := by decide
def e2422361803738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e2422361803738 : Closed e2422361803738 ∧ code e2422361803738 = 11218454825946 := by decide
theorem cert_e2422361803738 : check e2422361803738 [[],[]] .smaller = true := by decide
def e2422361803754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))))
theorem wire_e2422361803754 : Closed e2422361803754 ∧ code e2422361803754 = 11218454825962 := by decide
theorem cert_e2422361803754 : check e2422361803754 [[],[]] .smaller = true := by decide
def e2422361803998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 3))))))))))))
theorem wire_e2422361803998 : Closed e2422361803998 ∧ code e2422361803998 = 11218454826206 := by decide
theorem cert_e2422361803998 : check e2422361803998 [[],[]] .smaller = true := by decide
def e2422361804014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422361804014 : Closed e2422361804014 ∧ code e2422361804014 = 11218454826222 := by decide
theorem cert_e2422361804014 : check e2422361804014 [[],[]] .smaller = true := by decide
def e2422361804022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422361804022 : Closed e2422361804022 ∧ code e2422361804022 = 11218454826230 := by decide
theorem cert_e2422361804022 : check e2422361804022 [[],[]] .smaller = true := by decide
def e2422361804026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 3) (.var 0))))))))))))
theorem wire_e2422361804026 : Closed e2422361804026 ∧ code e2422361804026 = 11218454826234 := by decide
theorem cert_e2422361804026 : check e2422361804026 [[],[]] .smaller = true := by decide
def e2422361804398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422361804398 : Closed e2422361804398 ∧ code e2422361804398 = 11218454826606 := by decide
theorem cert_e2422361804398 : check e2422361804398 [[],[]] .smaller = true := by decide
def e2422361804410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422361804410 : Closed e2422361804410 ∧ code e2422361804410 = 11218454826618 := by decide
theorem cert_e2422361804410 : check e2422361804410 [[],[]] .smaller = true := by decide
def e2422361804598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422361804598 : Closed e2422361804598 ∧ code e2422361804598 = 11218454826806 := by decide
theorem cert_e2422361804598 : check e2422361804598 [[],[]] .smaller = true := by decide
def e2422361804602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422361804602 : Closed e2422361804602 ∧ code e2422361804602 = 11218454826810 := by decide
theorem cert_e2422361804602 : check e2422361804602 [[],[]] .smaller = true := by decide
def e2422361804698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422361804698 : Closed e2422361804698 ∧ code e2422361804698 = 11218454826906 := by decide
theorem cert_e2422361804698 : check e2422361804698 [[],[]] .smaller = true := by decide
def e2422361810350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e2422361810350 : Closed e2422361810350 ∧ code e2422361810350 = 11218454832558 := by decide
theorem cert_e2422361810350 : check e2422361810350 [[],[]] .smaller = true := by decide
def e2422361810358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))))
theorem wire_e2422361810358 : Closed e2422361810358 ∧ code e2422361810358 = 11218454832566 := by decide
theorem cert_e2422361810358 : check e2422361810358 [[],[]] .smaller = true := by decide
def e2422361810362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e2422361810362 : Closed e2422361810362 ∧ code e2422361810362 = 11218454832570 := by decide
theorem cert_e2422361810362 : check e2422361810362 [[],[]] .smaller = true := by decide
def e2422361810390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))))
theorem wire_e2422361810390 : Closed e2422361810390 ∧ code e2422361810390 = 11218454832598 := by decide
theorem cert_e2422361810390 : check e2422361810390 [[],[]] .smaller = true := by decide
def e2422361810394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))))
theorem wire_e2422361810394 : Closed e2422361810394 ∧ code e2422361810394 = 11218454832602 := by decide
theorem cert_e2422361810394 : check e2422361810394 [[],[]] .smaller = true := by decide
def e2422361810410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e2422361810410 : Closed e2422361810410 ∧ code e2422361810410 = 11218454832618 := by decide
theorem cert_e2422361810410 : check e2422361810410 [[],[]] .smaller = true := by decide
def e2422361810542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422361810542 : Closed e2422361810542 ∧ code e2422361810542 = 11218454832750 := by decide
theorem cert_e2422361810542 : check e2422361810542 [[],[]] .smaller = true := by decide
def e2422361810550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 1))))))))))))
theorem wire_e2422361810550 : Closed e2422361810550 ∧ code e2422361810550 = 11218454832758 := by decide
theorem cert_e2422361810550 : check e2422361810550 [[],[]] .smaller = true := by decide
def e2422361810554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422361810554 : Closed e2422361810554 ∧ code e2422361810554 = 11218454832762 := by decide
theorem cert_e2422361810554 : check e2422361810554 [[],[]] .smaller = true := by decide
def e2422361810742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422361810742 : Closed e2422361810742 ∧ code e2422361810742 = 11218454832950 := by decide
theorem cert_e2422361810742 : check e2422361810742 [[],[]] .smaller = true := by decide
def e2422361810746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422361810746 : Closed e2422361810746 ∧ code e2422361810746 = 11218454832954 := by decide
theorem cert_e2422361810746 : check e2422361810746 [[],[]] .smaller = true := by decide
def e2422361810842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422361810842 : Closed e2422361810842 ∧ code e2422361810842 = 11218454833050 := by decide
theorem cert_e2422361810842 : check e2422361810842 [[],[]] .smaller = true := by decide
def e2422361813718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e2422361813718 : Closed e2422361813718 ∧ code e2422361813718 = 11218454835926 := by decide
theorem cert_e2422361813718 : check e2422361813718 [[],[]] .smaller = true := by decide
def e2422361813722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e2422361813722 : Closed e2422361813722 ∧ code e2422361813722 = 11218454835930 := by decide
theorem cert_e2422361813722 : check e2422361813722 [[],[]] .smaller = true := by decide
def e2422361813738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e2422361813738 : Closed e2422361813738 ∧ code e2422361813738 = 11218454835946 := by decide
theorem cert_e2422361813738 : check e2422361813738 [[],[]] .smaller = true := by decide
def e2422361813814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422361813814 : Closed e2422361813814 ∧ code e2422361813814 = 11218454836022 := by decide
theorem cert_e2422361813814 : check e2422361813814 [[],[]] .smaller = true := by decide
def e2422361813818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422361813818 : Closed e2422361813818 ∧ code e2422361813818 = 11218454836026 := by decide
theorem cert_e2422361813818 : check e2422361813818 [[],[]] .smaller = true := by decide
def e2422361813914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422361813914 : Closed e2422361813914 ∧ code e2422361813914 = 11218454836122 := by decide
theorem cert_e2422361813914 : check e2422361813914 [[],[]] .smaller = true := by decide
def e2422362256750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422362256750 : Closed e2422362256750 ∧ code e2422362256750 = 11218455278958 := by decide
theorem cert_e2422362256750 : check e2422362256750 [[],[]] .smaller = true := by decide
def e2422362256758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422362256758 : Closed e2422362256758 ∧ code e2422362256758 = 11218455278966 := by decide
theorem cert_e2422362256758 : check e2422362256758 [[],[]] .smaller = true := by decide
def e2422362256814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422362256814 : Closed e2422362256814 ∧ code e2422362256814 = 11218455279022 := by decide
theorem cert_e2422362256814 : check e2422362256814 [[],[]] .smaller = true := by decide
def e2422362256826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422362256826 : Closed e2422362256826 ∧ code e2422362256826 = 11218455279034 := by decide
theorem cert_e2422362256826 : check e2422362256826 [[],[]] .smaller = true := by decide
def e2422362256854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422362256854 : Closed e2422362256854 ∧ code e2422362256854 = 11218455279062 := by decide
theorem cert_e2422362256854 : check e2422362256854 [[],[]] .smaller = true := by decide
def e2422362256858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422362256858 : Closed e2422362256858 ∧ code e2422362256858 = 11218455279066 := by decide
theorem cert_e2422362256858 : check e2422362256858 [[],[]] .smaller = true := by decide
def e2422362257070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422362257070 : Closed e2422362257070 ∧ code e2422362257070 = 11218455279278 := by decide
theorem cert_e2422362257070 : check e2422362257070 [[],[]] .smaller = true := by decide
def e2422362257082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422362257082 : Closed e2422362257082 ∧ code e2422362257082 = 11218455279290 := by decide
theorem cert_e2422362257082 : check e2422362257082 [[],[]] .smaller = true := by decide
def e2422362257130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362257130 : Closed e2422362257130 ∧ code e2422362257130 = 11218455279338 := by decide
theorem cert_e2422362257130 : check e2422362257130 [[],[]] .smaller = true := by decide
def e2422362257238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422362257238 : Closed e2422362257238 ∧ code e2422362257238 = 11218455279446 := by decide
theorem cert_e2422362257238 : check e2422362257238 [[],[]] .smaller = true := by decide
def e2422362257242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422362257242 : Closed e2422362257242 ∧ code e2422362257242 = 11218455279450 := by decide
theorem cert_e2422362257242 : check e2422362257242 [[],[]] .smaller = true := by decide
def e2422362257258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362257258 : Closed e2422362257258 ∧ code e2422362257258 = 11218455279466 := by decide
theorem cert_e2422362257258 : check e2422362257258 [[],[]] .smaller = true := by decide
def e2422362258094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2422362258094 : Closed e2422362258094 ∧ code e2422362258094 = 11218455280302 := by decide
theorem cert_e2422362258094 : check e2422362258094 [[],[]] .smaller = true := by decide
def e2422362258106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2422362258106 : Closed e2422362258106 ∧ code e2422362258106 = 11218455280314 := by decide
theorem cert_e2422362258106 : check e2422362258106 [[],[]] .smaller = true := by decide
def e2422362258154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362258154 : Closed e2422362258154 ∧ code e2422362258154 = 11218455280362 := by decide
theorem cert_e2422362258154 : check e2422362258154 [[],[]] .smaller = true := by decide
def e2422362258346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362258346 : Closed e2422362258346 ∧ code e2422362258346 = 11218455280554 := by decide
theorem cert_e2422362258346 : check e2422362258346 [[],[]] .smaller = true := by decide
def e2422362258774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422362258774 : Closed e2422362258774 ∧ code e2422362258774 = 11218455280982 := by decide
theorem cert_e2422362258774 : check e2422362258774 [[],[]] .smaller = true := by decide
def e2422362258778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422362258778 : Closed e2422362258778 ∧ code e2422362258778 = 11218455280986 := by decide
theorem cert_e2422362258778 : check e2422362258778 [[],[]] .smaller = true := by decide
def e2422362258794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362258794 : Closed e2422362258794 ∧ code e2422362258794 = 11218455281002 := by decide
theorem cert_e2422362258794 : check e2422362258794 [[],[]] .smaller = true := by decide
def e2422362258858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)) (.var 0)))))))))
theorem wire_e2422362258858 : Closed e2422362258858 ∧ code e2422362258858 = 11218455281066 := by decide
theorem cert_e2422362258858 : check e2422362258858 [[],[]] .smaller = true := by decide
def e2422362261214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 3)))))))))
theorem wire_e2422362261214 : Closed e2422362261214 ∧ code e2422362261214 = 11218455283422 := by decide
theorem cert_e2422362261214 : check e2422362261214 [[],[]] .smaller = true := by decide
def e2422362261238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 3)) (.var 1)))))))))
theorem wire_e2422362261238 : Closed e2422362261238 ∧ code e2422362261238 = 11218455283446 := by decide
theorem cert_e2422362261238 : check e2422362261238 [[],[]] .smaller = true := by decide
def e2422362261342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 3)))))))))
theorem wire_e2422362261342 : Closed e2422362261342 ∧ code e2422362261342 = 11218455283550 := by decide
theorem cert_e2422362261342 : check e2422362261342 [[],[]] .smaller = true := by decide
def e2422362261358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 2)))))))))
theorem wire_e2422362261358 : Closed e2422362261358 ∧ code e2422362261358 = 11218455283566 := by decide
theorem cert_e2422362261358 : check e2422362261358 [[],[]] .smaller = true := by decide
def e2422362261366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 1)))))))))
theorem wire_e2422362261366 : Closed e2422362261366 ∧ code e2422362261366 = 11218455283574 := by decide
theorem cert_e2422362261366 : check e2422362261366 [[],[]] .smaller = true := by decide
def e2422362261370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.var 0)))))))))
theorem wire_e2422362261370 : Closed e2422362261370 ∧ code e2422362261370 = 11218455283578 := by decide
theorem cert_e2422362261370 : check e2422362261370 [[],[]] .smaller = true := by decide
def e2422362261430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 1)))))))))
theorem wire_e2422362261430 : Closed e2422362261430 ∧ code e2422362261430 = 11218455283638 := by decide
theorem cert_e2422362261430 : check e2422362261430 [[],[]] .smaller = true := by decide
def e2422362261462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.var 1)))))))))
theorem wire_e2422362261462 : Closed e2422362261462 ∧ code e2422362261462 = 11218455283670 := by decide
theorem cert_e2422362261462 : check e2422362261462 [[],[]] .smaller = true := by decide
def e2422362261466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.var 0)))))))))
theorem wire_e2422362261466 : Closed e2422362261466 ∧ code e2422362261466 = 11218455283674 := by decide
theorem cert_e2422362261466 : check e2422362261466 [[],[]] .smaller = true := by decide
def e2422362262894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)))))))))
theorem wire_e2422362262894 : Closed e2422362262894 ∧ code e2422362262894 = 11218455285102 := by decide
theorem cert_e2422362262894 : check e2422362262894 [[],[]] .smaller = true := by decide
def e2422362262902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)))))))))
theorem wire_e2422362262902 : Closed e2422362262902 ∧ code e2422362262902 = 11218455285110 := by decide
theorem cert_e2422362262902 : check e2422362262902 [[],[]] .smaller = true := by decide
def e2422362262958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)))))))))
theorem wire_e2422362262958 : Closed e2422362262958 ∧ code e2422362262958 = 11218455285166 := by decide
theorem cert_e2422362262958 : check e2422362262958 [[],[]] .smaller = true := by decide
def e2422362262970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)))))))))
theorem wire_e2422362262970 : Closed e2422362262970 ∧ code e2422362262970 = 11218455285178 := by decide
theorem cert_e2422362262970 : check e2422362262970 [[],[]] .smaller = true := by decide
def e2422362262998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)))))))))
theorem wire_e2422362262998 : Closed e2422362262998 ∧ code e2422362262998 = 11218455285206 := by decide
theorem cert_e2422362262998 : check e2422362262998 [[],[]] .smaller = true := by decide
def e2422362263002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)))))))))
theorem wire_e2422362263002 : Closed e2422362263002 ∧ code e2422362263002 = 11218455285210 := by decide
theorem cert_e2422362263002 : check e2422362263002 [[],[]] .smaller = true := by decide
def e2422362263214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)))))))))
theorem wire_e2422362263214 : Closed e2422362263214 ∧ code e2422362263214 = 11218455285422 := by decide
theorem cert_e2422362263214 : check e2422362263214 [[],[]] .smaller = true := by decide
def e2422362263226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)))))))))
theorem wire_e2422362263226 : Closed e2422362263226 ∧ code e2422362263226 = 11218455285434 := by decide
theorem cert_e2422362263226 : check e2422362263226 [[],[]] .smaller = true := by decide
def e2422362263274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362263274 : Closed e2422362263274 ∧ code e2422362263274 = 11218455285482 := by decide
theorem cert_e2422362263274 : check e2422362263274 [[],[]] .smaller = true := by decide
def e2422362263382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)))))))))
theorem wire_e2422362263382 : Closed e2422362263382 ∧ code e2422362263382 = 11218455285590 := by decide
theorem cert_e2422362263382 : check e2422362263382 [[],[]] .smaller = true := by decide
def e2422362263386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)))))))))
theorem wire_e2422362263386 : Closed e2422362263386 ∧ code e2422362263386 = 11218455285594 := by decide
theorem cert_e2422362263386 : check e2422362263386 [[],[]] .smaller = true := by decide
def e2422362263402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)))))))))
theorem wire_e2422362263402 : Closed e2422362263402 ∧ code e2422362263402 = 11218455285610 := by decide
theorem cert_e2422362263402 : check e2422362263402 [[],[]] .smaller = true := by decide
def e2422362264030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e2422362264030 : Closed e2422362264030 ∧ code e2422362264030 = 11218455286238 := by decide
theorem cert_e2422362264030 : check e2422362264030 [[],[]] .smaller = true := by decide
def e2422362264054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e2422362264054 : Closed e2422362264054 ∧ code e2422362264054 = 11218455286262 := by decide
theorem cert_e2422362264054 : check e2422362264054 [[],[]] .smaller = true := by decide
def e2422362264430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422362264430 : Closed e2422362264430 ∧ code e2422362264430 = 11218455286638 := by decide
theorem cert_e2422362264430 : check e2422362264430 [[],[]] .smaller = true := by decide
def e2422362264438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422362264438 : Closed e2422362264438 ∧ code e2422362264438 = 11218455286646 := by decide
theorem cert_e2422362264438 : check e2422362264438 [[],[]] .smaller = true := by decide
def e2422362264494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422362264494 : Closed e2422362264494 ∧ code e2422362264494 = 11218455286702 := by decide
theorem cert_e2422362264494 : check e2422362264494 [[],[]] .smaller = true := by decide
def e2422362264506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422362264506 : Closed e2422362264506 ∧ code e2422362264506 = 11218455286714 := by decide
theorem cert_e2422362264506 : check e2422362264506 [[],[]] .smaller = true := by decide
def e2422362264534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422362264534 : Closed e2422362264534 ∧ code e2422362264534 = 11218455286742 := by decide
theorem cert_e2422362264534 : check e2422362264534 [[],[]] .smaller = true := by decide
def e2422362264538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422362264538 : Closed e2422362264538 ∧ code e2422362264538 = 11218455286746 := by decide
theorem cert_e2422362264538 : check e2422362264538 [[],[]] .smaller = true := by decide
def e2422362264814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422362264814 : Closed e2422362264814 ∧ code e2422362264814 = 11218455287022 := by decide
theorem cert_e2422362264814 : check e2422362264814 [[],[]] .smaller = true := by decide
def e2422362264822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422362264822 : Closed e2422362264822 ∧ code e2422362264822 = 11218455287030 := by decide
theorem cert_e2422362264822 : check e2422362264822 [[],[]] .smaller = true := by decide
def e2422362265150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e2422362265150 : Closed e2422362265150 ∧ code e2422362265150 = 11218455287358 := by decide
theorem cert_e2422362265150 : check e2422362265150 [[],[]] .smaller = true := by decide
def e2422362265198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422362265198 : Closed e2422362265198 ∧ code e2422362265198 = 11218455287406 := by decide
theorem cert_e2422362265198 : check e2422362265198 [[],[]] .smaller = true := by decide
def e2422362265210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422362265210 : Closed e2422362265210 ∧ code e2422362265210 = 11218455287418 := by decide
theorem cert_e2422362265210 : check e2422362265210 [[],[]] .smaller = true := by decide
def e2422362265398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422362265398 : Closed e2422362265398 ∧ code e2422362265398 = 11218455287606 := by decide
theorem cert_e2422362265398 : check e2422362265398 [[],[]] .smaller = true := by decide
def e2422362265402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422362265402 : Closed e2422362265402 ∧ code e2422362265402 = 11218455287610 := by decide
theorem cert_e2422362265402 : check e2422362265402 [[],[]] .smaller = true := by decide
def e2422362265470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 5)))))))))
theorem wire_e2422362265470 : Closed e2422362265470 ∧ code e2422362265470 = 11218455287678 := by decide
theorem cert_e2422362265470 : check e2422362265470 [[],[]] .three = true := by decide
def e2422362265486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e2422362265486 : Closed e2422362265486 ∧ code e2422362265486 = 11218455287694 := by decide
theorem cert_e2422362265486 : check e2422362265486 [[],[]] .smaller = true := by decide
def e2422362265534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 4)))))))))
theorem wire_e2422362265534 : Closed e2422362265534 ∧ code e2422362265534 = 11218455287742 := by decide
theorem cert_e2422362265534 : check e2422362265534 [[],[]] .smaller = true := by decide
def e2422362265566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 3)))))))))
theorem wire_e2422362265566 : Closed e2422362265566 ∧ code e2422362265566 = 11218455287774 := by decide
theorem cert_e2422362265566 : check e2422362265566 [[],[]] .smaller = true := by decide
def e2422362265582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 5)) (.var 2)))))))))
theorem wire_e2422362265582 : Closed e2422362265582 ∧ code e2422362265582 = 11218455287790 := by decide
theorem cert_e2422362265582 : check e2422362265582 [[],[]] .three = true := by decide
def e2422362265822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e2422362265822 : Closed e2422362265822 ∧ code e2422362265822 = 11218455288030 := by decide
theorem cert_e2422362265822 : check e2422362265822 [[],[]] .smaller = true := by decide
def e2422362265838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e2422362265838 : Closed e2422362265838 ∧ code e2422362265838 = 11218455288046 := by decide
theorem cert_e2422362265838 : check e2422362265838 [[],[]] .smaller = true := by decide
def e2422362265846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e2422362265846 : Closed e2422362265846 ∧ code e2422362265846 = 11218455288054 := by decide
theorem cert_e2422362265846 : check e2422362265846 [[],[]] .smaller = true := by decide
end Blc.Floor43
