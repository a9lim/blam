import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392565979382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2392565979382 : Closed e2392565979382 ∧ code e2392565979382 = 11188659001590 := by decide
theorem cert_e2392565979382 : check e2392565979382 [[],[.left]] .chain = true := by decide
def e2392565979566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2392565979566 : Closed e2392565979566 ∧ code e2392565979566 = 11188659001774 := by decide
theorem cert_e2392565979566 : check e2392565979566 [[],[.left]] .chain = true := by decide
def e2392565979578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2392565979578 : Closed e2392565979578 ∧ code e2392565979578 = 11188659001786 := by decide
theorem cert_e2392565979578 : check e2392565979578 [[],[.left]] .chain = true := by decide
def e2392565979626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2392565979626 : Closed e2392565979626 ∧ code e2392565979626 = 11188659001834 := by decide
theorem cert_e2392565979626 : check e2392565979626 [[],[.left]] .chain = true := by decide
def e2392565979758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2392565979758 : Closed e2392565979758 ∧ code e2392565979758 = 11188659001966 := by decide
theorem cert_e2392565979758 : check e2392565979758 [[],[.left]] .chain = true := by decide
def e2392565979770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2392565979770 : Closed e2392565979770 ∧ code e2392565979770 = 11188659001978 := by decide
theorem cert_e2392565979770 : check e2392565979770 [[],[.left]] .chain = true := by decide
def e2392565979934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2392565979934 : Closed e2392565979934 ∧ code e2392565979934 = 11188659002142 := by decide
theorem cert_e2392565979934 : check e2392565979934 [[],[.left]] .chain = true := by decide
def e2392565980046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2392565980046 : Closed e2392565980046 ∧ code e2392565980046 = 11188659002254 := by decide
theorem cert_e2392565980046 : check e2392565980046 [[],[.left]] .chain = true := by decide
def e2392565980058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565980058 : Closed e2392565980058 ∧ code e2392565980058 = 11188659002266 := by decide
theorem cert_e2392565980058 : check e2392565980058 [[],[.left]] .chain = true := by decide
def e2392565980270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2392565980270 : Closed e2392565980270 ∧ code e2392565980270 = 11188659002478 := by decide
theorem cert_e2392565980270 : check e2392565980270 [[],[.left]] .chain = true := by decide
def e2392565980282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2392565980282 : Closed e2392565980282 ∧ code e2392565980282 = 11188659002490 := by decide
theorem cert_e2392565980282 : check e2392565980282 [[],[.left]] .chain = true := by decide
def e2392565980446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2392565980446 : Closed e2392565980446 ∧ code e2392565980446 = 11188659002654 := by decide
theorem cert_e2392565980446 : check e2392565980446 [[],[.left]] .chain = true := by decide
def e2392565980614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2392565980614 : Closed e2392565980614 ∧ code e2392565980614 = 11188659002822 := by decide
theorem cert_e2392565980614 : check e2392565980614 [[],[.left]] .chain = true := by decide
def e2392565980726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2392565980726 : Closed e2392565980726 ∧ code e2392565980726 = 11188659002934 := by decide
theorem cert_e2392565980726 : check e2392565980726 [[],[.left]] .chain = true := by decide
def e2392565980730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2392565980730 : Closed e2392565980730 ∧ code e2392565980730 = 11188659002938 := by decide
theorem cert_e2392565980730 : check e2392565980730 [[],[.left]] .chain = true := by decide
def e2392565980778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2392565980778 : Closed e2392565980778 ∧ code e2392565980778 = 11188659002986 := by decide
theorem cert_e2392565980778 : check e2392565980778 [[],[.left]] .chain = true := by decide
def e2392565980814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2392565980814 : Closed e2392565980814 ∧ code e2392565980814 = 11188659003022 := by decide
theorem cert_e2392565980814 : check e2392565980814 [[],[.left]] .chain = true := by decide
def e2392565980826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565980826 : Closed e2392565980826 ∧ code e2392565980826 = 11188659003034 := by decide
theorem cert_e2392565980826 : check e2392565980826 [[],[.left]] .chain = true := by decide
def e2392565980870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2392565980870 : Closed e2392565980870 ∧ code e2392565980870 = 11188659003078 := by decide
theorem cert_e2392565980870 : check e2392565980870 [[],[.left]] .chain = true := by decide
def e2392565981662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2392565981662 : Closed e2392565981662 ∧ code e2392565981662 = 11188659003870 := by decide
theorem cert_e2392565981662 : check e2392565981662 [[],[.left]] .chain = true := by decide
def e2392565981686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2392565981686 : Closed e2392565981686 ∧ code e2392565981686 = 11188659003894 := by decide
theorem cert_e2392565981686 : check e2392565981686 [[],[.left]] .chain = true := by decide
def e2392565982638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2392565982638 : Closed e2392565982638 ∧ code e2392565982638 = 11188659004846 := by decide
theorem cert_e2392565982638 : check e2392565982638 [[],[.left]] .chain = true := by decide
def e2392565982650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2392565982650 : Closed e2392565982650 ∧ code e2392565982650 = 11188659004858 := by decide
theorem cert_e2392565982650 : check e2392565982650 [[],[.left]] .chain = true := by decide
def e2392565982698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2392565982698 : Closed e2392565982698 ∧ code e2392565982698 = 11188659004906 := by decide
theorem cert_e2392565982698 : check e2392565982698 [[],[.left]] .chain = true := by decide
def e2392565982830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2392565982830 : Closed e2392565982830 ∧ code e2392565982830 = 11188659005038 := by decide
theorem cert_e2392565982830 : check e2392565982830 [[],[.left]] .chain = true := by decide
def e2392565982842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2392565982842 : Closed e2392565982842 ∧ code e2392565982842 = 11188659005050 := by decide
theorem cert_e2392565982842 : check e2392565982842 [[],[.left]] .chain = true := by decide
def e2392565983006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2392565983006 : Closed e2392565983006 ∧ code e2392565983006 = 11188659005214 := by decide
theorem cert_e2392565983006 : check e2392565983006 [[],[.left]] .chain = true := by decide
def e2392565983118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2392565983118 : Closed e2392565983118 ∧ code e2392565983118 = 11188659005326 := by decide
theorem cert_e2392565983118 : check e2392565983118 [[],[.left]] .chain = true := by decide
def e2392565983130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565983130 : Closed e2392565983130 ∧ code e2392565983130 = 11188659005338 := by decide
theorem cert_e2392565983130 : check e2392565983130 [[],[.left]] .chain = true := by decide
def e2392565986078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2392565986078 : Closed e2392565986078 ∧ code e2392565986078 = 11188659008286 := by decide
theorem cert_e2392565986078 : check e2392565986078 [[],[.left]] .chain = true := by decide
def e2392565986246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2392565986246 : Closed e2392565986246 ∧ code e2392565986246 = 11188659008454 := by decide
theorem cert_e2392565986246 : check e2392565986246 [[],[.left]] .chain = true := by decide
def e2392565987446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2392565987446 : Closed e2392565987446 ∧ code e2392565987446 = 11188659009654 := by decide
theorem cert_e2392565987446 : check e2392565987446 [[],[.left]] .chain = true := by decide
def e2392565987690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2392565987690 : Closed e2392565987690 ∧ code e2392565987690 = 11188659009898 := by decide
theorem cert_e2392565987690 : check e2392565987690 [[],[.left]] .chain = true := by decide
def e2392565987726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2392565987726 : Closed e2392565987726 ∧ code e2392565987726 = 11188659009934 := by decide
theorem cert_e2392565987726 : check e2392565987726 [[],[.left]] .chain = true := by decide
def e2392565987738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565987738 : Closed e2392565987738 ∧ code e2392565987738 = 11188659009946 := by decide
theorem cert_e2392565987738 : check e2392565987738 [[],[.left]] .chain = true := by decide
def e2392565987782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2392565987782 : Closed e2392565987782 ∧ code e2392565987782 = 11188659009990 := by decide
theorem cert_e2392565987782 : check e2392565987782 [[],[.left]] .chain = true := by decide
def e2392565990326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2392565990326 : Closed e2392565990326 ∧ code e2392565990326 = 11188659012534 := by decide
theorem cert_e2392565990326 : check e2392565990326 [[],[.left]] .chain = true := by decide
def e2392565990330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2392565990330 : Closed e2392565990330 ∧ code e2392565990330 = 11188659012538 := by decide
theorem cert_e2392565990330 : check e2392565990330 [[],[.left]] .chain = true := by decide
def e2392565990362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2392565990362 : Closed e2392565990362 ∧ code e2392565990362 = 11188659012570 := by decide
theorem cert_e2392565990362 : check e2392565990362 [[],[.left]] .chain = true := by decide
def e2392565991030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2392565991030 : Closed e2392565991030 ∧ code e2392565991030 = 11188659013238 := by decide
theorem cert_e2392565991030 : check e2392565991030 [[],[.left]] .chain = true := by decide
def e2392565991222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565991222 : Closed e2392565991222 ∧ code e2392565991222 = 11188659013430 := by decide
theorem cert_e2392565991222 : check e2392565991222 [[],[.left]] .chain = true := by decide
def e2392565991226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565991226 : Closed e2392565991226 ∧ code e2392565991226 = 11188659013434 := by decide
theorem cert_e2392565991226 : check e2392565991226 [[],[.left]] .chain = true := by decide
def e2392565992278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2392565992278 : Closed e2392565992278 ∧ code e2392565992278 = 11188659014486 := by decide
theorem cert_e2392565992278 : check e2392565992278 [[],[.left]] .chain = true := by decide
def e2392565992282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2392565992282 : Closed e2392565992282 ∧ code e2392565992282 = 11188659014490 := by decide
theorem cert_e2392565992282 : check e2392565992282 [[],[.left]] .chain = true := by decide
def e2392565992298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2392565992298 : Closed e2392565992298 ∧ code e2392565992298 = 11188659014506 := by decide
theorem cert_e2392565992298 : check e2392565992298 [[],[.left]] .chain = true := by decide
def e2392565992362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2392565992362 : Closed e2392565992362 ∧ code e2392565992362 = 11188659014570 := by decide
theorem cert_e2392565992362 : check e2392565992362 [[],[.left]] .chain = true := by decide
def e2392565992566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2392565992566 : Closed e2392565992566 ∧ code e2392565992566 = 11188659014774 := by decide
theorem cert_e2392565992566 : check e2392565992566 [[],[.left]] .chain = true := by decide
def e2392565992662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2392565992662 : Closed e2392565992662 ∧ code e2392565992662 = 11188659014870 := by decide
theorem cert_e2392565992662 : check e2392565992662 [[],[.left]] .chain = true := by decide
def e2392565992666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2392565992666 : Closed e2392565992666 ∧ code e2392565992666 = 11188659014874 := by decide
theorem cert_e2392565992666 : check e2392565992666 [[],[.left]] .chain = true := by decide
def e2392565992682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2392565992682 : Closed e2392565992682 ∧ code e2392565992682 = 11188659014890 := by decide
theorem cert_e2392565992682 : check e2392565992682 [[],[.left]] .chain = true := by decide
def e2392565992758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2392565992758 : Closed e2392565992758 ∧ code e2392565992758 = 11188659014966 := by decide
theorem cert_e2392565992758 : check e2392565992758 [[],[.left]] .chain = true := by decide
def e2392565992762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2392565992762 : Closed e2392565992762 ∧ code e2392565992762 = 11188659014970 := by decide
theorem cert_e2392565992762 : check e2392565992762 [[],[.left]] .chain = true := by decide
def e2392565992846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2392565992846 : Closed e2392565992846 ∧ code e2392565992846 = 11188659015054 := by decide
theorem cert_e2392565992846 : check e2392565992846 [[],[.left]] .chain = true := by decide
def e2392565992858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565992858 : Closed e2392565992858 ∧ code e2392565992858 = 11188659015066 := by decide
theorem cert_e2392565992858 : check e2392565992858 [[],[.left]] .chain = true := by decide
def e2392565993014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2392565993014 : Closed e2392565993014 ∧ code e2392565993014 = 11188659015222 := by decide
theorem cert_e2392565993014 : check e2392565993014 [[],[.left]] .chain = true := by decide
def e2392565993018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2392565993018 : Closed e2392565993018 ∧ code e2392565993018 = 11188659015226 := by decide
theorem cert_e2392565993018 : check e2392565993018 [[],[.left]] .chain = true := by decide
def e2392565993066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2392565993066 : Closed e2392565993066 ∧ code e2392565993066 = 11188659015274 := by decide
theorem cert_e2392565993066 : check e2392565993066 [[],[.left]] .chain = true := by decide
def e2392565993102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2392565993102 : Closed e2392565993102 ∧ code e2392565993102 = 11188659015310 := by decide
theorem cert_e2392565993102 : check e2392565993102 [[],[.left]] .chain = true := by decide
def e2392565993114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2392565993114 : Closed e2392565993114 ∧ code e2392565993114 = 11188659015322 := by decide
theorem cert_e2392565993114 : check e2392565993114 [[],[.left]] .chain = true := by decide
def e2392565993158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2392565993158 : Closed e2392565993158 ∧ code e2392565993158 = 11188659015366 := by decide
theorem cert_e2392565993158 : check e2392565993158 [[],[.left]] .chain = true := by decide
def e2392565993710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2392565993710 : Closed e2392565993710 ∧ code e2392565993710 = 11188659015918 := by decide
theorem cert_e2392565993710 : check e2392565993710 [[],[.left]] .chain = true := by decide
def e2392565993718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2392565993718 : Closed e2392565993718 ∧ code e2392565993718 = 11188659015926 := by decide
theorem cert_e2392565993718 : check e2392565993718 [[],[.left]] .chain = true := by decide
def e2392565994198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2392565994198 : Closed e2392565994198 ∧ code e2392565994198 = 11188659016406 := by decide
theorem cert_e2392565994198 : check e2392565994198 [[],[.left]] .chain = true := by decide
def e2392565994202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2392565994202 : Closed e2392565994202 ∧ code e2392565994202 = 11188659016410 := by decide
theorem cert_e2392565994202 : check e2392565994202 [[],[.left]] .chain = true := by decide
def e2392565994218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2392565994218 : Closed e2392565994218 ∧ code e2392565994218 = 11188659016426 := by decide
theorem cert_e2392565994218 : check e2392565994218 [[],[.left]] .chain = true := by decide
def e2392565994294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2392565994294 : Closed e2392565994294 ∧ code e2392565994294 = 11188659016502 := by decide
theorem cert_e2392565994294 : check e2392565994294 [[],[.left]] .chain = true := by decide
def e2392565994298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2392565994298 : Closed e2392565994298 ∧ code e2392565994298 = 11188659016506 := by decide
theorem cert_e2392565994298 : check e2392565994298 [[],[.left]] .chain = true := by decide
def e2392565994382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2392565994382 : Closed e2392565994382 ∧ code e2392565994382 = 11188659016590 := by decide
theorem cert_e2392565994382 : check e2392565994382 [[],[.left]] .chain = true := by decide
def e2392565994394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565994394 : Closed e2392565994394 ∧ code e2392565994394 = 11188659016602 := by decide
theorem cert_e2392565994394 : check e2392565994394 [[],[.left]] .chain = true := by decide
def e2392565995638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2392565995638 : Closed e2392565995638 ∧ code e2392565995638 = 11188659017846 := by decide
theorem cert_e2392565995638 : check e2392565995638 [[],[.left]] .chain = true := by decide
def e2392565995882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2392565995882 : Closed e2392565995882 ∧ code e2392565995882 = 11188659018090 := by decide
theorem cert_e2392565995882 : check e2392565995882 [[],[.left]] .chain = true := by decide
def e2392565995918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2392565995918 : Closed e2392565995918 ∧ code e2392565995918 = 11188659018126 := by decide
theorem cert_e2392565995918 : check e2392565995918 [[],[.left]] .chain = true := by decide
def e2392565995930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2392565995930 : Closed e2392565995930 ∧ code e2392565995930 = 11188659018138 := by decide
theorem cert_e2392565995930 : check e2392565995930 [[],[.left]] .chain = true := by decide
def e2392565995974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2392565995974 : Closed e2392565995974 ∧ code e2392565995974 = 11188659018182 := by decide
theorem cert_e2392565995974 : check e2392565995974 [[],[.left]] .chain = true := by decide
def e2392566008686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2392566008686 : Closed e2392566008686 ∧ code e2392566008686 = 11188659030894 := by decide
theorem cert_e2392566008686 : check e2392566008686 [[],[.left]] .smaller = true := by decide
def e2392566008694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2392566008694 : Closed e2392566008694 ∧ code e2392566008694 = 11188659030902 := by decide
theorem cert_e2392566008694 : check e2392566008694 [[],[.left]] .smaller = true := by decide
def e2392566008750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2392566008750 : Closed e2392566008750 ∧ code e2392566008750 = 11188659030958 := by decide
theorem cert_e2392566008750 : check e2392566008750 [[],[.left]] .smaller = true := by decide
def e2392566008762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2392566008762 : Closed e2392566008762 ∧ code e2392566008762 = 11188659030970 := by decide
theorem cert_e2392566008762 : check e2392566008762 [[],[.left]] .smaller = true := by decide
def e2392566008790 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2392566008790 : Closed e2392566008790 ∧ code e2392566008790 = 11188659030998 := by decide
theorem cert_e2392566008790 : check e2392566008790 [[],[.left]] .smaller = true := by decide
def e2392566008794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2392566008794 : Closed e2392566008794 ∧ code e2392566008794 = 11188659031002 := by decide
theorem cert_e2392566008794 : check e2392566008794 [[],[.left]] .smaller = true := by decide
def e2392566009070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2392566009070 : Closed e2392566009070 ∧ code e2392566009070 = 11188659031278 := by decide
theorem cert_e2392566009070 : check e2392566009070 [[],[.left]] .smaller = true := by decide
def e2392566009078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2392566009078 : Closed e2392566009078 ∧ code e2392566009078 = 11188659031286 := by decide
theorem cert_e2392566009078 : check e2392566009078 [[],[.left]] .smaller = true := by decide
def e2392566009454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2392566009454 : Closed e2392566009454 ∧ code e2392566009454 = 11188659031662 := by decide
theorem cert_e2392566009454 : check e2392566009454 [[],[.left]] .smaller = true := by decide
def e2392566009466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2392566009466 : Closed e2392566009466 ∧ code e2392566009466 = 11188659031674 := by decide
theorem cert_e2392566009466 : check e2392566009466 [[],[.left]] .smaller = true := by decide
def e2392566009654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2392566009654 : Closed e2392566009654 ∧ code e2392566009654 = 11188659031862 := by decide
theorem cert_e2392566009654 : check e2392566009654 [[],[.left]] .smaller = true := by decide
def e2392566009658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2392566009658 : Closed e2392566009658 ∧ code e2392566009658 = 11188659031866 := by decide
theorem cert_e2392566009658 : check e2392566009658 [[],[.left]] .smaller = true := by decide
def e2392566050158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2392566050158 : Closed e2392566050158 ∧ code e2392566050158 = 11188659072366 := by decide
theorem cert_e2392566050158 : check e2392566050158 [[],[.left]] .chain = true := by decide
def e2392566050166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2392566050166 : Closed e2392566050166 ∧ code e2392566050166 = 11188659072374 := by decide
theorem cert_e2392566050166 : check e2392566050166 [[],[.left]] .chain = true := by decide
def e2392566050222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2392566050222 : Closed e2392566050222 ∧ code e2392566050222 = 11188659072430 := by decide
theorem cert_e2392566050222 : check e2392566050222 [[],[.left]] .chain = true := by decide
def e2392566050234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2392566050234 : Closed e2392566050234 ∧ code e2392566050234 = 11188659072442 := by decide
theorem cert_e2392566050234 : check e2392566050234 [[],[.left]] .chain = true := by decide
def e2392566050262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2392566050262 : Closed e2392566050262 ∧ code e2392566050262 = 11188659072470 := by decide
theorem cert_e2392566050262 : check e2392566050262 [[],[.left]] .chain = true := by decide
def e2392566050266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2392566050266 : Closed e2392566050266 ∧ code e2392566050266 = 11188659072474 := by decide
theorem cert_e2392566050266 : check e2392566050266 [[],[.left]] .chain = true := by decide
def e2392566050478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2392566050478 : Closed e2392566050478 ∧ code e2392566050478 = 11188659072686 := by decide
theorem cert_e2392566050478 : check e2392566050478 [[],[.left]] .chain = true := by decide
def e2392566050490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2392566050490 : Closed e2392566050490 ∧ code e2392566050490 = 11188659072698 := by decide
theorem cert_e2392566050490 : check e2392566050490 [[],[.left]] .chain = true := by decide
def e2392566050538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2392566050538 : Closed e2392566050538 ∧ code e2392566050538 = 11188659072746 := by decide
theorem cert_e2392566050538 : check e2392566050538 [[],[.left]] .chain = true := by decide
def e2392566050646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2392566050646 : Closed e2392566050646 ∧ code e2392566050646 = 11188659072854 := by decide
theorem cert_e2392566050646 : check e2392566050646 [[],[.left]] .chain = true := by decide
def e2392566050650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2392566050650 : Closed e2392566050650 ∧ code e2392566050650 = 11188659072858 := by decide
theorem cert_e2392566050650 : check e2392566050650 [[],[.left]] .chain = true := by decide
def e2392566050666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2392566050666 : Closed e2392566050666 ∧ code e2392566050666 = 11188659072874 := by decide
theorem cert_e2392566050666 : check e2392566050666 [[],[.left]] .chain = true := by decide
def e2392566051694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2392566051694 : Closed e2392566051694 ∧ code e2392566051694 = 11188659073902 := by decide
theorem cert_e2392566051694 : check e2392566051694 [[],[.left]] .chain = true := by decide
def e2392566051702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2392566051702 : Closed e2392566051702 ∧ code e2392566051702 = 11188659073910 := by decide
theorem cert_e2392566051702 : check e2392566051702 [[],[.left]] .chain = true := by decide
def e2392566051758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2392566051758 : Closed e2392566051758 ∧ code e2392566051758 = 11188659073966 := by decide
theorem cert_e2392566051758 : check e2392566051758 [[],[.left]] .chain = true := by decide
def e2392566051770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2392566051770 : Closed e2392566051770 ∧ code e2392566051770 = 11188659073978 := by decide
theorem cert_e2392566051770 : check e2392566051770 [[],[.left]] .chain = true := by decide
def e2392566051798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2392566051798 : Closed e2392566051798 ∧ code e2392566051798 = 11188659074006 := by decide
theorem cert_e2392566051798 : check e2392566051798 [[],[.left]] .chain = true := by decide
def e2392566051802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2392566051802 : Closed e2392566051802 ∧ code e2392566051802 = 11188659074010 := by decide
theorem cert_e2392566051802 : check e2392566051802 [[],[.left]] .chain = true := by decide
def e2392566052078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392566052078 : Closed e2392566052078 ∧ code e2392566052078 = 11188659074286 := by decide
theorem cert_e2392566052078 : check e2392566052078 [[],[.left]] .chain = true := by decide
def e2392566052086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392566052086 : Closed e2392566052086 ∧ code e2392566052086 = 11188659074294 := by decide
theorem cert_e2392566052086 : check e2392566052086 [[],[.left]] .chain = true := by decide
def e2392566052462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392566052462 : Closed e2392566052462 ∧ code e2392566052462 = 11188659074670 := by decide
theorem cert_e2392566052462 : check e2392566052462 [[],[.left]] .chain = true := by decide
def e2392566052474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392566052474 : Closed e2392566052474 ∧ code e2392566052474 = 11188659074682 := by decide
theorem cert_e2392566052474 : check e2392566052474 [[],[.left]] .chain = true := by decide
def e2392566052662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392566052662 : Closed e2392566052662 ∧ code e2392566052662 = 11188659074870 := by decide
theorem cert_e2392566052662 : check e2392566052662 [[],[.left]] .chain = true := by decide
def e2392566052666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392566052666 : Closed e2392566052666 ∧ code e2392566052666 = 11188659074874 := by decide
theorem cert_e2392566052666 : check e2392566052666 [[],[.left]] .chain = true := by decide
def e2392566053102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2392566053102 : Closed e2392566053102 ∧ code e2392566053102 = 11188659075310 := by decide
theorem cert_e2392566053102 : check e2392566053102 [[],[.left]] .chain = true := by decide
def e2392566053110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2392566053110 : Closed e2392566053110 ∧ code e2392566053110 = 11188659075318 := by decide
theorem cert_e2392566053110 : check e2392566053110 [[],[.left]] .chain = true := by decide
def e2392566053294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2392566053294 : Closed e2392566053294 ∧ code e2392566053294 = 11188659075502 := by decide
theorem cert_e2392566053294 : check e2392566053294 [[],[.left]] .chain = true := by decide
def e2392566053306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2392566053306 : Closed e2392566053306 ∧ code e2392566053306 = 11188659075514 := by decide
theorem cert_e2392566053306 : check e2392566053306 [[],[.left]] .chain = true := by decide
def e2392566053354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2392566053354 : Closed e2392566053354 ∧ code e2392566053354 = 11188659075562 := by decide
theorem cert_e2392566053354 : check e2392566053354 [[],[.left]] .chain = true := by decide
def e2392566053486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392566053486 : Closed e2392566053486 ∧ code e2392566053486 = 11188659075694 := by decide
theorem cert_e2392566053486 : check e2392566053486 [[],[.left]] .chain = true := by decide
def e2392566053498 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392566053498 : Closed e2392566053498 ∧ code e2392566053498 = 11188659075706 := by decide
theorem cert_e2392566053498 : check e2392566053498 [[],[.left]] .chain = true := by decide
def e2392566053662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2392566053662 : Closed e2392566053662 ∧ code e2392566053662 = 11188659075870 := by decide
theorem cert_e2392566053662 : check e2392566053662 [[],[.left]] .chain = true := by decide
def e2392566053774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2392566053774 : Closed e2392566053774 ∧ code e2392566053774 = 11188659075982 := by decide
theorem cert_e2392566053774 : check e2392566053774 [[],[.left]] .chain = true := by decide
def e2392566053786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392566053786 : Closed e2392566053786 ∧ code e2392566053786 = 11188659075994 := by decide
theorem cert_e2392566053786 : check e2392566053786 [[],[.left]] .chain = true := by decide
def e2392566054006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2392566054006 : Closed e2392566054006 ∧ code e2392566054006 = 11188659076214 := by decide
theorem cert_e2392566054006 : check e2392566054006 [[],[.left]] .chain = true := by decide
def e2392566054102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2392566054102 : Closed e2392566054102 ∧ code e2392566054102 = 11188659076310 := by decide
theorem cert_e2392566054102 : check e2392566054102 [[],[.left]] .chain = true := by decide
def e2392566054106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2392566054106 : Closed e2392566054106 ∧ code e2392566054106 = 11188659076314 := by decide
theorem cert_e2392566054106 : check e2392566054106 [[],[.left]] .chain = true := by decide
def e2392566054122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2392566054122 : Closed e2392566054122 ∧ code e2392566054122 = 11188659076330 := by decide
theorem cert_e2392566054122 : check e2392566054122 [[],[.left]] .chain = true := by decide
def e2392566054198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392566054198 : Closed e2392566054198 ∧ code e2392566054198 = 11188659076406 := by decide
theorem cert_e2392566054198 : check e2392566054198 [[],[.left]] .chain = true := by decide
def e2392566054202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392566054202 : Closed e2392566054202 ∧ code e2392566054202 = 11188659076410 := by decide
theorem cert_e2392566054202 : check e2392566054202 [[],[.left]] .chain = true := by decide
def e2392566054286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2392566054286 : Closed e2392566054286 ∧ code e2392566054286 = 11188659076494 := by decide
theorem cert_e2392566054286 : check e2392566054286 [[],[.left]] .chain = true := by decide
def e2392566054298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392566054298 : Closed e2392566054298 ∧ code e2392566054298 = 11188659076506 := by decide
theorem cert_e2392566054298 : check e2392566054298 [[],[.left]] .chain = true := by decide
def e2392566055902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2392566055902 : Closed e2392566055902 ∧ code e2392566055902 = 11188659078110 := by decide
theorem cert_e2392566055902 : check e2392566055902 [[],[.left]] .chain = true := by decide
def e2392566055918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2392566055918 : Closed e2392566055918 ∧ code e2392566055918 = 11188659078126 := by decide
theorem cert_e2392566055918 : check e2392566055918 [[],[.left]] .chain = true := by decide
def e2392566057838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392566057838 : Closed e2392566057838 ∧ code e2392566057838 = 11188659080046 := by decide
theorem cert_e2392566057838 : check e2392566057838 [[],[.left]] .chain = true := by decide
def e2392566057846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392566057846 : Closed e2392566057846 ∧ code e2392566057846 = 11188659080054 := by decide
theorem cert_e2392566057846 : check e2392566057846 [[],[.left]] .chain = true := by decide
def e2392566057902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392566057902 : Closed e2392566057902 ∧ code e2392566057902 = 11188659080110 := by decide
theorem cert_e2392566057902 : check e2392566057902 [[],[.left]] .chain = true := by decide
def e2392566057914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392566057914 : Closed e2392566057914 ∧ code e2392566057914 = 11188659080122 := by decide
theorem cert_e2392566057914 : check e2392566057914 [[],[.left]] .chain = true := by decide
def e2392566057942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392566057942 : Closed e2392566057942 ∧ code e2392566057942 = 11188659080150 := by decide
theorem cert_e2392566057942 : check e2392566057942 [[],[.left]] .chain = true := by decide
def e2392566057946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392566057946 : Closed e2392566057946 ∧ code e2392566057946 = 11188659080154 := by decide
theorem cert_e2392566057946 : check e2392566057946 [[],[.left]] .chain = true := by decide
def e2392566058222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392566058222 : Closed e2392566058222 ∧ code e2392566058222 = 11188659080430 := by decide
theorem cert_e2392566058222 : check e2392566058222 [[],[.left]] .chain = true := by decide
def e2392566058230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392566058230 : Closed e2392566058230 ∧ code e2392566058230 = 11188659080438 := by decide
theorem cert_e2392566058230 : check e2392566058230 [[],[.left]] .chain = true := by decide
def e2392566058606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392566058606 : Closed e2392566058606 ∧ code e2392566058606 = 11188659080814 := by decide
theorem cert_e2392566058606 : check e2392566058606 [[],[.left]] .chain = true := by decide
def e2392566058618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392566058618 : Closed e2392566058618 ∧ code e2392566058618 = 11188659080826 := by decide
theorem cert_e2392566058618 : check e2392566058618 [[],[.left]] .chain = true := by decide
def e2392566058806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392566058806 : Closed e2392566058806 ∧ code e2392566058806 = 11188659081014 := by decide
theorem cert_e2392566058806 : check e2392566058806 [[],[.left]] .chain = true := by decide
def e2392566058810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392566058810 : Closed e2392566058810 ∧ code e2392566058810 = 11188659081018 := by decide
theorem cert_e2392566058810 : check e2392566058810 [[],[.left]] .chain = true := by decide
def e2392566063582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2392566063582 : Closed e2392566063582 ∧ code e2392566063582 = 11188659085790 := by decide
theorem cert_e2392566063582 : check e2392566063582 [[],[.left]] .chain = true := by decide
def e2392566063606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2392566063606 : Closed e2392566063606 ∧ code e2392566063606 = 11188659085814 := by decide
theorem cert_e2392566063606 : check e2392566063606 [[],[.left]] .chain = true := by decide
def e2392566064558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2392566064558 : Closed e2392566064558 ∧ code e2392566064558 = 11188659086766 := by decide
theorem cert_e2392566064558 : check e2392566064558 [[],[.left]] .chain = true := by decide
def e2392566064570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2392566064570 : Closed e2392566064570 ∧ code e2392566064570 = 11188659086778 := by decide
theorem cert_e2392566064570 : check e2392566064570 [[],[.left]] .chain = true := by decide
def e2392566064618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2392566064618 : Closed e2392566064618 ∧ code e2392566064618 = 11188659086826 := by decide
theorem cert_e2392566064618 : check e2392566064618 [[],[.left]] .chain = true := by decide
def e2392566064750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392566064750 : Closed e2392566064750 ∧ code e2392566064750 = 11188659086958 := by decide
theorem cert_e2392566064750 : check e2392566064750 [[],[.left]] .chain = true := by decide
def e2392566064762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392566064762 : Closed e2392566064762 ∧ code e2392566064762 = 11188659086970 := by decide
theorem cert_e2392566064762 : check e2392566064762 [[],[.left]] .chain = true := by decide
def e2392566064926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2392566064926 : Closed e2392566064926 ∧ code e2392566064926 = 11188659087134 := by decide
theorem cert_e2392566064926 : check e2392566064926 [[],[.left]] .chain = true := by decide
def e2392566065038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2392566065038 : Closed e2392566065038 ∧ code e2392566065038 = 11188659087246 := by decide
theorem cert_e2392566065038 : check e2392566065038 [[],[.left]] .chain = true := by decide
def e2392566065050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392566065050 : Closed e2392566065050 ∧ code e2392566065050 = 11188659087258 := by decide
theorem cert_e2392566065050 : check e2392566065050 [[],[.left]] .chain = true := by decide
def e2392566067438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2392566067438 : Closed e2392566067438 ∧ code e2392566067438 = 11188659089646 := by decide
theorem cert_e2392566067438 : check e2392566067438 [[],[.left]] .chain = true := by decide
def e2392566067446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2392566067446 : Closed e2392566067446 ∧ code e2392566067446 = 11188659089654 := by decide
theorem cert_e2392566067446 : check e2392566067446 [[],[.left]] .chain = true := by decide
def e2392566067926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2392566067926 : Closed e2392566067926 ∧ code e2392566067926 = 11188659090134 := by decide
theorem cert_e2392566067926 : check e2392566067926 [[],[.left]] .chain = true := by decide
def e2392566067930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2392566067930 : Closed e2392566067930 ∧ code e2392566067930 = 11188659090138 := by decide
theorem cert_e2392566067930 : check e2392566067930 [[],[.left]] .chain = true := by decide
def e2392566067946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2392566067946 : Closed e2392566067946 ∧ code e2392566067946 = 11188659090154 := by decide
theorem cert_e2392566067946 : check e2392566067946 [[],[.left]] .chain = true := by decide
def e2392566068022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392566068022 : Closed e2392566068022 ∧ code e2392566068022 = 11188659090230 := by decide
theorem cert_e2392566068022 : check e2392566068022 [[],[.left]] .chain = true := by decide
def e2392566068026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392566068026 : Closed e2392566068026 ∧ code e2392566068026 = 11188659090234 := by decide
theorem cert_e2392566068026 : check e2392566068026 [[],[.left]] .chain = true := by decide
def e2392566068110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2392566068110 : Closed e2392566068110 ∧ code e2392566068110 = 11188659090318 := by decide
theorem cert_e2392566068110 : check e2392566068110 [[],[.left]] .chain = true := by decide
end Blc.Floor43
