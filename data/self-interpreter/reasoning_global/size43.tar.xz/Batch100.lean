import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e835589426618 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0)))))
theorem wire_e835589426618 : Closed e835589426618 ∧ code e835589426618 = 9631682448826 := by decide
theorem cert_e835589426618 : check e835589426618 [] .sourceHead = true := by decide
def e835589426650 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))) (.var 0)))))
theorem wire_e835589426650 : Closed e835589426650 ∧ code e835589426650 = 9631682448858 := by decide
theorem cert_e835589426650 : check e835589426650 [] .sourceHead = true := by decide
def e835589426874 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0)))))
theorem wire_e835589426874 : Closed e835589426874 ∧ code e835589426874 = 9631682449082 := by decide
theorem cert_e835589426874 : check e835589426874 [] .sourceHead = true := by decide
def e835589426922 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0)))))
theorem wire_e835589426922 : Closed e835589426922 ∧ code e835589426922 = 9631682449130 := by decide
theorem cert_e835589426922 : check e835589426922 [] .sourceHead = true := by decide
def e835589427034 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))) (.var 0)))))
theorem wire_e835589427034 : Closed e835589427034 ∧ code e835589427034 = 9631682449242 := by decide
theorem cert_e835589427034 : check e835589427034 [] .sourceHead = true := by decide
def e835589427050 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0)))))
theorem wire_e835589427050 : Closed e835589427050 ∧ code e835589427050 = 9631682449258 := by decide
theorem cert_e835589427050 : check e835589427050 [] .sourceHead = true := by decide
def e835589428154 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0)))))
theorem wire_e835589428154 : Closed e835589428154 ∧ code e835589428154 = 9631682450362 := by decide
theorem cert_e835589428154 : check e835589428154 [] .sourceHead = true := by decide
def e835589428186 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0)))))
theorem wire_e835589428186 : Closed e835589428186 ∧ code e835589428186 = 9631682450394 := by decide
theorem cert_e835589428186 : check e835589428186 [] .sourceHead = true := by decide
def e835589429690 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e835589429690 : Closed e835589429690 ∧ code e835589429690 = 9631682451898 := by decide
theorem cert_e835589429690 : check e835589429690 [] .sourceHead = true := by decide
def e835589429738 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e835589429738 : Closed e835589429738 ∧ code e835589429738 = 9631682451946 := by decide
theorem cert_e835589429738 : check e835589429738 [] .sourceHead = true := by decide
def e835589430490 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e835589430490 : Closed e835589430490 ∧ code e835589430490 = 9631682452698 := by decide
theorem cert_e835589430490 : check e835589430490 [] .sourceHead = true := by decide
def e835589430506 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e835589430506 : Closed e835589430506 ∧ code e835589430506 = 9631682452714 := by decide
theorem cert_e835589430506 : check e835589430506 [] .sourceHead = true := by decide
def e835589433018 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.var 0)))))
theorem wire_e835589433018 : Closed e835589433018 ∧ code e835589433018 = 9631682455226 := by decide
theorem cert_e835589433018 : check e835589433018 [] .sourceHead = true := by decide
def e835589433066 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))) (.var 0)))))
theorem wire_e835589433066 : Closed e835589433066 ∧ code e835589433066 = 9631682455274 := by decide
theorem cert_e835589433066 : check e835589433066 [] .sourceHead = true := by decide
def e835589433258 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))) (.var 0)))))
theorem wire_e835589433258 : Closed e835589433258 ∧ code e835589433258 = 9631682455466 := by decide
theorem cert_e835589433258 : check e835589433258 [] .sourceHead = true := by decide
def e835589433786 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.var 0)))))
theorem wire_e835589433786 : Closed e835589433786 ∧ code e835589433786 = 9631682455994 := by decide
theorem cert_e835589433786 : check e835589433786 [] .sourceHead = true := by decide
def e835589433834 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))) (.var 0)))))
theorem wire_e835589433834 : Closed e835589433834 ∧ code e835589433834 = 9631682456042 := by decide
theorem cert_e835589433834 : check e835589433834 [] .sourceHead = true := by decide
def e835589434986 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))) (.var 0)))))
theorem wire_e835589434986 : Closed e835589434986 ∧ code e835589434986 = 9631682457194 := by decide
theorem cert_e835589434986 : check e835589434986 [] .sourceHead = true := by decide
def e835589436250 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))) (.var 0)))))
theorem wire_e835589436250 : Closed e835589436250 ∧ code e835589436250 = 9631682458458 := by decide
theorem cert_e835589436250 : check e835589436250 [] .sourceHead = true := by decide
def e835589436266 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))) (.var 0)))))
theorem wire_e835589436266 : Closed e835589436266 ∧ code e835589436266 = 9631682458474 := by decide
theorem cert_e835589436266 : check e835589436266 [] .sourceHead = true := by decide
def e835589436330 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))) (.var 0)))))
theorem wire_e835589436330 : Closed e835589436330 ∧ code e835589436330 = 9631682458538 := by decide
theorem cert_e835589436330 : check e835589436330 [] .sourceHead = true := by decide
def e835589436634 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e835589436634 : Closed e835589436634 ∧ code e835589436634 = 9631682458842 := by decide
theorem cert_e835589436634 : check e835589436634 [] .sourceHead = true := by decide
def e835589436650 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e835589436650 : Closed e835589436650 ∧ code e835589436650 = 9631682458858 := by decide
theorem cert_e835589436650 : check e835589436650 [] .sourceHead = true := by decide
def e835589437034 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 0)))))
theorem wire_e835589437034 : Closed e835589437034 ∧ code e835589437034 = 9631682459242 := by decide
theorem cert_e835589437034 : check e835589437034 [] .sourceHead = true := by decide
def e835589451194 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0)))))
theorem wire_e835589451194 : Closed e835589451194 ∧ code e835589451194 = 9631682473402 := by decide
theorem cert_e835589451194 : check e835589451194 [] .sourceHead = true := by decide
def e835589451226 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0)))))
theorem wire_e835589451226 : Closed e835589451226 ∧ code e835589451226 = 9631682473434 := by decide
theorem cert_e835589451226 : check e835589451226 [] .sourceHead = true := by decide
def e835589451450 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0)))))
theorem wire_e835589451450 : Closed e835589451450 ∧ code e835589451450 = 9631682473658 := by decide
theorem cert_e835589451450 : check e835589451450 [] .sourceHead = true := by decide
def e835589451498 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0)))))
theorem wire_e835589451498 : Closed e835589451498 ∧ code e835589451498 = 9631682473706 := by decide
theorem cert_e835589451498 : check e835589451498 [] .sourceHead = true := by decide
def e835589451610 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0)))))
theorem wire_e835589451610 : Closed e835589451610 ∧ code e835589451610 = 9631682473818 := by decide
theorem cert_e835589451610 : check e835589451610 [] .sourceHead = true := by decide
def e835589451626 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0)))))
theorem wire_e835589451626 : Closed e835589451626 ∧ code e835589451626 = 9631682473834 := by decide
theorem cert_e835589451626 : check e835589451626 [] .sourceHead = true := by decide
def e835589452730 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0)))))
theorem wire_e835589452730 : Closed e835589452730 ∧ code e835589452730 = 9631682474938 := by decide
theorem cert_e835589452730 : check e835589452730 [] .sourceHead = true := by decide
def e835589452762 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0)))))
theorem wire_e835589452762 : Closed e835589452762 ∧ code e835589452762 = 9631682474970 := by decide
theorem cert_e835589452762 : check e835589452762 [] .sourceHead = true := by decide
def e835589454266 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0)))))
theorem wire_e835589454266 : Closed e835589454266 ∧ code e835589454266 = 9631682476474 := by decide
theorem cert_e835589454266 : check e835589454266 [] .sourceHead = true := by decide
def e835589454314 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0)))))
theorem wire_e835589454314 : Closed e835589454314 ∧ code e835589454314 = 9631682476522 := by decide
theorem cert_e835589454314 : check e835589454314 [] .sourceHead = true := by decide
def e835589455066 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0)))))
theorem wire_e835589455066 : Closed e835589455066 ∧ code e835589455066 = 9631682477274 := by decide
theorem cert_e835589455066 : check e835589455066 [] .sourceHead = true := by decide
def e835589455082 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0)))))
theorem wire_e835589455082 : Closed e835589455082 ∧ code e835589455082 = 9631682477290 := by decide
theorem cert_e835589455082 : check e835589455082 [] .sourceHead = true := by decide
def e835589478074 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))) (.var 0)))))
theorem wire_e835589478074 : Closed e835589478074 ∧ code e835589478074 = 9631682500282 := by decide
theorem cert_e835589478074 : check e835589478074 [] .sourceHead = true := by decide
def e835589478122 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.var 0)))))
theorem wire_e835589478122 : Closed e835589478122 ∧ code e835589478122 = 9631682500330 := by decide
theorem cert_e835589478122 : check e835589478122 [] .sourceHead = true := by decide
def e835589478314 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))) (.var 0)))))
theorem wire_e835589478314 : Closed e835589478314 ∧ code e835589478314 = 9631682500522 := by decide
theorem cert_e835589478314 : check e835589478314 [] .sourceHead = true := by decide
def e835589478842 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))) (.var 0)))))
theorem wire_e835589478842 : Closed e835589478842 ∧ code e835589478842 = 9631682501050 := by decide
theorem cert_e835589478842 : check e835589478842 [] .sourceHead = true := by decide
def e835589478890 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))) (.var 0)))))
theorem wire_e835589478890 : Closed e835589478890 ∧ code e835589478890 = 9631682501098 := by decide
theorem cert_e835589478890 : check e835589478890 [] .sourceHead = true := by decide
def e835589480042 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))) (.var 0)))))
theorem wire_e835589480042 : Closed e835589480042 ∧ code e835589480042 = 9631682502250 := by decide
theorem cert_e835589480042 : check e835589480042 [] .sourceHead = true := by decide
def e835589491546 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.var 0)))))
theorem wire_e835589491546 : Closed e835589491546 ∧ code e835589491546 = 9631682513754 := by decide
theorem cert_e835589491546 : check e835589491546 [] .sourceHead = true := by decide
def e835589491562 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.var 0)))))
theorem wire_e835589491562 : Closed e835589491562 ∧ code e835589491562 = 9631682513770 := by decide
theorem cert_e835589491562 : check e835589491562 [] .sourceHead = true := by decide
def e835589491626 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.var 0)))))
theorem wire_e835589491626 : Closed e835589491626 ∧ code e835589491626 = 9631682513834 := by decide
theorem cert_e835589491626 : check e835589491626 [] .sourceHead = true := by decide
def e835589491930 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.var 0)))))
theorem wire_e835589491930 : Closed e835589491930 ∧ code e835589491930 = 9631682514138 := by decide
theorem cert_e835589491930 : check e835589491930 [] .sourceHead = true := by decide
def e835589491946 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.var 0)))))
theorem wire_e835589491946 : Closed e835589491946 ∧ code e835589491946 = 9631682514154 := by decide
theorem cert_e835589491946 : check e835589491946 [] .sourceHead = true := by decide
def e835589492330 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.var 0)))))
theorem wire_e835589492330 : Closed e835589492330 ∧ code e835589492330 = 9631682514538 := by decide
theorem cert_e835589492330 : check e835589492330 [] .sourceHead = true := by decide
def e835590041018 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0)))))
theorem wire_e835590041018 : Closed e835590041018 ∧ code e835590041018 = 9631683063226 := by decide
theorem cert_e835590041018 : check e835590041018 [] .sourceHead = true := by decide
def e835590041050 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0)))))
theorem wire_e835590041050 : Closed e835590041050 ∧ code e835590041050 = 9631683063258 := by decide
theorem cert_e835590041050 : check e835590041050 [] .sourceHead = true := by decide
def e835590041274 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0)))))
theorem wire_e835590041274 : Closed e835590041274 ∧ code e835590041274 = 9631683063482 := by decide
theorem cert_e835590041274 : check e835590041274 [] .sourceHead = true := by decide
def e835590041322 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0)))))
theorem wire_e835590041322 : Closed e835590041322 ∧ code e835590041322 = 9631683063530 := by decide
theorem cert_e835590041322 : check e835590041322 [] .sourceHead = true := by decide
def e835590041434 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0)))))
theorem wire_e835590041434 : Closed e835590041434 ∧ code e835590041434 = 9631683063642 := by decide
theorem cert_e835590041434 : check e835590041434 [] .sourceHead = true := by decide
def e835590041450 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0)))))
theorem wire_e835590041450 : Closed e835590041450 ∧ code e835590041450 = 9631683063658 := by decide
theorem cert_e835590041450 : check e835590041450 [] .sourceHead = true := by decide
def e835590042554 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0)))))
theorem wire_e835590042554 : Closed e835590042554 ∧ code e835590042554 = 9631683064762 := by decide
theorem cert_e835590042554 : check e835590042554 [] .sourceHead = true := by decide
def e835590042586 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0)))))
theorem wire_e835590042586 : Closed e835590042586 ∧ code e835590042586 = 9631683064794 := by decide
theorem cert_e835590042586 : check e835590042586 [] .sourceHead = true := by decide
def e835590044090 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0)))))
theorem wire_e835590044090 : Closed e835590044090 ∧ code e835590044090 = 9631683066298 := by decide
theorem cert_e835590044090 : check e835590044090 [] .sourceHead = true := by decide
def e835590044138 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0)))))
theorem wire_e835590044138 : Closed e835590044138 ∧ code e835590044138 = 9631683066346 := by decide
theorem cert_e835590044138 : check e835590044138 [] .sourceHead = true := by decide
def e835590044890 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0)))))
theorem wire_e835590044890 : Closed e835590044890 ∧ code e835590044890 = 9631683067098 := by decide
theorem cert_e835590044890 : check e835590044890 [] .sourceHead = true := by decide
def e835590044906 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0)))))
theorem wire_e835590044906 : Closed e835590044906 ∧ code e835590044906 = 9631683067114 := by decide
theorem cert_e835590044906 : check e835590044906 [] .sourceHead = true := by decide
def e836456246810 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456246810 : Closed e836456246810 ∧ code e836456246810 = 9632549269018 := by decide
theorem cert_e836456246810 : check e836456246810 [] .sourceHead = true := by decide
def e836456248858 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456248858 : Closed e836456248858 ∧ code e836456248858 = 9632549271066 := by decide
theorem cert_e836456248858 : check e836456248858 [] .sourceHead = true := by decide
def e836456263194 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456263194 : Closed e836456263194 ∧ code e836456263194 = 9632549285402 := by decide
theorem cert_e836456263194 : check e836456263194 [] .sourceHead = true := by decide
def e836456266266 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456266266 : Closed e836456266266 ∧ code e836456266266 = 9632549288474 := by decide
theorem cert_e836456266266 : check e836456266266 [] .sourceHead = true := by decide
def e836456273434 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456273434 : Closed e836456273434 ∧ code e836456273434 = 9632549295642 := by decide
theorem cert_e836456273434 : check e836456273434 [] .sourceHead = true := by decide
def e836456274458 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456274458 : Closed e836456274458 ∧ code e836456274458 = 9632549296666 := by decide
theorem cert_e836456274458 : check e836456274458 [] .sourceHead = true := by decide
def e836456328730 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456328730 : Closed e836456328730 ∧ code e836456328730 = 9632549350938 := by decide
theorem cert_e836456328730 : check e836456328730 [] .sourceHead = true := by decide
def e836456331802 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456331802 : Closed e836456331802 ∧ code e836456331802 = 9632549354010 := by decide
theorem cert_e836456331802 : check e836456331802 [] .sourceHead = true := by decide
def e836456344090 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456344090 : Closed e836456344090 ∧ code e836456344090 = 9632549366298 := by decide
theorem cert_e836456344090 : check e836456344090 [] .sourceHead = true := by decide
def e836456371738 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456371738 : Closed e836456371738 ∧ code e836456371738 = 9632549393946 := by decide
theorem cert_e836456371738 : check e836456371738 [] .sourceHead = true := by decide
def e836456372762 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456372762 : Closed e836456372762 ∧ code e836456372762 = 9632549394970 := by decide
theorem cert_e836456372762 : check e836456372762 [] .sourceHead = true := by decide
def e836456376858 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456376858 : Closed e836456376858 ∧ code e836456376858 = 9632549399066 := by decide
theorem cert_e836456376858 : check e836456376858 [] .sourceHead = true := by decide
def e836456640026 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456640026 : Closed e836456640026 ∧ code e836456640026 = 9632549662234 := by decide
theorem cert_e836456640026 : check e836456640026 [] .sourceHead = true := by decide
def e836456642074 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456642074 : Closed e836456642074 ∧ code e836456642074 = 9632549664282 := by decide
theorem cert_e836456642074 : check e836456642074 [] .sourceHead = true := by decide
def e836456656410 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456656410 : Closed e836456656410 ∧ code e836456656410 = 9632549678618 := by decide
theorem cert_e836456656410 : check e836456656410 [] .sourceHead = true := by decide
def e836456659482 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456659482 : Closed e836456659482 ∧ code e836456659482 = 9632549681690 := by decide
theorem cert_e836456659482 : check e836456659482 [] .sourceHead = true := by decide
def e836456666650 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456666650 : Closed e836456666650 ∧ code e836456666650 = 9632549688858 := by decide
theorem cert_e836456666650 : check e836456666650 [] .sourceHead = true := by decide
def e836456667674 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456667674 : Closed e836456667674 ∧ code e836456667674 = 9632549689882 := by decide
theorem cert_e836456667674 : check e836456667674 [] .sourceHead = true := by decide
def e836456738330 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456738330 : Closed e836456738330 ∧ code e836456738330 = 9632549760538 := by decide
theorem cert_e836456738330 : check e836456738330 [] .sourceHead = true := by decide
def e836456740378 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456740378 : Closed e836456740378 ∧ code e836456740378 = 9632549762586 := by decide
theorem cert_e836456740378 : check e836456740378 [] .sourceHead = true := by decide
def e836456836634 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456836634 : Closed e836456836634 ∧ code e836456836634 = 9632549858842 := by decide
theorem cert_e836456836634 : check e836456836634 [] .sourceHead = true := by decide
def e836456839706 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456839706 : Closed e836456839706 ∧ code e836456839706 = 9632549861914 := by decide
theorem cert_e836456839706 : check e836456839706 [] .sourceHead = true := by decide
def e836456887834 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456887834 : Closed e836456887834 ∧ code e836456887834 = 9632549910042 := by decide
theorem cert_e836456887834 : check e836456887834 [] .sourceHead = true := by decide
def e836456888858 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836456888858 : Closed e836456888858 ∧ code e836456888858 = 9632549911066 := by decide
theorem cert_e836456888858 : check e836456888858 [] .sourceHead = true := by decide
def e836457049626 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457049626 : Closed e836457049626 ∧ code e836457049626 = 9632550071834 := by decide
theorem cert_e836457049626 : check e836457049626 [] .sourceHead = true := by decide
def e836457052698 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457052698 : Closed e836457052698 ∧ code e836457052698 = 9632550074906 := by decide
theorem cert_e836457052698 : check e836457052698 [] .sourceHead = true := by decide
def e836457064986 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457064986 : Closed e836457064986 ∧ code e836457064986 = 9632550087194 := by decide
theorem cert_e836457064986 : check e836457064986 [] .sourceHead = true := by decide
def e836457098778 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457098778 : Closed e836457098778 ∧ code e836457098778 = 9632550120986 := by decide
theorem cert_e836457098778 : check e836457098778 [] .sourceHead = true := by decide
def e836457101850 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457101850 : Closed e836457101850 ∧ code e836457101850 = 9632550124058 := by decide
theorem cert_e836457101850 : check e836457101850 [] .sourceHead = true := by decide
def e836457175578 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457175578 : Closed e836457175578 ∧ code e836457175578 = 9632550197786 := by decide
theorem cert_e836457175578 : check e836457175578 [] .sourceHead = true := by decide
def e836457256474 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457256474 : Closed e836457256474 ∧ code e836457256474 = 9632550278682 := by decide
theorem cert_e836457256474 : check e836457256474 [] .sourceHead = true := by decide
def e836457257498 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457257498 : Closed e836457257498 ∧ code e836457257498 = 9632550279706 := by decide
theorem cert_e836457257498 : check e836457257498 [] .sourceHead = true := by decide
def e836457261594 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457261594 : Closed e836457261594 ∧ code e836457261594 = 9632550283802 := by decide
theorem cert_e836457261594 : check e836457261594 [] .sourceHead = true := by decide
def e836457281050 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457281050 : Closed e836457281050 ∧ code e836457281050 = 9632550303258 := by decide
theorem cert_e836457281050 : check e836457281050 [] .sourceHead = true := by decide
def e836457282074 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457282074 : Closed e836457282074 ∧ code e836457282074 = 9632550304282 := by decide
theorem cert_e836457282074 : check e836457282074 [] .sourceHead = true := by decide
def e836457306650 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836457306650 : Closed e836457306650 ∧ code e836457306650 = 9632550328858 := by decide
theorem cert_e836457306650 : check e836457306650 [] .sourceHead = true := by decide
def e836458212890 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458212890 : Closed e836458212890 ∧ code e836458212890 = 9632551235098 := by decide
theorem cert_e836458212890 : check e836458212890 [] .sourceHead = true := by decide
def e836458214938 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458214938 : Closed e836458214938 ∧ code e836458214938 = 9632551237146 := by decide
theorem cert_e836458214938 : check e836458214938 [] .sourceHead = true := by decide
def e836458229274 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458229274 : Closed e836458229274 ∧ code e836458229274 = 9632551251482 := by decide
theorem cert_e836458229274 : check e836458229274 [] .sourceHead = true := by decide
def e836458232346 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458232346 : Closed e836458232346 ∧ code e836458232346 = 9632551254554 := by decide
theorem cert_e836458232346 : check e836458232346 [] .sourceHead = true := by decide
def e836458239514 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458239514 : Closed e836458239514 ∧ code e836458239514 = 9632551261722 := by decide
theorem cert_e836458239514 : check e836458239514 [] .sourceHead = true := by decide
def e836458240538 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458240538 : Closed e836458240538 ∧ code e836458240538 = 9632551262746 := by decide
theorem cert_e836458240538 : check e836458240538 [] .sourceHead = true := by decide
def e836458311194 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458311194 : Closed e836458311194 ∧ code e836458311194 = 9632551333402 := by decide
theorem cert_e836458311194 : check e836458311194 [] .sourceHead = true := by decide
def e836458313242 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458313242 : Closed e836458313242 ∧ code e836458313242 = 9632551335450 := by decide
theorem cert_e836458313242 : check e836458313242 [] .sourceHead = true := by decide
def e836458409498 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458409498 : Closed e836458409498 ∧ code e836458409498 = 9632551431706 := by decide
theorem cert_e836458409498 : check e836458409498 [] .sourceHead = true := by decide
def e836458412570 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458412570 : Closed e836458412570 ∧ code e836458412570 = 9632551434778 := by decide
theorem cert_e836458412570 : check e836458412570 [] .sourceHead = true := by decide
def e836458460698 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458460698 : Closed e836458460698 ∧ code e836458460698 = 9632551482906 := by decide
theorem cert_e836458460698 : check e836458460698 [] .sourceHead = true := by decide
def e836458461722 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836458461722 : Closed e836458461722 ∧ code e836458461722 = 9632551483930 := by decide
theorem cert_e836458461722 : check e836458461722 [] .sourceHead = true := by decide
def e836459933210 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836459933210 : Closed e836459933210 ∧ code e836459933210 = 9632552955418 := by decide
theorem cert_e836459933210 : check e836459933210 [] .sourceHead = true := by decide
def e836459936282 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836459936282 : Closed e836459936282 ∧ code e836459936282 = 9632552958490 := by decide
theorem cert_e836459936282 : check e836459936282 [] .sourceHead = true := by decide
def e836459948570 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836459948570 : Closed e836459948570 ∧ code e836459948570 = 9632552970778 := by decide
theorem cert_e836459948570 : check e836459948570 [] .sourceHead = true := by decide
def e836459982362 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836459982362 : Closed e836459982362 ∧ code e836459982362 = 9632553004570 := by decide
theorem cert_e836459982362 : check e836459982362 [] .sourceHead = true := by decide
def e836459985434 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836459985434 : Closed e836459985434 ∧ code e836459985434 = 9632553007642 := by decide
theorem cert_e836459985434 : check e836459985434 [] .sourceHead = true := by decide
def e836460059162 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836460059162 : Closed e836460059162 ∧ code e836460059162 = 9632553081370 := by decide
theorem cert_e836460059162 : check e836460059162 [] .sourceHead = true := by decide
def e836460795418 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836460795418 : Closed e836460795418 ∧ code e836460795418 = 9632553817626 := by decide
theorem cert_e836460795418 : check e836460795418 [] .sourceHead = true := by decide
def e836460796442 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836460796442 : Closed e836460796442 ∧ code e836460796442 = 9632553818650 := by decide
theorem cert_e836460796442 : check e836460796442 [] .sourceHead = true := by decide
def e836460800538 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836460800538 : Closed e836460800538 ∧ code e836460800538 = 9632553822746 := by decide
theorem cert_e836460800538 : check e836460800538 [] .sourceHead = true := by decide
def e836460819994 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836460819994 : Closed e836460819994 ∧ code e836460819994 = 9632553842202 := by decide
theorem cert_e836460819994 : check e836460819994 [] .sourceHead = true := by decide
def e836460821018 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836460821018 : Closed e836460821018 ∧ code e836460821018 = 9632553843226 := by decide
theorem cert_e836460821018 : check e836460821018 [] .sourceHead = true := by decide
def e836460845594 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836460845594 : Closed e836460845594 ∧ code e836460845594 = 9632553867802 := by decide
theorem cert_e836460845594 : check e836460845594 [] .sourceHead = true := by decide
def e836495961626 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836495961626 : Closed e836495961626 ∧ code e836495961626 = 9632588983834 := by decide
theorem cert_e836495961626 : check e836495961626 [] .sourceHead = true := by decide
def e836495963674 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836495963674 : Closed e836495963674 ∧ code e836495963674 = 9632588985882 := by decide
theorem cert_e836495963674 : check e836495963674 [] .sourceHead = true := by decide
def e836495978010 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836495978010 : Closed e836495978010 ∧ code e836495978010 = 9632589000218 := by decide
theorem cert_e836495978010 : check e836495978010 [] .sourceHead = true := by decide
def e836495981082 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836495981082 : Closed e836495981082 ∧ code e836495981082 = 9632589003290 := by decide
theorem cert_e836495981082 : check e836495981082 [] .sourceHead = true := by decide
def e836495988250 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836495988250 : Closed e836495988250 ∧ code e836495988250 = 9632589010458 := by decide
theorem cert_e836495988250 : check e836495988250 [] .sourceHead = true := by decide
def e836495989274 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836495989274 : Closed e836495989274 ∧ code e836495989274 = 9632589011482 := by decide
theorem cert_e836495989274 : check e836495989274 [] .sourceHead = true := by decide
def e836496059930 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836496059930 : Closed e836496059930 ∧ code e836496059930 = 9632589082138 := by decide
theorem cert_e836496059930 : check e836496059930 [] .sourceHead = true := by decide
def e836496061978 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836496061978 : Closed e836496061978 ∧ code e836496061978 = 9632589084186 := by decide
theorem cert_e836496061978 : check e836496061978 [] .sourceHead = true := by decide
def e836496158234 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836496158234 : Closed e836496158234 ∧ code e836496158234 = 9632589180442 := by decide
theorem cert_e836496158234 : check e836496158234 [] .sourceHead = true := by decide
def e836496161306 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836496161306 : Closed e836496161306 ∧ code e836496161306 = 9632589183514 := by decide
theorem cert_e836496161306 : check e836496161306 [] .sourceHead = true := by decide
def e836496209434 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836496209434 : Closed e836496209434 ∧ code e836496209434 = 9632589231642 := by decide
theorem cert_e836496209434 : check e836496209434 [] .sourceHead = true := by decide
def e836496210458 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e836496210458 : Closed e836496210458 ∧ code e836496210458 = 9632589232666 := by decide
theorem cert_e836496210458 : check e836496210458 [] .sourceHead = true := by decide
def e836499451246 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e836499451246 : Closed e836499451246 ∧ code e836499451246 = 9632592473454 := by decide
theorem cert_e836499451246 : check e836499451246 [] .sourceHead = true := by decide
def e836499451254 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e836499451254 : Closed e836499451254 ∧ code e836499451254 = 9632592473462 := by decide
theorem cert_e836499451254 : check e836499451254 [] .sourceHead = true := by decide
def e836499451310 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e836499451310 : Closed e836499451310 ∧ code e836499451310 = 9632592473518 := by decide
theorem cert_e836499451310 : check e836499451310 [] .sourceHead = true := by decide
def e836499451322 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e836499451322 : Closed e836499451322 ∧ code e836499451322 = 9632592473530 := by decide
theorem cert_e836499451322 : check e836499451322 [] .sourceHead = true := by decide
def e836499451350 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e836499451350 : Closed e836499451350 ∧ code e836499451350 = 9632592473558 := by decide
theorem cert_e836499451350 : check e836499451350 [] .sourceHead = true := by decide
def e836499451354 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e836499451354 : Closed e836499451354 ∧ code e836499451354 = 9632592473562 := by decide
theorem cert_e836499451354 : check e836499451354 [] .sourceHead = true := by decide
def e836499451566 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e836499451566 : Closed e836499451566 ∧ code e836499451566 = 9632592473774 := by decide
theorem cert_e836499451566 : check e836499451566 [] .sourceHead = true := by decide
def e836499451578 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e836499451578 : Closed e836499451578 ∧ code e836499451578 = 9632592473786 := by decide
theorem cert_e836499451578 : check e836499451578 [] .sourceHead = true := by decide
def e836499451626 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e836499451626 : Closed e836499451626 ∧ code e836499451626 = 9632592473834 := by decide
theorem cert_e836499451626 : check e836499451626 [] .sourceHead = true := by decide
def e836499451734 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e836499451734 : Closed e836499451734 ∧ code e836499451734 = 9632592473942 := by decide
theorem cert_e836499451734 : check e836499451734 [] .sourceHead = true := by decide
def e836499451738 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e836499451738 : Closed e836499451738 ∧ code e836499451738 = 9632592473946 := by decide
theorem cert_e836499451738 : check e836499451738 [] .sourceHead = true := by decide
def e836499451754 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e836499451754 : Closed e836499451754 ∧ code e836499451754 = 9632592473962 := by decide
theorem cert_e836499451754 : check e836499451754 [] .sourceHead = true := by decide
def e836499452782 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e836499452782 : Closed e836499452782 ∧ code e836499452782 = 9632592474990 := by decide
theorem cert_e836499452782 : check e836499452782 [] .sourceHead = true := by decide
def e836499452790 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e836499452790 : Closed e836499452790 ∧ code e836499452790 = 9632592474998 := by decide
theorem cert_e836499452790 : check e836499452790 [] .sourceHead = true := by decide
def e836499452846 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e836499452846 : Closed e836499452846 ∧ code e836499452846 = 9632592475054 := by decide
theorem cert_e836499452846 : check e836499452846 [] .sourceHead = true := by decide
def e836499452858 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e836499452858 : Closed e836499452858 ∧ code e836499452858 = 9632592475066 := by decide
theorem cert_e836499452858 : check e836499452858 [] .sourceHead = true := by decide
def e836499452886 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e836499452886 : Closed e836499452886 ∧ code e836499452886 = 9632592475094 := by decide
theorem cert_e836499452886 : check e836499452886 [] .sourceHead = true := by decide
def e836499452890 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e836499452890 : Closed e836499452890 ∧ code e836499452890 = 9632592475098 := by decide
theorem cert_e836499452890 : check e836499452890 [] .sourceHead = true := by decide
def e836499453166 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e836499453166 : Closed e836499453166 ∧ code e836499453166 = 9632592475374 := by decide
theorem cert_e836499453166 : check e836499453166 [] .sourceHead = true := by decide
def e836499453174 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e836499453174 : Closed e836499453174 ∧ code e836499453174 = 9632592475382 := by decide
theorem cert_e836499453174 : check e836499453174 [] .sourceHead = true := by decide
def e836499453550 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e836499453550 : Closed e836499453550 ∧ code e836499453550 = 9632592475758 := by decide
theorem cert_e836499453550 : check e836499453550 [] .sourceHead = true := by decide
def e836499453562 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e836499453562 : Closed e836499453562 ∧ code e836499453562 = 9632592475770 := by decide
theorem cert_e836499453562 : check e836499453562 [] .sourceHead = true := by decide
def e836499453750 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e836499453750 : Closed e836499453750 ∧ code e836499453750 = 9632592475958 := by decide
theorem cert_e836499453750 : check e836499453750 [] .sourceHead = true := by decide
def e836499453754 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e836499453754 : Closed e836499453754 ∧ code e836499453754 = 9632592475962 := by decide
theorem cert_e836499453754 : check e836499453754 [] .sourceHead = true := by decide
def e836499454382 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e836499454382 : Closed e836499454382 ∧ code e836499454382 = 9632592476590 := by decide
theorem cert_e836499454382 : check e836499454382 [] .sourceHead = true := by decide
def e836499454394 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e836499454394 : Closed e836499454394 ∧ code e836499454394 = 9632592476602 := by decide
theorem cert_e836499454394 : check e836499454394 [] .sourceHead = true := by decide
def e836499454442 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e836499454442 : Closed e836499454442 ∧ code e836499454442 = 9632592476650 := by decide
theorem cert_e836499454442 : check e836499454442 [] .sourceHead = true := by decide
def e836499454574 : Term := (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e836499454574 : Closed e836499454574 ∧ code e836499454574 = 9632592476782 := by decide
theorem cert_e836499454574 : check e836499454574 [] .sourceHead = true := by decide
end Blc.Floor43
