import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422377428190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422377428190 : Closed e2422377428190 ∧ code e2422377428190 = 11218470450398 := by decide
theorem cert_e2422377428190 : check e2422377428190 [[],[]] .three = true := by decide
def e2422377428218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422377428218 : Closed e2422377428218 ∧ code e2422377428218 = 11218470450426 := by decide
theorem cert_e2422377428218 : check e2422377428218 [[],[]] .three = true := by decide
def e2422377459030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422377459030 : Closed e2422377459030 ∧ code e2422377459030 = 11218470481238 := by decide
theorem cert_e2422377459030 : check e2422377459030 [[],[]] .smaller = true := by decide
def e2422377459034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422377459034 : Closed e2422377459034 ∧ code e2422377459034 = 11218470481242 := by decide
theorem cert_e2422377459034 : check e2422377459034 [[],[]] .smaller = true := by decide
def e2422377459050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422377459050 : Closed e2422377459050 ∧ code e2422377459050 = 11218470481258 := by decide
theorem cert_e2422377459050 : check e2422377459050 [[],[]] .smaller = true := by decide
def e2422377459114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422377459114 : Closed e2422377459114 ∧ code e2422377459114 = 11218470481322 := by decide
theorem cert_e2422377459114 : check e2422377459114 [[],[]] .smaller = true := by decide
def e2422377459370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422377459370 : Closed e2422377459370 ∧ code e2422377459370 = 11218470481578 := by decide
theorem cert_e2422377459370 : check e2422377459370 [[],[]] .smaller = true := by decide
def e2422377459798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 1))))))))
theorem wire_e2422377459798 : Closed e2422377459798 ∧ code e2422377459798 = 11218470482006 := by decide
theorem cert_e2422377459798 : check e2422377459798 [[],[]] .smaller = true := by decide
def e2422377459802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1)) (.var 0))))))))
theorem wire_e2422377459802 : Closed e2422377459802 ∧ code e2422377459802 = 11218470482010 := by decide
theorem cert_e2422377459802 : check e2422377459802 [[],[]] .smaller = true := by decide
def e2422377460062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 3))))))))
theorem wire_e2422377460062 : Closed e2422377460062 ∧ code e2422377460062 = 11218470482270 := by decide
theorem cert_e2422377460062 : check e2422377460062 [[],[]] .three = true := by decide
def e2422377460078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 2))))))))
theorem wire_e2422377460078 : Closed e2422377460078 ∧ code e2422377460078 = 11218470482286 := by decide
theorem cert_e2422377460078 : check e2422377460078 [[],[]] .smaller = true := by decide
def e2422377460086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 1))))))))
theorem wire_e2422377460086 : Closed e2422377460086 ∧ code e2422377460086 = 11218470482294 := by decide
theorem cert_e2422377460086 : check e2422377460086 [[],[]] .smaller = true := by decide
def e2422377460090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 0))))))))
theorem wire_e2422377460090 : Closed e2422377460090 ∧ code e2422377460090 = 11218470482298 := by decide
theorem cert_e2422377460090 : check e2422377460090 [[],[]] .three = true := by decide
def e2422377460150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e2422377460150 : Closed e2422377460150 ∧ code e2422377460150 = 11218470482358 := by decide
theorem cert_e2422377460150 : check e2422377460150 [[],[]] .smaller = true := by decide
def e2422377460182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e2422377460182 : Closed e2422377460182 ∧ code e2422377460182 = 11218470482390 := by decide
theorem cert_e2422377460182 : check e2422377460182 [[],[]] .smaller = true := by decide
def e2422377460186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e2422377460186 : Closed e2422377460186 ∧ code e2422377460186 = 11218470482394 := by decide
theorem cert_e2422377460186 : check e2422377460186 [[],[]] .smaller = true := by decide
def e2422377460566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422377460566 : Closed e2422377460566 ∧ code e2422377460566 = 11218470482774 := by decide
theorem cert_e2422377460566 : check e2422377460566 [[],[]] .smaller = true := by decide
def e2422377460570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422377460570 : Closed e2422377460570 ∧ code e2422377460570 = 11218470482778 := by decide
theorem cert_e2422377460570 : check e2422377460570 [[],[]] .smaller = true := by decide
def e2422377460586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e2422377460586 : Closed e2422377460586 ∧ code e2422377460586 = 11218470482794 := by decide
theorem cert_e2422377460586 : check e2422377460586 [[],[]] .smaller = true := by decide
def e2422377460650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422377460650 : Closed e2422377460650 ∧ code e2422377460650 = 11218470482858 := by decide
theorem cert_e2422377460650 : check e2422377460650 [[],[]] .smaller = true := by decide
def e2422377460758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422377460758 : Closed e2422377460758 ∧ code e2422377460758 = 11218470482966 := by decide
theorem cert_e2422377460758 : check e2422377460758 [[],[]] .smaller = true := by decide
def e2422377460830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422377460830 : Closed e2422377460830 ∧ code e2422377460830 = 11218470483038 := by decide
theorem cert_e2422377460830 : check e2422377460830 [[],[]] .three = true := by decide
def e2422377460854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422377460854 : Closed e2422377460854 ∧ code e2422377460854 = 11218470483062 := by decide
theorem cert_e2422377460854 : check e2422377460854 [[],[]] .smaller = true := by decide
def e2422377460950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422377460950 : Closed e2422377460950 ∧ code e2422377460950 = 11218470483158 := by decide
theorem cert_e2422377460950 : check e2422377460950 [[],[]] .smaller = true := by decide
def e2422377460954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422377460954 : Closed e2422377460954 ∧ code e2422377460954 = 11218470483162 := by decide
theorem cert_e2422377460954 : check e2422377460954 [[],[]] .smaller = true := by decide
def e2422377460970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422377460970 : Closed e2422377460970 ∧ code e2422377460970 = 11218470483178 := by decide
theorem cert_e2422377460970 : check e2422377460970 [[],[]] .smaller = true := by decide
def e2422377461046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377461046 : Closed e2422377461046 ∧ code e2422377461046 = 11218470483254 := by decide
theorem cert_e2422377461046 : check e2422377461046 [[],[]] .smaller = true := by decide
def e2422377461050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377461050 : Closed e2422377461050 ∧ code e2422377461050 = 11218470483258 := by decide
theorem cert_e2422377461050 : check e2422377461050 [[],[]] .smaller = true := by decide
def e2422377461122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422377461122 : Closed e2422377461122 ∧ code e2422377461122 = 11218470483330 := by decide
theorem cert_e2422377461122 : check e2422377461122 [[],[]] .smaller = true := by decide
def e2422377461134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422377461134 : Closed e2422377461134 ∧ code e2422377461134 = 11218470483342 := by decide
theorem cert_e2422377461134 : check e2422377461134 [[],[]] .smaller = true := by decide
def e2422377461146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377461146 : Closed e2422377461146 ∧ code e2422377461146 = 11218470483354 := by decide
theorem cert_e2422377461146 : check e2422377461146 [[],[]] .smaller = true := by decide
def e2422377461214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e2422377461214 : Closed e2422377461214 ∧ code e2422377461214 = 11218470483422 := by decide
theorem cert_e2422377461214 : check e2422377461214 [[],[]] .three = true := by decide
def e2422377461218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422377461218 : Closed e2422377461218 ∧ code e2422377461218 = 11218470483426 := by decide
theorem cert_e2422377461218 : check e2422377461218 [[],[]] .three = true := by decide
def e2422377461230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e2422377461230 : Closed e2422377461230 ∧ code e2422377461230 = 11218470483438 := by decide
theorem cert_e2422377461230 : check e2422377461230 [[],[]] .three = true := by decide
def e2422377461258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377461258 : Closed e2422377461258 ∧ code e2422377461258 = 11218470483466 := by decide
theorem cert_e2422377461258 : check e2422377461258 [[],[]] .smaller = true := by decide
def e2422377461294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422377461294 : Closed e2422377461294 ∧ code e2422377461294 = 11218470483502 := by decide
theorem cert_e2422377461294 : check e2422377461294 [[],[]] .smaller = true := by decide
def e2422377461302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422377461302 : Closed e2422377461302 ∧ code e2422377461302 = 11218470483510 := by decide
theorem cert_e2422377461302 : check e2422377461302 [[],[]] .smaller = true := by decide
def e2422377461306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422377461306 : Closed e2422377461306 ∧ code e2422377461306 = 11218470483514 := by decide
theorem cert_e2422377461306 : check e2422377461306 [[],[]] .smaller = true := by decide
def e2422377461354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422377461354 : Closed e2422377461354 ∧ code e2422377461354 = 11218470483562 := by decide
theorem cert_e2422377461354 : check e2422377461354 [[],[]] .smaller = true := by decide
def e2422377461378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422377461378 : Closed e2422377461378 ∧ code e2422377461378 = 11218470483586 := by decide
theorem cert_e2422377461378 : check e2422377461378 [[],[]] .smaller = true := by decide
def e2422377461390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422377461390 : Closed e2422377461390 ∧ code e2422377461390 = 11218470483598 := by decide
theorem cert_e2422377461390 : check e2422377461390 [[],[]] .smaller = true := by decide
def e2422377461402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377461402 : Closed e2422377461402 ∧ code e2422377461402 = 11218470483610 := by decide
theorem cert_e2422377461402 : check e2422377461402 [[],[]] .smaller = true := by decide
def e2422377461446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422377461446 : Closed e2422377461446 ∧ code e2422377461446 = 11218470483654 := by decide
theorem cert_e2422377461446 : check e2422377461446 [[],[]] .smaller = true := by decide
def e2422377461470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e2422377461470 : Closed e2422377461470 ∧ code e2422377461470 = 11218470483678 := by decide
theorem cert_e2422377461470 : check e2422377461470 [[],[]] .three = true := by decide
def e2422377461474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422377461474 : Closed e2422377461474 ∧ code e2422377461474 = 11218470483682 := by decide
theorem cert_e2422377461474 : check e2422377461474 [[],[]] .smaller = true := by decide
def e2422377461486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e2422377461486 : Closed e2422377461486 ∧ code e2422377461486 = 11218470483694 := by decide
theorem cert_e2422377461486 : check e2422377461486 [[],[]] .smaller = true := by decide
def e2422377461494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e2422377461494 : Closed e2422377461494 ∧ code e2422377461494 = 11218470483702 := by decide
theorem cert_e2422377461494 : check e2422377461494 [[],[]] .three = true := by decide
def e2422377461526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422377461526 : Closed e2422377461526 ∧ code e2422377461526 = 11218470483734 := by decide
theorem cert_e2422377461526 : check e2422377461526 [[],[]] .smaller = true := by decide
def e2422377461598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e2422377461598 : Closed e2422377461598 ∧ code e2422377461598 = 11218470483806 := by decide
theorem cert_e2422377461598 : check e2422377461598 [[],[]] .three = true := by decide
def e2422377461602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422377461602 : Closed e2422377461602 ∧ code e2422377461602 = 11218470483810 := by decide
theorem cert_e2422377461602 : check e2422377461602 [[],[]] .smaller = true := by decide
def e2422377461614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e2422377461614 : Closed e2422377461614 ∧ code e2422377461614 = 11218470483822 := by decide
theorem cert_e2422377461614 : check e2422377461614 [[],[]] .smaller = true := by decide
def e2422377461622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e2422377461622 : Closed e2422377461622 ∧ code e2422377461622 = 11218470483830 := by decide
theorem cert_e2422377461622 : check e2422377461622 [[],[]] .smaller = true := by decide
def e2422377461626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e2422377461626 : Closed e2422377461626 ∧ code e2422377461626 = 11218470483834 := by decide
theorem cert_e2422377461626 : check e2422377461626 [[],[]] .three = true := by decide
def e2422377461642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422377461642 : Closed e2422377461642 ∧ code e2422377461642 = 11218470483850 := by decide
theorem cert_e2422377461642 : check e2422377461642 [[],[]] .three = true := by decide
def e2422377461666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422377461666 : Closed e2422377461666 ∧ code e2422377461666 = 11218470483874 := by decide
theorem cert_e2422377461666 : check e2422377461666 [[],[]] .three = true := by decide
def e2422377461678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e2422377461678 : Closed e2422377461678 ∧ code e2422377461678 = 11218470483886 := by decide
theorem cert_e2422377461678 : check e2422377461678 [[],[]] .three = true := by decide
def e2422377461686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e2422377461686 : Closed e2422377461686 ∧ code e2422377461686 = 11218470483894 := by decide
theorem cert_e2422377461686 : check e2422377461686 [[],[]] .three = true := by decide
def e2422377461690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e2422377461690 : Closed e2422377461690 ∧ code e2422377461690 = 11218470483898 := by decide
theorem cert_e2422377461690 : check e2422377461690 [[],[]] .three = true := by decide
def e2422377461802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0)) (.var 0))))))))
theorem wire_e2422377461802 : Closed e2422377461802 ∧ code e2422377461802 = 11218470484010 := by decide
theorem cert_e2422377461802 : check e2422377461802 [[],[]] .smaller = true := by decide
def e2422377461934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e2422377461934 : Closed e2422377461934 ∧ code e2422377461934 = 11218470484142 := by decide
theorem cert_e2422377461934 : check e2422377461934 [[],[]] .smaller = true := by decide
def e2422377461946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e2422377461946 : Closed e2422377461946 ∧ code e2422377461946 = 11218470484154 := by decide
theorem cert_e2422377461946 : check e2422377461946 [[],[]] .smaller = true := by decide
def e2422377461974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e2422377461974 : Closed e2422377461974 ∧ code e2422377461974 = 11218470484182 := by decide
theorem cert_e2422377461974 : check e2422377461974 [[],[]] .smaller = true := by decide
def e2422377461978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e2422377461978 : Closed e2422377461978 ∧ code e2422377461978 = 11218470484186 := by decide
theorem cert_e2422377461978 : check e2422377461978 [[],[]] .smaller = true := by decide
def e2422377461994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e2422377461994 : Closed e2422377461994 ∧ code e2422377461994 = 11218470484202 := by decide
theorem cert_e2422377461994 : check e2422377461994 [[],[]] .smaller = true := by decide
def e2422377462186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422377462186 : Closed e2422377462186 ∧ code e2422377462186 = 11218470484394 := by decide
theorem cert_e2422377462186 : check e2422377462186 [[],[]] .smaller = true := by decide
def e2422377462282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422377462282 : Closed e2422377462282 ∧ code e2422377462282 = 11218470484490 := by decide
theorem cert_e2422377462282 : check e2422377462282 [[],[]] .smaller = true := by decide
def e2422377462318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422377462318 : Closed e2422377462318 ∧ code e2422377462318 = 11218470484526 := by decide
theorem cert_e2422377462318 : check e2422377462318 [[],[]] .smaller = true := by decide
def e2422377462326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422377462326 : Closed e2422377462326 ∧ code e2422377462326 = 11218470484534 := by decide
theorem cert_e2422377462326 : check e2422377462326 [[],[]] .smaller = true := by decide
def e2422377462330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422377462330 : Closed e2422377462330 ∧ code e2422377462330 = 11218470484538 := by decide
theorem cert_e2422377462330 : check e2422377462330 [[],[]] .smaller = true := by decide
def e2422377462378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422377462378 : Closed e2422377462378 ∧ code e2422377462378 = 11218470484586 := by decide
theorem cert_e2422377462378 : check e2422377462378 [[],[]] .smaller = true := by decide
def e2422377462402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422377462402 : Closed e2422377462402 ∧ code e2422377462402 = 11218470484610 := by decide
theorem cert_e2422377462402 : check e2422377462402 [[],[]] .smaller = true := by decide
def e2422377462414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422377462414 : Closed e2422377462414 ∧ code e2422377462414 = 11218470484622 := by decide
theorem cert_e2422377462414 : check e2422377462414 [[],[]] .smaller = true := by decide
def e2422377462426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377462426 : Closed e2422377462426 ∧ code e2422377462426 = 11218470484634 := by decide
theorem cert_e2422377462426 : check e2422377462426 [[],[]] .smaller = true := by decide
def e2422377462470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422377462470 : Closed e2422377462470 ∧ code e2422377462470 = 11218470484678 := by decide
theorem cert_e2422377462470 : check e2422377462470 [[],[]] .smaller = true := by decide
def e2422377462494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2422377462494 : Closed e2422377462494 ∧ code e2422377462494 = 11218470484702 := by decide
theorem cert_e2422377462494 : check e2422377462494 [[],[]] .three = true := by decide
def e2422377462498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422377462498 : Closed e2422377462498 ∧ code e2422377462498 = 11218470484706 := by decide
theorem cert_e2422377462498 : check e2422377462498 [[],[]] .smaller = true := by decide
def e2422377462510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2422377462510 : Closed e2422377462510 ∧ code e2422377462510 = 11218470484718 := by decide
theorem cert_e2422377462510 : check e2422377462510 [[],[]] .smaller = true := by decide
def e2422377462518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2422377462518 : Closed e2422377462518 ∧ code e2422377462518 = 11218470484726 := by decide
theorem cert_e2422377462518 : check e2422377462518 [[],[]] .three = true := by decide
def e2422377462554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422377462554 : Closed e2422377462554 ∧ code e2422377462554 = 11218470484762 := by decide
theorem cert_e2422377462554 : check e2422377462554 [[],[]] .smaller = true := by decide
def e2422377462598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422377462598 : Closed e2422377462598 ∧ code e2422377462598 = 11218470484806 := by decide
theorem cert_e2422377462598 : check e2422377462598 [[],[]] .smaller = true := by decide
def e2422377462622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2422377462622 : Closed e2422377462622 ∧ code e2422377462622 = 11218470484830 := by decide
theorem cert_e2422377462622 : check e2422377462622 [[],[]] .three = true := by decide
def e2422377462650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2422377462650 : Closed e2422377462650 ∧ code e2422377462650 = 11218470484858 := by decide
theorem cert_e2422377462650 : check e2422377462650 [[],[]] .three = true := by decide
def e2422377462666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422377462666 : Closed e2422377462666 ∧ code e2422377462666 = 11218470484874 := by decide
theorem cert_e2422377462666 : check e2422377462666 [[],[]] .smaller = true := by decide
def e2422377462690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422377462690 : Closed e2422377462690 ∧ code e2422377462690 = 11218470484898 := by decide
theorem cert_e2422377462690 : check e2422377462690 [[],[]] .smaller = true := by decide
def e2422377462702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2422377462702 : Closed e2422377462702 ∧ code e2422377462702 = 11218470484910 := by decide
theorem cert_e2422377462702 : check e2422377462702 [[],[]] .smaller = true := by decide
def e2422377462714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2422377462714 : Closed e2422377462714 ∧ code e2422377462714 = 11218470484922 := by decide
theorem cert_e2422377462714 : check e2422377462714 [[],[]] .smaller = true := by decide
def e2422377462742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2422377462742 : Closed e2422377462742 ∧ code e2422377462742 = 11218470484950 := by decide
theorem cert_e2422377462742 : check e2422377462742 [[],[]] .three = true := by decide
def e2422377462746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2422377462746 : Closed e2422377462746 ∧ code e2422377462746 = 11218470484954 := by decide
theorem cert_e2422377462746 : check e2422377462746 [[],[]] .three = true := by decide
def e2422377462870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e2422377462870 : Closed e2422377462870 ∧ code e2422377462870 = 11218470485078 := by decide
theorem cert_e2422377462870 : check e2422377462870 [[],[]] .smaller = true := by decide
def e2422377462874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e2422377462874 : Closed e2422377462874 ∧ code e2422377462874 = 11218470485082 := by decide
theorem cert_e2422377462874 : check e2422377462874 [[],[]] .smaller = true := by decide
def e2422377463062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422377463062 : Closed e2422377463062 ∧ code e2422377463062 = 11218470485270 := by decide
theorem cert_e2422377463062 : check e2422377463062 [[],[]] .smaller = true := by decide
def e2422377463134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2422377463134 : Closed e2422377463134 ∧ code e2422377463134 = 11218470485342 := by decide
theorem cert_e2422377463134 : check e2422377463134 [[],[]] .three = true := by decide
def e2422377463138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422377463138 : Closed e2422377463138 ∧ code e2422377463138 = 11218470485346 := by decide
theorem cert_e2422377463138 : check e2422377463138 [[],[]] .smaller = true := by decide
def e2422377463150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2422377463150 : Closed e2422377463150 ∧ code e2422377463150 = 11218470485358 := by decide
theorem cert_e2422377463150 : check e2422377463150 [[],[]] .smaller = true := by decide
def e2422377463158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2422377463158 : Closed e2422377463158 ∧ code e2422377463158 = 11218470485366 := by decide
theorem cert_e2422377463158 : check e2422377463158 [[],[]] .smaller = true := by decide
def e2422377463162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2422377463162 : Closed e2422377463162 ∧ code e2422377463162 = 11218470485370 := by decide
theorem cert_e2422377463162 : check e2422377463162 [[],[]] .three = true := by decide
def e2422377463178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422377463178 : Closed e2422377463178 ∧ code e2422377463178 = 11218470485386 := by decide
theorem cert_e2422377463178 : check e2422377463178 [[],[]] .smaller = true := by decide
def e2422377463202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422377463202 : Closed e2422377463202 ∧ code e2422377463202 = 11218470485410 := by decide
theorem cert_e2422377463202 : check e2422377463202 [[],[]] .smaller = true := by decide
def e2422377463214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2422377463214 : Closed e2422377463214 ∧ code e2422377463214 = 11218470485422 := by decide
theorem cert_e2422377463214 : check e2422377463214 [[],[]] .smaller = true := by decide
def e2422377463226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2422377463226 : Closed e2422377463226 ∧ code e2422377463226 = 11218470485434 := by decide
theorem cert_e2422377463226 : check e2422377463226 [[],[]] .smaller = true := by decide
def e2422377463254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2422377463254 : Closed e2422377463254 ∧ code e2422377463254 = 11218470485462 := by decide
theorem cert_e2422377463254 : check e2422377463254 [[],[]] .smaller = true := by decide
def e2422377463258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2422377463258 : Closed e2422377463258 ∧ code e2422377463258 = 11218470485466 := by decide
theorem cert_e2422377463258 : check e2422377463258 [[],[]] .smaller = true := by decide
def e2422377463274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2422377463274 : Closed e2422377463274 ∧ code e2422377463274 = 11218470485482 := by decide
theorem cert_e2422377463274 : check e2422377463274 [[],[]] .three = true := by decide
def e2422377463338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.lam (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e2422377463338 : Closed e2422377463338 ∧ code e2422377463338 = 11218470485546 := by decide
theorem cert_e2422377463338 : check e2422377463338 [[],[]] .three = true := by decide
def e2422377463434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422377463434 : Closed e2422377463434 ∧ code e2422377463434 = 11218470485642 := by decide
theorem cert_e2422377463434 : check e2422377463434 [[],[]] .three = true := by decide
def e2422377463458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422377463458 : Closed e2422377463458 ∧ code e2422377463458 = 11218470485666 := by decide
theorem cert_e2422377463458 : check e2422377463458 [[],[]] .three = true := by decide
def e2422377463470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422377463470 : Closed e2422377463470 ∧ code e2422377463470 = 11218470485678 := by decide
theorem cert_e2422377463470 : check e2422377463470 [[],[]] .three = true := by decide
def e2422377463478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2422377463478 : Closed e2422377463478 ∧ code e2422377463478 = 11218470485686 := by decide
theorem cert_e2422377463478 : check e2422377463478 [[],[]] .three = true := by decide
def e2422377463482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422377463482 : Closed e2422377463482 ∧ code e2422377463482 = 11218470485690 := by decide
theorem cert_e2422377463482 : check e2422377463482 [[],[]] .three = true := by decide
def e2422377463510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2422377463510 : Closed e2422377463510 ∧ code e2422377463510 = 11218470485718 := by decide
theorem cert_e2422377463510 : check e2422377463510 [[],[]] .three = true := by decide
def e2422377463514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2422377463514 : Closed e2422377463514 ∧ code e2422377463514 = 11218470485722 := by decide
theorem cert_e2422377463514 : check e2422377463514 [[],[]] .three = true := by decide
def e2422377463530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422377463530 : Closed e2422377463530 ∧ code e2422377463530 = 11218470485738 := by decide
theorem cert_e2422377463530 : check e2422377463530 [[],[]] .three = true := by decide
def e2422377464022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 1))))))))
theorem wire_e2422377464022 : Closed e2422377464022 ∧ code e2422377464022 = 11218470486230 := by decide
theorem cert_e2422377464022 : check e2422377464022 [[],[]] .smaller = true := by decide
def e2422377464118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377464118 : Closed e2422377464118 ∧ code e2422377464118 = 11218470486326 := by decide
theorem cert_e2422377464118 : check e2422377464118 [[],[]] .smaller = true := by decide
def e2422377464122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377464122 : Closed e2422377464122 ∧ code e2422377464122 = 11218470486330 := by decide
theorem cert_e2422377464122 : check e2422377464122 [[],[]] .smaller = true := by decide
def e2422377464286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 3))))))))
theorem wire_e2422377464286 : Closed e2422377464286 ∧ code e2422377464286 = 11218470486494 := by decide
theorem cert_e2422377464286 : check e2422377464286 [[],[]] .three = true := by decide
def e2422377464302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2))))))))
theorem wire_e2422377464302 : Closed e2422377464302 ∧ code e2422377464302 = 11218470486510 := by decide
theorem cert_e2422377464302 : check e2422377464302 [[],[]] .smaller = true := by decide
def e2422377464310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 1))))))))
theorem wire_e2422377464310 : Closed e2422377464310 ∧ code e2422377464310 = 11218470486518 := by decide
theorem cert_e2422377464310 : check e2422377464310 [[],[]] .smaller = true := by decide
def e2422377464314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.lam (.var 5)))) (.var 0))))))))
theorem wire_e2422377464314 : Closed e2422377464314 ∧ code e2422377464314 = 11218470486522 := by decide
theorem cert_e2422377464314 : check e2422377464314 [[],[]] .three = true := by decide
def e2422377464670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e2422377464670 : Closed e2422377464670 ∧ code e2422377464670 = 11218470486878 := by decide
theorem cert_e2422377464670 : check e2422377464670 [[],[]] .three = true := by decide
def e2422377464694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e2422377464694 : Closed e2422377464694 ∧ code e2422377464694 = 11218470486902 := by decide
theorem cert_e2422377464694 : check e2422377464694 [[],[]] .smaller = true := by decide
def e2422377464758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e2422377464758 : Closed e2422377464758 ∧ code e2422377464758 = 11218470486966 := by decide
theorem cert_e2422377464758 : check e2422377464758 [[],[]] .smaller = true := by decide
def e2422377464762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e2422377464762 : Closed e2422377464762 ∧ code e2422377464762 = 11218470486970 := by decide
theorem cert_e2422377464762 : check e2422377464762 [[],[]] .smaller = true := by decide
def e2422377464790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e2422377464790 : Closed e2422377464790 ∧ code e2422377464790 = 11218470486998 := by decide
theorem cert_e2422377464790 : check e2422377464790 [[],[]] .smaller = true := by decide
def e2422377464794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e2422377464794 : Closed e2422377464794 ∧ code e2422377464794 = 11218470487002 := by decide
theorem cert_e2422377464794 : check e2422377464794 [[],[]] .smaller = true := by decide
def e2422377465054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422377465054 : Closed e2422377465054 ∧ code e2422377465054 = 11218470487262 := by decide
theorem cert_e2422377465054 : check e2422377465054 [[],[]] .three = true := by decide
def e2422377465070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422377465070 : Closed e2422377465070 ∧ code e2422377465070 = 11218470487278 := by decide
theorem cert_e2422377465070 : check e2422377465070 [[],[]] .smaller = true := by decide
def e2422377465078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422377465078 : Closed e2422377465078 ∧ code e2422377465078 = 11218470487286 := by decide
theorem cert_e2422377465078 : check e2422377465078 [[],[]] .smaller = true := by decide
def e2422377465082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422377465082 : Closed e2422377465082 ∧ code e2422377465082 = 11218470487290 := by decide
theorem cert_e2422377465082 : check e2422377465082 [[],[]] .three = true := by decide
def e2422377465406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 4)))))))))
theorem wire_e2422377465406 : Closed e2422377465406 ∧ code e2422377465406 = 11218470487614 := by decide
theorem cert_e2422377465406 : check e2422377465406 [[],[]] .three = true := by decide
def e2422377465462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422377465462 : Closed e2422377465462 ∧ code e2422377465462 = 11218470487670 := by decide
theorem cert_e2422377465462 : check e2422377465462 [[],[]] .smaller = true := by decide
def e2422377465630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.lam (.var 3)))))))))
theorem wire_e2422377465630 : Closed e2422377465630 ∧ code e2422377465630 = 11218470487838 := by decide
theorem cert_e2422377465630 : check e2422377465630 [[],[]] .smaller = true := by decide
def e2422377465654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377465654 : Closed e2422377465654 ∧ code e2422377465654 = 11218470487862 := by decide
theorem cert_e2422377465654 : check e2422377465654 [[],[]] .smaller = true := by decide
def e2422377465658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377465658 : Closed e2422377465658 ∧ code e2422377465658 = 11218470487866 := by decide
theorem cert_e2422377465658 : check e2422377465658 [[],[]] .smaller = true := by decide
def e2422377465742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2)))))))))
theorem wire_e2422377465742 : Closed e2422377465742 ∧ code e2422377465742 = 11218470487950 := by decide
theorem cert_e2422377465742 : check e2422377465742 [[],[]] .smaller = true := by decide
def e2422377465798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 1)))))))))
theorem wire_e2422377465798 : Closed e2422377465798 ∧ code e2422377465798 = 11218470488006 := by decide
theorem cert_e2422377465798 : check e2422377465798 [[],[]] .three = true := by decide
def e2422377465822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 4))) (.var 3))))))))
theorem wire_e2422377465822 : Closed e2422377465822 ∧ code e2422377465822 = 11218470488030 := by decide
theorem cert_e2422377465822 : check e2422377465822 [[],[]] .three = true := by decide
def e2422377466710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422377466710 : Closed e2422377466710 ∧ code e2422377466710 = 11218470488918 := by decide
theorem cert_e2422377466710 : check e2422377466710 [[],[]] .smaller = true := by decide
def e2422377466714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422377466714 : Closed e2422377466714 ∧ code e2422377466714 = 11218470488922 := by decide
theorem cert_e2422377466714 : check e2422377466714 [[],[]] .smaller = true := by decide
def e2422377466730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422377466730 : Closed e2422377466730 ∧ code e2422377466730 = 11218470488938 := by decide
theorem cert_e2422377466730 : check e2422377466730 [[],[]] .smaller = true := by decide
def e2422377466794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422377466794 : Closed e2422377466794 ∧ code e2422377466794 = 11218470489002 := by decide
theorem cert_e2422377466794 : check e2422377466794 [[],[]] .smaller = true := by decide
def e2422377466902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1))))))))
theorem wire_e2422377466902 : Closed e2422377466902 ∧ code e2422377466902 = 11218470489110 := by decide
theorem cert_e2422377466902 : check e2422377466902 [[],[]] .smaller = true := by decide
def e2422377466974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e2422377466974 : Closed e2422377466974 ∧ code e2422377466974 = 11218470489182 := by decide
theorem cert_e2422377466974 : check e2422377466974 [[],[]] .three = true := by decide
def e2422377466998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e2422377466998 : Closed e2422377466998 ∧ code e2422377466998 = 11218470489206 := by decide
theorem cert_e2422377466998 : check e2422377466998 [[],[]] .smaller = true := by decide
def e2422377467094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422377467094 : Closed e2422377467094 ∧ code e2422377467094 = 11218470489302 := by decide
theorem cert_e2422377467094 : check e2422377467094 [[],[]] .smaller = true := by decide
def e2422377467098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422377467098 : Closed e2422377467098 ∧ code e2422377467098 = 11218470489306 := by decide
theorem cert_e2422377467098 : check e2422377467098 [[],[]] .smaller = true := by decide
def e2422377467114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422377467114 : Closed e2422377467114 ∧ code e2422377467114 = 11218470489322 := by decide
theorem cert_e2422377467114 : check e2422377467114 [[],[]] .smaller = true := by decide
def e2422377467190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422377467190 : Closed e2422377467190 ∧ code e2422377467190 = 11218470489398 := by decide
theorem cert_e2422377467190 : check e2422377467190 [[],[]] .smaller = true := by decide
def e2422377467194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422377467194 : Closed e2422377467194 ∧ code e2422377467194 = 11218470489402 := by decide
theorem cert_e2422377467194 : check e2422377467194 [[],[]] .smaller = true := by decide
def e2422377467266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422377467266 : Closed e2422377467266 ∧ code e2422377467266 = 11218470489474 := by decide
theorem cert_e2422377467266 : check e2422377467266 [[],[]] .smaller = true := by decide
def e2422377467278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e2422377467278 : Closed e2422377467278 ∧ code e2422377467278 = 11218470489486 := by decide
theorem cert_e2422377467278 : check e2422377467278 [[],[]] .smaller = true := by decide
def e2422377467290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422377467290 : Closed e2422377467290 ∧ code e2422377467290 = 11218470489498 := by decide
theorem cert_e2422377467290 : check e2422377467290 [[],[]] .smaller = true := by decide
def e2422377467358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e2422377467358 : Closed e2422377467358 ∧ code e2422377467358 = 11218470489566 := by decide
theorem cert_e2422377467358 : check e2422377467358 [[],[]] .three = true := by decide
def e2422377467362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e2422377467362 : Closed e2422377467362 ∧ code e2422377467362 = 11218470489570 := by decide
theorem cert_e2422377467362 : check e2422377467362 [[],[]] .three = true := by decide
def e2422377467374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e2422377467374 : Closed e2422377467374 ∧ code e2422377467374 = 11218470489582 := by decide
theorem cert_e2422377467374 : check e2422377467374 [[],[]] .three = true := by decide
def e2422377467402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422377467402 : Closed e2422377467402 ∧ code e2422377467402 = 11218470489610 := by decide
theorem cert_e2422377467402 : check e2422377467402 [[],[]] .smaller = true := by decide
def e2422377467438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422377467438 : Closed e2422377467438 ∧ code e2422377467438 = 11218470489646 := by decide
theorem cert_e2422377467438 : check e2422377467438 [[],[]] .smaller = true := by decide
def e2422377467446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422377467446 : Closed e2422377467446 ∧ code e2422377467446 = 11218470489654 := by decide
theorem cert_e2422377467446 : check e2422377467446 [[],[]] .smaller = true := by decide
def e2422377467450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422377467450 : Closed e2422377467450 ∧ code e2422377467450 = 11218470489658 := by decide
theorem cert_e2422377467450 : check e2422377467450 [[],[]] .smaller = true := by decide
def e2422377467498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422377467498 : Closed e2422377467498 ∧ code e2422377467498 = 11218470489706 := by decide
theorem cert_e2422377467498 : check e2422377467498 [[],[]] .smaller = true := by decide
end Blc.Floor43
