import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e605806421790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))))
theorem wire_e605806421790 : Closed e605806421790 ∧ code e605806421790 = 9401899443998 := by decide
theorem cert_e605806421790 : check e605806421790 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806421902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))))
theorem wire_e605806421902 : Closed e605806421902 ∧ code e605806421902 = 9401899444110 := by decide
theorem cert_e605806421902 : check e605806421902 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806424862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e605806424862 : Closed e605806424862 ∧ code e605806424862 = 9401899447070 := by decide
theorem cert_e605806424862 : check e605806424862 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806425030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e605806425030 : Closed e605806425030 ∧ code e605806425030 = 9401899447238 := by decide
theorem cert_e605806425030 : check e605806425030 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806426510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))))
theorem wire_e605806426510 : Closed e605806426510 ∧ code e605806426510 = 9401899448718 := by decide
theorem cert_e605806426510 : check e605806426510 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605806426566 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))))
theorem wire_e605806426566 : Closed e605806426566 ∧ code e605806426566 = 9401899448774 := by decide
theorem cert_e605806426566 : check e605806426566 [[.under],[.under],[.under]] .sourceHead = true := by decide
def e605825358558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e605825358558 : Closed e605825358558 ∧ code e605825358558 = 9401918380766 := by decide
theorem cert_e605825358558 : check e605825358558 [[.under],[.under]] .chain = true := by decide
def e605825358582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e605825358582 : Closed e605825358582 ∧ code e605825358582 = 9401918380790 := by decide
theorem cert_e605825358582 : check e605825358582 [[.under],[.under]] .chain = true := by decide
def e605825358686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e605825358686 : Closed e605825358686 ∧ code e605825358686 = 9401918380894 := by decide
theorem cert_e605825358686 : check e605825358686 [[.under],[.under]] .chain = true := by decide
def e605825358702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e605825358702 : Closed e605825358702 ∧ code e605825358702 = 9401918380910 := by decide
theorem cert_e605825358702 : check e605825358702 [[.under],[.under]] .smaller = true := by decide
def e605825358710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e605825358710 : Closed e605825358710 ∧ code e605825358710 = 9401918380918 := by decide
theorem cert_e605825358710 : check e605825358710 [[.under],[.under]] .smaller = true := by decide
def e605825358714 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e605825358714 : Closed e605825358714 ∧ code e605825358714 = 9401918380922 := by decide
theorem cert_e605825358714 : check e605825358714 [[.under],[.under]] .chain = true := by decide
def e605825358774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e605825358774 : Closed e605825358774 ∧ code e605825358774 = 9401918380982 := by decide
theorem cert_e605825358774 : check e605825358774 [[.under],[.under]] .smaller = true := by decide
def e605825358806 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e605825358806 : Closed e605825358806 ∧ code e605825358806 = 9401918381014 := by decide
theorem cert_e605825358806 : check e605825358806 [[.under],[.under]] .chain = true := by decide
def e605825358810 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e605825358810 : Closed e605825358810 ∧ code e605825358810 = 9401918381018 := by decide
theorem cert_e605825358810 : check e605825358810 [[.under],[.under]] .chain = true := by decide
def e605825359198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e605825359198 : Closed e605825359198 ∧ code e605825359198 = 9401918381406 := by decide
theorem cert_e605825359198 : check e605825359198 [[.under],[.under]] .chain = true := by decide
def e605825359214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e605825359214 : Closed e605825359214 ∧ code e605825359214 = 9401918381422 := by decide
theorem cert_e605825359214 : check e605825359214 [[.under],[.under]] .smaller = true := by decide
def e605825359222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e605825359222 : Closed e605825359222 ∧ code e605825359222 = 9401918381430 := by decide
theorem cert_e605825359222 : check e605825359222 [[.under],[.under]] .smaller = true := by decide
def e605825359226 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e605825359226 : Closed e605825359226 ∧ code e605825359226 = 9401918381434 := by decide
theorem cert_e605825359226 : check e605825359226 [[.under],[.under]] .chain = true := by decide
def e605825359278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e605825359278 : Closed e605825359278 ∧ code e605825359278 = 9401918381486 := by decide
theorem cert_e605825359278 : check e605825359278 [[.under],[.under]] .smaller = true := by decide
def e605825359290 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e605825359290 : Closed e605825359290 ∧ code e605825359290 = 9401918381498 := by decide
theorem cert_e605825359290 : check e605825359290 [[.under],[.under]] .smaller = true := by decide
def e605825359318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e605825359318 : Closed e605825359318 ∧ code e605825359318 = 9401918381526 := by decide
theorem cert_e605825359318 : check e605825359318 [[.under],[.under]] .smaller = true := by decide
def e605825359322 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e605825359322 : Closed e605825359322 ∧ code e605825359322 = 9401918381530 := by decide
theorem cert_e605825359322 : check e605825359322 [[.under],[.under]] .smaller = true := by decide
def e605825359338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e605825359338 : Closed e605825359338 ∧ code e605825359338 = 9401918381546 := by decide
theorem cert_e605825359338 : check e605825359338 [[.under],[.under]] .chain = true := by decide
def e605825359542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e605825359542 : Closed e605825359542 ∧ code e605825359542 = 9401918381750 := by decide
theorem cert_e605825359542 : check e605825359542 [[.under],[.under]] .smaller = true := by decide
def e605825359574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e605825359574 : Closed e605825359574 ∧ code e605825359574 = 9401918381782 := by decide
theorem cert_e605825359574 : check e605825359574 [[.under],[.under]] .smaller = true := by decide
def e605825359578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e605825359578 : Closed e605825359578 ∧ code e605825359578 = 9401918381786 := by decide
theorem cert_e605825359578 : check e605825359578 [[.under],[.under]] .smaller = true := by decide
def e605825359702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e605825359702 : Closed e605825359702 ∧ code e605825359702 = 9401918381910 := by decide
theorem cert_e605825359702 : check e605825359702 [[.under],[.under]] .chain = true := by decide
def e605825359706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e605825359706 : Closed e605825359706 ∧ code e605825359706 = 9401918381914 := by decide
theorem cert_e605825359706 : check e605825359706 [[.under],[.under]] .chain = true := by decide
def e605825359722 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e605825359722 : Closed e605825359722 ∧ code e605825359722 = 9401918381930 := by decide
theorem cert_e605825359722 : check e605825359722 [[.under],[.under]] .chain = true := by decide
def e605825361630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e605825361630 : Closed e605825361630 ∧ code e605825361630 = 9401918383838 := by decide
theorem cert_e605825361630 : check e605825361630 [[.under],[.under]] .chain = true := by decide
def e605825361654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e605825361654 : Closed e605825361654 ∧ code e605825361654 = 9401918383862 := by decide
theorem cert_e605825361654 : check e605825361654 [[.under],[.under]] .chain = true := by decide
def e605825361758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e605825361758 : Closed e605825361758 ∧ code e605825361758 = 9401918383966 := by decide
theorem cert_e605825361758 : check e605825361758 [[.under],[.under]] .chain = true := by decide
def e605825361774 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e605825361774 : Closed e605825361774 ∧ code e605825361774 = 9401918383982 := by decide
theorem cert_e605825361774 : check e605825361774 [[.under],[.under]] .smaller = true := by decide
def e605825361782 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e605825361782 : Closed e605825361782 ∧ code e605825361782 = 9401918383990 := by decide
theorem cert_e605825361782 : check e605825361782 [[.under],[.under]] .smaller = true := by decide
def e605825361786 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e605825361786 : Closed e605825361786 ∧ code e605825361786 = 9401918383994 := by decide
theorem cert_e605825361786 : check e605825361786 [[.under],[.under]] .chain = true := by decide
def e605825361846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e605825361846 : Closed e605825361846 ∧ code e605825361846 = 9401918384054 := by decide
theorem cert_e605825361846 : check e605825361846 [[.under],[.under]] .smaller = true := by decide
def e605825361878 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e605825361878 : Closed e605825361878 ∧ code e605825361878 = 9401918384086 := by decide
theorem cert_e605825361878 : check e605825361878 [[.under],[.under]] .chain = true := by decide
def e605825361882 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e605825361882 : Closed e605825361882 ∧ code e605825361882 = 9401918384090 := by decide
theorem cert_e605825361882 : check e605825361882 [[.under],[.under]] .chain = true := by decide
def e605825362398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e605825362398 : Closed e605825362398 ∧ code e605825362398 = 9401918384606 := by decide
theorem cert_e605825362398 : check e605825362398 [[.under],[.under]] .chain = true := by decide
def e605825362422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e605825362422 : Closed e605825362422 ∧ code e605825362422 = 9401918384630 := by decide
theorem cert_e605825362422 : check e605825362422 [[.under],[.under]] .chain = true := by decide
def e605825363166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e605825363166 : Closed e605825363166 ∧ code e605825363166 = 9401918385374 := by decide
theorem cert_e605825363166 : check e605825363166 [[.under],[.under]] .chain = true := by decide
def e605825363182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605825363182 : Closed e605825363182 ∧ code e605825363182 = 9401918385390 := by decide
theorem cert_e605825363182 : check e605825363182 [[.under],[.under]] .smaller = true := by decide
def e605825363190 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605825363190 : Closed e605825363190 ∧ code e605825363190 = 9401918385398 := by decide
theorem cert_e605825363190 : check e605825363190 [[.under],[.under]] .smaller = true := by decide
def e605825363194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e605825363194 : Closed e605825363194 ∧ code e605825363194 = 9401918385402 := by decide
theorem cert_e605825363194 : check e605825363194 [[.under],[.under]] .chain = true := by decide
def e605825363574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e605825363574 : Closed e605825363574 ∧ code e605825363574 = 9401918385782 := by decide
theorem cert_e605825363574 : check e605825363574 [[.under],[.under]] .smaller = true := by decide
def e605825363766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605825363766 : Closed e605825363766 ∧ code e605825363766 = 9401918385974 := by decide
theorem cert_e605825363766 : check e605825363766 [[.under],[.under]] .chain = true := by decide
def e605825363770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605825363770 : Closed e605825363770 ∧ code e605825363770 = 9401918385978 := by decide
theorem cert_e605825363770 : check e605825363770 [[.under],[.under]] .chain = true := by decide
def e605825364830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e605825364830 : Closed e605825364830 ∧ code e605825364830 = 9401918387038 := by decide
theorem cert_e605825364830 : check e605825364830 [[.under],[.under]] .chain = true := by decide
def e605825364846 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e605825364846 : Closed e605825364846 ∧ code e605825364846 = 9401918387054 := by decide
theorem cert_e605825364846 : check e605825364846 [[.under],[.under]] .smaller = true := by decide
def e605825364854 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e605825364854 : Closed e605825364854 ∧ code e605825364854 = 9401918387062 := by decide
theorem cert_e605825364854 : check e605825364854 [[.under],[.under]] .smaller = true := by decide
def e605825364858 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e605825364858 : Closed e605825364858 ∧ code e605825364858 = 9401918387066 := by decide
theorem cert_e605825364858 : check e605825364858 [[.under],[.under]] .chain = true := by decide
def e605825364910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e605825364910 : Closed e605825364910 ∧ code e605825364910 = 9401918387118 := by decide
theorem cert_e605825364910 : check e605825364910 [[.under],[.under]] .smaller = true := by decide
def e605825364922 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e605825364922 : Closed e605825364922 ∧ code e605825364922 = 9401918387130 := by decide
theorem cert_e605825364922 : check e605825364922 [[.under],[.under]] .smaller = true := by decide
def e605825364950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e605825364950 : Closed e605825364950 ∧ code e605825364950 = 9401918387158 := by decide
theorem cert_e605825364950 : check e605825364950 [[.under],[.under]] .smaller = true := by decide
def e605825364954 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e605825364954 : Closed e605825364954 ∧ code e605825364954 = 9401918387162 := by decide
theorem cert_e605825364954 : check e605825364954 [[.under],[.under]] .smaller = true := by decide
def e605825364970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e605825364970 : Closed e605825364970 ∧ code e605825364970 = 9401918387178 := by decide
theorem cert_e605825364970 : check e605825364970 [[.under],[.under]] .chain = true := by decide
def e605825365214 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e605825365214 : Closed e605825365214 ∧ code e605825365214 = 9401918387422 := by decide
theorem cert_e605825365214 : check e605825365214 [[.under],[.under]] .chain = true := by decide
def e605825365230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e605825365230 : Closed e605825365230 ∧ code e605825365230 = 9401918387438 := by decide
theorem cert_e605825365230 : check e605825365230 [[.under],[.under]] .smaller = true := by decide
def e605825365238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e605825365238 : Closed e605825365238 ∧ code e605825365238 = 9401918387446 := by decide
theorem cert_e605825365238 : check e605825365238 [[.under],[.under]] .smaller = true := by decide
def e605825365242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e605825365242 : Closed e605825365242 ∧ code e605825365242 = 9401918387450 := by decide
theorem cert_e605825365242 : check e605825365242 [[.under],[.under]] .chain = true := by decide
def e605825365614 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e605825365614 : Closed e605825365614 ∧ code e605825365614 = 9401918387822 := by decide
theorem cert_e605825365614 : check e605825365614 [[.under],[.under]] .smaller = true := by decide
def e605825365626 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e605825365626 : Closed e605825365626 ∧ code e605825365626 = 9401918387834 := by decide
theorem cert_e605825365626 : check e605825365626 [[.under],[.under]] .smaller = true := by decide
def e605825365814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605825365814 : Closed e605825365814 ∧ code e605825365814 = 9401918388022 := by decide
theorem cert_e605825365814 : check e605825365814 [[.under],[.under]] .smaller = true := by decide
def e605825365818 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605825365818 : Closed e605825365818 ∧ code e605825365818 = 9401918388026 := by decide
theorem cert_e605825365818 : check e605825365818 [[.under],[.under]] .smaller = true := by decide
def e605825365914 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605825365914 : Closed e605825365914 ∧ code e605825365914 = 9401918388122 := by decide
theorem cert_e605825365914 : check e605825365914 [[.under],[.under]] .chain = true := by decide
def e605825366454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e605825366454 : Closed e605825366454 ∧ code e605825366454 = 9401918388662 := by decide
theorem cert_e605825366454 : check e605825366454 [[.under],[.under]] .smaller = true := by decide
def e605825366486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e605825366486 : Closed e605825366486 ∧ code e605825366486 = 9401918388694 := by decide
theorem cert_e605825366486 : check e605825366486 [[.under],[.under]] .smaller = true := by decide
def e605825366490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e605825366490 : Closed e605825366490 ∧ code e605825366490 = 9401918388698 := by decide
theorem cert_e605825366490 : check e605825366490 [[.under],[.under]] .smaller = true := by decide
def e605825366646 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e605825366646 : Closed e605825366646 ∧ code e605825366646 = 9401918388854 := by decide
theorem cert_e605825366646 : check e605825366646 [[.under],[.under]] .smaller = true := by decide
def e605825366838 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605825366838 : Closed e605825366838 ∧ code e605825366838 = 9401918389046 := by decide
theorem cert_e605825366838 : check e605825366838 [[.under],[.under]] .smaller = true := by decide
def e605825366842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605825366842 : Closed e605825366842 ∧ code e605825366842 = 9401918389050 := by decide
theorem cert_e605825366842 : check e605825366842 [[.under],[.under]] .smaller = true := by decide
def e605825367254 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e605825367254 : Closed e605825367254 ∧ code e605825367254 = 9401918389462 := by decide
theorem cert_e605825367254 : check e605825367254 [[.under],[.under]] .chain = true := by decide
def e605825367258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e605825367258 : Closed e605825367258 ∧ code e605825367258 = 9401918389466 := by decide
theorem cert_e605825367258 : check e605825367258 [[.under],[.under]] .chain = true := by decide
def e605825367274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e605825367274 : Closed e605825367274 ∧ code e605825367274 = 9401918389482 := by decide
theorem cert_e605825367274 : check e605825367274 [[.under],[.under]] .chain = true := by decide
def e605825367350 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e605825367350 : Closed e605825367350 ∧ code e605825367350 = 9401918389558 := by decide
theorem cert_e605825367350 : check e605825367350 [[.under],[.under]] .chain = true := by decide
def e605825367354 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e605825367354 : Closed e605825367354 ∧ code e605825367354 = 9401918389562 := by decide
theorem cert_e605825367354 : check e605825367354 [[.under],[.under]] .chain = true := by decide
def e605825367450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e605825367450 : Closed e605825367450 ∧ code e605825367450 = 9401918389658 := by decide
theorem cert_e605825367450 : check e605825367450 [[.under],[.under]] .chain = true := by decide
def e605825373918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e605825373918 : Closed e605825373918 ∧ code e605825373918 = 9401918396126 := by decide
theorem cert_e605825373918 : check e605825373918 [[.under],[.under]] .chain = true := by decide
def e605825373942 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e605825373942 : Closed e605825373942 ∧ code e605825373942 = 9401918396150 := by decide
theorem cert_e605825373942 : check e605825373942 [[.under],[.under]] .chain = true := by decide
def e605825374046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e605825374046 : Closed e605825374046 ∧ code e605825374046 = 9401918396254 := by decide
theorem cert_e605825374046 : check e605825374046 [[.under],[.under]] .chain = true := by decide
def e605825374062 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e605825374062 : Closed e605825374062 ∧ code e605825374062 = 9401918396270 := by decide
theorem cert_e605825374062 : check e605825374062 [[.under],[.under]] .smaller = true := by decide
def e605825374070 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e605825374070 : Closed e605825374070 ∧ code e605825374070 = 9401918396278 := by decide
theorem cert_e605825374070 : check e605825374070 [[.under],[.under]] .smaller = true := by decide
def e605825374074 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e605825374074 : Closed e605825374074 ∧ code e605825374074 = 9401918396282 := by decide
theorem cert_e605825374074 : check e605825374074 [[.under],[.under]] .chain = true := by decide
def e605825374134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e605825374134 : Closed e605825374134 ∧ code e605825374134 = 9401918396342 := by decide
theorem cert_e605825374134 : check e605825374134 [[.under],[.under]] .smaller = true := by decide
def e605825374166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e605825374166 : Closed e605825374166 ∧ code e605825374166 = 9401918396374 := by decide
theorem cert_e605825374166 : check e605825374166 [[.under],[.under]] .chain = true := by decide
def e605825374170 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e605825374170 : Closed e605825374170 ∧ code e605825374170 = 9401918396378 := by decide
theorem cert_e605825374170 : check e605825374170 [[.under],[.under]] .chain = true := by decide
def e605825374686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e605825374686 : Closed e605825374686 ∧ code e605825374686 = 9401918396894 := by decide
theorem cert_e605825374686 : check e605825374686 [[.under],[.under]] .chain = true := by decide
def e605825374710 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e605825374710 : Closed e605825374710 ∧ code e605825374710 = 9401918396918 := by decide
theorem cert_e605825374710 : check e605825374710 [[.under],[.under]] .chain = true := by decide
def e605825375454 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605825375454 : Closed e605825375454 ∧ code e605825375454 = 9401918397662 := by decide
theorem cert_e605825375454 : check e605825375454 [[.under],[.under]] .chain = true := by decide
def e605825375470 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605825375470 : Closed e605825375470 ∧ code e605825375470 = 9401918397678 := by decide
theorem cert_e605825375470 : check e605825375470 [[.under],[.under]] .smaller = true := by decide
def e605825375478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605825375478 : Closed e605825375478 ∧ code e605825375478 = 9401918397686 := by decide
theorem cert_e605825375478 : check e605825375478 [[.under],[.under]] .smaller = true := by decide
def e605825375482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605825375482 : Closed e605825375482 ∧ code e605825375482 = 9401918397690 := by decide
theorem cert_e605825375482 : check e605825375482 [[.under],[.under]] .chain = true := by decide
def e605825375862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e605825375862 : Closed e605825375862 ∧ code e605825375862 = 9401918398070 := by decide
theorem cert_e605825375862 : check e605825375862 [[.under],[.under]] .smaller = true := by decide
def e605825376054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605825376054 : Closed e605825376054 ∧ code e605825376054 = 9401918398262 := by decide
theorem cert_e605825376054 : check e605825376054 [[.under],[.under]] .chain = true := by decide
def e605825376058 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605825376058 : Closed e605825376058 ∧ code e605825376058 = 9401918398266 := by decide
theorem cert_e605825376058 : check e605825376058 [[.under],[.under]] .chain = true := by decide
def e605825387358 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e605825387358 : Closed e605825387358 ∧ code e605825387358 = 9401918409566 := by decide
theorem cert_e605825387358 : check e605825387358 [[.under],[.under]] .chain = true := by decide
def e605825387374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e605825387374 : Closed e605825387374 ∧ code e605825387374 = 9401918409582 := by decide
theorem cert_e605825387374 : check e605825387374 [[.under],[.under]] .smaller = true := by decide
def e605825387382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e605825387382 : Closed e605825387382 ∧ code e605825387382 = 9401918409590 := by decide
theorem cert_e605825387382 : check e605825387382 [[.under],[.under]] .smaller = true := by decide
def e605825387386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e605825387386 : Closed e605825387386 ∧ code e605825387386 = 9401918409594 := by decide
theorem cert_e605825387386 : check e605825387386 [[.under],[.under]] .chain = true := by decide
def e605825387438 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e605825387438 : Closed e605825387438 ∧ code e605825387438 = 9401918409646 := by decide
theorem cert_e605825387438 : check e605825387438 [[.under],[.under]] .smaller = true := by decide
def e605825387450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e605825387450 : Closed e605825387450 ∧ code e605825387450 = 9401918409658 := by decide
theorem cert_e605825387450 : check e605825387450 [[.under],[.under]] .smaller = true := by decide
def e605825387478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e605825387478 : Closed e605825387478 ∧ code e605825387478 = 9401918409686 := by decide
theorem cert_e605825387478 : check e605825387478 [[.under],[.under]] .smaller = true := by decide
def e605825387482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e605825387482 : Closed e605825387482 ∧ code e605825387482 = 9401918409690 := by decide
theorem cert_e605825387482 : check e605825387482 [[.under],[.under]] .smaller = true := by decide
def e605825387498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e605825387498 : Closed e605825387498 ∧ code e605825387498 = 9401918409706 := by decide
theorem cert_e605825387498 : check e605825387498 [[.under],[.under]] .chain = true := by decide
def e605825387742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e605825387742 : Closed e605825387742 ∧ code e605825387742 = 9401918409950 := by decide
theorem cert_e605825387742 : check e605825387742 [[.under],[.under]] .chain = true := by decide
def e605825387758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e605825387758 : Closed e605825387758 ∧ code e605825387758 = 9401918409966 := by decide
theorem cert_e605825387758 : check e605825387758 [[.under],[.under]] .smaller = true := by decide
def e605825387766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e605825387766 : Closed e605825387766 ∧ code e605825387766 = 9401918409974 := by decide
theorem cert_e605825387766 : check e605825387766 [[.under],[.under]] .smaller = true := by decide
def e605825387770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e605825387770 : Closed e605825387770 ∧ code e605825387770 = 9401918409978 := by decide
theorem cert_e605825387770 : check e605825387770 [[.under],[.under]] .chain = true := by decide
def e605825388142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e605825388142 : Closed e605825388142 ∧ code e605825388142 = 9401918410350 := by decide
theorem cert_e605825388142 : check e605825388142 [[.under],[.under]] .smaller = true := by decide
def e605825388154 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e605825388154 : Closed e605825388154 ∧ code e605825388154 = 9401918410362 := by decide
theorem cert_e605825388154 : check e605825388154 [[.under],[.under]] .smaller = true := by decide
def e605825388342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605825388342 : Closed e605825388342 ∧ code e605825388342 = 9401918410550 := by decide
theorem cert_e605825388342 : check e605825388342 [[.under],[.under]] .smaller = true := by decide
def e605825388346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605825388346 : Closed e605825388346 ∧ code e605825388346 = 9401918410554 := by decide
theorem cert_e605825388346 : check e605825388346 [[.under],[.under]] .smaller = true := by decide
def e605825388442 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605825388442 : Closed e605825388442 ∧ code e605825388442 = 9401918410650 := by decide
theorem cert_e605825388442 : check e605825388442 [[.under],[.under]] .chain = true := by decide
def e605825394102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e605825394102 : Closed e605825394102 ∧ code e605825394102 = 9401918416310 := by decide
theorem cert_e605825394102 : check e605825394102 [[.under],[.under]] .smaller = true := by decide
def e605825394134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e605825394134 : Closed e605825394134 ∧ code e605825394134 = 9401918416342 := by decide
theorem cert_e605825394134 : check e605825394134 [[.under],[.under]] .smaller = true := by decide
def e605825394138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e605825394138 : Closed e605825394138 ∧ code e605825394138 = 9401918416346 := by decide
theorem cert_e605825394138 : check e605825394138 [[.under],[.under]] .smaller = true := by decide
def e605825394294 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e605825394294 : Closed e605825394294 ∧ code e605825394294 = 9401918416502 := by decide
theorem cert_e605825394294 : check e605825394294 [[.under],[.under]] .smaller = true := by decide
def e605825394486 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605825394486 : Closed e605825394486 ∧ code e605825394486 = 9401918416694 := by decide
theorem cert_e605825394486 : check e605825394486 [[.under],[.under]] .smaller = true := by decide
def e605825394490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605825394490 : Closed e605825394490 ∧ code e605825394490 = 9401918416698 := by decide
theorem cert_e605825394490 : check e605825394490 [[.under],[.under]] .smaller = true := by decide
def e605825397462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e605825397462 : Closed e605825397462 ∧ code e605825397462 = 9401918419670 := by decide
theorem cert_e605825397462 : check e605825397462 [[.under],[.under]] .chain = true := by decide
def e605825397466 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e605825397466 : Closed e605825397466 ∧ code e605825397466 = 9401918419674 := by decide
theorem cert_e605825397466 : check e605825397466 [[.under],[.under]] .chain = true := by decide
def e605825397482 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e605825397482 : Closed e605825397482 ∧ code e605825397482 = 9401918419690 := by decide
theorem cert_e605825397482 : check e605825397482 [[.under],[.under]] .chain = true := by decide
def e605825397558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e605825397558 : Closed e605825397558 ∧ code e605825397558 = 9401918419766 := by decide
theorem cert_e605825397558 : check e605825397558 [[.under],[.under]] .chain = true := by decide
def e605825397562 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e605825397562 : Closed e605825397562 ∧ code e605825397562 = 9401918419770 := by decide
theorem cert_e605825397562 : check e605825397562 [[.under],[.under]] .chain = true := by decide
def e605825397658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e605825397658 : Closed e605825397658 ∧ code e605825397658 = 9401918419866 := by decide
theorem cert_e605825397658 : check e605825397658 [[.under],[.under]] .chain = true := by decide
def e605825622894 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e605825622894 : Closed e605825622894 ∧ code e605825622894 = 9401918645102 := by decide
theorem cert_e605825622894 : check e605825622894 [[.under],[.under]] .chain = true := by decide
def e605825622902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e605825622902 : Closed e605825622902 ∧ code e605825622902 = 9401918645110 := by decide
theorem cert_e605825622902 : check e605825622902 [[.under],[.under]] .chain = true := by decide
def e605825622958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e605825622958 : Closed e605825622958 ∧ code e605825622958 = 9401918645166 := by decide
theorem cert_e605825622958 : check e605825622958 [[.under],[.under]] .chain = true := by decide
def e605825622970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e605825622970 : Closed e605825622970 ∧ code e605825622970 = 9401918645178 := by decide
theorem cert_e605825622970 : check e605825622970 [[.under],[.under]] .chain = true := by decide
def e605825622998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e605825622998 : Closed e605825622998 ∧ code e605825622998 = 9401918645206 := by decide
theorem cert_e605825622998 : check e605825622998 [[.under],[.under]] .chain = true := by decide
def e605825623002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e605825623002 : Closed e605825623002 ∧ code e605825623002 = 9401918645210 := by decide
theorem cert_e605825623002 : check e605825623002 [[.under],[.under]] .chain = true := by decide
def e605825624302 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e605825624302 : Closed e605825624302 ∧ code e605825624302 = 9401918646510 := by decide
theorem cert_e605825624302 : check e605825624302 [[.under],[.under]] .chain = true := by decide
def e605825624310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e605825624310 : Closed e605825624310 ∧ code e605825624310 = 9401918646518 := by decide
theorem cert_e605825624310 : check e605825624310 [[.under],[.under]] .chain = true := by decide
def e605825624862 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e605825624862 : Closed e605825624862 ∧ code e605825624862 = 9401918647070 := by decide
theorem cert_e605825624862 : check e605825624862 [[.under],[.under]] .chain = true := by decide
def e605825624974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e605825624974 : Closed e605825624974 ∧ code e605825624974 = 9401918647182 := by decide
theorem cert_e605825624974 : check e605825624974 [[.under],[.under]] .chain = true := by decide
def e605825625198 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605825625198 : Closed e605825625198 ∧ code e605825625198 = 9401918647406 := by decide
theorem cert_e605825625198 : check e605825625198 [[.under],[.under]] .chain = true := by decide
def e605825625210 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605825625210 : Closed e605825625210 ∧ code e605825625210 = 9401918647418 := by decide
theorem cert_e605825625210 : check e605825625210 [[.under],[.under]] .chain = true := by decide
def e605825625374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605825625374 : Closed e605825625374 ∧ code e605825625374 = 9401918647582 := by decide
theorem cert_e605825625374 : check e605825625374 [[.under],[.under]] .chain = true := by decide
def e605825625542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605825625542 : Closed e605825625542 ∧ code e605825625542 = 9401918647750 := by decide
theorem cert_e605825625542 : check e605825625542 [[.under],[.under]] .chain = true := by decide
def e605825625654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605825625654 : Closed e605825625654 ∧ code e605825625654 = 9401918647862 := by decide
theorem cert_e605825625654 : check e605825625654 [[.under],[.under]] .chain = true := by decide
def e605825625658 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605825625658 : Closed e605825625658 ∧ code e605825625658 = 9401918647866 := by decide
theorem cert_e605825625658 : check e605825625658 [[.under],[.under]] .chain = true := by decide
def e605825625742 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605825625742 : Closed e605825625742 ∧ code e605825625742 = 9401918647950 := by decide
theorem cert_e605825625742 : check e605825625742 [[.under],[.under]] .chain = true := by decide
def e605825625798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605825625798 : Closed e605825625798 ∧ code e605825625798 = 9401918648006 := by decide
theorem cert_e605825625798 : check e605825625798 [[.under],[.under]] .chain = true := by decide
def e605825626542 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2))))))))
theorem wire_e605825626542 : Closed e605825626542 ∧ code e605825626542 = 9401918648750 := by decide
theorem cert_e605825626542 : check e605825626542 [[.under],[.under]] .chain = true := by decide
def e605825626554 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0))))))))
theorem wire_e605825626554 : Closed e605825626554 ∧ code e605825626554 = 9401918648762 := by decide
theorem cert_e605825626554 : check e605825626554 [[.under],[.under]] .chain = true := by decide
def e605825626602 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0))))))))
theorem wire_e605825626602 : Closed e605825626602 ∧ code e605825626602 = 9401918648810 := by decide
theorem cert_e605825626602 : check e605825626602 [[.under],[.under]] .chain = true := by decide
def e605825627246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e605825627246 : Closed e605825627246 ∧ code e605825627246 = 9401918649454 := by decide
theorem cert_e605825627246 : check e605825627246 [[.under],[.under]] .chain = true := by decide
def e605825627258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e605825627258 : Closed e605825627258 ∧ code e605825627258 = 9401918649466 := by decide
theorem cert_e605825627258 : check e605825627258 [[.under],[.under]] .chain = true := by decide
def e605825627422 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e605825627422 : Closed e605825627422 ∧ code e605825627422 = 9401918649630 := by decide
theorem cert_e605825627422 : check e605825627422 [[.under],[.under]] .chain = true := by decide
def e605825627590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e605825627590 : Closed e605825627590 ∧ code e605825627590 = 9401918649798 := by decide
theorem cert_e605825627590 : check e605825627590 [[.under],[.under]] .chain = true := by decide
def e605825627930 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 0))))))))
theorem wire_e605825627930 : Closed e605825627930 ∧ code e605825627930 = 9401918650138 := by decide
theorem cert_e605825627930 : check e605825627930 [[.under],[.under]] .chain = true := by decide
def e605825627974 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e605825627974 : Closed e605825627974 ∧ code e605825627974 = 9401918650182 := by decide
theorem cert_e605825627974 : check e605825627974 [[.under],[.under]] .chain = true := by decide
def e605825628374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.var 1))))))))
theorem wire_e605825628374 : Closed e605825628374 ∧ code e605825628374 = 9401918650582 := by decide
theorem cert_e605825628374 : check e605825628374 [[.under],[.under]] .chain = true := by decide
def e605825628378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 0))))))))
theorem wire_e605825628378 : Closed e605825628378 ∧ code e605825628378 = 9401918650586 := by decide
theorem cert_e605825628378 : check e605825628378 [[.under],[.under]] .chain = true := by decide
def e605825628394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e605825628394 : Closed e605825628394 ∧ code e605825628394 = 9401918650602 := by decide
theorem cert_e605825628394 : check e605825628394 [[.under],[.under]] .chain = true := by decide
def e605825628726 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e605825628726 : Closed e605825628726 ∧ code e605825628726 = 9401918650934 := by decide
theorem cert_e605825628726 : check e605825628726 [[.under],[.under]] .chain = true := by decide
def e605825628730 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e605825628730 : Closed e605825628730 ∧ code e605825628730 = 9401918650938 := by decide
theorem cert_e605825628730 : check e605825628730 [[.under],[.under]] .chain = true := by decide
def e605825628814 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e605825628814 : Closed e605825628814 ∧ code e605825628814 = 9401918651022 := by decide
theorem cert_e605825628814 : check e605825628814 [[.under],[.under]] .chain = true := by decide
def e605825628870 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e605825628870 : Closed e605825628870 ∧ code e605825628870 = 9401918651078 := by decide
theorem cert_e605825628870 : check e605825628870 [[.under],[.under]] .chain = true := by decide
end Blc.Floor43
