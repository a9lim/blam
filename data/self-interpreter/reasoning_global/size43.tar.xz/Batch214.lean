import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392414270702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392414270702 : Closed e2392414270702 ∧ code e2392414270702 = 11188507292910 := by decide
theorem cert_e2392414270702 : check e2392414270702 [[],[.left],[]] .sourceHead = true := by decide
def e2392414270710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392414270710 : Closed e2392414270710 ∧ code e2392414270710 = 11188507292918 := by decide
theorem cert_e2392414270710 : check e2392414270710 [[],[.left],[]] .sourceHead = true := by decide
def e2392414271086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392414271086 : Closed e2392414271086 ∧ code e2392414271086 = 11188507293294 := by decide
theorem cert_e2392414271086 : check e2392414271086 [[],[.left],[]] .sourceHead = true := by decide
def e2392414271098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392414271098 : Closed e2392414271098 ∧ code e2392414271098 = 11188507293306 := by decide
theorem cert_e2392414271098 : check e2392414271098 [[],[.left],[]] .sourceHead = true := by decide
def e2392414271286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392414271286 : Closed e2392414271286 ∧ code e2392414271286 = 11188507293494 := by decide
theorem cert_e2392414271286 : check e2392414271286 [[],[.left],[]] .sourceHead = true := by decide
def e2392414271290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392414271290 : Closed e2392414271290 ∧ code e2392414271290 = 11188507293498 := by decide
theorem cert_e2392414271290 : check e2392414271290 [[],[.left],[]] .sourceHead = true := by decide
def e2392414271918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2392414271918 : Closed e2392414271918 ∧ code e2392414271918 = 11188507294126 := by decide
theorem cert_e2392414271918 : check e2392414271918 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2392414271930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2392414271930 : Closed e2392414271930 ∧ code e2392414271930 = 11188507294138 := by decide
theorem cert_e2392414271930 : check e2392414271930 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392414271978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2392414271978 : Closed e2392414271978 ∧ code e2392414271978 = 11188507294186 := by decide
theorem cert_e2392414271978 : check e2392414271978 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392414272110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392414272110 : Closed e2392414272110 ∧ code e2392414272110 = 11188507294318 := by decide
theorem cert_e2392414272110 : check e2392414272110 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2392414272122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392414272122 : Closed e2392414272122 ∧ code e2392414272122 = 11188507294330 := by decide
theorem cert_e2392414272122 : check e2392414272122 [[],[.left],[],[.under,.left],[.under]] .smaller = true := by decide
def e2392414272410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392414272410 : Closed e2392414272410 ∧ code e2392414272410 = 11188507294618 := by decide
theorem cert_e2392414272410 : check e2392414272410 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392414272726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2392414272726 : Closed e2392414272726 ∧ code e2392414272726 = 11188507294934 := by decide
theorem cert_e2392414272726 : check e2392414272726 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392414272730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2392414272730 : Closed e2392414272730 ∧ code e2392414272730 = 11188507294938 := by decide
theorem cert_e2392414272730 : check e2392414272730 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392414272746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2392414272746 : Closed e2392414272746 ∧ code e2392414272746 = 11188507294954 := by decide
theorem cert_e2392414272746 : check e2392414272746 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392414272822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392414272822 : Closed e2392414272822 ∧ code e2392414272822 = 11188507295030 := by decide
theorem cert_e2392414272822 : check e2392414272822 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392414272826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392414272826 : Closed e2392414272826 ∧ code e2392414272826 = 11188507295034 := by decide
theorem cert_e2392414272826 : check e2392414272826 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2392414272922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392414272922 : Closed e2392414272922 ∧ code e2392414272922 = 11188507295130 := by decide
theorem cert_e2392414272922 : check e2392414272922 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2392414276462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392414276462 : Closed e2392414276462 ∧ code e2392414276462 = 11188507298670 := by decide
theorem cert_e2392414276462 : check e2392414276462 [[],[.left],[]] .sourceHead = true := by decide
def e2392414276470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392414276470 : Closed e2392414276470 ∧ code e2392414276470 = 11188507298678 := by decide
theorem cert_e2392414276470 : check e2392414276470 [[],[.left],[]] .sourceHead = true := by decide
def e2392414276526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392414276526 : Closed e2392414276526 ∧ code e2392414276526 = 11188507298734 := by decide
theorem cert_e2392414276526 : check e2392414276526 [[],[.left],[]] .sourceHead = true := by decide
def e2392414276538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392414276538 : Closed e2392414276538 ∧ code e2392414276538 = 11188507298746 := by decide
theorem cert_e2392414276538 : check e2392414276538 [[],[.left],[]] .sourceHead = true := by decide
def e2392414276566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392414276566 : Closed e2392414276566 ∧ code e2392414276566 = 11188507298774 := by decide
theorem cert_e2392414276566 : check e2392414276566 [[],[.left],[]] .sourceHead = true := by decide
def e2392414276570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392414276570 : Closed e2392414276570 ∧ code e2392414276570 = 11188507298778 := by decide
theorem cert_e2392414276570 : check e2392414276570 [[],[.left],[]] .sourceHead = true := by decide
def e2392414276846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392414276846 : Closed e2392414276846 ∧ code e2392414276846 = 11188507299054 := by decide
theorem cert_e2392414276846 : check e2392414276846 [[],[.left],[]] .sourceHead = true := by decide
def e2392414276854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392414276854 : Closed e2392414276854 ∧ code e2392414276854 = 11188507299062 := by decide
theorem cert_e2392414276854 : check e2392414276854 [[],[.left],[]] .sourceHead = true := by decide
def e2392414277230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392414277230 : Closed e2392414277230 ∧ code e2392414277230 = 11188507299438 := by decide
theorem cert_e2392414277230 : check e2392414277230 [[],[.left],[]] .sourceHead = true := by decide
def e2392414277242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392414277242 : Closed e2392414277242 ∧ code e2392414277242 = 11188507299450 := by decide
theorem cert_e2392414277242 : check e2392414277242 [[],[.left],[]] .sourceHead = true := by decide
def e2392414277430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392414277430 : Closed e2392414277430 ∧ code e2392414277430 = 11188507299638 := by decide
theorem cert_e2392414277430 : check e2392414277430 [[],[.left],[]] .sourceHead = true := by decide
def e2392414277434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392414277434 : Closed e2392414277434 ∧ code e2392414277434 = 11188507299642 := by decide
theorem cert_e2392414277434 : check e2392414277434 [[],[.left],[]] .sourceHead = true := by decide
def e2392414283182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2392414283182 : Closed e2392414283182 ∧ code e2392414283182 = 11188507305390 := by decide
theorem cert_e2392414283182 : check e2392414283182 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392414283194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2392414283194 : Closed e2392414283194 ∧ code e2392414283194 = 11188507305402 := by decide
theorem cert_e2392414283194 : check e2392414283194 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392414283242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2392414283242 : Closed e2392414283242 ∧ code e2392414283242 = 11188507305450 := by decide
theorem cert_e2392414283242 : check e2392414283242 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392414283374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2392414283374 : Closed e2392414283374 ∧ code e2392414283374 = 11188507305582 := by decide
theorem cert_e2392414283374 : check e2392414283374 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392414283386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2392414283386 : Closed e2392414283386 ∧ code e2392414283386 = 11188507305594 := by decide
theorem cert_e2392414283386 : check e2392414283386 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392414283674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2392414283674 : Closed e2392414283674 ∧ code e2392414283674 = 11188507305882 := by decide
theorem cert_e2392414283674 : check e2392414283674 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392414286550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2392414286550 : Closed e2392414286550 ∧ code e2392414286550 = 11188507308758 := by decide
theorem cert_e2392414286550 : check e2392414286550 [[],[.left],[],[.under]] .three = true := by decide
def e2392414286554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2392414286554 : Closed e2392414286554 ∧ code e2392414286554 = 11188507308762 := by decide
theorem cert_e2392414286554 : check e2392414286554 [[],[.left],[],[.under]] .three = true := by decide
def e2392414286570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2392414286570 : Closed e2392414286570 ∧ code e2392414286570 = 11188507308778 := by decide
theorem cert_e2392414286570 : check e2392414286570 [[],[.left],[],[.under]] .three = true := by decide
def e2392414286646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2392414286646 : Closed e2392414286646 ∧ code e2392414286646 = 11188507308854 := by decide
theorem cert_e2392414286646 : check e2392414286646 [[],[.left],[],[.under]] .three = true := by decide
def e2392414286650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2392414286650 : Closed e2392414286650 ∧ code e2392414286650 = 11188507308858 := by decide
theorem cert_e2392414286650 : check e2392414286650 [[],[.left],[],[.under]] .three = true := by decide
def e2392414286746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2392414286746 : Closed e2392414286746 ∧ code e2392414286746 = 11188507308954 := by decide
theorem cert_e2392414286746 : check e2392414286746 [[],[.left],[],[.under]] .three = true := by decide
def e2392414423918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392414423918 : Closed e2392414423918 ∧ code e2392414423918 = 11188507446126 := by decide
theorem cert_e2392414423918 : check e2392414423918 [[],[.left],[],[]] .smaller = true := by decide
def e2392414423926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392414423926 : Closed e2392414423926 ∧ code e2392414423926 = 11188507446134 := by decide
theorem cert_e2392414423926 : check e2392414423926 [[],[.left],[],[]] .smaller = true := by decide
def e2392414423982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392414423982 : Closed e2392414423982 ∧ code e2392414423982 = 11188507446190 := by decide
theorem cert_e2392414423982 : check e2392414423982 [[],[.left],[],[]] .smaller = true := by decide
def e2392414423994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392414423994 : Closed e2392414423994 ∧ code e2392414423994 = 11188507446202 := by decide
theorem cert_e2392414423994 : check e2392414423994 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392414424022 : Closed e2392414424022 ∧ code e2392414424022 = 11188507446230 := by decide
theorem cert_e2392414424022 : check e2392414424022 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392414424026 : Closed e2392414424026 ∧ code e2392414424026 = 11188507446234 := by decide
theorem cert_e2392414424026 : check e2392414424026 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392414424302 : Closed e2392414424302 ∧ code e2392414424302 = 11188507446510 := by decide
theorem cert_e2392414424302 : check e2392414424302 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392414424310 : Closed e2392414424310 ∧ code e2392414424310 = 11188507446518 := by decide
theorem cert_e2392414424310 : check e2392414424310 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392414424686 : Closed e2392414424686 ∧ code e2392414424686 = 11188507446894 := by decide
theorem cert_e2392414424686 : check e2392414424686 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392414424698 : Closed e2392414424698 ∧ code e2392414424698 = 11188507446906 := by decide
theorem cert_e2392414424698 : check e2392414424698 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392414424886 : Closed e2392414424886 ∧ code e2392414424886 = 11188507447094 := by decide
theorem cert_e2392414424886 : check e2392414424886 [[],[.left],[],[]] .smaller = true := by decide
def e2392414424890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392414424890 : Closed e2392414424890 ∧ code e2392414424890 = 11188507447098 := by decide
theorem cert_e2392414424890 : check e2392414424890 [[],[.left],[],[]] .smaller = true := by decide
def e2392415013742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392415013742 : Closed e2392415013742 ∧ code e2392415013742 = 11188508035950 := by decide
theorem cert_e2392415013742 : check e2392415013742 [[],[.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e2392415013750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392415013750 : Closed e2392415013750 ∧ code e2392415013750 = 11188508035958 := by decide
theorem cert_e2392415013750 : check e2392415013750 [[],[.left],[.left],[.left],[],[.left],[]] .smaller = true := by decide
def e2392415013806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392415013806 : Closed e2392415013806 ∧ code e2392415013806 = 11188508036014 := by decide
theorem cert_e2392415013806 : check e2392415013806 [[],[.left],[.left],[.left],[],[.left],[],[.left],[]] .smaller = true := by decide
def e2392415013818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392415013818 : Closed e2392415013818 ∧ code e2392415013818 = 11188508036026 := by decide
private def t_e2392415013818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem cert_e2392415013818 : ¬ IsSelfInterpreter e2392415013818 :=
  wSource (t := t_e2392415013818) (replay_sound (ps := []) (t := e2392415013818) (by decide)) (by decide)
def e2392415013846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392415013846 : Closed e2392415013846 ∧ code e2392415013846 = 11188508036054 := by decide
theorem cert_e2392415013846 : check e2392415013846 [[],[.left],[.left],[.left],[],[.left],[.left],[]] .smaller = true := by decide
def e2392415013850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392415013850 : Closed e2392415013850 ∧ code e2392415013850 = 11188508036058 := by decide
private def t_e2392415013850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2392415013850 : ¬ IsSelfInterpreter e2392415013850 :=
  wSource (t := t_e2392415013850) (replay_sound (ps := []) (t := e2392415013850) (by decide)) (by decide)
def e2392415014126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392415014126 : Closed e2392415014126 ∧ code e2392415014126 = 11188508036334 := by decide
theorem cert_e2392415014126 : check e2392415014126 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2392415014134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392415014134 : Closed e2392415014134 ∧ code e2392415014134 = 11188508036342 := by decide
theorem cert_e2392415014134 : check e2392415014134 [[],[.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2392415014510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392415014510 : Closed e2392415014510 ∧ code e2392415014510 = 11188508036718 := by decide
theorem cert_e2392415014510 : check e2392415014510 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under]] .smaller = true := by decide
def e2392415014522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392415014522 : Closed e2392415014522 ∧ code e2392415014522 = 11188508036730 := by decide
theorem cert_e2392415014522 : check e2392415014522 [[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2392415014710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392415014710 : Closed e2392415014710 ∧ code e2392415014710 = 11188508036918 := by decide
theorem cert_e2392415014710 : check e2392415014710 [[],[.left],[.left],[.left],[],[],[.left],[]] .smaller = true := by decide
def e2392415014714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392415014714 : Closed e2392415014714 ∧ code e2392415014714 = 11188508036922 := by decide
theorem cert_e2392415014714 : check e2392415014714 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2392498859546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498859546 : Closed e2392498859546 ∧ code e2392498859546 = 11188591881754 := by decide
private def t_e2392498859546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498859546 : ¬ IsSelfInterpreter e2392498859546 :=
  wSource (t := t_e2392498859546) (replay_sound (ps := []) (t := e2392498859546) (by decide)) (by decide)
def e2392498861594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498861594 : Closed e2392498861594 ∧ code e2392498861594 = 11188591883802 := by decide
private def t_e2392498861594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498861594 : ¬ IsSelfInterpreter e2392498861594 :=
  wSource (t := t_e2392498861594) (replay_sound (ps := []) (t := e2392498861594) (by decide)) (by decide)
def e2392498875930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498875930 : Closed e2392498875930 ∧ code e2392498875930 = 11188591898138 := by decide
private def t_e2392498875930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498875930 : ¬ IsSelfInterpreter e2392498875930 :=
  wSource (t := t_e2392498875930) (replay_sound (ps := []) (t := e2392498875930) (by decide)) (by decide)
def e2392498879002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498879002 : Closed e2392498879002 ∧ code e2392498879002 = 11188591901210 := by decide
private def t_e2392498879002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498879002 : ¬ IsSelfInterpreter e2392498879002 :=
  wSource (t := t_e2392498879002) (replay_sound (ps := []) (t := e2392498879002) (by decide)) (by decide)
def e2392498886170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498886170 : Closed e2392498886170 ∧ code e2392498886170 = 11188591908378 := by decide
private def t_e2392498886170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498886170 : ¬ IsSelfInterpreter e2392498886170 :=
  wSource (t := t_e2392498886170) (replay_sound (ps := []) (t := e2392498886170) (by decide)) (by decide)
def e2392498887194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498887194 : Closed e2392498887194 ∧ code e2392498887194 = 11188591909402 := by decide
private def t_e2392498887194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498887194 : ¬ IsSelfInterpreter e2392498887194 :=
  wSource (t := t_e2392498887194) (replay_sound (ps := []) (t := e2392498887194) (by decide)) (by decide)
def e2392498957850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498957850 : Closed e2392498957850 ∧ code e2392498957850 = 11188591980058 := by decide
private def t_e2392498957850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498957850 : ¬ IsSelfInterpreter e2392498957850 :=
  wSource (t := t_e2392498957850) (replay_sound (ps := []) (t := e2392498957850) (by decide)) (by decide)
def e2392498959898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392498959898 : Closed e2392498959898 ∧ code e2392498959898 = 11188591982106 := by decide
private def t_e2392498959898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392498959898 : ¬ IsSelfInterpreter e2392498959898 :=
  wSource (t := t_e2392498959898) (replay_sound (ps := []) (t := e2392498959898) (by decide)) (by decide)
def e2392499056154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392499056154 : Closed e2392499056154 ∧ code e2392499056154 = 11188592078362 := by decide
private def t_e2392499056154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392499056154 : ¬ IsSelfInterpreter e2392499056154 :=
  wSource (t := t_e2392499056154) (replay_sound (ps := []) (t := e2392499056154) (by decide)) (by decide)
def e2392499059226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392499059226 : Closed e2392499059226 ∧ code e2392499059226 = 11188592081434 := by decide
private def t_e2392499059226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392499059226 : ¬ IsSelfInterpreter e2392499059226 :=
  wSource (t := t_e2392499059226) (replay_sound (ps := []) (t := e2392499059226) (by decide)) (by decide)
def e2392499107354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392499107354 : Closed e2392499107354 ∧ code e2392499107354 = 11188592129562 := by decide
private def t_e2392499107354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392499107354 : ¬ IsSelfInterpreter e2392499107354 :=
  wSource (t := t_e2392499107354) (replay_sound (ps := []) (t := e2392499107354) (by decide)) (by decide)
def e2392499108378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392499108378 : Closed e2392499108378 ∧ code e2392499108378 = 11188592130586 := by decide
private def t_e2392499108378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392499108378 : ¬ IsSelfInterpreter e2392499108378 :=
  wSource (t := t_e2392499108378) (replay_sound (ps := []) (t := e2392499108378) (by decide)) (by decide)
def e2392501106714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501106714 : Closed e2392501106714 ∧ code e2392501106714 = 11188594128922 := by decide
theorem cert_e2392501106714 : check e2392501106714 [[]] .width = true := by decide
def e2392501114906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501114906 : Closed e2392501114906 ∧ code e2392501114906 = 11188594137114 := by decide
theorem cert_e2392501114906 : check e2392501114906 [[]] .width = true := by decide
def e2392501172250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501172250 : Closed e2392501172250 ∧ code e2392501172250 = 11188594194458 := by decide
theorem cert_e2392501172250 : check e2392501172250 [[]] .width = true := by decide
def e2392501184538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501184538 : Closed e2392501184538 ∧ code e2392501184538 = 11188594206746 := by decide
theorem cert_e2392501184538 : check e2392501184538 [[]] .width = true := by decide
def e2392501213210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501213210 : Closed e2392501213210 ∧ code e2392501213210 = 11188594235418 := by decide
theorem cert_e2392501213210 : check e2392501213210 [[]] .width = true := by decide
def e2392501217306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501217306 : Closed e2392501217306 ∧ code e2392501217306 = 11188594239514 := by decide
theorem cert_e2392501217306 : check e2392501217306 [[]] .width = true := by decide
def e2392501499930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501499930 : Closed e2392501499930 ∧ code e2392501499930 = 11188594522138 := by decide
theorem cert_e2392501499930 : check e2392501499930 [[]] .width = true := by decide
def e2392501508122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501508122 : Closed e2392501508122 ∧ code e2392501508122 = 11188594530330 := by decide
theorem cert_e2392501508122 : check e2392501508122 [[]] .width = true := by decide
def e2392501893146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501893146 : Closed e2392501893146 ∧ code e2392501893146 = 11188594915354 := by decide
theorem cert_e2392501893146 : check e2392501893146 [[]] .width = true := by decide
def e2392501905434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392501905434 : Closed e2392501905434 ∧ code e2392501905434 = 11188594927642 := by decide
theorem cert_e2392501905434 : check e2392501905434 [[]] .width = true := by decide
def e2392502097946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392502097946 : Closed e2392502097946 ∧ code e2392502097946 = 11188595120154 := by decide
theorem cert_e2392502097946 : check e2392502097946 [[]] .width = true := by decide
def e2392502102042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392502102042 : Closed e2392502102042 ∧ code e2392502102042 = 11188595124250 := by decide
theorem cert_e2392502102042 : check e2392502102042 [[]] .width = true := by decide
def e2392514932078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2392514932078 : Closed e2392514932078 ∧ code e2392514932078 = 11188607954286 := by decide
theorem cert_e2392514932078 : check e2392514932078 [[],[.left],[]] .sourceHead = true := by decide
def e2392514932086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2392514932086 : Closed e2392514932086 ∧ code e2392514932086 = 11188607954294 := by decide
theorem cert_e2392514932086 : check e2392514932086 [[],[.left],[]] .sourceHead = true := by decide
def e2392514932142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2392514932142 : Closed e2392514932142 ∧ code e2392514932142 = 11188607954350 := by decide
theorem cert_e2392514932142 : check e2392514932142 [[],[.left],[]] .sourceHead = true := by decide
def e2392514932154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2392514932154 : Closed e2392514932154 ∧ code e2392514932154 = 11188607954362 := by decide
theorem cert_e2392514932154 : check e2392514932154 [[],[.left],[]] .sourceHead = true := by decide
def e2392514932182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2392514932182 : Closed e2392514932182 ∧ code e2392514932182 = 11188607954390 := by decide
theorem cert_e2392514932182 : check e2392514932182 [[],[.left],[]] .sourceHead = true := by decide
def e2392514932186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2392514932186 : Closed e2392514932186 ∧ code e2392514932186 = 11188607954394 := by decide
theorem cert_e2392514932186 : check e2392514932186 [[],[.left],[]] .sourceHead = true := by decide
def e2392514932398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2392514932398 : Closed e2392514932398 ∧ code e2392514932398 = 11188607954606 := by decide
theorem cert_e2392514932398 : check e2392514932398 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392514932410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2392514932410 : Closed e2392514932410 ∧ code e2392514932410 = 11188607954618 := by decide
theorem cert_e2392514932410 : check e2392514932410 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392514932458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2392514932458 : Closed e2392514932458 ∧ code e2392514932458 = 11188607954666 := by decide
theorem cert_e2392514932458 : check e2392514932458 [[],[.left],[],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2392514932566 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2392514932566 : Closed e2392514932566 ∧ code e2392514932566 = 11188607954774 := by decide
theorem cert_e2392514932566 : check e2392514932566 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392514932570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2392514932570 : Closed e2392514932570 ∧ code e2392514932570 = 11188607954778 := by decide
theorem cert_e2392514932570 : check e2392514932570 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392514932586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2392514932586 : Closed e2392514932586 ∧ code e2392514932586 = 11188607954794 := by decide
theorem cert_e2392514932586 : check e2392514932586 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392514933614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2392514933614 : Closed e2392514933614 ∧ code e2392514933614 = 11188607955822 := by decide
theorem cert_e2392514933614 : check e2392514933614 [[],[.left],[]] .sourceHead = true := by decide
def e2392514933622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2392514933622 : Closed e2392514933622 ∧ code e2392514933622 = 11188607955830 := by decide
theorem cert_e2392514933622 : check e2392514933622 [[],[.left],[]] .sourceHead = true := by decide
def e2392514933678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2392514933678 : Closed e2392514933678 ∧ code e2392514933678 = 11188607955886 := by decide
theorem cert_e2392514933678 : check e2392514933678 [[],[.left],[]] .sourceHead = true := by decide
def e2392514933690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2392514933690 : Closed e2392514933690 ∧ code e2392514933690 = 11188607955898 := by decide
theorem cert_e2392514933690 : check e2392514933690 [[],[.left],[]] .sourceHead = true := by decide
def e2392514933718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2392514933718 : Closed e2392514933718 ∧ code e2392514933718 = 11188607955926 := by decide
theorem cert_e2392514933718 : check e2392514933718 [[],[.left],[]] .sourceHead = true := by decide
def e2392514933722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2392514933722 : Closed e2392514933722 ∧ code e2392514933722 = 11188607955930 := by decide
theorem cert_e2392514933722 : check e2392514933722 [[],[.left],[]] .sourceHead = true := by decide
def e2392514933998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2392514933998 : Closed e2392514933998 ∧ code e2392514933998 = 11188607956206 := by decide
theorem cert_e2392514933998 : check e2392514933998 [[],[.left],[]] .sourceHead = true := by decide
def e2392514934006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2392514934006 : Closed e2392514934006 ∧ code e2392514934006 = 11188607956214 := by decide
theorem cert_e2392514934006 : check e2392514934006 [[],[.left],[]] .sourceHead = true := by decide
def e2392514934382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392514934382 : Closed e2392514934382 ∧ code e2392514934382 = 11188607956590 := by decide
theorem cert_e2392514934382 : check e2392514934382 [[],[.left],[]] .sourceHead = true := by decide
def e2392514934394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392514934394 : Closed e2392514934394 ∧ code e2392514934394 = 11188607956602 := by decide
theorem cert_e2392514934394 : check e2392514934394 [[],[.left],[]] .sourceHead = true := by decide
def e2392514934582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392514934582 : Closed e2392514934582 ∧ code e2392514934582 = 11188607956790 := by decide
theorem cert_e2392514934582 : check e2392514934582 [[],[.left],[]] .sourceHead = true := by decide
def e2392514934586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392514934586 : Closed e2392514934586 ∧ code e2392514934586 = 11188607956794 := by decide
theorem cert_e2392514934586 : check e2392514934586 [[],[.left],[]] .sourceHead = true := by decide
def e2392514935214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2392514935214 : Closed e2392514935214 ∧ code e2392514935214 = 11188607957422 := by decide
theorem cert_e2392514935214 : check e2392514935214 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514935226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2392514935226 : Closed e2392514935226 ∧ code e2392514935226 = 11188607957434 := by decide
theorem cert_e2392514935226 : check e2392514935226 [[],[.left],[],[.under,.left]] .sourceHead = true := by decide
def e2392514935274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2392514935274 : Closed e2392514935274 ∧ code e2392514935274 = 11188607957482 := by decide
theorem cert_e2392514935274 : check e2392514935274 [[],[.left],[],[.under,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2392514935406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2392514935406 : Closed e2392514935406 ∧ code e2392514935406 = 11188607957614 := by decide
theorem cert_e2392514935406 : check e2392514935406 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514935418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2392514935418 : Closed e2392514935418 ∧ code e2392514935418 = 11188607957626 := by decide
theorem cert_e2392514935418 : check e2392514935418 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514935706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392514935706 : Closed e2392514935706 ∧ code e2392514935706 = 11188607957914 := by decide
theorem cert_e2392514935706 : check e2392514935706 [[],[.left],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2392514936022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2392514936022 : Closed e2392514936022 ∧ code e2392514936022 = 11188607958230 := by decide
theorem cert_e2392514936022 : check e2392514936022 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514936026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2392514936026 : Closed e2392514936026 ∧ code e2392514936026 = 11188607958234 := by decide
theorem cert_e2392514936026 : check e2392514936026 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514936042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2392514936042 : Closed e2392514936042 ∧ code e2392514936042 = 11188607958250 := by decide
theorem cert_e2392514936042 : check e2392514936042 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514936118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2392514936118 : Closed e2392514936118 ∧ code e2392514936118 = 11188607958326 := by decide
theorem cert_e2392514936118 : check e2392514936118 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514936122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2392514936122 : Closed e2392514936122 ∧ code e2392514936122 = 11188607958330 := by decide
theorem cert_e2392514936122 : check e2392514936122 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514936218 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2392514936218 : Closed e2392514936218 ∧ code e2392514936218 = 11188607958426 := by decide
theorem cert_e2392514936218 : check e2392514936218 [[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2392514939758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392514939758 : Closed e2392514939758 ∧ code e2392514939758 = 11188607961966 := by decide
theorem cert_e2392514939758 : check e2392514939758 [[],[.left],[]] .sourceHead = true := by decide
def e2392514939766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392514939766 : Closed e2392514939766 ∧ code e2392514939766 = 11188607961974 := by decide
theorem cert_e2392514939766 : check e2392514939766 [[],[.left],[]] .sourceHead = true := by decide
def e2392514939822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392514939822 : Closed e2392514939822 ∧ code e2392514939822 = 11188607962030 := by decide
theorem cert_e2392514939822 : check e2392514939822 [[],[.left],[]] .sourceHead = true := by decide
def e2392514939834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392514939834 : Closed e2392514939834 ∧ code e2392514939834 = 11188607962042 := by decide
theorem cert_e2392514939834 : check e2392514939834 [[],[.left],[]] .sourceHead = true := by decide
def e2392514939862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392514939862 : Closed e2392514939862 ∧ code e2392514939862 = 11188607962070 := by decide
theorem cert_e2392514939862 : check e2392514939862 [[],[.left],[]] .sourceHead = true := by decide
def e2392514939866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392514939866 : Closed e2392514939866 ∧ code e2392514939866 = 11188607962074 := by decide
theorem cert_e2392514939866 : check e2392514939866 [[],[.left],[]] .sourceHead = true := by decide
def e2392514940142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392514940142 : Closed e2392514940142 ∧ code e2392514940142 = 11188607962350 := by decide
theorem cert_e2392514940142 : check e2392514940142 [[],[.left],[]] .sourceHead = true := by decide
def e2392514940150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392514940150 : Closed e2392514940150 ∧ code e2392514940150 = 11188607962358 := by decide
theorem cert_e2392514940150 : check e2392514940150 [[],[.left],[]] .sourceHead = true := by decide
def e2392514940526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392514940526 : Closed e2392514940526 ∧ code e2392514940526 = 11188607962734 := by decide
theorem cert_e2392514940526 : check e2392514940526 [[],[.left],[]] .sourceHead = true := by decide
def e2392514940538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392514940538 : Closed e2392514940538 ∧ code e2392514940538 = 11188607962746 := by decide
theorem cert_e2392514940538 : check e2392514940538 [[],[.left],[]] .sourceHead = true := by decide
def e2392514940726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2392514940726 : Closed e2392514940726 ∧ code e2392514940726 = 11188607962934 := by decide
theorem cert_e2392514940726 : check e2392514940726 [[],[.left],[]] .sourceHead = true := by decide
def e2392514940730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2392514940730 : Closed e2392514940730 ∧ code e2392514940730 = 11188607962938 := by decide
theorem cert_e2392514940730 : check e2392514940730 [[],[.left],[]] .sourceHead = true := by decide
def e2392514946478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2392514946478 : Closed e2392514946478 ∧ code e2392514946478 = 11188607968686 := by decide
theorem cert_e2392514946478 : check e2392514946478 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2392514946490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2392514946490 : Closed e2392514946490 ∧ code e2392514946490 = 11188607968698 := by decide
theorem cert_e2392514946490 : check e2392514946490 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2392514946538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2392514946538 : Closed e2392514946538 ∧ code e2392514946538 = 11188607968746 := by decide
theorem cert_e2392514946538 : check e2392514946538 [[],[.left],[],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2392514946670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2392514946670 : Closed e2392514946670 ∧ code e2392514946670 = 11188607968878 := by decide
theorem cert_e2392514946670 : check e2392514946670 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2392514946682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2392514946682 : Closed e2392514946682 ∧ code e2392514946682 = 11188607968890 := by decide
theorem cert_e2392514946682 : check e2392514946682 [[],[.left],[],[.under]] .sourceHead = true := by decide
def e2392514946970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2392514946970 : Closed e2392514946970 ∧ code e2392514946970 = 11188607969178 := by decide
theorem cert_e2392514946970 : check e2392514946970 [[],[.left],[],[.under],[.under,.left],[.under]] .chain = true := by decide
def e2392514949846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2392514949846 : Closed e2392514949846 ∧ code e2392514949846 = 11188607972054 := by decide
theorem cert_e2392514949846 : check e2392514949846 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392514949850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2392514949850 : Closed e2392514949850 ∧ code e2392514949850 = 11188607972058 := by decide
theorem cert_e2392514949850 : check e2392514949850 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392514949866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2392514949866 : Closed e2392514949866 ∧ code e2392514949866 = 11188607972074 := by decide
theorem cert_e2392514949866 : check e2392514949866 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392514949942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2392514949942 : Closed e2392514949942 ∧ code e2392514949942 = 11188607972150 := by decide
theorem cert_e2392514949942 : check e2392514949942 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392514949946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2392514949946 : Closed e2392514949946 ∧ code e2392514949946 = 11188607972154 := by decide
theorem cert_e2392514949946 : check e2392514949946 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392514950042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2392514950042 : Closed e2392514950042 ∧ code e2392514950042 = 11188607972250 := by decide
theorem cert_e2392514950042 : check e2392514950042 [[],[.left],[],[.under]] .smaller = true := by decide
def e2392515087214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2392515087214 : Closed e2392515087214 ∧ code e2392515087214 = 11188608109422 := by decide
private def t_e2392515087214 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392515087214 : ¬ IsSelfInterpreter e2392515087214 :=
  wSource (t := t_e2392515087214) (replay_sound (ps := [[],[.left]]) (t := e2392515087214) (by decide)) (by decide)
def e2392515087222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2392515087222 : Closed e2392515087222 ∧ code e2392515087222 = 11188608109430 := by decide
def e2392515087278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2392515087278 : Closed e2392515087278 ∧ code e2392515087278 = 11188608109486 := by decide
private def t_e2392515087278 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392515087278 : ¬ IsSelfInterpreter e2392515087278 :=
  wSource (t := t_e2392515087278) (replay_sound (ps := [[],[.left]]) (t := e2392515087278) (by decide)) (by decide)
def e2392515087290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2392515087290 : Closed e2392515087290 ∧ code e2392515087290 = 11188608109498 := by decide
def e2392515087318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2392515087318 : Closed e2392515087318 ∧ code e2392515087318 = 11188608109526 := by decide
def e2392515087322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2392515087322 : Closed e2392515087322 ∧ code e2392515087322 = 11188608109530 := by decide
def e2392515087598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2392515087598 : Closed e2392515087598 ∧ code e2392515087598 = 11188608109806 := by decide
def e2392515087606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2392515087606 : Closed e2392515087606 ∧ code e2392515087606 = 11188608109814 := by decide
def e2392515087982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2392515087982 : Closed e2392515087982 ∧ code e2392515087982 = 11188608110190 := by decide
def e2392515087994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2392515087994 : Closed e2392515087994 ∧ code e2392515087994 = 11188608110202 := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392415013818
#print axioms Blc.Floor43.cert_e2392415013850
#print axioms Blc.Floor43.cert_e2392498859546
#print axioms Blc.Floor43.cert_e2392498861594
#print axioms Blc.Floor43.cert_e2392498875930
#print axioms Blc.Floor43.cert_e2392498879002
#print axioms Blc.Floor43.cert_e2392498886170
#print axioms Blc.Floor43.cert_e2392498887194
#print axioms Blc.Floor43.cert_e2392498957850
#print axioms Blc.Floor43.cert_e2392498959898
#print axioms Blc.Floor43.cert_e2392499056154
#print axioms Blc.Floor43.cert_e2392499059226
#print axioms Blc.Floor43.cert_e2392499107354
#print axioms Blc.Floor43.cert_e2392499108378
#print axioms Blc.Floor43.cert_e2392515087214
#print axioms Blc.Floor43.cert_e2392515087278
