import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422364582846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 4)))))))))
theorem wire_e2422364582846 : Closed e2422364582846 ∧ code e2422364582846 = 11218457605054 := by decide
theorem cert_e2422364582846 : check e2422364582846 [[],[]] .three = true := by decide
def e2422364582854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422364582854 : Closed e2422364582854 ∧ code e2422364582854 = 11218457605062 := by decide
theorem cert_e2422364582854 : check e2422364582854 [[],[]] .smaller = true := by decide
def e2422364582902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 4) (.var 1)))))))))
theorem wire_e2422364582902 : Closed e2422364582902 ∧ code e2422364582902 = 11218457605110 := by decide
theorem cert_e2422364582902 : check e2422364582902 [[],[]] .three = true := by decide
def e2422364584382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364584382 : Closed e2422364584382 ∧ code e2422364584382 = 11218457606590 := by decide
theorem cert_e2422364584382 : check e2422364584382 [[],[]] .three = true := by decide
def e2422364584442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364584442 : Closed e2422364584442 ∧ code e2422364584442 = 11218457606650 := by decide
theorem cert_e2422364584442 : check e2422364584442 [[],[]] .three = true := by decide
def e2422364585158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422364585158 : Closed e2422364585158 ∧ code e2422364585158 = 11218457607366 := by decide
theorem cert_e2422364585158 : check e2422364585158 [[],[]] .smaller = true := by decide
def e2422364585782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 5))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364585782 : Closed e2422364585782 ∧ code e2422364585782 = 11218457607990 := by decide
theorem cert_e2422364585782 : check e2422364585782 [[],[]] .three = true := by decide
def e2422364585786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 5))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364585786 : Closed e2422364585786 ∧ code e2422364585786 = 11218457607994 := by decide
theorem cert_e2422364585786 : check e2422364585786 [[],[]] .three = true := by decide
def e2422364592302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2))))))))
theorem wire_e2422364592302 : Closed e2422364592302 ∧ code e2422364592302 = 11218457614510 := by decide
theorem cert_e2422364592302 : check e2422364592302 [[],[]] .smaller = true := by decide
def e2422364592314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0))))))))
theorem wire_e2422364592314 : Closed e2422364592314 ∧ code e2422364592314 = 11218457614522 := by decide
theorem cert_e2422364592314 : check e2422364592314 [[],[]] .smaller = true := by decide
def e2422364592686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422364592686 : Closed e2422364592686 ∧ code e2422364592686 = 11218457614894 := by decide
theorem cert_e2422364592686 : check e2422364592686 [[],[]] .smaller = true := by decide
def e2422364592830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 4))))))))
theorem wire_e2422364592830 : Closed e2422364592830 ∧ code e2422364592830 = 11218457615038 := by decide
theorem cert_e2422364592830 : check e2422364592830 [[],[]] .three = true := by decide
def e2422364592862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 3))))))))
theorem wire_e2422364592862 : Closed e2422364592862 ∧ code e2422364592862 = 11218457615070 := by decide
theorem cert_e2422364592862 : check e2422364592862 [[],[]] .smaller = true := by decide
def e2422364592866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422364592866 : Closed e2422364592866 ∧ code e2422364592866 = 11218457615074 := by decide
theorem cert_e2422364592866 : check e2422364592866 [[],[]] .smaller = true := by decide
def e2422364592878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2))))))))
theorem wire_e2422364592878 : Closed e2422364592878 ∧ code e2422364592878 = 11218457615086 := by decide
theorem cert_e2422364592878 : check e2422364592878 [[],[]] .smaller = true := by decide
def e2422364592886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))) (.var 1))))))))
theorem wire_e2422364592886 : Closed e2422364592886 ∧ code e2422364592886 = 11218457615094 := by decide
theorem cert_e2422364592886 : check e2422364592886 [[],[]] .smaller = true := by decide
def e2422364592890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 4))) (.var 0))))))))
theorem wire_e2422364592890 : Closed e2422364592890 ∧ code e2422364592890 = 11218457615098 := by decide
theorem cert_e2422364592890 : check e2422364592890 [[],[]] .three = true := by decide
def e2422364592990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 3))))))))
theorem wire_e2422364592990 : Closed e2422364592990 ∧ code e2422364592990 = 11218457615198 := by decide
theorem cert_e2422364592990 : check e2422364592990 [[],[]] .smaller = true := by decide
def e2422364593006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2))))))))
theorem wire_e2422364593006 : Closed e2422364593006 ∧ code e2422364593006 = 11218457615214 := by decide
theorem cert_e2422364593006 : check e2422364593006 [[],[]] .smaller = true := by decide
def e2422364593014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1))))))))
theorem wire_e2422364593014 : Closed e2422364593014 ∧ code e2422364593014 = 11218457615222 := by decide
theorem cert_e2422364593014 : check e2422364593014 [[],[]] .smaller = true := by decide
def e2422364593018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 3))) (.var 0))))))))
theorem wire_e2422364593018 : Closed e2422364593018 ∧ code e2422364593018 = 11218457615226 := by decide
theorem cert_e2422364593018 : check e2422364593018 [[],[]] .smaller = true := by decide
def e2422364593034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364593034 : Closed e2422364593034 ∧ code e2422364593034 = 11218457615242 := by decide
theorem cert_e2422364593034 : check e2422364593034 [[],[]] .smaller = true := by decide
def e2422364593058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364593058 : Closed e2422364593058 ∧ code e2422364593058 = 11218457615266 := by decide
theorem cert_e2422364593058 : check e2422364593058 [[],[]] .smaller = true := by decide
def e2422364593070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2))))))))
theorem wire_e2422364593070 : Closed e2422364593070 ∧ code e2422364593070 = 11218457615278 := by decide
theorem cert_e2422364593070 : check e2422364593070 [[],[]] .smaller = true := by decide
def e2422364593078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1))))))))
theorem wire_e2422364593078 : Closed e2422364593078 ∧ code e2422364593078 = 11218457615286 := by decide
theorem cert_e2422364593078 : check e2422364593078 [[],[]] .smaller = true := by decide
def e2422364593082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0))))))))
theorem wire_e2422364593082 : Closed e2422364593082 ∧ code e2422364593082 = 11218457615290 := by decide
theorem cert_e2422364593082 : check e2422364593082 [[],[]] .smaller = true := by decide
def e2422364593110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))) (.var 1))))))))
theorem wire_e2422364593110 : Closed e2422364593110 ∧ code e2422364593110 = 11218457615318 := by decide
theorem cert_e2422364593110 : check e2422364593110 [[],[]] .smaller = true := by decide
def e2422364593114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 1))) (.var 0))))))))
theorem wire_e2422364593114 : Closed e2422364593114 ∧ code e2422364593114 = 11218457615322 := by decide
theorem cert_e2422364593114 : check e2422364593114 [[],[]] .smaller = true := by decide
def e2422364593130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 4)) (.var 0))) (.var 0))))))))
theorem wire_e2422364593130 : Closed e2422364593130 ∧ code e2422364593130 = 11218457615338 := by decide
theorem cert_e2422364593130 : check e2422364593130 [[],[]] .three = true := by decide
def e2422364593502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 3))))))))
theorem wire_e2422364593502 : Closed e2422364593502 ∧ code e2422364593502 = 11218457615710 := by decide
theorem cert_e2422364593502 : check e2422364593502 [[],[]] .smaller = true := by decide
def e2422364593518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e2422364593518 : Closed e2422364593518 ∧ code e2422364593518 = 11218457615726 := by decide
theorem cert_e2422364593518 : check e2422364593518 [[],[]] .smaller = true := by decide
def e2422364593526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e2422364593526 : Closed e2422364593526 ∧ code e2422364593526 = 11218457615734 := by decide
theorem cert_e2422364593526 : check e2422364593526 [[],[]] .smaller = true := by decide
def e2422364593530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 3))) (.var 0))))))))
theorem wire_e2422364593530 : Closed e2422364593530 ∧ code e2422364593530 = 11218457615738 := by decide
theorem cert_e2422364593530 : check e2422364593530 [[],[]] .smaller = true := by decide
def e2422364593582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e2422364593582 : Closed e2422364593582 ∧ code e2422364593582 = 11218457615790 := by decide
theorem cert_e2422364593582 : check e2422364593582 [[],[]] .smaller = true := by decide
def e2422364593594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e2422364593594 : Closed e2422364593594 ∧ code e2422364593594 = 11218457615802 := by decide
theorem cert_e2422364593594 : check e2422364593594 [[],[]] .smaller = true := by decide
def e2422364593622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e2422364593622 : Closed e2422364593622 ∧ code e2422364593622 = 11218457615830 := by decide
theorem cert_e2422364593622 : check e2422364593622 [[],[]] .smaller = true := by decide
def e2422364593626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e2422364593626 : Closed e2422364593626 ∧ code e2422364593626 = 11218457615834 := by decide
theorem cert_e2422364593626 : check e2422364593626 [[],[]] .smaller = true := by decide
def e2422364593642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.var 0))) (.var 0))))))))
theorem wire_e2422364593642 : Closed e2422364593642 ∧ code e2422364593642 = 11218457615850 := by decide
theorem cert_e2422364593642 : check e2422364593642 [[],[]] .smaller = true := by decide
def e2422364593706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0))))))))
theorem wire_e2422364593706 : Closed e2422364593706 ∧ code e2422364593706 = 11218457615914 := by decide
theorem cert_e2422364593706 : check e2422364593706 [[],[]] .smaller = true := by decide
def e2422364593802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422364593802 : Closed e2422364593802 ∧ code e2422364593802 = 11218457616010 := by decide
theorem cert_e2422364593802 : check e2422364593802 [[],[]] .smaller = true := by decide
def e2422364593826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422364593826 : Closed e2422364593826 ∧ code e2422364593826 = 11218457616034 := by decide
theorem cert_e2422364593826 : check e2422364593826 [[],[]] .smaller = true := by decide
def e2422364593838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e2422364593838 : Closed e2422364593838 ∧ code e2422364593838 = 11218457616046 := by decide
theorem cert_e2422364593838 : check e2422364593838 [[],[]] .smaller = true := by decide
def e2422364593846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1))))))))
theorem wire_e2422364593846 : Closed e2422364593846 ∧ code e2422364593846 = 11218457616054 := by decide
theorem cert_e2422364593846 : check e2422364593846 [[],[]] .smaller = true := by decide
def e2422364593850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e2422364593850 : Closed e2422364593850 ∧ code e2422364593850 = 11218457616058 := by decide
theorem cert_e2422364593850 : check e2422364593850 [[],[]] .smaller = true := by decide
def e2422364593878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1))))))))
theorem wire_e2422364593878 : Closed e2422364593878 ∧ code e2422364593878 = 11218457616086 := by decide
theorem cert_e2422364593878 : check e2422364593878 [[],[]] .smaller = true := by decide
def e2422364593882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0))))))))
theorem wire_e2422364593882 : Closed e2422364593882 ∧ code e2422364593882 = 11218457616090 := by decide
theorem cert_e2422364593882 : check e2422364593882 [[],[]] .smaller = true := by decide
def e2422364593898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e2422364593898 : Closed e2422364593898 ∧ code e2422364593898 = 11218457616106 := by decide
theorem cert_e2422364593898 : check e2422364593898 [[],[]] .smaller = true := by decide
def e2422364594006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e2422364594006 : Closed e2422364594006 ∧ code e2422364594006 = 11218457616214 := by decide
theorem cert_e2422364594006 : check e2422364594006 [[],[]] .smaller = true := by decide
def e2422364594010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e2422364594010 : Closed e2422364594010 ∧ code e2422364594010 = 11218457616218 := by decide
theorem cert_e2422364594010 : check e2422364594010 [[],[]] .smaller = true := by decide
def e2422364594026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 3) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e2422364594026 : Closed e2422364594026 ∧ code e2422364594026 = 11218457616234 := by decide
theorem cert_e2422364594026 : check e2422364594026 [[],[]] .smaller = true := by decide
def e2422364594090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 4) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422364594090 : Closed e2422364594090 ∧ code e2422364594090 = 11218457616298 := by decide
theorem cert_e2422364594090 : check e2422364594090 [[],[]] .three = true := by decide
def e2422364594414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2))))))))
theorem wire_e2422364594414 : Closed e2422364594414 ∧ code e2422364594414 = 11218457616622 := by decide
theorem cert_e2422364594414 : check e2422364594414 [[],[]] .smaller = true := by decide
def e2422364594426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0))))))))
theorem wire_e2422364594426 : Closed e2422364594426 ∧ code e2422364594426 = 11218457616634 := by decide
theorem cert_e2422364594426 : check e2422364594426 [[],[]] .smaller = true := by decide
def e2422364594606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2))))))))
theorem wire_e2422364594606 : Closed e2422364594606 ∧ code e2422364594606 = 11218457616814 := by decide
theorem cert_e2422364594606 : check e2422364594606 [[],[]] .smaller = true := by decide
def e2422364594798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364594798 : Closed e2422364594798 ∧ code e2422364594798 = 11218457617006 := by decide
theorem cert_e2422364594798 : check e2422364594798 [[],[]] .smaller = true := by decide
def e2422364594810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364594810 : Closed e2422364594810 ∧ code e2422364594810 = 11218457617018 := by decide
theorem cert_e2422364594810 : check e2422364594810 [[],[]] .smaller = true := by decide
def e2422364594974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3)))))))))
theorem wire_e2422364594974 : Closed e2422364594974 ∧ code e2422364594974 = 11218457617182 := by decide
theorem cert_e2422364594974 : check e2422364594974 [[],[]] .smaller = true := by decide
def e2422364595134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 4))))))))
theorem wire_e2422364595134 : Closed e2422364595134 ∧ code e2422364595134 = 11218457617342 := by decide
theorem cert_e2422364595134 : check e2422364595134 [[],[]] .three = true := by decide
def e2422364595142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1)))))))))
theorem wire_e2422364595142 : Closed e2422364595142 ∧ code e2422364595142 = 11218457617350 := by decide
theorem cert_e2422364595142 : check e2422364595142 [[],[]] .smaller = true := by decide
def e2422364595190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 5)))) (.var 1))))))))
theorem wire_e2422364595190 : Closed e2422364595190 ∧ code e2422364595190 = 11218457617398 := by decide
theorem cert_e2422364595190 : check e2422364595190 [[],[]] .three = true := by decide
def e2422364595758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))))
theorem wire_e2422364595758 : Closed e2422364595758 ∧ code e2422364595758 = 11218457617966 := by decide
theorem cert_e2422364595758 : check e2422364595758 [[],[]] .smaller = true := by decide
def e2422364595902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 4))))))))
theorem wire_e2422364595902 : Closed e2422364595902 ∧ code e2422364595902 = 11218457618110 := by decide
theorem cert_e2422364595902 : check e2422364595902 [[],[]] .three = true := by decide
def e2422364595934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 3))))))))
theorem wire_e2422364595934 : Closed e2422364595934 ∧ code e2422364595934 = 11218457618142 := by decide
theorem cert_e2422364595934 : check e2422364595934 [[],[]] .smaller = true := by decide
def e2422364595938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))))
theorem wire_e2422364595938 : Closed e2422364595938 ∧ code e2422364595938 = 11218457618146 := by decide
theorem cert_e2422364595938 : check e2422364595938 [[],[]] .smaller = true := by decide
def e2422364595950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2))))))))
theorem wire_e2422364595950 : Closed e2422364595950 ∧ code e2422364595950 = 11218457618158 := by decide
theorem cert_e2422364595950 : check e2422364595950 [[],[]] .smaller = true := by decide
def e2422364595958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))) (.var 1))))))))
theorem wire_e2422364595958 : Closed e2422364595958 ∧ code e2422364595958 = 11218457618166 := by decide
theorem cert_e2422364595958 : check e2422364595958 [[],[]] .smaller = true := by decide
def e2422364595962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 4)))) (.var 0))))))))
theorem wire_e2422364595962 : Closed e2422364595962 ∧ code e2422364595962 = 11218457618170 := by decide
theorem cert_e2422364595962 : check e2422364595962 [[],[]] .three = true := by decide
def e2422364596062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 3))))))))
theorem wire_e2422364596062 : Closed e2422364596062 ∧ code e2422364596062 = 11218457618270 := by decide
theorem cert_e2422364596062 : check e2422364596062 [[],[]] .smaller = true := by decide
def e2422364596078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e2422364596078 : Closed e2422364596078 ∧ code e2422364596078 = 11218457618286 := by decide
theorem cert_e2422364596078 : check e2422364596078 [[],[]] .smaller = true := by decide
def e2422364596086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))))
theorem wire_e2422364596086 : Closed e2422364596086 ∧ code e2422364596086 = 11218457618294 := by decide
theorem cert_e2422364596086 : check e2422364596086 [[],[]] .smaller = true := by decide
def e2422364596090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e2422364596090 : Closed e2422364596090 ∧ code e2422364596090 = 11218457618298 := by decide
theorem cert_e2422364596090 : check e2422364596090 [[],[]] .smaller = true := by decide
def e2422364596106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422364596106 : Closed e2422364596106 ∧ code e2422364596106 = 11218457618314 := by decide
theorem cert_e2422364596106 : check e2422364596106 [[],[]] .smaller = true := by decide
def e2422364596130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))))
theorem wire_e2422364596130 : Closed e2422364596130 ∧ code e2422364596130 = 11218457618338 := by decide
theorem cert_e2422364596130 : check e2422364596130 [[],[]] .smaller = true := by decide
def e2422364596142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2))))))))
theorem wire_e2422364596142 : Closed e2422364596142 ∧ code e2422364596142 = 11218457618350 := by decide
theorem cert_e2422364596142 : check e2422364596142 [[],[]] .smaller = true := by decide
def e2422364596150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))))
theorem wire_e2422364596150 : Closed e2422364596150 ∧ code e2422364596150 = 11218457618358 := by decide
theorem cert_e2422364596150 : check e2422364596150 [[],[]] .smaller = true := by decide
def e2422364596154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))))))
theorem wire_e2422364596154 : Closed e2422364596154 ∧ code e2422364596154 = 11218457618362 := by decide
theorem cert_e2422364596154 : check e2422364596154 [[],[]] .smaller = true := by decide
def e2422364596182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))) (.var 1))))))))
theorem wire_e2422364596182 : Closed e2422364596182 ∧ code e2422364596182 = 11218457618390 := by decide
theorem cert_e2422364596182 : check e2422364596182 [[],[]] .smaller = true := by decide
def e2422364596186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e2422364596186 : Closed e2422364596186 ∧ code e2422364596186 = 11218457618394 := by decide
theorem cert_e2422364596186 : check e2422364596186 [[],[]] .smaller = true := by decide
def e2422364596202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 4) (.var 0)))) (.var 0))))))))
theorem wire_e2422364596202 : Closed e2422364596202 ∧ code e2422364596202 = 11218457618410 := by decide
theorem cert_e2422364596202 : check e2422364596202 [[],[]] .three = true := by decide
def e2422364596286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4))))))))))
theorem wire_e2422364596286 : Closed e2422364596286 ∧ code e2422364596286 = 11218457618494 := by decide
theorem cert_e2422364596286 : check e2422364596286 [[],[]] .smaller = true := by decide
def e2422364596670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 4)))))))))
theorem wire_e2422364596670 : Closed e2422364596670 ∧ code e2422364596670 = 11218457618878 := by decide
theorem cert_e2422364596670 : check e2422364596670 [[],[]] .three = true := by decide
def e2422364596702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422364596702 : Closed e2422364596702 ∧ code e2422364596702 = 11218457618910 := by decide
theorem cert_e2422364596702 : check e2422364596702 [[],[]] .smaller = true := by decide
def e2422364596706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422364596706 : Closed e2422364596706 ∧ code e2422364596706 = 11218457618914 := by decide
theorem cert_e2422364596706 : check e2422364596706 [[],[]] .smaller = true := by decide
def e2422364596718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422364596718 : Closed e2422364596718 ∧ code e2422364596718 = 11218457618926 := by decide
theorem cert_e2422364596718 : check e2422364596718 [[],[]] .smaller = true := by decide
def e2422364596726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422364596726 : Closed e2422364596726 ∧ code e2422364596726 = 11218457618934 := by decide
theorem cert_e2422364596726 : check e2422364596726 [[],[]] .smaller = true := by decide
def e2422364596730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 4) (.var 0)))))))))
theorem wire_e2422364596730 : Closed e2422364596730 ∧ code e2422364596730 = 11218457618938 := by decide
theorem cert_e2422364596730 : check e2422364596730 [[],[]] .three = true := by decide
def e2422364597374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 5)))))))))
theorem wire_e2422364597374 : Closed e2422364597374 ∧ code e2422364597374 = 11218457619582 := by decide
theorem cert_e2422364597374 : check e2422364597374 [[],[]] .three = true := by decide
def e2422364597470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364597470 : Closed e2422364597470 ∧ code e2422364597470 = 11218457619678 := by decide
theorem cert_e2422364597470 : check e2422364597470 [[],[]] .smaller = true := by decide
def e2422364597486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364597486 : Closed e2422364597486 ∧ code e2422364597486 = 11218457619694 := by decide
theorem cert_e2422364597486 : check e2422364597486 [[],[]] .smaller = true := by decide
def e2422364597494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364597494 : Closed e2422364597494 ∧ code e2422364597494 = 11218457619702 := by decide
theorem cert_e2422364597494 : check e2422364597494 [[],[]] .smaller = true := by decide
def e2422364597498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364597498 : Closed e2422364597498 ∧ code e2422364597498 = 11218457619706 := by decide
theorem cert_e2422364597498 : check e2422364597498 [[],[]] .smaller = true := by decide
def e2422364597774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364597774 : Closed e2422364597774 ∧ code e2422364597774 = 11218457619982 := by decide
theorem cert_e2422364597774 : check e2422364597774 [[],[]] .smaller = true := by decide
def e2422364597786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364597786 : Closed e2422364597786 ∧ code e2422364597786 = 11218457619994 := by decide
theorem cert_e2422364597786 : check e2422364597786 [[],[]] .smaller = true := by decide
def e2422364597858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364597858 : Closed e2422364597858 ∧ code e2422364597858 = 11218457620066 := by decide
theorem cert_e2422364597858 : check e2422364597858 [[],[]] .smaller = true := by decide
def e2422364597870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364597870 : Closed e2422364597870 ∧ code e2422364597870 = 11218457620078 := by decide
theorem cert_e2422364597870 : check e2422364597870 [[],[]] .smaller = true := by decide
def e2422364597878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364597878 : Closed e2422364597878 ∧ code e2422364597878 = 11218457620086 := by decide
theorem cert_e2422364597878 : check e2422364597878 [[],[]] .smaller = true := by decide
def e2422364597882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364597882 : Closed e2422364597882 ∧ code e2422364597882 = 11218457620090 := by decide
theorem cert_e2422364597882 : check e2422364597882 [[],[]] .smaller = true := by decide
def e2422364598070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364598070 : Closed e2422364598070 ∧ code e2422364598070 = 11218457620278 := by decide
theorem cert_e2422364598070 : check e2422364598070 [[],[]] .smaller = true := by decide
def e2422364598074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364598074 : Closed e2422364598074 ∧ code e2422364598074 = 11218457620282 := by decide
theorem cert_e2422364598074 : check e2422364598074 [[],[]] .smaller = true := by decide
def e2422364598158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.lam (.var 2)))))))))
theorem wire_e2422364598158 : Closed e2422364598158 ∧ code e2422364598158 = 11218457620366 := by decide
theorem cert_e2422364598158 : check e2422364598158 [[],[]] .three = true := by decide
def e2422364598170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364598170 : Closed e2422364598170 ∧ code e2422364598170 = 11218457620378 := by decide
theorem cert_e2422364598170 : check e2422364598170 [[],[]] .three = true := by decide
def e2422364598206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 4))))))))
theorem wire_e2422364598206 : Closed e2422364598206 ∧ code e2422364598206 = 11218457620414 := by decide
theorem cert_e2422364598206 : check e2422364598206 [[],[]] .three = true := by decide
def e2422364598718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 4))))))))
theorem wire_e2422364598718 : Closed e2422364598718 ∧ code e2422364598718 = 11218457620926 := by decide
theorem cert_e2422364598718 : check e2422364598718 [[],[]] .three = true := by decide
def e2422364598778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 5)))) (.var 0))))))))
theorem wire_e2422364598778 : Closed e2422364598778 ∧ code e2422364598778 = 11218457620986 := by decide
theorem cert_e2422364598778 : check e2422364598778 [[],[]] .three = true := by decide
def e2422364599134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 3))))))))
theorem wire_e2422364599134 : Closed e2422364599134 ∧ code e2422364599134 = 11218457621342 := by decide
theorem cert_e2422364599134 : check e2422364599134 [[],[]] .smaller = true := by decide
def e2422364599150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e2422364599150 : Closed e2422364599150 ∧ code e2422364599150 = 11218457621358 := by decide
theorem cert_e2422364599150 : check e2422364599150 [[],[]] .smaller = true := by decide
def e2422364599158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e2422364599158 : Closed e2422364599158 ∧ code e2422364599158 = 11218457621366 := by decide
theorem cert_e2422364599158 : check e2422364599158 [[],[]] .smaller = true := by decide
def e2422364599162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e2422364599162 : Closed e2422364599162 ∧ code e2422364599162 = 11218457621370 := by decide
theorem cert_e2422364599162 : check e2422364599162 [[],[]] .smaller = true := by decide
def e2422364599214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e2422364599214 : Closed e2422364599214 ∧ code e2422364599214 = 11218457621422 := by decide
theorem cert_e2422364599214 : check e2422364599214 [[],[]] .smaller = true := by decide
def e2422364599226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e2422364599226 : Closed e2422364599226 ∧ code e2422364599226 = 11218457621434 := by decide
theorem cert_e2422364599226 : check e2422364599226 [[],[]] .smaller = true := by decide
def e2422364599254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e2422364599254 : Closed e2422364599254 ∧ code e2422364599254 = 11218457621462 := by decide
theorem cert_e2422364599254 : check e2422364599254 [[],[]] .smaller = true := by decide
def e2422364599258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e2422364599258 : Closed e2422364599258 ∧ code e2422364599258 = 11218457621466 := by decide
theorem cert_e2422364599258 : check e2422364599258 [[],[]] .smaller = true := by decide
def e2422364599274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e2422364599274 : Closed e2422364599274 ∧ code e2422364599274 = 11218457621482 := by decide
theorem cert_e2422364599274 : check e2422364599274 [[],[]] .smaller = true := by decide
def e2422364599422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 5)))))))))
theorem wire_e2422364599422 : Closed e2422364599422 ∧ code e2422364599422 = 11218457621630 := by decide
theorem cert_e2422364599422 : check e2422364599422 [[],[]] .three = true := by decide
def e2422364599518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422364599518 : Closed e2422364599518 ∧ code e2422364599518 = 11218457621726 := by decide
theorem cert_e2422364599518 : check e2422364599518 [[],[]] .smaller = true := by decide
def e2422364599534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422364599534 : Closed e2422364599534 ∧ code e2422364599534 = 11218457621742 := by decide
theorem cert_e2422364599534 : check e2422364599534 [[],[]] .smaller = true := by decide
def e2422364599542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422364599542 : Closed e2422364599542 ∧ code e2422364599542 = 11218457621750 := by decide
theorem cert_e2422364599542 : check e2422364599542 [[],[]] .smaller = true := by decide
def e2422364599546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422364599546 : Closed e2422364599546 ∧ code e2422364599546 = 11218457621754 := by decide
theorem cert_e2422364599546 : check e2422364599546 [[],[]] .smaller = true := by decide
def e2422364599918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364599918 : Closed e2422364599918 ∧ code e2422364599918 = 11218457622126 := by decide
theorem cert_e2422364599918 : check e2422364599918 [[],[]] .smaller = true := by decide
def e2422364599930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364599930 : Closed e2422364599930 ∧ code e2422364599930 = 11218457622138 := by decide
theorem cert_e2422364599930 : check e2422364599930 [[],[]] .smaller = true := by decide
def e2422364600118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364600118 : Closed e2422364600118 ∧ code e2422364600118 = 11218457622326 := by decide
theorem cert_e2422364600118 : check e2422364600118 [[],[]] .smaller = true := by decide
def e2422364600122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364600122 : Closed e2422364600122 ∧ code e2422364600122 = 11218457622330 := by decide
theorem cert_e2422364600122 : check e2422364600122 [[],[]] .smaller = true := by decide
def e2422364600218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364600218 : Closed e2422364600218 ∧ code e2422364600218 = 11218457622426 := by decide
theorem cert_e2422364600218 : check e2422364600218 [[],[]] .smaller = true := by decide
def e2422364600254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 4))))))))
theorem wire_e2422364600254 : Closed e2422364600254 ∧ code e2422364600254 = 11218457622462 := by decide
theorem cert_e2422364600254 : check e2422364600254 [[],[]] .three = true := by decide
def e2422364600262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 4))) (.lam (.var 1)))))))))
theorem wire_e2422364600262 : Closed e2422364600262 ∧ code e2422364600262 = 11218457622470 := by decide
theorem cert_e2422364600262 : check e2422364600262 [[],[]] .three = true := by decide
def e2422364600286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 4))) (.var 3))))))))
theorem wire_e2422364600286 : Closed e2422364600286 ∧ code e2422364600286 = 11218457622494 := by decide
theorem cert_e2422364600286 : check e2422364600286 [[],[]] .three = true := by decide
def e2422364600378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0))))))))
theorem wire_e2422364600378 : Closed e2422364600378 ∧ code e2422364600378 = 11218457622586 := by decide
theorem cert_e2422364600378 : check e2422364600378 [[],[]] .smaller = true := by decide
def e2422364600426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))))
theorem wire_e2422364600426 : Closed e2422364600426 ∧ code e2422364600426 = 11218457622634 := by decide
theorem cert_e2422364600426 : check e2422364600426 [[],[]] .smaller = true := by decide
def e2422364600474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364600474 : Closed e2422364600474 ∧ code e2422364600474 = 11218457622682 := by decide
theorem cert_e2422364600474 : check e2422364600474 [[],[]] .smaller = true := by decide
def e2422364600518 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1)))))))))
theorem wire_e2422364600518 : Closed e2422364600518 ∧ code e2422364600518 = 11218457622726 := by decide
theorem cert_e2422364600518 : check e2422364600518 [[],[]] .smaller = true := by decide
def e2422364600714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422364600714 : Closed e2422364600714 ∧ code e2422364600714 = 11218457622922 := by decide
theorem cert_e2422364600714 : check e2422364600714 [[],[]] .smaller = true := by decide
def e2422364600738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))))
theorem wire_e2422364600738 : Closed e2422364600738 ∧ code e2422364600738 = 11218457622946 := by decide
theorem cert_e2422364600738 : check e2422364600738 [[],[]] .smaller = true := by decide
def e2422364600750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422364600750 : Closed e2422364600750 ∧ code e2422364600750 = 11218457622958 := by decide
theorem cert_e2422364600750 : check e2422364600750 [[],[]] .smaller = true := by decide
def e2422364600758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422364600758 : Closed e2422364600758 ∧ code e2422364600758 = 11218457622966 := by decide
theorem cert_e2422364600758 : check e2422364600758 [[],[]] .smaller = true := by decide
def e2422364600762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422364600762 : Closed e2422364600762 ∧ code e2422364600762 = 11218457622970 := by decide
theorem cert_e2422364600762 : check e2422364600762 [[],[]] .smaller = true := by decide
def e2422364600790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422364600790 : Closed e2422364600790 ∧ code e2422364600790 = 11218457622998 := by decide
theorem cert_e2422364600790 : check e2422364600790 [[],[]] .smaller = true := by decide
def e2422364600794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e2422364600794 : Closed e2422364600794 ∧ code e2422364600794 = 11218457623002 := by decide
theorem cert_e2422364600794 : check e2422364600794 [[],[]] .smaller = true := by decide
def e2422364600810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422364600810 : Closed e2422364600810 ∧ code e2422364600810 = 11218457623018 := by decide
theorem cert_e2422364600810 : check e2422364600810 [[],[]] .smaller = true := by decide
def e2422364600846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2))))))))))
theorem wire_e2422364600846 : Closed e2422364600846 ∧ code e2422364600846 = 11218457623054 := by decide
theorem cert_e2422364600846 : check e2422364600846 [[],[]] .smaller = true := by decide
def e2422364600858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422364600858 : Closed e2422364600858 ∧ code e2422364600858 = 11218457623066 := by decide
theorem cert_e2422364600858 : check e2422364600858 [[],[]] .smaller = true := by decide
def e2422364600930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422364600930 : Closed e2422364600930 ∧ code e2422364600930 = 11218457623138 := by decide
theorem cert_e2422364600930 : check e2422364600930 [[],[]] .smaller = true := by decide
def e2422364600942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422364600942 : Closed e2422364600942 ∧ code e2422364600942 = 11218457623150 := by decide
theorem cert_e2422364600942 : check e2422364600942 [[],[]] .smaller = true := by decide
def e2422364600950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))))
theorem wire_e2422364600950 : Closed e2422364600950 ∧ code e2422364600950 = 11218457623158 := by decide
theorem cert_e2422364600950 : check e2422364600950 [[],[]] .smaller = true := by decide
def e2422364600954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422364600954 : Closed e2422364600954 ∧ code e2422364600954 = 11218457623162 := by decide
theorem cert_e2422364600954 : check e2422364600954 [[],[]] .smaller = true := by decide
def e2422364601142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364601142 : Closed e2422364601142 ∧ code e2422364601142 = 11218457623350 := by decide
theorem cert_e2422364601142 : check e2422364601142 [[],[]] .smaller = true := by decide
def e2422364601146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364601146 : Closed e2422364601146 ∧ code e2422364601146 = 11218457623354 := by decide
theorem cert_e2422364601146 : check e2422364601146 [[],[]] .smaller = true := by decide
def e2422364601242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364601242 : Closed e2422364601242 ∧ code e2422364601242 = 11218457623450 := by decide
theorem cert_e2422364601242 : check e2422364601242 [[],[]] .smaller = true := by decide
def e2422364601278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 4))))))))
theorem wire_e2422364601278 : Closed e2422364601278 ∧ code e2422364601278 = 11218457623486 := by decide
theorem cert_e2422364601278 : check e2422364601278 [[],[]] .three = true := by decide
def e2422364601310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 3))))))))
theorem wire_e2422364601310 : Closed e2422364601310 ∧ code e2422364601310 = 11218457623518 := by decide
theorem cert_e2422364601310 : check e2422364601310 [[],[]] .smaller = true := by decide
def e2422364601326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 4))) (.var 2))))))))
theorem wire_e2422364601326 : Closed e2422364601326 ∧ code e2422364601326 = 11218457623534 := by decide
theorem cert_e2422364601326 : check e2422364601326 [[],[]] .three = true := by decide
def e2422364601558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e2422364601558 : Closed e2422364601558 ∧ code e2422364601558 = 11218457623766 := by decide
theorem cert_e2422364601558 : check e2422364601558 [[],[]] .smaller = true := by decide
def e2422364601562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e2422364601562 : Closed e2422364601562 ∧ code e2422364601562 = 11218457623770 := by decide
theorem cert_e2422364601562 : check e2422364601562 [[],[]] .smaller = true := by decide
def e2422364601578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e2422364601578 : Closed e2422364601578 ∧ code e2422364601578 = 11218457623786 := by decide
theorem cert_e2422364601578 : check e2422364601578 [[],[]] .smaller = true := by decide
def e2422364601654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422364601654 : Closed e2422364601654 ∧ code e2422364601654 = 11218457623862 := by decide
theorem cert_e2422364601654 : check e2422364601654 [[],[]] .smaller = true := by decide
def e2422364601658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422364601658 : Closed e2422364601658 ∧ code e2422364601658 = 11218457623866 := by decide
theorem cert_e2422364601658 : check e2422364601658 [[],[]] .smaller = true := by decide
def e2422364601754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422364601754 : Closed e2422364601754 ∧ code e2422364601754 = 11218457623962 := by decide
theorem cert_e2422364601754 : check e2422364601754 [[],[]] .smaller = true := by decide
def e2422364601790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 4))))))))
theorem wire_e2422364601790 : Closed e2422364601790 ∧ code e2422364601790 = 11218457623998 := by decide
theorem cert_e2422364601790 : check e2422364601790 [[],[]] .three = true := by decide
def e2422364601822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 3))))))))
theorem wire_e2422364601822 : Closed e2422364601822 ∧ code e2422364601822 = 11218457624030 := by decide
theorem cert_e2422364601822 : check e2422364601822 [[],[]] .smaller = true := by decide
def e2422364601838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 3))) (.var 2))))))))
theorem wire_e2422364601838 : Closed e2422364601838 ∧ code e2422364601838 = 11218457624046 := by decide
theorem cert_e2422364601838 : check e2422364601838 [[],[]] .smaller = true := by decide
def e2422364601846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 4))) (.var 1))))))))
theorem wire_e2422364601846 : Closed e2422364601846 ∧ code e2422364601846 = 11218457624054 := by decide
theorem cert_e2422364601846 : check e2422364601846 [[],[]] .three = true := by decide
end Blc.Floor43
