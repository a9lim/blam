import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e834096807322 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096807322 : Closed e834096807322 ∧ code e834096807322 = 9630189829530 := by decide
theorem cert_e834096807322 : check e834096807322 [] .sourceHead = true := by decide
def e834096808926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e834096808926 : Closed e834096808926 ∧ code e834096808926 = 9630189831134 := by decide
theorem cert_e834096808926 : check e834096808926 [] .sourceHead = true := by decide
def e834096808942 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e834096808942 : Closed e834096808942 ∧ code e834096808942 = 9630189831150 := by decide
theorem cert_e834096808942 : check e834096808942 [] .sourceHead = true := by decide
def e834096810862 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e834096810862 : Closed e834096810862 ∧ code e834096810862 = 9630189833070 := by decide
theorem cert_e834096810862 : check e834096810862 [] .sourceHead = true := by decide
def e834096810870 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e834096810870 : Closed e834096810870 ∧ code e834096810870 = 9630189833078 := by decide
theorem cert_e834096810870 : check e834096810870 [] .sourceHead = true := by decide
def e834096810926 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e834096810926 : Closed e834096810926 ∧ code e834096810926 = 9630189833134 := by decide
theorem cert_e834096810926 : check e834096810926 [] .sourceHead = true := by decide
def e834096810938 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e834096810938 : Closed e834096810938 ∧ code e834096810938 = 9630189833146 := by decide
theorem cert_e834096810938 : check e834096810938 [] .sourceHead = true := by decide
def e834096810966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e834096810966 : Closed e834096810966 ∧ code e834096810966 = 9630189833174 := by decide
theorem cert_e834096810966 : check e834096810966 [] .sourceHead = true := by decide
def e834096810970 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e834096810970 : Closed e834096810970 ∧ code e834096810970 = 9630189833178 := by decide
theorem cert_e834096810970 : check e834096810970 [] .sourceHead = true := by decide
def e834096811246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e834096811246 : Closed e834096811246 ∧ code e834096811246 = 9630189833454 := by decide
theorem cert_e834096811246 : check e834096811246 [] .sourceHead = true := by decide
def e834096811254 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e834096811254 : Closed e834096811254 ∧ code e834096811254 = 9630189833462 := by decide
theorem cert_e834096811254 : check e834096811254 [] .sourceHead = true := by decide
def e834096811630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096811630 : Closed e834096811630 ∧ code e834096811630 = 9630189833838 := by decide
theorem cert_e834096811630 : check e834096811630 [] .sourceHead = true := by decide
def e834096811642 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096811642 : Closed e834096811642 ∧ code e834096811642 = 9630189833850 := by decide
theorem cert_e834096811642 : check e834096811642 [] .sourceHead = true := by decide
def e834096811830 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096811830 : Closed e834096811830 ∧ code e834096811830 = 9630189834038 := by decide
theorem cert_e834096811830 : check e834096811830 [] .sourceHead = true := by decide
def e834096811834 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096811834 : Closed e834096811834 ∧ code e834096811834 = 9630189834042 := by decide
theorem cert_e834096811834 : check e834096811834 [] .sourceHead = true := by decide
def e834096816606 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e834096816606 : Closed e834096816606 ∧ code e834096816606 = 9630189838814 := by decide
theorem cert_e834096816606 : check e834096816606 [] .sourceHead = true := by decide
def e834096816630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e834096816630 : Closed e834096816630 ∧ code e834096816630 = 9630189838838 := by decide
theorem cert_e834096816630 : check e834096816630 [] .sourceHead = true := by decide
def e834096817582 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e834096817582 : Closed e834096817582 ∧ code e834096817582 = 9630189839790 := by decide
theorem cert_e834096817582 : check e834096817582 [] .sourceHead = true := by decide
def e834096817594 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e834096817594 : Closed e834096817594 ∧ code e834096817594 = 9630189839802 := by decide
theorem cert_e834096817594 : check e834096817594 [] .sourceHead = true := by decide
def e834096817642 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e834096817642 : Closed e834096817642 ∧ code e834096817642 = 9630189839850 := by decide
theorem cert_e834096817642 : check e834096817642 [] .sourceHead = true := by decide
def e834096817774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096817774 : Closed e834096817774 ∧ code e834096817774 = 9630189839982 := by decide
theorem cert_e834096817774 : check e834096817774 [] .sourceHead = true := by decide
def e834096817786 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096817786 : Closed e834096817786 ∧ code e834096817786 = 9630189839994 := by decide
theorem cert_e834096817786 : check e834096817786 [] .sourceHead = true := by decide
def e834096817950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e834096817950 : Closed e834096817950 ∧ code e834096817950 = 9630189840158 := by decide
theorem cert_e834096817950 : check e834096817950 [] .sourceHead = true := by decide
def e834096818062 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e834096818062 : Closed e834096818062 ∧ code e834096818062 = 9630189840270 := by decide
theorem cert_e834096818062 : check e834096818062 [] .sourceHead = true := by decide
def e834096818074 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096818074 : Closed e834096818074 ∧ code e834096818074 = 9630189840282 := by decide
theorem cert_e834096818074 : check e834096818074 [] .sourceHead = true := by decide
def e834096820462 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e834096820462 : Closed e834096820462 ∧ code e834096820462 = 9630189842670 := by decide
theorem cert_e834096820462 : check e834096820462 [] .sourceHead = true := by decide
def e834096820470 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e834096820470 : Closed e834096820470 ∧ code e834096820470 = 9630189842678 := by decide
theorem cert_e834096820470 : check e834096820470 [] .sourceHead = true := by decide
def e834096820950 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e834096820950 : Closed e834096820950 ∧ code e834096820950 = 9630189843158 := by decide
theorem cert_e834096820950 : check e834096820950 [] .sourceHead = true := by decide
def e834096820954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e834096820954 : Closed e834096820954 ∧ code e834096820954 = 9630189843162 := by decide
theorem cert_e834096820954 : check e834096820954 [] .sourceHead = true := by decide
def e834096820970 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e834096820970 : Closed e834096820970 ∧ code e834096820970 = 9630189843178 := by decide
theorem cert_e834096820970 : check e834096820970 [] .sourceHead = true := by decide
def e834096821046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096821046 : Closed e834096821046 ∧ code e834096821046 = 9630189843254 := by decide
theorem cert_e834096821046 : check e834096821046 [] .sourceHead = true := by decide
def e834096821050 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096821050 : Closed e834096821050 ∧ code e834096821050 = 9630189843258 := by decide
theorem cert_e834096821050 : check e834096821050 [] .sourceHead = true := by decide
def e834096821134 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e834096821134 : Closed e834096821134 ∧ code e834096821134 = 9630189843342 := by decide
theorem cert_e834096821134 : check e834096821134 [] .sourceHead = true := by decide
def e834096821146 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096821146 : Closed e834096821146 ∧ code e834096821146 = 9630189843354 := by decide
theorem cert_e834096821146 : check e834096821146 [] .sourceHead = true := by decide
def e834096826222 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e834096826222 : Closed e834096826222 ∧ code e834096826222 = 9630189848430 := by decide
theorem cert_e834096826222 : check e834096826222 [] .sourceHead = true := by decide
def e834096826234 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e834096826234 : Closed e834096826234 ∧ code e834096826234 = 9630189848442 := by decide
theorem cert_e834096826234 : check e834096826234 [] .sourceHead = true := by decide
def e834096826330 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e834096826330 : Closed e834096826330 ∧ code e834096826330 = 9630189848538 := by decide
theorem cert_e834096826330 : check e834096826330 [] .sourceHead = true := by decide
def e834096827630 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e834096827630 : Closed e834096827630 ∧ code e834096827630 = 9630189849838 := by decide
theorem cert_e834096827630 : check e834096827630 [] .sourceHead = true := by decide
def e834096827638 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e834096827638 : Closed e834096827638 ∧ code e834096827638 = 9630189849846 := by decide
theorem cert_e834096827638 : check e834096827638 [] .sourceHead = true := by decide
def e834096828014 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e834096828014 : Closed e834096828014 ∧ code e834096828014 = 9630189850222 := by decide
theorem cert_e834096828014 : check e834096828014 [] .sourceHead = true := by decide
def e834096828026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e834096828026 : Closed e834096828026 ∧ code e834096828026 = 9630189850234 := by decide
theorem cert_e834096828026 : check e834096828026 [] .sourceHead = true := by decide
def e834096828214 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096828214 : Closed e834096828214 ∧ code e834096828214 = 9630189850422 := by decide
theorem cert_e834096828214 : check e834096828214 [] .sourceHead = true := by decide
def e834096828218 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096828218 : Closed e834096828218 ∧ code e834096828218 = 9630189850426 := by decide
theorem cert_e834096828218 : check e834096828218 [] .sourceHead = true := by decide
def e834096830126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e834096830126 : Closed e834096830126 ∧ code e834096830126 = 9630189852334 := by decide
theorem cert_e834096830126 : check e834096830126 [] .sourceHead = true := by decide
def e834096830138 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e834096830138 : Closed e834096830138 ∧ code e834096830138 = 9630189852346 := by decide
theorem cert_e834096830138 : check e834096830138 [] .sourceHead = true := by decide
def e834096830186 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e834096830186 : Closed e834096830186 ∧ code e834096830186 = 9630189852394 := by decide
theorem cert_e834096830186 : check e834096830186 [] .sourceHead = true := by decide
def e834096830378 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e834096830378 : Closed e834096830378 ∧ code e834096830378 = 9630189852586 := by decide
theorem cert_e834096830378 : check e834096830378 [] .sourceHead = true := by decide
def e834096830702 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e834096830702 : Closed e834096830702 ∧ code e834096830702 = 9630189852910 := by decide
theorem cert_e834096830702 : check e834096830702 [] .sourceHead = true := by decide
def e834096830710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e834096830710 : Closed e834096830710 ∧ code e834096830710 = 9630189852918 := by decide
theorem cert_e834096830710 : check e834096830710 [] .sourceHead = true := by decide
def e834096830894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e834096830894 : Closed e834096830894 ∧ code e834096830894 = 9630189853102 := by decide
theorem cert_e834096830894 : check e834096830894 [] .sourceHead = true := by decide
def e834096830906 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e834096830906 : Closed e834096830906 ∧ code e834096830906 = 9630189853114 := by decide
theorem cert_e834096830906 : check e834096830906 [] .sourceHead = true := by decide
def e834096830954 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e834096830954 : Closed e834096830954 ∧ code e834096830954 = 9630189853162 := by decide
theorem cert_e834096830954 : check e834096830954 [] .sourceHead = true := by decide
def e834096831086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e834096831086 : Closed e834096831086 ∧ code e834096831086 = 9630189853294 := by decide
theorem cert_e834096831086 : check e834096831086 [] .sourceHead = true := by decide
def e834096831098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e834096831098 : Closed e834096831098 ∧ code e834096831098 = 9630189853306 := by decide
theorem cert_e834096831098 : check e834096831098 [] .sourceHead = true := by decide
def e834096831262 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e834096831262 : Closed e834096831262 ∧ code e834096831262 = 9630189853470 := by decide
theorem cert_e834096831262 : check e834096831262 [] .sourceHead = true := by decide
def e834096831374 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e834096831374 : Closed e834096831374 ∧ code e834096831374 = 9630189853582 := by decide
theorem cert_e834096831374 : check e834096831374 [] .sourceHead = true := by decide
def e834096831386 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096831386 : Closed e834096831386 ∧ code e834096831386 = 9630189853594 := by decide
theorem cert_e834096831386 : check e834096831386 [] .sourceHead = true := by decide
def e834096831598 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e834096831598 : Closed e834096831598 ∧ code e834096831598 = 9630189853806 := by decide
theorem cert_e834096831598 : check e834096831598 [] .sourceHead = true := by decide
def e834096831610 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e834096831610 : Closed e834096831610 ∧ code e834096831610 = 9630189853818 := by decide
theorem cert_e834096831610 : check e834096831610 [] .sourceHead = true := by decide
def e834096831774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e834096831774 : Closed e834096831774 ∧ code e834096831774 = 9630189853982 := by decide
theorem cert_e834096831774 : check e834096831774 [] .sourceHead = true := by decide
def e834096831942 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e834096831942 : Closed e834096831942 ∧ code e834096831942 = 9630189854150 := by decide
theorem cert_e834096831942 : check e834096831942 [] .sourceHead = true := by decide
def e834096832054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e834096832054 : Closed e834096832054 ∧ code e834096832054 = 9630189854262 := by decide
theorem cert_e834096832054 : check e834096832054 [] .sourceHead = true := by decide
def e834096832058 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e834096832058 : Closed e834096832058 ∧ code e834096832058 = 9630189854266 := by decide
theorem cert_e834096832058 : check e834096832058 [] .sourceHead = true := by decide
def e834096832106 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e834096832106 : Closed e834096832106 ∧ code e834096832106 = 9630189854314 := by decide
theorem cert_e834096832106 : check e834096832106 [] .sourceHead = true := by decide
def e834096832142 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e834096832142 : Closed e834096832142 ∧ code e834096832142 = 9630189854350 := by decide
theorem cert_e834096832142 : check e834096832142 [] .sourceHead = true := by decide
def e834096832154 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096832154 : Closed e834096832154 ∧ code e834096832154 = 9630189854362 := by decide
theorem cert_e834096832154 : check e834096832154 [] .sourceHead = true := by decide
def e834096832198 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e834096832198 : Closed e834096832198 ∧ code e834096832198 = 9630189854406 := by decide
theorem cert_e834096832198 : check e834096832198 [] .sourceHead = true := by decide
def e834096832990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e834096832990 : Closed e834096832990 ∧ code e834096832990 = 9630189855198 := by decide
theorem cert_e834096832990 : check e834096832990 [] .sourceHead = true := by decide
def e834096833014 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e834096833014 : Closed e834096833014 ∧ code e834096833014 = 9630189855222 := by decide
theorem cert_e834096833014 : check e834096833014 [] .sourceHead = true := by decide
def e834096833966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e834096833966 : Closed e834096833966 ∧ code e834096833966 = 9630189856174 := by decide
theorem cert_e834096833966 : check e834096833966 [] .sourceHead = true := by decide
def e834096833978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e834096833978 : Closed e834096833978 ∧ code e834096833978 = 9630189856186 := by decide
theorem cert_e834096833978 : check e834096833978 [] .sourceHead = true := by decide
def e834096834026 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e834096834026 : Closed e834096834026 ∧ code e834096834026 = 9630189856234 := by decide
theorem cert_e834096834026 : check e834096834026 [] .sourceHead = true := by decide
def e834096834158 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096834158 : Closed e834096834158 ∧ code e834096834158 = 9630189856366 := by decide
theorem cert_e834096834158 : check e834096834158 [] .sourceHead = true := by decide
def e834096834170 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096834170 : Closed e834096834170 ∧ code e834096834170 = 9630189856378 := by decide
theorem cert_e834096834170 : check e834096834170 [] .sourceHead = true := by decide
def e834096834334 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e834096834334 : Closed e834096834334 ∧ code e834096834334 = 9630189856542 := by decide
theorem cert_e834096834334 : check e834096834334 [] .sourceHead = true := by decide
def e834096834446 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e834096834446 : Closed e834096834446 ∧ code e834096834446 = 9630189856654 := by decide
theorem cert_e834096834446 : check e834096834446 [] .sourceHead = true := by decide
def e834096834458 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096834458 : Closed e834096834458 ∧ code e834096834458 = 9630189856666 := by decide
theorem cert_e834096834458 : check e834096834458 [] .sourceHead = true := by decide
def e834096837406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e834096837406 : Closed e834096837406 ∧ code e834096837406 = 9630189859614 := by decide
theorem cert_e834096837406 : check e834096837406 [] .sourceHead = true := by decide
def e834096837574 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e834096837574 : Closed e834096837574 ∧ code e834096837574 = 9630189859782 := by decide
theorem cert_e834096837574 : check e834096837574 [] .sourceHead = true := by decide
def e834096838774 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e834096838774 : Closed e834096838774 ∧ code e834096838774 = 9630189860982 := by decide
theorem cert_e834096838774 : check e834096838774 [] .sourceHead = true := by decide
def e834096839018 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e834096839018 : Closed e834096839018 ∧ code e834096839018 = 9630189861226 := by decide
theorem cert_e834096839018 : check e834096839018 [] .sourceHead = true := by decide
def e834096839054 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e834096839054 : Closed e834096839054 ∧ code e834096839054 = 9630189861262 := by decide
theorem cert_e834096839054 : check e834096839054 [] .sourceHead = true := by decide
def e834096839066 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096839066 : Closed e834096839066 ∧ code e834096839066 = 9630189861274 := by decide
theorem cert_e834096839066 : check e834096839066 [] .sourceHead = true := by decide
def e834096839110 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e834096839110 : Closed e834096839110 ∧ code e834096839110 = 9630189861318 := by decide
theorem cert_e834096839110 : check e834096839110 [] .sourceHead = true := by decide
def e834096841654 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))))
theorem wire_e834096841654 : Closed e834096841654 ∧ code e834096841654 = 9630189863862 := by decide
theorem cert_e834096841654 : check e834096841654 [] .sourceHead = true := by decide
def e834096841658 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e834096841658 : Closed e834096841658 ∧ code e834096841658 = 9630189863866 := by decide
theorem cert_e834096841658 : check e834096841658 [] .sourceHead = true := by decide
def e834096841690 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e834096841690 : Closed e834096841690 ∧ code e834096841690 = 9630189863898 := by decide
theorem cert_e834096841690 : check e834096841690 [] .sourceHead = true := by decide
def e834096842358 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))))
theorem wire_e834096842358 : Closed e834096842358 ∧ code e834096842358 = 9630189864566 := by decide
theorem cert_e834096842358 : check e834096842358 [] .sourceHead = true := by decide
def e834096842550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096842550 : Closed e834096842550 ∧ code e834096842550 = 9630189864758 := by decide
theorem cert_e834096842550 : check e834096842550 [] .sourceHead = true := by decide
def e834096842554 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096842554 : Closed e834096842554 ∧ code e834096842554 = 9630189864762 := by decide
theorem cert_e834096842554 : check e834096842554 [] .sourceHead = true := by decide
def e834096843606 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e834096843606 : Closed e834096843606 ∧ code e834096843606 = 9630189865814 := by decide
theorem cert_e834096843606 : check e834096843606 [] .sourceHead = true := by decide
def e834096843610 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e834096843610 : Closed e834096843610 ∧ code e834096843610 = 9630189865818 := by decide
theorem cert_e834096843610 : check e834096843610 [] .sourceHead = true := by decide
def e834096843626 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e834096843626 : Closed e834096843626 ∧ code e834096843626 = 9630189865834 := by decide
theorem cert_e834096843626 : check e834096843626 [] .sourceHead = true := by decide
def e834096843690 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e834096843690 : Closed e834096843690 ∧ code e834096843690 = 9630189865898 := by decide
theorem cert_e834096843690 : check e834096843690 [] .sourceHead = true := by decide
def e834096843894 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e834096843894 : Closed e834096843894 ∧ code e834096843894 = 9630189866102 := by decide
theorem cert_e834096843894 : check e834096843894 [] .sourceHead = true := by decide
def e834096843990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e834096843990 : Closed e834096843990 ∧ code e834096843990 = 9630189866198 := by decide
theorem cert_e834096843990 : check e834096843990 [] .sourceHead = true := by decide
def e834096843994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e834096843994 : Closed e834096843994 ∧ code e834096843994 = 9630189866202 := by decide
theorem cert_e834096843994 : check e834096843994 [] .sourceHead = true := by decide
def e834096844010 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e834096844010 : Closed e834096844010 ∧ code e834096844010 = 9630189866218 := by decide
theorem cert_e834096844010 : check e834096844010 [] .sourceHead = true := by decide
def e834096844086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e834096844086 : Closed e834096844086 ∧ code e834096844086 = 9630189866294 := by decide
theorem cert_e834096844086 : check e834096844086 [] .sourceHead = true := by decide
def e834096844090 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e834096844090 : Closed e834096844090 ∧ code e834096844090 = 9630189866298 := by decide
theorem cert_e834096844090 : check e834096844090 [] .sourceHead = true := by decide
def e834096844174 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e834096844174 : Closed e834096844174 ∧ code e834096844174 = 9630189866382 := by decide
theorem cert_e834096844174 : check e834096844174 [] .sourceHead = true := by decide
def e834096844186 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096844186 : Closed e834096844186 ∧ code e834096844186 = 9630189866394 := by decide
theorem cert_e834096844186 : check e834096844186 [] .sourceHead = true := by decide
def e834096844342 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e834096844342 : Closed e834096844342 ∧ code e834096844342 = 9630189866550 := by decide
theorem cert_e834096844342 : check e834096844342 [] .sourceHead = true := by decide
def e834096844346 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e834096844346 : Closed e834096844346 ∧ code e834096844346 = 9630189866554 := by decide
theorem cert_e834096844346 : check e834096844346 [] .sourceHead = true := by decide
def e834096844394 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e834096844394 : Closed e834096844394 ∧ code e834096844394 = 9630189866602 := by decide
theorem cert_e834096844394 : check e834096844394 [] .sourceHead = true := by decide
def e834096844430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e834096844430 : Closed e834096844430 ∧ code e834096844430 = 9630189866638 := by decide
theorem cert_e834096844430 : check e834096844430 [] .sourceHead = true := by decide
def e834096844442 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e834096844442 : Closed e834096844442 ∧ code e834096844442 = 9630189866650 := by decide
theorem cert_e834096844442 : check e834096844442 [] .sourceHead = true := by decide
def e834096844486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e834096844486 : Closed e834096844486 ∧ code e834096844486 = 9630189866694 := by decide
theorem cert_e834096844486 : check e834096844486 [] .sourceHead = true := by decide
def e834096845038 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e834096845038 : Closed e834096845038 ∧ code e834096845038 = 9630189867246 := by decide
theorem cert_e834096845038 : check e834096845038 [] .sourceHead = true := by decide
def e834096845046 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e834096845046 : Closed e834096845046 ∧ code e834096845046 = 9630189867254 := by decide
theorem cert_e834096845046 : check e834096845046 [] .sourceHead = true := by decide
def e834096845526 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e834096845526 : Closed e834096845526 ∧ code e834096845526 = 9630189867734 := by decide
theorem cert_e834096845526 : check e834096845526 [] .sourceHead = true := by decide
def e834096845530 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e834096845530 : Closed e834096845530 ∧ code e834096845530 = 9630189867738 := by decide
theorem cert_e834096845530 : check e834096845530 [] .sourceHead = true := by decide
def e834096845546 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e834096845546 : Closed e834096845546 ∧ code e834096845546 = 9630189867754 := by decide
theorem cert_e834096845546 : check e834096845546 [] .sourceHead = true := by decide
def e834096845622 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096845622 : Closed e834096845622 ∧ code e834096845622 = 9630189867830 := by decide
theorem cert_e834096845622 : check e834096845622 [] .sourceHead = true := by decide
def e834096845626 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096845626 : Closed e834096845626 ∧ code e834096845626 = 9630189867834 := by decide
theorem cert_e834096845626 : check e834096845626 [] .sourceHead = true := by decide
def e834096845710 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e834096845710 : Closed e834096845710 ∧ code e834096845710 = 9630189867918 := by decide
theorem cert_e834096845710 : check e834096845710 [] .sourceHead = true := by decide
def e834096845722 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096845722 : Closed e834096845722 ∧ code e834096845722 = 9630189867930 := by decide
theorem cert_e834096845722 : check e834096845722 [] .sourceHead = true := by decide
def e834096846966 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e834096846966 : Closed e834096846966 ∧ code e834096846966 = 9630189869174 := by decide
theorem cert_e834096846966 : check e834096846966 [] .sourceHead = true := by decide
def e834096847210 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e834096847210 : Closed e834096847210 ∧ code e834096847210 = 9630189869418 := by decide
theorem cert_e834096847210 : check e834096847210 [] .sourceHead = true := by decide
def e834096847246 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e834096847246 : Closed e834096847246 ∧ code e834096847246 = 9630189869454 := by decide
theorem cert_e834096847246 : check e834096847246 [] .sourceHead = true := by decide
def e834096847258 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e834096847258 : Closed e834096847258 ∧ code e834096847258 = 9630189869466 := by decide
theorem cert_e834096847258 : check e834096847258 [] .sourceHead = true := by decide
def e834096847302 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e834096847302 : Closed e834096847302 ∧ code e834096847302 = 9630189869510 := by decide
theorem cert_e834096847302 : check e834096847302 [] .sourceHead = true := by decide
def e834096860014 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e834096860014 : Closed e834096860014 ∧ code e834096860014 = 9630189882222 := by decide
theorem cert_e834096860014 : check e834096860014 [] .sourceHead = true := by decide
def e834096860022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e834096860022 : Closed e834096860022 ∧ code e834096860022 = 9630189882230 := by decide
theorem cert_e834096860022 : check e834096860022 [] .sourceHead = true := by decide
def e834096860078 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e834096860078 : Closed e834096860078 ∧ code e834096860078 = 9630189882286 := by decide
theorem cert_e834096860078 : check e834096860078 [] .sourceHead = true := by decide
def e834096860090 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e834096860090 : Closed e834096860090 ∧ code e834096860090 = 9630189882298 := by decide
theorem cert_e834096860090 : check e834096860090 [] .sourceHead = true := by decide
def e834096860118 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e834096860118 : Closed e834096860118 ∧ code e834096860118 = 9630189882326 := by decide
theorem cert_e834096860118 : check e834096860118 [] .sourceHead = true := by decide
def e834096860122 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e834096860122 : Closed e834096860122 ∧ code e834096860122 = 9630189882330 := by decide
theorem cert_e834096860122 : check e834096860122 [] .sourceHead = true := by decide
def e834096860398 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e834096860398 : Closed e834096860398 ∧ code e834096860398 = 9630189882606 := by decide
theorem cert_e834096860398 : check e834096860398 [] .sourceHead = true := by decide
def e834096860406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e834096860406 : Closed e834096860406 ∧ code e834096860406 = 9630189882614 := by decide
theorem cert_e834096860406 : check e834096860406 [] .sourceHead = true := by decide
def e834096860782 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e834096860782 : Closed e834096860782 ∧ code e834096860782 = 9630189882990 := by decide
theorem cert_e834096860782 : check e834096860782 [] .sourceHead = true := by decide
def e834096860794 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e834096860794 : Closed e834096860794 ∧ code e834096860794 = 9630189883002 := by decide
theorem cert_e834096860794 : check e834096860794 [] .sourceHead = true := by decide
def e834096860982 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e834096860982 : Closed e834096860982 ∧ code e834096860982 = 9630189883190 := by decide
theorem cert_e834096860982 : check e834096860982 [] .sourceHead = true := by decide
def e834096860986 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e834096860986 : Closed e834096860986 ∧ code e834096860986 = 9630189883194 := by decide
theorem cert_e834096860986 : check e834096860986 [] .sourceHead = true := by decide
def e834096901486 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e834096901486 : Closed e834096901486 ∧ code e834096901486 = 9630189923694 := by decide
theorem cert_e834096901486 : check e834096901486 [] .sourceHead = true := by decide
def e834096901494 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e834096901494 : Closed e834096901494 ∧ code e834096901494 = 9630189923702 := by decide
theorem cert_e834096901494 : check e834096901494 [] .sourceHead = true := by decide
def e834096901550 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e834096901550 : Closed e834096901550 ∧ code e834096901550 = 9630189923758 := by decide
theorem cert_e834096901550 : check e834096901550 [] .sourceHead = true := by decide
def e834096901562 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e834096901562 : Closed e834096901562 ∧ code e834096901562 = 9630189923770 := by decide
theorem cert_e834096901562 : check e834096901562 [] .sourceHead = true := by decide
def e834096901590 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e834096901590 : Closed e834096901590 ∧ code e834096901590 = 9630189923798 := by decide
theorem cert_e834096901590 : check e834096901590 [] .sourceHead = true := by decide
def e834096901594 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e834096901594 : Closed e834096901594 ∧ code e834096901594 = 9630189923802 := by decide
theorem cert_e834096901594 : check e834096901594 [] .sourceHead = true := by decide
def e834096901806 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e834096901806 : Closed e834096901806 ∧ code e834096901806 = 9630189924014 := by decide
theorem cert_e834096901806 : check e834096901806 [] .sourceHead = true := by decide
def e834096901818 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e834096901818 : Closed e834096901818 ∧ code e834096901818 = 9630189924026 := by decide
theorem cert_e834096901818 : check e834096901818 [] .sourceHead = true := by decide
def e834096901866 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e834096901866 : Closed e834096901866 ∧ code e834096901866 = 9630189924074 := by decide
theorem cert_e834096901866 : check e834096901866 [] .sourceHead = true := by decide
def e834096901974 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e834096901974 : Closed e834096901974 ∧ code e834096901974 = 9630189924182 := by decide
theorem cert_e834096901974 : check e834096901974 [] .sourceHead = true := by decide
def e834096901978 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e834096901978 : Closed e834096901978 ∧ code e834096901978 = 9630189924186 := by decide
theorem cert_e834096901978 : check e834096901978 [] .sourceHead = true := by decide
def e834096901994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e834096901994 : Closed e834096901994 ∧ code e834096901994 = 9630189924202 := by decide
theorem cert_e834096901994 : check e834096901994 [] .sourceHead = true := by decide
def e834096903022 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e834096903022 : Closed e834096903022 ∧ code e834096903022 = 9630189925230 := by decide
theorem cert_e834096903022 : check e834096903022 [] .sourceHead = true := by decide
def e834096903030 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e834096903030 : Closed e834096903030 ∧ code e834096903030 = 9630189925238 := by decide
theorem cert_e834096903030 : check e834096903030 [] .sourceHead = true := by decide
def e834096903086 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e834096903086 : Closed e834096903086 ∧ code e834096903086 = 9630189925294 := by decide
theorem cert_e834096903086 : check e834096903086 [] .sourceHead = true := by decide
def e834096903098 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e834096903098 : Closed e834096903098 ∧ code e834096903098 = 9630189925306 := by decide
theorem cert_e834096903098 : check e834096903098 [] .sourceHead = true := by decide
def e834096903126 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e834096903126 : Closed e834096903126 ∧ code e834096903126 = 9630189925334 := by decide
theorem cert_e834096903126 : check e834096903126 [] .sourceHead = true := by decide
def e834096903130 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e834096903130 : Closed e834096903130 ∧ code e834096903130 = 9630189925338 := by decide
theorem cert_e834096903130 : check e834096903130 [] .sourceHead = true := by decide
def e834096903406 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e834096903406 : Closed e834096903406 ∧ code e834096903406 = 9630189925614 := by decide
theorem cert_e834096903406 : check e834096903406 [] .sourceHead = true := by decide
def e834096903414 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e834096903414 : Closed e834096903414 ∧ code e834096903414 = 9630189925622 := by decide
theorem cert_e834096903414 : check e834096903414 [] .sourceHead = true := by decide
def e834096903790 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e834096903790 : Closed e834096903790 ∧ code e834096903790 = 9630189925998 := by decide
theorem cert_e834096903790 : check e834096903790 [] .sourceHead = true := by decide
def e834096903802 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e834096903802 : Closed e834096903802 ∧ code e834096903802 = 9630189926010 := by decide
theorem cert_e834096903802 : check e834096903802 [] .sourceHead = true := by decide
def e834096903990 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e834096903990 : Closed e834096903990 ∧ code e834096903990 = 9630189926198 := by decide
theorem cert_e834096903990 : check e834096903990 [] .sourceHead = true := by decide
def e834096903994 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e834096903994 : Closed e834096903994 ∧ code e834096903994 = 9630189926202 := by decide
theorem cert_e834096903994 : check e834096903994 [] .sourceHead = true := by decide
def e834096904430 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))))
theorem wire_e834096904430 : Closed e834096904430 ∧ code e834096904430 = 9630189926638 := by decide
theorem cert_e834096904430 : check e834096904430 [] .sourceHead = true := by decide
def e834096904438 : Term := (.lam (.app (.var 0) (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))))
theorem wire_e834096904438 : Closed e834096904438 ∧ code e834096904438 = 9630189926646 := by decide
theorem cert_e834096904438 : check e834096904438 [] .sourceHead = true := by decide
end Blc.Floor43
