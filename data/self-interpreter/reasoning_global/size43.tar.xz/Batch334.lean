import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418335758778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2418335758778 : Closed e2418335758778 ∧ code e2418335758778 = 11214428780986 := by decide
theorem cert_e2418335758778 : check e2418335758778 [[],[]] .chain = true := by decide
def e2418335758826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2418335758826 : Closed e2418335758826 ∧ code e2418335758826 = 11214428781034 := by decide
theorem cert_e2418335758826 : check e2418335758826 [[],[]] .chain = true := by decide
def e2418335758958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2418335758958 : Closed e2418335758958 ∧ code e2418335758958 = 11214428781166 := by decide
theorem cert_e2418335758958 : check e2418335758958 [[],[]] .chain = true := by decide
def e2418335758970 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2418335758970 : Closed e2418335758970 ∧ code e2418335758970 = 11214428781178 := by decide
theorem cert_e2418335758970 : check e2418335758970 [[],[]] .chain = true := by decide
def e2418335759134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2418335759134 : Closed e2418335759134 ∧ code e2418335759134 = 11214428781342 := by decide
theorem cert_e2418335759134 : check e2418335759134 [[],[]] .chain = true := by decide
def e2418335759246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2418335759246 : Closed e2418335759246 ∧ code e2418335759246 = 11214428781454 := by decide
theorem cert_e2418335759246 : check e2418335759246 [[],[]] .chain = true := by decide
def e2418335759258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335759258 : Closed e2418335759258 ∧ code e2418335759258 = 11214428781466 := by decide
theorem cert_e2418335759258 : check e2418335759258 [[],[]] .chain = true := by decide
def e2418335759478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2418335759478 : Closed e2418335759478 ∧ code e2418335759478 = 11214428781686 := by decide
theorem cert_e2418335759478 : check e2418335759478 [[],[]] .chain = true := by decide
def e2418335759574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2418335759574 : Closed e2418335759574 ∧ code e2418335759574 = 11214428781782 := by decide
theorem cert_e2418335759574 : check e2418335759574 [[],[]] .chain = true := by decide
def e2418335759578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2418335759578 : Closed e2418335759578 ∧ code e2418335759578 = 11214428781786 := by decide
theorem cert_e2418335759578 : check e2418335759578 [[],[]] .chain = true := by decide
def e2418335759594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2418335759594 : Closed e2418335759594 ∧ code e2418335759594 = 11214428781802 := by decide
theorem cert_e2418335759594 : check e2418335759594 [[],[]] .chain = true := by decide
def e2418335759670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335759670 : Closed e2418335759670 ∧ code e2418335759670 = 11214428781878 := by decide
theorem cert_e2418335759670 : check e2418335759670 [[],[]] .chain = true := by decide
def e2418335759674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335759674 : Closed e2418335759674 ∧ code e2418335759674 = 11214428781882 := by decide
theorem cert_e2418335759674 : check e2418335759674 [[],[]] .chain = true := by decide
def e2418335759758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2418335759758 : Closed e2418335759758 ∧ code e2418335759758 = 11214428781966 := by decide
theorem cert_e2418335759758 : check e2418335759758 [[],[]] .chain = true := by decide
def e2418335759770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335759770 : Closed e2418335759770 ∧ code e2418335759770 = 11214428781978 := by decide
theorem cert_e2418335759770 : check e2418335759770 [[],[]] .chain = true := by decide
def e2418335761374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2418335761374 : Closed e2418335761374 ∧ code e2418335761374 = 11214428783582 := by decide
theorem cert_e2418335761374 : check e2418335761374 [[],[]] .chain = true := by decide
def e2418335761390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2418335761390 : Closed e2418335761390 ∧ code e2418335761390 = 11214428783598 := by decide
theorem cert_e2418335761390 : check e2418335761390 [[],[]] .chain = true := by decide
def e2418335763310 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418335763310 : Closed e2418335763310 ∧ code e2418335763310 = 11214428785518 := by decide
theorem cert_e2418335763310 : check e2418335763310 [[],[]] .chain = true := by decide
def e2418335763318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418335763318 : Closed e2418335763318 ∧ code e2418335763318 = 11214428785526 := by decide
theorem cert_e2418335763318 : check e2418335763318 [[],[]] .chain = true := by decide
def e2418335763374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418335763374 : Closed e2418335763374 ∧ code e2418335763374 = 11214428785582 := by decide
theorem cert_e2418335763374 : check e2418335763374 [[],[]] .chain = true := by decide
def e2418335763386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418335763386 : Closed e2418335763386 ∧ code e2418335763386 = 11214428785594 := by decide
theorem cert_e2418335763386 : check e2418335763386 [[],[]] .chain = true := by decide
def e2418335763414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418335763414 : Closed e2418335763414 ∧ code e2418335763414 = 11214428785622 := by decide
theorem cert_e2418335763414 : check e2418335763414 [[],[]] .chain = true := by decide
def e2418335763418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418335763418 : Closed e2418335763418 ∧ code e2418335763418 = 11214428785626 := by decide
theorem cert_e2418335763418 : check e2418335763418 [[],[]] .chain = true := by decide
def e2418335763694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418335763694 : Closed e2418335763694 ∧ code e2418335763694 = 11214428785902 := by decide
theorem cert_e2418335763694 : check e2418335763694 [[],[]] .chain = true := by decide
def e2418335763702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418335763702 : Closed e2418335763702 ∧ code e2418335763702 = 11214428785910 := by decide
theorem cert_e2418335763702 : check e2418335763702 [[],[]] .chain = true := by decide
def e2418335764078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335764078 : Closed e2418335764078 ∧ code e2418335764078 = 11214428786286 := by decide
theorem cert_e2418335764078 : check e2418335764078 [[],[]] .chain = true := by decide
def e2418335764090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335764090 : Closed e2418335764090 ∧ code e2418335764090 = 11214428786298 := by decide
theorem cert_e2418335764090 : check e2418335764090 [[],[]] .chain = true := by decide
def e2418335764278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335764278 : Closed e2418335764278 ∧ code e2418335764278 = 11214428786486 := by decide
theorem cert_e2418335764278 : check e2418335764278 [[],[]] .chain = true := by decide
def e2418335764282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335764282 : Closed e2418335764282 ∧ code e2418335764282 = 11214428786490 := by decide
theorem cert_e2418335764282 : check e2418335764282 [[],[]] .chain = true := by decide
def e2418335769054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2418335769054 : Closed e2418335769054 ∧ code e2418335769054 = 11214428791262 := by decide
theorem cert_e2418335769054 : check e2418335769054 [[],[]] .chain = true := by decide
def e2418335769078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2418335769078 : Closed e2418335769078 ∧ code e2418335769078 = 11214428791286 := by decide
theorem cert_e2418335769078 : check e2418335769078 [[],[]] .chain = true := by decide
def e2418335770030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2418335770030 : Closed e2418335770030 ∧ code e2418335770030 = 11214428792238 := by decide
theorem cert_e2418335770030 : check e2418335770030 [[],[]] .chain = true := by decide
def e2418335770042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2418335770042 : Closed e2418335770042 ∧ code e2418335770042 = 11214428792250 := by decide
theorem cert_e2418335770042 : check e2418335770042 [[],[]] .chain = true := by decide
def e2418335770090 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2418335770090 : Closed e2418335770090 ∧ code e2418335770090 = 11214428792298 := by decide
theorem cert_e2418335770090 : check e2418335770090 [[],[]] .chain = true := by decide
def e2418335770222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335770222 : Closed e2418335770222 ∧ code e2418335770222 = 11214428792430 := by decide
theorem cert_e2418335770222 : check e2418335770222 [[],[]] .chain = true := by decide
def e2418335770234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335770234 : Closed e2418335770234 ∧ code e2418335770234 = 11214428792442 := by decide
theorem cert_e2418335770234 : check e2418335770234 [[],[]] .chain = true := by decide
def e2418335770398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2418335770398 : Closed e2418335770398 ∧ code e2418335770398 = 11214428792606 := by decide
theorem cert_e2418335770398 : check e2418335770398 [[],[]] .chain = true := by decide
def e2418335770510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2418335770510 : Closed e2418335770510 ∧ code e2418335770510 = 11214428792718 := by decide
theorem cert_e2418335770510 : check e2418335770510 [[],[]] .chain = true := by decide
def e2418335770522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335770522 : Closed e2418335770522 ∧ code e2418335770522 = 11214428792730 := by decide
theorem cert_e2418335770522 : check e2418335770522 [[],[]] .chain = true := by decide
def e2418335772910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2418335772910 : Closed e2418335772910 ∧ code e2418335772910 = 11214428795118 := by decide
theorem cert_e2418335772910 : check e2418335772910 [[],[]] .chain = true := by decide
def e2418335772918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2418335772918 : Closed e2418335772918 ∧ code e2418335772918 = 11214428795126 := by decide
theorem cert_e2418335772918 : check e2418335772918 [[],[]] .chain = true := by decide
def e2418335773398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2418335773398 : Closed e2418335773398 ∧ code e2418335773398 = 11214428795606 := by decide
theorem cert_e2418335773398 : check e2418335773398 [[],[]] .chain = true := by decide
def e2418335773402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2418335773402 : Closed e2418335773402 ∧ code e2418335773402 = 11214428795610 := by decide
theorem cert_e2418335773402 : check e2418335773402 [[],[]] .chain = true := by decide
def e2418335773418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2418335773418 : Closed e2418335773418 ∧ code e2418335773418 = 11214428795626 := by decide
theorem cert_e2418335773418 : check e2418335773418 [[],[]] .chain = true := by decide
def e2418335773494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335773494 : Closed e2418335773494 ∧ code e2418335773494 = 11214428795702 := by decide
theorem cert_e2418335773494 : check e2418335773494 [[],[]] .chain = true := by decide
def e2418335773498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335773498 : Closed e2418335773498 ∧ code e2418335773498 = 11214428795706 := by decide
theorem cert_e2418335773498 : check e2418335773498 [[],[]] .chain = true := by decide
def e2418335773582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2418335773582 : Closed e2418335773582 ∧ code e2418335773582 = 11214428795790 := by decide
theorem cert_e2418335773582 : check e2418335773582 [[],[]] .chain = true := by decide
def e2418335773594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335773594 : Closed e2418335773594 ∧ code e2418335773594 = 11214428795802 := by decide
theorem cert_e2418335773594 : check e2418335773594 [[],[]] .chain = true := by decide
def e2418335778670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2418335778670 : Closed e2418335778670 ∧ code e2418335778670 = 11214428800878 := by decide
theorem cert_e2418335778670 : check e2418335778670 [[],[]] .chain = true := by decide
def e2418335778682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))
theorem wire_e2418335778682 : Closed e2418335778682 ∧ code e2418335778682 = 11214428800890 := by decide
theorem cert_e2418335778682 : check e2418335778682 [[],[]] .chain = true := by decide
def e2418335778778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))
theorem wire_e2418335778778 : Closed e2418335778778 ∧ code e2418335778778 = 11214428800986 := by decide
theorem cert_e2418335778778 : check e2418335778778 [[],[]] .chain = true := by decide
def e2418335780078 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2418335780078 : Closed e2418335780078 ∧ code e2418335780078 = 11214428802286 := by decide
theorem cert_e2418335780078 : check e2418335780078 [[],[]] .chain = true := by decide
def e2418335780086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2418335780086 : Closed e2418335780086 ∧ code e2418335780086 = 11214428802294 := by decide
theorem cert_e2418335780086 : check e2418335780086 [[],[]] .chain = true := by decide
def e2418335780462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2418335780462 : Closed e2418335780462 ∧ code e2418335780462 = 11214428802670 := by decide
theorem cert_e2418335780462 : check e2418335780462 [[],[]] .chain = true := by decide
def e2418335780474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2418335780474 : Closed e2418335780474 ∧ code e2418335780474 = 11214428802682 := by decide
theorem cert_e2418335780474 : check e2418335780474 [[],[]] .chain = true := by decide
def e2418335780662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335780662 : Closed e2418335780662 ∧ code e2418335780662 = 11214428802870 := by decide
theorem cert_e2418335780662 : check e2418335780662 [[],[]] .chain = true := by decide
def e2418335780666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335780666 : Closed e2418335780666 ∧ code e2418335780666 = 11214428802874 := by decide
theorem cert_e2418335780666 : check e2418335780666 [[],[]] .chain = true := by decide
def e2418335782574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2418335782574 : Closed e2418335782574 ∧ code e2418335782574 = 11214428804782 := by decide
theorem cert_e2418335782574 : check e2418335782574 [[],[]] .chain = true := by decide
def e2418335782586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2418335782586 : Closed e2418335782586 ∧ code e2418335782586 = 11214428804794 := by decide
theorem cert_e2418335782586 : check e2418335782586 [[],[]] .chain = true := by decide
def e2418335782634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2418335782634 : Closed e2418335782634 ∧ code e2418335782634 = 11214428804842 := by decide
theorem cert_e2418335782634 : check e2418335782634 [[],[]] .chain = true := by decide
def e2418335782826 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2418335782826 : Closed e2418335782826 ∧ code e2418335782826 = 11214428805034 := by decide
theorem cert_e2418335782826 : check e2418335782826 [[],[]] .chain = true := by decide
def e2418335783150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2418335783150 : Closed e2418335783150 ∧ code e2418335783150 = 11214428805358 := by decide
theorem cert_e2418335783150 : check e2418335783150 [[],[]] .chain = true := by decide
def e2418335783158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2418335783158 : Closed e2418335783158 ∧ code e2418335783158 = 11214428805366 := by decide
theorem cert_e2418335783158 : check e2418335783158 [[],[]] .chain = true := by decide
def e2418335783342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2418335783342 : Closed e2418335783342 ∧ code e2418335783342 = 11214428805550 := by decide
theorem cert_e2418335783342 : check e2418335783342 [[],[]] .chain = true := by decide
def e2418335783354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2418335783354 : Closed e2418335783354 ∧ code e2418335783354 = 11214428805562 := by decide
theorem cert_e2418335783354 : check e2418335783354 [[],[]] .chain = true := by decide
def e2418335783402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2418335783402 : Closed e2418335783402 ∧ code e2418335783402 = 11214428805610 := by decide
theorem cert_e2418335783402 : check e2418335783402 [[],[]] .chain = true := by decide
def e2418335783534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2418335783534 : Closed e2418335783534 ∧ code e2418335783534 = 11214428805742 := by decide
theorem cert_e2418335783534 : check e2418335783534 [[],[]] .chain = true := by decide
def e2418335783546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2418335783546 : Closed e2418335783546 ∧ code e2418335783546 = 11214428805754 := by decide
theorem cert_e2418335783546 : check e2418335783546 [[],[]] .chain = true := by decide
def e2418335783710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2418335783710 : Closed e2418335783710 ∧ code e2418335783710 = 11214428805918 := by decide
theorem cert_e2418335783710 : check e2418335783710 [[],[]] .chain = true := by decide
def e2418335783822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2418335783822 : Closed e2418335783822 ∧ code e2418335783822 = 11214428806030 := by decide
theorem cert_e2418335783822 : check e2418335783822 [[],[]] .chain = true := by decide
def e2418335783834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335783834 : Closed e2418335783834 ∧ code e2418335783834 = 11214428806042 := by decide
theorem cert_e2418335783834 : check e2418335783834 [[],[]] .chain = true := by decide
def e2418335784046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2418335784046 : Closed e2418335784046 ∧ code e2418335784046 = 11214428806254 := by decide
theorem cert_e2418335784046 : check e2418335784046 [[],[]] .chain = true := by decide
def e2418335784058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2418335784058 : Closed e2418335784058 ∧ code e2418335784058 = 11214428806266 := by decide
theorem cert_e2418335784058 : check e2418335784058 [[],[]] .chain = true := by decide
def e2418335784222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2418335784222 : Closed e2418335784222 ∧ code e2418335784222 = 11214428806430 := by decide
theorem cert_e2418335784222 : check e2418335784222 [[],[]] .chain = true := by decide
def e2418335784390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2418335784390 : Closed e2418335784390 ∧ code e2418335784390 = 11214428806598 := by decide
theorem cert_e2418335784390 : check e2418335784390 [[],[]] .chain = true := by decide
def e2418335784502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2418335784502 : Closed e2418335784502 ∧ code e2418335784502 = 11214428806710 := by decide
theorem cert_e2418335784502 : check e2418335784502 [[],[]] .chain = true := by decide
def e2418335784506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2418335784506 : Closed e2418335784506 ∧ code e2418335784506 = 11214428806714 := by decide
theorem cert_e2418335784506 : check e2418335784506 [[],[]] .chain = true := by decide
def e2418335784554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2418335784554 : Closed e2418335784554 ∧ code e2418335784554 = 11214428806762 := by decide
theorem cert_e2418335784554 : check e2418335784554 [[],[]] .chain = true := by decide
def e2418335784590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2418335784590 : Closed e2418335784590 ∧ code e2418335784590 = 11214428806798 := by decide
theorem cert_e2418335784590 : check e2418335784590 [[],[]] .chain = true := by decide
def e2418335784602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335784602 : Closed e2418335784602 ∧ code e2418335784602 = 11214428806810 := by decide
theorem cert_e2418335784602 : check e2418335784602 [[],[]] .chain = true := by decide
def e2418335784646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2418335784646 : Closed e2418335784646 ∧ code e2418335784646 = 11214428806854 := by decide
theorem cert_e2418335784646 : check e2418335784646 [[],[]] .chain = true := by decide
def e2418335785438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2418335785438 : Closed e2418335785438 ∧ code e2418335785438 = 11214428807646 := by decide
theorem cert_e2418335785438 : check e2418335785438 [[],[]] .chain = true := by decide
def e2418335785462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2418335785462 : Closed e2418335785462 ∧ code e2418335785462 = 11214428807670 := by decide
theorem cert_e2418335785462 : check e2418335785462 [[],[]] .chain = true := by decide
def e2418335786414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2418335786414 : Closed e2418335786414 ∧ code e2418335786414 = 11214428808622 := by decide
theorem cert_e2418335786414 : check e2418335786414 [[],[]] .chain = true := by decide
def e2418335786426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2418335786426 : Closed e2418335786426 ∧ code e2418335786426 = 11214428808634 := by decide
theorem cert_e2418335786426 : check e2418335786426 [[],[]] .chain = true := by decide
def e2418335786474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2418335786474 : Closed e2418335786474 ∧ code e2418335786474 = 11214428808682 := by decide
theorem cert_e2418335786474 : check e2418335786474 [[],[]] .chain = true := by decide
def e2418335786606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2418335786606 : Closed e2418335786606 ∧ code e2418335786606 = 11214428808814 := by decide
theorem cert_e2418335786606 : check e2418335786606 [[],[]] .chain = true := by decide
def e2418335786618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2418335786618 : Closed e2418335786618 ∧ code e2418335786618 = 11214428808826 := by decide
theorem cert_e2418335786618 : check e2418335786618 [[],[]] .chain = true := by decide
def e2418335786782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2418335786782 : Closed e2418335786782 ∧ code e2418335786782 = 11214428808990 := by decide
theorem cert_e2418335786782 : check e2418335786782 [[],[]] .chain = true := by decide
def e2418335786894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2418335786894 : Closed e2418335786894 ∧ code e2418335786894 = 11214428809102 := by decide
theorem cert_e2418335786894 : check e2418335786894 [[],[]] .chain = true := by decide
def e2418335786906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335786906 : Closed e2418335786906 ∧ code e2418335786906 = 11214428809114 := by decide
theorem cert_e2418335786906 : check e2418335786906 [[],[]] .chain = true := by decide
def e2418335789854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2418335789854 : Closed e2418335789854 ∧ code e2418335789854 = 11214428812062 := by decide
theorem cert_e2418335789854 : check e2418335789854 [[],[]] .chain = true := by decide
def e2418335790022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2418335790022 : Closed e2418335790022 ∧ code e2418335790022 = 11214428812230 := by decide
theorem cert_e2418335790022 : check e2418335790022 [[],[]] .chain = true := by decide
def e2418335791222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2418335791222 : Closed e2418335791222 ∧ code e2418335791222 = 11214428813430 := by decide
theorem cert_e2418335791222 : check e2418335791222 [[],[]] .chain = true := by decide
def e2418335791466 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2418335791466 : Closed e2418335791466 ∧ code e2418335791466 = 11214428813674 := by decide
theorem cert_e2418335791466 : check e2418335791466 [[],[]] .chain = true := by decide
def e2418335791502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2418335791502 : Closed e2418335791502 ∧ code e2418335791502 = 11214428813710 := by decide
theorem cert_e2418335791502 : check e2418335791502 [[],[]] .chain = true := by decide
def e2418335791514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335791514 : Closed e2418335791514 ∧ code e2418335791514 = 11214428813722 := by decide
theorem cert_e2418335791514 : check e2418335791514 [[],[]] .chain = true := by decide
def e2418335791558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2418335791558 : Closed e2418335791558 ∧ code e2418335791558 = 11214428813766 := by decide
theorem cert_e2418335791558 : check e2418335791558 [[],[]] .chain = true := by decide
def e2418335794102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2418335794102 : Closed e2418335794102 ∧ code e2418335794102 = 11214428816310 := by decide
theorem cert_e2418335794102 : check e2418335794102 [[],[]] .chain = true := by decide
def e2418335794106 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2418335794106 : Closed e2418335794106 ∧ code e2418335794106 = 11214428816314 := by decide
theorem cert_e2418335794106 : check e2418335794106 [[],[]] .chain = true := by decide
def e2418335794138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2418335794138 : Closed e2418335794138 ∧ code e2418335794138 = 11214428816346 := by decide
theorem cert_e2418335794138 : check e2418335794138 [[],[]] .chain = true := by decide
def e2418335794806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2418335794806 : Closed e2418335794806 ∧ code e2418335794806 = 11214428817014 := by decide
theorem cert_e2418335794806 : check e2418335794806 [[],[]] .chain = true := by decide
def e2418335794998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335794998 : Closed e2418335794998 ∧ code e2418335794998 = 11214428817206 := by decide
theorem cert_e2418335794998 : check e2418335794998 [[],[]] .chain = true := by decide
def e2418335795002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335795002 : Closed e2418335795002 ∧ code e2418335795002 = 11214428817210 := by decide
theorem cert_e2418335795002 : check e2418335795002 [[],[]] .chain = true := by decide
def e2418335796054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2418335796054 : Closed e2418335796054 ∧ code e2418335796054 = 11214428818262 := by decide
theorem cert_e2418335796054 : check e2418335796054 [[],[]] .chain = true := by decide
def e2418335796058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2418335796058 : Closed e2418335796058 ∧ code e2418335796058 = 11214428818266 := by decide
theorem cert_e2418335796058 : check e2418335796058 [[],[]] .chain = true := by decide
def e2418335796074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2418335796074 : Closed e2418335796074 ∧ code e2418335796074 = 11214428818282 := by decide
theorem cert_e2418335796074 : check e2418335796074 [[],[]] .chain = true := by decide
def e2418335796138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2418335796138 : Closed e2418335796138 ∧ code e2418335796138 = 11214428818346 := by decide
theorem cert_e2418335796138 : check e2418335796138 [[],[]] .chain = true := by decide
def e2418335796342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2418335796342 : Closed e2418335796342 ∧ code e2418335796342 = 11214428818550 := by decide
theorem cert_e2418335796342 : check e2418335796342 [[],[]] .chain = true := by decide
def e2418335796438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2418335796438 : Closed e2418335796438 ∧ code e2418335796438 = 11214428818646 := by decide
theorem cert_e2418335796438 : check e2418335796438 [[],[]] .chain = true := by decide
def e2418335796442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2418335796442 : Closed e2418335796442 ∧ code e2418335796442 = 11214428818650 := by decide
theorem cert_e2418335796442 : check e2418335796442 [[],[]] .chain = true := by decide
def e2418335796458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2418335796458 : Closed e2418335796458 ∧ code e2418335796458 = 11214428818666 := by decide
theorem cert_e2418335796458 : check e2418335796458 [[],[]] .chain = true := by decide
def e2418335796534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2418335796534 : Closed e2418335796534 ∧ code e2418335796534 = 11214428818742 := by decide
theorem cert_e2418335796534 : check e2418335796534 [[],[]] .chain = true := by decide
def e2418335796538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2418335796538 : Closed e2418335796538 ∧ code e2418335796538 = 11214428818746 := by decide
theorem cert_e2418335796538 : check e2418335796538 [[],[]] .chain = true := by decide
def e2418335796622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2418335796622 : Closed e2418335796622 ∧ code e2418335796622 = 11214428818830 := by decide
theorem cert_e2418335796622 : check e2418335796622 [[],[]] .chain = true := by decide
def e2418335796634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335796634 : Closed e2418335796634 ∧ code e2418335796634 = 11214428818842 := by decide
theorem cert_e2418335796634 : check e2418335796634 [[],[]] .chain = true := by decide
def e2418335796790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2418335796790 : Closed e2418335796790 ∧ code e2418335796790 = 11214428818998 := by decide
theorem cert_e2418335796790 : check e2418335796790 [[],[]] .chain = true := by decide
def e2418335796794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2418335796794 : Closed e2418335796794 ∧ code e2418335796794 = 11214428819002 := by decide
theorem cert_e2418335796794 : check e2418335796794 [[],[]] .chain = true := by decide
def e2418335796842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2418335796842 : Closed e2418335796842 ∧ code e2418335796842 = 11214428819050 := by decide
theorem cert_e2418335796842 : check e2418335796842 [[],[]] .chain = true := by decide
def e2418335796878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2418335796878 : Closed e2418335796878 ∧ code e2418335796878 = 11214428819086 := by decide
theorem cert_e2418335796878 : check e2418335796878 [[],[]] .chain = true := by decide
def e2418335796890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2418335796890 : Closed e2418335796890 ∧ code e2418335796890 = 11214428819098 := by decide
theorem cert_e2418335796890 : check e2418335796890 [[],[]] .chain = true := by decide
def e2418335796934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2418335796934 : Closed e2418335796934 ∧ code e2418335796934 = 11214428819142 := by decide
theorem cert_e2418335796934 : check e2418335796934 [[],[]] .chain = true := by decide
def e2418335797486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2418335797486 : Closed e2418335797486 ∧ code e2418335797486 = 11214428819694 := by decide
theorem cert_e2418335797486 : check e2418335797486 [[],[]] .chain = true := by decide
def e2418335797494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2418335797494 : Closed e2418335797494 ∧ code e2418335797494 = 11214428819702 := by decide
theorem cert_e2418335797494 : check e2418335797494 [[],[]] .chain = true := by decide
def e2418335797974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2418335797974 : Closed e2418335797974 ∧ code e2418335797974 = 11214428820182 := by decide
theorem cert_e2418335797974 : check e2418335797974 [[],[]] .chain = true := by decide
def e2418335797978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2418335797978 : Closed e2418335797978 ∧ code e2418335797978 = 11214428820186 := by decide
theorem cert_e2418335797978 : check e2418335797978 [[],[]] .chain = true := by decide
def e2418335797994 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2418335797994 : Closed e2418335797994 ∧ code e2418335797994 = 11214428820202 := by decide
theorem cert_e2418335797994 : check e2418335797994 [[],[]] .chain = true := by decide
def e2418335798070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2418335798070 : Closed e2418335798070 ∧ code e2418335798070 = 11214428820278 := by decide
theorem cert_e2418335798070 : check e2418335798070 [[],[]] .chain = true := by decide
def e2418335798074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2418335798074 : Closed e2418335798074 ∧ code e2418335798074 = 11214428820282 := by decide
theorem cert_e2418335798074 : check e2418335798074 [[],[]] .chain = true := by decide
def e2418335798158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2418335798158 : Closed e2418335798158 ∧ code e2418335798158 = 11214428820366 := by decide
theorem cert_e2418335798158 : check e2418335798158 [[],[]] .chain = true := by decide
def e2418335798170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335798170 : Closed e2418335798170 ∧ code e2418335798170 = 11214428820378 := by decide
theorem cert_e2418335798170 : check e2418335798170 [[],[]] .chain = true := by decide
def e2418335799414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2418335799414 : Closed e2418335799414 ∧ code e2418335799414 = 11214428821622 := by decide
theorem cert_e2418335799414 : check e2418335799414 [[],[]] .chain = true := by decide
def e2418335799658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2418335799658 : Closed e2418335799658 ∧ code e2418335799658 = 11214428821866 := by decide
theorem cert_e2418335799658 : check e2418335799658 [[],[]] .chain = true := by decide
def e2418335799694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2418335799694 : Closed e2418335799694 ∧ code e2418335799694 = 11214428821902 := by decide
theorem cert_e2418335799694 : check e2418335799694 [[],[]] .chain = true := by decide
def e2418335799706 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2418335799706 : Closed e2418335799706 ∧ code e2418335799706 = 11214428821914 := by decide
theorem cert_e2418335799706 : check e2418335799706 [[],[]] .chain = true := by decide
def e2418335799750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2418335799750 : Closed e2418335799750 ∧ code e2418335799750 = 11214428821958 := by decide
theorem cert_e2418335799750 : check e2418335799750 [[],[]] .chain = true := by decide
def e2418335812462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2418335812462 : Closed e2418335812462 ∧ code e2418335812462 = 11214428834670 := by decide
theorem cert_e2418335812462 : check e2418335812462 [[],[]] .smaller = true := by decide
def e2418335812470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2418335812470 : Closed e2418335812470 ∧ code e2418335812470 = 11214428834678 := by decide
theorem cert_e2418335812470 : check e2418335812470 [[],[]] .smaller = true := by decide
def e2418335812526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2418335812526 : Closed e2418335812526 ∧ code e2418335812526 = 11214428834734 := by decide
theorem cert_e2418335812526 : check e2418335812526 [[],[]] .smaller = true := by decide
def e2418335812538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2418335812538 : Closed e2418335812538 ∧ code e2418335812538 = 11214428834746 := by decide
theorem cert_e2418335812538 : check e2418335812538 [[],[]] .smaller = true := by decide
def e2418335812566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2418335812566 : Closed e2418335812566 ∧ code e2418335812566 = 11214428834774 := by decide
theorem cert_e2418335812566 : check e2418335812566 [[],[]] .smaller = true := by decide
def e2418335812570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2418335812570 : Closed e2418335812570 ∧ code e2418335812570 = 11214428834778 := by decide
theorem cert_e2418335812570 : check e2418335812570 [[],[]] .smaller = true := by decide
def e2418335812846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2418335812846 : Closed e2418335812846 ∧ code e2418335812846 = 11214428835054 := by decide
theorem cert_e2418335812846 : check e2418335812846 [[],[]] .smaller = true := by decide
def e2418335812854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2418335812854 : Closed e2418335812854 ∧ code e2418335812854 = 11214428835062 := by decide
theorem cert_e2418335812854 : check e2418335812854 [[],[]] .smaller = true := by decide
def e2418335813230 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2418335813230 : Closed e2418335813230 ∧ code e2418335813230 = 11214428835438 := by decide
theorem cert_e2418335813230 : check e2418335813230 [[],[]] .smaller = true := by decide
def e2418335813242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2418335813242 : Closed e2418335813242 ∧ code e2418335813242 = 11214428835450 := by decide
theorem cert_e2418335813242 : check e2418335813242 [[],[]] .smaller = true := by decide
def e2418335813430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2418335813430 : Closed e2418335813430 ∧ code e2418335813430 = 11214428835638 := by decide
theorem cert_e2418335813430 : check e2418335813430 [[],[]] .smaller = true := by decide
def e2418335813434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2418335813434 : Closed e2418335813434 ∧ code e2418335813434 = 11214428835642 := by decide
theorem cert_e2418335813434 : check e2418335813434 [[],[]] .smaller = true := by decide
def e2418335853934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2418335853934 : Closed e2418335853934 ∧ code e2418335853934 = 11214428876142 := by decide
theorem cert_e2418335853934 : check e2418335853934 [[],[]] .chain = true := by decide
def e2418335853942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2418335853942 : Closed e2418335853942 ∧ code e2418335853942 = 11214428876150 := by decide
theorem cert_e2418335853942 : check e2418335853942 [[],[]] .chain = true := by decide
def e2418335853998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2418335853998 : Closed e2418335853998 ∧ code e2418335853998 = 11214428876206 := by decide
theorem cert_e2418335853998 : check e2418335853998 [[],[]] .chain = true := by decide
def e2418335854010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2418335854010 : Closed e2418335854010 ∧ code e2418335854010 = 11214428876218 := by decide
theorem cert_e2418335854010 : check e2418335854010 [[],[]] .chain = true := by decide
def e2418335854038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2418335854038 : Closed e2418335854038 ∧ code e2418335854038 = 11214428876246 := by decide
theorem cert_e2418335854038 : check e2418335854038 [[],[]] .chain = true := by decide
def e2418335854042 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2418335854042 : Closed e2418335854042 ∧ code e2418335854042 = 11214428876250 := by decide
theorem cert_e2418335854042 : check e2418335854042 [[],[]] .chain = true := by decide
def e2418335854254 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2418335854254 : Closed e2418335854254 ∧ code e2418335854254 = 11214428876462 := by decide
theorem cert_e2418335854254 : check e2418335854254 [[],[]] .chain = true := by decide
def e2418335854266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2418335854266 : Closed e2418335854266 ∧ code e2418335854266 = 11214428876474 := by decide
theorem cert_e2418335854266 : check e2418335854266 [[],[]] .chain = true := by decide
def e2418335854314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2418335854314 : Closed e2418335854314 ∧ code e2418335854314 = 11214428876522 := by decide
theorem cert_e2418335854314 : check e2418335854314 [[],[]] .chain = true := by decide
def e2418335854422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2418335854422 : Closed e2418335854422 ∧ code e2418335854422 = 11214428876630 := by decide
theorem cert_e2418335854422 : check e2418335854422 [[],[]] .chain = true := by decide
def e2418335854426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2418335854426 : Closed e2418335854426 ∧ code e2418335854426 = 11214428876634 := by decide
theorem cert_e2418335854426 : check e2418335854426 [[],[]] .chain = true := by decide
def e2418335854442 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2418335854442 : Closed e2418335854442 ∧ code e2418335854442 = 11214428876650 := by decide
theorem cert_e2418335854442 : check e2418335854442 [[],[]] .chain = true := by decide
end Blc.Floor43
