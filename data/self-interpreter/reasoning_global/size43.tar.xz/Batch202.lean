import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389347669726 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2389347669726 : Closed e2389347669726 ∧ code e2389347669726 = 11185440691934 := by decide
theorem cert_e2389347669726 : check e2389347669726 [[],[.left]] .chain = true := by decide
def e2389347669750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2389347669750 : Closed e2389347669750 ∧ code e2389347669750 = 11185440691958 := by decide
theorem cert_e2389347669750 : check e2389347669750 [[],[.left]] .chain = true := by decide
def e2389347669854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2389347669854 : Closed e2389347669854 ∧ code e2389347669854 = 11185440692062 := by decide
theorem cert_e2389347669854 : check e2389347669854 [[],[.left]] .chain = true := by decide
def e2389347669882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2389347669882 : Closed e2389347669882 ∧ code e2389347669882 = 11185440692090 := by decide
theorem cert_e2389347669882 : check e2389347669882 [[],[.left]] .chain = true := by decide
def e2389347669974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2389347669974 : Closed e2389347669974 ∧ code e2389347669974 = 11185440692182 := by decide
theorem cert_e2389347669974 : check e2389347669974 [[],[.left]] .chain = true := by decide
def e2389347669978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2389347669978 : Closed e2389347669978 ∧ code e2389347669978 = 11185440692186 := by decide
theorem cert_e2389347669978 : check e2389347669978 [[],[.left]] .chain = true := by decide
def e2389347670494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2389347670494 : Closed e2389347670494 ∧ code e2389347670494 = 11185440692702 := by decide
theorem cert_e2389347670494 : check e2389347670494 [[],[.left]] .chain = true := by decide
def e2389347670518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2389347670518 : Closed e2389347670518 ∧ code e2389347670518 = 11185440692726 := by decide
theorem cert_e2389347670518 : check e2389347670518 [[],[.left]] .chain = true := by decide
def e2389347671262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389347671262 : Closed e2389347671262 ∧ code e2389347671262 = 11185440693470 := by decide
theorem cert_e2389347671262 : check e2389347671262 [[],[.left]] .chain = true := by decide
def e2389347671290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389347671290 : Closed e2389347671290 ∧ code e2389347671290 = 11185440693498 := by decide
theorem cert_e2389347671290 : check e2389347671290 [[],[.left]] .chain = true := by decide
def e2389347671862 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389347671862 : Closed e2389347671862 ∧ code e2389347671862 = 11185440694070 := by decide
theorem cert_e2389347671862 : check e2389347671862 [[],[.left]] .chain = true := by decide
def e2389347671866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389347671866 : Closed e2389347671866 ∧ code e2389347671866 = 11185440694074 := by decide
theorem cert_e2389347671866 : check e2389347671866 [[],[.left]] .chain = true := by decide
def e2389347686638 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2389347686638 : Closed e2389347686638 ∧ code e2389347686638 = 11185440708846 := by decide
theorem cert_e2389347686638 : check e2389347686638 [[],[.left]] .chain = true := by decide
def e2389347686646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2389347686646 : Closed e2389347686646 ∧ code e2389347686646 = 11185440708854 := by decide
theorem cert_e2389347686646 : check e2389347686646 [[],[.left]] .chain = true := by decide
def e2389347687198 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2389347687198 : Closed e2389347687198 ∧ code e2389347687198 = 11185440709406 := by decide
theorem cert_e2389347687198 : check e2389347687198 [[],[.left]] .chain = true := by decide
def e2389347687310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2389347687310 : Closed e2389347687310 ∧ code e2389347687310 = 11185440709518 := by decide
theorem cert_e2389347687310 : check e2389347687310 [[],[.left]] .chain = true := by decide
def e2389347687534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2389347687534 : Closed e2389347687534 ∧ code e2389347687534 = 11185440709742 := by decide
theorem cert_e2389347687534 : check e2389347687534 [[],[.left]] .chain = true := by decide
def e2389347687546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2389347687546 : Closed e2389347687546 ∧ code e2389347687546 = 11185440709754 := by decide
theorem cert_e2389347687546 : check e2389347687546 [[],[.left]] .chain = true := by decide
def e2389347687710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2389347687710 : Closed e2389347687710 ∧ code e2389347687710 = 11185440709918 := by decide
theorem cert_e2389347687710 : check e2389347687710 [[],[.left]] .chain = true := by decide
def e2389347687878 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2389347687878 : Closed e2389347687878 ∧ code e2389347687878 = 11185440710086 := by decide
theorem cert_e2389347687878 : check e2389347687878 [[],[.left]] .chain = true := by decide
def e2389347687990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2389347687990 : Closed e2389347687990 ∧ code e2389347687990 = 11185440710198 := by decide
theorem cert_e2389347687990 : check e2389347687990 [[],[.left]] .chain = true := by decide
def e2389347687994 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2389347687994 : Closed e2389347687994 ∧ code e2389347687994 = 11185440710202 := by decide
theorem cert_e2389347687994 : check e2389347687994 [[],[.left]] .chain = true := by decide
def e2389347688078 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2389347688078 : Closed e2389347688078 ∧ code e2389347688078 = 11185440710286 := by decide
theorem cert_e2389347688078 : check e2389347688078 [[],[.left]] .chain = true := by decide
def e2389347688134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2389347688134 : Closed e2389347688134 ∧ code e2389347688134 = 11185440710342 := by decide
theorem cert_e2389347688134 : check e2389347688134 [[],[.left]] .chain = true := by decide
def e2389347690270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2389347690270 : Closed e2389347690270 ∧ code e2389347690270 = 11185440712478 := by decide
theorem cert_e2389347690270 : check e2389347690270 [[],[.left]] .chain = true := by decide
def e2389347690382 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2389347690382 : Closed e2389347690382 ∧ code e2389347690382 = 11185440712590 := by decide
theorem cert_e2389347690382 : check e2389347690382 [[],[.left]] .chain = true := by decide
def e2389347693342 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2389347693342 : Closed e2389347693342 ∧ code e2389347693342 = 11185440715550 := by decide
theorem cert_e2389347693342 : check e2389347693342 [[],[.left]] .chain = true := by decide
def e2389347693510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2389347693510 : Closed e2389347693510 ∧ code e2389347693510 = 11185440715718 := by decide
theorem cert_e2389347693510 : check e2389347693510 [[],[.left]] .chain = true := by decide
def e2389347694990 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2389347694990 : Closed e2389347694990 ∧ code e2389347694990 = 11185440717198 := by decide
theorem cert_e2389347694990 : check e2389347694990 [[],[.left]] .chain = true := by decide
def e2389347695046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2389347695046 : Closed e2389347695046 ∧ code e2389347695046 = 11185440717254 := by decide
theorem cert_e2389347695046 : check e2389347695046 [[],[.left]] .chain = true := by decide
def e2389355539898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e2389355539898 : Closed e2389355539898 ∧ code e2389355539898 = 11185448562106 := by decide
theorem cert_e2389355539898 : check e2389355539898 [[],[.left]] .chain = true := by decide
def e2389355539930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e2389355539930 : Closed e2389355539930 ∧ code e2389355539930 = 11185448562138 := by decide
theorem cert_e2389355539930 : check e2389355539930 [[],[.left]] .chain = true := by decide
def e2389355540154 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e2389355540154 : Closed e2389355540154 ∧ code e2389355540154 = 11185448562362 := by decide
theorem cert_e2389355540154 : check e2389355540154 [[],[.left]] .chain = true := by decide
def e2389355540202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e2389355540202 : Closed e2389355540202 ∧ code e2389355540202 = 11185448562410 := by decide
theorem cert_e2389355540202 : check e2389355540202 [[],[.left]] .chain = true := by decide
def e2389355540314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e2389355540314 : Closed e2389355540314 ∧ code e2389355540314 = 11185448562522 := by decide
theorem cert_e2389355540314 : check e2389355540314 [[],[.left]] .chain = true := by decide
def e2389355540330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e2389355540330 : Closed e2389355540330 ∧ code e2389355540330 = 11185448562538 := by decide
theorem cert_e2389355540330 : check e2389355540330 [[],[.left]] .chain = true := by decide
def e2389355541434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e2389355541434 : Closed e2389355541434 ∧ code e2389355541434 = 11185448563642 := by decide
theorem cert_e2389355541434 : check e2389355541434 [[],[.left]] .chain = true := by decide
def e2389355541466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e2389355541466 : Closed e2389355541466 ∧ code e2389355541466 = 11185448563674 := by decide
theorem cert_e2389355541466 : check e2389355541466 [[],[.left]] .chain = true := by decide
def e2389355542970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e2389355542970 : Closed e2389355542970 ∧ code e2389355542970 = 11185448565178 := by decide
theorem cert_e2389355542970 : check e2389355542970 [[],[.left]] .chain = true := by decide
def e2389355543018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e2389355543018 : Closed e2389355543018 ∧ code e2389355543018 = 11185448565226 := by decide
theorem cert_e2389355543018 : check e2389355543018 [[],[.left]] .chain = true := by decide
def e2389355543770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e2389355543770 : Closed e2389355543770 ∧ code e2389355543770 = 11185448565978 := by decide
theorem cert_e2389355543770 : check e2389355543770 [[],[.left]] .chain = true := by decide
def e2389355543786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e2389355543786 : Closed e2389355543786 ∧ code e2389355543786 = 11185448565994 := by decide
theorem cert_e2389355543786 : check e2389355543786 [[],[.left]] .chain = true := by decide
def e2389355793262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2389355793262 : Closed e2389355793262 ∧ code e2389355793262 = 11185448815470 := by decide
theorem cert_e2389355793262 : check e2389355793262 [[],[.left]] .chain = true := by decide
def e2389355793270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2389355793270 : Closed e2389355793270 ∧ code e2389355793270 = 11185448815478 := by decide
theorem cert_e2389355793270 : check e2389355793270 [[],[.left]] .chain = true := by decide
def e2389355793326 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2389355793326 : Closed e2389355793326 ∧ code e2389355793326 = 11185448815534 := by decide
theorem cert_e2389355793326 : check e2389355793326 [[],[.left]] .chain = true := by decide
def e2389355793338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2389355793338 : Closed e2389355793338 ∧ code e2389355793338 = 11185448815546 := by decide
theorem cert_e2389355793338 : check e2389355793338 [[],[.left]] .chain = true := by decide
def e2389355793366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2389355793366 : Closed e2389355793366 ∧ code e2389355793366 = 11185448815574 := by decide
theorem cert_e2389355793366 : check e2389355793366 [[],[.left]] .chain = true := by decide
def e2389355793370 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2389355793370 : Closed e2389355793370 ∧ code e2389355793370 = 11185448815578 := by decide
theorem cert_e2389355793370 : check e2389355793370 [[],[.left]] .chain = true := by decide
def e2389355793646 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2389355793646 : Closed e2389355793646 ∧ code e2389355793646 = 11185448815854 := by decide
theorem cert_e2389355793646 : check e2389355793646 [[],[.left]] .chain = true := by decide
def e2389355793654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2389355793654 : Closed e2389355793654 ∧ code e2389355793654 = 11185448815862 := by decide
theorem cert_e2389355793654 : check e2389355793654 [[],[.left]] .chain = true := by decide
def e2389355794030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2389355794030 : Closed e2389355794030 ∧ code e2389355794030 = 11185448816238 := by decide
theorem cert_e2389355794030 : check e2389355794030 [[],[.left]] .chain = true := by decide
def e2389355794042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2389355794042 : Closed e2389355794042 ∧ code e2389355794042 = 11185448816250 := by decide
theorem cert_e2389355794042 : check e2389355794042 [[],[.left]] .chain = true := by decide
def e2389355794230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2389355794230 : Closed e2389355794230 ∧ code e2389355794230 = 11185448816438 := by decide
theorem cert_e2389355794230 : check e2389355794230 [[],[.left]] .chain = true := by decide
def e2389355794234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2389355794234 : Closed e2389355794234 ∧ code e2389355794234 = 11185448816442 := by decide
theorem cert_e2389355794234 : check e2389355794234 [[],[.left]] .chain = true := by decide
def e2389356588510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2389356588510 : Closed e2389356588510 ∧ code e2389356588510 = 11185449610718 := by decide
theorem cert_e2389356588510 : check e2389356588510 [[],[.left]] .chain = true := by decide
def e2389356588526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2389356588526 : Closed e2389356588526 ∧ code e2389356588526 = 11185449610734 := by decide
theorem cert_e2389356588526 : check e2389356588526 [[],[.left]] .chain = true := by decide
def e2389356588894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2389356588894 : Closed e2389356588894 ∧ code e2389356588894 = 11185449611102 := by decide
theorem cert_e2389356588894 : check e2389356588894 [[],[.left]] .chain = true := by decide
def e2389356588922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2389356588922 : Closed e2389356588922 ∧ code e2389356588922 = 11185449611130 := by decide
theorem cert_e2389356588922 : check e2389356588922 [[],[.left]] .chain = true := by decide
def e2389356588974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2389356588974 : Closed e2389356588974 ∧ code e2389356588974 = 11185449611182 := by decide
theorem cert_e2389356588974 : check e2389356588974 [[],[.left]] .chain = true := by decide
def e2389356588986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2389356588986 : Closed e2389356588986 ∧ code e2389356588986 = 11185449611194 := by decide
theorem cert_e2389356588986 : check e2389356588986 [[],[.left]] .chain = true := by decide
def e2389356590046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2389356590046 : Closed e2389356590046 ∧ code e2389356590046 = 11185449612254 := by decide
theorem cert_e2389356590046 : check e2389356590046 [[],[.left]] .chain = true := by decide
def e2389356590062 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2389356590062 : Closed e2389356590062 ∧ code e2389356590062 = 11185449612270 := by decide
theorem cert_e2389356590062 : check e2389356590062 [[],[.left]] .chain = true := by decide
def e2389356592350 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389356592350 : Closed e2389356592350 ∧ code e2389356592350 = 11185449614558 := by decide
theorem cert_e2389356592350 : check e2389356592350 [[],[.left]] .chain = true := by decide
def e2389356592378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389356592378 : Closed e2389356592378 ∧ code e2389356592378 = 11185449614586 := by decide
theorem cert_e2389356592378 : check e2389356592378 [[],[.left]] .chain = true := by decide
def e2389356592750 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389356592750 : Closed e2389356592750 ∧ code e2389356592750 = 11185449614958 := by decide
theorem cert_e2389356592750 : check e2389356592750 [[],[.left]] .chain = true := by decide
def e2389356592762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389356592762 : Closed e2389356592762 ∧ code e2389356592762 = 11185449614970 := by decide
theorem cert_e2389356592762 : check e2389356592762 [[],[.left]] .chain = true := by decide
def e2389356621166 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2389356621166 : Closed e2389356621166 ∧ code e2389356621166 = 11185449643374 := by decide
theorem cert_e2389356621166 : check e2389356621166 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2389356621174 : Closed e2389356621174 ∧ code e2389356621174 = 11185449643382 := by decide
theorem cert_e2389356621174 : check e2389356621174 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2389356621230 : Closed e2389356621230 ∧ code e2389356621230 = 11185449643438 := by decide
theorem cert_e2389356621230 : check e2389356621230 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2389356621242 : Closed e2389356621242 ∧ code e2389356621242 = 11185449643450 := by decide
theorem cert_e2389356621242 : check e2389356621242 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2389356621270 : Closed e2389356621270 ∧ code e2389356621270 = 11185449643478 := by decide
theorem cert_e2389356621270 : check e2389356621270 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2389356621274 : Closed e2389356621274 ∧ code e2389356621274 = 11185449643482 := by decide
theorem cert_e2389356621274 : check e2389356621274 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2389356621486 : Closed e2389356621486 ∧ code e2389356621486 = 11185449643694 := by decide
theorem cert_e2389356621486 : check e2389356621486 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621498 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2389356621498 : Closed e2389356621498 ∧ code e2389356621498 = 11185449643706 := by decide
theorem cert_e2389356621498 : check e2389356621498 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621546 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2389356621546 : Closed e2389356621546 ∧ code e2389356621546 = 11185449643754 := by decide
theorem cert_e2389356621546 : check e2389356621546 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621654 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2389356621654 : Closed e2389356621654 ∧ code e2389356621654 = 11185449643862 := by decide
theorem cert_e2389356621654 : check e2389356621654 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621658 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2389356621658 : Closed e2389356621658 ∧ code e2389356621658 = 11185449643866 := by decide
theorem cert_e2389356621658 : check e2389356621658 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356621674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2389356621674 : Closed e2389356621674 ∧ code e2389356621674 = 11185449643882 := by decide
theorem cert_e2389356621674 : check e2389356621674 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356622702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2389356622702 : Closed e2389356622702 ∧ code e2389356622702 = 11185449644910 := by decide
theorem cert_e2389356622702 : check e2389356622702 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356622710 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2389356622710 : Closed e2389356622710 ∧ code e2389356622710 = 11185449644918 := by decide
theorem cert_e2389356622710 : check e2389356622710 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356622766 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2389356622766 : Closed e2389356622766 ∧ code e2389356622766 = 11185449644974 := by decide
theorem cert_e2389356622766 : check e2389356622766 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356622778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2389356622778 : Closed e2389356622778 ∧ code e2389356622778 = 11185449644986 := by decide
theorem cert_e2389356622778 : check e2389356622778 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356622806 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2389356622806 : Closed e2389356622806 ∧ code e2389356622806 = 11185449645014 := by decide
theorem cert_e2389356622806 : check e2389356622806 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356622810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2389356622810 : Closed e2389356622810 ∧ code e2389356622810 = 11185449645018 := by decide
theorem cert_e2389356622810 : check e2389356622810 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356623086 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2389356623086 : Closed e2389356623086 ∧ code e2389356623086 = 11185449645294 := by decide
theorem cert_e2389356623086 : check e2389356623086 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356623094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2389356623094 : Closed e2389356623094 ∧ code e2389356623094 = 11185449645302 := by decide
theorem cert_e2389356623094 : check e2389356623094 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356623470 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389356623470 : Closed e2389356623470 ∧ code e2389356623470 = 11185449645678 := by decide
theorem cert_e2389356623470 : check e2389356623470 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356623482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389356623482 : Closed e2389356623482 ∧ code e2389356623482 = 11185449645690 := by decide
theorem cert_e2389356623482 : check e2389356623482 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356623670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389356623670 : Closed e2389356623670 ∧ code e2389356623670 = 11185449645878 := by decide
theorem cert_e2389356623670 : check e2389356623670 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356623674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389356623674 : Closed e2389356623674 ∧ code e2389356623674 = 11185449645882 := by decide
theorem cert_e2389356623674 : check e2389356623674 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356624302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2389356624302 : Closed e2389356624302 ∧ code e2389356624302 = 11185449646510 := by decide
theorem cert_e2389356624302 : check e2389356624302 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356624314 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2389356624314 : Closed e2389356624314 ∧ code e2389356624314 = 11185449646522 := by decide
theorem cert_e2389356624314 : check e2389356624314 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356624362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2389356624362 : Closed e2389356624362 ∧ code e2389356624362 = 11185449646570 := by decide
theorem cert_e2389356624362 : check e2389356624362 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356624494 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2389356624494 : Closed e2389356624494 ∧ code e2389356624494 = 11185449646702 := by decide
theorem cert_e2389356624494 : check e2389356624494 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356624506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2389356624506 : Closed e2389356624506 ∧ code e2389356624506 = 11185449646714 := by decide
theorem cert_e2389356624506 : check e2389356624506 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356624794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389356624794 : Closed e2389356624794 ∧ code e2389356624794 = 11185449647002 := by decide
theorem cert_e2389356624794 : check e2389356624794 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356625110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2389356625110 : Closed e2389356625110 ∧ code e2389356625110 = 11185449647318 := by decide
theorem cert_e2389356625110 : check e2389356625110 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356625114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2389356625114 : Closed e2389356625114 ∧ code e2389356625114 = 11185449647322 := by decide
theorem cert_e2389356625114 : check e2389356625114 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356625130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2389356625130 : Closed e2389356625130 ∧ code e2389356625130 = 11185449647338 := by decide
theorem cert_e2389356625130 : check e2389356625130 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356625206 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2389356625206 : Closed e2389356625206 ∧ code e2389356625206 = 11185449647414 := by decide
theorem cert_e2389356625206 : check e2389356625206 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356625210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2389356625210 : Closed e2389356625210 ∧ code e2389356625210 = 11185449647418 := by decide
theorem cert_e2389356625210 : check e2389356625210 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356625306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2389356625306 : Closed e2389356625306 ∧ code e2389356625306 = 11185449647514 := by decide
theorem cert_e2389356625306 : check e2389356625306 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356626910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2389356626910 : Closed e2389356626910 ∧ code e2389356626910 = 11185449649118 := by decide
theorem cert_e2389356626910 : check e2389356626910 [[],[.left]] .chain = true := by decide
def e2389356626926 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2389356626926 : Closed e2389356626926 ∧ code e2389356626926 = 11185449649134 := by decide
theorem cert_e2389356626926 : check e2389356626926 [[],[.left]] .chain = true := by decide
def e2389356628846 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389356628846 : Closed e2389356628846 ∧ code e2389356628846 = 11185449651054 := by decide
theorem cert_e2389356628846 : check e2389356628846 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356628854 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389356628854 : Closed e2389356628854 ∧ code e2389356628854 = 11185449651062 := by decide
theorem cert_e2389356628854 : check e2389356628854 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356628910 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389356628910 : Closed e2389356628910 ∧ code e2389356628910 = 11185449651118 := by decide
theorem cert_e2389356628910 : check e2389356628910 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356628922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389356628922 : Closed e2389356628922 ∧ code e2389356628922 = 11185449651130 := by decide
theorem cert_e2389356628922 : check e2389356628922 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356628950 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389356628950 : Closed e2389356628950 ∧ code e2389356628950 = 11185449651158 := by decide
theorem cert_e2389356628950 : check e2389356628950 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356628954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389356628954 : Closed e2389356628954 ∧ code e2389356628954 = 11185449651162 := by decide
theorem cert_e2389356628954 : check e2389356628954 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356629230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389356629230 : Closed e2389356629230 ∧ code e2389356629230 = 11185449651438 := by decide
theorem cert_e2389356629230 : check e2389356629230 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356629238 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389356629238 : Closed e2389356629238 ∧ code e2389356629238 = 11185449651446 := by decide
theorem cert_e2389356629238 : check e2389356629238 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356629614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389356629614 : Closed e2389356629614 ∧ code e2389356629614 = 11185449651822 := by decide
theorem cert_e2389356629614 : check e2389356629614 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356629626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389356629626 : Closed e2389356629626 ∧ code e2389356629626 = 11185449651834 := by decide
theorem cert_e2389356629626 : check e2389356629626 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356629814 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389356629814 : Closed e2389356629814 ∧ code e2389356629814 = 11185449652022 := by decide
theorem cert_e2389356629814 : check e2389356629814 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356629818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389356629818 : Closed e2389356629818 ∧ code e2389356629818 = 11185449652026 := by decide
theorem cert_e2389356629818 : check e2389356629818 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356634590 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2389356634590 : Closed e2389356634590 ∧ code e2389356634590 = 11185449656798 := by decide
theorem cert_e2389356634590 : check e2389356634590 [[],[.left]] .chain = true := by decide
def e2389356634614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2389356634614 : Closed e2389356634614 ∧ code e2389356634614 = 11185449656822 := by decide
theorem cert_e2389356634614 : check e2389356634614 [[],[.left]] .chain = true := by decide
def e2389356635566 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2389356635566 : Closed e2389356635566 ∧ code e2389356635566 = 11185449657774 := by decide
theorem cert_e2389356635566 : check e2389356635566 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356635578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2389356635578 : Closed e2389356635578 ∧ code e2389356635578 = 11185449657786 := by decide
theorem cert_e2389356635578 : check e2389356635578 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356635626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2389356635626 : Closed e2389356635626 ∧ code e2389356635626 = 11185449657834 := by decide
theorem cert_e2389356635626 : check e2389356635626 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356635758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389356635758 : Closed e2389356635758 ∧ code e2389356635758 = 11185449657966 := by decide
theorem cert_e2389356635758 : check e2389356635758 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356635770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389356635770 : Closed e2389356635770 ∧ code e2389356635770 = 11185449657978 := by decide
theorem cert_e2389356635770 : check e2389356635770 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356636058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389356636058 : Closed e2389356636058 ∧ code e2389356636058 = 11185449658266 := by decide
theorem cert_e2389356636058 : check e2389356636058 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356638446 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2389356638446 : Closed e2389356638446 ∧ code e2389356638446 = 11185449660654 := by decide
theorem cert_e2389356638446 : check e2389356638446 [[],[.left]] .chain = true := by decide
def e2389356638454 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2389356638454 : Closed e2389356638454 ∧ code e2389356638454 = 11185449660662 := by decide
theorem cert_e2389356638454 : check e2389356638454 [[],[.left]] .chain = true := by decide
def e2389356638934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2389356638934 : Closed e2389356638934 ∧ code e2389356638934 = 11185449661142 := by decide
theorem cert_e2389356638934 : check e2389356638934 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356638938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2389356638938 : Closed e2389356638938 ∧ code e2389356638938 = 11185449661146 := by decide
theorem cert_e2389356638938 : check e2389356638938 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356638954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2389356638954 : Closed e2389356638954 ∧ code e2389356638954 = 11185449661162 := by decide
theorem cert_e2389356638954 : check e2389356638954 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356639030 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389356639030 : Closed e2389356639030 ∧ code e2389356639030 = 11185449661238 := by decide
theorem cert_e2389356639030 : check e2389356639030 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356639034 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389356639034 : Closed e2389356639034 ∧ code e2389356639034 = 11185449661242 := by decide
theorem cert_e2389356639034 : check e2389356639034 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356639130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2389356639130 : Closed e2389356639130 ∧ code e2389356639130 = 11185449661338 := by decide
theorem cert_e2389356639130 : check e2389356639130 [[],[.left],[.left],[]] .chain = true := by decide
def e2389356776302 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389356776302 : Closed e2389356776302 ∧ code e2389356776302 = 11185449798510 := by decide
private def t_e2389356776302 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem cert_e2389356776302 : ¬ IsSelfInterpreter e2389356776302 :=
  wSource (t := t_e2389356776302) (replay_sound (ps := [[],[.left],[.left]]) (t := e2389356776302) (by decide)) (by decide)
def e2389356776310 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389356776310 : Closed e2389356776310 ∧ code e2389356776310 = 11185449798518 := by decide
def e2389356776366 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389356776366 : Closed e2389356776366 ∧ code e2389356776366 = 11185449798574 := by decide
private def t_e2389356776366 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem cert_e2389356776366 : ¬ IsSelfInterpreter e2389356776366 :=
  wSource (t := t_e2389356776366) (replay_sound (ps := [[],[.left],[.left]]) (t := e2389356776366) (by decide)) (by decide)
def e2389356776378 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389356776378 : Closed e2389356776378 ∧ code e2389356776378 = 11185449798586 := by decide
def e2389356776406 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389356776406 : Closed e2389356776406 ∧ code e2389356776406 = 11185449798614 := by decide
def e2389356776410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389356776410 : Closed e2389356776410 ∧ code e2389356776410 = 11185449798618 := by decide
def e2389356776686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389356776686 : Closed e2389356776686 ∧ code e2389356776686 = 11185449798894 := by decide
def e2389356776694 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389356776694 : Closed e2389356776694 ∧ code e2389356776694 = 11185449798902 := by decide
def e2389356777070 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389356777070 : Closed e2389356777070 ∧ code e2389356777070 = 11185449799278 := by decide
def e2389356777082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389356777082 : Closed e2389356777082 ∧ code e2389356777082 = 11185449799290 := by decide
def e2389356777270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389356777270 : Closed e2389356777270 ∧ code e2389356777270 = 11185449799478 := by decide
def e2389356777274 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389356777274 : Closed e2389356777274 ∧ code e2389356777274 = 11185449799482 := by decide
def e2389357366126 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2389357366126 : Closed e2389357366126 ∧ code e2389357366126 = 11185450388334 := by decide
theorem cert_e2389357366126 : check e2389357366126 [[],[.left]] .chain = true := by decide
def e2389357366134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2389357366134 : Closed e2389357366134 ∧ code e2389357366134 = 11185450388342 := by decide
theorem cert_e2389357366134 : check e2389357366134 [[],[.left]] .chain = true := by decide
def e2389357366190 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2389357366190 : Closed e2389357366190 ∧ code e2389357366190 = 11185450388398 := by decide
theorem cert_e2389357366190 : check e2389357366190 [[],[.left]] .chain = true := by decide
def e2389357366202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2389357366202 : Closed e2389357366202 ∧ code e2389357366202 = 11185450388410 := by decide
theorem cert_e2389357366202 : check e2389357366202 [[],[.left]] .chain = true := by decide
def e2389357366230 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2389357366230 : Closed e2389357366230 ∧ code e2389357366230 = 11185450388438 := by decide
theorem cert_e2389357366230 : check e2389357366230 [[],[.left]] .chain = true := by decide
def e2389357366234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2389357366234 : Closed e2389357366234 ∧ code e2389357366234 = 11185450388442 := by decide
theorem cert_e2389357366234 : check e2389357366234 [[],[.left]] .chain = true := by decide
def e2389357366510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2389357366510 : Closed e2389357366510 ∧ code e2389357366510 = 11185450388718 := by decide
theorem cert_e2389357366510 : check e2389357366510 [[],[.left]] .chain = true := by decide
def e2389357366518 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2389357366518 : Closed e2389357366518 ∧ code e2389357366518 = 11185450388726 := by decide
theorem cert_e2389357366518 : check e2389357366518 [[],[.left]] .chain = true := by decide
def e2389357366894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2389357366894 : Closed e2389357366894 ∧ code e2389357366894 = 11185450389102 := by decide
theorem cert_e2389357366894 : check e2389357366894 [[],[.left]] .chain = true := by decide
def e2389357366906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2389357366906 : Closed e2389357366906 ∧ code e2389357366906 = 11185450389114 := by decide
theorem cert_e2389357366906 : check e2389357366906 [[],[.left]] .chain = true := by decide
def e2389357367094 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389357367094 : Closed e2389357367094 ∧ code e2389357367094 = 11185450389302 := by decide
theorem cert_e2389357367094 : check e2389357367094 [[],[.left]] .chain = true := by decide
def e2389357367098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389357367098 : Closed e2389357367098 ∧ code e2389357367098 = 11185450389306 := by decide
theorem cert_e2389357367098 : check e2389357367098 [[],[.left]] .chain = true := by decide
def e2389613927962 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389613927962 : Closed e2389613927962 ∧ code e2389613927962 = 11185706950170 := by decide
theorem cert_e2389613927962 : check e2389613927962 [[]] .width = true := by decide
def e2389613934106 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389613934106 : Closed e2389613934106 ∧ code e2389613934106 = 11185706956314 := by decide
theorem cert_e2389613934106 : check e2389613934106 [[]] .width = true := by decide
def e2389613960730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389613960730 : Closed e2389613960730 ∧ code e2389613960730 = 11185706982938 := by decide
theorem cert_e2389613960730 : check e2389613960730 [[]] .width = true := by decide
def e2389613967898 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2389613967898 : Closed e2389613967898 ∧ code e2389613967898 = 11185706990106 := by decide
theorem cert_e2389613967898 : check e2389613967898 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2389356776302
#print axioms Blc.Floor43.cert_e2389356776366
