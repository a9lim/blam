import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2407064435086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2407064435086 : Closed e2407064435086 ∧ code e2407064435086 = 11203157457294 := by decide
theorem cert_e2407064435086 : check e2407064435086 [[],[],[.under]] .smaller = true := by decide
def e2407064435142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2407064435142 : Closed e2407064435142 ∧ code e2407064435142 = 11203157457350 := by decide
theorem cert_e2407064435142 : check e2407064435142 [[],[],[.under]] .smaller = true := by decide
def e2407072279994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))))
theorem wire_e2407072279994 : Closed e2407072279994 ∧ code e2407072279994 = 11203165302202 := by decide
theorem cert_e2407072279994 : check e2407072279994 [[],[],[.left],[]] .smaller = true := by decide
def e2407072280026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))))
theorem wire_e2407072280026 : Closed e2407072280026 ∧ code e2407072280026 = 11203165302234 := by decide
theorem cert_e2407072280026 : check e2407072280026 [[],[],[.left],[]] .smaller = true := by decide
def e2407072280250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))))
theorem wire_e2407072280250 : Closed e2407072280250 ∧ code e2407072280250 = 11203165302458 := by decide
theorem cert_e2407072280250 : check e2407072280250 [[],[],[.left],[]] .smaller = true := by decide
def e2407072280298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))))
theorem wire_e2407072280298 : Closed e2407072280298 ∧ code e2407072280298 = 11203165302506 := by decide
theorem cert_e2407072280298 : check e2407072280298 [[],[],[.left],[]] .smaller = true := by decide
def e2407072280410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))))
theorem wire_e2407072280410 : Closed e2407072280410 ∧ code e2407072280410 = 11203165302618 := by decide
theorem cert_e2407072280410 : check e2407072280410 [[],[],[.left],[]] .smaller = true := by decide
def e2407072280426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))))
theorem wire_e2407072280426 : Closed e2407072280426 ∧ code e2407072280426 = 11203165302634 := by decide
theorem cert_e2407072280426 : check e2407072280426 [[],[],[.left],[]] .smaller = true := by decide
def e2407072281530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))))
theorem wire_e2407072281530 : Closed e2407072281530 ∧ code e2407072281530 = 11203165303738 := by decide
theorem cert_e2407072281530 : check e2407072281530 [[],[],[.left],[]] .smaller = true := by decide
def e2407072281562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))))
theorem wire_e2407072281562 : Closed e2407072281562 ∧ code e2407072281562 = 11203165303770 := by decide
theorem cert_e2407072281562 : check e2407072281562 [[],[],[.left],[]] .smaller = true := by decide
def e2407072283066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))))
theorem wire_e2407072283066 : Closed e2407072283066 ∧ code e2407072283066 = 11203165305274 := by decide
theorem cert_e2407072283066 : check e2407072283066 [[],[],[.left],[]] .smaller = true := by decide
def e2407072283114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))))
theorem wire_e2407072283114 : Closed e2407072283114 ∧ code e2407072283114 = 11203165305322 := by decide
theorem cert_e2407072283114 : check e2407072283114 [[],[],[.left],[]] .smaller = true := by decide
def e2407072283866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))))
theorem wire_e2407072283866 : Closed e2407072283866 ∧ code e2407072283866 = 11203165306074 := by decide
theorem cert_e2407072283866 : check e2407072283866 [[],[],[.left],[]] .smaller = true := by decide
def e2407072283882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))))
theorem wire_e2407072283882 : Closed e2407072283882 ∧ code e2407072283882 = 11203165306090 := by decide
theorem cert_e2407072283882 : check e2407072283882 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2407072533358 : Closed e2407072533358 ∧ code e2407072533358 = 11203165555566 := by decide
theorem cert_e2407072533358 : check e2407072533358 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2407072533366 : Closed e2407072533366 ∧ code e2407072533366 = 11203165555574 := by decide
theorem cert_e2407072533366 : check e2407072533366 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2407072533422 : Closed e2407072533422 ∧ code e2407072533422 = 11203165555630 := by decide
theorem cert_e2407072533422 : check e2407072533422 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2407072533434 : Closed e2407072533434 ∧ code e2407072533434 = 11203165555642 := by decide
theorem cert_e2407072533434 : check e2407072533434 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2407072533462 : Closed e2407072533462 ∧ code e2407072533462 = 11203165555670 := by decide
theorem cert_e2407072533462 : check e2407072533462 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533466 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2407072533466 : Closed e2407072533466 ∧ code e2407072533466 = 11203165555674 := by decide
theorem cert_e2407072533466 : check e2407072533466 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2407072533742 : Closed e2407072533742 ∧ code e2407072533742 = 11203165555950 := by decide
theorem cert_e2407072533742 : check e2407072533742 [[],[],[.left],[]] .smaller = true := by decide
def e2407072533750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2407072533750 : Closed e2407072533750 ∧ code e2407072533750 = 11203165555958 := by decide
theorem cert_e2407072533750 : check e2407072533750 [[],[],[.left],[]] .smaller = true := by decide
def e2407072534126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2407072534126 : Closed e2407072534126 ∧ code e2407072534126 = 11203165556334 := by decide
theorem cert_e2407072534126 : check e2407072534126 [[],[],[.left],[]] .smaller = true := by decide
def e2407072534138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2407072534138 : Closed e2407072534138 ∧ code e2407072534138 = 11203165556346 := by decide
theorem cert_e2407072534138 : check e2407072534138 [[],[],[.left],[]] .smaller = true := by decide
def e2407072534326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2407072534326 : Closed e2407072534326 ∧ code e2407072534326 = 11203165556534 := by decide
theorem cert_e2407072534326 : check e2407072534326 [[],[],[.left],[]] .smaller = true := by decide
def e2407072534330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2407072534330 : Closed e2407072534330 ∧ code e2407072534330 = 11203165556538 := by decide
theorem cert_e2407072534330 : check e2407072534330 [[],[],[.left],[]] .smaller = true := by decide
def e2407073328606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2407073328606 : Closed e2407073328606 ∧ code e2407073328606 = 11203166350814 := by decide
theorem cert_e2407073328606 : check e2407073328606 [[],[],[]] .smaller = true := by decide
def e2407073328622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2407073328622 : Closed e2407073328622 ∧ code e2407073328622 = 11203166350830 := by decide
theorem cert_e2407073328622 : check e2407073328622 [[],[],[]] .smaller = true := by decide
def e2407073328990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2407073328990 : Closed e2407073328990 ∧ code e2407073328990 = 11203166351198 := by decide
theorem cert_e2407073328990 : check e2407073328990 [[],[],[]] .smaller = true := by decide
def e2407073329018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2407073329018 : Closed e2407073329018 ∧ code e2407073329018 = 11203166351226 := by decide
theorem cert_e2407073329018 : check e2407073329018 [[],[],[]] .smaller = true := by decide
def e2407073329070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2407073329070 : Closed e2407073329070 ∧ code e2407073329070 = 11203166351278 := by decide
theorem cert_e2407073329070 : check e2407073329070 [[],[],[]] .smaller = true := by decide
def e2407073329082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2407073329082 : Closed e2407073329082 ∧ code e2407073329082 = 11203166351290 := by decide
theorem cert_e2407073329082 : check e2407073329082 [[],[],[]] .smaller = true := by decide
def e2407073330142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2407073330142 : Closed e2407073330142 ∧ code e2407073330142 = 11203166352350 := by decide
theorem cert_e2407073330142 : check e2407073330142 [[],[],[]] .smaller = true := by decide
def e2407073330158 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2407073330158 : Closed e2407073330158 ∧ code e2407073330158 = 11203166352366 := by decide
theorem cert_e2407073330158 : check e2407073330158 [[],[],[]] .smaller = true := by decide
def e2407073332446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2407073332446 : Closed e2407073332446 ∧ code e2407073332446 = 11203166354654 := by decide
theorem cert_e2407073332446 : check e2407073332446 [[],[],[]] .smaller = true := by decide
def e2407073332474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2407073332474 : Closed e2407073332474 ∧ code e2407073332474 = 11203166354682 := by decide
theorem cert_e2407073332474 : check e2407073332474 [[],[],[]] .smaller = true := by decide
def e2407073332846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407073332846 : Closed e2407073332846 ∧ code e2407073332846 = 11203166355054 := by decide
theorem cert_e2407073332846 : check e2407073332846 [[],[],[]] .smaller = true := by decide
def e2407073332858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407073332858 : Closed e2407073332858 ∧ code e2407073332858 = 11203166355066 := by decide
theorem cert_e2407073332858 : check e2407073332858 [[],[],[]] .smaller = true := by decide
def e2407073361262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2407073361262 : Closed e2407073361262 ∧ code e2407073361262 = 11203166383470 := by decide
theorem cert_e2407073361262 : check e2407073361262 [[],[],[]] .smaller = true := by decide
def e2407073361270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2407073361270 : Closed e2407073361270 ∧ code e2407073361270 = 11203166383478 := by decide
theorem cert_e2407073361270 : check e2407073361270 [[],[],[]] .smaller = true := by decide
def e2407073361326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2407073361326 : Closed e2407073361326 ∧ code e2407073361326 = 11203166383534 := by decide
theorem cert_e2407073361326 : check e2407073361326 [[],[],[]] .smaller = true := by decide
def e2407073361338 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2407073361338 : Closed e2407073361338 ∧ code e2407073361338 = 11203166383546 := by decide
theorem cert_e2407073361338 : check e2407073361338 [[],[],[]] .smaller = true := by decide
def e2407073361366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2407073361366 : Closed e2407073361366 ∧ code e2407073361366 = 11203166383574 := by decide
theorem cert_e2407073361366 : check e2407073361366 [[],[],[]] .smaller = true := by decide
def e2407073361370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2407073361370 : Closed e2407073361370 ∧ code e2407073361370 = 11203166383578 := by decide
theorem cert_e2407073361370 : check e2407073361370 [[],[],[]] .smaller = true := by decide
def e2407073361582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2407073361582 : Closed e2407073361582 ∧ code e2407073361582 = 11203166383790 := by decide
theorem cert_e2407073361582 : check e2407073361582 [[],[],[]] .smaller = true := by decide
def e2407073361594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2407073361594 : Closed e2407073361594 ∧ code e2407073361594 = 11203166383802 := by decide
theorem cert_e2407073361594 : check e2407073361594 [[],[],[]] .smaller = true := by decide
def e2407073361642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2407073361642 : Closed e2407073361642 ∧ code e2407073361642 = 11203166383850 := by decide
theorem cert_e2407073361642 : check e2407073361642 [[],[],[]] .smaller = true := by decide
def e2407073361750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2407073361750 : Closed e2407073361750 ∧ code e2407073361750 = 11203166383958 := by decide
theorem cert_e2407073361750 : check e2407073361750 [[],[],[]] .smaller = true := by decide
def e2407073361754 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2407073361754 : Closed e2407073361754 ∧ code e2407073361754 = 11203166383962 := by decide
theorem cert_e2407073361754 : check e2407073361754 [[],[],[]] .smaller = true := by decide
def e2407073361770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2407073361770 : Closed e2407073361770 ∧ code e2407073361770 = 11203166383978 := by decide
theorem cert_e2407073361770 : check e2407073361770 [[],[],[]] .smaller = true := by decide
def e2407073362798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2407073362798 : Closed e2407073362798 ∧ code e2407073362798 = 11203166385006 := by decide
theorem cert_e2407073362798 : check e2407073362798 [[],[],[]] .smaller = true := by decide
def e2407073362806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2407073362806 : Closed e2407073362806 ∧ code e2407073362806 = 11203166385014 := by decide
theorem cert_e2407073362806 : check e2407073362806 [[],[],[]] .smaller = true := by decide
def e2407073362862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2407073362862 : Closed e2407073362862 ∧ code e2407073362862 = 11203166385070 := by decide
theorem cert_e2407073362862 : check e2407073362862 [[],[],[]] .smaller = true := by decide
def e2407073362874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2407073362874 : Closed e2407073362874 ∧ code e2407073362874 = 11203166385082 := by decide
theorem cert_e2407073362874 : check e2407073362874 [[],[],[]] .smaller = true := by decide
def e2407073362902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2407073362902 : Closed e2407073362902 ∧ code e2407073362902 = 11203166385110 := by decide
theorem cert_e2407073362902 : check e2407073362902 [[],[],[]] .smaller = true := by decide
def e2407073362906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2407073362906 : Closed e2407073362906 ∧ code e2407073362906 = 11203166385114 := by decide
theorem cert_e2407073362906 : check e2407073362906 [[],[],[]] .smaller = true := by decide
def e2407073363182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2407073363182 : Closed e2407073363182 ∧ code e2407073363182 = 11203166385390 := by decide
theorem cert_e2407073363182 : check e2407073363182 [[],[],[]] .smaller = true := by decide
def e2407073363190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2407073363190 : Closed e2407073363190 ∧ code e2407073363190 = 11203166385398 := by decide
theorem cert_e2407073363190 : check e2407073363190 [[],[],[]] .smaller = true := by decide
def e2407073363566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407073363566 : Closed e2407073363566 ∧ code e2407073363566 = 11203166385774 := by decide
theorem cert_e2407073363566 : check e2407073363566 [[],[],[]] .smaller = true := by decide
def e2407073363578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407073363578 : Closed e2407073363578 ∧ code e2407073363578 = 11203166385786 := by decide
theorem cert_e2407073363578 : check e2407073363578 [[],[],[]] .smaller = true := by decide
def e2407073363766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407073363766 : Closed e2407073363766 ∧ code e2407073363766 = 11203166385974 := by decide
theorem cert_e2407073363766 : check e2407073363766 [[],[],[]] .smaller = true := by decide
def e2407073363770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407073363770 : Closed e2407073363770 ∧ code e2407073363770 = 11203166385978 := by decide
theorem cert_e2407073363770 : check e2407073363770 [[],[],[]] .smaller = true := by decide
def e2407073364398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2407073364398 : Closed e2407073364398 ∧ code e2407073364398 = 11203166386606 := by decide
theorem cert_e2407073364398 : check e2407073364398 [[],[],[]] .smaller = true := by decide
def e2407073364410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2407073364410 : Closed e2407073364410 ∧ code e2407073364410 = 11203166386618 := by decide
theorem cert_e2407073364410 : check e2407073364410 [[],[],[]] .smaller = true := by decide
def e2407073364458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2407073364458 : Closed e2407073364458 ∧ code e2407073364458 = 11203166386666 := by decide
theorem cert_e2407073364458 : check e2407073364458 [[],[],[]] .smaller = true := by decide
def e2407073364590 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407073364590 : Closed e2407073364590 ∧ code e2407073364590 = 11203166386798 := by decide
theorem cert_e2407073364590 : check e2407073364590 [[],[],[]] .smaller = true := by decide
def e2407073364602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407073364602 : Closed e2407073364602 ∧ code e2407073364602 = 11203166386810 := by decide
theorem cert_e2407073364602 : check e2407073364602 [[],[],[]] .smaller = true := by decide
def e2407073364890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407073364890 : Closed e2407073364890 ∧ code e2407073364890 = 11203166387098 := by decide
theorem cert_e2407073364890 : check e2407073364890 [[],[],[]] .smaller = true := by decide
def e2407073365206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2407073365206 : Closed e2407073365206 ∧ code e2407073365206 = 11203166387414 := by decide
theorem cert_e2407073365206 : check e2407073365206 [[],[],[]] .smaller = true := by decide
def e2407073365210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2407073365210 : Closed e2407073365210 ∧ code e2407073365210 = 11203166387418 := by decide
theorem cert_e2407073365210 : check e2407073365210 [[],[],[]] .smaller = true := by decide
def e2407073365226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2407073365226 : Closed e2407073365226 ∧ code e2407073365226 = 11203166387434 := by decide
theorem cert_e2407073365226 : check e2407073365226 [[],[],[]] .smaller = true := by decide
def e2407073365302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407073365302 : Closed e2407073365302 ∧ code e2407073365302 = 11203166387510 := by decide
theorem cert_e2407073365302 : check e2407073365302 [[],[],[]] .smaller = true := by decide
def e2407073365306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407073365306 : Closed e2407073365306 ∧ code e2407073365306 = 11203166387514 := by decide
theorem cert_e2407073365306 : check e2407073365306 [[],[],[]] .smaller = true := by decide
def e2407073365402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407073365402 : Closed e2407073365402 ∧ code e2407073365402 = 11203166387610 := by decide
theorem cert_e2407073365402 : check e2407073365402 [[],[],[]] .smaller = true := by decide
def e2407073367006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2407073367006 : Closed e2407073367006 ∧ code e2407073367006 = 11203166389214 := by decide
theorem cert_e2407073367006 : check e2407073367006 [[],[],[]] .smaller = true := by decide
def e2407073367022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2407073367022 : Closed e2407073367022 ∧ code e2407073367022 = 11203166389230 := by decide
theorem cert_e2407073367022 : check e2407073367022 [[],[],[]] .smaller = true := by decide
def e2407073368942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2407073368942 : Closed e2407073368942 ∧ code e2407073368942 = 11203166391150 := by decide
theorem cert_e2407073368942 : check e2407073368942 [[],[],[]] .smaller = true := by decide
def e2407073368950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2407073368950 : Closed e2407073368950 ∧ code e2407073368950 = 11203166391158 := by decide
theorem cert_e2407073368950 : check e2407073368950 [[],[],[]] .smaller = true := by decide
def e2407073369006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2407073369006 : Closed e2407073369006 ∧ code e2407073369006 = 11203166391214 := by decide
theorem cert_e2407073369006 : check e2407073369006 [[],[],[]] .smaller = true := by decide
def e2407073369018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2407073369018 : Closed e2407073369018 ∧ code e2407073369018 = 11203166391226 := by decide
theorem cert_e2407073369018 : check e2407073369018 [[],[],[]] .smaller = true := by decide
def e2407073369046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2407073369046 : Closed e2407073369046 ∧ code e2407073369046 = 11203166391254 := by decide
theorem cert_e2407073369046 : check e2407073369046 [[],[],[]] .smaller = true := by decide
def e2407073369050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2407073369050 : Closed e2407073369050 ∧ code e2407073369050 = 11203166391258 := by decide
theorem cert_e2407073369050 : check e2407073369050 [[],[],[]] .smaller = true := by decide
def e2407073369326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407073369326 : Closed e2407073369326 ∧ code e2407073369326 = 11203166391534 := by decide
theorem cert_e2407073369326 : check e2407073369326 [[],[],[]] .smaller = true := by decide
def e2407073369334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407073369334 : Closed e2407073369334 ∧ code e2407073369334 = 11203166391542 := by decide
theorem cert_e2407073369334 : check e2407073369334 [[],[],[]] .smaller = true := by decide
def e2407073369710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407073369710 : Closed e2407073369710 ∧ code e2407073369710 = 11203166391918 := by decide
theorem cert_e2407073369710 : check e2407073369710 [[],[],[]] .smaller = true := by decide
def e2407073369722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407073369722 : Closed e2407073369722 ∧ code e2407073369722 = 11203166391930 := by decide
theorem cert_e2407073369722 : check e2407073369722 [[],[],[]] .smaller = true := by decide
def e2407073369910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407073369910 : Closed e2407073369910 ∧ code e2407073369910 = 11203166392118 := by decide
theorem cert_e2407073369910 : check e2407073369910 [[],[],[]] .smaller = true := by decide
def e2407073369914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407073369914 : Closed e2407073369914 ∧ code e2407073369914 = 11203166392122 := by decide
theorem cert_e2407073369914 : check e2407073369914 [[],[],[]] .smaller = true := by decide
def e2407073374686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2407073374686 : Closed e2407073374686 ∧ code e2407073374686 = 11203166396894 := by decide
theorem cert_e2407073374686 : check e2407073374686 [[],[],[]] .smaller = true := by decide
def e2407073374710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2407073374710 : Closed e2407073374710 ∧ code e2407073374710 = 11203166396918 := by decide
theorem cert_e2407073374710 : check e2407073374710 [[],[],[]] .smaller = true := by decide
def e2407073375662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2407073375662 : Closed e2407073375662 ∧ code e2407073375662 = 11203166397870 := by decide
theorem cert_e2407073375662 : check e2407073375662 [[],[],[]] .smaller = true := by decide
def e2407073375674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2407073375674 : Closed e2407073375674 ∧ code e2407073375674 = 11203166397882 := by decide
theorem cert_e2407073375674 : check e2407073375674 [[],[],[]] .smaller = true := by decide
def e2407073375722 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2407073375722 : Closed e2407073375722 ∧ code e2407073375722 = 11203166397930 := by decide
theorem cert_e2407073375722 : check e2407073375722 [[],[],[]] .smaller = true := by decide
def e2407073375854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407073375854 : Closed e2407073375854 ∧ code e2407073375854 = 11203166398062 := by decide
theorem cert_e2407073375854 : check e2407073375854 [[],[],[]] .smaller = true := by decide
def e2407073375866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407073375866 : Closed e2407073375866 ∧ code e2407073375866 = 11203166398074 := by decide
theorem cert_e2407073375866 : check e2407073375866 [[],[],[]] .smaller = true := by decide
def e2407073376154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407073376154 : Closed e2407073376154 ∧ code e2407073376154 = 11203166398362 := by decide
theorem cert_e2407073376154 : check e2407073376154 [[],[],[]] .smaller = true := by decide
def e2407073378542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2407073378542 : Closed e2407073378542 ∧ code e2407073378542 = 11203166400750 := by decide
theorem cert_e2407073378542 : check e2407073378542 [[],[],[]] .smaller = true := by decide
def e2407073378550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2407073378550 : Closed e2407073378550 ∧ code e2407073378550 = 11203166400758 := by decide
theorem cert_e2407073378550 : check e2407073378550 [[],[],[]] .smaller = true := by decide
def e2407073379030 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2407073379030 : Closed e2407073379030 ∧ code e2407073379030 = 11203166401238 := by decide
theorem cert_e2407073379030 : check e2407073379030 [[],[],[]] .smaller = true := by decide
def e2407073379034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2407073379034 : Closed e2407073379034 ∧ code e2407073379034 = 11203166401242 := by decide
theorem cert_e2407073379034 : check e2407073379034 [[],[],[]] .smaller = true := by decide
def e2407073379050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2407073379050 : Closed e2407073379050 ∧ code e2407073379050 = 11203166401258 := by decide
theorem cert_e2407073379050 : check e2407073379050 [[],[],[]] .smaller = true := by decide
def e2407073379126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407073379126 : Closed e2407073379126 ∧ code e2407073379126 = 11203166401334 := by decide
theorem cert_e2407073379126 : check e2407073379126 [[],[],[]] .smaller = true := by decide
def e2407073379130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407073379130 : Closed e2407073379130 ∧ code e2407073379130 = 11203166401338 := by decide
theorem cert_e2407073379130 : check e2407073379130 [[],[],[]] .smaller = true := by decide
def e2407073379226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407073379226 : Closed e2407073379226 ∧ code e2407073379226 = 11203166401434 := by decide
theorem cert_e2407073379226 : check e2407073379226 [[],[],[]] .smaller = true := by decide
def e2407073516398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2407073516398 : Closed e2407073516398 ∧ code e2407073516398 = 11203166538606 := by decide
theorem cert_e2407073516398 : check e2407073516398 [[],[],[]] .smaller = true := by decide
def e2407073516406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2407073516406 : Closed e2407073516406 ∧ code e2407073516406 = 11203166538614 := by decide
theorem cert_e2407073516406 : check e2407073516406 [[],[],[]] .smaller = true := by decide
def e2407073516462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2407073516462 : Closed e2407073516462 ∧ code e2407073516462 = 11203166538670 := by decide
theorem cert_e2407073516462 : check e2407073516462 [[],[],[]] .smaller = true := by decide
def e2407073516474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2407073516474 : Closed e2407073516474 ∧ code e2407073516474 = 11203166538682 := by decide
theorem cert_e2407073516474 : check e2407073516474 [[],[],[]] .smaller = true := by decide
def e2407073516502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2407073516502 : Closed e2407073516502 ∧ code e2407073516502 = 11203166538710 := by decide
theorem cert_e2407073516502 : check e2407073516502 [[],[],[]] .smaller = true := by decide
def e2407073516506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2407073516506 : Closed e2407073516506 ∧ code e2407073516506 = 11203166538714 := by decide
theorem cert_e2407073516506 : check e2407073516506 [[],[],[]] .smaller = true := by decide
def e2407073516782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407073516782 : Closed e2407073516782 ∧ code e2407073516782 = 11203166538990 := by decide
theorem cert_e2407073516782 : check e2407073516782 [[],[],[]] .smaller = true := by decide
def e2407073516790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407073516790 : Closed e2407073516790 ∧ code e2407073516790 = 11203166538998 := by decide
theorem cert_e2407073516790 : check e2407073516790 [[],[],[]] .smaller = true := by decide
def e2407073517166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407073517166 : Closed e2407073517166 ∧ code e2407073517166 = 11203166539374 := by decide
theorem cert_e2407073517166 : check e2407073517166 [[],[],[]] .smaller = true := by decide
def e2407073517178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407073517178 : Closed e2407073517178 ∧ code e2407073517178 = 11203166539386 := by decide
theorem cert_e2407073517178 : check e2407073517178 [[],[],[]] .smaller = true := by decide
def e2407073517366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407073517366 : Closed e2407073517366 ∧ code e2407073517366 = 11203166539574 := by decide
theorem cert_e2407073517366 : check e2407073517366 [[],[],[]] .smaller = true := by decide
def e2407073517370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407073517370 : Closed e2407073517370 ∧ code e2407073517370 = 11203166539578 := by decide
theorem cert_e2407073517370 : check e2407073517370 [[],[],[]] .smaller = true := by decide
def e2407074106222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2407074106222 : Closed e2407074106222 ∧ code e2407074106222 = 11203167128430 := by decide
theorem cert_e2407074106222 : check e2407074106222 [[],[],[]] .smaller = true := by decide
def e2407074106230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2407074106230 : Closed e2407074106230 ∧ code e2407074106230 = 11203167128438 := by decide
theorem cert_e2407074106230 : check e2407074106230 [[],[],[]] .smaller = true := by decide
def e2407074106286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2407074106286 : Closed e2407074106286 ∧ code e2407074106286 = 11203167128494 := by decide
theorem cert_e2407074106286 : check e2407074106286 [[],[],[]] .smaller = true := by decide
def e2407074106298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2407074106298 : Closed e2407074106298 ∧ code e2407074106298 = 11203167128506 := by decide
theorem cert_e2407074106298 : check e2407074106298 [[],[],[]] .smaller = true := by decide
def e2407074106326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2407074106326 : Closed e2407074106326 ∧ code e2407074106326 = 11203167128534 := by decide
theorem cert_e2407074106326 : check e2407074106326 [[],[],[]] .smaller = true := by decide
def e2407074106330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2407074106330 : Closed e2407074106330 ∧ code e2407074106330 = 11203167128538 := by decide
theorem cert_e2407074106330 : check e2407074106330 [[],[],[]] .smaller = true := by decide
def e2407074106606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407074106606 : Closed e2407074106606 ∧ code e2407074106606 = 11203167128814 := by decide
theorem cert_e2407074106606 : check e2407074106606 [[],[],[]] .smaller = true := by decide
def e2407074106614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407074106614 : Closed e2407074106614 ∧ code e2407074106614 = 11203167128822 := by decide
theorem cert_e2407074106614 : check e2407074106614 [[],[],[]] .smaller = true := by decide
def e2407074106990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407074106990 : Closed e2407074106990 ∧ code e2407074106990 = 11203167129198 := by decide
theorem cert_e2407074106990 : check e2407074106990 [[],[],[]] .smaller = true := by decide
def e2407074107002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407074107002 : Closed e2407074107002 ∧ code e2407074107002 = 11203167129210 := by decide
theorem cert_e2407074107002 : check e2407074107002 [[],[],[]] .smaller = true := by decide
def e2407074107190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407074107190 : Closed e2407074107190 ∧ code e2407074107190 = 11203167129398 := by decide
theorem cert_e2407074107190 : check e2407074107190 [[],[],[]] .smaller = true := by decide
def e2407074107194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407074107194 : Closed e2407074107194 ∧ code e2407074107194 = 11203167129402 := by decide
theorem cert_e2407074107194 : check e2407074107194 [[],[],[]] .smaller = true := by decide
def e2408146462746 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408146462746 : Closed e2408146462746 ∧ code e2408146462746 = 11204239484954 := by decide
theorem cert_e2408146462746 : check e2408146462746 [[]] .width = true := by decide
def e2408146495514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408146495514 : Closed e2408146495514 ∧ code e2408146495514 = 11204239517722 := by decide
theorem cert_e2408146495514 : check e2408146495514 [[]] .width = true := by decide
def e2408146724890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408146724890 : Closed e2408146724890 ∧ code e2408146724890 = 11204239747098 := by decide
theorem cert_e2408146724890 : check e2408146724890 [[]] .width = true := by decide
def e2408146774042 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408146774042 : Closed e2408146774042 ∧ code e2408146774042 = 11204239796250 := by decide
theorem cert_e2408146774042 : check e2408146774042 [[]] .width = true := by decide
def e2408146888730 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408146888730 : Closed e2408146888730 ∧ code e2408146888730 = 11204239910938 := by decide
theorem cert_e2408146888730 : check e2408146888730 [[]] .width = true := by decide
def e2408146905114 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408146905114 : Closed e2408146905114 ∧ code e2408146905114 = 11204239927322 := by decide
theorem cert_e2408146905114 : check e2408146905114 [[]] .width = true := by decide
def e2408148035610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408148035610 : Closed e2408148035610 ∧ code e2408148035610 = 11204241057818 := by decide
theorem cert_e2408148035610 : check e2408148035610 [[]] .width = true := by decide
def e2408148068378 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408148068378 : Closed e2408148068378 ∧ code e2408148068378 = 11204241090586 := by decide
theorem cert_e2408148068378 : check e2408148068378 [[]] .width = true := by decide
def e2408149608474 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408149608474 : Closed e2408149608474 ∧ code e2408149608474 = 11204242630682 := by decide
theorem cert_e2408149608474 : check e2408149608474 [[]] .width = true := by decide
def e2408149657626 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408149657626 : Closed e2408149657626 ∧ code e2408149657626 = 11204242679834 := by decide
theorem cert_e2408149657626 : check e2408149657626 [[]] .width = true := by decide
def e2408150427674 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408150427674 : Closed e2408150427674 ∧ code e2408150427674 = 11204243449882 := by decide
theorem cert_e2408150427674 : check e2408150427674 [[]] .width = true := by decide
def e2408150444058 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408150444058 : Closed e2408150444058 ∧ code e2408150444058 = 11204243466266 := by decide
theorem cert_e2408150444058 : check e2408150444058 [[]] .width = true := by decide
def e2408204580890 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204580890 : Closed e2408204580890 ∧ code e2408204580890 = 11204297603098 := by decide
theorem cert_e2408204580890 : check e2408204580890 [[]] .width = true := by decide
def e2408204589082 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204589082 : Closed e2408204589082 ∧ code e2408204589082 = 11204297611290 := by decide
theorem cert_e2408204589082 : check e2408204589082 [[]] .width = true := by decide
def e2408204646426 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204646426 : Closed e2408204646426 ∧ code e2408204646426 = 11204297668634 := by decide
theorem cert_e2408204646426 : check e2408204646426 [[]] .width = true := by decide
def e2408204658714 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204658714 : Closed e2408204658714 ∧ code e2408204658714 = 11204297680922 := by decide
theorem cert_e2408204658714 : check e2408204658714 [[]] .width = true := by decide
def e2408204687386 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204687386 : Closed e2408204687386 ∧ code e2408204687386 = 11204297709594 := by decide
theorem cert_e2408204687386 : check e2408204687386 [[]] .width = true := by decide
def e2408204691482 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204691482 : Closed e2408204691482 ∧ code e2408204691482 = 11204297713690 := by decide
theorem cert_e2408204691482 : check e2408204691482 [[]] .width = true := by decide
def e2408204974106 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204974106 : Closed e2408204974106 ∧ code e2408204974106 = 11204297996314 := by decide
theorem cert_e2408204974106 : check e2408204974106 [[]] .width = true := by decide
def e2408204982298 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408204982298 : Closed e2408204982298 ∧ code e2408204982298 = 11204298004506 := by decide
theorem cert_e2408204982298 : check e2408204982298 [[]] .width = true := by decide
def e2408205367322 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408205367322 : Closed e2408205367322 ∧ code e2408205367322 = 11204298389530 := by decide
theorem cert_e2408205367322 : check e2408205367322 [[]] .width = true := by decide
def e2408205379610 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408205379610 : Closed e2408205379610 ∧ code e2408205379610 = 11204298401818 := by decide
theorem cert_e2408205379610 : check e2408205379610 [[]] .width = true := by decide
def e2408205572122 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408205572122 : Closed e2408205572122 ∧ code e2408205572122 = 11204298594330 := by decide
theorem cert_e2408205572122 : check e2408205572122 [[]] .width = true := by decide
def e2408205576218 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2408205576218 : Closed e2408205576218 ∧ code e2408205576218 = 11204298598426 := by decide
theorem cert_e2408205576218 : check e2408205576218 [[]] .width = true := by decide
def e2408274687514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408274687514 : Closed e2408274687514 ∧ code e2408274687514 = 11204367709722 := by decide
private def t_e2408274687514 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408274687514 : ¬ IsSelfInterpreter e2408274687514 :=
  wSource (t := t_e2408274687514) (replay_sound (ps := []) (t := e2408274687514) (by decide)) (by decide)
def e2408274703898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408274703898 : Closed e2408274703898 ∧ code e2408274703898 = 11204367726106 := by decide
private def t_e2408274703898 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408274703898 : ¬ IsSelfInterpreter e2408274703898 :=
  wSource (t := t_e2408274703898) (replay_sound (ps := []) (t := e2408274703898) (by decide)) (by decide)
def e2408274818586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408274818586 : Closed e2408274818586 ∧ code e2408274818586 = 11204367840794 := by decide
private def t_e2408274818586 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408274818586 : ¬ IsSelfInterpreter e2408274818586 :=
  wSource (t := t_e2408274818586) (replay_sound (ps := []) (t := e2408274818586) (by decide)) (by decide)
def e2408274843162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408274843162 : Closed e2408274843162 ∧ code e2408274843162 = 11204367865370 := by decide
private def t_e2408274843162 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408274843162 : ¬ IsSelfInterpreter e2408274843162 :=
  wSource (t := t_e2408274843162) (replay_sound (ps := []) (t := e2408274843162) (by decide)) (by decide)
def e2408274900506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408274900506 : Closed e2408274900506 ∧ code e2408274900506 = 11204367922714 := by decide
private def t_e2408274900506 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408274900506 : ¬ IsSelfInterpreter e2408274900506 :=
  wSource (t := t_e2408274900506) (replay_sound (ps := []) (t := e2408274900506) (by decide)) (by decide)
def e2408274908698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408274908698 : Closed e2408274908698 ∧ code e2408274908698 = 11204367930906 := by decide
private def t_e2408274908698 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408274908698 : ¬ IsSelfInterpreter e2408274908698 :=
  wSource (t := t_e2408274908698) (replay_sound (ps := []) (t := e2408274908698) (by decide)) (by decide)
def e2408275473946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408275473946 : Closed e2408275473946 ∧ code e2408275473946 = 11204368496154 := by decide
private def t_e2408275473946 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408275473946 : ¬ IsSelfInterpreter e2408275473946 :=
  wSource (t := t_e2408275473946) (replay_sound (ps := []) (t := e2408275473946) (by decide)) (by decide)
def e2408275490330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2408275490330 : Closed e2408275490330 ∧ code e2408275490330 = 11204368512538 := by decide
private def t_e2408275490330 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2408275490330 : ¬ IsSelfInterpreter e2408275490330 :=
  wSource (t := t_e2408275490330) (replay_sound (ps := []) (t := e2408275490330) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2408274687514
#print axioms Blc.Floor43.cert_e2408274703898
#print axioms Blc.Floor43.cert_e2408274818586
#print axioms Blc.Floor43.cert_e2408274843162
#print axioms Blc.Floor43.cert_e2408274900506
#print axioms Blc.Floor43.cert_e2408274908698
#print axioms Blc.Floor43.cert_e2408275473946
#print axioms Blc.Floor43.cert_e2408275490330
