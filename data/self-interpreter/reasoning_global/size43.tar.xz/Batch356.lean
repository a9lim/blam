import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419144023926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2419144023926 : Closed e2419144023926 ∧ code e2419144023926 = 11215237046134 := by decide
theorem cert_e2419144023926 : check e2419144023926 [[],[]] .sourceHead = true := by decide
def e2419144025886 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2419144025886 : Closed e2419144025886 ∧ code e2419144025886 = 11215237048094 := by decide
theorem cert_e2419144025886 : check e2419144025886 [[],[]] .smaller = true := by decide
def e2419144025998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2419144025998 : Closed e2419144025998 ∧ code e2419144025998 = 11215237048206 := by decide
theorem cert_e2419144025998 : check e2419144025998 [[],[]] .smaller = true := by decide
def e2419144028958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2419144028958 : Closed e2419144028958 ∧ code e2419144028958 = 11215237051166 := by decide
theorem cert_e2419144028958 : check e2419144028958 [[],[]] .smaller = true := by decide
def e2419144029126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2419144029126 : Closed e2419144029126 ∧ code e2419144029126 = 11215237051334 := by decide
theorem cert_e2419144029126 : check e2419144029126 [[],[]] .smaller = true := by decide
def e2419144029150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419144029150 : Closed e2419144029150 ∧ code e2419144029150 = 11215237051358 := by decide
theorem cert_e2419144029150 : check e2419144029150 [[],[]] .sourceHead = true := by decide
def e2419144029166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419144029166 : Closed e2419144029166 ∧ code e2419144029166 = 11215237051374 := by decide
theorem cert_e2419144029166 : check e2419144029166 [[],[]] .sourceHead = true := by decide
def e2419144030606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2419144030606 : Closed e2419144030606 ∧ code e2419144030606 = 11215237052814 := by decide
theorem cert_e2419144030606 : check e2419144030606 [[],[]] .smaller = true := by decide
def e2419144030662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2419144030662 : Closed e2419144030662 ∧ code e2419144030662 = 11215237052870 := by decide
theorem cert_e2419144030662 : check e2419144030662 [[],[]] .smaller = true := by decide
def e2419144030686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419144030686 : Closed e2419144030686 ∧ code e2419144030686 = 11215237052894 := by decide
theorem cert_e2419144030686 : check e2419144030686 [[],[]] .sourceHead = true := by decide
def e2419144030710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419144030710 : Closed e2419144030710 ∧ code e2419144030710 = 11215237052918 := by decide
theorem cert_e2419144030710 : check e2419144030710 [[],[]] .sourceHead = true := by decide
def e2419144031470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419144031470 : Closed e2419144031470 ∧ code e2419144031470 = 11215237053678 := by decide
theorem cert_e2419144031470 : check e2419144031470 [[],[]] .sourceHead = true := by decide
def e2419144031478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419144031478 : Closed e2419144031478 ∧ code e2419144031478 = 11215237053686 := by decide
theorem cert_e2419144031478 : check e2419144031478 [[],[]] .sourceHead = true := by decide
def e2419144071790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419144071790 : Closed e2419144071790 ∧ code e2419144071790 = 11215237093998 := by decide
theorem cert_e2419144071790 : check e2419144071790 [[],[]] .sourceHead = true := by decide
def e2419144071802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419144071802 : Closed e2419144071802 ∧ code e2419144071802 = 11215237094010 := by decide
theorem cert_e2419144071802 : check e2419144071802 [[],[]] .sourceHead = true := by decide
def e2419144087726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2419144087726 : Closed e2419144087726 ∧ code e2419144087726 = 11215237109934 := by decide
theorem cert_e2419144087726 : check e2419144087726 [[],[]] .sourceHead = true := by decide
def e2419144087738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2419144087738 : Closed e2419144087738 ∧ code e2419144087738 = 11215237109946 := by decide
theorem cert_e2419144087738 : check e2419144087738 [[],[]] .sourceHead = true := by decide
def e2419144088110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2419144088110 : Closed e2419144088110 ∧ code e2419144088110 = 11215237110318 := by decide
theorem cert_e2419144088110 : check e2419144088110 [[],[]] .sourceHead = true := by decide
def e2419144088290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2419144088290 : Closed e2419144088290 ∧ code e2419144088290 = 11215237110498 := by decide
theorem cert_e2419144088290 : check e2419144088290 [[],[]] .sourceHead = true := by decide
def e2419144088302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2419144088302 : Closed e2419144088302 ∧ code e2419144088302 = 11215237110510 := by decide
theorem cert_e2419144088302 : check e2419144088302 [[],[]] .sourceHead = true := by decide
def e2419144088430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2419144088430 : Closed e2419144088430 ∧ code e2419144088430 = 11215237110638 := by decide
theorem cert_e2419144088430 : check e2419144088430 [[],[]] .sourceHead = true := by decide
def e2419144088438 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2419144088438 : Closed e2419144088438 ∧ code e2419144088438 = 11215237110646 := by decide
theorem cert_e2419144088438 : check e2419144088438 [[],[]] .sourceHead = true := by decide
def e2419144088458 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419144088458 : Closed e2419144088458 ∧ code e2419144088458 = 11215237110666 := by decide
theorem cert_e2419144088458 : check e2419144088458 [[],[]] .sourceHead = true := by decide
def e2419144088482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419144088482 : Closed e2419144088482 ∧ code e2419144088482 = 11215237110690 := by decide
theorem cert_e2419144088482 : check e2419144088482 [[],[]] .sourceHead = true := by decide
def e2419144088494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2)))))))
theorem wire_e2419144088494 : Closed e2419144088494 ∧ code e2419144088494 = 11215237110702 := by decide
theorem cert_e2419144088494 : check e2419144088494 [[],[]] .sourceHead = true := by decide
def e2419144088502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))
theorem wire_e2419144088502 : Closed e2419144088502 ∧ code e2419144088502 = 11215237110710 := by decide
theorem cert_e2419144088502 : check e2419144088502 [[],[]] .sourceHead = true := by decide
def e2419144088506 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0)))))))
theorem wire_e2419144088506 : Closed e2419144088506 ∧ code e2419144088506 = 11215237110714 := by decide
theorem cert_e2419144088506 : check e2419144088506 [[],[]] .sourceHead = true := by decide
def e2419144088942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2419144088942 : Closed e2419144088942 ∧ code e2419144088942 = 11215237111150 := by decide
theorem cert_e2419144088942 : check e2419144088942 [[],[]] .sourceHead = true := by decide
def e2419144088950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2419144088950 : Closed e2419144088950 ∧ code e2419144088950 = 11215237111158 := by decide
theorem cert_e2419144088950 : check e2419144088950 [[],[]] .sourceHead = true := by decide
def e2419144089006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2419144089006 : Closed e2419144089006 ∧ code e2419144089006 = 11215237111214 := by decide
theorem cert_e2419144089006 : check e2419144089006 [[],[]] .sourceHead = true := by decide
def e2419144089018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2419144089018 : Closed e2419144089018 ∧ code e2419144089018 = 11215237111226 := by decide
theorem cert_e2419144089018 : check e2419144089018 [[],[]] .sourceHead = true := by decide
def e2419144089046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2419144089046 : Closed e2419144089046 ∧ code e2419144089046 = 11215237111254 := by decide
theorem cert_e2419144089046 : check e2419144089046 [[],[]] .sourceHead = true := by decide
def e2419144089050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2419144089050 : Closed e2419144089050 ∧ code e2419144089050 = 11215237111258 := by decide
theorem cert_e2419144089050 : check e2419144089050 [[],[]] .sourceHead = true := by decide
def e2419144089130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2419144089130 : Closed e2419144089130 ∧ code e2419144089130 = 11215237111338 := by decide
theorem cert_e2419144089130 : check e2419144089130 [[],[]] .sourceHead = true := by decide
def e2419144089226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2419144089226 : Closed e2419144089226 ∧ code e2419144089226 = 11215237111434 := by decide
theorem cert_e2419144089226 : check e2419144089226 [[],[]] .sourceHead = true := by decide
def e2419144089250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2419144089250 : Closed e2419144089250 ∧ code e2419144089250 = 11215237111458 := by decide
theorem cert_e2419144089250 : check e2419144089250 [[],[]] .sourceHead = true := by decide
def e2419144089262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2419144089262 : Closed e2419144089262 ∧ code e2419144089262 = 11215237111470 := by decide
theorem cert_e2419144089262 : check e2419144089262 [[],[]] .sourceHead = true := by decide
def e2419144089270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))
theorem wire_e2419144089270 : Closed e2419144089270 ∧ code e2419144089270 = 11215237111478 := by decide
theorem cert_e2419144089270 : check e2419144089270 [[],[]] .sourceHead = true := by decide
def e2419144089274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2419144089274 : Closed e2419144089274 ∧ code e2419144089274 = 11215237111482 := by decide
theorem cert_e2419144089274 : check e2419144089274 [[],[]] .sourceHead = true := by decide
def e2419144089302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))
theorem wire_e2419144089302 : Closed e2419144089302 ∧ code e2419144089302 = 11215237111510 := by decide
theorem cert_e2419144089302 : check e2419144089302 [[],[]] .sourceHead = true := by decide
def e2419144089306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))
theorem wire_e2419144089306 : Closed e2419144089306 ∧ code e2419144089306 = 11215237111514 := by decide
theorem cert_e2419144089306 : check e2419144089306 [[],[]] .sourceHead = true := by decide
def e2419144089322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2419144089322 : Closed e2419144089322 ∧ code e2419144089322 = 11215237111530 := by decide
theorem cert_e2419144089322 : check e2419144089322 [[],[]] .sourceHead = true := by decide
def e2419144089838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2419144089838 : Closed e2419144089838 ∧ code e2419144089838 = 11215237112046 := by decide
theorem cert_e2419144089838 : check e2419144089838 [[],[]] .sourceHead = true := by decide
def e2419144089850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2419144089850 : Closed e2419144089850 ∧ code e2419144089850 = 11215237112058 := by decide
theorem cert_e2419144089850 : check e2419144089850 [[],[]] .sourceHead = true := by decide
def e2419144090030 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2419144090030 : Closed e2419144090030 ∧ code e2419144090030 = 11215237112238 := by decide
theorem cert_e2419144090030 : check e2419144090030 [[],[]] .sourceHead = true := by decide
def e2419144090222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2419144090222 : Closed e2419144090222 ∧ code e2419144090222 = 11215237112430 := by decide
theorem cert_e2419144090222 : check e2419144090222 [[],[]] .sourceHead = true := by decide
def e2419144090234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2419144090234 : Closed e2419144090234 ∧ code e2419144090234 = 11215237112442 := by decide
theorem cert_e2419144090234 : check e2419144090234 [[],[]] .sourceHead = true := by decide
def e2419144090398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 3))))))))
theorem wire_e2419144090398 : Closed e2419144090398 ∧ code e2419144090398 = 11215237112606 := by decide
theorem cert_e2419144090398 : check e2419144090398 [[],[]] .sourceHead = true := by decide
def e2419144090566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))))))))
theorem wire_e2419144090566 : Closed e2419144090566 ∧ code e2419144090566 = 11215237112774 := by decide
theorem cert_e2419144090566 : check e2419144090566 [[],[]] .sourceHead = true := by decide
def e2419144091182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2419144091182 : Closed e2419144091182 ∧ code e2419144091182 = 11215237113390 := by decide
theorem cert_e2419144091182 : check e2419144091182 [[],[]] .sourceHead = true := by decide
def e2419144091362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))))))))
theorem wire_e2419144091362 : Closed e2419144091362 ∧ code e2419144091362 = 11215237113570 := by decide
theorem cert_e2419144091362 : check e2419144091362 [[],[]] .sourceHead = true := by decide
def e2419144091374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)))))))
theorem wire_e2419144091374 : Closed e2419144091374 ∧ code e2419144091374 = 11215237113582 := by decide
theorem cert_e2419144091374 : check e2419144091374 [[],[]] .sourceHead = true := by decide
def e2419144091502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))
theorem wire_e2419144091502 : Closed e2419144091502 ∧ code e2419144091502 = 11215237113710 := by decide
theorem cert_e2419144091502 : check e2419144091502 [[],[]] .sourceHead = true := by decide
def e2419144091510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))
theorem wire_e2419144091510 : Closed e2419144091510 ∧ code e2419144091510 = 11215237113718 := by decide
theorem cert_e2419144091510 : check e2419144091510 [[],[]] .sourceHead = true := by decide
def e2419144091530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419144091530 : Closed e2419144091530 ∧ code e2419144091530 = 11215237113738 := by decide
theorem cert_e2419144091530 : check e2419144091530 [[],[]] .sourceHead = true := by decide
def e2419144091554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419144091554 : Closed e2419144091554 ∧ code e2419144091554 = 11215237113762 := by decide
theorem cert_e2419144091554 : check e2419144091554 [[],[]] .sourceHead = true := by decide
def e2419144091566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)))))))
theorem wire_e2419144091566 : Closed e2419144091566 ∧ code e2419144091566 = 11215237113774 := by decide
theorem cert_e2419144091566 : check e2419144091566 [[],[]] .sourceHead = true := by decide
def e2419144091574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))
theorem wire_e2419144091574 : Closed e2419144091574 ∧ code e2419144091574 = 11215237113782 := by decide
theorem cert_e2419144091574 : check e2419144091574 [[],[]] .sourceHead = true := by decide
def e2419144091578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)))))))
theorem wire_e2419144091578 : Closed e2419144091578 ∧ code e2419144091578 = 11215237113786 := by decide
theorem cert_e2419144091578 : check e2419144091578 [[],[]] .sourceHead = true := by decide
def e2419144091710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))))))))
theorem wire_e2419144091710 : Closed e2419144091710 ∧ code e2419144091710 = 11215237113918 := by decide
theorem cert_e2419144091710 : check e2419144091710 [[],[]] .sourceHead = true := by decide
def e2419144092130 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2419144092130 : Closed e2419144092130 ∧ code e2419144092130 = 11215237114338 := by decide
theorem cert_e2419144092130 : check e2419144092130 [[],[]] .sourceHead = true := by decide
def e2419144092142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))))))))
theorem wire_e2419144092142 : Closed e2419144092142 ∧ code e2419144092142 = 11215237114350 := by decide
theorem cert_e2419144092142 : check e2419144092142 [[],[]] .sourceHead = true := by decide
def e2419144092910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419144092910 : Closed e2419144092910 ∧ code e2419144092910 = 11215237115118 := by decide
theorem cert_e2419144092910 : check e2419144092910 [[],[]] .sourceHead = true := by decide
def e2419144092918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419144092918 : Closed e2419144092918 ∧ code e2419144092918 = 11215237115126 := by decide
theorem cert_e2419144092918 : check e2419144092918 [[],[]] .sourceHead = true := by decide
def e2419144093198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419144093198 : Closed e2419144093198 ∧ code e2419144093198 = 11215237115406 := by decide
theorem cert_e2419144093198 : check e2419144093198 [[],[]] .sourceHead = true := by decide
def e2419144093210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419144093210 : Closed e2419144093210 ∧ code e2419144093210 = 11215237115418 := by decide
theorem cert_e2419144093210 : check e2419144093210 [[],[]] .sourceHead = true := by decide
def e2419144093282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419144093282 : Closed e2419144093282 ∧ code e2419144093282 = 11215237115490 := by decide
theorem cert_e2419144093282 : check e2419144093282 [[],[]] .sourceHead = true := by decide
def e2419144093294 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419144093294 : Closed e2419144093294 ∧ code e2419144093294 = 11215237115502 := by decide
theorem cert_e2419144093294 : check e2419144093294 [[],[]] .sourceHead = true := by decide
def e2419144093302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419144093302 : Closed e2419144093302 ∧ code e2419144093302 = 11215237115510 := by decide
theorem cert_e2419144093302 : check e2419144093302 [[],[]] .sourceHead = true := by decide
def e2419144093306 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419144093306 : Closed e2419144093306 ∧ code e2419144093306 = 11215237115514 := by decide
theorem cert_e2419144093306 : check e2419144093306 [[],[]] .sourceHead = true := by decide
def e2419144094574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2419144094574 : Closed e2419144094574 ∧ code e2419144094574 = 11215237116782 := by decide
theorem cert_e2419144094574 : check e2419144094574 [[],[]] .sourceHead = true := by decide
def e2419144094582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2419144094582 : Closed e2419144094582 ∧ code e2419144094582 = 11215237116790 := by decide
theorem cert_e2419144094582 : check e2419144094582 [[],[]] .sourceHead = true := by decide
def e2419144094638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2419144094638 : Closed e2419144094638 ∧ code e2419144094638 = 11215237116846 := by decide
theorem cert_e2419144094638 : check e2419144094638 [[],[]] .sourceHead = true := by decide
def e2419144094650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2419144094650 : Closed e2419144094650 ∧ code e2419144094650 = 11215237116858 := by decide
theorem cert_e2419144094650 : check e2419144094650 [[],[]] .sourceHead = true := by decide
def e2419144094678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2419144094678 : Closed e2419144094678 ∧ code e2419144094678 = 11215237116886 := by decide
theorem cert_e2419144094678 : check e2419144094678 [[],[]] .sourceHead = true := by decide
def e2419144094682 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2419144094682 : Closed e2419144094682 ∧ code e2419144094682 = 11215237116890 := by decide
theorem cert_e2419144094682 : check e2419144094682 [[],[]] .sourceHead = true := by decide
def e2419144094958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419144094958 : Closed e2419144094958 ∧ code e2419144094958 = 11215237117166 := by decide
theorem cert_e2419144094958 : check e2419144094958 [[],[]] .sourceHead = true := by decide
def e2419144094966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419144094966 : Closed e2419144094966 ∧ code e2419144094966 = 11215237117174 := by decide
theorem cert_e2419144094966 : check e2419144094966 [[],[]] .sourceHead = true := by decide
def e2419144095342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419144095342 : Closed e2419144095342 ∧ code e2419144095342 = 11215237117550 := by decide
theorem cert_e2419144095342 : check e2419144095342 [[],[]] .sourceHead = true := by decide
def e2419144095354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419144095354 : Closed e2419144095354 ∧ code e2419144095354 = 11215237117562 := by decide
theorem cert_e2419144095354 : check e2419144095354 [[],[]] .sourceHead = true := by decide
def e2419144095542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419144095542 : Closed e2419144095542 ∧ code e2419144095542 = 11215237117750 := by decide
theorem cert_e2419144095542 : check e2419144095542 [[],[]] .sourceHead = true := by decide
def e2419144095546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419144095546 : Closed e2419144095546 ∧ code e2419144095546 = 11215237117754 := by decide
theorem cert_e2419144095546 : check e2419144095546 [[],[]] .sourceHead = true := by decide
def e2419144095802 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)))))))
theorem wire_e2419144095802 : Closed e2419144095802 ∧ code e2419144095802 = 11215237118010 := by decide
theorem cert_e2419144095802 : check e2419144095802 [[],[]] .sourceHead = true := by decide
def e2419144095850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)))))))
theorem wire_e2419144095850 : Closed e2419144095850 ∧ code e2419144095850 = 11215237118058 := by decide
theorem cert_e2419144095850 : check e2419144095850 [[],[]] .sourceHead = true := by decide
def e2419144095898 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))))))))
theorem wire_e2419144095898 : Closed e2419144095898 ∧ code e2419144095898 = 11215237118106 := by decide
theorem cert_e2419144095898 : check e2419144095898 [[],[]] .sourceHead = true := by decide
def e2419144095942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))))))))
theorem wire_e2419144095942 : Closed e2419144095942 ∧ code e2419144095942 = 11215237118150 := by decide
theorem cert_e2419144095942 : check e2419144095942 [[],[]] .sourceHead = true := by decide
def e2419144096138 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2419144096138 : Closed e2419144096138 ∧ code e2419144096138 = 11215237118346 := by decide
theorem cert_e2419144096138 : check e2419144096138 [[],[]] .sourceHead = true := by decide
def e2419144096162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2419144096162 : Closed e2419144096162 ∧ code e2419144096162 = 11215237118370 := by decide
theorem cert_e2419144096162 : check e2419144096162 [[],[]] .sourceHead = true := by decide
def e2419144096174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2419144096174 : Closed e2419144096174 ∧ code e2419144096174 = 11215237118382 := by decide
theorem cert_e2419144096174 : check e2419144096174 [[],[]] .sourceHead = true := by decide
def e2419144096182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2419144096182 : Closed e2419144096182 ∧ code e2419144096182 = 11215237118390 := by decide
theorem cert_e2419144096182 : check e2419144096182 [[],[]] .sourceHead = true := by decide
def e2419144096186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2419144096186 : Closed e2419144096186 ∧ code e2419144096186 = 11215237118394 := by decide
theorem cert_e2419144096186 : check e2419144096186 [[],[]] .sourceHead = true := by decide
def e2419144096214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2419144096214 : Closed e2419144096214 ∧ code e2419144096214 = 11215237118422 := by decide
theorem cert_e2419144096214 : check e2419144096214 [[],[]] .sourceHead = true := by decide
def e2419144096218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2419144096218 : Closed e2419144096218 ∧ code e2419144096218 = 11215237118426 := by decide
theorem cert_e2419144096218 : check e2419144096218 [[],[]] .sourceHead = true := by decide
def e2419144096234 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2419144096234 : Closed e2419144096234 ∧ code e2419144096234 = 11215237118442 := by decide
theorem cert_e2419144096234 : check e2419144096234 [[],[]] .sourceHead = true := by decide
def e2419144096270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419144096270 : Closed e2419144096270 ∧ code e2419144096270 = 11215237118478 := by decide
theorem cert_e2419144096270 : check e2419144096270 [[],[]] .sourceHead = true := by decide
def e2419144096282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2419144096282 : Closed e2419144096282 ∧ code e2419144096282 = 11215237118490 := by decide
theorem cert_e2419144096282 : check e2419144096282 [[],[]] .sourceHead = true := by decide
def e2419144096354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419144096354 : Closed e2419144096354 ∧ code e2419144096354 = 11215237118562 := by decide
theorem cert_e2419144096354 : check e2419144096354 [[],[]] .sourceHead = true := by decide
def e2419144096366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419144096366 : Closed e2419144096366 ∧ code e2419144096366 = 11215237118574 := by decide
theorem cert_e2419144096366 : check e2419144096366 [[],[]] .sourceHead = true := by decide
def e2419144096374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2419144096374 : Closed e2419144096374 ∧ code e2419144096374 = 11215237118582 := by decide
theorem cert_e2419144096374 : check e2419144096374 [[],[]] .sourceHead = true := by decide
def e2419144096378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419144096378 : Closed e2419144096378 ∧ code e2419144096378 = 11215237118586 := by decide
theorem cert_e2419144096378 : check e2419144096378 [[],[]] .sourceHead = true := by decide
def e2419144096566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419144096566 : Closed e2419144096566 ∧ code e2419144096566 = 11215237118774 := by decide
theorem cert_e2419144096566 : check e2419144096566 [[],[]] .sourceHead = true := by decide
def e2419144096570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419144096570 : Closed e2419144096570 ∧ code e2419144096570 = 11215237118778 := by decide
theorem cert_e2419144096570 : check e2419144096570 [[],[]] .sourceHead = true := by decide
def e2419144096666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2419144096666 : Closed e2419144096666 ∧ code e2419144096666 = 11215237118874 := by decide
theorem cert_e2419144096666 : check e2419144096666 [[],[]] .sourceHead = true := by decide
def e2419144099806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2419144099806 : Closed e2419144099806 ∧ code e2419144099806 = 11215237122014 := by decide
theorem cert_e2419144099806 : check e2419144099806 [[],[]] .sourceHead = true := by decide
def e2419144103470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2419144103470 : Closed e2419144103470 ∧ code e2419144103470 = 11215237125678 := by decide
theorem cert_e2419144103470 : check e2419144103470 [[],[]] .sourceHead = true := by decide
def e2419144103650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2419144103650 : Closed e2419144103650 ∧ code e2419144103650 = 11215237125858 := by decide
theorem cert_e2419144103650 : check e2419144103650 [[],[]] .sourceHead = true := by decide
def e2419144103662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2419144103662 : Closed e2419144103662 ∧ code e2419144103662 = 11215237125870 := by decide
theorem cert_e2419144103662 : check e2419144103662 [[],[]] .sourceHead = true := by decide
def e2419144103790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2419144103790 : Closed e2419144103790 ∧ code e2419144103790 = 11215237125998 := by decide
theorem cert_e2419144103790 : check e2419144103790 [[],[]] .sourceHead = true := by decide
def e2419144103798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2419144103798 : Closed e2419144103798 ∧ code e2419144103798 = 11215237126006 := by decide
theorem cert_e2419144103798 : check e2419144103798 [[],[]] .sourceHead = true := by decide
def e2419144103818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419144103818 : Closed e2419144103818 ∧ code e2419144103818 = 11215237126026 := by decide
theorem cert_e2419144103818 : check e2419144103818 [[],[]] .sourceHead = true := by decide
def e2419144103842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419144103842 : Closed e2419144103842 ∧ code e2419144103842 = 11215237126050 := by decide
theorem cert_e2419144103842 : check e2419144103842 [[],[]] .sourceHead = true := by decide
def e2419144103854 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2419144103854 : Closed e2419144103854 ∧ code e2419144103854 = 11215237126062 := by decide
theorem cert_e2419144103854 : check e2419144103854 [[],[]] .sourceHead = true := by decide
def e2419144103862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2419144103862 : Closed e2419144103862 ∧ code e2419144103862 = 11215237126070 := by decide
theorem cert_e2419144103862 : check e2419144103862 [[],[]] .sourceHead = true := by decide
def e2419144103866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2419144103866 : Closed e2419144103866 ∧ code e2419144103866 = 11215237126074 := by decide
theorem cert_e2419144103866 : check e2419144103866 [[],[]] .sourceHead = true := by decide
def e2419144103998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2419144103998 : Closed e2419144103998 ∧ code e2419144103998 = 11215237126206 := by decide
theorem cert_e2419144103998 : check e2419144103998 [[],[]] .sourceHead = true := by decide
def e2419144104418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2419144104418 : Closed e2419144104418 ∧ code e2419144104418 = 11215237126626 := by decide
theorem cert_e2419144104418 : check e2419144104418 [[],[]] .sourceHead = true := by decide
def e2419144104430 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419144104430 : Closed e2419144104430 ∧ code e2419144104430 = 11215237126638 := by decide
theorem cert_e2419144104430 : check e2419144104430 [[],[]] .sourceHead = true := by decide
def e2419144105198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419144105198 : Closed e2419144105198 ∧ code e2419144105198 = 11215237127406 := by decide
theorem cert_e2419144105198 : check e2419144105198 [[],[]] .sourceHead = true := by decide
def e2419144105206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419144105206 : Closed e2419144105206 ∧ code e2419144105206 = 11215237127414 := by decide
theorem cert_e2419144105206 : check e2419144105206 [[],[]] .sourceHead = true := by decide
def e2419144105486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2419144105486 : Closed e2419144105486 ∧ code e2419144105486 = 11215237127694 := by decide
theorem cert_e2419144105486 : check e2419144105486 [[],[]] .sourceHead = true := by decide
def e2419144105498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2419144105498 : Closed e2419144105498 ∧ code e2419144105498 = 11215237127706 := by decide
theorem cert_e2419144105498 : check e2419144105498 [[],[]] .sourceHead = true := by decide
def e2419144105570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419144105570 : Closed e2419144105570 ∧ code e2419144105570 = 11215237127778 := by decide
theorem cert_e2419144105570 : check e2419144105570 [[],[]] .sourceHead = true := by decide
def e2419144105582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419144105582 : Closed e2419144105582 ∧ code e2419144105582 = 11215237127790 := by decide
theorem cert_e2419144105582 : check e2419144105582 [[],[]] .sourceHead = true := by decide
def e2419144105590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419144105590 : Closed e2419144105590 ∧ code e2419144105590 = 11215237127798 := by decide
theorem cert_e2419144105590 : check e2419144105590 [[],[]] .sourceHead = true := by decide
def e2419144105594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419144105594 : Closed e2419144105594 ∧ code e2419144105594 = 11215237127802 := by decide
theorem cert_e2419144105594 : check e2419144105594 [[],[]] .sourceHead = true := by decide
def e2419144117102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419144117102 : Closed e2419144117102 ∧ code e2419144117102 = 11215237139310 := by decide
theorem cert_e2419144117102 : check e2419144117102 [[],[]] .sourceHead = true := by decide
def e2419144117110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419144117110 : Closed e2419144117110 ∧ code e2419144117110 = 11215237139318 := by decide
theorem cert_e2419144117110 : check e2419144117110 [[],[]] .sourceHead = true := by decide
def e2419144117166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419144117166 : Closed e2419144117166 ∧ code e2419144117166 = 11215237139374 := by decide
theorem cert_e2419144117166 : check e2419144117166 [[],[]] .sourceHead = true := by decide
def e2419144117178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419144117178 : Closed e2419144117178 ∧ code e2419144117178 = 11215237139386 := by decide
theorem cert_e2419144117178 : check e2419144117178 [[],[]] .sourceHead = true := by decide
def e2419144117206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419144117206 : Closed e2419144117206 ∧ code e2419144117206 = 11215237139414 := by decide
theorem cert_e2419144117206 : check e2419144117206 [[],[]] .sourceHead = true := by decide
def e2419144117210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419144117210 : Closed e2419144117210 ∧ code e2419144117210 = 11215237139418 := by decide
theorem cert_e2419144117210 : check e2419144117210 [[],[]] .sourceHead = true := by decide
def e2419144117486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419144117486 : Closed e2419144117486 ∧ code e2419144117486 = 11215237139694 := by decide
theorem cert_e2419144117486 : check e2419144117486 [[],[]] .sourceHead = true := by decide
def e2419144117494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419144117494 : Closed e2419144117494 ∧ code e2419144117494 = 11215237139702 := by decide
theorem cert_e2419144117494 : check e2419144117494 [[],[]] .sourceHead = true := by decide
def e2419144117870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419144117870 : Closed e2419144117870 ∧ code e2419144117870 = 11215237140078 := by decide
theorem cert_e2419144117870 : check e2419144117870 [[],[]] .sourceHead = true := by decide
def e2419144117882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419144117882 : Closed e2419144117882 ∧ code e2419144117882 = 11215237140090 := by decide
theorem cert_e2419144117882 : check e2419144117882 [[],[]] .sourceHead = true := by decide
def e2419144118070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419144118070 : Closed e2419144118070 ∧ code e2419144118070 = 11215237140278 := by decide
theorem cert_e2419144118070 : check e2419144118070 [[],[]] .sourceHead = true := by decide
def e2419144118074 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419144118074 : Closed e2419144118074 ∧ code e2419144118074 = 11215237140282 := by decide
theorem cert_e2419144118074 : check e2419144118074 [[],[]] .sourceHead = true := by decide
def e2419144122846 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2419144122846 : Closed e2419144122846 ∧ code e2419144122846 = 11215237145054 := by decide
theorem cert_e2419144122846 : check e2419144122846 [[],[]] .sourceHead = true := by decide
def e2419144122870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2419144122870 : Closed e2419144122870 ∧ code e2419144122870 = 11215237145078 := by decide
theorem cert_e2419144122870 : check e2419144122870 [[],[]] .sourceHead = true := by decide
def e2419144123786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419144123786 : Closed e2419144123786 ∧ code e2419144123786 = 11215237145994 := by decide
theorem cert_e2419144123786 : check e2419144123786 [[],[]] .sourceHead = true := by decide
def e2419144123810 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419144123810 : Closed e2419144123810 ∧ code e2419144123810 = 11215237146018 := by decide
theorem cert_e2419144123810 : check e2419144123810 [[],[]] .sourceHead = true := by decide
def e2419144123822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2419144123822 : Closed e2419144123822 ∧ code e2419144123822 = 11215237146030 := by decide
theorem cert_e2419144123822 : check e2419144123822 [[],[]] .sourceHead = true := by decide
def e2419144123830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2419144123830 : Closed e2419144123830 ∧ code e2419144123830 = 11215237146038 := by decide
theorem cert_e2419144123830 : check e2419144123830 [[],[]] .sourceHead = true := by decide
def e2419144123834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2419144123834 : Closed e2419144123834 ∧ code e2419144123834 = 11215237146042 := by decide
theorem cert_e2419144123834 : check e2419144123834 [[],[]] .sourceHead = true := by decide
def e2419144123862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2419144123862 : Closed e2419144123862 ∧ code e2419144123862 = 11215237146070 := by decide
theorem cert_e2419144123862 : check e2419144123862 [[],[]] .sourceHead = true := by decide
def e2419144123866 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2419144123866 : Closed e2419144123866 ∧ code e2419144123866 = 11215237146074 := by decide
theorem cert_e2419144123866 : check e2419144123866 [[],[]] .sourceHead = true := by decide
def e2419144123882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2419144123882 : Closed e2419144123882 ∧ code e2419144123882 = 11215237146090 := by decide
theorem cert_e2419144123882 : check e2419144123882 [[],[]] .sourceHead = true := by decide
def e2419144123918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))))))))
theorem wire_e2419144123918 : Closed e2419144123918 ∧ code e2419144123918 = 11215237146126 := by decide
theorem cert_e2419144123918 : check e2419144123918 [[],[]] .sourceHead = true := by decide
def e2419144123930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2419144123930 : Closed e2419144123930 ∧ code e2419144123930 = 11215237146138 := by decide
theorem cert_e2419144123930 : check e2419144123930 [[],[]] .sourceHead = true := by decide
def e2419144124002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419144124002 : Closed e2419144124002 ∧ code e2419144124002 = 11215237146210 := by decide
theorem cert_e2419144124002 : check e2419144124002 [[],[]] .sourceHead = true := by decide
def e2419144124014 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419144124014 : Closed e2419144124014 ∧ code e2419144124014 = 11215237146222 := by decide
theorem cert_e2419144124014 : check e2419144124014 [[],[]] .sourceHead = true := by decide
def e2419144124022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419144124022 : Closed e2419144124022 ∧ code e2419144124022 = 11215237146230 := by decide
theorem cert_e2419144124022 : check e2419144124022 [[],[]] .sourceHead = true := by decide
def e2419144124026 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419144124026 : Closed e2419144124026 ∧ code e2419144124026 = 11215237146234 := by decide
theorem cert_e2419144124026 : check e2419144124026 [[],[]] .sourceHead = true := by decide
def e2419144124214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419144124214 : Closed e2419144124214 ∧ code e2419144124214 = 11215237146422 := by decide
theorem cert_e2419144124214 : check e2419144124214 [[],[]] .sourceHead = true := by decide
def e2419144124218 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419144124218 : Closed e2419144124218 ∧ code e2419144124218 = 11215237146426 := by decide
theorem cert_e2419144124218 : check e2419144124218 [[],[]] .sourceHead = true := by decide
def e2419144124314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2419144124314 : Closed e2419144124314 ∧ code e2419144124314 = 11215237146522 := by decide
theorem cert_e2419144124314 : check e2419144124314 [[],[]] .sourceHead = true := by decide
def e2419144273374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2419144273374 : Closed e2419144273374 ∧ code e2419144273374 = 11215237295582 := by decide
theorem cert_e2419144273374 : check e2419144273374 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2419144273390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2419144273390 : Closed e2419144273390 ∧ code e2419144273390 = 11215237295598 := by decide
private def t_e2419144273390 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem cert_e2419144273390 : ¬ IsSelfInterpreter e2419144273390 :=
  wSource (t := t_e2419144273390) (replay_sound (ps := []) (t := e2419144273390) (by decide)) (by decide)
def e2419144273646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2419144273646 : Closed e2419144273646 ∧ code e2419144273646 = 11215237295854 := by decide
theorem cert_e2419144273646 : check e2419144273646 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2419144273758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.lam (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2419144273758 : Closed e2419144273758 ∧ code e2419144273758 = 11215237295966 := by decide
theorem cert_e2419144273758 : check e2419144273758 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419144273390
