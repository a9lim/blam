import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759454298938 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e759454298938 : Closed e759454298938 ∧ code e759454298938 = 9555547321146 := by decide
theorem cert_e759454298938 : check e759454298938 [] .sourceHead = true := by decide
def e759454299034 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e759454299034 : Closed e759454299034 ∧ code e759454299034 = 9555547321242 := by decide
theorem cert_e759454299034 : check e759454299034 [] .sourceHead = true := by decide
def e759454436206 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759454436206 : Closed e759454436206 ∧ code e759454436206 = 9555547458414 := by decide
theorem cert_e759454436206 : check e759454436206 [] .sourceHead = true := by decide
def e759454436214 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759454436214 : Closed e759454436214 ∧ code e759454436214 = 9555547458422 := by decide
theorem cert_e759454436214 : check e759454436214 [] .sourceHead = true := by decide
def e759454436270 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759454436270 : Closed e759454436270 ∧ code e759454436270 = 9555547458478 := by decide
theorem cert_e759454436270 : check e759454436270 [] .sourceHead = true := by decide
def e759454436282 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759454436282 : Closed e759454436282 ∧ code e759454436282 = 9555547458490 := by decide
theorem cert_e759454436282 : check e759454436282 [] .sourceHead = true := by decide
def e759454436310 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759454436310 : Closed e759454436310 ∧ code e759454436310 = 9555547458518 := by decide
theorem cert_e759454436310 : check e759454436310 [] .sourceHead = true := by decide
def e759454436314 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759454436314 : Closed e759454436314 ∧ code e759454436314 = 9555547458522 := by decide
theorem cert_e759454436314 : check e759454436314 [] .sourceHead = true := by decide
def e759454436590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759454436590 : Closed e759454436590 ∧ code e759454436590 = 9555547458798 := by decide
theorem cert_e759454436590 : check e759454436590 [] .sourceHead = true := by decide
def e759454436598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759454436598 : Closed e759454436598 ∧ code e759454436598 = 9555547458806 := by decide
theorem cert_e759454436598 : check e759454436598 [] .sourceHead = true := by decide
def e759454436974 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759454436974 : Closed e759454436974 ∧ code e759454436974 = 9555547459182 := by decide
theorem cert_e759454436974 : check e759454436974 [] .sourceHead = true := by decide
def e759454436986 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759454436986 : Closed e759454436986 ∧ code e759454436986 = 9555547459194 := by decide
theorem cert_e759454436986 : check e759454436986 [] .sourceHead = true := by decide
def e759454437174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759454437174 : Closed e759454437174 ∧ code e759454437174 = 9555547459382 := by decide
theorem cert_e759454437174 : check e759454437174 [] .sourceHead = true := by decide
def e759454437178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759454437178 : Closed e759454437178 ∧ code e759454437178 = 9555547459386 := by decide
theorem cert_e759454437178 : check e759454437178 [] .sourceHead = true := by decide
def e759455026030 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759455026030 : Closed e759455026030 ∧ code e759455026030 = 9555548048238 := by decide
theorem cert_e759455026030 : check e759455026030 [] .sourceHead = true := by decide
def e759455026038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759455026038 : Closed e759455026038 ∧ code e759455026038 = 9555548048246 := by decide
theorem cert_e759455026038 : check e759455026038 [] .sourceHead = true := by decide
def e759455026094 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759455026094 : Closed e759455026094 ∧ code e759455026094 = 9555548048302 := by decide
theorem cert_e759455026094 : check e759455026094 [] .sourceHead = true := by decide
def e759455026106 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759455026106 : Closed e759455026106 ∧ code e759455026106 = 9555548048314 := by decide
theorem cert_e759455026106 : check e759455026106 [] .sourceHead = true := by decide
def e759455026134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759455026134 : Closed e759455026134 ∧ code e759455026134 = 9555548048342 := by decide
theorem cert_e759455026134 : check e759455026134 [] .sourceHead = true := by decide
def e759455026138 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759455026138 : Closed e759455026138 ∧ code e759455026138 = 9555548048346 := by decide
theorem cert_e759455026138 : check e759455026138 [] .sourceHead = true := by decide
def e759455026414 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759455026414 : Closed e759455026414 ∧ code e759455026414 = 9555548048622 := by decide
theorem cert_e759455026414 : check e759455026414 [] .sourceHead = true := by decide
def e759455026422 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759455026422 : Closed e759455026422 ∧ code e759455026422 = 9555548048630 := by decide
theorem cert_e759455026422 : check e759455026422 [] .sourceHead = true := by decide
def e759455026798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759455026798 : Closed e759455026798 ∧ code e759455026798 = 9555548049006 := by decide
theorem cert_e759455026798 : check e759455026798 [] .sourceHead = true := by decide
def e759455026810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759455026810 : Closed e759455026810 ∧ code e759455026810 = 9555548049018 := by decide
theorem cert_e759455026810 : check e759455026810 [] .sourceHead = true := by decide
def e759455026998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759455026998 : Closed e759455026998 ∧ code e759455026998 = 9555548049206 := by decide
theorem cert_e759455026998 : check e759455026998 [] .sourceHead = true := by decide
def e759455027002 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759455027002 : Closed e759455027002 ∧ code e759455027002 = 9555548049210 := by decide
theorem cert_e759455027002 : check e759455027002 [] .sourceHead = true := by decide
def e765376771514 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e765376771514 : Closed e765376771514 ∧ code e765376771514 = 9561469793722 := by decide
theorem cert_e765376771514 : check e765376771514 [] .sourceHead = true := by decide
def e765376771546 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e765376771546 : Closed e765376771546 ∧ code e765376771546 = 9561469793754 := by decide
theorem cert_e765376771546 : check e765376771546 [] .sourceHead = true := by decide
def e765376771770 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e765376771770 : Closed e765376771770 ∧ code e765376771770 = 9561469793978 := by decide
theorem cert_e765376771770 : check e765376771770 [] .sourceHead = true := by decide
def e765376771818 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e765376771818 : Closed e765376771818 ∧ code e765376771818 = 9561469794026 := by decide
theorem cert_e765376771818 : check e765376771818 [] .sourceHead = true := by decide
def e765376771930 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e765376771930 : Closed e765376771930 ∧ code e765376771930 = 9561469794138 := by decide
theorem cert_e765376771930 : check e765376771930 [] .sourceHead = true := by decide
def e765376771946 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e765376771946 : Closed e765376771946 ∧ code e765376771946 = 9561469794154 := by decide
theorem cert_e765376771946 : check e765376771946 [] .sourceHead = true := by decide
def e765376772794 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e765376772794 : Closed e765376772794 ∧ code e765376772794 = 9561469795002 := by decide
theorem cert_e765376772794 : check e765376772794 [] .sourceHead = true := by decide
def e765376772842 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e765376772842 : Closed e765376772842 ∧ code e765376772842 = 9561469795050 := by decide
theorem cert_e765376772842 : check e765376772842 [] .sourceHead = true := by decide
def e765376773034 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e765376773034 : Closed e765376773034 ∧ code e765376773034 = 9561469795242 := by decide
theorem cert_e765376773034 : check e765376773034 [] .sourceHead = true := by decide
def e765376773466 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e765376773466 : Closed e765376773466 ∧ code e765376773466 = 9561469795674 := by decide
theorem cert_e765376773466 : check e765376773466 [] .sourceHead = true := by decide
def e765376773482 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e765376773482 : Closed e765376773482 ∧ code e765376773482 = 9561469795690 := by decide
theorem cert_e765376773482 : check e765376773482 [] .sourceHead = true := by decide
def e765376773546 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e765376773546 : Closed e765376773546 ∧ code e765376773546 = 9561469795754 := by decide
theorem cert_e765376773546 : check e765376773546 [] .sourceHead = true := by decide
def e765376777658 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e765376777658 : Closed e765376777658 ∧ code e765376777658 = 9561469799866 := by decide
theorem cert_e765376777658 : check e765376777658 [] .sourceHead = true := by decide
def e765376777690 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e765376777690 : Closed e765376777690 ∧ code e765376777690 = 9561469799898 := by decide
theorem cert_e765376777690 : check e765376777690 [] .sourceHead = true := by decide
def e765376777914 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e765376777914 : Closed e765376777914 ∧ code e765376777914 = 9561469800122 := by decide
theorem cert_e765376777914 : check e765376777914 [] .sourceHead = true := by decide
def e765376777962 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e765376777962 : Closed e765376777962 ∧ code e765376777962 = 9561469800170 := by decide
theorem cert_e765376777962 : check e765376777962 [] .sourceHead = true := by decide
def e765376778074 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e765376778074 : Closed e765376778074 ∧ code e765376778074 = 9561469800282 := by decide
theorem cert_e765376778074 : check e765376778074 [] .sourceHead = true := by decide
def e765376778090 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e765376778090 : Closed e765376778090 ∧ code e765376778090 = 9561469800298 := by decide
theorem cert_e765376778090 : check e765376778090 [] .sourceHead = true := by decide
def e765376779194 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e765376779194 : Closed e765376779194 ∧ code e765376779194 = 9561469801402 := by decide
theorem cert_e765376779194 : check e765376779194 [] .sourceHead = true := by decide
def e765376779226 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e765376779226 : Closed e765376779226 ∧ code e765376779226 = 9561469801434 := by decide
theorem cert_e765376779226 : check e765376779226 [] .sourceHead = true := by decide
def e765376780730 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e765376780730 : Closed e765376780730 ∧ code e765376780730 = 9561469802938 := by decide
theorem cert_e765376780730 : check e765376780730 [] .sourceHead = true := by decide
def e765376780778 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e765376780778 : Closed e765376780778 ∧ code e765376780778 = 9561469802986 := by decide
theorem cert_e765376780778 : check e765376780778 [] .sourceHead = true := by decide
def e765376781530 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e765376781530 : Closed e765376781530 ∧ code e765376781530 = 9561469803738 := by decide
theorem cert_e765376781530 : check e765376781530 [] .sourceHead = true := by decide
def e765376781546 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e765376781546 : Closed e765376781546 ∧ code e765376781546 = 9561469803754 := by decide
theorem cert_e765376781546 : check e765376781546 [] .sourceHead = true := by decide
def e765376784058 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e765376784058 : Closed e765376784058 ∧ code e765376784058 = 9561469806266 := by decide
theorem cert_e765376784058 : check e765376784058 [] .sourceHead = true := by decide
def e765376784106 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e765376784106 : Closed e765376784106 ∧ code e765376784106 = 9561469806314 := by decide
theorem cert_e765376784106 : check e765376784106 [] .sourceHead = true := by decide
def e765376784298 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e765376784298 : Closed e765376784298 ∧ code e765376784298 = 9561469806506 := by decide
theorem cert_e765376784298 : check e765376784298 [] .sourceHead = true := by decide
def e765376784826 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e765376784826 : Closed e765376784826 ∧ code e765376784826 = 9561469807034 := by decide
theorem cert_e765376784826 : check e765376784826 [] .sourceHead = true := by decide
def e765376784874 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e765376784874 : Closed e765376784874 ∧ code e765376784874 = 9561469807082 := by decide
theorem cert_e765376784874 : check e765376784874 [] .sourceHead = true := by decide
def e765376786026 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e765376786026 : Closed e765376786026 ∧ code e765376786026 = 9561469808234 := by decide
theorem cert_e765376786026 : check e765376786026 [] .sourceHead = true := by decide
def e765376787290 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e765376787290 : Closed e765376787290 ∧ code e765376787290 = 9561469809498 := by decide
theorem cert_e765376787290 : check e765376787290 [] .sourceHead = true := by decide
def e765376787306 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e765376787306 : Closed e765376787306 ∧ code e765376787306 = 9561469809514 := by decide
theorem cert_e765376787306 : check e765376787306 [] .sourceHead = true := by decide
def e765376787370 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e765376787370 : Closed e765376787370 ∧ code e765376787370 = 9561469809578 := by decide
theorem cert_e765376787370 : check e765376787370 [] .sourceHead = true := by decide
def e765376787674 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e765376787674 : Closed e765376787674 ∧ code e765376787674 = 9561469809882 := by decide
theorem cert_e765376787674 : check e765376787674 [] .sourceHead = true := by decide
def e765376787690 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e765376787690 : Closed e765376787690 ∧ code e765376787690 = 9561469809898 := by decide
theorem cert_e765376787690 : check e765376787690 [] .sourceHead = true := by decide
def e765376788074 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e765376788074 : Closed e765376788074 ∧ code e765376788074 = 9561469810282 := by decide
theorem cert_e765376788074 : check e765376788074 [] .sourceHead = true := by decide
def e765376802234 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e765376802234 : Closed e765376802234 ∧ code e765376802234 = 9561469824442 := by decide
theorem cert_e765376802234 : check e765376802234 [] .sourceHead = true := by decide
def e765376802266 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e765376802266 : Closed e765376802266 ∧ code e765376802266 = 9561469824474 := by decide
theorem cert_e765376802266 : check e765376802266 [] .sourceHead = true := by decide
def e765376802490 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e765376802490 : Closed e765376802490 ∧ code e765376802490 = 9561469824698 := by decide
theorem cert_e765376802490 : check e765376802490 [] .sourceHead = true := by decide
def e765376802538 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e765376802538 : Closed e765376802538 ∧ code e765376802538 = 9561469824746 := by decide
theorem cert_e765376802538 : check e765376802538 [] .sourceHead = true := by decide
def e765376802650 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e765376802650 : Closed e765376802650 ∧ code e765376802650 = 9561469824858 := by decide
theorem cert_e765376802650 : check e765376802650 [] .sourceHead = true := by decide
def e765376802666 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e765376802666 : Closed e765376802666 ∧ code e765376802666 = 9561469824874 := by decide
theorem cert_e765376802666 : check e765376802666 [] .sourceHead = true := by decide
def e765376803770 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e765376803770 : Closed e765376803770 ∧ code e765376803770 = 9561469825978 := by decide
theorem cert_e765376803770 : check e765376803770 [] .sourceHead = true := by decide
def e765376803802 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e765376803802 : Closed e765376803802 ∧ code e765376803802 = 9561469826010 := by decide
theorem cert_e765376803802 : check e765376803802 [] .sourceHead = true := by decide
def e765376805306 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e765376805306 : Closed e765376805306 ∧ code e765376805306 = 9561469827514 := by decide
theorem cert_e765376805306 : check e765376805306 [] .sourceHead = true := by decide
def e765376805354 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e765376805354 : Closed e765376805354 ∧ code e765376805354 = 9561469827562 := by decide
theorem cert_e765376805354 : check e765376805354 [] .sourceHead = true := by decide
def e765376806106 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e765376806106 : Closed e765376806106 ∧ code e765376806106 = 9561469828314 := by decide
theorem cert_e765376806106 : check e765376806106 [] .sourceHead = true := by decide
def e765376806122 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e765376806122 : Closed e765376806122 ∧ code e765376806122 = 9561469828330 := by decide
theorem cert_e765376806122 : check e765376806122 [] .sourceHead = true := by decide
def e765376829114 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e765376829114 : Closed e765376829114 ∧ code e765376829114 = 9561469851322 := by decide
theorem cert_e765376829114 : check e765376829114 [] .sourceHead = true := by decide
def e765376829162 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e765376829162 : Closed e765376829162 ∧ code e765376829162 = 9561469851370 := by decide
theorem cert_e765376829162 : check e765376829162 [] .sourceHead = true := by decide
def e765376829354 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e765376829354 : Closed e765376829354 ∧ code e765376829354 = 9561469851562 := by decide
theorem cert_e765376829354 : check e765376829354 [] .sourceHead = true := by decide
def e765376829882 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e765376829882 : Closed e765376829882 ∧ code e765376829882 = 9561469852090 := by decide
theorem cert_e765376829882 : check e765376829882 [] .sourceHead = true := by decide
def e765376829930 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e765376829930 : Closed e765376829930 ∧ code e765376829930 = 9561469852138 := by decide
theorem cert_e765376829930 : check e765376829930 [] .sourceHead = true := by decide
def e765376831082 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e765376831082 : Closed e765376831082 ∧ code e765376831082 = 9561469853290 := by decide
theorem cert_e765376831082 : check e765376831082 [] .sourceHead = true := by decide
def e765376842586 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e765376842586 : Closed e765376842586 ∧ code e765376842586 = 9561469864794 := by decide
theorem cert_e765376842586 : check e765376842586 [] .sourceHead = true := by decide
def e765376842602 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e765376842602 : Closed e765376842602 ∧ code e765376842602 = 9561469864810 := by decide
theorem cert_e765376842602 : check e765376842602 [] .sourceHead = true := by decide
def e765376842666 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e765376842666 : Closed e765376842666 ∧ code e765376842666 = 9561469864874 := by decide
theorem cert_e765376842666 : check e765376842666 [] .sourceHead = true := by decide
def e765376842970 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e765376842970 : Closed e765376842970 ∧ code e765376842970 = 9561469865178 := by decide
theorem cert_e765376842970 : check e765376842970 [] .sourceHead = true := by decide
def e765376842986 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e765376842986 : Closed e765376842986 ∧ code e765376842986 = 9561469865194 := by decide
theorem cert_e765376842986 : check e765376842986 [] .sourceHead = true := by decide
def e765376843370 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e765376843370 : Closed e765376843370 ∧ code e765376843370 = 9561469865578 := by decide
theorem cert_e765376843370 : check e765376843370 [] .sourceHead = true := by decide
def e765377392058 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e765377392058 : Closed e765377392058 ∧ code e765377392058 = 9561470414266 := by decide
theorem cert_e765377392058 : check e765377392058 [] .sourceHead = true := by decide
def e765377392090 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e765377392090 : Closed e765377392090 ∧ code e765377392090 = 9561470414298 := by decide
theorem cert_e765377392090 : check e765377392090 [] .sourceHead = true := by decide
def e765377392314 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e765377392314 : Closed e765377392314 ∧ code e765377392314 = 9561470414522 := by decide
theorem cert_e765377392314 : check e765377392314 [] .sourceHead = true := by decide
def e765377392362 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e765377392362 : Closed e765377392362 ∧ code e765377392362 = 9561470414570 := by decide
theorem cert_e765377392362 : check e765377392362 [] .sourceHead = true := by decide
def e765377392474 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e765377392474 : Closed e765377392474 ∧ code e765377392474 = 9561470414682 := by decide
theorem cert_e765377392474 : check e765377392474 [] .sourceHead = true := by decide
def e765377392490 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e765377392490 : Closed e765377392490 ∧ code e765377392490 = 9561470414698 := by decide
theorem cert_e765377392490 : check e765377392490 [] .sourceHead = true := by decide
def e765377393594 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e765377393594 : Closed e765377393594 ∧ code e765377393594 = 9561470415802 := by decide
theorem cert_e765377393594 : check e765377393594 [] .sourceHead = true := by decide
def e765377393626 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e765377393626 : Closed e765377393626 ∧ code e765377393626 = 9561470415834 := by decide
theorem cert_e765377393626 : check e765377393626 [] .sourceHead = true := by decide
def e765377395130 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e765377395130 : Closed e765377395130 ∧ code e765377395130 = 9561470417338 := by decide
theorem cert_e765377395130 : check e765377395130 [] .sourceHead = true := by decide
def e765377395178 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e765377395178 : Closed e765377395178 ∧ code e765377395178 = 9561470417386 := by decide
theorem cert_e765377395178 : check e765377395178 [] .sourceHead = true := by decide
def e765377395930 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e765377395930 : Closed e765377395930 ∧ code e765377395930 = 9561470418138 := by decide
theorem cert_e765377395930 : check e765377395930 [] .sourceHead = true := by decide
def e765377395946 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e765377395946 : Closed e765377395946 ∧ code e765377395946 = 9561470418154 := by decide
theorem cert_e765377395946 : check e765377395946 [] .sourceHead = true := by decide
def e765379751354 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e765379751354 : Closed e765379751354 ∧ code e765379751354 = 9561472773562 := by decide
theorem cert_e765379751354 : check e765379751354 [] .sourceHead = true := by decide
def e765379751386 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e765379751386 : Closed e765379751386 ∧ code e765379751386 = 9561472773594 := by decide
theorem cert_e765379751386 : check e765379751386 [] .sourceHead = true := by decide
def e765379751610 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e765379751610 : Closed e765379751610 ∧ code e765379751610 = 9561472773818 := by decide
theorem cert_e765379751610 : check e765379751610 [] .sourceHead = true := by decide
def e765379751658 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e765379751658 : Closed e765379751658 ∧ code e765379751658 = 9561472773866 := by decide
theorem cert_e765379751658 : check e765379751658 [] .sourceHead = true := by decide
def e765379751770 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e765379751770 : Closed e765379751770 ∧ code e765379751770 = 9561472773978 := by decide
theorem cert_e765379751770 : check e765379751770 [] .sourceHead = true := by decide
def e765379751786 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e765379751786 : Closed e765379751786 ∧ code e765379751786 = 9561472773994 := by decide
theorem cert_e765379751786 : check e765379751786 [] .sourceHead = true := by decide
def e765379752890 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e765379752890 : Closed e765379752890 ∧ code e765379752890 = 9561472775098 := by decide
theorem cert_e765379752890 : check e765379752890 [] .sourceHead = true := by decide
def e765379752922 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e765379752922 : Closed e765379752922 ∧ code e765379752922 = 9561472775130 := by decide
theorem cert_e765379752922 : check e765379752922 [] .sourceHead = true := by decide
def e765379754426 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e765379754426 : Closed e765379754426 ∧ code e765379754426 = 9561472776634 := by decide
theorem cert_e765379754426 : check e765379754426 [] .sourceHead = true := by decide
def e765379754474 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e765379754474 : Closed e765379754474 ∧ code e765379754474 = 9561472776682 := by decide
theorem cert_e765379754474 : check e765379754474 [] .sourceHead = true := by decide
def e765379755226 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e765379755226 : Closed e765379755226 ∧ code e765379755226 = 9561472777434 := by decide
theorem cert_e765379755226 : check e765379755226 [] .sourceHead = true := by decide
def e765379755242 : Term := (.lam (.app (.app (.var 0) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e765379755242 : Closed e765379755242 ∧ code e765379755242 = 9561472777450 := by decide
theorem cert_e765379755242 : check e765379755242 [] .sourceHead = true := by decide
def e768810511898 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810511898 : Closed e768810511898 ∧ code e768810511898 = 9564903534106 := by decide
theorem cert_e768810511898 : check e768810511898 [] .sourceHead = true := by decide
def e768810513946 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810513946 : Closed e768810513946 ∧ code e768810513946 = 9564903536154 := by decide
theorem cert_e768810513946 : check e768810513946 [] .sourceHead = true := by decide
def e768810528282 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810528282 : Closed e768810528282 ∧ code e768810528282 = 9564903550490 := by decide
theorem cert_e768810528282 : check e768810528282 [] .sourceHead = true := by decide
def e768810531354 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810531354 : Closed e768810531354 ∧ code e768810531354 = 9564903553562 := by decide
theorem cert_e768810531354 : check e768810531354 [] .sourceHead = true := by decide
def e768810538522 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810538522 : Closed e768810538522 ∧ code e768810538522 = 9564903560730 := by decide
theorem cert_e768810538522 : check e768810538522 [] .sourceHead = true := by decide
def e768810539546 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810539546 : Closed e768810539546 ∧ code e768810539546 = 9564903561754 := by decide
theorem cert_e768810539546 : check e768810539546 [] .sourceHead = true := by decide
def e768810593818 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810593818 : Closed e768810593818 ∧ code e768810593818 = 9564903616026 := by decide
theorem cert_e768810593818 : check e768810593818 [] .sourceHead = true := by decide
def e768810596890 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810596890 : Closed e768810596890 ∧ code e768810596890 = 9564903619098 := by decide
theorem cert_e768810596890 : check e768810596890 [] .sourceHead = true := by decide
def e768810609178 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810609178 : Closed e768810609178 ∧ code e768810609178 = 9564903631386 := by decide
theorem cert_e768810609178 : check e768810609178 [] .sourceHead = true := by decide
def e768810636826 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810636826 : Closed e768810636826 ∧ code e768810636826 = 9564903659034 := by decide
theorem cert_e768810636826 : check e768810636826 [] .sourceHead = true := by decide
def e768810637850 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810637850 : Closed e768810637850 ∧ code e768810637850 = 9564903660058 := by decide
theorem cert_e768810637850 : check e768810637850 [] .sourceHead = true := by decide
def e768810641946 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810641946 : Closed e768810641946 ∧ code e768810641946 = 9564903664154 := by decide
theorem cert_e768810641946 : check e768810641946 [] .sourceHead = true := by decide
def e768810905114 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810905114 : Closed e768810905114 ∧ code e768810905114 = 9564903927322 := by decide
theorem cert_e768810905114 : check e768810905114 [] .sourceHead = true := by decide
def e768810907162 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810907162 : Closed e768810907162 ∧ code e768810907162 = 9564903929370 := by decide
theorem cert_e768810907162 : check e768810907162 [] .sourceHead = true := by decide
def e768810921498 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810921498 : Closed e768810921498 ∧ code e768810921498 = 9564903943706 := by decide
theorem cert_e768810921498 : check e768810921498 [] .sourceHead = true := by decide
def e768810924570 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810924570 : Closed e768810924570 ∧ code e768810924570 = 9564903946778 := by decide
theorem cert_e768810924570 : check e768810924570 [] .sourceHead = true := by decide
def e768810931738 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810931738 : Closed e768810931738 ∧ code e768810931738 = 9564903953946 := by decide
theorem cert_e768810931738 : check e768810931738 [] .sourceHead = true := by decide
def e768810932762 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768810932762 : Closed e768810932762 ∧ code e768810932762 = 9564903954970 := by decide
theorem cert_e768810932762 : check e768810932762 [] .sourceHead = true := by decide
def e768811003418 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811003418 : Closed e768811003418 ∧ code e768811003418 = 9564904025626 := by decide
theorem cert_e768811003418 : check e768811003418 [] .sourceHead = true := by decide
def e768811005466 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811005466 : Closed e768811005466 ∧ code e768811005466 = 9564904027674 := by decide
theorem cert_e768811005466 : check e768811005466 [] .sourceHead = true := by decide
def e768811101722 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811101722 : Closed e768811101722 ∧ code e768811101722 = 9564904123930 := by decide
theorem cert_e768811101722 : check e768811101722 [] .sourceHead = true := by decide
def e768811104794 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811104794 : Closed e768811104794 ∧ code e768811104794 = 9564904127002 := by decide
theorem cert_e768811104794 : check e768811104794 [] .sourceHead = true := by decide
def e768811152922 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811152922 : Closed e768811152922 ∧ code e768811152922 = 9564904175130 := by decide
theorem cert_e768811152922 : check e768811152922 [] .sourceHead = true := by decide
def e768811153946 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811153946 : Closed e768811153946 ∧ code e768811153946 = 9564904176154 := by decide
theorem cert_e768811153946 : check e768811153946 [] .sourceHead = true := by decide
def e768811314714 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811314714 : Closed e768811314714 ∧ code e768811314714 = 9564904336922 := by decide
theorem cert_e768811314714 : check e768811314714 [] .sourceHead = true := by decide
def e768811317786 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811317786 : Closed e768811317786 ∧ code e768811317786 = 9564904339994 := by decide
theorem cert_e768811317786 : check e768811317786 [] .sourceHead = true := by decide
def e768811330074 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811330074 : Closed e768811330074 ∧ code e768811330074 = 9564904352282 := by decide
theorem cert_e768811330074 : check e768811330074 [] .sourceHead = true := by decide
def e768811363866 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811363866 : Closed e768811363866 ∧ code e768811363866 = 9564904386074 := by decide
theorem cert_e768811363866 : check e768811363866 [] .sourceHead = true := by decide
def e768811366938 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811366938 : Closed e768811366938 ∧ code e768811366938 = 9564904389146 := by decide
theorem cert_e768811366938 : check e768811366938 [] .sourceHead = true := by decide
def e768811440666 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811440666 : Closed e768811440666 ∧ code e768811440666 = 9564904462874 := by decide
theorem cert_e768811440666 : check e768811440666 [] .sourceHead = true := by decide
def e768811521562 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811521562 : Closed e768811521562 ∧ code e768811521562 = 9564904543770 := by decide
theorem cert_e768811521562 : check e768811521562 [] .sourceHead = true := by decide
def e768811522586 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811522586 : Closed e768811522586 ∧ code e768811522586 = 9564904544794 := by decide
theorem cert_e768811522586 : check e768811522586 [] .sourceHead = true := by decide
def e768811526682 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811526682 : Closed e768811526682 ∧ code e768811526682 = 9564904548890 := by decide
theorem cert_e768811526682 : check e768811526682 [] .sourceHead = true := by decide
def e768811546138 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811546138 : Closed e768811546138 ∧ code e768811546138 = 9564904568346 := by decide
theorem cert_e768811546138 : check e768811546138 [] .sourceHead = true := by decide
def e768811547162 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811547162 : Closed e768811547162 ∧ code e768811547162 = 9564904569370 := by decide
theorem cert_e768811547162 : check e768811547162 [] .sourceHead = true := by decide
def e768811571738 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768811571738 : Closed e768811571738 ∧ code e768811571738 = 9564904593946 := by decide
theorem cert_e768811571738 : check e768811571738 [] .sourceHead = true := by decide
def e768812477978 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812477978 : Closed e768812477978 ∧ code e768812477978 = 9564905500186 := by decide
theorem cert_e768812477978 : check e768812477978 [] .sourceHead = true := by decide
def e768812480026 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812480026 : Closed e768812480026 ∧ code e768812480026 = 9564905502234 := by decide
theorem cert_e768812480026 : check e768812480026 [] .sourceHead = true := by decide
def e768812494362 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812494362 : Closed e768812494362 ∧ code e768812494362 = 9564905516570 := by decide
theorem cert_e768812494362 : check e768812494362 [] .sourceHead = true := by decide
def e768812497434 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812497434 : Closed e768812497434 ∧ code e768812497434 = 9564905519642 := by decide
theorem cert_e768812497434 : check e768812497434 [] .sourceHead = true := by decide
def e768812504602 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812504602 : Closed e768812504602 ∧ code e768812504602 = 9564905526810 := by decide
theorem cert_e768812504602 : check e768812504602 [] .sourceHead = true := by decide
def e768812505626 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812505626 : Closed e768812505626 ∧ code e768812505626 = 9564905527834 := by decide
theorem cert_e768812505626 : check e768812505626 [] .sourceHead = true := by decide
def e768812576282 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812576282 : Closed e768812576282 ∧ code e768812576282 = 9564905598490 := by decide
theorem cert_e768812576282 : check e768812576282 [] .sourceHead = true := by decide
def e768812578330 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812578330 : Closed e768812578330 ∧ code e768812578330 = 9564905600538 := by decide
theorem cert_e768812578330 : check e768812578330 [] .sourceHead = true := by decide
def e768812674586 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812674586 : Closed e768812674586 ∧ code e768812674586 = 9564905696794 := by decide
theorem cert_e768812674586 : check e768812674586 [] .sourceHead = true := by decide
def e768812677658 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812677658 : Closed e768812677658 ∧ code e768812677658 = 9564905699866 := by decide
theorem cert_e768812677658 : check e768812677658 [] .sourceHead = true := by decide
def e768812725786 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812725786 : Closed e768812725786 ∧ code e768812725786 = 9564905747994 := by decide
theorem cert_e768812725786 : check e768812725786 [] .sourceHead = true := by decide
def e768812726810 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768812726810 : Closed e768812726810 ∧ code e768812726810 = 9564905749018 := by decide
theorem cert_e768812726810 : check e768812726810 [] .sourceHead = true := by decide
def e768814198298 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768814198298 : Closed e768814198298 ∧ code e768814198298 = 9564907220506 := by decide
theorem cert_e768814198298 : check e768814198298 [] .sourceHead = true := by decide
def e768814201370 : Term := (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e768814201370 : Closed e768814201370 ∧ code e768814201370 = 9564907223578 := by decide
theorem cert_e768814201370 : check e768814201370 [] .sourceHead = true := by decide
end Blc.Floor43
