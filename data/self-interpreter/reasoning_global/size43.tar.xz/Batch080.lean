import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e775459901238 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e775459901238 : Closed e775459901238 ∧ code e775459901238 = 9571552923446 := by decide
theorem cert_e775459901238 : check e775459901238 [] .sourceHead = true := by decide
def e775459901242 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e775459901242 : Closed e775459901242 ∧ code e775459901242 = 9571552923450 := by decide
theorem cert_e775459901242 : check e775459901242 [] .sourceHead = true := by decide
def e775460490094 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e775460490094 : Closed e775460490094 ∧ code e775460490094 = 9571553512302 := by decide
theorem cert_e775460490094 : check e775460490094 [] .sourceHead = true := by decide
def e775460490102 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e775460490102 : Closed e775460490102 ∧ code e775460490102 = 9571553512310 := by decide
theorem cert_e775460490102 : check e775460490102 [] .sourceHead = true := by decide
def e775460490158 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e775460490158 : Closed e775460490158 ∧ code e775460490158 = 9571553512366 := by decide
theorem cert_e775460490158 : check e775460490158 [] .sourceHead = true := by decide
def e775460490170 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e775460490170 : Closed e775460490170 ∧ code e775460490170 = 9571553512378 := by decide
theorem cert_e775460490170 : check e775460490170 [] .sourceHead = true := by decide
def e775460490198 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e775460490198 : Closed e775460490198 ∧ code e775460490198 = 9571553512406 := by decide
theorem cert_e775460490198 : check e775460490198 [] .sourceHead = true := by decide
def e775460490202 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e775460490202 : Closed e775460490202 ∧ code e775460490202 = 9571553512410 := by decide
theorem cert_e775460490202 : check e775460490202 [] .sourceHead = true := by decide
def e775460490478 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e775460490478 : Closed e775460490478 ∧ code e775460490478 = 9571553512686 := by decide
theorem cert_e775460490478 : check e775460490478 [] .sourceHead = true := by decide
def e775460490486 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e775460490486 : Closed e775460490486 ∧ code e775460490486 = 9571553512694 := by decide
theorem cert_e775460490486 : check e775460490486 [] .sourceHead = true := by decide
def e775460490862 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e775460490862 : Closed e775460490862 ∧ code e775460490862 = 9571553513070 := by decide
theorem cert_e775460490862 : check e775460490862 [] .sourceHead = true := by decide
def e775460490874 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e775460490874 : Closed e775460490874 ∧ code e775460490874 = 9571553513082 := by decide
theorem cert_e775460490874 : check e775460490874 [] .sourceHead = true := by decide
def e775460491062 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e775460491062 : Closed e775460491062 ∧ code e775460491062 = 9571553513270 := by decide
theorem cert_e775460491062 : check e775460491062 [] .sourceHead = true := by decide
def e775460491066 : Term := (.lam (.app (.app (.var 0) (.var 0)) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e775460491066 : Closed e775460491066 ∧ code e775460491066 = 9571553513274 := by decide
theorem cert_e775460491066 : check e775460491066 [] .sourceHead = true := by decide
def e824781614446 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e824781614446 : Closed e824781614446 ∧ code e824781614446 = 9620874636654 := by decide
theorem cert_e824781614446 : check e824781614446 [] .sourceHead = true := by decide
def e824781614454 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e824781614454 : Closed e824781614454 ∧ code e824781614454 = 9620874636662 := by decide
theorem cert_e824781614454 : check e824781614454 [] .sourceHead = true := by decide
def e824781614510 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e824781614510 : Closed e824781614510 ∧ code e824781614510 = 9620874636718 := by decide
theorem cert_e824781614510 : check e824781614510 [] .sourceHead = true := by decide
def e824781614522 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e824781614522 : Closed e824781614522 ∧ code e824781614522 = 9620874636730 := by decide
theorem cert_e824781614522 : check e824781614522 [] .sourceHead = true := by decide
def e824781614550 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e824781614550 : Closed e824781614550 ∧ code e824781614550 = 9620874636758 := by decide
theorem cert_e824781614550 : check e824781614550 [] .sourceHead = true := by decide
def e824781614554 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e824781614554 : Closed e824781614554 ∧ code e824781614554 = 9620874636762 := by decide
theorem cert_e824781614554 : check e824781614554 [] .sourceHead = true := by decide
def e824781614766 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e824781614766 : Closed e824781614766 ∧ code e824781614766 = 9620874636974 := by decide
theorem cert_e824781614766 : check e824781614766 [] .sourceHead = true := by decide
def e824781614778 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e824781614778 : Closed e824781614778 ∧ code e824781614778 = 9620874636986 := by decide
theorem cert_e824781614778 : check e824781614778 [] .sourceHead = true := by decide
def e824781614826 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e824781614826 : Closed e824781614826 ∧ code e824781614826 = 9620874637034 := by decide
theorem cert_e824781614826 : check e824781614826 [] .sourceHead = true := by decide
def e824781614934 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e824781614934 : Closed e824781614934 ∧ code e824781614934 = 9620874637142 := by decide
theorem cert_e824781614934 : check e824781614934 [] .sourceHead = true := by decide
def e824781614938 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e824781614938 : Closed e824781614938 ∧ code e824781614938 = 9620874637146 := by decide
theorem cert_e824781614938 : check e824781614938 [] .sourceHead = true := by decide
def e824781614954 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e824781614954 : Closed e824781614954 ∧ code e824781614954 = 9620874637162 := by decide
theorem cert_e824781614954 : check e824781614954 [] .sourceHead = true := by decide
def e824781615982 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e824781615982 : Closed e824781615982 ∧ code e824781615982 = 9620874638190 := by decide
theorem cert_e824781615982 : check e824781615982 [] .sourceHead = true := by decide
def e824781615990 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e824781615990 : Closed e824781615990 ∧ code e824781615990 = 9620874638198 := by decide
theorem cert_e824781615990 : check e824781615990 [] .sourceHead = true := by decide
def e824781616046 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e824781616046 : Closed e824781616046 ∧ code e824781616046 = 9620874638254 := by decide
theorem cert_e824781616046 : check e824781616046 [] .sourceHead = true := by decide
def e824781616058 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e824781616058 : Closed e824781616058 ∧ code e824781616058 = 9620874638266 := by decide
theorem cert_e824781616058 : check e824781616058 [] .sourceHead = true := by decide
def e824781616086 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e824781616086 : Closed e824781616086 ∧ code e824781616086 = 9620874638294 := by decide
theorem cert_e824781616086 : check e824781616086 [] .sourceHead = true := by decide
def e824781616090 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e824781616090 : Closed e824781616090 ∧ code e824781616090 = 9620874638298 := by decide
theorem cert_e824781616090 : check e824781616090 [] .sourceHead = true := by decide
def e824781616366 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e824781616366 : Closed e824781616366 ∧ code e824781616366 = 9620874638574 := by decide
theorem cert_e824781616366 : check e824781616366 [] .sourceHead = true := by decide
def e824781616374 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e824781616374 : Closed e824781616374 ∧ code e824781616374 = 9620874638582 := by decide
theorem cert_e824781616374 : check e824781616374 [] .sourceHead = true := by decide
def e824781616750 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e824781616750 : Closed e824781616750 ∧ code e824781616750 = 9620874638958 := by decide
theorem cert_e824781616750 : check e824781616750 [] .sourceHead = true := by decide
def e824781616762 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e824781616762 : Closed e824781616762 ∧ code e824781616762 = 9620874638970 := by decide
theorem cert_e824781616762 : check e824781616762 [] .sourceHead = true := by decide
def e824781616950 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e824781616950 : Closed e824781616950 ∧ code e824781616950 = 9620874639158 := by decide
theorem cert_e824781616950 : check e824781616950 [] .sourceHead = true := by decide
def e824781616954 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e824781616954 : Closed e824781616954 ∧ code e824781616954 = 9620874639162 := by decide
theorem cert_e824781616954 : check e824781616954 [] .sourceHead = true := by decide
def e824781617582 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e824781617582 : Closed e824781617582 ∧ code e824781617582 = 9620874639790 := by decide
theorem cert_e824781617582 : check e824781617582 [] .sourceHead = true := by decide
def e824781617594 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e824781617594 : Closed e824781617594 ∧ code e824781617594 = 9620874639802 := by decide
theorem cert_e824781617594 : check e824781617594 [] .sourceHead = true := by decide
def e824781617642 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e824781617642 : Closed e824781617642 ∧ code e824781617642 = 9620874639850 := by decide
theorem cert_e824781617642 : check e824781617642 [] .sourceHead = true := by decide
def e824781617774 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e824781617774 : Closed e824781617774 ∧ code e824781617774 = 9620874639982 := by decide
theorem cert_e824781617774 : check e824781617774 [] .sourceHead = true := by decide
def e824781617786 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e824781617786 : Closed e824781617786 ∧ code e824781617786 = 9620874639994 := by decide
theorem cert_e824781617786 : check e824781617786 [] .sourceHead = true := by decide
def e824781618074 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e824781618074 : Closed e824781618074 ∧ code e824781618074 = 9620874640282 := by decide
theorem cert_e824781618074 : check e824781618074 [] .sourceHead = true := by decide
def e824781618390 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e824781618390 : Closed e824781618390 ∧ code e824781618390 = 9620874640598 := by decide
theorem cert_e824781618390 : check e824781618390 [] .sourceHead = true := by decide
def e824781618394 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e824781618394 : Closed e824781618394 ∧ code e824781618394 = 9620874640602 := by decide
theorem cert_e824781618394 : check e824781618394 [] .sourceHead = true := by decide
def e824781618410 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e824781618410 : Closed e824781618410 ∧ code e824781618410 = 9620874640618 := by decide
theorem cert_e824781618410 : check e824781618410 [] .sourceHead = true := by decide
def e824781618486 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e824781618486 : Closed e824781618486 ∧ code e824781618486 = 9620874640694 := by decide
theorem cert_e824781618486 : check e824781618486 [] .sourceHead = true := by decide
def e824781618490 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e824781618490 : Closed e824781618490 ∧ code e824781618490 = 9620874640698 := by decide
theorem cert_e824781618490 : check e824781618490 [] .sourceHead = true := by decide
def e824781618586 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e824781618586 : Closed e824781618586 ∧ code e824781618586 = 9620874640794 := by decide
theorem cert_e824781618586 : check e824781618586 [] .sourceHead = true := by decide
def e824781622126 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e824781622126 : Closed e824781622126 ∧ code e824781622126 = 9620874644334 := by decide
theorem cert_e824781622126 : check e824781622126 [] .sourceHead = true := by decide
def e824781622134 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e824781622134 : Closed e824781622134 ∧ code e824781622134 = 9620874644342 := by decide
theorem cert_e824781622134 : check e824781622134 [] .sourceHead = true := by decide
def e824781622190 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))))
theorem wire_e824781622190 : Closed e824781622190 ∧ code e824781622190 = 9620874644398 := by decide
theorem cert_e824781622190 : check e824781622190 [] .sourceHead = true := by decide
def e824781622202 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))))
theorem wire_e824781622202 : Closed e824781622202 ∧ code e824781622202 = 9620874644410 := by decide
theorem cert_e824781622202 : check e824781622202 [] .sourceHead = true := by decide
def e824781622230 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))))
theorem wire_e824781622230 : Closed e824781622230 ∧ code e824781622230 = 9620874644438 := by decide
theorem cert_e824781622230 : check e824781622230 [] .sourceHead = true := by decide
def e824781622234 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))))
theorem wire_e824781622234 : Closed e824781622234 ∧ code e824781622234 = 9620874644442 := by decide
theorem cert_e824781622234 : check e824781622234 [] .sourceHead = true := by decide
def e824781622510 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))))
theorem wire_e824781622510 : Closed e824781622510 ∧ code e824781622510 = 9620874644718 := by decide
theorem cert_e824781622510 : check e824781622510 [] .sourceHead = true := by decide
def e824781622518 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))))
theorem wire_e824781622518 : Closed e824781622518 ∧ code e824781622518 = 9620874644726 := by decide
theorem cert_e824781622518 : check e824781622518 [] .sourceHead = true := by decide
def e824781622894 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))))
theorem wire_e824781622894 : Closed e824781622894 ∧ code e824781622894 = 9620874645102 := by decide
theorem cert_e824781622894 : check e824781622894 [] .sourceHead = true := by decide
def e824781622906 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))))
theorem wire_e824781622906 : Closed e824781622906 ∧ code e824781622906 = 9620874645114 := by decide
theorem cert_e824781622906 : check e824781622906 [] .sourceHead = true := by decide
def e824781623094 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))))
theorem wire_e824781623094 : Closed e824781623094 ∧ code e824781623094 = 9620874645302 := by decide
theorem cert_e824781623094 : check e824781623094 [] .sourceHead = true := by decide
def e824781623098 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))))
theorem wire_e824781623098 : Closed e824781623098 ∧ code e824781623098 = 9620874645306 := by decide
theorem cert_e824781623098 : check e824781623098 [] .sourceHead = true := by decide
def e824781628846 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))))
theorem wire_e824781628846 : Closed e824781628846 ∧ code e824781628846 = 9620874651054 := by decide
theorem cert_e824781628846 : check e824781628846 [] .sourceHead = true := by decide
def e824781628858 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))))
theorem wire_e824781628858 : Closed e824781628858 ∧ code e824781628858 = 9620874651066 := by decide
theorem cert_e824781628858 : check e824781628858 [] .sourceHead = true := by decide
def e824781628906 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))))
theorem wire_e824781628906 : Closed e824781628906 ∧ code e824781628906 = 9620874651114 := by decide
theorem cert_e824781628906 : check e824781628906 [] .sourceHead = true := by decide
def e824781629038 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))))
theorem wire_e824781629038 : Closed e824781629038 ∧ code e824781629038 = 9620874651246 := by decide
theorem cert_e824781629038 : check e824781629038 [] .sourceHead = true := by decide
def e824781629050 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))))
theorem wire_e824781629050 : Closed e824781629050 ∧ code e824781629050 = 9620874651258 := by decide
theorem cert_e824781629050 : check e824781629050 [] .sourceHead = true := by decide
def e824781629338 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))))
theorem wire_e824781629338 : Closed e824781629338 ∧ code e824781629338 = 9620874651546 := by decide
theorem cert_e824781629338 : check e824781629338 [] .sourceHead = true := by decide
def e824781632214 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))))
theorem wire_e824781632214 : Closed e824781632214 ∧ code e824781632214 = 9620874654422 := by decide
theorem cert_e824781632214 : check e824781632214 [] .sourceHead = true := by decide
def e824781632218 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))))
theorem wire_e824781632218 : Closed e824781632218 ∧ code e824781632218 = 9620874654426 := by decide
theorem cert_e824781632218 : check e824781632218 [] .sourceHead = true := by decide
def e824781632234 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))))
theorem wire_e824781632234 : Closed e824781632234 ∧ code e824781632234 = 9620874654442 := by decide
theorem cert_e824781632234 : check e824781632234 [] .sourceHead = true := by decide
def e824781632310 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))))
theorem wire_e824781632310 : Closed e824781632310 ∧ code e824781632310 = 9620874654518 := by decide
theorem cert_e824781632310 : check e824781632310 [] .sourceHead = true := by decide
def e824781632314 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))))
theorem wire_e824781632314 : Closed e824781632314 ∧ code e824781632314 = 9620874654522 := by decide
theorem cert_e824781632314 : check e824781632314 [] .sourceHead = true := by decide
def e824781632410 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))))
theorem wire_e824781632410 : Closed e824781632410 ∧ code e824781632410 = 9620874654618 := by decide
theorem cert_e824781632410 : check e824781632410 [] .sourceHead = true := by decide
def e825216055322 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216055322 : Closed e825216055322 ∧ code e825216055322 = 9621309077530 := by decide
theorem cert_e825216055322 : check e825216055322 [] .sourceHead = true := by decide
def e825216063514 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216063514 : Closed e825216063514 ∧ code e825216063514 = 9621309085722 := by decide
theorem cert_e825216063514 : check e825216063514 [] .sourceHead = true := by decide
def e825216120858 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216120858 : Closed e825216120858 ∧ code e825216120858 = 9621309143066 := by decide
theorem cert_e825216120858 : check e825216120858 [] .sourceHead = true := by decide
def e825216133146 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216133146 : Closed e825216133146 ∧ code e825216133146 = 9621309155354 := by decide
theorem cert_e825216133146 : check e825216133146 [] .sourceHead = true := by decide
def e825216161818 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216161818 : Closed e825216161818 ∧ code e825216161818 = 9621309184026 := by decide
theorem cert_e825216161818 : check e825216161818 [] .sourceHead = true := by decide
def e825216165914 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216165914 : Closed e825216165914 ∧ code e825216165914 = 9621309188122 := by decide
theorem cert_e825216165914 : check e825216165914 [] .sourceHead = true := by decide
def e825216383002 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216383002 : Closed e825216383002 ∧ code e825216383002 = 9621309405210 := by decide
theorem cert_e825216383002 : check e825216383002 [] .sourceHead = true := by decide
def e825216395290 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216395290 : Closed e825216395290 ∧ code e825216395290 = 9621309417498 := by decide
theorem cert_e825216395290 : check e825216395290 [] .sourceHead = true := by decide
def e825216444442 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216444442 : Closed e825216444442 ∧ code e825216444442 = 9621309466650 := by decide
theorem cert_e825216444442 : check e825216444442 [] .sourceHead = true := by decide
def e825216555034 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216555034 : Closed e825216555034 ∧ code e825216555034 = 9621309577242 := by decide
theorem cert_e825216555034 : check e825216555034 [] .sourceHead = true := by decide
def e825216559130 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216559130 : Closed e825216559130 ∧ code e825216559130 = 9621309581338 := by decide
theorem cert_e825216559130 : check e825216559130 [] .sourceHead = true := by decide
def e825216575514 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825216575514 : Closed e825216575514 ∧ code e825216575514 = 9621309597722 := by decide
theorem cert_e825216575514 : check e825216575514 [] .sourceHead = true := by decide
def e825217628186 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825217628186 : Closed e825217628186 ∧ code e825217628186 = 9621310650394 := by decide
theorem cert_e825217628186 : check e825217628186 [] .sourceHead = true := by decide
def e825217636378 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825217636378 : Closed e825217636378 ∧ code e825217636378 = 9621310658586 := by decide
theorem cert_e825217636378 : check e825217636378 [] .sourceHead = true := by decide
def e825217693722 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825217693722 : Closed e825217693722 ∧ code e825217693722 = 9621310715930 := by decide
theorem cert_e825217693722 : check e825217693722 [] .sourceHead = true := by decide
def e825217706010 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825217706010 : Closed e825217706010 ∧ code e825217706010 = 9621310728218 := by decide
theorem cert_e825217706010 : check e825217706010 [] .sourceHead = true := by decide
def e825217734682 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825217734682 : Closed e825217734682 ∧ code e825217734682 = 9621310756890 := by decide
theorem cert_e825217734682 : check e825217734682 [] .sourceHead = true := by decide
def e825217738778 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825217738778 : Closed e825217738778 ∧ code e825217738778 = 9621310760986 := by decide
theorem cert_e825217738778 : check e825217738778 [] .sourceHead = true := by decide
def e825218021402 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825218021402 : Closed e825218021402 ∧ code e825218021402 = 9621311043610 := by decide
theorem cert_e825218021402 : check e825218021402 [] .sourceHead = true := by decide
def e825218029594 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825218029594 : Closed e825218029594 ∧ code e825218029594 = 9621311051802 := by decide
theorem cert_e825218029594 : check e825218029594 [] .sourceHead = true := by decide
def e825218414618 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825218414618 : Closed e825218414618 ∧ code e825218414618 = 9621311436826 := by decide
theorem cert_e825218414618 : check e825218414618 [] .sourceHead = true := by decide
def e825218426906 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825218426906 : Closed e825218426906 ∧ code e825218426906 = 9621311449114 := by decide
theorem cert_e825218426906 : check e825218426906 [] .sourceHead = true := by decide
def e825218619418 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825218619418 : Closed e825218619418 ∧ code e825218619418 = 9621311641626 := by decide
theorem cert_e825218619418 : check e825218619418 [] .sourceHead = true := by decide
def e825218623514 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825218623514 : Closed e825218623514 ∧ code e825218623514 = 9621311645722 := by decide
theorem cert_e825218623514 : check e825218623514 [] .sourceHead = true := by decide
def e825219266586 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825219266586 : Closed e825219266586 ∧ code e825219266586 = 9621312288794 := by decide
theorem cert_e825219266586 : check e825219266586 [] .sourceHead = true := by decide
def e825219278874 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825219278874 : Closed e825219278874 ∧ code e825219278874 = 9621312301082 := by decide
theorem cert_e825219278874 : check e825219278874 [] .sourceHead = true := by decide
def e825219328026 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825219328026 : Closed e825219328026 ∧ code e825219328026 = 9621312350234 := by decide
theorem cert_e825219328026 : check e825219328026 [] .sourceHead = true := by decide
def e825219463194 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825219463194 : Closed e825219463194 ∧ code e825219463194 = 9621312485402 := by decide
theorem cert_e825219463194 : check e825219463194 [] .sourceHead = true := by decide
def e825219475482 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825219475482 : Closed e825219475482 ∧ code e825219475482 = 9621312497690 := by decide
theorem cert_e825219475482 : check e825219475482 [] .sourceHead = true := by decide
def e825219770394 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825219770394 : Closed e825219770394 ∧ code e825219770394 = 9621312792602 := by decide
theorem cert_e825219770394 : check e825219770394 [] .sourceHead = true := by decide
def e825220093978 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825220093978 : Closed e825220093978 ∧ code e825220093978 = 9621313116186 := by decide
theorem cert_e825220093978 : check e825220093978 [] .sourceHead = true := by decide
def e825220098074 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825220098074 : Closed e825220098074 ∧ code e825220098074 = 9621313120282 := by decide
theorem cert_e825220098074 : check e825220098074 [] .sourceHead = true := by decide
def e825220114458 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825220114458 : Closed e825220114458 ∧ code e825220114458 = 9621313136666 := by decide
theorem cert_e825220114458 : check e825220114458 [] .sourceHead = true := by decide
def e825220192282 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825220192282 : Closed e825220192282 ∧ code e825220192282 = 9621313214490 := by decide
theorem cert_e825220192282 : check e825220192282 [] .sourceHead = true := by decide
def e825220196378 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825220196378 : Closed e825220196378 ∧ code e825220196378 = 9621313218586 := by decide
theorem cert_e825220196378 : check e825220196378 [] .sourceHead = true := by decide
def e825220294682 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825220294682 : Closed e825220294682 ∧ code e825220294682 = 9621313316890 := by decide
theorem cert_e825220294682 : check e825220294682 [] .sourceHead = true := by decide
def e825223919642 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825223919642 : Closed e825223919642 ∧ code e825223919642 = 9621316941850 := by decide
theorem cert_e825223919642 : check e825223919642 [] .sourceHead = true := by decide
def e825223927834 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825223927834 : Closed e825223927834 ∧ code e825223927834 = 9621316950042 := by decide
theorem cert_e825223927834 : check e825223927834 [] .sourceHead = true := by decide
def e825223985178 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825223985178 : Closed e825223985178 ∧ code e825223985178 = 9621317007386 := by decide
theorem cert_e825223985178 : check e825223985178 [] .sourceHead = true := by decide
def e825223997466 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825223997466 : Closed e825223997466 ∧ code e825223997466 = 9621317019674 := by decide
theorem cert_e825223997466 : check e825223997466 [] .sourceHead = true := by decide
def e825224026138 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224026138 : Closed e825224026138 ∧ code e825224026138 = 9621317048346 := by decide
theorem cert_e825224026138 : check e825224026138 [] .sourceHead = true := by decide
def e825224030234 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224030234 : Closed e825224030234 ∧ code e825224030234 = 9621317052442 := by decide
theorem cert_e825224030234 : check e825224030234 [] .sourceHead = true := by decide
def e825224312858 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224312858 : Closed e825224312858 ∧ code e825224312858 = 9621317335066 := by decide
theorem cert_e825224312858 : check e825224312858 [] .sourceHead = true := by decide
def e825224321050 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224321050 : Closed e825224321050 ∧ code e825224321050 = 9621317343258 := by decide
theorem cert_e825224321050 : check e825224321050 [] .sourceHead = true := by decide
def e825224706074 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224706074 : Closed e825224706074 ∧ code e825224706074 = 9621317728282 := by decide
theorem cert_e825224706074 : check e825224706074 [] .sourceHead = true := by decide
def e825224718362 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224718362 : Closed e825224718362 ∧ code e825224718362 = 9621317740570 := by decide
theorem cert_e825224718362 : check e825224718362 [] .sourceHead = true := by decide
def e825224910874 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224910874 : Closed e825224910874 ∧ code e825224910874 = 9621317933082 := by decide
theorem cert_e825224910874 : check e825224910874 [] .sourceHead = true := by decide
def e825224914970 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e825224914970 : Closed e825224914970 ∧ code e825224914970 = 9621317937178 := by decide
theorem cert_e825224914970 : check e825224914970 [] .sourceHead = true := by decide
def e825225162094 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))))
theorem wire_e825225162094 : Closed e825225162094 ∧ code e825225162094 = 9621318184302 := by decide
theorem cert_e825225162094 : check e825225162094 [] .sourceHead = true := by decide
def e825225162102 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))))
theorem wire_e825225162102 : Closed e825225162102 ∧ code e825225162102 = 9621318184310 := by decide
theorem cert_e825225162102 : check e825225162102 [] .sourceHead = true := by decide
def e825225162158 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))))
theorem wire_e825225162158 : Closed e825225162158 ∧ code e825225162158 = 9621318184366 := by decide
theorem cert_e825225162158 : check e825225162158 [] .sourceHead = true := by decide
def e825225162170 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))))
theorem wire_e825225162170 : Closed e825225162170 ∧ code e825225162170 = 9621318184378 := by decide
theorem cert_e825225162170 : check e825225162170 [] .sourceHead = true := by decide
def e825225162198 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))))
theorem wire_e825225162198 : Closed e825225162198 ∧ code e825225162198 = 9621318184406 := by decide
theorem cert_e825225162198 : check e825225162198 [] .sourceHead = true := by decide
def e825225162202 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))))
theorem wire_e825225162202 : Closed e825225162202 ∧ code e825225162202 = 9621318184410 := by decide
theorem cert_e825225162202 : check e825225162202 [] .sourceHead = true := by decide
def e825225162414 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))))
theorem wire_e825225162414 : Closed e825225162414 ∧ code e825225162414 = 9621318184622 := by decide
theorem cert_e825225162414 : check e825225162414 [] .sourceHead = true := by decide
def e825225162426 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))))
theorem wire_e825225162426 : Closed e825225162426 ∧ code e825225162426 = 9621318184634 := by decide
theorem cert_e825225162426 : check e825225162426 [] .sourceHead = true := by decide
def e825225162474 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))))
theorem wire_e825225162474 : Closed e825225162474 ∧ code e825225162474 = 9621318184682 := by decide
theorem cert_e825225162474 : check e825225162474 [] .sourceHead = true := by decide
def e825225162582 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))))
theorem wire_e825225162582 : Closed e825225162582 ∧ code e825225162582 = 9621318184790 := by decide
theorem cert_e825225162582 : check e825225162582 [] .sourceHead = true := by decide
def e825225162586 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))))
theorem wire_e825225162586 : Closed e825225162586 ∧ code e825225162586 = 9621318184794 := by decide
theorem cert_e825225162586 : check e825225162586 [] .sourceHead = true := by decide
def e825225162602 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))))
theorem wire_e825225162602 : Closed e825225162602 ∧ code e825225162602 = 9621318184810 := by decide
theorem cert_e825225162602 : check e825225162602 [] .sourceHead = true := by decide
def e825225163630 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))))
theorem wire_e825225163630 : Closed e825225163630 ∧ code e825225163630 = 9621318185838 := by decide
theorem cert_e825225163630 : check e825225163630 [] .sourceHead = true := by decide
def e825225163638 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))))
theorem wire_e825225163638 : Closed e825225163638 ∧ code e825225163638 = 9621318185846 := by decide
theorem cert_e825225163638 : check e825225163638 [] .sourceHead = true := by decide
def e825225163694 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))))
theorem wire_e825225163694 : Closed e825225163694 ∧ code e825225163694 = 9621318185902 := by decide
theorem cert_e825225163694 : check e825225163694 [] .sourceHead = true := by decide
def e825225163706 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))))
theorem wire_e825225163706 : Closed e825225163706 ∧ code e825225163706 = 9621318185914 := by decide
theorem cert_e825225163706 : check e825225163706 [] .sourceHead = true := by decide
def e825225163734 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))))
theorem wire_e825225163734 : Closed e825225163734 ∧ code e825225163734 = 9621318185942 := by decide
theorem cert_e825225163734 : check e825225163734 [] .sourceHead = true := by decide
def e825225163738 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))))
theorem wire_e825225163738 : Closed e825225163738 ∧ code e825225163738 = 9621318185946 := by decide
theorem cert_e825225163738 : check e825225163738 [] .sourceHead = true := by decide
def e825225164014 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))))
theorem wire_e825225164014 : Closed e825225164014 ∧ code e825225164014 = 9621318186222 := by decide
theorem cert_e825225164014 : check e825225164014 [] .sourceHead = true := by decide
def e825225164022 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))))
theorem wire_e825225164022 : Closed e825225164022 ∧ code e825225164022 = 9621318186230 := by decide
theorem cert_e825225164022 : check e825225164022 [] .sourceHead = true := by decide
def e825225164398 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e825225164398 : Closed e825225164398 ∧ code e825225164398 = 9621318186606 := by decide
theorem cert_e825225164398 : check e825225164398 [] .sourceHead = true := by decide
def e825225164410 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e825225164410 : Closed e825225164410 ∧ code e825225164410 = 9621318186618 := by decide
theorem cert_e825225164410 : check e825225164410 [] .sourceHead = true := by decide
def e825225164598 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e825225164598 : Closed e825225164598 ∧ code e825225164598 = 9621318186806 := by decide
theorem cert_e825225164598 : check e825225164598 [] .sourceHead = true := by decide
def e825225164602 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e825225164602 : Closed e825225164602 ∧ code e825225164602 = 9621318186810 := by decide
theorem cert_e825225164602 : check e825225164602 [] .sourceHead = true := by decide
def e825225165230 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))))
theorem wire_e825225165230 : Closed e825225165230 ∧ code e825225165230 = 9621318187438 := by decide
theorem cert_e825225165230 : check e825225165230 [] .sourceHead = true := by decide
def e825225165242 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))))
theorem wire_e825225165242 : Closed e825225165242 ∧ code e825225165242 = 9621318187450 := by decide
theorem cert_e825225165242 : check e825225165242 [] .sourceHead = true := by decide
def e825225165290 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))))
theorem wire_e825225165290 : Closed e825225165290 ∧ code e825225165290 = 9621318187498 := by decide
theorem cert_e825225165290 : check e825225165290 [] .sourceHead = true := by decide
def e825225165422 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))))
theorem wire_e825225165422 : Closed e825225165422 ∧ code e825225165422 = 9621318187630 := by decide
theorem cert_e825225165422 : check e825225165422 [] .sourceHead = true := by decide
def e825225165434 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))))
theorem wire_e825225165434 : Closed e825225165434 ∧ code e825225165434 = 9621318187642 := by decide
theorem cert_e825225165434 : check e825225165434 [] .sourceHead = true := by decide
def e825225165722 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e825225165722 : Closed e825225165722 ∧ code e825225165722 = 9621318187930 := by decide
theorem cert_e825225165722 : check e825225165722 [] .sourceHead = true := by decide
def e825225166038 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))))
theorem wire_e825225166038 : Closed e825225166038 ∧ code e825225166038 = 9621318188246 := by decide
theorem cert_e825225166038 : check e825225166038 [] .sourceHead = true := by decide
def e825225166042 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))))
theorem wire_e825225166042 : Closed e825225166042 ∧ code e825225166042 = 9621318188250 := by decide
theorem cert_e825225166042 : check e825225166042 [] .sourceHead = true := by decide
def e825225166058 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))))
theorem wire_e825225166058 : Closed e825225166058 ∧ code e825225166058 = 9621318188266 := by decide
theorem cert_e825225166058 : check e825225166058 [] .sourceHead = true := by decide
def e825225166134 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))))
theorem wire_e825225166134 : Closed e825225166134 ∧ code e825225166134 = 9621318188342 := by decide
theorem cert_e825225166134 : check e825225166134 [] .sourceHead = true := by decide
def e825225166138 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))))
theorem wire_e825225166138 : Closed e825225166138 ∧ code e825225166138 = 9621318188346 := by decide
theorem cert_e825225166138 : check e825225166138 [] .sourceHead = true := by decide
def e825225166234 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))))
theorem wire_e825225166234 : Closed e825225166234 ∧ code e825225166234 = 9621318188442 := by decide
theorem cert_e825225166234 : check e825225166234 [] .sourceHead = true := by decide
def e825225169774 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))))
theorem wire_e825225169774 : Closed e825225169774 ∧ code e825225169774 = 9621318191982 := by decide
theorem cert_e825225169774 : check e825225169774 [] .sourceHead = true := by decide
def e825225169782 : Term := (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))))
theorem wire_e825225169782 : Closed e825225169782 ∧ code e825225169782 = 9621318191990 := by decide
theorem cert_e825225169782 : check e825225169782 [] .sourceHead = true := by decide
end Blc.Floor43
