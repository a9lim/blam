import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422376601274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e2422376601274 : Closed e2422376601274 ∧ code e2422376601274 = 11218469623482 := by decide
theorem cert_e2422376601274 : check e2422376601274 [[],[]] .smaller = true := by decide
def e2422376601322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e2422376601322 : Closed e2422376601322 ∧ code e2422376601322 = 11218469623530 := by decide
theorem cert_e2422376601322 : check e2422376601322 [[],[]] .smaller = true := by decide
def e2422376601514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0))))))))
theorem wire_e2422376601514 : Closed e2422376601514 ∧ code e2422376601514 = 11218469623722 := by decide
theorem cert_e2422376601514 : check e2422376601514 [[],[]] .smaller = true := by decide
def e2422376601646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2))))))))
theorem wire_e2422376601646 : Closed e2422376601646 ∧ code e2422376601646 = 11218469623854 := by decide
theorem cert_e2422376601646 : check e2422376601646 [[],[]] .smaller = true := by decide
def e2422376601822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 3))))))))
theorem wire_e2422376601822 : Closed e2422376601822 ∧ code e2422376601822 = 11218469624030 := by decide
theorem cert_e2422376601822 : check e2422376601822 [[],[]] .three = true := by decide
def e2422376601838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422376601838 : Closed e2422376601838 ∧ code e2422376601838 = 11218469624046 := by decide
theorem cert_e2422376601838 : check e2422376601838 [[],[]] .smaller = true := by decide
def e2422376601846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e2422376601846 : Closed e2422376601846 ∧ code e2422376601846 = 11218469624054 := by decide
theorem cert_e2422376601846 : check e2422376601846 [[],[]] .smaller = true := by decide
def e2422376601850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422376601850 : Closed e2422376601850 ∧ code e2422376601850 = 11218469624058 := by decide
theorem cert_e2422376601850 : check e2422376601850 [[],[]] .three = true := by decide
def e2422376602030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e2422376602030 : Closed e2422376602030 ∧ code e2422376602030 = 11218469624238 := by decide
theorem cert_e2422376602030 : check e2422376602030 [[],[]] .smaller = true := by decide
def e2422376602042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422376602042 : Closed e2422376602042 ∧ code e2422376602042 = 11218469624250 := by decide
theorem cert_e2422376602042 : check e2422376602042 [[],[]] .smaller = true := by decide
def e2422376602090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422376602090 : Closed e2422376602090 ∧ code e2422376602090 = 11218469624298 := by decide
theorem cert_e2422376602090 : check e2422376602090 [[],[]] .smaller = true := by decide
def e2422376602174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 4)))))))))
theorem wire_e2422376602174 : Closed e2422376602174 ∧ code e2422376602174 = 11218469624382 := by decide
theorem cert_e2422376602174 : check e2422376602174 [[],[]] .three = true := by decide
def e2422376602222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376602222 : Closed e2422376602222 ∧ code e2422376602222 = 11218469624430 := by decide
theorem cert_e2422376602222 : check e2422376602222 [[],[]] .smaller = true := by decide
def e2422376602234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376602234 : Closed e2422376602234 ∧ code e2422376602234 = 11218469624442 := by decide
theorem cert_e2422376602234 : check e2422376602234 [[],[]] .smaller = true := by decide
def e2422376602398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422376602398 : Closed e2422376602398 ∧ code e2422376602398 = 11218469624606 := by decide
theorem cert_e2422376602398 : check e2422376602398 [[],[]] .smaller = true := by decide
def e2422376602498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422376602498 : Closed e2422376602498 ∧ code e2422376602498 = 11218469624706 := by decide
theorem cert_e2422376602498 : check e2422376602498 [[],[]] .smaller = true := by decide
def e2422376602510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e2422376602510 : Closed e2422376602510 ∧ code e2422376602510 = 11218469624718 := by decide
theorem cert_e2422376602510 : check e2422376602510 [[],[]] .smaller = true := by decide
def e2422376602522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376602522 : Closed e2422376602522 ∧ code e2422376602522 = 11218469624730 := by decide
theorem cert_e2422376602522 : check e2422376602522 [[],[]] .smaller = true := by decide
def e2422376602566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422376602566 : Closed e2422376602566 ∧ code e2422376602566 = 11218469624774 := by decide
theorem cert_e2422376602566 : check e2422376602566 [[],[]] .three = true := by decide
def e2422376602590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 3))))))))
theorem wire_e2422376602590 : Closed e2422376602590 ∧ code e2422376602590 = 11218469624798 := by decide
theorem cert_e2422376602590 : check e2422376602590 [[],[]] .three = true := by decide
def e2422376602718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e2422376602718 : Closed e2422376602718 ∧ code e2422376602718 = 11218469624926 := by decide
theorem cert_e2422376602718 : check e2422376602718 [[],[]] .three = true := by decide
def e2422376602734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e2422376602734 : Closed e2422376602734 ∧ code e2422376602734 = 11218469624942 := by decide
theorem cert_e2422376602734 : check e2422376602734 [[],[]] .smaller = true := by decide
def e2422376602746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422376602746 : Closed e2422376602746 ∧ code e2422376602746 = 11218469624954 := by decide
theorem cert_e2422376602746 : check e2422376602746 [[],[]] .smaller = true := by decide
def e2422376602910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e2422376602910 : Closed e2422376602910 ∧ code e2422376602910 = 11218469625118 := by decide
theorem cert_e2422376602910 : check e2422376602910 [[],[]] .smaller = true := by decide
def e2422376603078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422376603078 : Closed e2422376603078 ∧ code e2422376603078 = 11218469625286 := by decide
theorem cert_e2422376603078 : check e2422376603078 [[],[]] .smaller = true := by decide
def e2422376603102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 3))))))))
theorem wire_e2422376603102 : Closed e2422376603102 ∧ code e2422376603102 = 11218469625310 := by decide
theorem cert_e2422376603102 : check e2422376603102 [[],[]] .three = true := by decide
def e2422376603106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e2422376603106 : Closed e2422376603106 ∧ code e2422376603106 = 11218469625314 := by decide
theorem cert_e2422376603106 : check e2422376603106 [[],[]] .three = true := by decide
def e2422376603118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 2))))))))
theorem wire_e2422376603118 : Closed e2422376603118 ∧ code e2422376603118 = 11218469625326 := by decide
theorem cert_e2422376603118 : check e2422376603118 [[],[]] .three = true := by decide
def e2422376603146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 0))))) (.var 0))))))))
theorem wire_e2422376603146 : Closed e2422376603146 ∧ code e2422376603146 = 11218469625354 := by decide
theorem cert_e2422376603146 : check e2422376603146 [[],[]] .smaller = true := by decide
def e2422376603182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 2))))))))
theorem wire_e2422376603182 : Closed e2422376603182 ∧ code e2422376603182 = 11218469625390 := by decide
theorem cert_e2422376603182 : check e2422376603182 [[],[]] .smaller = true := by decide
def e2422376603190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))))
theorem wire_e2422376603190 : Closed e2422376603190 ∧ code e2422376603190 = 11218469625398 := by decide
theorem cert_e2422376603190 : check e2422376603190 [[],[]] .smaller = true := by decide
def e2422376603194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))))
theorem wire_e2422376603194 : Closed e2422376603194 ∧ code e2422376603194 = 11218469625402 := by decide
theorem cert_e2422376603194 : check e2422376603194 [[],[]] .smaller = true := by decide
def e2422376603242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0))))))))
theorem wire_e2422376603242 : Closed e2422376603242 ∧ code e2422376603242 = 11218469625450 := by decide
theorem cert_e2422376603242 : check e2422376603242 [[],[]] .smaller = true := by decide
def e2422376603266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.lam (.var 0))))))))))
theorem wire_e2422376603266 : Closed e2422376603266 ∧ code e2422376603266 = 11218469625474 := by decide
theorem cert_e2422376603266 : check e2422376603266 [[],[]] .smaller = true := by decide
def e2422376603278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))))
theorem wire_e2422376603278 : Closed e2422376603278 ∧ code e2422376603278 = 11218469625486 := by decide
theorem cert_e2422376603278 : check e2422376603278 [[],[]] .smaller = true := by decide
def e2422376603290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376603290 : Closed e2422376603290 ∧ code e2422376603290 = 11218469625498 := by decide
theorem cert_e2422376603290 : check e2422376603290 [[],[]] .smaller = true := by decide
def e2422376603334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))))
theorem wire_e2422376603334 : Closed e2422376603334 ∧ code e2422376603334 = 11218469625542 := by decide
theorem cert_e2422376603334 : check e2422376603334 [[],[]] .smaller = true := by decide
def e2422376603358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 3))))))))
theorem wire_e2422376603358 : Closed e2422376603358 ∧ code e2422376603358 = 11218469625566 := by decide
theorem cert_e2422376603358 : check e2422376603358 [[],[]] .three = true := by decide
def e2422376603362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 0)))))))))
theorem wire_e2422376603362 : Closed e2422376603362 ∧ code e2422376603362 = 11218469625570 := by decide
theorem cert_e2422376603362 : check e2422376603362 [[],[]] .smaller = true := by decide
def e2422376603374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 2))))))))
theorem wire_e2422376603374 : Closed e2422376603374 ∧ code e2422376603374 = 11218469625582 := by decide
theorem cert_e2422376603374 : check e2422376603374 [[],[]] .smaller = true := by decide
def e2422376603382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 1))))))))
theorem wire_e2422376603382 : Closed e2422376603382 ∧ code e2422376603382 = 11218469625590 := by decide
theorem cert_e2422376603382 : check e2422376603382 [[],[]] .three = true := by decide
def e2422376603414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422376603414 : Closed e2422376603414 ∧ code e2422376603414 = 11218469625622 := by decide
theorem cert_e2422376603414 : check e2422376603414 [[],[]] .three = true := by decide
def e2422376603418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422376603418 : Closed e2422376603418 ∧ code e2422376603418 = 11218469625626 := by decide
theorem cert_e2422376603418 : check e2422376603418 [[],[]] .three = true := by decide
def e2422376603462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422376603462 : Closed e2422376603462 ∧ code e2422376603462 = 11218469625670 := by decide
theorem cert_e2422376603462 : check e2422376603462 [[],[]] .three = true := by decide
def e2422376603486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 3))))))))
theorem wire_e2422376603486 : Closed e2422376603486 ∧ code e2422376603486 = 11218469625694 := by decide
theorem cert_e2422376603486 : check e2422376603486 [[],[]] .three = true := by decide
def e2422376603490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.lam (.var 0)))))))))
theorem wire_e2422376603490 : Closed e2422376603490 ∧ code e2422376603490 = 11218469625698 := by decide
theorem cert_e2422376603490 : check e2422376603490 [[],[]] .three = true := by decide
def e2422376603502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 2))))))))
theorem wire_e2422376603502 : Closed e2422376603502 ∧ code e2422376603502 = 11218469625710 := by decide
theorem cert_e2422376603502 : check e2422376603502 [[],[]] .three = true := by decide
def e2422376603510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 1))))))))
theorem wire_e2422376603510 : Closed e2422376603510 ∧ code e2422376603510 = 11218469625718 := by decide
theorem cert_e2422376603510 : check e2422376603510 [[],[]] .three = true := by decide
def e2422376603514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 0))))))))
theorem wire_e2422376603514 : Closed e2422376603514 ∧ code e2422376603514 = 11218469625722 := by decide
theorem cert_e2422376603514 : check e2422376603514 [[],[]] .three = true := by decide
def e2422376604094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 4))))))))))
theorem wire_e2422376604094 : Closed e2422376604094 ∧ code e2422376604094 = 11218469626302 := by decide
theorem cert_e2422376604094 : check e2422376604094 [[],[]] .three = true := by decide
def e2422376604126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e2422376604126 : Closed e2422376604126 ∧ code e2422376604126 = 11218469626334 := by decide
theorem cert_e2422376604126 : check e2422376604126 [[],[]] .smaller = true := by decide
def e2422376604150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e2422376604150 : Closed e2422376604150 ∧ code e2422376604150 = 11218469626358 := by decide
theorem cert_e2422376604150 : check e2422376604150 [[],[]] .smaller = true := by decide
def e2422376604154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 4) (.var 0))))))))))
theorem wire_e2422376604154 : Closed e2422376604154 ∧ code e2422376604154 = 11218469626362 := by decide
theorem cert_e2422376604154 : check e2422376604154 [[],[]] .three = true := by decide
def e2422376605102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2422376605102 : Closed e2422376605102 ∧ code e2422376605102 = 11218469627310 := by decide
theorem cert_e2422376605102 : check e2422376605102 [[],[]] .smaller = true := by decide
def e2422376605114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2422376605114 : Closed e2422376605114 ∧ code e2422376605114 = 11218469627322 := by decide
theorem cert_e2422376605114 : check e2422376605114 [[],[]] .smaller = true := by decide
def e2422376605162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2422376605162 : Closed e2422376605162 ∧ code e2422376605162 = 11218469627370 := by decide
theorem cert_e2422376605162 : check e2422376605162 [[],[]] .smaller = true := by decide
def e2422376605246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 4))))))))))
theorem wire_e2422376605246 : Closed e2422376605246 ∧ code e2422376605246 = 11218469627454 := by decide
theorem cert_e2422376605246 : check e2422376605246 [[],[]] .three = true := by decide
def e2422376605294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376605294 : Closed e2422376605294 ∧ code e2422376605294 = 11218469627502 := by decide
theorem cert_e2422376605294 : check e2422376605294 [[],[]] .smaller = true := by decide
def e2422376605306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376605306 : Closed e2422376605306 ∧ code e2422376605306 = 11218469627514 := by decide
theorem cert_e2422376605306 : check e2422376605306 [[],[]] .smaller = true := by decide
def e2422376605470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422376605470 : Closed e2422376605470 ∧ code e2422376605470 = 11218469627678 := by decide
theorem cert_e2422376605470 : check e2422376605470 [[],[]] .smaller = true := by decide
def e2422376605570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422376605570 : Closed e2422376605570 ∧ code e2422376605570 = 11218469627778 := by decide
theorem cert_e2422376605570 : check e2422376605570 [[],[]] .smaller = true := by decide
def e2422376605582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422376605582 : Closed e2422376605582 ∧ code e2422376605582 = 11218469627790 := by decide
theorem cert_e2422376605582 : check e2422376605582 [[],[]] .smaller = true := by decide
def e2422376605594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376605594 : Closed e2422376605594 ∧ code e2422376605594 = 11218469627802 := by decide
theorem cert_e2422376605594 : check e2422376605594 [[],[]] .smaller = true := by decide
def e2422376605638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.lam (.var 1))))))))))
theorem wire_e2422376605638 : Closed e2422376605638 ∧ code e2422376605638 = 11218469627846 := by decide
theorem cert_e2422376605638 : check e2422376605638 [[],[]] .three = true := by decide
def e2422376605662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 3)))))))))
theorem wire_e2422376605662 : Closed e2422376605662 ∧ code e2422376605662 = 11218469627870 := by decide
theorem cert_e2422376605662 : check e2422376605662 [[],[]] .three = true := by decide
def e2422376607870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 5))))))))))
theorem wire_e2422376607870 : Closed e2422376607870 ∧ code e2422376607870 = 11218469630078 := by decide
theorem cert_e2422376607870 : check e2422376607870 [[],[]] .three = true := by decide
def e2422376607966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376607966 : Closed e2422376607966 ∧ code e2422376607966 = 11218469630174 := by decide
theorem cert_e2422376607966 : check e2422376607966 [[],[]] .smaller = true := by decide
def e2422376607994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376607994 : Closed e2422376607994 ∧ code e2422376607994 = 11218469630202 := by decide
theorem cert_e2422376607994 : check e2422376607994 [[],[]] .smaller = true := by decide
def e2422376608542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422376608542 : Closed e2422376608542 ∧ code e2422376608542 = 11218469630750 := by decide
theorem cert_e2422376608542 : check e2422376608542 [[],[]] .smaller = true := by decide
def e2422376608710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422376608710 : Closed e2422376608710 ∧ code e2422376608710 = 11218469630918 := by decide
theorem cert_e2422376608710 : check e2422376608710 [[],[]] .smaller = true := by decide
def e2422376608734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422376608734 : Closed e2422376608734 ∧ code e2422376608734 = 11218469630942 := by decide
theorem cert_e2422376608734 : check e2422376608734 [[],[]] .three = true := by decide
def e2422376608738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422376608738 : Closed e2422376608738 ∧ code e2422376608738 = 11218469630946 := by decide
theorem cert_e2422376608738 : check e2422376608738 [[],[]] .three = true := by decide
def e2422376608750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422376608750 : Closed e2422376608750 ∧ code e2422376608750 = 11218469630958 := by decide
theorem cert_e2422376608750 : check e2422376608750 [[],[]] .three = true := by decide
def e2422376609818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376609818 : Closed e2422376609818 ∧ code e2422376609818 = 11218469632026 := by decide
theorem cert_e2422376609818 : check e2422376609818 [[],[]] .smaller = true := by decide
def e2422376609854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 4))))))))))
theorem wire_e2422376609854 : Closed e2422376609854 ∧ code e2422376609854 = 11218469632062 := by decide
theorem cert_e2422376609854 : check e2422376609854 [[],[]] .smaller = true := by decide
def e2422376609902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376609902 : Closed e2422376609902 ∧ code e2422376609902 = 11218469632110 := by decide
theorem cert_e2422376609902 : check e2422376609902 [[],[]] .smaller = true := by decide
def e2422376609910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422376609910 : Closed e2422376609910 ∧ code e2422376609910 = 11218469632118 := by decide
theorem cert_e2422376609910 : check e2422376609910 [[],[]] .smaller = true := by decide
def e2422376609914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376609914 : Closed e2422376609914 ∧ code e2422376609914 = 11218469632122 := by decide
theorem cert_e2422376609914 : check e2422376609914 [[],[]] .smaller = true := by decide
def e2422376610154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422376610154 : Closed e2422376610154 ∧ code e2422376610154 = 11218469632362 := by decide
theorem cert_e2422376610154 : check e2422376610154 [[],[]] .smaller = true := by decide
def e2422376610178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422376610178 : Closed e2422376610178 ∧ code e2422376610178 = 11218469632386 := by decide
theorem cert_e2422376610178 : check e2422376610178 [[],[]] .smaller = true := by decide
def e2422376610190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422376610190 : Closed e2422376610190 ∧ code e2422376610190 = 11218469632398 := by decide
theorem cert_e2422376610190 : check e2422376610190 [[],[]] .smaller = true := by decide
def e2422376610202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376610202 : Closed e2422376610202 ∧ code e2422376610202 = 11218469632410 := by decide
theorem cert_e2422376610202 : check e2422376610202 [[],[]] .smaller = true := by decide
def e2422376610246 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422376610246 : Closed e2422376610246 ∧ code e2422376610246 = 11218469632454 := by decide
theorem cert_e2422376610246 : check e2422376610246 [[],[]] .smaller = true := by decide
def e2422376610270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422376610270 : Closed e2422376610270 ∧ code e2422376610270 = 11218469632478 := by decide
theorem cert_e2422376610270 : check e2422376610270 [[],[]] .three = true := by decide
def e2422376610274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422376610274 : Closed e2422376610274 ∧ code e2422376610274 = 11218469632482 := by decide
theorem cert_e2422376610274 : check e2422376610274 [[],[]] .smaller = true := by decide
def e2422376610286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422376610286 : Closed e2422376610286 ∧ code e2422376610286 = 11218469632494 := by decide
theorem cert_e2422376610286 : check e2422376610286 [[],[]] .smaller = true := by decide
def e2422376610294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422376610294 : Closed e2422376610294 ∧ code e2422376610294 = 11218469632502 := by decide
theorem cert_e2422376610294 : check e2422376610294 [[],[]] .three = true := by decide
def e2422376610846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.lam (.var 3))))))))))
theorem wire_e2422376610846 : Closed e2422376610846 ∧ code e2422376610846 = 11218469633054 := by decide
theorem cert_e2422376610846 : check e2422376610846 [[],[]] .three = true := by decide
def e2422376610870 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376610870 : Closed e2422376610870 ∧ code e2422376610870 = 11218469633078 := by decide
theorem cert_e2422376610870 : check e2422376610870 [[],[]] .three = true := by decide
def e2422376610874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376610874 : Closed e2422376610874 ∧ code e2422376610874 = 11218469633082 := by decide
theorem cert_e2422376610874 : check e2422376610874 [[],[]] .three = true := by decide
def e2422376611014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422376611014 : Closed e2422376611014 ∧ code e2422376611014 = 11218469633222 := by decide
theorem cert_e2422376611014 : check e2422376611014 [[],[]] .three = true := by decide
def e2422376611038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422376611038 : Closed e2422376611038 ∧ code e2422376611038 = 11218469633246 := by decide
theorem cert_e2422376611038 : check e2422376611038 [[],[]] .three = true := by decide
def e2422376611042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422376611042 : Closed e2422376611042 ∧ code e2422376611042 = 11218469633250 := by decide
theorem cert_e2422376611042 : check e2422376611042 [[],[]] .three = true := by decide
def e2422376611054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422376611054 : Closed e2422376611054 ∧ code e2422376611054 = 11218469633262 := by decide
theorem cert_e2422376611054 : check e2422376611054 [[],[]] .three = true := by decide
def e2422376611062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422376611062 : Closed e2422376611062 ∧ code e2422376611062 = 11218469633270 := by decide
theorem cert_e2422376611062 : check e2422376611062 [[],[]] .three = true := by decide
def e2422376611066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422376611066 : Closed e2422376611066 ∧ code e2422376611066 = 11218469633274 := by decide
theorem cert_e2422376611066 : check e2422376611066 [[],[]] .three = true := by decide
def e2422376612318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 3))))))))
theorem wire_e2422376612318 : Closed e2422376612318 ∧ code e2422376612318 = 11218469634526 := by decide
theorem cert_e2422376612318 : check e2422376612318 [[],[]] .three = true := by decide
def e2422376612346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.lam (.var 5)))) (.var 0))))))))
theorem wire_e2422376612346 : Closed e2422376612346 ∧ code e2422376612346 = 11218469634554 := by decide
theorem cert_e2422376612346 : check e2422376612346 [[],[]] .three = true := by decide
def e2422376612718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e2422376612718 : Closed e2422376612718 ∧ code e2422376612718 = 11218469634926 := by decide
theorem cert_e2422376612718 : check e2422376612718 [[],[]] .smaller = true := by decide
def e2422376612730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))))
theorem wire_e2422376612730 : Closed e2422376612730 ∧ code e2422376612730 = 11218469634938 := by decide
theorem cert_e2422376612730 : check e2422376612730 [[],[]] .smaller = true := by decide
def e2422376612782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e2422376612782 : Closed e2422376612782 ∧ code e2422376612782 = 11218469634990 := by decide
theorem cert_e2422376612782 : check e2422376612782 [[],[]] .smaller = true := by decide
def e2422376612842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))))
theorem wire_e2422376612842 : Closed e2422376612842 ∧ code e2422376612842 = 11218469635050 := by decide
theorem cert_e2422376612842 : check e2422376612842 [[],[]] .smaller = true := by decide
def e2422376613086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422376613086 : Closed e2422376613086 ∧ code e2422376613086 = 11218469635294 := by decide
theorem cert_e2422376613086 : check e2422376613086 [[],[]] .three = true := by decide
def e2422376613114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422376613114 : Closed e2422376613114 ∧ code e2422376613114 = 11218469635322 := by decide
theorem cert_e2422376613114 : check e2422376613114 [[],[]] .three = true := by decide
def e2422376613438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 4)))))))))
theorem wire_e2422376613438 : Closed e2422376613438 ∧ code e2422376613438 = 11218469635646 := by decide
theorem cert_e2422376613438 : check e2422376613438 [[],[]] .three = true := by decide
def e2422376613486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376613486 : Closed e2422376613486 ∧ code e2422376613486 = 11218469635694 := by decide
theorem cert_e2422376613486 : check e2422376613486 [[],[]] .smaller = true := by decide
def e2422376613498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376613498 : Closed e2422376613498 ∧ code e2422376613498 = 11218469635706 := by decide
theorem cert_e2422376613498 : check e2422376613498 [[],[]] .smaller = true := by decide
def e2422376613786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376613786 : Closed e2422376613786 ∧ code e2422376613786 = 11218469635994 := by decide
theorem cert_e2422376613786 : check e2422376613786 [[],[]] .smaller = true := by decide
def e2422376613830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 4))) (.lam (.var 1)))))))))
theorem wire_e2422376613830 : Closed e2422376613830 ∧ code e2422376613830 = 11218469636038 := by decide
theorem cert_e2422376613830 : check e2422376613830 [[],[]] .three = true := by decide
def e2422376615006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 3))))))))
theorem wire_e2422376615006 : Closed e2422376615006 ∧ code e2422376615006 = 11218469637214 := by decide
theorem cert_e2422376615006 : check e2422376615006 [[],[]] .three = true := by decide
def e2422376615022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))))
theorem wire_e2422376615022 : Closed e2422376615022 ∧ code e2422376615022 = 11218469637230 := by decide
theorem cert_e2422376615022 : check e2422376615022 [[],[]] .smaller = true := by decide
def e2422376615034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))))
theorem wire_e2422376615034 : Closed e2422376615034 ∧ code e2422376615034 = 11218469637242 := by decide
theorem cert_e2422376615034 : check e2422376615034 [[],[]] .smaller = true := by decide
def e2422376615198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))))
theorem wire_e2422376615198 : Closed e2422376615198 ∧ code e2422376615198 = 11218469637406 := by decide
theorem cert_e2422376615198 : check e2422376615198 [[],[]] .smaller = true := by decide
def e2422376615366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))))
theorem wire_e2422376615366 : Closed e2422376615366 ∧ code e2422376615366 = 11218469637574 := by decide
theorem cert_e2422376615366 : check e2422376615366 [[],[]] .smaller = true := by decide
def e2422376615390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e2422376615390 : Closed e2422376615390 ∧ code e2422376615390 = 11218469637598 := by decide
theorem cert_e2422376615390 : check e2422376615390 [[],[]] .three = true := by decide
def e2422376615394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.lam (.var 0)))))))))
theorem wire_e2422376615394 : Closed e2422376615394 ∧ code e2422376615394 = 11218469637602 := by decide
theorem cert_e2422376615394 : check e2422376615394 [[],[]] .three = true := by decide
def e2422376615406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e2422376615406 : Closed e2422376615406 ∧ code e2422376615406 = 11218469637614 := by decide
theorem cert_e2422376615406 : check e2422376615406 [[],[]] .three = true := by decide
def e2422376615706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))))
theorem wire_e2422376615706 : Closed e2422376615706 ∧ code e2422376615706 = 11218469637914 := by decide
theorem cert_e2422376615706 : check e2422376615706 [[],[]] .smaller = true := by decide
def e2422376615750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))))
theorem wire_e2422376615750 : Closed e2422376615750 ∧ code e2422376615750 = 11218469637958 := by decide
theorem cert_e2422376615750 : check e2422376615750 [[],[]] .smaller = true := by decide
def e2422376615774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e2422376615774 : Closed e2422376615774 ∧ code e2422376615774 = 11218469637982 := by decide
theorem cert_e2422376615774 : check e2422376615774 [[],[]] .three = true := by decide
def e2422376615802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e2422376615802 : Closed e2422376615802 ∧ code e2422376615802 = 11218469638010 := by decide
theorem cert_e2422376615802 : check e2422376615802 [[],[]] .three = true := by decide
def e2422376615818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422376615818 : Closed e2422376615818 ∧ code e2422376615818 = 11218469638026 := by decide
theorem cert_e2422376615818 : check e2422376615818 [[],[]] .three = true := by decide
def e2422376615842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.lam (.var 0)))))))))
theorem wire_e2422376615842 : Closed e2422376615842 ∧ code e2422376615842 = 11218469638050 := by decide
theorem cert_e2422376615842 : check e2422376615842 [[],[]] .three = true := by decide
def e2422376615854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e2422376615854 : Closed e2422376615854 ∧ code e2422376615854 = 11218469638062 := by decide
theorem cert_e2422376615854 : check e2422376615854 [[],[]] .three = true := by decide
def e2422376615866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e2422376615866 : Closed e2422376615866 ∧ code e2422376615866 = 11218469638074 := by decide
theorem cert_e2422376615866 : check e2422376615866 [[],[]] .three = true := by decide
def e2422376616062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 5))))))))))
theorem wire_e2422376616062 : Closed e2422376616062 ∧ code e2422376616062 = 11218469638270 := by decide
theorem cert_e2422376616062 : check e2422376616062 [[],[]] .three = true := by decide
def e2422376616158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376616158 : Closed e2422376616158 ∧ code e2422376616158 = 11218469638366 := by decide
theorem cert_e2422376616158 : check e2422376616158 [[],[]] .smaller = true := by decide
def e2422376616186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376616186 : Closed e2422376616186 ∧ code e2422376616186 = 11218469638394 := by decide
theorem cert_e2422376616186 : check e2422376616186 [[],[]] .smaller = true := by decide
def e2422376616734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422376616734 : Closed e2422376616734 ∧ code e2422376616734 = 11218469638942 := by decide
theorem cert_e2422376616734 : check e2422376616734 [[],[]] .smaller = true := by decide
def e2422376616902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422376616902 : Closed e2422376616902 ∧ code e2422376616902 = 11218469639110 := by decide
theorem cert_e2422376616902 : check e2422376616902 [[],[]] .smaller = true := by decide
def e2422376616926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422376616926 : Closed e2422376616926 ∧ code e2422376616926 = 11218469639134 := by decide
theorem cert_e2422376616926 : check e2422376616926 [[],[]] .three = true := by decide
def e2422376616930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422376616930 : Closed e2422376616930 ∧ code e2422376616930 = 11218469639138 := by decide
theorem cert_e2422376616930 : check e2422376616930 [[],[]] .three = true := by decide
def e2422376616942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422376616942 : Closed e2422376616942 ∧ code e2422376616942 = 11218469639150 := by decide
theorem cert_e2422376616942 : check e2422376616942 [[],[]] .three = true := by decide
def e2422376619062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376619062 : Closed e2422376619062 ∧ code e2422376619062 = 11218469641270 := by decide
theorem cert_e2422376619062 : check e2422376619062 [[],[]] .smaller = true := by decide
def e2422376619066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376619066 : Closed e2422376619066 ∧ code e2422376619066 = 11218469641274 := by decide
theorem cert_e2422376619066 : check e2422376619066 [[],[]] .smaller = true := by decide
def e2422376619206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422376619206 : Closed e2422376619206 ∧ code e2422376619206 = 11218469641414 := by decide
theorem cert_e2422376619206 : check e2422376619206 [[],[]] .smaller = true := by decide
def e2422376619230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422376619230 : Closed e2422376619230 ∧ code e2422376619230 = 11218469641438 := by decide
theorem cert_e2422376619230 : check e2422376619230 [[],[]] .three = true := by decide
def e2422376619258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422376619258 : Closed e2422376619258 ∧ code e2422376619258 = 11218469641466 := by decide
theorem cert_e2422376619258 : check e2422376619258 [[],[]] .three = true := by decide
def e2422376619534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.lam (.lam (.var 2))))))))))
theorem wire_e2422376619534 : Closed e2422376619534 ∧ code e2422376619534 = 11218469641742 := by decide
theorem cert_e2422376619534 : check e2422376619534 [[],[]] .three = true := by decide
def e2422376619618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422376619618 : Closed e2422376619618 ∧ code e2422376619618 = 11218469641826 := by decide
theorem cert_e2422376619618 : check e2422376619618 [[],[]] .three = true := by decide
def e2422376619630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376619630 : Closed e2422376619630 ∧ code e2422376619630 = 11218469641838 := by decide
theorem cert_e2422376619630 : check e2422376619630 [[],[]] .three = true := by decide
def e2422376619642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376619642 : Closed e2422376619642 ∧ code e2422376619642 = 11218469641850 := by decide
theorem cert_e2422376619642 : check e2422376619642 [[],[]] .three = true := by decide
def e2422376620138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.var 0))))))))
theorem wire_e2422376620138 : Closed e2422376620138 ∧ code e2422376620138 = 11218469642346 := by decide
theorem cert_e2422376620138 : check e2422376620138 [[],[]] .smaller = true := by decide
def e2422376620186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376620186 : Closed e2422376620186 ∧ code e2422376620186 = 11218469642394 := by decide
theorem cert_e2422376620186 : check e2422376620186 [[],[]] .smaller = true := by decide
def e2422376620270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 2))))))))
theorem wire_e2422376620270 : Closed e2422376620270 ∧ code e2422376620270 = 11218469642478 := by decide
theorem cert_e2422376620270 : check e2422376620270 [[],[]] .smaller = true := by decide
def e2422376620282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.var 0))))))))
theorem wire_e2422376620282 : Closed e2422376620282 ∧ code e2422376620282 = 11218469642490 := by decide
theorem cert_e2422376620282 : check e2422376620282 [[],[]] .smaller = true := by decide
def e2422376620470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))))
theorem wire_e2422376620470 : Closed e2422376620470 ∧ code e2422376620470 = 11218469642678 := by decide
theorem cert_e2422376620470 : check e2422376620470 [[],[]] .smaller = true := by decide
def e2422376620474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e2422376620474 : Closed e2422376620474 ∧ code e2422376620474 = 11218469642682 := by decide
theorem cert_e2422376620474 : check e2422376620474 [[],[]] .smaller = true := by decide
def e2422376620502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))))
theorem wire_e2422376620502 : Closed e2422376620502 ∧ code e2422376620502 = 11218469642710 := by decide
theorem cert_e2422376620502 : check e2422376620502 [[],[]] .smaller = true := by decide
def e2422376620506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 0))))))))
theorem wire_e2422376620506 : Closed e2422376620506 ∧ code e2422376620506 = 11218469642714 := by decide
theorem cert_e2422376620506 : check e2422376620506 [[],[]] .smaller = true := by decide
def e2422376620522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e2422376620522 : Closed e2422376620522 ∧ code e2422376620522 = 11218469642730 := by decide
theorem cert_e2422376620522 : check e2422376620522 [[],[]] .smaller = true := by decide
def e2422376620654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422376620654 : Closed e2422376620654 ∧ code e2422376620654 = 11218469642862 := by decide
theorem cert_e2422376620654 : check e2422376620654 [[],[]] .smaller = true := by decide
def e2422376620666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422376620666 : Closed e2422376620666 ∧ code e2422376620666 = 11218469642874 := by decide
theorem cert_e2422376620666 : check e2422376620666 [[],[]] .smaller = true := by decide
def e2422376620830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 3)))))))))
theorem wire_e2422376620830 : Closed e2422376620830 ∧ code e2422376620830 = 11218469643038 := by decide
theorem cert_e2422376620830 : check e2422376620830 [[],[]] .smaller = true := by decide
def e2422376620854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422376620854 : Closed e2422376620854 ∧ code e2422376620854 = 11218469643062 := by decide
theorem cert_e2422376620854 : check e2422376620854 [[],[]] .smaller = true := by decide
def e2422376620858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422376620858 : Closed e2422376620858 ∧ code e2422376620858 = 11218469643066 := by decide
theorem cert_e2422376620858 : check e2422376620858 [[],[]] .smaller = true := by decide
def e2422376620954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422376620954 : Closed e2422376620954 ∧ code e2422376620954 = 11218469643162 := by decide
theorem cert_e2422376620954 : check e2422376620954 [[],[]] .smaller = true := by decide
def e2422376620998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.lam (.var 1)))))))))
theorem wire_e2422376620998 : Closed e2422376620998 ∧ code e2422376620998 = 11218469643206 := by decide
theorem cert_e2422376620998 : check e2422376620998 [[],[]] .smaller = true := by decide
def e2422376621022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 3))) (.var 3))))))))
theorem wire_e2422376621022 : Closed e2422376621022 ∧ code e2422376621022 = 11218469643230 := by decide
theorem cert_e2422376621022 : check e2422376621022 [[],[]] .three = true := by decide
def e2422376621038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 4))) (.var 2))))))))
theorem wire_e2422376621038 : Closed e2422376621038 ∧ code e2422376621038 = 11218469643246 := by decide
theorem cert_e2422376621038 : check e2422376621038 [[],[]] .three = true := by decide
end Blc.Floor43
