import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392357003802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357003802 : Closed e2392357003802 ∧ code e2392357003802 = 11188450026010 := by decide
private def t_e2392357003802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357003802 : ¬ IsSelfInterpreter e2392357003802 :=
  wSource (t := t_e2392357003802) (replay_sound (ps := []) (t := e2392357003802) (by decide)) (by decide)
def e2392357005338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392357005338 : Closed e2392357005338 ∧ code e2392357005338 = 11188450027546 := by decide
theorem cert_e2392357005338 : check e2392357005338 [[]] .width = true := by decide
def e2392357006874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357006874 : Closed e2392357006874 ∧ code e2392357006874 = 11188450029082 := by decide
private def t_e2392357006874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357006874 : ¬ IsSelfInterpreter e2392357006874 :=
  wSource (t := t_e2392357006874) (replay_sound (ps := []) (t := e2392357006874) (by decide)) (by decide)
def e2392357046810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357046810 : Closed e2392357046810 ∧ code e2392357046810 = 11188450069018 := by decide
private def t_e2392357046810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357046810 : ¬ IsSelfInterpreter e2392357046810 :=
  wSource (t := t_e2392357046810) (replay_sound (ps := []) (t := e2392357046810) (by decide)) (by decide)
def e2392357052954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357052954 : Closed e2392357052954 ∧ code e2392357052954 = 11188450075162 := by decide
private def t_e2392357052954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357052954 : ¬ IsSelfInterpreter e2392357052954 :=
  wSource (t := t_e2392357052954) (replay_sound (ps := []) (t := e2392357052954) (by decide)) (by decide)
def e2392357054490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392357054490 : Closed e2392357054490 ∧ code e2392357054490 = 11188450076698 := by decide
theorem cert_e2392357054490 : check e2392357054490 [[]] .width = true := by decide
def e2392357056026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357056026 : Closed e2392357056026 ∧ code e2392357056026 = 11188450078234 := by decide
private def t_e2392357056026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357056026 : ¬ IsSelfInterpreter e2392357056026 :=
  wSource (t := t_e2392357056026) (replay_sound (ps := []) (t := e2392357056026) (by decide)) (by decide)
def e2392357059098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357059098 : Closed e2392357059098 ∧ code e2392357059098 = 11188450081306 := by decide
private def t_e2392357059098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357059098 : ¬ IsSelfInterpreter e2392357059098 :=
  wSource (t := t_e2392357059098) (replay_sound (ps := []) (t := e2392357059098) (by decide)) (by decide)
def e2392357092890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357092890 : Closed e2392357092890 ∧ code e2392357092890 = 11188450115098 := by decide
private def t_e2392357092890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357092890 : ¬ IsSelfInterpreter e2392357092890 :=
  wSource (t := t_e2392357092890) (replay_sound (ps := []) (t := e2392357092890) (by decide)) (by decide)
def e2392357138630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392357138630 : Closed e2392357138630 ∧ code e2392357138630 = 11188450160838 := by decide
theorem cert_e2392357138630 : check e2392357138630 [[]] .width = true := by decide
def e2392357189658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392357189658 : Closed e2392357189658 ∧ code e2392357189658 = 11188450211866 := by decide
theorem cert_e2392357189658 : check e2392357189658 [[]] .width = true := by decide
def e2392357200410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357200410 : Closed e2392357200410 ∧ code e2392357200410 = 11188450222618 := by decide
private def t_e2392357200410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357200410 : ¬ IsSelfInterpreter e2392357200410 :=
  wSource (t := t_e2392357200410) (replay_sound (ps := []) (t := e2392357200410) (by decide)) (by decide)
def e2392357201946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392357201946 : Closed e2392357201946 ∧ code e2392357201946 = 11188450224154 := by decide
theorem cert_e2392357201946 : check e2392357201946 [[]] .width = true := by decide
def e2392357203482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357203482 : Closed e2392357203482 ∧ code e2392357203482 = 11188450225690 := by decide
private def t_e2392357203482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357203482 : ¬ IsSelfInterpreter e2392357203482 :=
  wSource (t := t_e2392357203482) (replay_sound (ps := []) (t := e2392357203482) (by decide)) (by decide)
def e2392357306394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392357306394 : Closed e2392357306394 ∧ code e2392357306394 = 11188450328602 := by decide
theorem cert_e2392357306394 : check e2392357306394 [[]] .width = true := by decide
def e2392357306486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392357306486 : Closed e2392357306486 ∧ code e2392357306486 = 11188450328694 := by decide
theorem cert_e2392357306486 : check e2392357306486 [[]] .width = true := by decide
def e2392357306730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392357306730 : Closed e2392357306730 ∧ code e2392357306730 = 11188450328938 := by decide
theorem cert_e2392357306730 : check e2392357306730 [[]] .width = true := by decide
def e2392357306778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392357306778 : Closed e2392357306778 ∧ code e2392357306778 = 11188450328986 := by decide
theorem cert_e2392357306778 : check e2392357306778 [[]] .width = true := by decide
def e2392357307786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392357307786 : Closed e2392357307786 ∧ code e2392357307786 = 11188450329994 := by decide
theorem cert_e2392357307786 : check e2392357307786 [[]] .width = true := by decide
def e2392357307810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392357307810 : Closed e2392357307810 ∧ code e2392357307810 = 11188450330018 := by decide
private def t_e2392357307810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392357307810 : ¬ IsSelfInterpreter e2392357307810 :=
  wSource (t := t_e2392357307810) (replay_sound (ps := []) (t := e2392357307810) (by decide)) (by decide)
def e2392357307918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392357307918 : Closed e2392357307918 ∧ code e2392357307918 = 11188450330126 := by decide
theorem cert_e2392357307918 : check e2392357307918 [[]] .width = true := by decide
def e2392357307930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392357307930 : Closed e2392357307930 ∧ code e2392357307930 = 11188450330138 := by decide
private def t_e2392357307930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392357307930 : ¬ IsSelfInterpreter e2392357307930 :=
  wSource (t := t_e2392357307930) (replay_sound (ps := []) (t := e2392357307930) (by decide)) (by decide)
def e2392357308002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392357308002 : Closed e2392357308002 ∧ code e2392357308002 = 11188450330210 := by decide
theorem cert_e2392357308002 : check e2392357308002 [[]] .width = true := by decide
def e2392357473818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357473818 : Closed e2392357473818 ∧ code e2392357473818 = 11188450496026 := by decide
private def t_e2392357473818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357473818 : ¬ IsSelfInterpreter e2392357473818 :=
  wSource (t := t_e2392357473818) (replay_sound (ps := []) (t := e2392357473818) (by decide)) (by decide)
def e2392357482694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392357482694 : Closed e2392357482694 ∧ code e2392357482694 = 11188450504902 := by decide
theorem cert_e2392357482694 : check e2392357482694 [[]] .width = true := by decide
def e2392357495322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357495322 : Closed e2392357495322 ∧ code e2392357495322 = 11188450517530 := by decide
private def t_e2392357495322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357495322 : ¬ IsSelfInterpreter e2392357495322 :=
  wSource (t := t_e2392357495322) (replay_sound (ps := []) (t := e2392357495322) (by decide)) (by decide)
def e2392357496858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392357496858 : Closed e2392357496858 ∧ code e2392357496858 = 11188450519066 := by decide
theorem cert_e2392357496858 : check e2392357496858 [[]] .width = true := by decide
def e2392357498394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357498394 : Closed e2392357498394 ∧ code e2392357498394 = 11188450520602 := by decide
private def t_e2392357498394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357498394 : ¬ IsSelfInterpreter e2392357498394 :=
  wSource (t := t_e2392357498394) (replay_sound (ps := []) (t := e2392357498394) (by decide)) (by decide)
def e2392357501466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392357501466 : Closed e2392357501466 ∧ code e2392357501466 = 11188450523674 := by decide
private def t_e2392357501466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392357501466 : ¬ IsSelfInterpreter e2392357501466 :=
  wSource (t := t_e2392357501466) (replay_sound (ps := []) (t := e2392357501466) (by decide)) (by decide)
def e2392357503002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392357503002 : Closed e2392357503002 ∧ code e2392357503002 = 11188450525210 := by decide
theorem cert_e2392357503002 : check e2392357503002 [[]] .width = true := by decide
def e2392357503094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392357503094 : Closed e2392357503094 ∧ code e2392357503094 = 11188450525302 := by decide
theorem cert_e2392357503094 : check e2392357503094 [[]] .width = true := by decide
def e2392357503338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392357503338 : Closed e2392357503338 ∧ code e2392357503338 = 11188450525546 := by decide
theorem cert_e2392357503338 : check e2392357503338 [[]] .width = true := by decide
def e2392357503386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392357503386 : Closed e2392357503386 ∧ code e2392357503386 = 11188450525594 := by decide
theorem cert_e2392357503386 : check e2392357503386 [[]] .width = true := by decide
def e2392357504394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392357504394 : Closed e2392357504394 ∧ code e2392357504394 = 11188450526602 := by decide
theorem cert_e2392357504394 : check e2392357504394 [[]] .width = true := by decide
def e2392357504418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392357504418 : Closed e2392357504418 ∧ code e2392357504418 = 11188450526626 := by decide
private def t_e2392357504418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392357504418 : ¬ IsSelfInterpreter e2392357504418 :=
  wSource (t := t_e2392357504418) (replay_sound (ps := []) (t := e2392357504418) (by decide)) (by decide)
def e2392357504526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392357504526 : Closed e2392357504526 ∧ code e2392357504526 = 11188450526734 := by decide
theorem cert_e2392357504526 : check e2392357504526 [[]] .width = true := by decide
def e2392357504538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392357504538 : Closed e2392357504538 ∧ code e2392357504538 = 11188450526746 := by decide
private def t_e2392357504538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392357504538 : ¬ IsSelfInterpreter e2392357504538 :=
  wSource (t := t_e2392357504538) (replay_sound (ps := []) (t := e2392357504538) (by decide)) (by decide)
def e2392357504610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392357504610 : Closed e2392357504610 ∧ code e2392357504610 = 11188450526818 := by decide
theorem cert_e2392357504610 : check e2392357504610 [[]] .width = true := by decide
def e2392359942170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392359942170 : Closed e2392359942170 ∧ code e2392359942170 = 11188452964378 := by decide
theorem cert_e2392359942170 : check e2392359942170 [[]] .width = true := by decide
def e2392359950362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392359950362 : Closed e2392359950362 ∧ code e2392359950362 = 11188452972570 := by decide
theorem cert_e2392359950362 : check e2392359950362 [[]] .width = true := by decide
def e2392360424986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360424986 : Closed e2392360424986 ∧ code e2392360424986 = 11188453447194 := by decide
private def t_e2392360424986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360424986 : ¬ IsSelfInterpreter e2392360424986 :=
  wSource (t := t_e2392360424986) (replay_sound (ps := []) (t := e2392360424986) (by decide)) (by decide)
def e2392360441882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392360441882 : Closed e2392360441882 ∧ code e2392360441882 = 11188453464090 := by decide
theorem cert_e2392360441882 : check e2392360441882 [[]] .width = true := by decide
def e2392360444442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360444442 : Closed e2392360444442 ∧ code e2392360444442 = 11188453466650 := by decide
private def t_e2392360444442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360444442 : ¬ IsSelfInterpreter e2392360444442 :=
  wSource (t := t_e2392360444442) (replay_sound (ps := []) (t := e2392360444442) (by decide)) (by decide)
def e2392360445978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392360445978 : Closed e2392360445978 ∧ code e2392360445978 = 11188453468186 := by decide
theorem cert_e2392360445978 : check e2392360445978 [[]] .width = true := by decide
def e2392360447514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360447514 : Closed e2392360447514 ∧ code e2392360447514 = 11188453469722 := by decide
private def t_e2392360447514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360447514 : ¬ IsSelfInterpreter e2392360447514 :=
  wSource (t := t_e2392360447514) (replay_sound (ps := []) (t := e2392360447514) (by decide)) (by decide)
def e2392360449562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360449562 : Closed e2392360449562 ∧ code e2392360449562 = 11188453471770 := by decide
private def t_e2392360449562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360449562 : ¬ IsSelfInterpreter e2392360449562 :=
  wSource (t := t_e2392360449562) (replay_sound (ps := []) (t := e2392360449562) (by decide)) (by decide)
def e2392360454682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360454682 : Closed e2392360454682 ∧ code e2392360454682 = 11188453476890 := by decide
private def t_e2392360454682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360454682 : ¬ IsSelfInterpreter e2392360454682 :=
  wSource (t := t_e2392360454682) (replay_sound (ps := []) (t := e2392360454682) (by decide)) (by decide)
def e2392360460826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360460826 : Closed e2392360460826 ∧ code e2392360460826 = 11188453483034 := by decide
private def t_e2392360460826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360460826 : ¬ IsSelfInterpreter e2392360460826 :=
  wSource (t := t_e2392360460826) (replay_sound (ps := []) (t := e2392360460826) (by decide)) (by decide)
def e2392360462362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392360462362 : Closed e2392360462362 ∧ code e2392360462362 = 11188453484570 := by decide
theorem cert_e2392360462362 : check e2392360462362 [[]] .width = true := by decide
def e2392360463898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360463898 : Closed e2392360463898 ∧ code e2392360463898 = 11188453486106 := by decide
private def t_e2392360463898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360463898 : ¬ IsSelfInterpreter e2392360463898 :=
  wSource (t := t_e2392360463898) (replay_sound (ps := []) (t := e2392360463898) (by decide)) (by decide)
def e2392360466970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360466970 : Closed e2392360466970 ∧ code e2392360466970 = 11188453489178 := by decide
private def t_e2392360466970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360466970 : ¬ IsSelfInterpreter e2392360466970 :=
  wSource (t := t_e2392360466970) (replay_sound (ps := []) (t := e2392360466970) (by decide)) (by decide)
def e2392360474138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360474138 : Closed e2392360474138 ∧ code e2392360474138 = 11188453496346 := by decide
private def t_e2392360474138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360474138 : ¬ IsSelfInterpreter e2392360474138 :=
  wSource (t := t_e2392360474138) (replay_sound (ps := []) (t := e2392360474138) (by decide)) (by decide)
def e2392360475162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360475162 : Closed e2392360475162 ∧ code e2392360475162 = 11188453497370 := by decide
private def t_e2392360475162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360475162 : ¬ IsSelfInterpreter e2392360475162 :=
  wSource (t := t_e2392360475162) (replay_sound (ps := []) (t := e2392360475162) (by decide)) (by decide)
def e2392360492570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360492570 : Closed e2392360492570 ∧ code e2392360492570 = 11188453514778 := by decide
private def t_e2392360492570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360492570 : ¬ IsSelfInterpreter e2392360492570 :=
  wSource (t := t_e2392360492570) (replay_sound (ps := []) (t := e2392360492570) (by decide)) (by decide)
def e2392360513734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392360513734 : Closed e2392360513734 ∧ code e2392360513734 = 11188453535942 := by decide
theorem cert_e2392360513734 : check e2392360513734 [[]] .width = true := by decide
def e2392360540186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392360540186 : Closed e2392360540186 ∧ code e2392360540186 = 11188453562394 := by decide
theorem cert_e2392360540186 : check e2392360540186 [[]] .width = true := by decide
def e2392360542746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360542746 : Closed e2392360542746 ∧ code e2392360542746 = 11188453564954 := by decide
private def t_e2392360542746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360542746 : ¬ IsSelfInterpreter e2392360542746 :=
  wSource (t := t_e2392360542746) (replay_sound (ps := []) (t := e2392360542746) (by decide)) (by decide)
def e2392360544282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392360544282 : Closed e2392360544282 ∧ code e2392360544282 = 11188453566490 := by decide
theorem cert_e2392360544282 : check e2392360544282 [[]] .width = true := by decide
def e2392360545818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360545818 : Closed e2392360545818 ∧ code e2392360545818 = 11188453568026 := by decide
private def t_e2392360545818 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360545818 : ¬ IsSelfInterpreter e2392360545818 :=
  wSource (t := t_e2392360545818) (replay_sound (ps := []) (t := e2392360545818) (by decide)) (by decide)
def e2392360547866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360547866 : Closed e2392360547866 ∧ code e2392360547866 = 11188453570074 := by decide
private def t_e2392360547866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360547866 : ¬ IsSelfInterpreter e2392360547866 :=
  wSource (t := t_e2392360547866) (replay_sound (ps := []) (t := e2392360547866) (by decide)) (by decide)
def e2392360583194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392360583194 : Closed e2392360583194 ∧ code e2392360583194 = 11188453605402 := by decide
theorem cert_e2392360583194 : check e2392360583194 [[]] .width = true := by decide
def e2392360583286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392360583286 : Closed e2392360583286 ∧ code e2392360583286 = 11188453605494 := by decide
theorem cert_e2392360583286 : check e2392360583286 [[]] .width = true := by decide
def e2392360583530 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392360583530 : Closed e2392360583530 ∧ code e2392360583530 = 11188453605738 := by decide
theorem cert_e2392360583530 : check e2392360583530 [[]] .width = true := by decide
def e2392360583578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392360583578 : Closed e2392360583578 ∧ code e2392360583578 = 11188453605786 := by decide
theorem cert_e2392360583578 : check e2392360583578 [[]] .width = true := by decide
def e2392360584586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392360584586 : Closed e2392360584586 ∧ code e2392360584586 = 11188453606794 := by decide
theorem cert_e2392360584586 : check e2392360584586 [[]] .width = true := by decide
def e2392360584610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392360584610 : Closed e2392360584610 ∧ code e2392360584610 = 11188453606818 := by decide
private def t_e2392360584610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392360584610 : ¬ IsSelfInterpreter e2392360584610 :=
  wSource (t := t_e2392360584610) (replay_sound (ps := []) (t := e2392360584610) (by decide)) (by decide)
def e2392360584718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392360584718 : Closed e2392360584718 ∧ code e2392360584718 = 11188453606926 := by decide
theorem cert_e2392360584718 : check e2392360584718 [[]] .width = true := by decide
def e2392360584730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392360584730 : Closed e2392360584730 ∧ code e2392360584730 = 11188453606938 := by decide
private def t_e2392360584730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392360584730 : ¬ IsSelfInterpreter e2392360584730 :=
  wSource (t := t_e2392360584730) (replay_sound (ps := []) (t := e2392360584730) (by decide)) (by decide)
def e2392360584802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392360584802 : Closed e2392360584802 ∧ code e2392360584802 = 11188453607010 := by decide
theorem cert_e2392360584802 : check e2392360584802 [[]] .width = true := by decide
def e2392360619546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360619546 : Closed e2392360619546 ∧ code e2392360619546 = 11188453641754 := by decide
private def t_e2392360619546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360619546 : ¬ IsSelfInterpreter e2392360619546 :=
  wSource (t := t_e2392360619546) (replay_sound (ps := []) (t := e2392360619546) (by decide)) (by decide)
def e2392360628422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392360628422 : Closed e2392360628422 ∧ code e2392360628422 = 11188453650630 := by decide
theorem cert_e2392360628422 : check e2392360628422 [[]] .width = true := by decide
def e2392360641050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360641050 : Closed e2392360641050 ∧ code e2392360641050 = 11188453663258 := by decide
private def t_e2392360641050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360641050 : ¬ IsSelfInterpreter e2392360641050 :=
  wSource (t := t_e2392360641050) (replay_sound (ps := []) (t := e2392360641050) (by decide)) (by decide)
def e2392360642586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392360642586 : Closed e2392360642586 ∧ code e2392360642586 = 11188453664794 := by decide
theorem cert_e2392360642586 : check e2392360642586 [[]] .width = true := by decide
def e2392360644122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360644122 : Closed e2392360644122 ∧ code e2392360644122 = 11188453666330 := by decide
private def t_e2392360644122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360644122 : ¬ IsSelfInterpreter e2392360644122 :=
  wSource (t := t_e2392360644122) (replay_sound (ps := []) (t := e2392360644122) (by decide)) (by decide)
def e2392360647194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360647194 : Closed e2392360647194 ∧ code e2392360647194 = 11188453669402 := by decide
private def t_e2392360647194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360647194 : ¬ IsSelfInterpreter e2392360647194 :=
  wSource (t := t_e2392360647194) (replay_sound (ps := []) (t := e2392360647194) (by decide)) (by decide)
def e2392360648730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392360648730 : Closed e2392360648730 ∧ code e2392360648730 = 11188453670938 := by decide
theorem cert_e2392360648730 : check e2392360648730 [[]] .width = true := by decide
def e2392360648822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392360648822 : Closed e2392360648822 ∧ code e2392360648822 = 11188453671030 := by decide
theorem cert_e2392360648822 : check e2392360648822 [[]] .width = true := by decide
def e2392360649066 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392360649066 : Closed e2392360649066 ∧ code e2392360649066 = 11188453671274 := by decide
theorem cert_e2392360649066 : check e2392360649066 [[]] .width = true := by decide
def e2392360649114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392360649114 : Closed e2392360649114 ∧ code e2392360649114 = 11188453671322 := by decide
theorem cert_e2392360649114 : check e2392360649114 [[]] .width = true := by decide
def e2392360650122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392360650122 : Closed e2392360650122 ∧ code e2392360650122 = 11188453672330 := by decide
theorem cert_e2392360650122 : check e2392360650122 [[]] .width = true := by decide
def e2392360650146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392360650146 : Closed e2392360650146 ∧ code e2392360650146 = 11188453672354 := by decide
private def t_e2392360650146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392360650146 : ¬ IsSelfInterpreter e2392360650146 :=
  wSource (t := t_e2392360650146) (replay_sound (ps := []) (t := e2392360650146) (by decide)) (by decide)
def e2392360650254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392360650254 : Closed e2392360650254 ∧ code e2392360650254 = 11188453672462 := by decide
theorem cert_e2392360650254 : check e2392360650254 [[]] .width = true := by decide
def e2392360650266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392360650266 : Closed e2392360650266 ∧ code e2392360650266 = 11188453672474 := by decide
private def t_e2392360650266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392360650266 : ¬ IsSelfInterpreter e2392360650266 :=
  wSource (t := t_e2392360650266) (replay_sound (ps := []) (t := e2392360650266) (by decide)) (by decide)
def e2392360650338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392360650338 : Closed e2392360650338 ∧ code e2392360650338 = 11188453672546 := by decide
theorem cert_e2392360650338 : check e2392360650338 [[]] .width = true := by decide
def e2392360695322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360695322 : Closed e2392360695322 ∧ code e2392360695322 = 11188453717530 := by decide
private def t_e2392360695322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360695322 : ¬ IsSelfInterpreter e2392360695322 :=
  wSource (t := t_e2392360695322) (replay_sound (ps := []) (t := e2392360695322) (by decide)) (by decide)
def e2392360696346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392360696346 : Closed e2392360696346 ∧ code e2392360696346 = 11188453718554 := by decide
private def t_e2392360696346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392360696346 : ¬ IsSelfInterpreter e2392360696346 :=
  wSource (t := t_e2392360696346) (replay_sound (ps := []) (t := e2392360696346) (by decide)) (by decide)
def e2392363937134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2392363937134 : Closed e2392363937134 ∧ code e2392363937134 = 11188456959342 := by decide
theorem cert_e2392363937134 : check e2392363937134 [[],[.left]] .smaller = true := by decide
def e2392363937142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2392363937142 : Closed e2392363937142 ∧ code e2392363937142 = 11188456959350 := by decide
theorem cert_e2392363937142 : check e2392363937142 [[],[.left]] .smaller = true := by decide
def e2392363937198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2392363937198 : Closed e2392363937198 ∧ code e2392363937198 = 11188456959406 := by decide
theorem cert_e2392363937198 : check e2392363937198 [[],[.left]] .smaller = true := by decide
def e2392363937210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2392363937210 : Closed e2392363937210 ∧ code e2392363937210 = 11188456959418 := by decide
theorem cert_e2392363937210 : check e2392363937210 [[],[.left]] .smaller = true := by decide
def e2392363937238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2392363937238 : Closed e2392363937238 ∧ code e2392363937238 = 11188456959446 := by decide
theorem cert_e2392363937238 : check e2392363937238 [[],[.left]] .smaller = true := by decide
def e2392363937242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2392363937242 : Closed e2392363937242 ∧ code e2392363937242 = 11188456959450 := by decide
theorem cert_e2392363937242 : check e2392363937242 [[],[.left]] .smaller = true := by decide
def e2392363937454 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2392363937454 : Closed e2392363937454 ∧ code e2392363937454 = 11188456959662 := by decide
theorem cert_e2392363937454 : check e2392363937454 [[],[.left]] .smaller = true := by decide
def e2392363937466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2392363937466 : Closed e2392363937466 ∧ code e2392363937466 = 11188456959674 := by decide
theorem cert_e2392363937466 : check e2392363937466 [[],[.left]] .smaller = true := by decide
def e2392363937514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2392363937514 : Closed e2392363937514 ∧ code e2392363937514 = 11188456959722 := by decide
theorem cert_e2392363937514 : check e2392363937514 [[],[.left]] .smaller = true := by decide
def e2392363937622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2392363937622 : Closed e2392363937622 ∧ code e2392363937622 = 11188456959830 := by decide
theorem cert_e2392363937622 : check e2392363937622 [[],[.left]] .smaller = true := by decide
def e2392363937626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2392363937626 : Closed e2392363937626 ∧ code e2392363937626 = 11188456959834 := by decide
theorem cert_e2392363937626 : check e2392363937626 [[],[.left]] .smaller = true := by decide
def e2392363937642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2392363937642 : Closed e2392363937642 ∧ code e2392363937642 = 11188456959850 := by decide
theorem cert_e2392363937642 : check e2392363937642 [[],[.left]] .smaller = true := by decide
def e2392363938670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2392363938670 : Closed e2392363938670 ∧ code e2392363938670 = 11188456960878 := by decide
theorem cert_e2392363938670 : check e2392363938670 [[],[.left]] .smaller = true := by decide
def e2392363938678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2392363938678 : Closed e2392363938678 ∧ code e2392363938678 = 11188456960886 := by decide
theorem cert_e2392363938678 : check e2392363938678 [[],[.left]] .smaller = true := by decide
def e2392363938734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2392363938734 : Closed e2392363938734 ∧ code e2392363938734 = 11188456960942 := by decide
theorem cert_e2392363938734 : check e2392363938734 [[],[.left]] .smaller = true := by decide
def e2392363938746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2392363938746 : Closed e2392363938746 ∧ code e2392363938746 = 11188456960954 := by decide
theorem cert_e2392363938746 : check e2392363938746 [[],[.left]] .smaller = true := by decide
def e2392363938774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2392363938774 : Closed e2392363938774 ∧ code e2392363938774 = 11188456960982 := by decide
theorem cert_e2392363938774 : check e2392363938774 [[],[.left]] .smaller = true := by decide
def e2392363938778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2392363938778 : Closed e2392363938778 ∧ code e2392363938778 = 11188456960986 := by decide
theorem cert_e2392363938778 : check e2392363938778 [[],[.left]] .smaller = true := by decide
def e2392363939054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2392363939054 : Closed e2392363939054 ∧ code e2392363939054 = 11188456961262 := by decide
theorem cert_e2392363939054 : check e2392363939054 [[],[.left]] .smaller = true := by decide
def e2392363939062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2392363939062 : Closed e2392363939062 ∧ code e2392363939062 = 11188456961270 := by decide
theorem cert_e2392363939062 : check e2392363939062 [[],[.left]] .smaller = true := by decide
def e2392363939438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392363939438 : Closed e2392363939438 ∧ code e2392363939438 = 11188456961646 := by decide
theorem cert_e2392363939438 : check e2392363939438 [[],[.left]] .smaller = true := by decide
def e2392363939450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392363939450 : Closed e2392363939450 ∧ code e2392363939450 = 11188456961658 := by decide
theorem cert_e2392363939450 : check e2392363939450 [[],[.left]] .smaller = true := by decide
def e2392363939638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392363939638 : Closed e2392363939638 ∧ code e2392363939638 = 11188456961846 := by decide
theorem cert_e2392363939638 : check e2392363939638 [[],[.left]] .smaller = true := by decide
def e2392363939642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392363939642 : Closed e2392363939642 ∧ code e2392363939642 = 11188456961850 := by decide
theorem cert_e2392363939642 : check e2392363939642 [[],[.left]] .smaller = true := by decide
def e2392363940270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2392363940270 : Closed e2392363940270 ∧ code e2392363940270 = 11188456962478 := by decide
theorem cert_e2392363940270 : check e2392363940270 [[],[.left]] .smaller = true := by decide
def e2392363940282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2392363940282 : Closed e2392363940282 ∧ code e2392363940282 = 11188456962490 := by decide
theorem cert_e2392363940282 : check e2392363940282 [[],[.left]] .smaller = true := by decide
def e2392363940330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2392363940330 : Closed e2392363940330 ∧ code e2392363940330 = 11188456962538 := by decide
theorem cert_e2392363940330 : check e2392363940330 [[],[.left]] .smaller = true := by decide
def e2392363940462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2392363940462 : Closed e2392363940462 ∧ code e2392363940462 = 11188456962670 := by decide
theorem cert_e2392363940462 : check e2392363940462 [[],[.left]] .smaller = true := by decide
def e2392363940474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2392363940474 : Closed e2392363940474 ∧ code e2392363940474 = 11188456962682 := by decide
theorem cert_e2392363940474 : check e2392363940474 [[],[.left]] .smaller = true := by decide
def e2392363940762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392363940762 : Closed e2392363940762 ∧ code e2392363940762 = 11188456962970 := by decide
theorem cert_e2392363940762 : check e2392363940762 [[],[.left]] .smaller = true := by decide
def e2392363941078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2392363941078 : Closed e2392363941078 ∧ code e2392363941078 = 11188456963286 := by decide
theorem cert_e2392363941078 : check e2392363941078 [[],[.left]] .smaller = true := by decide
def e2392363941082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2392363941082 : Closed e2392363941082 ∧ code e2392363941082 = 11188456963290 := by decide
theorem cert_e2392363941082 : check e2392363941082 [[],[.left]] .smaller = true := by decide
def e2392363941098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2392363941098 : Closed e2392363941098 ∧ code e2392363941098 = 11188456963306 := by decide
theorem cert_e2392363941098 : check e2392363941098 [[],[.left]] .smaller = true := by decide
def e2392363941174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2392363941174 : Closed e2392363941174 ∧ code e2392363941174 = 11188456963382 := by decide
theorem cert_e2392363941174 : check e2392363941174 [[],[.left]] .smaller = true := by decide
def e2392363941178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2392363941178 : Closed e2392363941178 ∧ code e2392363941178 = 11188456963386 := by decide
theorem cert_e2392363941178 : check e2392363941178 [[],[.left]] .smaller = true := by decide
def e2392363941274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2392363941274 : Closed e2392363941274 ∧ code e2392363941274 = 11188456963482 := by decide
theorem cert_e2392363941274 : check e2392363941274 [[],[.left]] .smaller = true := by decide
def e2392363944814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2392363944814 : Closed e2392363944814 ∧ code e2392363944814 = 11188456967022 := by decide
theorem cert_e2392363944814 : check e2392363944814 [[],[.left]] .smaller = true := by decide
def e2392363944822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2392363944822 : Closed e2392363944822 ∧ code e2392363944822 = 11188456967030 := by decide
theorem cert_e2392363944822 : check e2392363944822 [[],[.left]] .smaller = true := by decide
def e2392363944878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2392363944878 : Closed e2392363944878 ∧ code e2392363944878 = 11188456967086 := by decide
theorem cert_e2392363944878 : check e2392363944878 [[],[.left]] .smaller = true := by decide
def e2392363944890 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2392363944890 : Closed e2392363944890 ∧ code e2392363944890 = 11188456967098 := by decide
theorem cert_e2392363944890 : check e2392363944890 [[],[.left]] .smaller = true := by decide
def e2392363944918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2392363944918 : Closed e2392363944918 ∧ code e2392363944918 = 11188456967126 := by decide
theorem cert_e2392363944918 : check e2392363944918 [[],[.left]] .smaller = true := by decide
def e2392363944922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2392363944922 : Closed e2392363944922 ∧ code e2392363944922 = 11188456967130 := by decide
theorem cert_e2392363944922 : check e2392363944922 [[],[.left]] .smaller = true := by decide
def e2392363945198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2392363945198 : Closed e2392363945198 ∧ code e2392363945198 = 11188456967406 := by decide
theorem cert_e2392363945198 : check e2392363945198 [[],[.left]] .smaller = true := by decide
def e2392363945206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2392363945206 : Closed e2392363945206 ∧ code e2392363945206 = 11188456967414 := by decide
theorem cert_e2392363945206 : check e2392363945206 [[],[.left]] .smaller = true := by decide
def e2392363945582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392363945582 : Closed e2392363945582 ∧ code e2392363945582 = 11188456967790 := by decide
theorem cert_e2392363945582 : check e2392363945582 [[],[.left]] .smaller = true := by decide
def e2392363945594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392363945594 : Closed e2392363945594 ∧ code e2392363945594 = 11188456967802 := by decide
theorem cert_e2392363945594 : check e2392363945594 [[],[.left]] .smaller = true := by decide
def e2392363945782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392363945782 : Closed e2392363945782 ∧ code e2392363945782 = 11188456967990 := by decide
theorem cert_e2392363945782 : check e2392363945782 [[],[.left]] .smaller = true := by decide
def e2392363945786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392363945786 : Closed e2392363945786 ∧ code e2392363945786 = 11188456967994 := by decide
theorem cert_e2392363945786 : check e2392363945786 [[],[.left]] .smaller = true := by decide
def e2392363951534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2392363951534 : Closed e2392363951534 ∧ code e2392363951534 = 11188456973742 := by decide
theorem cert_e2392363951534 : check e2392363951534 [[],[.left]] .smaller = true := by decide
def e2392363951546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2392363951546 : Closed e2392363951546 ∧ code e2392363951546 = 11188456973754 := by decide
theorem cert_e2392363951546 : check e2392363951546 [[],[.left]] .smaller = true := by decide
def e2392363951594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2392363951594 : Closed e2392363951594 ∧ code e2392363951594 = 11188456973802 := by decide
theorem cert_e2392363951594 : check e2392363951594 [[],[.left]] .smaller = true := by decide
def e2392363951726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2392363951726 : Closed e2392363951726 ∧ code e2392363951726 = 11188456973934 := by decide
theorem cert_e2392363951726 : check e2392363951726 [[],[.left]] .smaller = true := by decide
def e2392363951738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2392363951738 : Closed e2392363951738 ∧ code e2392363951738 = 11188456973946 := by decide
theorem cert_e2392363951738 : check e2392363951738 [[],[.left]] .smaller = true := by decide
def e2392363952026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392363952026 : Closed e2392363952026 ∧ code e2392363952026 = 11188456974234 := by decide
theorem cert_e2392363952026 : check e2392363952026 [[],[.left]] .smaller = true := by decide
def e2392363954902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2392363954902 : Closed e2392363954902 ∧ code e2392363954902 = 11188456977110 := by decide
theorem cert_e2392363954902 : check e2392363954902 [[],[.left]] .smaller = true := by decide
def e2392363954906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2392363954906 : Closed e2392363954906 ∧ code e2392363954906 = 11188456977114 := by decide
theorem cert_e2392363954906 : check e2392363954906 [[],[.left]] .smaller = true := by decide
def e2392363954922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2392363954922 : Closed e2392363954922 ∧ code e2392363954922 = 11188456977130 := by decide
theorem cert_e2392363954922 : check e2392363954922 [[],[.left]] .smaller = true := by decide
def e2392363954998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2392363954998 : Closed e2392363954998 ∧ code e2392363954998 = 11188456977206 := by decide
theorem cert_e2392363954998 : check e2392363954998 [[],[.left]] .smaller = true := by decide
def e2392363955002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2392363955002 : Closed e2392363955002 ∧ code e2392363955002 = 11188456977210 := by decide
theorem cert_e2392363955002 : check e2392363955002 [[],[.left]] .smaller = true := by decide
def e2392363955098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2392363955098 : Closed e2392363955098 ∧ code e2392363955098 = 11188456977306 := by decide
theorem cert_e2392363955098 : check e2392363955098 [[],[.left]] .smaller = true := by decide
def e2392364070638 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2392364070638 : Closed e2392364070638 ∧ code e2392364070638 = 11188457092846 := by decide
theorem cert_e2392364070638 : check e2392364070638 [[],[.left],[]] .sourceHead = true := by decide
def e2392364070766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2392364070766 : Closed e2392364070766 ∧ code e2392364070766 = 11188457092974 := by decide
theorem cert_e2392364070766 : check e2392364070766 [[],[.left],[]] .sourceHead = true := by decide
def e2392364070774 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2392364070774 : Closed e2392364070774 ∧ code e2392364070774 = 11188457092982 := by decide
theorem cert_e2392364070774 : check e2392364070774 [[],[.left],[]] .sourceHead = true := by decide
def e2392364071662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2392364071662 : Closed e2392364071662 ∧ code e2392364071662 = 11188457093870 := by decide
theorem cert_e2392364071662 : check e2392364071662 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .three = true := by decide
def e2392364071854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2392364071854 : Closed e2392364071854 ∧ code e2392364071854 = 11188457094062 := by decide
theorem cert_e2392364071854 : check e2392364071854 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392364071866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2392364071866 : Closed e2392364071866 ∧ code e2392364071866 = 11188457094074 := by decide
theorem cert_e2392364071866 : check e2392364071866 [[],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2392364072302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2392364072302 : Closed e2392364072302 ∧ code e2392364072302 = 11188457094510 := by decide
theorem cert_e2392364072302 : check e2392364072302 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392364072310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2392364072310 : Closed e2392364072310 ∧ code e2392364072310 = 11188457094518 := by decide
theorem cert_e2392364072310 : check e2392364072310 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392364072366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2392364072366 : Closed e2392364072366 ∧ code e2392364072366 = 11188457094574 := by decide
theorem cert_e2392364072366 : check e2392364072366 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392364072378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2392364072378 : Closed e2392364072378 ∧ code e2392364072378 = 11188457094586 := by decide
theorem cert_e2392364072378 : check e2392364072378 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2392364072406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2392364072406 : Closed e2392364072406 ∧ code e2392364072406 = 11188457094614 := by decide
private def t_e2392364072406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2392364072406 : ¬ IsSelfInterpreter e2392364072406 :=
  wSource (t := t_e2392364072406) (replay_sound (ps := []) (t := e2392364072406) (by decide)) (by decide)
def e2392364072410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2392364072410 : Closed e2392364072410 ∧ code e2392364072410 = 11188457094618 := by decide
private def t_e2392364072410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2392364072410 : ¬ IsSelfInterpreter e2392364072410 :=
  wSource (t := t_e2392364072410) (replay_sound (ps := []) (t := e2392364072410) (by decide)) (by decide)
def e2392364076782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2392364076782 : Closed e2392364076782 ∧ code e2392364076782 = 11188457098990 := by decide
theorem cert_e2392364076782 : check e2392364076782 [[],[.left],[]] .sourceHead = true := by decide
def e2392364076910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2392364076910 : Closed e2392364076910 ∧ code e2392364076910 = 11188457099118 := by decide
theorem cert_e2392364076910 : check e2392364076910 [[],[.left],[]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392357003802
#print axioms Blc.Floor43.cert_e2392357006874
#print axioms Blc.Floor43.cert_e2392357046810
#print axioms Blc.Floor43.cert_e2392357052954
#print axioms Blc.Floor43.cert_e2392357056026
#print axioms Blc.Floor43.cert_e2392357059098
#print axioms Blc.Floor43.cert_e2392357092890
#print axioms Blc.Floor43.cert_e2392357200410
#print axioms Blc.Floor43.cert_e2392357203482
#print axioms Blc.Floor43.cert_e2392357307810
#print axioms Blc.Floor43.cert_e2392357307930
#print axioms Blc.Floor43.cert_e2392357473818
#print axioms Blc.Floor43.cert_e2392357495322
#print axioms Blc.Floor43.cert_e2392357498394
#print axioms Blc.Floor43.cert_e2392357501466
#print axioms Blc.Floor43.cert_e2392357504418
#print axioms Blc.Floor43.cert_e2392357504538
#print axioms Blc.Floor43.cert_e2392360424986
#print axioms Blc.Floor43.cert_e2392360444442
#print axioms Blc.Floor43.cert_e2392360447514
#print axioms Blc.Floor43.cert_e2392360449562
#print axioms Blc.Floor43.cert_e2392360454682
#print axioms Blc.Floor43.cert_e2392360460826
#print axioms Blc.Floor43.cert_e2392360463898
#print axioms Blc.Floor43.cert_e2392360466970
#print axioms Blc.Floor43.cert_e2392360474138
#print axioms Blc.Floor43.cert_e2392360475162
#print axioms Blc.Floor43.cert_e2392360492570
#print axioms Blc.Floor43.cert_e2392360542746
#print axioms Blc.Floor43.cert_e2392360545818
#print axioms Blc.Floor43.cert_e2392360547866
#print axioms Blc.Floor43.cert_e2392360584610
#print axioms Blc.Floor43.cert_e2392360584730
#print axioms Blc.Floor43.cert_e2392360619546
#print axioms Blc.Floor43.cert_e2392360641050
#print axioms Blc.Floor43.cert_e2392360644122
#print axioms Blc.Floor43.cert_e2392360647194
#print axioms Blc.Floor43.cert_e2392360650146
#print axioms Blc.Floor43.cert_e2392360650266
#print axioms Blc.Floor43.cert_e2392360695322
#print axioms Blc.Floor43.cert_e2392360696346
#print axioms Blc.Floor43.cert_e2392364072406
#print axioms Blc.Floor43.cert_e2392364072410
