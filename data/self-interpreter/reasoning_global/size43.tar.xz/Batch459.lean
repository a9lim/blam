import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406522794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406522794 : Closed e2422406522794 ∧ code e2422406522794 = 11218499545002 := by decide
theorem cert_e2422406522794 : check e2422406522794 [[],[]] .chain = true := by decide
def e2422406523118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406523118 : Closed e2422406523118 ∧ code e2422406523118 = 11218499545326 := by decide
theorem cert_e2422406523118 : check e2422406523118 [[],[]] .chain = true := by decide
def e2422406523126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406523126 : Closed e2422406523126 ∧ code e2422406523126 = 11218499545334 := by decide
theorem cert_e2422406523126 : check e2422406523126 [[],[]] .chain = true := by decide
def e2422406523310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406523310 : Closed e2422406523310 ∧ code e2422406523310 = 11218499545518 := by decide
theorem cert_e2422406523310 : check e2422406523310 [[],[]] .chain = true := by decide
def e2422406523322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406523322 : Closed e2422406523322 ∧ code e2422406523322 = 11218499545530 := by decide
theorem cert_e2422406523322 : check e2422406523322 [[],[]] .chain = true := by decide
def e2422406523370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406523370 : Closed e2422406523370 ∧ code e2422406523370 = 11218499545578 := by decide
theorem cert_e2422406523370 : check e2422406523370 [[],[]] .chain = true := by decide
def e2422406523502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406523502 : Closed e2422406523502 ∧ code e2422406523502 = 11218499545710 := by decide
theorem cert_e2422406523502 : check e2422406523502 [[],[]] .chain = true := by decide
def e2422406523514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406523514 : Closed e2422406523514 ∧ code e2422406523514 = 11218499545722 := by decide
theorem cert_e2422406523514 : check e2422406523514 [[],[]] .chain = true := by decide
def e2422406523678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406523678 : Closed e2422406523678 ∧ code e2422406523678 = 11218499545886 := by decide
theorem cert_e2422406523678 : check e2422406523678 [[],[]] .chain = true := by decide
def e2422406523790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406523790 : Closed e2422406523790 ∧ code e2422406523790 = 11218499545998 := by decide
theorem cert_e2422406523790 : check e2422406523790 [[],[]] .chain = true := by decide
def e2422406523802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406523802 : Closed e2422406523802 ∧ code e2422406523802 = 11218499546010 := by decide
theorem cert_e2422406523802 : check e2422406523802 [[],[]] .chain = true := by decide
def e2422406524014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406524014 : Closed e2422406524014 ∧ code e2422406524014 = 11218499546222 := by decide
theorem cert_e2422406524014 : check e2422406524014 [[],[]] .chain = true := by decide
def e2422406524026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406524026 : Closed e2422406524026 ∧ code e2422406524026 = 11218499546234 := by decide
theorem cert_e2422406524026 : check e2422406524026 [[],[]] .chain = true := by decide
def e2422406524190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406524190 : Closed e2422406524190 ∧ code e2422406524190 = 11218499546398 := by decide
theorem cert_e2422406524190 : check e2422406524190 [[],[]] .chain = true := by decide
def e2422406524358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 1)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406524358 : Closed e2422406524358 ∧ code e2422406524358 = 11218499546566 := by decide
theorem cert_e2422406524358 : check e2422406524358 [[],[]] .chain = true := by decide
def e2422406524470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406524470 : Closed e2422406524470 ∧ code e2422406524470 = 11218499546678 := by decide
theorem cert_e2422406524470 : check e2422406524470 [[],[]] .chain = true := by decide
def e2422406524474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406524474 : Closed e2422406524474 ∧ code e2422406524474 = 11218499546682 := by decide
theorem cert_e2422406524474 : check e2422406524474 [[],[]] .chain = true := by decide
def e2422406524522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422406524522 : Closed e2422406524522 ∧ code e2422406524522 = 11218499546730 := by decide
theorem cert_e2422406524522 : check e2422406524522 [[],[]] .chain = true := by decide
def e2422406524558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406524558 : Closed e2422406524558 ∧ code e2422406524558 = 11218499546766 := by decide
theorem cert_e2422406524558 : check e2422406524558 [[],[]] .chain = true := by decide
def e2422406524570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406524570 : Closed e2422406524570 ∧ code e2422406524570 = 11218499546778 := by decide
theorem cert_e2422406524570 : check e2422406524570 [[],[]] .chain = true := by decide
def e2422406524614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406524614 : Closed e2422406524614 ∧ code e2422406524614 = 11218499546822 := by decide
theorem cert_e2422406524614 : check e2422406524614 [[],[]] .chain = true := by decide
def e2422406525294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406525294 : Closed e2422406525294 ∧ code e2422406525294 = 11218499547502 := by decide
theorem cert_e2422406525294 : check e2422406525294 [[],[]] .chain = true := by decide
def e2422406525302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406525302 : Closed e2422406525302 ∧ code e2422406525302 = 11218499547510 := by decide
theorem cert_e2422406525302 : check e2422406525302 [[],[]] .chain = true := by decide
def e2422406525358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406525358 : Closed e2422406525358 ∧ code e2422406525358 = 11218499547566 := by decide
theorem cert_e2422406525358 : check e2422406525358 [[],[]] .chain = true := by decide
def e2422406525370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406525370 : Closed e2422406525370 ∧ code e2422406525370 = 11218499547578 := by decide
theorem cert_e2422406525370 : check e2422406525370 [[],[]] .chain = true := by decide
def e2422406525418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 0)) (.var 0))))))
theorem wire_e2422406525418 : Closed e2422406525418 ∧ code e2422406525418 = 11218499547626 := by decide
theorem cert_e2422406525418 : check e2422406525418 [[],[]] .chain = true := by decide
def e2422406526062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406526062 : Closed e2422406526062 ∧ code e2422406526062 = 11218499548270 := by decide
theorem cert_e2422406526062 : check e2422406526062 [[],[]] .chain = true := by decide
def e2422406526074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406526074 : Closed e2422406526074 ∧ code e2422406526074 = 11218499548282 := by decide
theorem cert_e2422406526074 : check e2422406526074 [[],[]] .chain = true := by decide
def e2422406526238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406526238 : Closed e2422406526238 ∧ code e2422406526238 = 11218499548446 := by decide
theorem cert_e2422406526238 : check e2422406526238 [[],[]] .chain = true := by decide
def e2422406526406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406526406 : Closed e2422406526406 ∧ code e2422406526406 = 11218499548614 := by decide
theorem cert_e2422406526406 : check e2422406526406 [[],[]] .chain = true := by decide
def e2422406526510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406526510 : Closed e2422406526510 ∧ code e2422406526510 = 11218499548718 := by decide
theorem cert_e2422406526510 : check e2422406526510 [[],[]] .chain = true := by decide
def e2422406526690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406526690 : Closed e2422406526690 ∧ code e2422406526690 = 11218499548898 := by decide
theorem cert_e2422406526690 : check e2422406526690 [[],[]] .chain = true := by decide
def e2422406526702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2422406526702 : Closed e2422406526702 ∧ code e2422406526702 = 11218499548910 := by decide
theorem cert_e2422406526702 : check e2422406526702 [[],[]] .sourceHead = true := by decide
def e2422406526742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406526742 : Closed e2422406526742 ∧ code e2422406526742 = 11218499548950 := by decide
theorem cert_e2422406526742 : check e2422406526742 [[],[]] .chain = true := by decide
def e2422406526746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406526746 : Closed e2422406526746 ∧ code e2422406526746 = 11218499548954 := by decide
theorem cert_e2422406526746 : check e2422406526746 [[],[]] .chain = true := by decide
def e2422406526790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406526790 : Closed e2422406526790 ∧ code e2422406526790 = 11218499548998 := by decide
theorem cert_e2422406526790 : check e2422406526790 [[],[]] .chain = true := by decide
def e2422406526818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406526818 : Closed e2422406526818 ∧ code e2422406526818 = 11218499549026 := by decide
theorem cert_e2422406526818 : check e2422406526818 [[],[]] .chain = true := by decide
def e2422406526830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2422406526830 : Closed e2422406526830 ∧ code e2422406526830 = 11218499549038 := by decide
theorem cert_e2422406526830 : check e2422406526830 [[],[]] .sourceHead = true := by decide
def e2422406526838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2422406526838 : Closed e2422406526838 ∧ code e2422406526838 = 11218499549046 := by decide
theorem cert_e2422406526838 : check e2422406526838 [[],[]] .sourceHead = true := by decide
def e2422406527150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406527150 : Closed e2422406527150 ∧ code e2422406527150 = 11218499549358 := by decide
theorem cert_e2422406527150 : check e2422406527150 [[],[]] .chain = true := by decide
def e2422406527162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406527162 : Closed e2422406527162 ∧ code e2422406527162 = 11218499549370 := by decide
theorem cert_e2422406527162 : check e2422406527162 [[],[]] .chain = true := by decide
def e2422406527534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406527534 : Closed e2422406527534 ∧ code e2422406527534 = 11218499549742 := by decide
theorem cert_e2422406527534 : check e2422406527534 [[],[]] .chain = true := by decide
def e2422406527714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406527714 : Closed e2422406527714 ∧ code e2422406527714 = 11218499549922 := by decide
theorem cert_e2422406527714 : check e2422406527714 [[],[]] .chain = true := by decide
def e2422406527726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406527726 : Closed e2422406527726 ∧ code e2422406527726 = 11218499549934 := by decide
theorem cert_e2422406527726 : check e2422406527726 [[],[]] .sourceHead = true := by decide
def e2422406527882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406527882 : Closed e2422406527882 ∧ code e2422406527882 = 11218499550090 := by decide
theorem cert_e2422406527882 : check e2422406527882 [[],[]] .chain = true := by decide
def e2422406527906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406527906 : Closed e2422406527906 ∧ code e2422406527906 = 11218499550114 := by decide
theorem cert_e2422406527906 : check e2422406527906 [[],[]] .chain = true := by decide
def e2422406527918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406527918 : Closed e2422406527918 ∧ code e2422406527918 = 11218499550126 := by decide
theorem cert_e2422406527918 : check e2422406527918 [[],[]] .sourceHead = true := by decide
def e2422406527930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406527930 : Closed e2422406527930 ∧ code e2422406527930 = 11218499550138 := by decide
theorem cert_e2422406527930 : check e2422406527930 [[],[]] .sourceHead = true := by decide
def e2422406528086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406528086 : Closed e2422406528086 ∧ code e2422406528086 = 11218499550294 := by decide
theorem cert_e2422406528086 : check e2422406528086 [[],[]] .chain = true := by decide
def e2422406528090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406528090 : Closed e2422406528090 ∧ code e2422406528090 = 11218499550298 := by decide
theorem cert_e2422406528090 : check e2422406528090 [[],[]] .chain = true := by decide
def e2422406528106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406528106 : Closed e2422406528106 ∧ code e2422406528106 = 11218499550314 := by decide
theorem cert_e2422406528106 : check e2422406528106 [[],[]] .chain = true := by decide
def e2422406528278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406528278 : Closed e2422406528278 ∧ code e2422406528278 = 11218499550486 := by decide
theorem cert_e2422406528278 : check e2422406528278 [[],[]] .chain = true := by decide
def e2422406528282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406528282 : Closed e2422406528282 ∧ code e2422406528282 = 11218499550490 := by decide
theorem cert_e2422406528282 : check e2422406528282 [[],[]] .chain = true := by decide
def e2422406528326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406528326 : Closed e2422406528326 ∧ code e2422406528326 = 11218499550534 := by decide
theorem cert_e2422406528326 : check e2422406528326 [[],[]] .chain = true := by decide
def e2422406528354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406528354 : Closed e2422406528354 ∧ code e2422406528354 = 11218499550562 := by decide
theorem cert_e2422406528354 : check e2422406528354 [[],[]] .chain = true := by decide
def e2422406528366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406528366 : Closed e2422406528366 ∧ code e2422406528366 = 11218499550574 := by decide
theorem cert_e2422406528366 : check e2422406528366 [[],[]] .sourceHead = true := by decide
def e2422406528374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406528374 : Closed e2422406528374 ∧ code e2422406528374 = 11218499550582 := by decide
theorem cert_e2422406528374 : check e2422406528374 [[],[]] .sourceHead = true := by decide
def e2422406528394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406528394 : Closed e2422406528394 ∧ code e2422406528394 = 11218499550602 := by decide
theorem cert_e2422406528394 : check e2422406528394 [[],[]] .chain = true := by decide
def e2422406528418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406528418 : Closed e2422406528418 ∧ code e2422406528418 = 11218499550626 := by decide
theorem cert_e2422406528418 : check e2422406528418 [[],[]] .chain = true := by decide
def e2422406528430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406528430 : Closed e2422406528430 ∧ code e2422406528430 = 11218499550638 := by decide
theorem cert_e2422406528430 : check e2422406528430 [[],[]] .sourceHead = true := by decide
def e2422406528442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406528442 : Closed e2422406528442 ∧ code e2422406528442 = 11218499550650 := by decide
theorem cert_e2422406528442 : check e2422406528442 [[],[]] .sourceHead = true := by decide
def e2422406528470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406528470 : Closed e2422406528470 ∧ code e2422406528470 = 11218499550678 := by decide
theorem cert_e2422406528470 : check e2422406528470 [[],[]] .sourceHead = true := by decide
def e2422406528474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406528474 : Closed e2422406528474 ∧ code e2422406528474 = 11218499550682 := by decide
theorem cert_e2422406528474 : check e2422406528474 [[],[]] .sourceHead = true := by decide
def e2422406537902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406537902 : Closed e2422406537902 ∧ code e2422406537902 = 11218499560110 := by decide
theorem cert_e2422406537902 : check e2422406537902 [[],[]] .chain = true := by decide
def e2422406537914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406537914 : Closed e2422406537914 ∧ code e2422406537914 = 11218499560122 := by decide
theorem cert_e2422406537914 : check e2422406537914 [[],[]] .chain = true := by decide
def e2422406537962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406537962 : Closed e2422406537962 ∧ code e2422406537962 = 11218499560170 := by decide
theorem cert_e2422406537962 : check e2422406537962 [[],[]] .chain = true := by decide
def e2422406539438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406539438 : Closed e2422406539438 ∧ code e2422406539438 = 11218499561646 := by decide
theorem cert_e2422406539438 : check e2422406539438 [[],[]] .chain = true := by decide
def e2422406539450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406539450 : Closed e2422406539450 ∧ code e2422406539450 = 11218499561658 := by decide
theorem cert_e2422406539450 : check e2422406539450 [[],[]] .chain = true := by decide
def e2422406539822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406539822 : Closed e2422406539822 ∧ code e2422406539822 = 11218499562030 := by decide
theorem cert_e2422406539822 : check e2422406539822 [[],[]] .chain = true := by decide
def e2422406540002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406540002 : Closed e2422406540002 ∧ code e2422406540002 = 11218499562210 := by decide
theorem cert_e2422406540002 : check e2422406540002 [[],[]] .chain = true := by decide
def e2422406540014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2422406540014 : Closed e2422406540014 ∧ code e2422406540014 = 11218499562222 := by decide
theorem cert_e2422406540014 : check e2422406540014 [[],[]] .sourceHead = true := by decide
def e2422406540142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2422406540142 : Closed e2422406540142 ∧ code e2422406540142 = 11218499562350 := by decide
theorem cert_e2422406540142 : check e2422406540142 [[],[]] .chain = true := by decide
def e2422406540150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2422406540150 : Closed e2422406540150 ∧ code e2422406540150 = 11218499562358 := by decide
theorem cert_e2422406540150 : check e2422406540150 [[],[]] .chain = true := by decide
def e2422406540170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406540170 : Closed e2422406540170 ∧ code e2422406540170 = 11218499562378 := by decide
theorem cert_e2422406540170 : check e2422406540170 [[],[]] .chain = true := by decide
def e2422406540194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406540194 : Closed e2422406540194 ∧ code e2422406540194 = 11218499562402 := by decide
theorem cert_e2422406540194 : check e2422406540194 [[],[]] .chain = true := by decide
def e2422406540206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2422406540206 : Closed e2422406540206 ∧ code e2422406540206 = 11218499562414 := by decide
theorem cert_e2422406540206 : check e2422406540206 [[],[]] .sourceHead = true := by decide
def e2422406540214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2422406540214 : Closed e2422406540214 ∧ code e2422406540214 = 11218499562422 := by decide
theorem cert_e2422406540214 : check e2422406540214 [[],[]] .chain = true := by decide
def e2422406540218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2422406540218 : Closed e2422406540218 ∧ code e2422406540218 = 11218499562426 := by decide
theorem cert_e2422406540218 : check e2422406540218 [[],[]] .sourceHead = true := by decide
def e2422406540654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406540654 : Closed e2422406540654 ∧ code e2422406540654 = 11218499562862 := by decide
theorem cert_e2422406540654 : check e2422406540654 [[],[]] .chain = true := by decide
def e2422406540662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406540662 : Closed e2422406540662 ∧ code e2422406540662 = 11218499562870 := by decide
theorem cert_e2422406540662 : check e2422406540662 [[],[]] .chain = true := by decide
def e2422406540718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406540718 : Closed e2422406540718 ∧ code e2422406540718 = 11218499562926 := by decide
theorem cert_e2422406540718 : check e2422406540718 [[],[]] .chain = true := by decide
def e2422406540730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406540730 : Closed e2422406540730 ∧ code e2422406540730 = 11218499562938 := by decide
theorem cert_e2422406540730 : check e2422406540730 [[],[]] .chain = true := by decide
def e2422406540758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406540758 : Closed e2422406540758 ∧ code e2422406540758 = 11218499562966 := by decide
theorem cert_e2422406540758 : check e2422406540758 [[],[]] .chain = true := by decide
def e2422406540762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406540762 : Closed e2422406540762 ∧ code e2422406540762 = 11218499562970 := by decide
theorem cert_e2422406540762 : check e2422406540762 [[],[]] .chain = true := by decide
def e2422406540842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406540842 : Closed e2422406540842 ∧ code e2422406540842 = 11218499563050 := by decide
theorem cert_e2422406540842 : check e2422406540842 [[],[]] .chain = true := by decide
def e2422406540938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406540938 : Closed e2422406540938 ∧ code e2422406540938 = 11218499563146 := by decide
theorem cert_e2422406540938 : check e2422406540938 [[],[]] .chain = true := by decide
def e2422406540962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406540962 : Closed e2422406540962 ∧ code e2422406540962 = 11218499563170 := by decide
theorem cert_e2422406540962 : check e2422406540962 [[],[]] .chain = true := by decide
def e2422406540974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406540974 : Closed e2422406540974 ∧ code e2422406540974 = 11218499563182 := by decide
theorem cert_e2422406540974 : check e2422406540974 [[],[]] .sourceHead = true := by decide
def e2422406540982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406540982 : Closed e2422406540982 ∧ code e2422406540982 = 11218499563190 := by decide
theorem cert_e2422406540982 : check e2422406540982 [[],[]] .chain = true := by decide
def e2422406540986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406540986 : Closed e2422406540986 ∧ code e2422406540986 = 11218499563194 := by decide
theorem cert_e2422406540986 : check e2422406540986 [[],[]] .sourceHead = true := by decide
def e2422406541014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406541014 : Closed e2422406541014 ∧ code e2422406541014 = 11218499563222 := by decide
theorem cert_e2422406541014 : check e2422406541014 [[],[]] .chain = true := by decide
def e2422406541018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406541018 : Closed e2422406541018 ∧ code e2422406541018 = 11218499563226 := by decide
theorem cert_e2422406541018 : check e2422406541018 [[],[]] .chain = true := by decide
def e2422406541034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406541034 : Closed e2422406541034 ∧ code e2422406541034 = 11218499563242 := by decide
theorem cert_e2422406541034 : check e2422406541034 [[],[]] .sourceHead = true := by decide
def e2422406542702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406542702 : Closed e2422406542702 ∧ code e2422406542702 = 11218499564910 := by decide
theorem cert_e2422406542702 : check e2422406542702 [[],[]] .chain = true := by decide
def e2422406542710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406542710 : Closed e2422406542710 ∧ code e2422406542710 = 11218499564918 := by decide
theorem cert_e2422406542710 : check e2422406542710 [[],[]] .chain = true := by decide
def e2422406542766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406542766 : Closed e2422406542766 ∧ code e2422406542766 = 11218499564974 := by decide
theorem cert_e2422406542766 : check e2422406542766 [[],[]] .chain = true := by decide
def e2422406542778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406542778 : Closed e2422406542778 ∧ code e2422406542778 = 11218499564986 := by decide
theorem cert_e2422406542778 : check e2422406542778 [[],[]] .chain = true := by decide
def e2422406542806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406542806 : Closed e2422406542806 ∧ code e2422406542806 = 11218499565014 := by decide
theorem cert_e2422406542806 : check e2422406542806 [[],[]] .chain = true := by decide
def e2422406542810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406542810 : Closed e2422406542810 ∧ code e2422406542810 = 11218499565018 := by decide
theorem cert_e2422406542810 : check e2422406542810 [[],[]] .chain = true := by decide
def e2422406543022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406543022 : Closed e2422406543022 ∧ code e2422406543022 = 11218499565230 := by decide
theorem cert_e2422406543022 : check e2422406543022 [[],[]] .chain = true := by decide
def e2422406543034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406543034 : Closed e2422406543034 ∧ code e2422406543034 = 11218499565242 := by decide
theorem cert_e2422406543034 : check e2422406543034 [[],[]] .chain = true := by decide
def e2422406543082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406543082 : Closed e2422406543082 ∧ code e2422406543082 = 11218499565290 := by decide
theorem cert_e2422406543082 : check e2422406543082 [[],[]] .chain = true := by decide
def e2422406543190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406543190 : Closed e2422406543190 ∧ code e2422406543190 = 11218499565398 := by decide
theorem cert_e2422406543190 : check e2422406543190 [[],[]] .chain = true := by decide
def e2422406543194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406543194 : Closed e2422406543194 ∧ code e2422406543194 = 11218499565402 := by decide
theorem cert_e2422406543194 : check e2422406543194 [[],[]] .chain = true := by decide
def e2422406543210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406543210 : Closed e2422406543210 ∧ code e2422406543210 = 11218499565418 := by decide
theorem cert_e2422406543210 : check e2422406543210 [[],[]] .chain = true := by decide
def e2422406543530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406543530 : Closed e2422406543530 ∧ code e2422406543530 = 11218499565738 := by decide
theorem cert_e2422406543530 : check e2422406543530 [[],[]] .chain = true := by decide
def e2422406543914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406543914 : Closed e2422406543914 ∧ code e2422406543914 = 11218499566122 := by decide
theorem cert_e2422406543914 : check e2422406543914 [[],[]] .chain = true := by decide
def e2422406544010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406544010 : Closed e2422406544010 ∧ code e2422406544010 = 11218499566218 := by decide
theorem cert_e2422406544010 : check e2422406544010 [[],[]] .chain = true := by decide
def e2422406544034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406544034 : Closed e2422406544034 ∧ code e2422406544034 = 11218499566242 := by decide
theorem cert_e2422406544034 : check e2422406544034 [[],[]] .chain = true := by decide
def e2422406544046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406544046 : Closed e2422406544046 ∧ code e2422406544046 = 11218499566254 := by decide
theorem cert_e2422406544046 : check e2422406544046 [[],[]] .sourceHead = true := by decide
def e2422406544054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406544054 : Closed e2422406544054 ∧ code e2422406544054 = 11218499566262 := by decide
theorem cert_e2422406544054 : check e2422406544054 [[],[]] .chain = true := by decide
def e2422406544058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406544058 : Closed e2422406544058 ∧ code e2422406544058 = 11218499566266 := by decide
theorem cert_e2422406544058 : check e2422406544058 [[],[]] .sourceHead = true := by decide
def e2422406544086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406544086 : Closed e2422406544086 ∧ code e2422406544086 = 11218499566294 := by decide
theorem cert_e2422406544086 : check e2422406544086 [[],[]] .chain = true := by decide
def e2422406544090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406544090 : Closed e2422406544090 ∧ code e2422406544090 = 11218499566298 := by decide
theorem cert_e2422406544090 : check e2422406544090 [[],[]] .chain = true := by decide
def e2422406544106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406544106 : Closed e2422406544106 ∧ code e2422406544106 = 11218499566314 := by decide
theorem cert_e2422406544106 : check e2422406544106 [[],[]] .sourceHead = true := by decide
def e2422406544214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406544214 : Closed e2422406544214 ∧ code e2422406544214 = 11218499566422 := by decide
theorem cert_e2422406544214 : check e2422406544214 [[],[]] .chain = true := by decide
def e2422406544218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406544218 : Closed e2422406544218 ∧ code e2422406544218 = 11218499566426 := by decide
theorem cert_e2422406544218 : check e2422406544218 [[],[]] .chain = true := by decide
def e2422406544234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406544234 : Closed e2422406544234 ∧ code e2422406544234 = 11218499566442 := by decide
theorem cert_e2422406544234 : check e2422406544234 [[],[]] .chain = true := by decide
def e2422406544298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0)) (.var 0))))))
theorem wire_e2422406544298 : Closed e2422406544298 ∧ code e2422406544298 = 11218499566506 := by decide
theorem cert_e2422406544298 : check e2422406544298 [[],[]] .sourceHead = true := by decide
def e2422406545582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422406545582 : Closed e2422406545582 ∧ code e2422406545582 = 11218499567790 := by decide
theorem cert_e2422406545582 : check e2422406545582 [[],[]] .chain = true := by decide
def e2422406545594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422406545594 : Closed e2422406545594 ∧ code e2422406545594 = 11218499567802 := by decide
theorem cert_e2422406545594 : check e2422406545594 [[],[]] .chain = true := by decide
def e2422406546158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e2422406546158 : Closed e2422406546158 ∧ code e2422406546158 = 11218499568366 := by decide
theorem cert_e2422406546158 : check e2422406546158 [[],[]] .sourceHead = true := by decide
def e2422406546286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422406546286 : Closed e2422406546286 ∧ code e2422406546286 = 11218499568494 := by decide
theorem cert_e2422406546286 : check e2422406546286 [[],[]] .chain = true := by decide
def e2422406546294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422406546294 : Closed e2422406546294 ∧ code e2422406546294 = 11218499568502 := by decide
theorem cert_e2422406546294 : check e2422406546294 [[],[]] .chain = true := by decide
def e2422406546350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422406546350 : Closed e2422406546350 ∧ code e2422406546350 = 11218499568558 := by decide
theorem cert_e2422406546350 : check e2422406546350 [[],[]] .chain = true := by decide
def e2422406546362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422406546362 : Closed e2422406546362 ∧ code e2422406546362 = 11218499568570 := by decide
theorem cert_e2422406546362 : check e2422406546362 [[],[]] .chain = true := by decide
def e2422406546410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 0)) (.var 0))))))
theorem wire_e2422406546410 : Closed e2422406546410 ∧ code e2422406546410 = 11218499568618 := by decide
theorem cert_e2422406546410 : check e2422406546410 [[],[]] .chain = true := by decide
def e2422406547118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406547118 : Closed e2422406547118 ∧ code e2422406547118 = 11218499569326 := by decide
theorem cert_e2422406547118 : check e2422406547118 [[],[]] .sourceHead = true := by decide
def e2422406547130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406547130 : Closed e2422406547130 ∧ code e2422406547130 = 11218499569338 := by decide
theorem cert_e2422406547130 : check e2422406547130 [[],[]] .sourceHead = true := by decide
def e2422406547694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406547694 : Closed e2422406547694 ∧ code e2422406547694 = 11218499569902 := by decide
theorem cert_e2422406547694 : check e2422406547694 [[],[]] .chain = true := by decide
def e2422406547702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406547702 : Closed e2422406547702 ∧ code e2422406547702 = 11218499569910 := by decide
theorem cert_e2422406547702 : check e2422406547702 [[],[]] .chain = true := by decide
def e2422406547886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406547886 : Closed e2422406547886 ∧ code e2422406547886 = 11218499570094 := by decide
theorem cert_e2422406547886 : check e2422406547886 [[],[]] .chain = true := by decide
def e2422406547898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406547898 : Closed e2422406547898 ∧ code e2422406547898 = 11218499570106 := by decide
theorem cert_e2422406547898 : check e2422406547898 [[],[]] .chain = true := by decide
def e2422406547946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406547946 : Closed e2422406547946 ∧ code e2422406547946 = 11218499570154 := by decide
theorem cert_e2422406547946 : check e2422406547946 [[],[]] .chain = true := by decide
def e2422406548078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406548078 : Closed e2422406548078 ∧ code e2422406548078 = 11218499570286 := by decide
theorem cert_e2422406548078 : check e2422406548078 [[],[]] .chain = true := by decide
def e2422406548090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406548090 : Closed e2422406548090 ∧ code e2422406548090 = 11218499570298 := by decide
theorem cert_e2422406548090 : check e2422406548090 [[],[]] .chain = true := by decide
def e2422406548254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406548254 : Closed e2422406548254 ∧ code e2422406548254 = 11218499570462 := by decide
theorem cert_e2422406548254 : check e2422406548254 [[],[]] .chain = true := by decide
def e2422406548366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406548366 : Closed e2422406548366 ∧ code e2422406548366 = 11218499570574 := by decide
theorem cert_e2422406548366 : check e2422406548366 [[],[]] .chain = true := by decide
def e2422406548378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406548378 : Closed e2422406548378 ∧ code e2422406548378 = 11218499570586 := by decide
theorem cert_e2422406548378 : check e2422406548378 [[],[]] .chain = true := by decide
def e2422406548590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406548590 : Closed e2422406548590 ∧ code e2422406548590 = 11218499570798 := by decide
theorem cert_e2422406548590 : check e2422406548590 [[],[]] .chain = true := by decide
def e2422406548602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406548602 : Closed e2422406548602 ∧ code e2422406548602 = 11218499570810 := by decide
theorem cert_e2422406548602 : check e2422406548602 [[],[]] .chain = true := by decide
def e2422406548766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406548766 : Closed e2422406548766 ∧ code e2422406548766 = 11218499570974 := by decide
theorem cert_e2422406548766 : check e2422406548766 [[],[]] .chain = true := by decide
def e2422406548934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406548934 : Closed e2422406548934 ∧ code e2422406548934 = 11218499571142 := by decide
theorem cert_e2422406548934 : check e2422406548934 [[],[]] .chain = true := by decide
def e2422406549038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406549038 : Closed e2422406549038 ∧ code e2422406549038 = 11218499571246 := by decide
theorem cert_e2422406549038 : check e2422406549038 [[],[]] .chain = true := by decide
def e2422406549218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406549218 : Closed e2422406549218 ∧ code e2422406549218 = 11218499571426 := by decide
theorem cert_e2422406549218 : check e2422406549218 [[],[]] .chain = true := by decide
def e2422406549230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e2422406549230 : Closed e2422406549230 ∧ code e2422406549230 = 11218499571438 := by decide
theorem cert_e2422406549230 : check e2422406549230 [[],[]] .sourceHead = true := by decide
def e2422406549270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406549270 : Closed e2422406549270 ∧ code e2422406549270 = 11218499571478 := by decide
theorem cert_e2422406549270 : check e2422406549270 [[],[]] .chain = true := by decide
def e2422406549274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406549274 : Closed e2422406549274 ∧ code e2422406549274 = 11218499571482 := by decide
theorem cert_e2422406549274 : check e2422406549274 [[],[]] .chain = true := by decide
def e2422406549318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406549318 : Closed e2422406549318 ∧ code e2422406549318 = 11218499571526 := by decide
theorem cert_e2422406549318 : check e2422406549318 [[],[]] .chain = true := by decide
def e2422406549346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406549346 : Closed e2422406549346 ∧ code e2422406549346 = 11218499571554 := by decide
theorem cert_e2422406549346 : check e2422406549346 [[],[]] .chain = true := by decide
def e2422406549358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1)) (.var 2))))))
theorem wire_e2422406549358 : Closed e2422406549358 ∧ code e2422406549358 = 11218499571566 := by decide
theorem cert_e2422406549358 : check e2422406549358 [[],[]] .sourceHead = true := by decide
def e2422406549366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 2)) (.var 1))))))
theorem wire_e2422406549366 : Closed e2422406549366 ∧ code e2422406549366 = 11218499571574 := by decide
theorem cert_e2422406549366 : check e2422406549366 [[],[]] .sourceHead = true := by decide
def e2422406551726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406551726 : Closed e2422406551726 ∧ code e2422406551726 = 11218499573934 := by decide
theorem cert_e2422406551726 : check e2422406551726 [[],[]] .chain = true := by decide
def e2422406551738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406551738 : Closed e2422406551738 ∧ code e2422406551738 = 11218499573946 := by decide
theorem cert_e2422406551738 : check e2422406551738 [[],[]] .chain = true := by decide
def e2422406552110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406552110 : Closed e2422406552110 ∧ code e2422406552110 = 11218499574318 := by decide
theorem cert_e2422406552110 : check e2422406552110 [[],[]] .chain = true := by decide
def e2422406552290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406552290 : Closed e2422406552290 ∧ code e2422406552290 = 11218499574498 := by decide
theorem cert_e2422406552290 : check e2422406552290 [[],[]] .chain = true := by decide
def e2422406552302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2422406552302 : Closed e2422406552302 ∧ code e2422406552302 = 11218499574510 := by decide
theorem cert_e2422406552302 : check e2422406552302 [[],[]] .sourceHead = true := by decide
def e2422406552430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406552430 : Closed e2422406552430 ∧ code e2422406552430 = 11218499574638 := by decide
theorem cert_e2422406552430 : check e2422406552430 [[],[]] .chain = true := by decide
def e2422406552438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406552438 : Closed e2422406552438 ∧ code e2422406552438 = 11218499574646 := by decide
theorem cert_e2422406552438 : check e2422406552438 [[],[]] .chain = true := by decide
def e2422406552458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406552458 : Closed e2422406552458 ∧ code e2422406552458 = 11218499574666 := by decide
theorem cert_e2422406552458 : check e2422406552458 [[],[]] .chain = true := by decide
end Blc.Floor43
