import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373619054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2393373619054 : Closed e2393373619054 ∧ code e2393373619054 = 11189466641262 := by decide
theorem cert_e2393373619054 : check e2393373619054 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2393373619062 : Closed e2393373619062 ∧ code e2393373619062 = 11189466641270 := by decide
theorem cert_e2393373619062 : check e2393373619062 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2393373619082 : Closed e2393373619082 ∧ code e2393373619082 = 11189466641290 := by decide
theorem cert_e2393373619082 : check e2393373619082 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373619106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2393373619106 : Closed e2393373619106 ∧ code e2393373619106 = 11189466641314 := by decide
theorem cert_e2393373619106 : check e2393373619106 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373619118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2393373619118 : Closed e2393373619118 ∧ code e2393373619118 = 11189466641326 := by decide
theorem cert_e2393373619118 : check e2393373619118 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2393373619126 : Closed e2393373619126 ∧ code e2393373619126 = 11189466641334 := by decide
theorem cert_e2393373619126 : check e2393373619126 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2393373619130 : Closed e2393373619130 ∧ code e2393373619130 = 11189466641338 := by decide
theorem cert_e2393373619130 : check e2393373619130 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2393373619158 : Closed e2393373619158 ∧ code e2393373619158 = 11189466641366 := by decide
theorem cert_e2393373619158 : check e2393373619158 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2393373619162 : Closed e2393373619162 ∧ code e2393373619162 = 11189466641370 := by decide
theorem cert_e2393373619162 : check e2393373619162 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2393373619230 : Closed e2393373619230 ∧ code e2393373619230 = 11189466641438 := by decide
theorem cert_e2393373619230 : check e2393373619230 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373619426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2393373619426 : Closed e2393373619426 ∧ code e2393373619426 = 11189466641634 := by decide
theorem cert_e2393373619426 : check e2393373619426 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373619438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373619438 : Closed e2393373619438 ∧ code e2393373619438 = 11189466641646 := by decide
theorem cert_e2393373619438 : check e2393373619438 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373619446 : Closed e2393373619446 ∧ code e2393373619446 = 11189466641654 := by decide
theorem cert_e2393373619446 : check e2393373619446 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619726 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2393373619726 : Closed e2393373619726 ∧ code e2393373619726 = 11189466641934 := by decide
theorem cert_e2393373619726 : check e2393373619726 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373619738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373619738 : Closed e2393373619738 ∧ code e2393373619738 = 11189466641946 := by decide
theorem cert_e2393373619738 : check e2393373619738 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373619810 : Closed e2393373619810 ∧ code e2393373619810 = 11189466642018 := by decide
theorem cert_e2393373619810 : check e2393373619810 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373619822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373619822 : Closed e2393373619822 ∧ code e2393373619822 = 11189466642030 := by decide
theorem cert_e2393373619822 : check e2393373619822 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373619830 : Closed e2393373619830 ∧ code e2393373619830 = 11189466642038 := by decide
theorem cert_e2393373619830 : check e2393373619830 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373619834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373619834 : Closed e2393373619834 ∧ code e2393373619834 = 11189466642042 := by decide
theorem cert_e2393373619834 : check e2393373619834 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373620022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373620022 : Closed e2393373620022 ∧ code e2393373620022 = 11189466642230 := by decide
theorem cert_e2393373620022 : check e2393373620022 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373620026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373620026 : Closed e2393373620026 ∧ code e2393373620026 = 11189466642234 := by decide
theorem cert_e2393373620026 : check e2393373620026 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373620282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2393373620282 : Closed e2393373620282 ∧ code e2393373620282 = 11189466642490 := by decide
theorem cert_e2393373620282 : check e2393373620282 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373620330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2393373620330 : Closed e2393373620330 ∧ code e2393373620330 = 11189466642538 := by decide
theorem cert_e2393373620330 : check e2393373620330 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .width = true := by decide
def e2393373620378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373620378 : Closed e2393373620378 ∧ code e2393373620378 = 11189466642586 := by decide
theorem cert_e2393373620378 : check e2393373620378 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373620422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2393373620422 : Closed e2393373620422 ∧ code e2393373620422 = 11189466642630 := by decide
theorem cert_e2393373620422 : check e2393373620422 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373620618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2393373620618 : Closed e2393373620618 ∧ code e2393373620618 = 11189466642826 := by decide
theorem cert_e2393373620618 : check e2393373620618 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373620642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2393373620642 : Closed e2393373620642 ∧ code e2393373620642 = 11189466642850 := by decide
theorem cert_e2393373620642 : check e2393373620642 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373620654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2393373620654 : Closed e2393373620654 ∧ code e2393373620654 = 11189466642862 := by decide
theorem cert_e2393373620654 : check e2393373620654 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373620662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2393373620662 : Closed e2393373620662 ∧ code e2393373620662 = 11189466642870 := by decide
theorem cert_e2393373620662 : check e2393373620662 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373620666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2393373620666 : Closed e2393373620666 ∧ code e2393373620666 = 11189466642874 := by decide
theorem cert_e2393373620666 : check e2393373620666 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373620694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2393373620694 : Closed e2393373620694 ∧ code e2393373620694 = 11189466642902 := by decide
def e2393373620698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2393373620698 : Closed e2393373620698 ∧ code e2393373620698 = 11189466642906 := by decide
theorem cert_e2393373620698 : check e2393373620698 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2393373620714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2393373620714 : Closed e2393373620714 ∧ code e2393373620714 = 11189466642922 := by decide
theorem cert_e2393373620714 : checkPay e2393373620714 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.left,.left,.right,.left],[.left,.left,.right],[.left,.left,.right,.under,.left,.left],[.left,.left,.right,.under,.left],[.left,.left,.right,.under],[.left,.left,.right,.under,.left,.right,.left],[.left,.left,.right,.under,.left,.right,.left,.left,.left,.left],[.left,.left,.right,.under,.left,.right,.left,.left,.left],[.left,.left,.right,.under,.left,.right,.left,.left],[.left,.right,.left],[.left,.right],[.left,.right,.under,.left,.right]] = true := by decide
def e2393373620750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2393373620750 : Closed e2393373620750 ∧ code e2393373620750 = 11189466642958 := by decide
theorem cert_e2393373620750 : check e2393373620750 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373620762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373620762 : Closed e2393373620762 ∧ code e2393373620762 = 11189466642970 := by decide
theorem cert_e2393373620762 : check e2393373620762 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .width = true := by decide
def e2393373620834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373620834 : Closed e2393373620834 ∧ code e2393373620834 = 11189466643042 := by decide
theorem cert_e2393373620834 : check e2393373620834 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373620846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373620846 : Closed e2393373620846 ∧ code e2393373620846 = 11189466643054 := by decide
theorem cert_e2393373620846 : checkPay e2393373620846 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.right],[.right,.left,.left],[.right,.left],[.right],[.right,.left,.right],[.right,.right]] = true := by decide
def e2393373620854 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373620854 : Closed e2393373620854 ∧ code e2393373620854 = 11189466643062 := by decide
def e2393373620858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373620858 : Closed e2393373620858 ∧ code e2393373620858 = 11189466643066 := by decide
theorem cert_e2393373620858 : checkPay e2393373620858 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.left,.left],[.left],[],[.left,.right],[.left,.right,.left,.left,.left],[.left,.right,.left,.left],[.left,.right,.left],[.left,.right,.left,.left,.right],[.left,.right,.left,.left,.right,.left],[.left,.right,.left,.left,.right],[.right,.right,.left],[.right,.right],[.right,.right,.under,.left,.right]] = true := by decide
def e2393373621046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373621046 : Closed e2393373621046 ∧ code e2393373621046 = 11189466643254 := by decide
theorem cert_e2393373621046 : check e2393373621046 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373621050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373621050 : Closed e2393373621050 ∧ code e2393373621050 = 11189466643258 := by decide
theorem cert_e2393373621050 : check e2393373621050 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373621146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373621146 : Closed e2393373621146 ∧ code e2393373621146 = 11189466643354 := by decide
theorem cert_e2393373621146 : check e2393373621146 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373621462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2393373621462 : Closed e2393373621462 ∧ code e2393373621462 = 11189466643670 := by decide
theorem cert_e2393373621462 : check e2393373621462 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373621466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2393373621466 : Closed e2393373621466 ∧ code e2393373621466 = 11189466643674 := by decide
theorem cert_e2393373621466 : check e2393373621466 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373621482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2393373621482 : Closed e2393373621482 ∧ code e2393373621482 = 11189466643690 := by decide
theorem cert_e2393373621482 : checkPay e2393373621482 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.right,.left,.left],[.right,.left],[.right],[.right,.left,.right,.right,.left,.left,.left],[.right,.left,.right,.right,.left,.left],[.right,.left,.right,.right,.left],[.right,.left,.right,.right,.left,.left,.left],[.right,.left,.right,.right,.left,.left],[.right,.left,.right,.right,.left],[.right,.left,.right,.right,.left,.left,.right,.right,.left,.left],[.right,.left,.right,.right,.left,.left,.right,.right,.left],[.right,.left,.right,.right,.left,.left,.right,.right]] = true := by decide
def e2393373621558 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373621558 : Closed e2393373621558 ∧ code e2393373621558 = 11189466643766 := by decide
theorem cert_e2393373621558 : checkPay e2393373621558 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2393373621562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373621562 : Closed e2393373621562 ∧ code e2393373621562 = 11189466643770 := by decide
theorem cert_e2393373621562 : checkPay e2393373621562 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.right]] = true := by decide
def e2393373621658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373621658 : Closed e2393373621658 ∧ code e2393373621658 = 11189466643866 := by decide
theorem cert_e2393373621658 : check e2393373621658 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373623262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))
theorem wire_e2393373623262 : Closed e2393373623262 ∧ code e2393373623262 = 11189466645470 := by decide
theorem cert_e2393373623262 : checkPay e2393373623262 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373623278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))
theorem wire_e2393373623278 : Closed e2393373623278 ∧ code e2393373623278 = 11189466645486 := by decide
theorem cert_e2393373623278 : checkPay e2393373623278 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2393373625110 : Closed e2393373625110 ∧ code e2393373625110 = 11189466647318 := by decide
theorem cert_e2393373625110 : check e2393373625110 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625186 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2393373625186 : Closed e2393373625186 ∧ code e2393373625186 = 11189466647394 := by decide
theorem cert_e2393373625186 : check e2393373625186 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393373625198 : Closed e2393373625198 ∧ code e2393373625198 = 11189466647406 := by decide
theorem cert_e2393373625198 : checkPay e2393373625198 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393373625206 : Closed e2393373625206 ∧ code e2393373625206 = 11189466647414 := by decide
theorem cert_e2393373625206 : checkPay e2393373625206 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373625226 : Closed e2393373625226 ∧ code e2393373625226 = 11189466647434 := by decide
theorem cert_e2393373625226 : check e2393373625226 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373625250 : Closed e2393373625250 ∧ code e2393373625250 = 11189466647458 := by decide
theorem cert_e2393373625250 : check e2393373625250 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625262 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393373625262 : Closed e2393373625262 ∧ code e2393373625262 = 11189466647470 := by decide
theorem cert_e2393373625262 : checkPay e2393373625262 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 1)))))))
theorem wire_e2393373625270 : Closed e2393373625270 ∧ code e2393373625270 = 11189466647478 := by decide
theorem cert_e2393373625270 : checkPay e2393373625270 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393373625274 : Closed e2393373625274 ∧ code e2393373625274 = 11189466647482 := by decide
theorem cert_e2393373625274 : checkPay e2393373625274 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393373625302 : Closed e2393373625302 ∧ code e2393373625302 = 11189466647510 := by decide
theorem cert_e2393373625302 : checkPay e2393373625302 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393373625306 : Closed e2393373625306 ∧ code e2393373625306 = 11189466647514 := by decide
theorem cert_e2393373625306 : checkPay e2393373625306 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.lam (.var 3)))))))))
theorem wire_e2393373625374 : Closed e2393373625374 ∧ code e2393373625374 = 11189466647582 := by decide
theorem cert_e2393373625374 : check e2393373625374 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2393373625570 : Closed e2393373625570 ∧ code e2393373625570 = 11189466647778 := by decide
theorem cert_e2393373625570 : check e2393373625570 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373625582 : Closed e2393373625582 ∧ code e2393373625582 = 11189466647790 := by decide
theorem cert_e2393373625582 : checkPay e2393373625582 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373625590 : Closed e2393373625590 ∧ code e2393373625590 = 11189466647798 := by decide
theorem cert_e2393373625590 : checkPay e2393373625590 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373625870 : Closed e2393373625870 ∧ code e2393373625870 = 11189466648078 := by decide
theorem cert_e2393373625870 : check e2393373625870 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373625882 : Closed e2393373625882 ∧ code e2393373625882 = 11189466648090 := by decide
theorem cert_e2393373625882 : checkPay e2393373625882 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373625954 : Closed e2393373625954 ∧ code e2393373625954 = 11189466648162 := by decide
theorem cert_e2393373625954 : check e2393373625954 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373625966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373625966 : Closed e2393373625966 ∧ code e2393373625966 = 11189466648174 := by decide
theorem cert_e2393373625966 : checkPay e2393373625966 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625974 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373625974 : Closed e2393373625974 ∧ code e2393373625974 = 11189466648182 := by decide
theorem cert_e2393373625974 : checkPay e2393373625974 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373625978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373625978 : Closed e2393373625978 ∧ code e2393373625978 = 11189466648186 := by decide
theorem cert_e2393373625978 : checkPay e2393373625978 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373626166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373626166 : Closed e2393373626166 ∧ code e2393373626166 = 11189466648374 := by decide
theorem cert_e2393373626166 : checkPay e2393373626166 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373626170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373626170 : Closed e2393373626170 ∧ code e2393373626170 = 11189466648378 := by decide
theorem cert_e2393373626170 : checkPay e2393373626170 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2393373630942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2393373630942 : Closed e2393373630942 ∧ code e2393373630942 = 11189466653150 := by decide
theorem cert_e2393373630942 : check e2393373630942 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373630966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2393373630966 : Closed e2393373630966 ∧ code e2393373630966 = 11189466653174 := by decide
theorem cert_e2393373630966 : check e2393373630966 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373631882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373631882 : Closed e2393373631882 ∧ code e2393373631882 = 11189466654090 := by decide
theorem cert_e2393373631882 : check e2393373631882 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373631906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373631906 : Closed e2393373631906 ∧ code e2393373631906 = 11189466654114 := by decide
theorem cert_e2393373631906 : check e2393373631906 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373631918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2393373631918 : Closed e2393373631918 ∧ code e2393373631918 = 11189466654126 := by decide
theorem cert_e2393373631918 : check e2393373631918 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373631926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2393373631926 : Closed e2393373631926 ∧ code e2393373631926 = 11189466654134 := by decide
theorem cert_e2393373631926 : check e2393373631926 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373631930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2393373631930 : Closed e2393373631930 ∧ code e2393373631930 = 11189466654138 := by decide
theorem cert_e2393373631930 : check e2393373631930 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373631958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2393373631958 : Closed e2393373631958 ∧ code e2393373631958 = 11189466654166 := by decide
theorem cert_e2393373631958 : check e2393373631958 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373631962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2393373631962 : Closed e2393373631962 ∧ code e2393373631962 = 11189466654170 := by decide
theorem cert_e2393373631962 : check e2393373631962 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373631978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2393373631978 : Closed e2393373631978 ∧ code e2393373631978 = 11189466654186 := by decide
theorem cert_e2393373631978 : check e2393373631978 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373632014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373632014 : Closed e2393373632014 ∧ code e2393373632014 = 11189466654222 := by decide
theorem cert_e2393373632014 : check e2393373632014 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373632026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373632026 : Closed e2393373632026 ∧ code e2393373632026 = 11189466654234 := by decide
theorem cert_e2393373632026 : check e2393373632026 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left]] .width = true := by decide
def e2393373632098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373632098 : Closed e2393373632098 ∧ code e2393373632098 = 11189466654306 := by decide
theorem cert_e2393373632098 : check e2393373632098 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373632110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373632110 : Closed e2393373632110 ∧ code e2393373632110 = 11189466654318 := by decide
theorem cert_e2393373632110 : check e2393373632110 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373632118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373632118 : Closed e2393373632118 ∧ code e2393373632118 = 11189466654326 := by decide
theorem cert_e2393373632118 : check e2393373632118 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373632122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373632122 : Closed e2393373632122 ∧ code e2393373632122 = 11189466654330 := by decide
theorem cert_e2393373632122 : check e2393373632122 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373632310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373632310 : Closed e2393373632310 ∧ code e2393373632310 = 11189466654518 := by decide
theorem cert_e2393373632310 : check e2393373632310 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373632314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373632314 : Closed e2393373632314 ∧ code e2393373632314 = 11189466654522 := by decide
theorem cert_e2393373632314 : check e2393373632314 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373632410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2393373632410 : Closed e2393373632410 ∧ code e2393373632410 = 11189466654618 := by decide
theorem cert_e2393373632410 : check e2393373632410 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373634798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2393373634798 : Closed e2393373634798 ∧ code e2393373634798 = 11189466657006 := by decide
private def t_e2393373634798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))
theorem cert_e2393373634798 : ¬ IsSelfInterpreter e2393373634798 :=
  wSource (t := t_e2393373634798) (replay_sound (ps := []) (t := e2393373634798) (by decide)) (by decide)
def e2393373634806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2393373634806 : Closed e2393373634806 ∧ code e2393373634806 = 11189466657014 := by decide
private def t_e2393373634806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))
theorem cert_e2393373634806 : ¬ IsSelfInterpreter e2393373634806 :=
  wSource (t := t_e2393373634806) (replay_sound (ps := []) (t := e2393373634806) (by decide)) (by decide)
def e2393373635286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2393373635286 : Closed e2393373635286 ∧ code e2393373635286 = 11189466657494 := by decide
private def t_e2393373635286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem cert_e2393373635286 : ¬ IsSelfInterpreter e2393373635286 :=
  wSource (t := t_e2393373635286) (replay_sound (ps := []) (t := e2393373635286) (by decide)) (by decide)
def e2393373635290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2393373635290 : Closed e2393373635290 ∧ code e2393373635290 = 11189466657498 := by decide
private def t_e2393373635290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem cert_e2393373635290 : ¬ IsSelfInterpreter e2393373635290 :=
  wSource (t := t_e2393373635290) (replay_sound (ps := []) (t := e2393373635290) (by decide)) (by decide)
def e2393373635306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2393373635306 : Closed e2393373635306 ∧ code e2393373635306 = 11189466657514 := by decide
private def t_e2393373635306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem cert_e2393373635306 : ¬ IsSelfInterpreter e2393373635306 :=
  wSource (t := t_e2393373635306) (replay_sound (ps := []) (t := e2393373635306) (by decide)) (by decide)
def e2393373635382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373635382 : Closed e2393373635382 ∧ code e2393373635382 = 11189466657590 := by decide
private def t_e2393373635382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem cert_e2393373635382 : ¬ IsSelfInterpreter e2393373635382 :=
  wSource (t := t_e2393373635382) (replay_sound (ps := []) (t := e2393373635382) (by decide)) (by decide)
def e2393373635386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373635386 : Closed e2393373635386 ∧ code e2393373635386 = 11189466657594 := by decide
private def t_e2393373635386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem cert_e2393373635386 : ¬ IsSelfInterpreter e2393373635386 :=
  wSource (t := t_e2393373635386) (replay_sound (ps := []) (t := e2393373635386) (by decide)) (by decide)
def e2393373635482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2393373635482 : Closed e2393373635482 ∧ code e2393373635482 = 11189466657690 := by decide
private def t_e2393373635482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem cert_e2393373635482 : ¬ IsSelfInterpreter e2393373635482 :=
  wSource (t := t_e2393373635482) (replay_sound (ps := []) (t := e2393373635482) (by decide)) (by decide)
def e2393373683166 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3)))))))))
theorem wire_e2393373683166 : Closed e2393373683166 ∧ code e2393373683166 = 11189466705374 := by decide
theorem cert_e2393373683166 : check e2393373683166 [[],[.left],[]] .chain = true := by decide
def e2393373683182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 2)))))))))
theorem wire_e2393373683182 : Closed e2393373683182 ∧ code e2393373683182 = 11189466705390 := by decide
theorem cert_e2393373683182 : check e2393373683182 [[],[.left],[]] .chain = true := by decide
def e2393373683550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 3)))))))))
theorem wire_e2393373683550 : Closed e2393373683550 ∧ code e2393373683550 = 11189466705758 := by decide
theorem cert_e2393373683550 : check e2393373683550 [[],[.left],[]] .chain = true := by decide
def e2393373683578 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 3)) (.var 0)))))))))
theorem wire_e2393373683578 : Closed e2393373683578 ∧ code e2393373683578 = 11189466705786 := by decide
theorem cert_e2393373683578 : check e2393373683578 [[],[.left],[]] .chain = true := by decide
def e2393373683630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 2)))))))))
theorem wire_e2393373683630 : Closed e2393373683630 ∧ code e2393373683630 = 11189466705838 := by decide
theorem cert_e2393373683630 : check e2393373683630 [[],[.left],[]] .chain = true := by decide
def e2393373683642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 2)) (.var 0)))))))))
theorem wire_e2393373683642 : Closed e2393373683642 ∧ code e2393373683642 = 11189466705850 := by decide
theorem cert_e2393373683642 : check e2393373683642 [[],[.left],[]] .chain = true := by decide
def e2393373684702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 3))))))))))
theorem wire_e2393373684702 : Closed e2393373684702 ∧ code e2393373684702 = 11189466706910 := by decide
theorem cert_e2393373684702 : check e2393373684702 [[],[.left],[]] .chain = true := by decide
def e2393373684718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 2))))))))))
theorem wire_e2393373684718 : Closed e2393373684718 ∧ code e2393373684718 = 11189466706926 := by decide
theorem cert_e2393373684718 : check e2393373684718 [[],[.left],[]] .chain = true := by decide
def e2393373687006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3))))))))))
theorem wire_e2393373687006 : Closed e2393373687006 ∧ code e2393373687006 = 11189466709214 := by decide
theorem cert_e2393373687006 : check e2393373687006 [[],[.left],[]] .chain = true := by decide
def e2393373687034 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0))))))))))
theorem wire_e2393373687034 : Closed e2393373687034 ∧ code e2393373687034 = 11189466709242 := by decide
theorem cert_e2393373687034 : check e2393373687034 [[],[.left],[]] .chain = true := by decide
def e2393373687406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393373687406 : Closed e2393373687406 ∧ code e2393373687406 = 11189466709614 := by decide
theorem cert_e2393373687406 : check e2393373687406 [[],[.left],[]] .chain = true := by decide
def e2393373687418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393373687418 : Closed e2393373687418 ∧ code e2393373687418 = 11189466709626 := by decide
theorem cert_e2393373687418 : check e2393373687418 [[],[.left],[]] .chain = true := by decide
def e2393373715822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2393373715822 : Closed e2393373715822 ∧ code e2393373715822 = 11189466738030 := by decide
theorem cert_e2393373715822 : check e2393373715822 [[],[.left],[]] .chain = true := by decide
def e2393373715830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2393373715830 : Closed e2393373715830 ∧ code e2393373715830 = 11189466738038 := by decide
theorem cert_e2393373715830 : check e2393373715830 [[],[.left],[]] .chain = true := by decide
def e2393373715886 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2393373715886 : Closed e2393373715886 ∧ code e2393373715886 = 11189466738094 := by decide
theorem cert_e2393373715886 : check e2393373715886 [[],[.left],[]] .chain = true := by decide
def e2393373715898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2393373715898 : Closed e2393373715898 ∧ code e2393373715898 = 11189466738106 := by decide
theorem cert_e2393373715898 : check e2393373715898 [[],[.left],[]] .chain = true := by decide
def e2393373715926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2393373715926 : Closed e2393373715926 ∧ code e2393373715926 = 11189466738134 := by decide
theorem cert_e2393373715926 : check e2393373715926 [[],[.left],[]] .chain = true := by decide
def e2393373715930 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2393373715930 : Closed e2393373715930 ∧ code e2393373715930 = 11189466738138 := by decide
theorem cert_e2393373715930 : check e2393373715930 [[],[.left],[]] .chain = true := by decide
def e2393373716142 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2393373716142 : Closed e2393373716142 ∧ code e2393373716142 = 11189466738350 := by decide
theorem cert_e2393373716142 : check e2393373716142 [[],[.left],[]] .chain = true := by decide
def e2393373716154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2393373716154 : Closed e2393373716154 ∧ code e2393373716154 = 11189466738362 := by decide
theorem cert_e2393373716154 : check e2393373716154 [[],[.left],[]] .chain = true := by decide
def e2393373716202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2393373716202 : Closed e2393373716202 ∧ code e2393373716202 = 11189466738410 := by decide
theorem cert_e2393373716202 : check e2393373716202 [[],[.left],[]] .chain = true := by decide
def e2393373716310 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2393373716310 : Closed e2393373716310 ∧ code e2393373716310 = 11189466738518 := by decide
theorem cert_e2393373716310 : check e2393373716310 [[],[.left],[]] .chain = true := by decide
def e2393373716314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2393373716314 : Closed e2393373716314 ∧ code e2393373716314 = 11189466738522 := by decide
theorem cert_e2393373716314 : check e2393373716314 [[],[.left],[]] .chain = true := by decide
def e2393373716330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2393373716330 : Closed e2393373716330 ∧ code e2393373716330 = 11189466738538 := by decide
theorem cert_e2393373716330 : check e2393373716330 [[],[.left],[]] .chain = true := by decide
def e2393373716958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))))
theorem wire_e2393373716958 : Closed e2393373716958 ∧ code e2393373716958 = 11189466739166 := by decide
theorem cert_e2393373716958 : check e2393373716958 [[],[.left],[]] .chain = true := by decide
def e2393373716982 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))))
theorem wire_e2393373716982 : Closed e2393373716982 ∧ code e2393373716982 = 11189466739190 := by decide
theorem cert_e2393373716982 : check e2393373716982 [[],[.left],[]] .chain = true := by decide
def e2393373717358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e2393373717358 : Closed e2393373717358 ∧ code e2393373717358 = 11189466739566 := by decide
theorem cert_e2393373717358 : check e2393373717358 [[],[.left],[]] .chain = true := by decide
def e2393373717366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e2393373717366 : Closed e2393373717366 ∧ code e2393373717366 = 11189466739574 := by decide
theorem cert_e2393373717366 : check e2393373717366 [[],[.left],[]] .chain = true := by decide
def e2393373717422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e2393373717422 : Closed e2393373717422 ∧ code e2393373717422 = 11189466739630 := by decide
theorem cert_e2393373717422 : check e2393373717422 [[],[.left],[]] .chain = true := by decide
def e2393373717434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e2393373717434 : Closed e2393373717434 ∧ code e2393373717434 = 11189466739642 := by decide
theorem cert_e2393373717434 : check e2393373717434 [[],[.left],[]] .chain = true := by decide
def e2393373717462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e2393373717462 : Closed e2393373717462 ∧ code e2393373717462 = 11189466739670 := by decide
theorem cert_e2393373717462 : check e2393373717462 [[],[.left],[]] .chain = true := by decide
def e2393373717466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e2393373717466 : Closed e2393373717466 ∧ code e2393373717466 = 11189466739674 := by decide
theorem cert_e2393373717466 : check e2393373717466 [[],[.left],[]] .chain = true := by decide
def e2393373717742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2393373717742 : Closed e2393373717742 ∧ code e2393373717742 = 11189466739950 := by decide
theorem cert_e2393373717742 : check e2393373717742 [[],[.left],[]] .chain = true := by decide
def e2393373717750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2393373717750 : Closed e2393373717750 ∧ code e2393373717750 = 11189466739958 := by decide
theorem cert_e2393373717750 : check e2393373717750 [[],[.left],[]] .chain = true := by decide
def e2393373718078 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))))
theorem wire_e2393373718078 : Closed e2393373718078 ∧ code e2393373718078 = 11189466740286 := by decide
theorem cert_e2393373718078 : check e2393373718078 [[],[.left],[]] .chain = true := by decide
def e2393373718126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393373718126 : Closed e2393373718126 ∧ code e2393373718126 = 11189466740334 := by decide
theorem cert_e2393373718126 : check e2393373718126 [[],[.left],[]] .chain = true := by decide
def e2393373718138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393373718138 : Closed e2393373718138 ∧ code e2393373718138 = 11189466740346 := by decide
theorem cert_e2393373718138 : check e2393373718138 [[],[.left],[]] .chain = true := by decide
def e2393373718326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393373718326 : Closed e2393373718326 ∧ code e2393373718326 = 11189466740534 := by decide
theorem cert_e2393373718326 : check e2393373718326 [[],[.left],[]] .chain = true := by decide
def e2393373718330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393373718330 : Closed e2393373718330 ∧ code e2393373718330 = 11189466740538 := by decide
theorem cert_e2393373718330 : check e2393373718330 [[],[.left],[]] .chain = true := by decide
def e2393373718414 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 2)))))))))
theorem wire_e2393373718414 : Closed e2393373718414 ∧ code e2393373718414 = 11189466740622 := by decide
theorem cert_e2393373718414 : check e2393373718414 [[],[.left],[]] .chain = true := by decide
def e2393373718750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 3))))))))
theorem wire_e2393373718750 : Closed e2393373718750 ∧ code e2393373718750 = 11189466740958 := by decide
theorem cert_e2393373718750 : check e2393373718750 [[],[.left],[]] .chain = true := by decide
def e2393373718778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 0))))))))
theorem wire_e2393373718778 : Closed e2393373718778 ∧ code e2393373718778 = 11189466740986 := by decide
theorem cert_e2393373718778 : check e2393373718778 [[],[.left],[]] .chain = true := by decide
def e2393373718958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e2393373718958 : Closed e2393373718958 ∧ code e2393373718958 = 11189466741166 := by decide
theorem cert_e2393373718958 : check e2393373718958 [[],[.left],[]] .chain = true := by decide
def e2393373718970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e2393373718970 : Closed e2393373718970 ∧ code e2393373718970 = 11189466741178 := by decide
theorem cert_e2393373718970 : check e2393373718970 [[],[.left],[]] .chain = true := by decide
def e2393373719018 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e2393373719018 : Closed e2393373719018 ∧ code e2393373719018 = 11189466741226 := by decide
theorem cert_e2393373719018 : check e2393373719018 [[],[.left],[]] .chain = true := by decide
def e2393373719102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 4)))))))))
theorem wire_e2393373719102 : Closed e2393373719102 ∧ code e2393373719102 = 11189466741310 := by decide
theorem cert_e2393373719102 : check e2393373719102 [[],[.left],[]] .chain = true := by decide
def e2393373719150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393373719150 : Closed e2393373719150 ∧ code e2393373719150 = 11189466741358 := by decide
theorem cert_e2393373719150 : check e2393373719150 [[],[.left],[]] .chain = true := by decide
def e2393373719162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393373719162 : Closed e2393373719162 ∧ code e2393373719162 = 11189466741370 := by decide
theorem cert_e2393373719162 : check e2393373719162 [[],[.left],[]] .chain = true := by decide
def e2393373719450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373719450 : Closed e2393373719450 ∧ code e2393373719450 = 11189466741658 := by decide
theorem cert_e2393373719450 : check e2393373719450 [[],[.left],[]] .chain = true := by decide
def e2393373719494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 1)))))))))
theorem wire_e2393373719494 : Closed e2393373719494 ∧ code e2393373719494 = 11189466741702 := by decide
theorem cert_e2393373719494 : check e2393373719494 [[],[.left],[]] .chain = true := by decide
def e2393373719766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2393373719766 : Closed e2393373719766 ∧ code e2393373719766 = 11189466741974 := by decide
theorem cert_e2393373719766 : check e2393373719766 [[],[.left],[]] .chain = true := by decide
def e2393373719770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2393373719770 : Closed e2393373719770 ∧ code e2393373719770 = 11189466741978 := by decide
theorem cert_e2393373719770 : check e2393373719770 [[],[.left],[]] .chain = true := by decide
def e2393373719786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2393373719786 : Closed e2393373719786 ∧ code e2393373719786 = 11189466741994 := by decide
theorem cert_e2393373719786 : check e2393373719786 [[],[.left],[]] .chain = true := by decide
def e2393373719862 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393373719862 : Closed e2393373719862 ∧ code e2393373719862 = 11189466742070 := by decide
theorem cert_e2393373719862 : check e2393373719862 [[],[.left],[]] .chain = true := by decide
def e2393373719866 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393373719866 : Closed e2393373719866 ∧ code e2393373719866 = 11189466742074 := by decide
theorem cert_e2393373719866 : check e2393373719866 [[],[.left],[]] .chain = true := by decide
def e2393373719962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373719962 : Closed e2393373719962 ∧ code e2393373719962 = 11189466742170 := by decide
theorem cert_e2393373719962 : check e2393373719962 [[],[.left],[]] .chain = true := by decide
def e2393373720030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 2)) (.var 3))))))))
theorem wire_e2393373720030 : Closed e2393373720030 ∧ code e2393373720030 = 11189466742238 := by decide
theorem cert_e2393373720030 : check e2393373720030 [[],[.left],[]] .sourceHead = true := by decide
def e2393373720046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 3)) (.var 2))))))))
theorem wire_e2393373720046 : Closed e2393373720046 ∧ code e2393373720046 = 11189466742254 := by decide
theorem cert_e2393373720046 : check e2393373720046 [[],[.left],[]] .sourceHead = true := by decide
def e2393373720118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2393373720118 : Closed e2393373720118 ∧ code e2393373720118 = 11189466742326 := by decide
theorem cert_e2393373720118 : check e2393373720118 [[],[.left],[]] .chain = true := by decide
def e2393373720122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2393373720122 : Closed e2393373720122 ∧ code e2393373720122 = 11189466742330 := by decide
theorem cert_e2393373720122 : check e2393373720122 [[],[.left],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393373634798
#print axioms Blc.Floor43.cert_e2393373634806
#print axioms Blc.Floor43.cert_e2393373635286
#print axioms Blc.Floor43.cert_e2393373635290
#print axioms Blc.Floor43.cert_e2393373635306
#print axioms Blc.Floor43.cert_e2393373635382
#print axioms Blc.Floor43.cert_e2393373635386
#print axioms Blc.Floor43.cert_e2393373635482
