import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411632096890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2411632096890 : Closed e2411632096890 ∧ code e2411632096890 = 11207725119098 := by decide
theorem cert_e2411632096890 : check e2411632096890 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632097078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411632097078 : Closed e2411632097078 ∧ code e2411632097078 = 11207725119286 := by decide
theorem cert_e2411632097078 : check e2411632097078 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632097082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411632097082 : Closed e2411632097082 ∧ code e2411632097082 = 11207725119290 := by decide
theorem cert_e2411632097082 : check e2411632097082 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632097718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2411632097718 : Closed e2411632097718 ∧ code e2411632097718 = 11207725119926 := by decide
theorem cert_e2411632097718 : check e2411632097718 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632097750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2411632097750 : Closed e2411632097750 ∧ code e2411632097750 = 11207725119958 := by decide
theorem cert_e2411632097750 : check e2411632097750 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632097754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2411632097754 : Closed e2411632097754 ∧ code e2411632097754 = 11207725119962 := by decide
theorem cert_e2411632097754 : check e2411632097754 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632097910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2411632097910 : Closed e2411632097910 ∧ code e2411632097910 = 11207725120118 := by decide
theorem cert_e2411632097910 : check e2411632097910 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632098102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2411632098102 : Closed e2411632098102 ∧ code e2411632098102 = 11207725120310 := by decide
theorem cert_e2411632098102 : check e2411632098102 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632098106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2411632098106 : Closed e2411632098106 ∧ code e2411632098106 = 11207725120314 := by decide
theorem cert_e2411632098106 : check e2411632098106 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632100782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e2411632100782 : Closed e2411632100782 ∧ code e2411632100782 = 11207725122990 := by decide
theorem cert_e2411632100782 : check e2411632100782 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632100794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e2411632100794 : Closed e2411632100794 ∧ code e2411632100794 = 11207725123002 := by decide
theorem cert_e2411632100794 : check e2411632100794 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632100842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e2411632100842 : Closed e2411632100842 ∧ code e2411632100842 = 11207725123050 := by decide
theorem cert_e2411632100842 : check e2411632100842 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632100974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e2411632100974 : Closed e2411632100974 ∧ code e2411632100974 = 11207725123182 := by decide
theorem cert_e2411632100974 : check e2411632100974 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632100986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e2411632100986 : Closed e2411632100986 ∧ code e2411632100986 = 11207725123194 := by decide
theorem cert_e2411632100986 : check e2411632100986 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632101150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2411632101150 : Closed e2411632101150 ∧ code e2411632101150 = 11207725123358 := by decide
theorem cert_e2411632101150 : check e2411632101150 [[],[]] .chain = true := by decide
def e2411632101262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2411632101262 : Closed e2411632101262 ∧ code e2411632101262 = 11207725123470 := by decide
theorem cert_e2411632101262 : check e2411632101262 [[],[]] .chain = true := by decide
def e2411632101274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411632101274 : Closed e2411632101274 ∧ code e2411632101274 = 11207725123482 := by decide
theorem cert_e2411632101274 : check e2411632101274 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632105014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2411632105014 : Closed e2411632105014 ∧ code e2411632105014 = 11207725127222 := by decide
theorem cert_e2411632105014 : check e2411632105014 [[],[]] .chain = true := by decide
def e2411632105018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2411632105018 : Closed e2411632105018 ∧ code e2411632105018 = 11207725127226 := by decide
theorem cert_e2411632105018 : check e2411632105018 [[],[]] .chain = true := by decide
def e2411632105102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2411632105102 : Closed e2411632105102 ∧ code e2411632105102 = 11207725127310 := by decide
theorem cert_e2411632105102 : check e2411632105102 [[],[]] .chain = true := by decide
def e2411632105158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2411632105158 : Closed e2411632105158 ∧ code e2411632105158 = 11207725127366 := by decide
theorem cert_e2411632105158 : check e2411632105158 [[],[]] .chain = true := by decide
def e2411632105238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411632105238 : Closed e2411632105238 ∧ code e2411632105238 = 11207725127446 := by decide
theorem cert_e2411632105238 : check e2411632105238 [[],[]] .chain = true := by decide
def e2411632105242 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411632105242 : Closed e2411632105242 ∧ code e2411632105242 = 11207725127450 := by decide
theorem cert_e2411632105242 : check e2411632105242 [[],[]] .chain = true := by decide
def e2411632105286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411632105286 : Closed e2411632105286 ∧ code e2411632105286 = 11207725127494 := by decide
theorem cert_e2411632105286 : check e2411632105286 [[],[]] .chain = true := by decide
def e2411632105314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411632105314 : Closed e2411632105314 ∧ code e2411632105314 = 11207725127522 := by decide
theorem cert_e2411632105314 : check e2411632105314 [[],[]] .chain = true := by decide
def e2411632105326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2411632105326 : Closed e2411632105326 ∧ code e2411632105326 = 11207725127534 := by decide
theorem cert_e2411632105326 : check e2411632105326 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632105334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2411632105334 : Closed e2411632105334 ∧ code e2411632105334 = 11207725127542 := by decide
theorem cert_e2411632105334 : check e2411632105334 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632105398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2411632105398 : Closed e2411632105398 ∧ code e2411632105398 = 11207725127606 := by decide
theorem cert_e2411632105398 : check e2411632105398 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632105582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2411632105582 : Closed e2411632105582 ∧ code e2411632105582 = 11207725127790 := by decide
theorem cert_e2411632105582 : check e2411632105582 [[],[]] .chain = true := by decide
def e2411632105594 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2411632105594 : Closed e2411632105594 ∧ code e2411632105594 = 11207725127802 := by decide
theorem cert_e2411632105594 : check e2411632105594 [[],[]] .chain = true := by decide
def e2411632105870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2411632105870 : Closed e2411632105870 ∧ code e2411632105870 = 11207725128078 := by decide
theorem cert_e2411632105870 : check e2411632105870 [[],[]] .chain = true := by decide
def e2411632105926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2411632105926 : Closed e2411632105926 ∧ code e2411632105926 = 11207725128134 := by decide
theorem cert_e2411632105926 : check e2411632105926 [[],[]] .chain = true := by decide
def e2411632106526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 3))))))))))
theorem wire_e2411632106526 : Closed e2411632106526 ∧ code e2411632106526 = 11207725128734 := by decide
theorem cert_e2411632106526 : check e2411632106526 [[],[]] .chain = true := by decide
def e2411632106550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411632106550 : Closed e2411632106550 ∧ code e2411632106550 = 11207725128758 := by decide
theorem cert_e2411632106550 : check e2411632106550 [[],[]] .chain = true := by decide
def e2411632106554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411632106554 : Closed e2411632106554 ∧ code e2411632106554 = 11207725128762 := by decide
theorem cert_e2411632106554 : check e2411632106554 [[],[]] .chain = true := by decide
def e2411632106694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411632106694 : Closed e2411632106694 ∧ code e2411632106694 = 11207725128902 := by decide
theorem cert_e2411632106694 : check e2411632106694 [[],[]] .chain = true := by decide
def e2411632106722 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411632106722 : Closed e2411632106722 ∧ code e2411632106722 = 11207725128930 := by decide
theorem cert_e2411632106722 : check e2411632106722 [[],[]] .chain = true := by decide
def e2411632106734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411632106734 : Closed e2411632106734 ∧ code e2411632106734 = 11207725128942 := by decide
theorem cert_e2411632106734 : check e2411632106734 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632106742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411632106742 : Closed e2411632106742 ∧ code e2411632106742 = 11207725128950 := by decide
theorem cert_e2411632106742 : check e2411632106742 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632107126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411632107126 : Closed e2411632107126 ∧ code e2411632107126 = 11207725129334 := by decide
theorem cert_e2411632107126 : check e2411632107126 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632116438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2411632116438 : Closed e2411632116438 ∧ code e2411632116438 = 11207725138646 := by decide
theorem cert_e2411632116438 : check e2411632116438 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632116442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2411632116442 : Closed e2411632116442 ∧ code e2411632116442 = 11207725138650 := by decide
theorem cert_e2411632116442 : check e2411632116442 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632116458 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2411632116458 : Closed e2411632116458 ∧ code e2411632116458 = 11207725138666 := by decide
theorem cert_e2411632116458 : check e2411632116458 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632116534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2411632116534 : Closed e2411632116534 ∧ code e2411632116534 = 11207725138742 := by decide
theorem cert_e2411632116534 : check e2411632116534 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632116538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2411632116538 : Closed e2411632116538 ∧ code e2411632116538 = 11207725138746 := by decide
theorem cert_e2411632116538 : check e2411632116538 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632116622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2411632116622 : Closed e2411632116622 ∧ code e2411632116622 = 11207725138830 := by decide
theorem cert_e2411632116622 : check e2411632116622 [[],[]] .chain = true := by decide
def e2411632116634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2411632116634 : Closed e2411632116634 ∧ code e2411632116634 = 11207725138842 := by decide
theorem cert_e2411632116634 : check e2411632116634 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632118550 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2411632118550 : Closed e2411632118550 ∧ code e2411632118550 = 11207725140758 := by decide
theorem cert_e2411632118550 : check e2411632118550 [[],[]] .chain = true := by decide
def e2411632118554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2411632118554 : Closed e2411632118554 ∧ code e2411632118554 = 11207725140762 := by decide
theorem cert_e2411632118554 : check e2411632118554 [[],[]] .chain = true := by decide
def e2411632118598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2411632118598 : Closed e2411632118598 ∧ code e2411632118598 = 11207725140806 := by decide
theorem cert_e2411632118598 : check e2411632118598 [[],[]] .chain = true := by decide
def e2411632118626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2411632118626 : Closed e2411632118626 ∧ code e2411632118626 = 11207725140834 := by decide
theorem cert_e2411632118626 : check e2411632118626 [[],[]] .chain = true := by decide
def e2411632118638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411632118638 : Closed e2411632118638 ∧ code e2411632118638 = 11207725140846 := by decide
theorem cert_e2411632118638 : check e2411632118638 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632118646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411632118646 : Closed e2411632118646 ∧ code e2411632118646 = 11207725140854 := by decide
theorem cert_e2411632118646 : check e2411632118646 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632118666 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2411632118666 : Closed e2411632118666 ∧ code e2411632118666 = 11207725140874 := by decide
theorem cert_e2411632118666 : check e2411632118666 [[],[]] .chain = true := by decide
def e2411632118690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2411632118690 : Closed e2411632118690 ∧ code e2411632118690 = 11207725140898 := by decide
theorem cert_e2411632118690 : check e2411632118690 [[],[]] .chain = true := by decide
def e2411632118702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411632118702 : Closed e2411632118702 ∧ code e2411632118702 = 11207725140910 := by decide
theorem cert_e2411632118702 : check e2411632118702 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632118714 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411632118714 : Closed e2411632118714 ∧ code e2411632118714 = 11207725140922 := by decide
theorem cert_e2411632118714 : check e2411632118714 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632118742 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411632118742 : Closed e2411632118742 ∧ code e2411632118742 = 11207725140950 := by decide
theorem cert_e2411632118742 : check e2411632118742 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632118746 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411632118746 : Closed e2411632118746 ∧ code e2411632118746 = 11207725140954 := by decide
theorem cert_e2411632118746 : check e2411632118746 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632118814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2411632118814 : Closed e2411632118814 ∧ code e2411632118814 = 11207725141022 := by decide
theorem cert_e2411632118814 : check e2411632118814 [[],[]] .chain = true := by decide
def e2411632118838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2411632118838 : Closed e2411632118838 ∧ code e2411632118838 = 11207725141046 := by decide
theorem cert_e2411632118838 : check e2411632118838 [[],[]] .chain = true := by decide
def e2411632118842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2411632118842 : Closed e2411632118842 ∧ code e2411632118842 = 11207725141050 := by decide
theorem cert_e2411632118842 : check e2411632118842 [[],[]] .chain = true := by decide
def e2411632118982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2411632118982 : Closed e2411632118982 ∧ code e2411632118982 = 11207725141190 := by decide
theorem cert_e2411632118982 : check e2411632118982 [[],[]] .chain = true := by decide
def e2411632119010 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2411632119010 : Closed e2411632119010 ∧ code e2411632119010 = 11207725141218 := by decide
theorem cert_e2411632119010 : check e2411632119010 [[],[]] .chain = true := by decide
def e2411632119022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411632119022 : Closed e2411632119022 ∧ code e2411632119022 = 11207725141230 := by decide
theorem cert_e2411632119022 : check e2411632119022 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632119030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411632119030 : Closed e2411632119030 ∧ code e2411632119030 = 11207725141238 := by decide
theorem cert_e2411632119030 : check e2411632119030 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632119310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2411632119310 : Closed e2411632119310 ∧ code e2411632119310 = 11207725141518 := by decide
theorem cert_e2411632119310 : check e2411632119310 [[],[]] .chain = true := by decide
def e2411632119394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2411632119394 : Closed e2411632119394 ∧ code e2411632119394 = 11207725141602 := by decide
theorem cert_e2411632119394 : check e2411632119394 [[],[]] .chain = true := by decide
def e2411632119406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411632119406 : Closed e2411632119406 ∧ code e2411632119406 = 11207725141614 := by decide
theorem cert_e2411632119406 : check e2411632119406 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632119418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411632119418 : Closed e2411632119418 ∧ code e2411632119418 = 11207725141626 := by decide
theorem cert_e2411632119418 : check e2411632119418 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632119606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411632119606 : Closed e2411632119606 ∧ code e2411632119606 = 11207725141814 := by decide
theorem cert_e2411632119606 : check e2411632119606 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632119610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411632119610 : Closed e2411632119610 ∧ code e2411632119610 = 11207725141818 := by decide
theorem cert_e2411632119610 : check e2411632119610 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632125366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))
theorem wire_e2411632125366 : Closed e2411632125366 ∧ code e2411632125366 = 11207725147574 := by decide
theorem cert_e2411632125366 : check e2411632125366 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632125398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))
theorem wire_e2411632125398 : Closed e2411632125398 ∧ code e2411632125398 = 11207725147606 := by decide
theorem cert_e2411632125398 : check e2411632125398 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632125402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))
theorem wire_e2411632125402 : Closed e2411632125402 ∧ code e2411632125402 = 11207725147610 := by decide
theorem cert_e2411632125402 : check e2411632125402 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632125558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))
theorem wire_e2411632125558 : Closed e2411632125558 ∧ code e2411632125558 = 11207725147766 := by decide
theorem cert_e2411632125558 : check e2411632125558 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632125750 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411632125750 : Closed e2411632125750 ∧ code e2411632125750 = 11207725147958 := by decide
theorem cert_e2411632125750 : check e2411632125750 [[],[],[.under,.under]] .smaller = true := by decide
def e2411632125754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411632125754 : Closed e2411632125754 ∧ code e2411632125754 = 11207725147962 := by decide
theorem cert_e2411632125754 : check e2411632125754 [[],[],[.under,.under]] .smaller = true := by decide
def e2411647228790 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1)))))
theorem wire_e2411647228790 : Closed e2411647228790 ∧ code e2411647228790 = 11207740250998 := by decide
theorem cert_e2411647228790 : check e2411647228790 [[],[]] .chain = true := by decide
def e2411647228794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))) (.var 0)))))
theorem wire_e2411647228794 : Closed e2411647228794 ∧ code e2411647228794 = 11207740251002 := by decide
theorem cert_e2411647228794 : check e2411647228794 [[],[]] .chain = true := by decide
def e2411647228854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1)))))
theorem wire_e2411647228854 : Closed e2411647228854 ∧ code e2411647228854 = 11207740251062 := by decide
theorem cert_e2411647228854 : check e2411647228854 [[],[]] .chain = true := by decide
def e2411647228890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))) (.var 0)))))
theorem wire_e2411647228890 : Closed e2411647228890 ∧ code e2411647228890 = 11207740251098 := by decide
theorem cert_e2411647228890 : check e2411647228890 [[],[]] .chain = true := by decide
def e2411647229302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1)))))
theorem wire_e2411647229302 : Closed e2411647229302 ∧ code e2411647229302 = 11207740251510 := by decide
theorem cert_e2411647229302 : check e2411647229302 [[],[]] .chain = true := by decide
def e2411647229306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))) (.var 0)))))
theorem wire_e2411647229306 : Closed e2411647229306 ∧ code e2411647229306 = 11207740251514 := by decide
theorem cert_e2411647229306 : check e2411647229306 [[],[]] .chain = true := by decide
def e2411647229398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1)))))
theorem wire_e2411647229398 : Closed e2411647229398 ∧ code e2411647229398 = 11207740251606 := by decide
theorem cert_e2411647229398 : check e2411647229398 [[],[]] .chain = true := by decide
def e2411647229418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))) (.var 0)))))
theorem wire_e2411647229418 : Closed e2411647229418 ∧ code e2411647229418 = 11207740251626 := by decide
theorem cert_e2411647229418 : check e2411647229418 [[],[]] .chain = true := by decide
def e2411647229622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1)))))
theorem wire_e2411647229622 : Closed e2411647229622 ∧ code e2411647229622 = 11207740251830 := by decide
theorem cert_e2411647229622 : check e2411647229622 [[],[]] .chain = true := by decide
def e2411647229654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1)))))
theorem wire_e2411647229654 : Closed e2411647229654 ∧ code e2411647229654 = 11207740251862 := by decide
theorem cert_e2411647229654 : check e2411647229654 [[],[]] .chain = true := by decide
def e2411647229786 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))) (.var 0)))))
theorem wire_e2411647229786 : Closed e2411647229786 ∧ code e2411647229786 = 11207740251994 := by decide
theorem cert_e2411647229786 : check e2411647229786 [[],[]] .chain = true := by decide
def e2411647229802 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))) (.var 0)))))
theorem wire_e2411647229802 : Closed e2411647229802 ∧ code e2411647229802 = 11207740252010 := by decide
theorem cert_e2411647229802 : check e2411647229802 [[],[]] .chain = true := by decide
def e2411647231862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1)))))
theorem wire_e2411647231862 : Closed e2411647231862 ∧ code e2411647231862 = 11207740254070 := by decide
theorem cert_e2411647231862 : check e2411647231862 [[],[]] .chain = true := by decide
def e2411647231866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))) (.var 0)))))
theorem wire_e2411647231866 : Closed e2411647231866 ∧ code e2411647231866 = 11207740254074 := by decide
theorem cert_e2411647231866 : check e2411647231866 [[],[]] .chain = true := by decide
def e2411647231926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1)))))
theorem wire_e2411647231926 : Closed e2411647231926 ∧ code e2411647231926 = 11207740254134 := by decide
theorem cert_e2411647231926 : check e2411647231926 [[],[]] .chain = true := by decide
def e2411647231962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))) (.var 0)))))
theorem wire_e2411647231962 : Closed e2411647231962 ∧ code e2411647231962 = 11207740254170 := by decide
theorem cert_e2411647231962 : check e2411647231962 [[],[]] .chain = true := by decide
def e2411647234934 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1)))))
theorem wire_e2411647234934 : Closed e2411647234934 ∧ code e2411647234934 = 11207740257142 := by decide
theorem cert_e2411647234934 : check e2411647234934 [[],[]] .chain = true := by decide
def e2411647234938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))) (.var 0)))))
theorem wire_e2411647234938 : Closed e2411647234938 ∧ code e2411647234938 = 11207740257146 := by decide
theorem cert_e2411647234938 : check e2411647234938 [[],[]] .chain = true := by decide
def e2411647235030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1)))))
theorem wire_e2411647235030 : Closed e2411647235030 ∧ code e2411647235030 = 11207740257238 := by decide
theorem cert_e2411647235030 : check e2411647235030 [[],[]] .chain = true := by decide
def e2411647235050 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))) (.var 0)))))
theorem wire_e2411647235050 : Closed e2411647235050 ∧ code e2411647235050 = 11207740257258 := by decide
theorem cert_e2411647235050 : check e2411647235050 [[],[]] .chain = true := by decide
def e2411647236534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1)))))
theorem wire_e2411647236534 : Closed e2411647236534 ∧ code e2411647236534 = 11207740258742 := by decide
theorem cert_e2411647236534 : check e2411647236534 [[],[]] .chain = true := by decide
def e2411647236566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1)))))
theorem wire_e2411647236566 : Closed e2411647236566 ∧ code e2411647236566 = 11207740258774 := by decide
theorem cert_e2411647236566 : check e2411647236566 [[],[]] .chain = true := by decide
def e2411647237338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))) (.var 0)))))
theorem wire_e2411647237338 : Closed e2411647237338 ∧ code e2411647237338 = 11207740259546 := by decide
theorem cert_e2411647237338 : check e2411647237338 [[],[]] .chain = true := by decide
def e2411647237354 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))) (.var 0)))))
theorem wire_e2411647237354 : Closed e2411647237354 ∧ code e2411647237354 = 11207740259562 := by decide
theorem cert_e2411647237354 : check e2411647237354 [[],[]] .chain = true := by decide
def e2411647296442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))) (.var 0)))))
theorem wire_e2411647296442 : Closed e2411647296442 ∧ code e2411647296442 = 11207740318650 := by decide
theorem cert_e2411647296442 : check e2411647296442 [[],[]] .chain = true := by decide
def e2411647296474 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))) (.var 0)))))
theorem wire_e2411647296474 : Closed e2411647296474 ∧ code e2411647296474 = 11207740318682 := by decide
theorem cert_e2411647296474 : check e2411647296474 [[],[]] .chain = true := by decide
def e2411647298682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))) (.var 0)))))
theorem wire_e2411647298682 : Closed e2411647298682 ∧ code e2411647298682 = 11207740320890 := by decide
theorem cert_e2411647298682 : check e2411647298682 [[],[]] .chain = true := by decide
def e2411647299014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.lam (.var 1))))))
theorem wire_e2411647299014 : Closed e2411647299014 ∧ code e2411647299014 = 11207740321222 := by decide
theorem cert_e2411647299014 : check e2411647299014 [[],[]] .chain = true := by decide
def e2411647299130 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))) (.var 0)))))
theorem wire_e2411647299130 : Closed e2411647299130 ∧ code e2411647299130 = 11207740321338 := by decide
theorem cert_e2411647299130 : check e2411647299130 [[],[]] .chain = true := by decide
def e2411647299270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.lam (.var 1))))))
theorem wire_e2411647299270 : Closed e2411647299270 ∧ code e2411647299270 = 11207740321478 := by decide
theorem cert_e2411647299270 : check e2411647299270 [[],[]] .chain = true := by decide
def e2411647300026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))) (.var 0)))))
theorem wire_e2411647300026 : Closed e2411647300026 ∧ code e2411647300026 = 11207740322234 := by decide
theorem cert_e2411647300026 : check e2411647300026 [[],[]] .chain = true := by decide
def e2411647300074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))) (.var 0)))))
theorem wire_e2411647300074 : Closed e2411647300074 ∧ code e2411647300074 = 11207740322282 := by decide
theorem cert_e2411647300074 : check e2411647300074 [[],[]] .chain = true := by decide
def e2411647300730 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))) (.var 0)))))
theorem wire_e2411647300730 : Closed e2411647300730 ∧ code e2411647300730 = 11207740322938 := by decide
theorem cert_e2411647300730 : check e2411647300730 [[],[]] .chain = true := by decide
def e2411647301062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.lam (.var 1))))))
theorem wire_e2411647301062 : Closed e2411647301062 ∧ code e2411647301062 = 11207740323270 := by decide
theorem cert_e2411647301062 : check e2411647301062 [[],[]] .chain = true := by decide
def e2411647301402 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))) (.var 0)))))
theorem wire_e2411647301402 : Closed e2411647301402 ∧ code e2411647301402 = 11207740323610 := by decide
theorem cert_e2411647301402 : check e2411647301402 [[],[]] .chain = true := by decide
def e2411647301446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.lam (.var 1))))))
theorem wire_e2411647301446 : Closed e2411647301446 ∧ code e2411647301446 = 11207740323654 := by decide
theorem cert_e2411647301446 : check e2411647301446 [[],[]] .chain = true := by decide
def e2411647301850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))) (.var 0)))))
theorem wire_e2411647301850 : Closed e2411647301850 ∧ code e2411647301850 = 11207740324058 := by decide
theorem cert_e2411647301850 : check e2411647301850 [[],[]] .chain = true := by decide
def e2411647301866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))) (.var 0)))))
theorem wire_e2411647301866 : Closed e2411647301866 ∧ code e2411647301866 = 11207740324074 := by decide
theorem cert_e2411647301866 : check e2411647301866 [[],[]] .chain = true := by decide
def e2411647302202 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))) (.var 0)))))
theorem wire_e2411647302202 : Closed e2411647302202 ∧ code e2411647302202 = 11207740324410 := by decide
theorem cert_e2411647302202 : check e2411647302202 [[],[]] .chain = true := by decide
def e2411647302342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.lam (.var 1))))))
theorem wire_e2411647302342 : Closed e2411647302342 ∧ code e2411647302342 = 11207740324550 := by decide
theorem cert_e2411647302342 : check e2411647302342 [[],[]] .chain = true := by decide
def e2411647302426 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))) (.var 0)))))
theorem wire_e2411647302426 : Closed e2411647302426 ∧ code e2411647302426 = 11207740324634 := by decide
theorem cert_e2411647302426 : check e2411647302426 [[],[]] .chain = true := by decide
def e2411647302470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.lam (.var 1))))))
theorem wire_e2411647302470 : Closed e2411647302470 ∧ code e2411647302470 = 11207740324678 := by decide
theorem cert_e2411647302470 : check e2411647302470 [[],[]] .chain = true := by decide
def e2411647310970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e2411647310970 : Closed e2411647310970 ∧ code e2411647310970 = 11207740333178 := by decide
theorem cert_e2411647310970 : check e2411647310970 [[],[]] .chain = true := by decide
def e2411647311302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.lam (.var 1))))))
theorem wire_e2411647311302 : Closed e2411647311302 ∧ code e2411647311302 = 11207740333510 := by decide
theorem cert_e2411647311302 : check e2411647311302 [[],[]] .chain = true := by decide
def e2411647311418 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e2411647311418 : Closed e2411647311418 ∧ code e2411647311418 = 11207740333626 := by decide
theorem cert_e2411647311418 : check e2411647311418 [[],[]] .chain = true := by decide
def e2411647311558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.lam (.var 1))))))
theorem wire_e2411647311558 : Closed e2411647311558 ∧ code e2411647311558 = 11207740333766 := by decide
theorem cert_e2411647311558 : check e2411647311558 [[],[]] .chain = true := by decide
def e2411647323258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))) (.var 0)))))
theorem wire_e2411647323258 : Closed e2411647323258 ∧ code e2411647323258 = 11207740345466 := by decide
theorem cert_e2411647323258 : check e2411647323258 [[],[]] .chain = true := by decide
def e2411647323590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.lam (.var 1))))))
theorem wire_e2411647323590 : Closed e2411647323590 ∧ code e2411647323590 = 11207740345798 := by decide
theorem cert_e2411647323590 : check e2411647323590 [[],[]] .chain = true := by decide
def e2411647323930 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e2411647323930 : Closed e2411647323930 ∧ code e2411647323930 = 11207740346138 := by decide
theorem cert_e2411647323930 : check e2411647323930 [[],[]] .chain = true := by decide
def e2411647323974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.lam (.var 1))))))
theorem wire_e2411647323974 : Closed e2411647323974 ∧ code e2411647323974 = 11207740346182 := by decide
theorem cert_e2411647323974 : check e2411647323974 [[],[]] .chain = true := by decide
def e2411647329850 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))) (.var 0)))))
theorem wire_e2411647329850 : Closed e2411647329850 ∧ code e2411647329850 = 11207740352058 := by decide
theorem cert_e2411647329850 : check e2411647329850 [[],[]] .chain = true := by decide
def e2411647329990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.lam (.var 1))))))
theorem wire_e2411647329990 : Closed e2411647329990 ∧ code e2411647329990 = 11207740352198 := by decide
theorem cert_e2411647329990 : check e2411647329990 [[],[]] .chain = true := by decide
def e2411647330074 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))) (.var 0)))))
theorem wire_e2411647330074 : Closed e2411647330074 ∧ code e2411647330074 = 11207740352282 := by decide
theorem cert_e2411647330074 : check e2411647330074 [[],[]] .chain = true := by decide
def e2411647330118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.lam (.var 1))))))
theorem wire_e2411647330118 : Closed e2411647330118 ∧ code e2411647330118 = 11207740352326 := by decide
theorem cert_e2411647330118 : check e2411647330118 [[],[]] .chain = true := by decide
def e2411647404910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2411647404910 : Closed e2411647404910 ∧ code e2411647404910 = 11207740427118 := by decide
theorem cert_e2411647404910 : check e2411647404910 [[],[]] .chain = true := by decide
def e2411647404918 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2411647404918 : Closed e2411647404918 ∧ code e2411647404918 = 11207740427126 := by decide
theorem cert_e2411647404918 : check e2411647404918 [[],[]] .chain = true := by decide
def e2411647404974 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2411647404974 : Closed e2411647404974 ∧ code e2411647404974 = 11207740427182 := by decide
theorem cert_e2411647404974 : check e2411647404974 [[],[]] .chain = true := by decide
def e2411647404986 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2411647404986 : Closed e2411647404986 ∧ code e2411647404986 = 11207740427194 := by decide
theorem cert_e2411647404986 : check e2411647404986 [[],[]] .chain = true := by decide
def e2411647405014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2411647405014 : Closed e2411647405014 ∧ code e2411647405014 = 11207740427222 := by decide
theorem cert_e2411647405014 : check e2411647405014 [[],[]] .chain = true := by decide
def e2411647405018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2411647405018 : Closed e2411647405018 ∧ code e2411647405018 = 11207740427226 := by decide
theorem cert_e2411647405018 : check e2411647405018 [[],[]] .chain = true := by decide
def e2411647405294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2411647405294 : Closed e2411647405294 ∧ code e2411647405294 = 11207740427502 := by decide
theorem cert_e2411647405294 : check e2411647405294 [[],[]] .chain = true := by decide
def e2411647405302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2411647405302 : Closed e2411647405302 ∧ code e2411647405302 = 11207740427510 := by decide
theorem cert_e2411647405302 : check e2411647405302 [[],[]] .chain = true := by decide
def e2411647405678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2411647405678 : Closed e2411647405678 ∧ code e2411647405678 = 11207740427886 := by decide
theorem cert_e2411647405678 : check e2411647405678 [[],[]] .chain = true := by decide
def e2411647405690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2411647405690 : Closed e2411647405690 ∧ code e2411647405690 = 11207740427898 := by decide
theorem cert_e2411647405690 : check e2411647405690 [[],[]] .chain = true := by decide
def e2411647405878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2411647405878 : Closed e2411647405878 ∧ code e2411647405878 = 11207740428086 := by decide
theorem cert_e2411647405878 : check e2411647405878 [[],[]] .chain = true := by decide
def e2411647405882 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2411647405882 : Closed e2411647405882 ∧ code e2411647405882 = 11207740428090 := by decide
theorem cert_e2411647405882 : check e2411647405882 [[],[]] .chain = true := by decide
def e2411647735518 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2411647735518 : Closed e2411647735518 ∧ code e2411647735518 = 11207740757726 := by decide
theorem cert_e2411647735518 : check e2411647735518 [[],[]] .chain = true := by decide
def e2411647735542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2411647735542 : Closed e2411647735542 ∧ code e2411647735542 = 11207740757750 := by decide
theorem cert_e2411647735542 : check e2411647735542 [[],[]] .chain = true := by decide
def e2411647735646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2411647735646 : Closed e2411647735646 ∧ code e2411647735646 = 11207740757854 := by decide
theorem cert_e2411647735646 : check e2411647735646 [[],[]] .chain = true := by decide
def e2411647735674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2411647735674 : Closed e2411647735674 ∧ code e2411647735674 = 11207740757882 := by decide
theorem cert_e2411647735674 : check e2411647735674 [[],[]] .chain = true := by decide
def e2411647735766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2411647735766 : Closed e2411647735766 ∧ code e2411647735766 = 11207740757974 := by decide
theorem cert_e2411647735766 : check e2411647735766 [[],[]] .chain = true := by decide
def e2411647735770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2411647735770 : Closed e2411647735770 ∧ code e2411647735770 = 11207740757978 := by decide
theorem cert_e2411647735770 : check e2411647735770 [[],[]] .chain = true := by decide
def e2411647736286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2411647736286 : Closed e2411647736286 ∧ code e2411647736286 = 11207740758494 := by decide
theorem cert_e2411647736286 : check e2411647736286 [[],[]] .chain = true := by decide
def e2411647736310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2411647736310 : Closed e2411647736310 ∧ code e2411647736310 = 11207740758518 := by decide
theorem cert_e2411647736310 : check e2411647736310 [[],[]] .chain = true := by decide
def e2411647737054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411647737054 : Closed e2411647737054 ∧ code e2411647737054 = 11207740759262 := by decide
theorem cert_e2411647737054 : check e2411647737054 [[],[]] .chain = true := by decide
def e2411647737082 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411647737082 : Closed e2411647737082 ∧ code e2411647737082 = 11207740759290 := by decide
theorem cert_e2411647737082 : check e2411647737082 [[],[]] .chain = true := by decide
def e2411647737654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411647737654 : Closed e2411647737654 ∧ code e2411647737654 = 11207740759862 := by decide
theorem cert_e2411647737654 : check e2411647737654 [[],[]] .chain = true := by decide
def e2411647737658 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411647737658 : Closed e2411647737658 ∧ code e2411647737658 = 11207740759866 := by decide
theorem cert_e2411647737658 : check e2411647737658 [[],[]] .chain = true := by decide
def e2411647752430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2411647752430 : Closed e2411647752430 ∧ code e2411647752430 = 11207740774638 := by decide
theorem cert_e2411647752430 : check e2411647752430 [[],[]] .chain = true := by decide
def e2411647752438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2411647752438 : Closed e2411647752438 ∧ code e2411647752438 = 11207740774646 := by decide
theorem cert_e2411647752438 : check e2411647752438 [[],[]] .chain = true := by decide
def e2411647752990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2411647752990 : Closed e2411647752990 ∧ code e2411647752990 = 11207740775198 := by decide
theorem cert_e2411647752990 : check e2411647752990 [[],[]] .chain = true := by decide
def e2411647753102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2411647753102 : Closed e2411647753102 ∧ code e2411647753102 = 11207740775310 := by decide
theorem cert_e2411647753102 : check e2411647753102 [[],[]] .chain = true := by decide
end Blc.Floor43
