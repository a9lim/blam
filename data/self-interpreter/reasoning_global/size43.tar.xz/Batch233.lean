import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373377514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 0))))))
theorem wire_e2393373377514 : Closed e2393373377514 ∧ code e2393373377514 = 11189466399722 := by decide
theorem cert_e2393373377514 : check e2393373377514 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373378222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2393373378222 : Closed e2393373378222 ∧ code e2393373378222 = 11189466400430 := by decide
theorem cert_e2393373378222 : check e2393373378222 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373378234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2393373378234 : Closed e2393373378234 ∧ code e2393373378234 = 11189466400442 := by decide
theorem cert_e2393373378234 : check e2393373378234 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .width = true := by decide
def e2393373378990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2393373378990 : Closed e2393373378990 ∧ code e2393373378990 = 11189466401198 := by decide
theorem cert_e2393373378990 : check e2393373378990 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373379002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2393373379002 : Closed e2393373379002 ∧ code e2393373379002 = 11189466401210 := by decide
theorem cert_e2393373379002 : check e2393373379002 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373379050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2393373379050 : Closed e2393373379050 ∧ code e2393373379050 = 11189466401258 := by decide
theorem cert_e2393373379050 : check e2393373379050 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373379182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373379182 : Closed e2393373379182 ∧ code e2393373379182 = 11189466401390 := by decide
theorem cert_e2393373379182 : check e2393373379182 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373379194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373379194 : Closed e2393373379194 ∧ code e2393373379194 = 11189466401402 := by decide
theorem cert_e2393373379194 : check e2393373379194 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373379482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373379482 : Closed e2393373379482 ∧ code e2393373379482 = 11189466401690 := by decide
theorem cert_e2393373379482 : check e2393373379482 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373379694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2393373379694 : Closed e2393373379694 ∧ code e2393373379694 = 11189466401902 := by decide
theorem cert_e2393373379694 : check e2393373379694 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393373379706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2393373379706 : Closed e2393373379706 ∧ code e2393373379706 = 11189466401914 := by decide
theorem cert_e2393373379706 : check e2393373379706 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373379870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2393373379870 : Closed e2393373379870 ∧ code e2393373379870 = 11189466402078 := by decide
theorem cert_e2393373379870 : check e2393373379870 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373380038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2393373380038 : Closed e2393373380038 ∧ code e2393373380038 = 11189466402246 := by decide
theorem cert_e2393373380038 : check e2393373380038 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373380378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2393373380378 : Closed e2393373380378 ∧ code e2393373380378 = 11189466402586 := by decide
theorem cert_e2393373380378 : check e2393373380378 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373380422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2393373380422 : Closed e2393373380422 ∧ code e2393373380422 = 11189466402630 := by decide
theorem cert_e2393373380422 : check e2393373380422 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373382830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2393373382830 : Closed e2393373382830 ∧ code e2393373382830 = 11189466405038 := by decide
theorem cert_e2393373382830 : check e2393373382830 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373382842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2393373382842 : Closed e2393373382842 ∧ code e2393373382842 = 11189466405050 := by decide
theorem cert_e2393373382842 : check e2393373382842 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373383214 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2393373383214 : Closed e2393373383214 ∧ code e2393373383214 = 11189466405422 := by decide
theorem cert_e2393373383214 : check e2393373383214 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2393373383394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2393373383394 : Closed e2393373383394 ∧ code e2393373383394 = 11189466405602 := by decide
theorem cert_e2393373383394 : check e2393373383394 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373383406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2393373383406 : Closed e2393373383406 ∧ code e2393373383406 = 11189466405614 := by decide
theorem cert_e2393373383406 : check e2393373383406 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373383534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2393373383534 : Closed e2393373383534 ∧ code e2393373383534 = 11189466405742 := by decide
def e2393373383542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2393373383542 : Closed e2393373383542 ∧ code e2393373383542 = 11189466405750 := by decide
theorem cert_e2393373383542 : check e2393373383542 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373383562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373383562 : Closed e2393373383562 ∧ code e2393373383562 = 11189466405770 := by decide
theorem cert_e2393373383562 : check e2393373383562 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373383586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373383586 : Closed e2393373383586 ∧ code e2393373383586 = 11189466405794 := by decide
theorem cert_e2393373383586 : check e2393373383586 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373383598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2393373383598 : Closed e2393373383598 ∧ code e2393373383598 = 11189466405806 := by decide
theorem cert_e2393373383598 : check e2393373383598 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373383606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2393373383606 : Closed e2393373383606 ∧ code e2393373383606 = 11189466405814 := by decide
def e2393373383610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2393373383610 : Closed e2393373383610 ∧ code e2393373383610 = 11189466405818 := by decide
theorem cert_e2393373383610 : check e2393373383610 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373384046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2393373384046 : Closed e2393373384046 ∧ code e2393373384046 = 11189466406254 := by decide
def e2393373384054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2393373384054 : Closed e2393373384054 ∧ code e2393373384054 = 11189466406262 := by decide
theorem cert_e2393373384054 : check e2393373384054 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2393373384110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2393373384110 : Closed e2393373384110 ∧ code e2393373384110 = 11189466406318 := by decide
theorem cert_e2393373384110 : check e2393373384110 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373384122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2393373384122 : Closed e2393373384122 ∧ code e2393373384122 = 11189466406330 := by decide
def e2393373384150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2393373384150 : Closed e2393373384150 ∧ code e2393373384150 = 11189466406358 := by decide
theorem cert_e2393373384150 : check e2393373384150 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373384154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2393373384154 : Closed e2393373384154 ∧ code e2393373384154 = 11189466406362 := by decide
def e2393373384234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2393373384234 : Closed e2393373384234 ∧ code e2393373384234 = 11189466406442 := by decide
theorem cert_e2393373384234 : check e2393373384234 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373384330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373384330 : Closed e2393373384330 ∧ code e2393373384330 = 11189466406538 := by decide
theorem cert_e2393373384330 : check e2393373384330 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373384354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373384354 : Closed e2393373384354 ∧ code e2393373384354 = 11189466406562 := by decide
theorem cert_e2393373384354 : check e2393373384354 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373384366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2393373384366 : Closed e2393373384366 ∧ code e2393373384366 = 11189466406574 := by decide
theorem cert_e2393373384366 : check e2393373384366 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373384374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2393373384374 : Closed e2393373384374 ∧ code e2393373384374 = 11189466406582 := by decide
def e2393373384378 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2393373384378 : Closed e2393373384378 ∧ code e2393373384378 = 11189466406586 := by decide
theorem cert_e2393373384378 : check e2393373384378 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left]] .sourceHead = true := by decide
def e2393373384406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2393373384406 : Closed e2393373384406 ∧ code e2393373384406 = 11189466406614 := by decide
theorem cert_e2393373384406 : check e2393373384406 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373384410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2393373384410 : Closed e2393373384410 ∧ code e2393373384410 = 11189466406618 := by decide
def e2393373384426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2393373384426 : Closed e2393373384426 ∧ code e2393373384426 = 11189466406634 := by decide
theorem cert_e2393373384426 : check e2393373384426 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373384942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2393373384942 : Closed e2393373384942 ∧ code e2393373384942 = 11189466407150 := by decide
theorem cert_e2393373384942 : check e2393373384942 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393373384954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2393373384954 : Closed e2393373384954 ∧ code e2393373384954 = 11189466407162 := by decide
theorem cert_e2393373384954 : check e2393373384954 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373385134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2393373385134 : Closed e2393373385134 ∧ code e2393373385134 = 11189466407342 := by decide
theorem cert_e2393373385134 : check e2393373385134 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373385326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373385326 : Closed e2393373385326 ∧ code e2393373385326 = 11189466407534 := by decide
theorem cert_e2393373385326 : check e2393373385326 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373385338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373385338 : Closed e2393373385338 ∧ code e2393373385338 = 11189466407546 := by decide
theorem cert_e2393373385338 : check e2393373385338 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373385502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2393373385502 : Closed e2393373385502 ∧ code e2393373385502 = 11189466407710 := by decide
theorem cert_e2393373385502 : check e2393373385502 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393373385670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2393373385670 : Closed e2393373385670 ∧ code e2393373385670 = 11189466407878 := by decide
theorem cert_e2393373385670 : check e2393373385670 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373386286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2393373386286 : Closed e2393373386286 ∧ code e2393373386286 = 11189466408494 := by decide
theorem cert_e2393373386286 : check e2393373386286 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373386466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2393373386466 : Closed e2393373386466 ∧ code e2393373386466 = 11189466408674 := by decide
theorem cert_e2393373386466 : check e2393373386466 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373386478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2393373386478 : Closed e2393373386478 ∧ code e2393373386478 = 11189466408686 := by decide
theorem cert_e2393373386478 : check e2393373386478 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373386606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2393373386606 : Closed e2393373386606 ∧ code e2393373386606 = 11189466408814 := by decide
def e2393373386614 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2393373386614 : Closed e2393373386614 ∧ code e2393373386614 = 11189466408822 := by decide
def e2393373386634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373386634 : Closed e2393373386634 ∧ code e2393373386634 = 11189466408842 := by decide
theorem cert_e2393373386634 : check e2393373386634 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373386658 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373386658 : Closed e2393373386658 ∧ code e2393373386658 = 11189466408866 := by decide
theorem cert_e2393373386658 : check e2393373386658 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373386670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2393373386670 : Closed e2393373386670 ∧ code e2393373386670 = 11189466408878 := by decide
theorem cert_e2393373386670 : check e2393373386670 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373386678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2393373386678 : Closed e2393373386678 ∧ code e2393373386678 = 11189466408886 := by decide
def e2393373386682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2393373386682 : Closed e2393373386682 ∧ code e2393373386682 = 11189466408890 := by decide
theorem cert_e2393373386682 : check e2393373386682 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373386814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2393373386814 : Closed e2393373386814 ∧ code e2393373386814 = 11189466409022 := by decide
theorem cert_e2393373386814 : check e2393373386814 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373387234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2393373387234 : Closed e2393373387234 ∧ code e2393373387234 = 11189466409442 := by decide
theorem cert_e2393373387234 : check e2393373387234 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373387246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2393373387246 : Closed e2393373387246 ∧ code e2393373387246 = 11189466409454 := by decide
theorem cert_e2393373387246 : check e2393373387246 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373388014 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373388014 : Closed e2393373388014 ∧ code e2393373388014 = 11189466410222 := by decide
def e2393373388022 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373388022 : Closed e2393373388022 ∧ code e2393373388022 = 11189466410230 := by decide
def e2393373388302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2393373388302 : Closed e2393373388302 ∧ code e2393373388302 = 11189466410510 := by decide
theorem cert_e2393373388302 : check e2393373388302 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373388314 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373388314 : Closed e2393373388314 ∧ code e2393373388314 = 11189466410522 := by decide
theorem cert_e2393373388314 : check e2393373388314 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .width = true := by decide
def e2393373388386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373388386 : Closed e2393373388386 ∧ code e2393373388386 = 11189466410594 := by decide
theorem cert_e2393373388386 : check e2393373388386 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373388398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373388398 : Closed e2393373388398 ∧ code e2393373388398 = 11189466410606 := by decide
theorem cert_e2393373388398 : check e2393373388398 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373388406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373388406 : Closed e2393373388406 ∧ code e2393373388406 = 11189466410614 := by decide
theorem cert_e2393373388406 : check e2393373388406 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373388410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373388410 : Closed e2393373388410 ∧ code e2393373388410 = 11189466410618 := by decide
theorem cert_e2393373388410 : check e2393373388410 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373389678 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2393373389678 : Closed e2393373389678 ∧ code e2393373389678 = 11189466411886 := by decide
theorem cert_e2393373389678 : check e2393373389678 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373389686 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2393373389686 : Closed e2393373389686 ∧ code e2393373389686 = 11189466411894 := by decide
theorem cert_e2393373389686 : check e2393373389686 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373389742 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2393373389742 : Closed e2393373389742 ∧ code e2393373389742 = 11189466411950 := by decide
def e2393373389754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2393373389754 : Closed e2393373389754 ∧ code e2393373389754 = 11189466411962 := by decide
def e2393373389782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2393373389782 : Closed e2393373389782 ∧ code e2393373389782 = 11189466411990 := by decide
def e2393373389786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2393373389786 : Closed e2393373389786 ∧ code e2393373389786 = 11189466411994 := by decide
def e2393373390062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373390062 : Closed e2393373390062 ∧ code e2393373390062 = 11189466412270 := by decide
theorem cert_e2393373390062 : check e2393373390062 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373390070 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373390070 : Closed e2393373390070 ∧ code e2393373390070 = 11189466412278 := by decide
theorem cert_e2393373390070 : check e2393373390070 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373390446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373390446 : Closed e2393373390446 ∧ code e2393373390446 = 11189466412654 := by decide
def e2393373390458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373390458 : Closed e2393373390458 ∧ code e2393373390458 = 11189466412666 := by decide
def e2393373390646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373390646 : Closed e2393373390646 ∧ code e2393373390646 = 11189466412854 := by decide
def e2393373390650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373390650 : Closed e2393373390650 ∧ code e2393373390650 = 11189466412858 := by decide
def e2393373390906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2393373390906 : Closed e2393373390906 ∧ code e2393373390906 = 11189466413114 := by decide
theorem cert_e2393373390906 : check e2393373390906 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373390954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2393373390954 : Closed e2393373390954 ∧ code e2393373390954 = 11189466413162 := by decide
def e2393373391002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373391002 : Closed e2393373391002 ∧ code e2393373391002 = 11189466413210 := by decide
theorem cert_e2393373391002 : check e2393373391002 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373391046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2393373391046 : Closed e2393373391046 ∧ code e2393373391046 = 11189466413254 := by decide
theorem cert_e2393373391046 : check e2393373391046 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373391242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373391242 : Closed e2393373391242 ∧ code e2393373391242 = 11189466413450 := by decide
theorem cert_e2393373391242 : check e2393373391242 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373391266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373391266 : Closed e2393373391266 ∧ code e2393373391266 = 11189466413474 := by decide
theorem cert_e2393373391266 : check e2393373391266 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373391278 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2393373391278 : Closed e2393373391278 ∧ code e2393373391278 = 11189466413486 := by decide
theorem cert_e2393373391278 : check e2393373391278 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373391286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2393373391286 : Closed e2393373391286 ∧ code e2393373391286 = 11189466413494 := by decide
theorem cert_e2393373391286 : check e2393373391286 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373391290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2393373391290 : Closed e2393373391290 ∧ code e2393373391290 = 11189466413498 := by decide
theorem cert_e2393373391290 : check e2393373391290 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373391318 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2393373391318 : Closed e2393373391318 ∧ code e2393373391318 = 11189466413526 := by decide
theorem cert_e2393373391318 : check e2393373391318 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2393373391322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2393373391322 : Closed e2393373391322 ∧ code e2393373391322 = 11189466413530 := by decide
def e2393373391338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2393373391338 : Closed e2393373391338 ∧ code e2393373391338 = 11189466413546 := by decide
theorem cert_e2393373391338 : check e2393373391338 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373391374 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2393373391374 : Closed e2393373391374 ∧ code e2393373391374 = 11189466413582 := by decide
theorem cert_e2393373391374 : check e2393373391374 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373391386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373391386 : Closed e2393373391386 ∧ code e2393373391386 = 11189466413594 := by decide
theorem cert_e2393373391386 : check e2393373391386 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373391458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373391458 : Closed e2393373391458 ∧ code e2393373391458 = 11189466413666 := by decide
theorem cert_e2393373391458 : check e2393373391458 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373391470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373391470 : Closed e2393373391470 ∧ code e2393373391470 = 11189466413678 := by decide
theorem cert_e2393373391470 : check e2393373391470 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373391478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373391478 : Closed e2393373391478 ∧ code e2393373391478 = 11189466413686 := by decide
theorem cert_e2393373391478 : check e2393373391478 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373391482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373391482 : Closed e2393373391482 ∧ code e2393373391482 = 11189466413690 := by decide
theorem cert_e2393373391482 : check e2393373391482 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373391670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373391670 : Closed e2393373391670 ∧ code e2393373391670 = 11189466413878 := by decide
def e2393373391674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373391674 : Closed e2393373391674 ∧ code e2393373391674 = 11189466413882 := by decide
def e2393373391770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373391770 : Closed e2393373391770 ∧ code e2393373391770 = 11189466413978 := by decide
def e2393373393366 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2393373393366 : Closed e2393373393366 ∧ code e2393373393366 = 11189466415574 := by decide
theorem cert_e2393373393366 : check e2393373393366 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .smaller = true := by decide
def e2393373393370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2393373393370 : Closed e2393373393370 ∧ code e2393373393370 = 11189466415578 := by decide
theorem cert_e2393373393370 : check e2393373393370 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373393386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2393373393386 : Closed e2393373393386 ∧ code e2393373393386 = 11189466415594 := by decide
theorem cert_e2393373393386 : check e2393373393386 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373393750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2393373393750 : Closed e2393373393750 ∧ code e2393373393750 = 11189466415958 := by decide
private def t_e2393373393750 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 1))))))
theorem cert_e2393373393750 : ¬ IsSelfInterpreter e2393373393750 :=
  wSource (t := t_e2393373393750) (replay_sound (ps := []) (t := e2393373393750) (by decide)) (by decide)
def e2393373393754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2393373393754 : Closed e2393373393754 ∧ code e2393373393754 = 11189466415962 := by decide
private def t_e2393373393754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 0))))))
theorem cert_e2393373393754 : ¬ IsSelfInterpreter e2393373393754 :=
  wSource (t := t_e2393373393754) (replay_sound (ps := []) (t := e2393373393754) (by decide)) (by decide)
def e2393373394134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2393373394134 : Closed e2393373394134 ∧ code e2393373394134 = 11189466416342 := by decide
theorem cert_e2393373394134 : check e2393373394134 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e2393373394138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2393373394138 : Closed e2393373394138 ∧ code e2393373394138 = 11189466416346 := by decide
theorem cert_e2393373394138 : check e2393373394138 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373394154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2393373394154 : Closed e2393373394154 ∧ code e2393373394154 = 11189466416362 := by decide
theorem cert_e2393373394154 : check e2393373394154 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373394230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373394230 : Closed e2393373394230 ∧ code e2393373394230 = 11189466416438 := by decide
theorem cert_e2393373394230 : check e2393373394230 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373394234 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373394234 : Closed e2393373394234 ∧ code e2393373394234 = 11189466416442 := by decide
theorem cert_e2393373394234 : check e2393373394234 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under]] .chain = true := by decide
def e2393373394330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373394330 : Closed e2393373394330 ∧ code e2393373394330 = 11189466416538 := by decide
theorem cert_e2393373394330 : check e2393373394330 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373394486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2393373394486 : Closed e2393373394486 ∧ code e2393373394486 = 11189466416694 := by decide
theorem cert_e2393373394486 : check e2393373394486 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393373394490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2393373394490 : Closed e2393373394490 ∧ code e2393373394490 = 11189466416698 := by decide
theorem cert_e2393373394490 : check e2393373394490 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373394574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2393373394574 : Closed e2393373394574 ∧ code e2393373394574 = 11189466416782 := by decide
theorem cert_e2393373394574 : check e2393373394574 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2393373394630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2393373394630 : Closed e2393373394630 ∧ code e2393373394630 = 11189466416838 := by decide
theorem cert_e2393373394630 : check e2393373394630 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373394714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2393373394714 : Closed e2393373394714 ∧ code e2393373394714 = 11189466416922 := by decide
theorem cert_e2393373394714 : check e2393373394714 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373394758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2393373394758 : Closed e2393373394758 ∧ code e2393373394758 = 11189466416966 := by decide
theorem cert_e2393373394758 : check e2393373394758 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373396054 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2393373396054 : Closed e2393373396054 ∧ code e2393373396054 = 11189466418262 := by decide
theorem cert_e2393373396054 : check e2393373396054 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2393373396058 : Closed e2393373396058 ∧ code e2393373396058 = 11189466418266 := by decide
theorem cert_e2393373396058 : check e2393373396058 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373396246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2393373396246 : Closed e2393373396246 ∧ code e2393373396246 = 11189466418454 := by decide
theorem cert_e2393373396246 : check e2393373396246 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2393373396322 : Closed e2393373396322 ∧ code e2393373396322 = 11189466418530 := by decide
theorem cert_e2393373396322 : check e2393373396322 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373396334 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2393373396334 : Closed e2393373396334 ∧ code e2393373396334 = 11189466418542 := by decide
theorem cert_e2393373396334 : check e2393373396334 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2393373396342 : Closed e2393373396342 ∧ code e2393373396342 = 11189466418550 := by decide
theorem cert_e2393373396342 : check e2393373396342 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373396362 : Closed e2393373396362 ∧ code e2393373396362 = 11189466418570 := by decide
theorem cert_e2393373396362 : check e2393373396362 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373396386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373396386 : Closed e2393373396386 ∧ code e2393373396386 = 11189466418594 := by decide
theorem cert_e2393373396386 : check e2393373396386 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373396398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2393373396398 : Closed e2393373396398 ∧ code e2393373396398 = 11189466418606 := by decide
theorem cert_e2393373396398 : check e2393373396398 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396406 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2393373396406 : Closed e2393373396406 ∧ code e2393373396406 = 11189466418614 := by decide
theorem cert_e2393373396406 : check e2393373396406 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2393373396410 : Closed e2393373396410 ∧ code e2393373396410 = 11189466418618 := by decide
theorem cert_e2393373396410 : check e2393373396410 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2393373396438 : Closed e2393373396438 ∧ code e2393373396438 = 11189466418646 := by decide
theorem cert_e2393373396438 : check e2393373396438 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2393373396442 : Closed e2393373396442 ∧ code e2393373396442 = 11189466418650 := by decide
theorem cert_e2393373396442 : check e2393373396442 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373396522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2393373396522 : Closed e2393373396522 ∧ code e2393373396522 = 11189466418730 := by decide
theorem cert_e2393373396522 : check e2393373396522 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373396618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2393373396618 : Closed e2393373396618 ∧ code e2393373396618 = 11189466418826 := by decide
theorem cert_e2393373396618 : check e2393373396618 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373396642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2393373396642 : Closed e2393373396642 ∧ code e2393373396642 = 11189466418850 := by decide
theorem cert_e2393373396642 : check e2393373396642 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393373396654 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2393373396654 : Closed e2393373396654 ∧ code e2393373396654 = 11189466418862 := by decide
theorem cert_e2393373396654 : check e2393373396654 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373396662 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2393373396662 : Closed e2393373396662 ∧ code e2393373396662 = 11189466418870 := by decide
theorem cert_e2393373396662 : check e2393373396662 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373396666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2393373396666 : Closed e2393373396666 ∧ code e2393373396666 = 11189466418874 := by decide
theorem cert_e2393373396666 : check e2393373396666 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373396694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2393373396694 : Closed e2393373396694 ∧ code e2393373396694 = 11189466418902 := by decide
theorem cert_e2393373396694 : check e2393373396694 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373396698 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2393373396698 : Closed e2393373396698 ∧ code e2393373396698 = 11189466418906 := by decide
def e2393373396714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2393373396714 : Closed e2393373396714 ∧ code e2393373396714 = 11189466418922 := by decide
theorem cert_e2393373396714 : check e2393373396714 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373396822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2393373396822 : Closed e2393373396822 ∧ code e2393373396822 = 11189466419030 := by decide
theorem cert_e2393373396822 : check e2393373396822 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373396826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2393373396826 : Closed e2393373396826 ∧ code e2393373396826 = 11189466419034 := by decide
theorem cert_e2393373396826 : check e2393373396826 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393373396842 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2393373396842 : Closed e2393373396842 ∧ code e2393373396842 = 11189466419050 := by decide
def e2393373397110 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2393373397110 : Closed e2393373397110 ∧ code e2393373397110 = 11189466419318 := by decide
theorem cert_e2393373397110 : check e2393373397110 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2393373397114 : Closed e2393373397114 ∧ code e2393373397114 = 11189466419322 := by decide
theorem cert_e2393373397114 : check e2393373397114 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373397206 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2393373397206 : Closed e2393373397206 ∧ code e2393373397206 = 11189466419414 := by decide
theorem cert_e2393373397206 : check e2393373397206 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397302 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373397302 : Closed e2393373397302 ∧ code e2393373397302 = 11189466419510 := by decide
theorem cert_e2393373397302 : check e2393373397302 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373397306 : Closed e2393373397306 ∧ code e2393373397306 = 11189466419514 := by decide
theorem cert_e2393373397306 : check e2393373397306 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2393373397390 : Closed e2393373397390 ∧ code e2393373397390 = 11189466419598 := by decide
theorem cert_e2393373397390 : check e2393373397390 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397446 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2393373397446 : Closed e2393373397446 ∧ code e2393373397446 = 11189466419654 := by decide
theorem cert_e2393373397446 : check e2393373397446 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373397782 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2393373397782 : Closed e2393373397782 ∧ code e2393373397782 = 11189466419990 := by decide
theorem cert_e2393373397782 : check e2393373397782 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2393373397858 : Closed e2393373397858 ∧ code e2393373397858 = 11189466420066 := by decide
theorem cert_e2393373397858 : check e2393373397858 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373397870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2393373397870 : Closed e2393373397870 ∧ code e2393373397870 = 11189466420078 := by decide
theorem cert_e2393373397870 : check e2393373397870 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2393373397878 : Closed e2393373397878 ∧ code e2393373397878 = 11189466420086 := by decide
theorem cert_e2393373397878 : check e2393373397878 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373397898 : Closed e2393373397898 ∧ code e2393373397898 = 11189466420106 := by decide
theorem cert_e2393373397898 : check e2393373397898 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373397922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373397922 : Closed e2393373397922 ∧ code e2393373397922 = 11189466420130 := by decide
theorem cert_e2393373397922 : check e2393373397922 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2393373397934 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2393373397934 : Closed e2393373397934 ∧ code e2393373397934 = 11189466420142 := by decide
theorem cert_e2393373397934 : check e2393373397934 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373397942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2393373397942 : Closed e2393373397942 ∧ code e2393373397942 = 11189466420150 := by decide
theorem cert_e2393373397942 : check e2393373397942 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393373393750
#print axioms Blc.Floor43.cert_e2393373393754
