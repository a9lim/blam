import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2262377360994 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377360994 : Closed e2262377360994 ∧ code e2262377360994 = 11058470383202 := by decide
theorem cert_e2262377360994 : check e2262377360994 [[],[.under]] .three = true := by decide
def e2262377361006 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377361006 : Closed e2262377361006 ∧ code e2262377361006 = 11058470383214 := by decide
theorem cert_e2262377361006 : check e2262377361006 [[],[.under]] .three = true := by decide
def e2262377361014 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377361014 : Closed e2262377361014 ∧ code e2262377361014 = 11058470383222 := by decide
theorem cert_e2262377361014 : check e2262377361014 [[],[.under]] .three = true := by decide
def e2262377361018 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377361018 : Closed e2262377361018 ∧ code e2262377361018 = 11058470383226 := by decide
theorem cert_e2262377361018 : check e2262377361018 [[],[.under]] .three = true := by decide
def e2262377361526 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))))
theorem wire_e2262377361526 : Closed e2262377361526 ∧ code e2262377361526 = 11058470383734 := by decide
theorem cert_e2262377361526 : check e2262377361526 [[],[.under]] .three = true := by decide
def e2262377361530 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))))
theorem wire_e2262377361530 : Closed e2262377361530 ∧ code e2262377361530 = 11058470383738 := by decide
theorem cert_e2262377361530 : check e2262377361530 [[],[.under]] .three = true := by decide
def e2262377361622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)))))))
theorem wire_e2262377361622 : Closed e2262377361622 ∧ code e2262377361622 = 11058470383830 := by decide
theorem cert_e2262377361622 : check e2262377361622 [[],[.under]] .three = true := by decide
def e2262377361718 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377361718 : Closed e2262377361718 ∧ code e2262377361718 = 11058470383926 := by decide
theorem cert_e2262377361718 : check e2262377361718 [[],[.under]] .three = true := by decide
def e2262377361722 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377361722 : Closed e2262377361722 ∧ code e2262377361722 = 11058470383930 := by decide
theorem cert_e2262377361722 : check e2262377361722 [[],[.under]] .three = true := by decide
def e2262377361806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))))
theorem wire_e2262377361806 : Closed e2262377361806 ∧ code e2262377361806 = 11058470384014 := by decide
theorem cert_e2262377361806 : check e2262377361806 [[],[.under]] .three = true := by decide
def e2262377361862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))))
theorem wire_e2262377361862 : Closed e2262377361862 ∧ code e2262377361862 = 11058470384070 := by decide
theorem cert_e2262377361862 : check e2262377361862 [[],[.under]] .three = true := by decide
def e2262377362198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2262377362198 : Closed e2262377362198 ∧ code e2262377362198 = 11058470384406 := by decide
theorem cert_e2262377362198 : check e2262377362198 [[],[.under]] .three = true := by decide
def e2262377362274 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))))
theorem wire_e2262377362274 : Closed e2262377362274 ∧ code e2262377362274 = 11058470384482 := by decide
theorem cert_e2262377362274 : check e2262377362274 [[],[.under]] .three = true := by decide
def e2262377362286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2262377362286 : Closed e2262377362286 ∧ code e2262377362286 = 11058470384494 := by decide
theorem cert_e2262377362286 : check e2262377362286 [[],[.under]] .three = true := by decide
def e2262377362294 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2262377362294 : Closed e2262377362294 ∧ code e2262377362294 = 11058470384502 := by decide
theorem cert_e2262377362294 : check e2262377362294 [[],[.under]] .three = true := by decide
def e2262377362314 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))))
theorem wire_e2262377362314 : Closed e2262377362314 ∧ code e2262377362314 = 11058470384522 := by decide
theorem cert_e2262377362314 : check e2262377362314 [[],[.under]] .three = true := by decide
def e2262377362338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))))
theorem wire_e2262377362338 : Closed e2262377362338 ∧ code e2262377362338 = 11058470384546 := by decide
theorem cert_e2262377362338 : check e2262377362338 [[],[.under]] .three = true := by decide
def e2262377362350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2262377362350 : Closed e2262377362350 ∧ code e2262377362350 = 11058470384558 := by decide
theorem cert_e2262377362350 : check e2262377362350 [[],[.under]] .three = true := by decide
def e2262377362358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 1)))))))
theorem wire_e2262377362358 : Closed e2262377362358 ∧ code e2262377362358 = 11058470384566 := by decide
theorem cert_e2262377362358 : check e2262377362358 [[],[.under]] .three = true := by decide
def e2262377362362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2262377362362 : Closed e2262377362362 ∧ code e2262377362362 = 11058470384570 := by decide
theorem cert_e2262377362362 : check e2262377362362 [[],[.under]] .three = true := by decide
def e2262377362390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2262377362390 : Closed e2262377362390 ∧ code e2262377362390 = 11058470384598 := by decide
theorem cert_e2262377362390 : check e2262377362390 [[],[.under]] .three = true := by decide
def e2262377362394 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2262377362394 : Closed e2262377362394 ∧ code e2262377362394 = 11058470384602 := by decide
theorem cert_e2262377362394 : check e2262377362394 [[],[.under]] .three = true := by decide
def e2262377362462 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))))
theorem wire_e2262377362462 : Closed e2262377362462 ∧ code e2262377362462 = 11058470384670 := by decide
theorem cert_e2262377362462 : check e2262377362462 [[],[.under]] .three = true := by decide
def e2262377362658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2262377362658 : Closed e2262377362658 ∧ code e2262377362658 = 11058470384866 := by decide
theorem cert_e2262377362658 : check e2262377362658 [[],[.under]] .three = true := by decide
def e2262377362670 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2262377362670 : Closed e2262377362670 ∧ code e2262377362670 = 11058470384878 := by decide
theorem cert_e2262377362670 : check e2262377362670 [[],[.under]] .three = true := by decide
def e2262377362678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2262377362678 : Closed e2262377362678 ∧ code e2262377362678 = 11058470384886 := by decide
theorem cert_e2262377362678 : check e2262377362678 [[],[.under]] .three = true := by decide
def e2262377362958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2262377362958 : Closed e2262377362958 ∧ code e2262377362958 = 11058470385166 := by decide
theorem cert_e2262377362958 : check e2262377362958 [[],[.under]] .three = true := by decide
def e2262377362970 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2262377362970 : Closed e2262377362970 ∧ code e2262377362970 = 11058470385178 := by decide
theorem cert_e2262377362970 : check e2262377362970 [[],[.under]] .three = true := by decide
def e2262377363042 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2262377363042 : Closed e2262377363042 ∧ code e2262377363042 = 11058470385250 := by decide
theorem cert_e2262377363042 : check e2262377363042 [[],[.under]] .three = true := by decide
def e2262377363054 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377363054 : Closed e2262377363054 ∧ code e2262377363054 = 11058470385262 := by decide
theorem cert_e2262377363054 : check e2262377363054 [[],[.under]] .three = true := by decide
def e2262377363062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 1))))))))
theorem wire_e2262377363062 : Closed e2262377363062 ∧ code e2262377363062 = 11058470385270 := by decide
theorem cert_e2262377363062 : check e2262377363062 [[],[.under]] .three = true := by decide
def e2262377363066 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377363066 : Closed e2262377363066 ∧ code e2262377363066 = 11058470385274 := by decide
theorem cert_e2262377363066 : check e2262377363066 [[],[.under]] .three = true := by decide
def e2262377363254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2262377363254 : Closed e2262377363254 ∧ code e2262377363254 = 11058470385462 := by decide
theorem cert_e2262377363254 : check e2262377363254 [[],[.under]] .three = true := by decide
def e2262377363258 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2262377363258 : Closed e2262377363258 ∧ code e2262377363258 = 11058470385466 := by decide
theorem cert_e2262377363258 : check e2262377363258 [[],[.under]] .three = true := by decide
def e2262377368430 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2262377368430 : Closed e2262377368430 ∧ code e2262377368430 = 11058470390638 := by decide
theorem cert_e2262377368430 : check e2262377368430 [[],[.under]] .smaller = true := by decide
def e2262377368438 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2262377368438 : Closed e2262377368438 ∧ code e2262377368438 = 11058470390646 := by decide
theorem cert_e2262377368438 : check e2262377368438 [[],[.under]] .smaller = true := by decide
def e2262377368494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2262377368494 : Closed e2262377368494 ∧ code e2262377368494 = 11058470390702 := by decide
theorem cert_e2262377368494 : check e2262377368494 [[],[.under]] .smaller = true := by decide
def e2262377368506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2262377368506 : Closed e2262377368506 ∧ code e2262377368506 = 11058470390714 := by decide
theorem cert_e2262377368506 : check e2262377368506 [[],[.under]] .smaller = true := by decide
def e2262377368534 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2262377368534 : Closed e2262377368534 ∧ code e2262377368534 = 11058470390742 := by decide
theorem cert_e2262377368534 : check e2262377368534 [[],[.under]] .smaller = true := by decide
def e2262377368538 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2262377368538 : Closed e2262377368538 ∧ code e2262377368538 = 11058470390746 := by decide
theorem cert_e2262377368538 : check e2262377368538 [[],[.under]] .smaller = true := by decide
def e2262377368814 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2262377368814 : Closed e2262377368814 ∧ code e2262377368814 = 11058470391022 := by decide
theorem cert_e2262377368814 : check e2262377368814 [[],[.under]] .smaller = true := by decide
def e2262377368822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2262377368822 : Closed e2262377368822 ∧ code e2262377368822 = 11058470391030 := by decide
theorem cert_e2262377368822 : check e2262377368822 [[],[.under]] .smaller = true := by decide
def e2262377369198 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2262377369198 : Closed e2262377369198 ∧ code e2262377369198 = 11058470391406 := by decide
theorem cert_e2262377369198 : check e2262377369198 [[],[.under]] .smaller = true := by decide
def e2262377369210 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2262377369210 : Closed e2262377369210 ∧ code e2262377369210 = 11058470391418 := by decide
theorem cert_e2262377369210 : check e2262377369210 [[],[.under]] .smaller = true := by decide
def e2262377369398 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262377369398 : Closed e2262377369398 ∧ code e2262377369398 = 11058470391606 := by decide
theorem cert_e2262377369398 : check e2262377369398 [[],[.under]] .smaller = true := by decide
def e2262377369402 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262377369402 : Closed e2262377369402 ∧ code e2262377369402 = 11058470391610 := by decide
theorem cert_e2262377369402 : check e2262377369402 [[],[.under]] .smaller = true := by decide
def e2262377377326 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2262377377326 : Closed e2262377377326 ∧ code e2262377377326 = 11058470399534 := by decide
theorem cert_e2262377377326 : check e2262377377326 [[],[.under]] .three = true := by decide
def e2262377377506 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2262377377506 : Closed e2262377377506 ∧ code e2262377377506 = 11058470399714 := by decide
theorem cert_e2262377377506 : check e2262377377506 [[],[.under]] .three = true := by decide
def e2262377377518 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2262377377518 : Closed e2262377377518 ∧ code e2262377377518 = 11058470399726 := by decide
theorem cert_e2262377377518 : check e2262377377518 [[],[.under]] .three = true := by decide
def e2262377377558 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2262377377558 : Closed e2262377377558 ∧ code e2262377377558 = 11058470399766 := by decide
theorem cert_e2262377377558 : check e2262377377558 [[],[.under]] .three = true := by decide
def e2262377377634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2262377377634 : Closed e2262377377634 ∧ code e2262377377634 = 11058470399842 := by decide
theorem cert_e2262377377634 : check e2262377377634 [[],[.under]] .three = true := by decide
def e2262377377646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2262377377646 : Closed e2262377377646 ∧ code e2262377377646 = 11058470399854 := by decide
theorem cert_e2262377377646 : check e2262377377646 [[],[.under]] .three = true := by decide
def e2262377377654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2262377377654 : Closed e2262377377654 ∧ code e2262377377654 = 11058470399862 := by decide
theorem cert_e2262377377654 : check e2262377377654 [[],[.under]] .three = true := by decide
def e2262377379902 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2262377379902 : Closed e2262377379902 ∧ code e2262377379902 = 11058470402110 := by decide
theorem cert_e2262377379902 : check e2262377379902 [[],[.under]] .three = true := by decide
def e2262377380322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2262377380322 : Closed e2262377380322 ∧ code e2262377380322 = 11058470402530 := by decide
theorem cert_e2262377380322 : check e2262377380322 [[],[.under]] .three = true := by decide
def e2262377380334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262377380334 : Closed e2262377380334 ∧ code e2262377380334 = 11058470402542 := by decide
theorem cert_e2262377380334 : check e2262377380334 [[],[.under]] .three = true := by decide
def e2262377380894 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2262377380894 : Closed e2262377380894 ∧ code e2262377380894 = 11058470403102 := by decide
theorem cert_e2262377380894 : check e2262377380894 [[],[.under]] .three = true := by decide
def e2262377381090 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2262377381090 : Closed e2262377381090 ∧ code e2262377381090 = 11058470403298 := by decide
theorem cert_e2262377381090 : check e2262377381090 [[],[.under]] .three = true := by decide
def e2262377381102 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377381102 : Closed e2262377381102 ∧ code e2262377381102 = 11058470403310 := by decide
theorem cert_e2262377381102 : check e2262377381102 [[],[.under]] .three = true := by decide
def e2262377381110 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377381110 : Closed e2262377381110 ∧ code e2262377381110 = 11058470403318 := by decide
theorem cert_e2262377381110 : check e2262377381110 [[],[.under]] .three = true := by decide
def e2262377400286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 3)))))))))
theorem wire_e2262377400286 : Closed e2262377400286 ∧ code e2262377400286 = 11058470422494 := by decide
theorem cert_e2262377400286 : check e2262377400286 [[],[.under]] .three = true := by decide
def e2262377403950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2262377403950 : Closed e2262377403950 ∧ code e2262377403950 = 11058470426158 := by decide
theorem cert_e2262377403950 : check e2262377403950 [[],[.under]] .three = true := by decide
def e2262377404130 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2262377404130 : Closed e2262377404130 ∧ code e2262377404130 = 11058470426338 := by decide
theorem cert_e2262377404130 : check e2262377404130 [[],[.under]] .three = true := by decide
def e2262377404142 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2262377404142 : Closed e2262377404142 ∧ code e2262377404142 = 11058470426350 := by decide
theorem cert_e2262377404142 : check e2262377404142 [[],[.under]] .three = true := by decide
def e2262377404270 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 1)) (.var 2))))))))
theorem wire_e2262377404270 : Closed e2262377404270 ∧ code e2262377404270 = 11058470426478 := by decide
theorem cert_e2262377404270 : check e2262377404270 [[],[.under]] .three = true := by decide
def e2262377404278 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 1))))))))
theorem wire_e2262377404278 : Closed e2262377404278 ∧ code e2262377404278 = 11058470426486 := by decide
theorem cert_e2262377404278 : check e2262377404278 [[],[.under]] .three = true := by decide
def e2262377404298 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262377404298 : Closed e2262377404298 ∧ code e2262377404298 = 11058470426506 := by decide
theorem cert_e2262377404298 : check e2262377404298 [[],[.under]] .three = true := by decide
def e2262377404322 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262377404322 : Closed e2262377404322 ∧ code e2262377404322 = 11058470426530 := by decide
theorem cert_e2262377404322 : check e2262377404322 [[],[.under]] .three = true := by decide
def e2262377404334 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2262377404334 : Closed e2262377404334 ∧ code e2262377404334 = 11058470426542 := by decide
theorem cert_e2262377404334 : check e2262377404334 [[],[.under]] .three = true := by decide
def e2262377404342 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 1))))))))
theorem wire_e2262377404342 : Closed e2262377404342 ∧ code e2262377404342 = 11058470426550 := by decide
theorem cert_e2262377404342 : check e2262377404342 [[],[.under]] .three = true := by decide
def e2262377404346 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2262377404346 : Closed e2262377404346 ∧ code e2262377404346 = 11058470426554 := by decide
theorem cert_e2262377404346 : check e2262377404346 [[],[.under]] .three = true := by decide
def e2262377404478 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2262377404478 : Closed e2262377404478 ∧ code e2262377404478 = 11058470426686 := by decide
theorem cert_e2262377404478 : check e2262377404478 [[],[.under]] .three = true := by decide
def e2262377404898 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2262377404898 : Closed e2262377404898 ∧ code e2262377404898 = 11058470427106 := by decide
theorem cert_e2262377404898 : check e2262377404898 [[],[.under]] .three = true := by decide
def e2262377404910 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2262377404910 : Closed e2262377404910 ∧ code e2262377404910 = 11058470427118 := by decide
theorem cert_e2262377404910 : check e2262377404910 [[],[.under]] .three = true := by decide
def e2262377405678 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377405678 : Closed e2262377405678 ∧ code e2262377405678 = 11058470427886 := by decide
theorem cert_e2262377405678 : check e2262377405678 [[],[.under]] .three = true := by decide
def e2262377405686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377405686 : Closed e2262377405686 ∧ code e2262377405686 = 11058470427894 := by decide
theorem cert_e2262377405686 : check e2262377405686 [[],[.under]] .three = true := by decide
def e2262377405966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2262377405966 : Closed e2262377405966 ∧ code e2262377405966 = 11058470428174 := by decide
theorem cert_e2262377405966 : check e2262377405966 [[],[.under]] .three = true := by decide
def e2262377405978 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2262377405978 : Closed e2262377405978 ∧ code e2262377405978 = 11058470428186 := by decide
theorem cert_e2262377405978 : check e2262377405978 [[],[.under]] .three = true := by decide
def e2262377406050 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262377406050 : Closed e2262377406050 ∧ code e2262377406050 = 11058470428258 := by decide
theorem cert_e2262377406050 : check e2262377406050 [[],[.under]] .three = true := by decide
def e2262377406062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377406062 : Closed e2262377406062 ∧ code e2262377406062 = 11058470428270 := by decide
theorem cert_e2262377406062 : check e2262377406062 [[],[.under]] .three = true := by decide
def e2262377406070 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262377406070 : Closed e2262377406070 ∧ code e2262377406070 = 11058470428278 := by decide
theorem cert_e2262377406070 : check e2262377406070 [[],[.under]] .three = true := by decide
def e2262377406074 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377406074 : Closed e2262377406074 ∧ code e2262377406074 = 11058470428282 := by decide
theorem cert_e2262377406074 : check e2262377406074 [[],[.under]] .three = true := by decide
def e2262377415646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2262377415646 : Closed e2262377415646 ∧ code e2262377415646 = 11058470437854 := by decide
theorem cert_e2262377415646 : check e2262377415646 [[],[.under]] .three = true := by decide
def e2262377415662 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2262377415662 : Closed e2262377415662 ∧ code e2262377415662 = 11058470437870 := by decide
theorem cert_e2262377415662 : check e2262377415662 [[],[.under]] .three = true := by decide
def e2262377417494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2262377417494 : Closed e2262377417494 ∧ code e2262377417494 = 11058470439702 := by decide
theorem cert_e2262377417494 : check e2262377417494 [[],[.under]] .three = true := by decide
def e2262377417570 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2262377417570 : Closed e2262377417570 ∧ code e2262377417570 = 11058470439778 := by decide
theorem cert_e2262377417570 : check e2262377417570 [[],[.under]] .three = true := by decide
def e2262377417582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2262377417582 : Closed e2262377417582 ∧ code e2262377417582 = 11058470439790 := by decide
theorem cert_e2262377417582 : check e2262377417582 [[],[.under]] .three = true := by decide
def e2262377417590 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2262377417590 : Closed e2262377417590 ∧ code e2262377417590 = 11058470439798 := by decide
theorem cert_e2262377417590 : check e2262377417590 [[],[.under]] .three = true := by decide
def e2262377417610 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2262377417610 : Closed e2262377417610 ∧ code e2262377417610 = 11058470439818 := by decide
theorem cert_e2262377417610 : check e2262377417610 [[],[.under]] .three = true := by decide
def e2262377417634 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2262377417634 : Closed e2262377417634 ∧ code e2262377417634 = 11058470439842 := by decide
theorem cert_e2262377417634 : check e2262377417634 [[],[.under]] .three = true := by decide
def e2262377417646 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2262377417646 : Closed e2262377417646 ∧ code e2262377417646 = 11058470439854 := by decide
theorem cert_e2262377417646 : check e2262377417646 [[],[.under]] .three = true := by decide
def e2262377417654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))))))))
theorem wire_e2262377417654 : Closed e2262377417654 ∧ code e2262377417654 = 11058470439862 := by decide
theorem cert_e2262377417654 : check e2262377417654 [[],[.under]] .three = true := by decide
def e2262377417658 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2262377417658 : Closed e2262377417658 ∧ code e2262377417658 = 11058470439866 := by decide
theorem cert_e2262377417658 : check e2262377417658 [[],[.under]] .three = true := by decide
def e2262377417686 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2262377417686 : Closed e2262377417686 ∧ code e2262377417686 = 11058470439894 := by decide
theorem cert_e2262377417686 : check e2262377417686 [[],[.under]] .three = true := by decide
def e2262377417690 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2262377417690 : Closed e2262377417690 ∧ code e2262377417690 = 11058470439898 := by decide
theorem cert_e2262377417690 : check e2262377417690 [[],[.under]] .three = true := by decide
def e2262377417758 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2262377417758 : Closed e2262377417758 ∧ code e2262377417758 = 11058470439966 := by decide
theorem cert_e2262377417758 : check e2262377417758 [[],[.under]] .three = true := by decide
def e2262377417954 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2262377417954 : Closed e2262377417954 ∧ code e2262377417954 = 11058470440162 := by decide
theorem cert_e2262377417954 : check e2262377417954 [[],[.under]] .three = true := by decide
def e2262377417966 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377417966 : Closed e2262377417966 ∧ code e2262377417966 = 11058470440174 := by decide
theorem cert_e2262377417966 : check e2262377417966 [[],[.under]] .three = true := by decide
def e2262377417974 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377417974 : Closed e2262377417974 ∧ code e2262377417974 = 11058470440182 := by decide
theorem cert_e2262377417974 : check e2262377417974 [[],[.under]] .three = true := by decide
def e2262377418254 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2262377418254 : Closed e2262377418254 ∧ code e2262377418254 = 11058470440462 := by decide
theorem cert_e2262377418254 : check e2262377418254 [[],[.under]] .three = true := by decide
def e2262377418266 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2262377418266 : Closed e2262377418266 ∧ code e2262377418266 = 11058470440474 := by decide
theorem cert_e2262377418266 : check e2262377418266 [[],[.under]] .three = true := by decide
def e2262377418338 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2262377418338 : Closed e2262377418338 ∧ code e2262377418338 = 11058470440546 := by decide
theorem cert_e2262377418338 : check e2262377418338 [[],[.under]] .three = true := by decide
def e2262377418350 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2262377418350 : Closed e2262377418350 ∧ code e2262377418350 = 11058470440558 := by decide
theorem cert_e2262377418350 : check e2262377418350 [[],[.under]] .three = true := by decide
def e2262377418358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 1)))))))))
theorem wire_e2262377418358 : Closed e2262377418358 ∧ code e2262377418358 = 11058470440566 := by decide
theorem cert_e2262377418358 : check e2262377418358 [[],[.under]] .three = true := by decide
def e2262377418362 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2262377418362 : Closed e2262377418362 ∧ code e2262377418362 = 11058470440570 := by decide
theorem cert_e2262377418362 : check e2262377418362 [[],[.under]] .three = true := by decide
def e2262377418550 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2262377418550 : Closed e2262377418550 ∧ code e2262377418550 = 11058470440758 := by decide
theorem cert_e2262377418550 : check e2262377418550 [[],[.under]] .three = true := by decide
def e2262377418554 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2262377418554 : Closed e2262377418554 ∧ code e2262377418554 = 11058470440762 := by decide
theorem cert_e2262377418554 : check e2262377418554 [[],[.under]] .three = true := by decide
def e2262377699038 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e2262377699038 : Closed e2262377699038 ∧ code e2262377699038 = 11058470721246 := by decide
theorem cert_e2262377699038 : check e2262377699038 [[],[.under]] .smaller = true := by decide
def e2262377699062 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e2262377699062 : Closed e2262377699062 ∧ code e2262377699062 = 11058470721270 := by decide
theorem cert_e2262377699062 : check e2262377699062 [[],[.under]] .smaller = true := by decide
def e2262377699166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e2262377699166 : Closed e2262377699166 ∧ code e2262377699166 = 11058470721374 := by decide
theorem cert_e2262377699166 : check e2262377699166 [[],[.under]] .smaller = true := by decide
def e2262377699194 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e2262377699194 : Closed e2262377699194 ∧ code e2262377699194 = 11058470721402 := by decide
theorem cert_e2262377699194 : check e2262377699194 [[],[.under]] .smaller = true := by decide
def e2262377699286 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e2262377699286 : Closed e2262377699286 ∧ code e2262377699286 = 11058470721494 := by decide
theorem cert_e2262377699286 : check e2262377699286 [[],[.under]] .smaller = true := by decide
def e2262377699290 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e2262377699290 : Closed e2262377699290 ∧ code e2262377699290 = 11058470721498 := by decide
theorem cert_e2262377699290 : check e2262377699290 [[],[.under]] .smaller = true := by decide
def e2262377699806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e2262377699806 : Closed e2262377699806 ∧ code e2262377699806 = 11058470722014 := by decide
theorem cert_e2262377699806 : check e2262377699806 [[],[.under]] .smaller = true := by decide
def e2262377699830 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e2262377699830 : Closed e2262377699830 ∧ code e2262377699830 = 11058470722038 := by decide
theorem cert_e2262377699830 : check e2262377699830 [[],[.under]] .smaller = true := by decide
def e2262377700574 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e2262377700574 : Closed e2262377700574 ∧ code e2262377700574 = 11058470722782 := by decide
theorem cert_e2262377700574 : check e2262377700574 [[],[.under]] .smaller = true := by decide
def e2262377700602 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e2262377700602 : Closed e2262377700602 ∧ code e2262377700602 = 11058470722810 := by decide
theorem cert_e2262377700602 : check e2262377700602 [[],[.under]] .smaller = true := by decide
def e2262377701174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e2262377701174 : Closed e2262377701174 ∧ code e2262377701174 = 11058470723382 := by decide
theorem cert_e2262377701174 : check e2262377701174 [[],[.under]] .smaller = true := by decide
def e2262377701178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e2262377701178 : Closed e2262377701178 ∧ code e2262377701178 = 11058470723386 := by decide
theorem cert_e2262377701178 : check e2262377701178 [[],[.under]] .smaller = true := by decide
def e2262377715950 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e2262377715950 : Closed e2262377715950 ∧ code e2262377715950 = 11058470738158 := by decide
theorem cert_e2262377715950 : check e2262377715950 [[],[.under]] .smaller = true := by decide
def e2262377715958 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e2262377715958 : Closed e2262377715958 ∧ code e2262377715958 = 11058470738166 := by decide
theorem cert_e2262377715958 : check e2262377715958 [[],[.under]] .smaller = true := by decide
def e2262377716510 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e2262377716510 : Closed e2262377716510 ∧ code e2262377716510 = 11058470738718 := by decide
theorem cert_e2262377716510 : check e2262377716510 [[],[.under]] .smaller = true := by decide
def e2262377716622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e2262377716622 : Closed e2262377716622 ∧ code e2262377716622 = 11058470738830 := by decide
theorem cert_e2262377716622 : check e2262377716622 [[],[.under]] .smaller = true := by decide
def e2262377716846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e2262377716846 : Closed e2262377716846 ∧ code e2262377716846 = 11058470739054 := by decide
theorem cert_e2262377716846 : check e2262377716846 [[],[.under]] .smaller = true := by decide
def e2262377716858 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2262377716858 : Closed e2262377716858 ∧ code e2262377716858 = 11058470739066 := by decide
theorem cert_e2262377716858 : check e2262377716858 [[],[.under]] .smaller = true := by decide
def e2262377717022 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2262377717022 : Closed e2262377717022 ∧ code e2262377717022 = 11058470739230 := by decide
theorem cert_e2262377717022 : check e2262377717022 [[],[.under]] .smaller = true := by decide
def e2262377717190 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2262377717190 : Closed e2262377717190 ∧ code e2262377717190 = 11058470739398 := by decide
theorem cert_e2262377717190 : check e2262377717190 [[],[.under]] .smaller = true := by decide
def e2262377717214 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 3))))))))
theorem wire_e2262377717214 : Closed e2262377717214 ∧ code e2262377717214 = 11058470739422 := by decide
theorem cert_e2262377717214 : check e2262377717214 [[],[.under]] .three = true := by decide
def e2262377717230 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.var 2))))))))
theorem wire_e2262377717230 : Closed e2262377717230 ∧ code e2262377717230 = 11058470739438 := by decide
theorem cert_e2262377717230 : check e2262377717230 [[],[.under]] .three = true := by decide
def e2262377717302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2262377717302 : Closed e2262377717302 ∧ code e2262377717302 = 11058470739510 := by decide
theorem cert_e2262377717302 : check e2262377717302 [[],[.under]] .smaller = true := by decide
def e2262377717306 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2262377717306 : Closed e2262377717306 ∧ code e2262377717306 = 11058470739514 := by decide
theorem cert_e2262377717306 : check e2262377717306 [[],[.under]] .smaller = true := by decide
def e2262377717390 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2262377717390 : Closed e2262377717390 ∧ code e2262377717390 = 11058470739598 := by decide
theorem cert_e2262377717390 : check e2262377717390 [[],[.under]] .smaller = true := by decide
def e2262377717446 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2262377717446 : Closed e2262377717446 ∧ code e2262377717446 = 11058470739654 := by decide
theorem cert_e2262377717446 : check e2262377717446 [[],[.under]] .smaller = true := by decide
def e2262377717470 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 3))))))))
theorem wire_e2262377717470 : Closed e2262377717470 ∧ code e2262377717470 = 11058470739678 := by decide
theorem cert_e2262377717470 : check e2262377717470 [[],[.under]] .three = true := by decide
def e2262377717494 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.var 1))))))))
theorem wire_e2262377717494 : Closed e2262377717494 ∧ code e2262377717494 = 11058470739702 := by decide
theorem cert_e2262377717494 : check e2262377717494 [[],[.under]] .three = true := by decide
def e2262377717614 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.var 2))))))))
theorem wire_e2262377717614 : Closed e2262377717614 ∧ code e2262377717614 = 11058470739822 := by decide
theorem cert_e2262377717614 : check e2262377717614 [[],[.under]] .three = true := by decide
def e2262377717622 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.var 1))))))))
theorem wire_e2262377717622 : Closed e2262377717622 ∧ code e2262377717622 = 11058470739830 := by decide
theorem cert_e2262377717622 : check e2262377717622 [[],[.under]] .three = true := by decide
def e2262377719582 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2262377719582 : Closed e2262377719582 ∧ code e2262377719582 = 11058470741790 := by decide
theorem cert_e2262377719582 : check e2262377719582 [[],[.under]] .smaller = true := by decide
def e2262377719694 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2262377719694 : Closed e2262377719694 ∧ code e2262377719694 = 11058470741902 := by decide
theorem cert_e2262377719694 : check e2262377719694 [[],[.under]] .smaller = true := by decide
def e2262377722654 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2262377722654 : Closed e2262377722654 ∧ code e2262377722654 = 11058470744862 := by decide
theorem cert_e2262377722654 : check e2262377722654 [[],[.under]] .smaller = true := by decide
def e2262377722822 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2262377722822 : Closed e2262377722822 ∧ code e2262377722822 = 11058470745030 := by decide
theorem cert_e2262377722822 : check e2262377722822 [[],[.under]] .smaller = true := by decide
def e2262377722846 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 3)))))))))
theorem wire_e2262377722846 : Closed e2262377722846 ∧ code e2262377722846 = 11058470745054 := by decide
theorem cert_e2262377722846 : check e2262377722846 [[],[.under]] .three = true := by decide
def e2262377722862 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.var 2)))))))))
theorem wire_e2262377722862 : Closed e2262377722862 ∧ code e2262377722862 = 11058470745070 := by decide
theorem cert_e2262377722862 : check e2262377722862 [[],[.under]] .three = true := by decide
def e2262377724302 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2262377724302 : Closed e2262377724302 ∧ code e2262377724302 = 11058470746510 := by decide
theorem cert_e2262377724302 : check e2262377724302 [[],[.under]] .smaller = true := by decide
def e2262377724358 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2262377724358 : Closed e2262377724358 ∧ code e2262377724358 = 11058470746566 := by decide
theorem cert_e2262377724358 : check e2262377724358 [[],[.under]] .smaller = true := by decide
def e2262377724382 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))))
theorem wire_e2262377724382 : Closed e2262377724382 ∧ code e2262377724382 = 11058470746590 := by decide
theorem cert_e2262377724382 : check e2262377724382 [[],[.under]] .three = true := by decide
def e2262377724406 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))))
theorem wire_e2262377724406 : Closed e2262377724406 ∧ code e2262377724406 = 11058470746614 := by decide
theorem cert_e2262377724406 : check e2262377724406 [[],[.under]] .three = true := by decide
def e2262377725166 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))
theorem wire_e2262377725166 : Closed e2262377725166 ∧ code e2262377725166 = 11058470747374 := by decide
theorem cert_e2262377725166 : check e2262377725166 [[],[.under]] .three = true := by decide
def e2262377725174 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))
theorem wire_e2262377725174 : Closed e2262377725174 ∧ code e2262377725174 = 11058470747382 := by decide
theorem cert_e2262377725174 : check e2262377725174 [[],[.under]] .three = true := by decide
def e2262377765486 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2262377765486 : Closed e2262377765486 ∧ code e2262377765486 = 11058470787694 := by decide
theorem cert_e2262377765486 : check e2262377765486 [[],[.under]] .three = true := by decide
def e2262377765498 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2262377765498 : Closed e2262377765498 ∧ code e2262377765498 = 11058470787706 := by decide
theorem cert_e2262377765498 : check e2262377765498 [[],[.under]] .three = true := by decide
def e2262377781422 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2262377781422 : Closed e2262377781422 ∧ code e2262377781422 = 11058470803630 := by decide
theorem cert_e2262377781422 : check e2262377781422 [[],[.under]] .three = true := by decide
def e2262377781434 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2262377781434 : Closed e2262377781434 ∧ code e2262377781434 = 11058470803642 := by decide
theorem cert_e2262377781434 : check e2262377781434 [[],[.under]] .three = true := by decide
def e2262377781806 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2262377781806 : Closed e2262377781806 ∧ code e2262377781806 = 11058470804014 := by decide
theorem cert_e2262377781806 : check e2262377781806 [[],[.under]] .three = true := by decide
def e2262377781986 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2262377781986 : Closed e2262377781986 ∧ code e2262377781986 = 11058470804194 := by decide
theorem cert_e2262377781986 : check e2262377781986 [[],[.under]] .three = true := by decide
def e2262377781998 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)))))))
theorem wire_e2262377781998 : Closed e2262377781998 ∧ code e2262377781998 = 11058470804206 := by decide
theorem cert_e2262377781998 : check e2262377781998 [[],[.under]] .three = true := by decide
def e2262377782126 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))
theorem wire_e2262377782126 : Closed e2262377782126 ∧ code e2262377782126 = 11058470804334 := by decide
theorem cert_e2262377782126 : check e2262377782126 [[],[.under]] .three = true := by decide
def e2262377782134 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))
theorem wire_e2262377782134 : Closed e2262377782134 ∧ code e2262377782134 = 11058470804342 := by decide
theorem cert_e2262377782134 : check e2262377782134 [[],[.under]] .three = true := by decide
def e2262377782154 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2262377782154 : Closed e2262377782154 ∧ code e2262377782154 = 11058470804362 := by decide
theorem cert_e2262377782154 : check e2262377782154 [[],[.under]] .three = true := by decide
def e2262377782178 : Term := (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2262377782178 : Closed e2262377782178 ∧ code e2262377782178 = 11058470804386 := by decide
theorem cert_e2262377782178 : check e2262377782178 [[],[.under]] .three = true := by decide
end Blc.Floor43
