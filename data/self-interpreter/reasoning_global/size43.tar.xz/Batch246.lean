import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393421106702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2393421106702 : Closed e2393421106702 ∧ code e2393421106702 = 11189514128910 := by decide
theorem cert_e2393421106702 : check e2393421106702 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2393421106786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2393421106786 : Closed e2393421106786 ∧ code e2393421106786 = 11189514128994 := by decide
theorem cert_e2393421106786 : check e2393421106786 [[],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2393421106798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2393421106798 : Closed e2393421106798 ∧ code e2393421106798 = 11189514129006 := by decide
def e2393421106810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2393421106810 : Closed e2393421106810 ∧ code e2393421106810 = 11189514129018 := by decide
def e2393421106998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2393421106998 : Closed e2393421106998 ∧ code e2393421106998 = 11189514129206 := by decide
def e2393421107002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2393421107002 : Closed e2393421107002 ∧ code e2393421107002 = 11189514129210 := by decide
def e2393421646702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393421646702 : Closed e2393421646702 ∧ code e2393421646702 = 11189514668910 := by decide
def e2393421646710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393421646710 : Closed e2393421646710 ∧ code e2393421646710 = 11189514668918 := by decide
def e2393421646766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393421646766 : Closed e2393421646766 ∧ code e2393421646766 = 11189514668974 := by decide
def e2393421646778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393421646778 : Closed e2393421646778 ∧ code e2393421646778 = 11189514668986 := by decide
private def t_e2393421646778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e2393421646778 : ¬ IsSelfInterpreter e2393421646778 :=
  wSource (t := t_e2393421646778) (replay_sound (ps := []) (t := e2393421646778) (by decide)) (by decide)
def e2393421646806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393421646806 : Closed e2393421646806 ∧ code e2393421646806 = 11189514669014 := by decide
def e2393421646810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393421646810 : Closed e2393421646810 ∧ code e2393421646810 = 11189514669018 := by decide
private def t_e2393421646810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e2393421646810 : ¬ IsSelfInterpreter e2393421646810 :=
  wSource (t := t_e2393421646810) (replay_sound (ps := []) (t := e2393421646810) (by decide)) (by decide)
def e2393421647086 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393421647086 : Closed e2393421647086 ∧ code e2393421647086 = 11189514669294 := by decide
theorem cert_e2393421647086 : check e2393421647086 [[],[.left],[.left],[.left],[.left],[.left],[],[],[.left],[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2393421647094 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393421647094 : Closed e2393421647094 ∧ code e2393421647094 = 11189514669302 := by decide
theorem cert_e2393421647094 : check e2393421647094 [[],[.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2393421647470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393421647470 : Closed e2393421647470 ∧ code e2393421647470 = 11189514669678 := by decide
theorem cert_e2393421647470 : check e2393421647470 [[],[.left],[.left],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2393421647482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393421647482 : Closed e2393421647482 ∧ code e2393421647482 = 11189514669690 := by decide
theorem cert_e2393421647482 : check e2393421647482 [[],[.left],[.left],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2393421647670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393421647670 : Closed e2393421647670 ∧ code e2393421647670 = 11189514669878 := by decide
theorem cert_e2393421647670 : check e2393421647670 [[],[.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2393421647674 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393421647674 : Closed e2393421647674 ∧ code e2393421647674 = 11189514669882 := by decide
theorem cert_e2393421647674 : check e2393421647674 [[],[.left],[.left],[.left],[.left],[.left],[],[],[.left],[],[],[.under],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left,.left],[.under,.left,.left,.left]] .sourceHead = true := by decide
def e2393424005998 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2393424005998 : Closed e2393424005998 ∧ code e2393424005998 = 11189517028206 := by decide
theorem cert_e2393424005998 : check e2393424005998 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left]] .chain = true := by decide
def e2393424006006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2393424006006 : Closed e2393424006006 ∧ code e2393424006006 = 11189517028214 := by decide
theorem cert_e2393424006006 : check e2393424006006 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2393424006062 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2393424006062 : Closed e2393424006062 ∧ code e2393424006062 = 11189517028270 := by decide
theorem cert_e2393424006062 : check e2393424006062 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .chain = true := by decide
def e2393424006074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2393424006074 : Closed e2393424006074 ∧ code e2393424006074 = 11189517028282 := by decide
theorem cert_e2393424006074 : check e2393424006074 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .chain = true := by decide
def e2393424006102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2393424006102 : Closed e2393424006102 ∧ code e2393424006102 = 11189517028310 := by decide
theorem cert_e2393424006102 : check e2393424006102 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393424006106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2393424006106 : Closed e2393424006106 ∧ code e2393424006106 = 11189517028314 := by decide
theorem cert_e2393424006106 : check e2393424006106 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2393424006382 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2393424006382 : Closed e2393424006382 ∧ code e2393424006382 = 11189517028590 := by decide
theorem cert_e2393424006382 : check e2393424006382 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left]] .chain = true := by decide
def e2393424006390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2393424006390 : Closed e2393424006390 ∧ code e2393424006390 = 11189517028598 := by decide
theorem cert_e2393424006390 : check e2393424006390 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2393424006766 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2393424006766 : Closed e2393424006766 ∧ code e2393424006766 = 11189517028974 := by decide
theorem cert_e2393424006766 : check e2393424006766 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393424006778 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2393424006778 : Closed e2393424006778 ∧ code e2393424006778 = 11189517028986 := by decide
theorem cert_e2393424006778 : check e2393424006778 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393424006966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2393424006966 : Closed e2393424006966 ∧ code e2393424006966 = 11189517029174 := by decide
theorem cert_e2393424006966 : check e2393424006966 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under]] .three = true := by decide
def e2393424006970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2393424006970 : Closed e2393424006970 ∧ code e2393424006970 = 11189517029178 := by decide
theorem cert_e2393424006970 : check e2393424006970 [[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under]] .three = true := by decide
def e2393518377838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393518377838 : Closed e2393518377838 ∧ code e2393518377838 = 11189611400046 := by decide
theorem cert_e2393518377838 : check e2393518377838 [[],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393518377846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393518377846 : Closed e2393518377846 ∧ code e2393518377846 = 11189611400054 := by decide
theorem cert_e2393518377846 : check e2393518377846 [[],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393518377902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393518377902 : Closed e2393518377902 ∧ code e2393518377902 = 11189611400110 := by decide
theorem cert_e2393518377902 : check e2393518377902 [[],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393518377914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393518377914 : Closed e2393518377914 ∧ code e2393518377914 = 11189611400122 := by decide
theorem cert_e2393518377914 : check e2393518377914 [[],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2393518377942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393518377942 : Closed e2393518377942 ∧ code e2393518377942 = 11189611400150 := by decide
theorem cert_e2393518377942 : check e2393518377942 [[],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393518377946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393518377946 : Closed e2393518377946 ∧ code e2393518377946 = 11189611400154 := by decide
theorem cert_e2393518377946 : check e2393518377946 [[],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2393518378222 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393518378222 : Closed e2393518378222 ∧ code e2393518378222 = 11189611400430 := by decide
theorem cert_e2393518378222 : check e2393518378222 [[],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2393518378230 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393518378230 : Closed e2393518378230 ∧ code e2393518378230 = 11189611400438 := by decide
theorem cert_e2393518378230 : check e2393518378230 [[],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2393518378606 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393518378606 : Closed e2393518378606 ∧ code e2393518378606 = 11189611400814 := by decide
theorem cert_e2393518378606 : check e2393518378606 [[],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2393518378618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393518378618 : Closed e2393518378618 ∧ code e2393518378618 = 11189611400826 := by decide
theorem cert_e2393518378618 : check e2393518378618 [[],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2393518378806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393518378806 : Closed e2393518378806 ∧ code e2393518378806 = 11189611401014 := by decide
theorem cert_e2393518378806 : check e2393518378806 [[],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2393518378810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393518378810 : Closed e2393518378810 ∧ code e2393518378810 = 11189611401018 := by decide
theorem cert_e2393518378810 : check e2393518378810 [[],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2405229649946 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405229649946 : Closed e2405229649946 ∧ code e2405229649946 = 11201322672154 := by decide
theorem cert_e2405229649946 : check e2405229649946 [[]] .width = true := by decide
def e2405229650038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405229650038 : Closed e2405229650038 ∧ code e2405229650038 = 11201322672246 := by decide
theorem cert_e2405229650038 : check e2405229650038 [[]] .width = true := by decide
def e2405229650282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405229650282 : Closed e2405229650282 ∧ code e2405229650282 = 11201322672490 := by decide
theorem cert_e2405229650282 : check e2405229650282 [[]] .width = true := by decide
def e2405229650330 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 4)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405229650330 : Closed e2405229650330 ∧ code e2405229650330 = 11201322672538 := by decide
theorem cert_e2405229650330 : check e2405229650330 [[]] .width = true := by decide
def e2405229879322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405229879322 : Closed e2405229879322 ∧ code e2405229879322 = 11201322901530 := by decide
theorem cert_e2405229879322 : check e2405229879322 [[]] .width = true := by decide
def e2405229879414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405229879414 : Closed e2405229879414 ∧ code e2405229879414 = 11201322901622 := by decide
theorem cert_e2405229879414 : check e2405229879414 [[]] .width = true := by decide
def e2405229879658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405229879658 : Closed e2405229879658 ∧ code e2405229879658 = 11201322901866 := by decide
theorem cert_e2405229879658 : check e2405229879658 [[]] .width = true := by decide
def e2405229879706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405229879706 : Closed e2405229879706 ∧ code e2405229879706 = 11201322901914 := by decide
theorem cert_e2405229879706 : check e2405229879706 [[]] .width = true := by decide
def e2405230698522 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405230698522 : Closed e2405230698522 ∧ code e2405230698522 = 11201323720730 := by decide
theorem cert_e2405230698522 : check e2405230698522 [[]] .width = true := by decide
def e2405230698614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405230698614 : Closed e2405230698614 ∧ code e2405230698614 = 11201323720822 := by decide
theorem cert_e2405230698614 : check e2405230698614 [[]] .width = true := by decide
def e2405230698858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405230698858 : Closed e2405230698858 ∧ code e2405230698858 = 11201323721066 := by decide
theorem cert_e2405230698858 : check e2405230698858 [[]] .width = true := by decide
def e2405230698906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 4)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405230698906 : Closed e2405230698906 ∧ code e2405230698906 = 11201323721114 := by decide
theorem cert_e2405230698906 : check e2405230698906 [[]] .width = true := by decide
def e2405230944282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405230944282 : Closed e2405230944282 ∧ code e2405230944282 = 11201323966490 := by decide
theorem cert_e2405230944282 : check e2405230944282 [[]] .width = true := by decide
def e2405230944374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405230944374 : Closed e2405230944374 ∧ code e2405230944374 = 11201323966582 := by decide
theorem cert_e2405230944374 : check e2405230944374 [[]] .width = true := by decide
def e2405230944618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405230944618 : Closed e2405230944618 ∧ code e2405230944618 = 11201323966826 := by decide
theorem cert_e2405230944618 : check e2405230944618 [[]] .width = true := by decide
def e2405230944666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 4)) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405230944666 : Closed e2405230944666 ∧ code e2405230944666 = 11201323966874 := by decide
theorem cert_e2405230944666 : check e2405230944666 [[]] .width = true := by decide
def e2405231845402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405231845402 : Closed e2405231845402 ∧ code e2405231845402 = 11201324867610 := by decide
theorem cert_e2405231845402 : check e2405231845402 [[]] .width = true := by decide
def e2405231845494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405231845494 : Closed e2405231845494 ∧ code e2405231845494 = 11201324867702 := by decide
theorem cert_e2405231845494 : check e2405231845494 [[]] .width = true := by decide
def e2405231845738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405231845738 : Closed e2405231845738 ∧ code e2405231845738 = 11201324867946 := by decide
theorem cert_e2405231845738 : check e2405231845738 [[]] .width = true := by decide
def e2405231845786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405231845786 : Closed e2405231845786 ∧ code e2405231845786 = 11201324867994 := by decide
theorem cert_e2405231845786 : check e2405231845786 [[]] .width = true := by decide
def e2405231861786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405231861786 : Closed e2405231861786 ∧ code e2405231861786 = 11201324883994 := by decide
theorem cert_e2405231861786 : check e2405231861786 [[]] .width = true := by decide
def e2405231861878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405231861878 : Closed e2405231861878 ∧ code e2405231861878 = 11201324884086 := by decide
theorem cert_e2405231861878 : check e2405231861878 [[]] .width = true := by decide
def e2405231862122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405231862122 : Closed e2405231862122 ∧ code e2405231862122 = 11201324884330 := by decide
theorem cert_e2405231862122 : check e2405231862122 [[]] .width = true := by decide
def e2405231862170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.app (.var 4) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405231862170 : Closed e2405231862170 ∧ code e2405231862170 = 11201324884378 := by decide
theorem cert_e2405231862170 : check e2405231862170 [[]] .width = true := by decide
def e2405235941402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405235941402 : Closed e2405235941402 ∧ code e2405235941402 = 11201328963610 := by decide
theorem cert_e2405235941402 : check e2405235941402 [[]] .width = true := by decide
def e2405235941494 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405235941494 : Closed e2405235941494 ∧ code e2405235941494 = 11201328963702 := by decide
theorem cert_e2405235941494 : check e2405235941494 [[]] .width = true := by decide
def e2405235941738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405235941738 : Closed e2405235941738 ∧ code e2405235941738 = 11201328963946 := by decide
theorem cert_e2405235941738 : check e2405235941738 [[]] .width = true := by decide
def e2405235941786 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 4))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405235941786 : Closed e2405235941786 ∧ code e2405235941786 = 11201328963994 := by decide
theorem cert_e2405235941786 : check e2405235941786 [[]] .width = true := by decide
def e2405236170778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405236170778 : Closed e2405236170778 ∧ code e2405236170778 = 11201329192986 := by decide
theorem cert_e2405236170778 : check e2405236170778 [[]] .width = true := by decide
def e2405236170870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405236170870 : Closed e2405236170870 ∧ code e2405236170870 = 11201329193078 := by decide
theorem cert_e2405236170870 : check e2405236170870 [[]] .width = true := by decide
def e2405236171114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405236171114 : Closed e2405236171114 ∧ code e2405236171114 = 11201329193322 := by decide
theorem cert_e2405236171114 : check e2405236171114 [[]] .width = true := by decide
def e2405236171162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 4) (.var 1))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405236171162 : Closed e2405236171162 ∧ code e2405236171162 = 11201329193370 := by decide
theorem cert_e2405236171162 : check e2405236171162 [[]] .width = true := by decide
def e2405242232858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405242232858 : Closed e2405242232858 ∧ code e2405242232858 = 11201335255066 := by decide
theorem cert_e2405242232858 : check e2405242232858 [[]] .width = true := by decide
def e2405242232950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405242232950 : Closed e2405242232950 ∧ code e2405242232950 = 11201335255158 := by decide
theorem cert_e2405242232950 : check e2405242232950 [[]] .width = true := by decide
def e2405242233194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405242233194 : Closed e2405242233194 ∧ code e2405242233194 = 11201335255402 := by decide
theorem cert_e2405242233194 : check e2405242233194 [[]] .width = true := by decide
def e2405242233242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 4))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405242233242 : Closed e2405242233242 ∧ code e2405242233242 = 11201335255450 := by decide
theorem cert_e2405242233242 : check e2405242233242 [[]] .width = true := by decide
def e2405242478618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405242478618 : Closed e2405242478618 ∧ code e2405242478618 = 11201335500826 := by decide
theorem cert_e2405242478618 : check e2405242478618 [[]] .width = true := by decide
def e2405242478710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405242478710 : Closed e2405242478710 ∧ code e2405242478710 = 11201335500918 := by decide
theorem cert_e2405242478710 : check e2405242478710 [[]] .width = true := by decide
def e2405242478954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405242478954 : Closed e2405242478954 ∧ code e2405242478954 = 11201335501162 := by decide
theorem cert_e2405242478954 : check e2405242478954 [[]] .width = true := by decide
def e2405242479002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 4) (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405242479002 : Closed e2405242479002 ∧ code e2405242479002 = 11201335501210 := by decide
theorem cert_e2405242479002 : check e2405242479002 [[]] .width = true := by decide
def e2405247967258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405247967258 : Closed e2405247967258 ∧ code e2405247967258 = 11201340989466 := by decide
theorem cert_e2405247967258 : check e2405247967258 [[]] .width = true := by decide
def e2405247967350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405247967350 : Closed e2405247967350 ∧ code e2405247967350 = 11201340989558 := by decide
theorem cert_e2405247967350 : check e2405247967350 [[]] .width = true := by decide
def e2405247967594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405247967594 : Closed e2405247967594 ∧ code e2405247967594 = 11201340989802 := by decide
theorem cert_e2405247967594 : check e2405247967594 [[]] .width = true := by decide
def e2405247967642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405247967642 : Closed e2405247967642 ∧ code e2405247967642 = 11201340989850 := by decide
theorem cert_e2405247967642 : check e2405247967642 [[]] .width = true := by decide
def e2405247983642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405247983642 : Closed e2405247983642 ∧ code e2405247983642 = 11201341005850 := by decide
theorem cert_e2405247983642 : check e2405247983642 [[]] .width = true := by decide
def e2405247983734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405247983734 : Closed e2405247983734 ∧ code e2405247983734 = 11201341005942 := by decide
theorem cert_e2405247983734 : check e2405247983734 [[]] .width = true := by decide
def e2405247983978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405247983978 : Closed e2405247983978 ∧ code e2405247983978 = 11201341006186 := by decide
theorem cert_e2405247983978 : check e2405247983978 [[]] .width = true := by decide
def e2405247984026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.lam (.app (.var 4) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405247984026 : Closed e2405247984026 ∧ code e2405247984026 = 11201341006234 := by decide
theorem cert_e2405247984026 : check e2405247984026 [[]] .width = true := by decide
def e2405363544262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405363544262 : Closed e2405363544262 ∧ code e2405363544262 = 11201456566470 := by decide
theorem cert_e2405363544262 : check e2405363544262 [[]] .width = true := by decide
def e2405363593414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405363593414 : Closed e2405363593414 ∧ code e2405363593414 = 11201456615622 := by decide
theorem cert_e2405363593414 : check e2405363593414 [[]] .width = true := by decide
def e2405363806406 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405363806406 : Closed e2405363806406 ∧ code e2405363806406 = 11201456828614 := by decide
theorem cert_e2405363806406 : check e2405363806406 [[]] .width = true := by decide
def e2405363863750 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405363863750 : Closed e2405363863750 ∧ code e2405363863750 = 11201456885958 := by decide
theorem cert_e2405363863750 : check e2405363863750 [[]] .width = true := by decide
def e2405363867162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405363867162 : Closed e2405363867162 ∧ code e2405363867162 = 11201456889370 := by decide
theorem cert_e2405363867162 : check e2405363867162 [[]] .width = true := by decide
def e2405364052166 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405364052166 : Closed e2405364052166 ∧ code e2405364052166 = 11201457074374 := by decide
theorem cert_e2405364052166 : check e2405364052166 [[]] .width = true := by decide
def e2405364060358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405364060358 : Closed e2405364060358 ∧ code e2405364060358 = 11201457082566 := by decide
theorem cert_e2405364060358 : check e2405364060358 [[]] .width = true := by decide
def e2405364063770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405364063770 : Closed e2405364063770 ∧ code e2405364063770 = 11201457085978 := by decide
theorem cert_e2405364063770 : check e2405364063770 [[]] .width = true := by decide
def e2405364069914 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405364069914 : Closed e2405364069914 ∧ code e2405364069914 = 11201457092122 := by decide
theorem cert_e2405364069914 : check e2405364069914 [[]] .width = true := by decide
def e2405364854982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405364854982 : Closed e2405364854982 ∧ code e2405364854982 = 11201457877190 := by decide
theorem cert_e2405364854982 : check e2405364854982 [[]] .width = true := by decide
def e2405364912326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405364912326 : Closed e2405364912326 ∧ code e2405364912326 = 11201457934534 := by decide
theorem cert_e2405364912326 : check e2405364912326 [[]] .width = true := by decide
def e2405364915738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405364915738 : Closed e2405364915738 ∧ code e2405364915738 = 11201457937946 := by decide
theorem cert_e2405364915738 : check e2405364915738 [[]] .width = true := by decide
def e2405365141702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405365141702 : Closed e2405365141702 ∧ code e2405365141702 = 11201458163910 := by decide
theorem cert_e2405365141702 : check e2405365141702 [[]] .width = true := by decide
def e2405365145114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365145114 : Closed e2405365145114 ∧ code e2405365145114 = 11201458167322 := by decide
theorem cert_e2405365145114 : check e2405365145114 [[]] .width = true := by decide
def e2405365152282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365152282 : Closed e2405365152282 ∧ code e2405365152282 = 11201458174490 := by decide
theorem cert_e2405365152282 : check e2405365152282 [[]] .width = true := by decide
def e2405365887174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405365887174 : Closed e2405365887174 ∧ code e2405365887174 = 11201458909382 := by decide
theorem cert_e2405365887174 : check e2405365887174 [[]] .width = true := by decide
def e2405365895366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405365895366 : Closed e2405365895366 ∧ code e2405365895366 = 11201458917574 := by decide
theorem cert_e2405365895366 : check e2405365895366 [[]] .width = true := by decide
def e2405365898778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365898778 : Closed e2405365898778 ∧ code e2405365898778 = 11201458920986 := by decide
theorem cert_e2405365898778 : check e2405365898778 [[]] .width = true := by decide
def e2405365904922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 3)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365904922 : Closed e2405365904922 ∧ code e2405365904922 = 11201458927130 := by decide
theorem cert_e2405365904922 : check e2405365904922 [[]] .width = true := by decide
def e2405365928134 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405365928134 : Closed e2405365928134 ∧ code e2405365928134 = 11201458950342 := by decide
theorem cert_e2405365928134 : check e2405365928134 [[]] .width = true := by decide
def e2405365931546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365931546 : Closed e2405365931546 ∧ code e2405365931546 = 11201458953754 := by decide
theorem cert_e2405365931546 : check e2405365931546 [[]] .width = true := by decide
def e2405365938714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 3)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365938714 : Closed e2405365938714 ∧ code e2405365938714 = 11201458960922 := by decide
theorem cert_e2405365938714 : check e2405365938714 [[]] .width = true := by decide
def e2405365962266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365962266 : Closed e2405365962266 ∧ code e2405365962266 = 11201458984474 := by decide
private def t_e2405365962266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405365962266 : ¬ IsSelfInterpreter e2405365962266 :=
  wSource (t := t_e2405365962266) (replay_sound (ps := []) (t := e2405365962266) (by decide)) (by decide)
def e2405365963290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405365963290 : Closed e2405365963290 ∧ code e2405365963290 = 11201458985498 := by decide
private def t_e2405365963290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 3)) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2405365963290 : ¬ IsSelfInterpreter e2405365963290 :=
  wSource (t := t_e2405365963290) (replay_sound (ps := []) (t := e2405365963290) (by decide)) (by decide)
def e2405368193050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405368193050 : Closed e2405368193050 ∧ code e2405368193050 = 11201461215258 := by decide
theorem cert_e2405368193050 : check e2405368193050 [[]] .width = true := by decide
def e2405368193142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405368193142 : Closed e2405368193142 ∧ code e2405368193142 = 11201461215350 := by decide
theorem cert_e2405368193142 : check e2405368193142 [[]] .width = true := by decide
def e2405368193386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405368193386 : Closed e2405368193386 ∧ code e2405368193386 = 11201461215594 := by decide
theorem cert_e2405368193386 : check e2405368193386 [[]] .width = true := by decide
def e2405368193434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405368193434 : Closed e2405368193434 ∧ code e2405368193434 = 11201461215642 := by decide
theorem cert_e2405368193434 : check e2405368193434 [[]] .width = true := by decide
def e2405368262854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405368262854 : Closed e2405368262854 ∧ code e2405368262854 = 11201461285062 := by decide
theorem cert_e2405368262854 : check e2405368262854 [[]] .width = true := by decide
def e2405368291354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405368291354 : Closed e2405368291354 ∧ code e2405368291354 = 11201461313562 := by decide
theorem cert_e2405368291354 : check e2405368291354 [[]] .width = true := by decide
def e2405368291446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405368291446 : Closed e2405368291446 ∧ code e2405368291446 = 11201461313654 := by decide
theorem cert_e2405368291446 : check e2405368291446 [[]] .width = true := by decide
def e2405368291690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405368291690 : Closed e2405368291690 ∧ code e2405368291690 = 11201461313898 := by decide
theorem cert_e2405368291690 : check e2405368291690 [[]] .width = true := by decide
def e2405368291738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405368291738 : Closed e2405368291738 ∧ code e2405368291738 = 11201461313946 := by decide
theorem cert_e2405368291738 : check e2405368291738 [[]] .width = true := by decide
def e2405369835718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405369835718 : Closed e2405369835718 ∧ code e2405369835718 = 11201462857926 := by decide
theorem cert_e2405369835718 : check e2405369835718 [[]] .width = true := by decide
def e2405369884870 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405369884870 : Closed e2405369884870 ∧ code e2405369884870 = 11201462907078 := by decide
theorem cert_e2405369884870 : check e2405369884870 [[]] .width = true := by decide
def e2405370097862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405370097862 : Closed e2405370097862 ∧ code e2405370097862 = 11201463120070 := by decide
theorem cert_e2405370097862 : check e2405370097862 [[]] .width = true := by decide
def e2405370155206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405370155206 : Closed e2405370155206 ∧ code e2405370155206 = 11201463177414 := by decide
theorem cert_e2405370155206 : check e2405370155206 [[]] .width = true := by decide
def e2405370158618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405370158618 : Closed e2405370158618 ∧ code e2405370158618 = 11201463180826 := by decide
theorem cert_e2405370158618 : check e2405370158618 [[]] .width = true := by decide
def e2405370343622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405370343622 : Closed e2405370343622 ∧ code e2405370343622 = 11201463365830 := by decide
theorem cert_e2405370343622 : check e2405370343622 [[]] .width = true := by decide
def e2405370351814 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405370351814 : Closed e2405370351814 ∧ code e2405370351814 = 11201463374022 := by decide
theorem cert_e2405370351814 : check e2405370351814 [[]] .width = true := by decide
def e2405370355226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405370355226 : Closed e2405370355226 ∧ code e2405370355226 = 11201463377434 := by decide
theorem cert_e2405370355226 : check e2405370355226 [[]] .width = true := by decide
def e2405370361370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 3))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405370361370 : Closed e2405370361370 ∧ code e2405370361370 = 11201463383578 := by decide
theorem cert_e2405370361370 : check e2405370361370 [[]] .width = true := by decide
def e2405371408582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405371408582 : Closed e2405371408582 ∧ code e2405371408582 = 11201464430790 := by decide
theorem cert_e2405371408582 : check e2405371408582 [[]] .width = true := by decide
def e2405371457734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405371457734 : Closed e2405371457734 ∧ code e2405371457734 = 11201464479942 := by decide
theorem cert_e2405371457734 : check e2405371457734 [[]] .width = true := by decide
def e2405372780570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405372780570 : Closed e2405372780570 ∧ code e2405372780570 = 11201465802778 := by decide
theorem cert_e2405372780570 : check e2405372780570 [[]] .width = true := by decide
def e2405372780662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405372780662 : Closed e2405372780662 ∧ code e2405372780662 = 11201465802870 := by decide
theorem cert_e2405372780662 : check e2405372780662 [[]] .width = true := by decide
def e2405372780906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405372780906 : Closed e2405372780906 ∧ code e2405372780906 = 11201465803114 := by decide
theorem cert_e2405372780906 : check e2405372780906 [[]] .width = true := by decide
def e2405372780954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 4)))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405372780954 : Closed e2405372780954 ∧ code e2405372780954 = 11201465803162 := by decide
theorem cert_e2405372780954 : check e2405372780954 [[]] .width = true := by decide
def e2405372981446 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405372981446 : Closed e2405372981446 ∧ code e2405372981446 = 11201466003654 := by decide
theorem cert_e2405372981446 : check e2405372981446 [[]] .width = true := by decide
def e2405373038790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405373038790 : Closed e2405373038790 ∧ code e2405373038790 = 11201466060998 := by decide
theorem cert_e2405373038790 : check e2405373038790 [[]] .width = true := by decide
def e2405373042202 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405373042202 : Closed e2405373042202 ∧ code e2405373042202 = 11201466064410 := by decide
theorem cert_e2405373042202 : check e2405373042202 [[]] .width = true := by decide
def e2405373509830 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405373509830 : Closed e2405373509830 ∧ code e2405373509830 = 11201466532038 := by decide
theorem cert_e2405373509830 : check e2405373509830 [[]] .width = true := by decide
def e2405373510358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405373510358 : Closed e2405373510358 ∧ code e2405373510358 = 11201466532566 := by decide
theorem cert_e2405373510358 : check e2405373510358 [[]] .width = true := by decide
def e2405373510362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405373510362 : Closed e2405373510362 ∧ code e2405373510362 = 11201466532570 := by decide
theorem cert_e2405373510362 : check e2405373510362 [[]] .width = true := by decide
def e2405373510378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405373510378 : Closed e2405373510378 ∧ code e2405373510378 = 11201466532586 := by decide
theorem cert_e2405373510378 : check e2405373510378 [[]] .width = true := by decide
def e2405373510454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405373510454 : Closed e2405373510454 ∧ code e2405373510454 = 11201466532662 := by decide
theorem cert_e2405373510454 : check e2405373510454 [[]] .width = true := by decide
def e2405373510458 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405373510458 : Closed e2405373510458 ∧ code e2405373510458 = 11201466532666 := by decide
theorem cert_e2405373510458 : check e2405373510458 [[]] .width = true := by decide
def e2405373510542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405373510542 : Closed e2405373510542 ∧ code e2405373510542 = 11201466532750 := by decide
theorem cert_e2405373510542 : check e2405373510542 [[]] .width = true := by decide
def e2405373510554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405373510554 : Closed e2405373510554 ∧ code e2405373510554 = 11201466532762 := by decide
theorem cert_e2405373510554 : check e2405373510554 [[]] .width = true := by decide
def e2405373512474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405373512474 : Closed e2405373512474 ∧ code e2405373512474 = 11201466534682 := by decide
theorem cert_e2405373512474 : check e2405373512474 [[]] .width = true := by decide
def e2405373512518 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405373512518 : Closed e2405373512518 ∧ code e2405373512518 = 11201466534726 := by decide
theorem cert_e2405373512518 : check e2405373512518 [[]] .width = true := by decide
def e2405373512758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405373512758 : Closed e2405373512758 ∧ code e2405373512758 = 11201466534966 := by decide
theorem cert_e2405373512758 : check e2405373512758 [[]] .width = true := by decide
def e2405373512762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405373512762 : Closed e2405373512762 ∧ code e2405373512762 = 11201466534970 := by decide
theorem cert_e2405373512762 : check e2405373512762 [[]] .width = true := by decide
def e2405373512902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405373512902 : Closed e2405373512902 ∧ code e2405373512902 = 11201466535110 := by decide
theorem cert_e2405373512902 : check e2405373512902 [[]] .width = true := by decide
def e2405374066714 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405374066714 : Closed e2405374066714 ∧ code e2405374066714 = 11201467088922 := by decide
theorem cert_e2405374066714 : check e2405374066714 [[]] .width = true := by decide
def e2405374066806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405374066806 : Closed e2405374066806 ∧ code e2405374066806 = 11201467089014 := by decide
theorem cert_e2405374066806 : check e2405374066806 [[]] .width = true := by decide
def e2405374067050 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405374067050 : Closed e2405374067050 ∧ code e2405374067050 = 11201467089258 := by decide
theorem cert_e2405374067050 : check e2405374067050 [[]] .width = true := by decide
def e2405374067098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405374067098 : Closed e2405374067098 ∧ code e2405374067098 = 11201467089306 := by decide
theorem cert_e2405374067098 : check e2405374067098 [[]] .width = true := by decide
def e2405374068106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405374068106 : Closed e2405374068106 ∧ code e2405374068106 = 11201467090314 := by decide
theorem cert_e2405374068106 : check e2405374068106 [[]] .width = true := by decide
def e2405374068130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405374068130 : Closed e2405374068130 ∧ code e2405374068130 = 11201467090338 := by decide
theorem cert_e2405374068130 : check e2405374068130 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393421646778
#print axioms Blc.Floor43.cert_e2393421646810
#print axioms Blc.Floor43.cert_e2405365962266
#print axioms Blc.Floor43.cert_e2405365963290
