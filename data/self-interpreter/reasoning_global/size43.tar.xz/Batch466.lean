import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406768270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406768270 : Closed e2422406768270 ∧ code e2422406768270 = 11218499790478 := by decide
theorem cert_e2422406768270 : check e2422406768270 [[],[]] .chain = true := by decide
def e2422406768326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406768326 : Closed e2422406768326 ∧ code e2422406768326 = 11218499790534 := by decide
theorem cert_e2422406768326 : check e2422406768326 [[],[]] .chain = true := by decide
def e2422406768406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406768406 : Closed e2422406768406 ∧ code e2422406768406 = 11218499790614 := by decide
theorem cert_e2422406768406 : check e2422406768406 [[],[]] .chain = true := by decide
def e2422406768410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2422406768410 : Closed e2422406768410 ∧ code e2422406768410 = 11218499790618 := by decide
theorem cert_e2422406768410 : check e2422406768410 [[],[]] .chain = true := by decide
def e2422406768454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2422406768454 : Closed e2422406768454 ∧ code e2422406768454 = 11218499790662 := by decide
theorem cert_e2422406768454 : check e2422406768454 [[],[]] .chain = true := by decide
def e2422406768482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406768482 : Closed e2422406768482 ∧ code e2422406768482 = 11218499790690 := by decide
theorem cert_e2422406768482 : check e2422406768482 [[],[]] .chain = true := by decide
def e2422406768494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422406768494 : Closed e2422406768494 ∧ code e2422406768494 = 11218499790702 := by decide
theorem cert_e2422406768494 : check e2422406768494 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406768502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422406768502 : Closed e2422406768502 ∧ code e2422406768502 = 11218499790710 := by decide
theorem cert_e2422406768502 : check e2422406768502 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406768566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422406768566 : Closed e2422406768566 ∧ code e2422406768566 = 11218499790774 := by decide
theorem cert_e2422406768566 : check e2422406768566 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406768750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2422406768750 : Closed e2422406768750 ∧ code e2422406768750 = 11218499790958 := by decide
theorem cert_e2422406768750 : check e2422406768750 [[],[]] .chain = true := by decide
def e2422406768762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2422406768762 : Closed e2422406768762 ∧ code e2422406768762 = 11218499790970 := by decide
theorem cert_e2422406768762 : check e2422406768762 [[],[]] .chain = true := by decide
def e2422406769038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422406769038 : Closed e2422406769038 ∧ code e2422406769038 = 11218499791246 := by decide
theorem cert_e2422406769038 : check e2422406769038 [[],[]] .chain = true := by decide
def e2422406769094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422406769094 : Closed e2422406769094 ∧ code e2422406769094 = 11218499791302 := by decide
theorem cert_e2422406769094 : check e2422406769094 [[],[]] .chain = true := by decide
def e2422406769694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406769694 : Closed e2422406769694 ∧ code e2422406769694 = 11218499791902 := by decide
theorem cert_e2422406769694 : check e2422406769694 [[],[]] .chain = true := by decide
def e2422406769718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2422406769718 : Closed e2422406769718 ∧ code e2422406769718 = 11218499791926 := by decide
theorem cert_e2422406769718 : check e2422406769718 [[],[]] .chain = true := by decide
def e2422406769722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2422406769722 : Closed e2422406769722 ∧ code e2422406769722 = 11218499791930 := by decide
theorem cert_e2422406769722 : check e2422406769722 [[],[]] .chain = true := by decide
def e2422406769862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2422406769862 : Closed e2422406769862 ∧ code e2422406769862 = 11218499792070 := by decide
theorem cert_e2422406769862 : check e2422406769862 [[],[]] .chain = true := by decide
def e2422406769890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406769890 : Closed e2422406769890 ∧ code e2422406769890 = 11218499792098 := by decide
theorem cert_e2422406769890 : check e2422406769890 [[],[]] .chain = true := by decide
def e2422406769902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406769902 : Closed e2422406769902 ∧ code e2422406769902 = 11218499792110 := by decide
theorem cert_e2422406769902 : check e2422406769902 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406769910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406769910 : Closed e2422406769910 ∧ code e2422406769910 = 11218499792118 := by decide
theorem cert_e2422406769910 : check e2422406769910 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406770294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406770294 : Closed e2422406770294 ∧ code e2422406770294 = 11218499792502 := by decide
theorem cert_e2422406770294 : check e2422406770294 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406825326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406825326 : Closed e2422406825326 ∧ code e2422406825326 = 11218499847534 := by decide
theorem cert_e2422406825326 : check e2422406825326 [[],[]] .chain = true := by decide
def e2422406825334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406825334 : Closed e2422406825334 ∧ code e2422406825334 = 11218499847542 := by decide
theorem cert_e2422406825334 : check e2422406825334 [[],[]] .chain = true := by decide
def e2422406825390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406825390 : Closed e2422406825390 ∧ code e2422406825390 = 11218499847598 := by decide
theorem cert_e2422406825390 : check e2422406825390 [[],[]] .chain = true := by decide
def e2422406825402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406825402 : Closed e2422406825402 ∧ code e2422406825402 = 11218499847610 := by decide
theorem cert_e2422406825402 : check e2422406825402 [[],[]] .chain = true := by decide
def e2422406825430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406825430 : Closed e2422406825430 ∧ code e2422406825430 = 11218499847638 := by decide
theorem cert_e2422406825430 : check e2422406825430 [[],[]] .chain = true := by decide
def e2422406825434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406825434 : Closed e2422406825434 ∧ code e2422406825434 = 11218499847642 := by decide
theorem cert_e2422406825434 : check e2422406825434 [[],[]] .chain = true := by decide
def e2422406828398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406828398 : Closed e2422406828398 ∧ code e2422406828398 = 11218499850606 := by decide
theorem cert_e2422406828398 : check e2422406828398 [[],[]] .chain = true := by decide
def e2422406828406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406828406 : Closed e2422406828406 ∧ code e2422406828406 = 11218499850614 := by decide
theorem cert_e2422406828406 : check e2422406828406 [[],[]] .chain = true := by decide
def e2422406829614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406829614 : Closed e2422406829614 ∧ code e2422406829614 = 11218499851822 := by decide
theorem cert_e2422406829614 : check e2422406829614 [[],[]] .chain = true := by decide
def e2422406829794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406829794 : Closed e2422406829794 ∧ code e2422406829794 = 11218499852002 := by decide
theorem cert_e2422406829794 : check e2422406829794 [[],[]] .chain = true := by decide
def e2422406829806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e2422406829806 : Closed e2422406829806 ∧ code e2422406829806 = 11218499852014 := by decide
theorem cert_e2422406829806 : check e2422406829806 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406829846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406829846 : Closed e2422406829846 ∧ code e2422406829846 = 11218499852054 := by decide
theorem cert_e2422406829846 : check e2422406829846 [[],[]] .chain = true := by decide
def e2422406829922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406829922 : Closed e2422406829922 ∧ code e2422406829922 = 11218499852130 := by decide
theorem cert_e2422406829922 : check e2422406829922 [[],[]] .chain = true := by decide
def e2422406829934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2422406829934 : Closed e2422406829934 ∧ code e2422406829934 = 11218499852142 := by decide
theorem cert_e2422406829934 : check e2422406829934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406829942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2422406829942 : Closed e2422406829942 ∧ code e2422406829942 = 11218499852150 := by decide
theorem cert_e2422406829942 : checkPay e2422406829942 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406830254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406830254 : Closed e2422406830254 ∧ code e2422406830254 = 11218499852462 := by decide
theorem cert_e2422406830254 : check e2422406830254 [[],[]] .chain = true := by decide
def e2422406830266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406830266 : Closed e2422406830266 ∧ code e2422406830266 = 11218499852474 := by decide
theorem cert_e2422406830266 : check e2422406830266 [[],[]] .chain = true := by decide
def e2422406830638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406830638 : Closed e2422406830638 ∧ code e2422406830638 = 11218499852846 := by decide
theorem cert_e2422406830638 : check e2422406830638 [[],[]] .chain = true := by decide
def e2422406830818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406830818 : Closed e2422406830818 ∧ code e2422406830818 = 11218499853026 := by decide
theorem cert_e2422406830818 : check e2422406830818 [[],[]] .chain = true := by decide
def e2422406830830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2422406830830 : Closed e2422406830830 ∧ code e2422406830830 = 11218499853038 := by decide
theorem cert_e2422406830830 : check e2422406830830 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406830958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406830958 : Closed e2422406830958 ∧ code e2422406830958 = 11218499853166 := by decide
theorem cert_e2422406830958 : check e2422406830958 [[],[]] .chain = true := by decide
def e2422406830966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406830966 : Closed e2422406830966 ∧ code e2422406830966 = 11218499853174 := by decide
theorem cert_e2422406830966 : check e2422406830966 [[],[]] .chain = true := by decide
def e2422406830986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406830986 : Closed e2422406830986 ∧ code e2422406830986 = 11218499853194 := by decide
theorem cert_e2422406830986 : check e2422406830986 [[],[]] .chain = true := by decide
def e2422406831010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406831010 : Closed e2422406831010 ∧ code e2422406831010 = 11218499853218 := by decide
theorem cert_e2422406831010 : check e2422406831010 [[],[]] .chain = true := by decide
def e2422406831022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406831022 : Closed e2422406831022 ∧ code e2422406831022 = 11218499853230 := by decide
theorem cert_e2422406831022 : check e2422406831022 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406831030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2422406831030 : Closed e2422406831030 ∧ code e2422406831030 = 11218499853238 := by decide
theorem cert_e2422406831030 : check e2422406831030 [[],[]] .chain = true := by decide
def e2422406831034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406831034 : Closed e2422406831034 ∧ code e2422406831034 = 11218499853242 := by decide
theorem cert_e2422406831034 : check e2422406831034 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406831190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406831190 : Closed e2422406831190 ∧ code e2422406831190 = 11218499853398 := by decide
theorem cert_e2422406831190 : check e2422406831190 [[],[]] .chain = true := by decide
def e2422406831194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406831194 : Closed e2422406831194 ∧ code e2422406831194 = 11218499853402 := by decide
theorem cert_e2422406831194 : check e2422406831194 [[],[]] .chain = true := by decide
def e2422406831382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406831382 : Closed e2422406831382 ∧ code e2422406831382 = 11218499853590 := by decide
theorem cert_e2422406831382 : check e2422406831382 [[],[]] .chain = true := by decide
def e2422406831458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406831458 : Closed e2422406831458 ∧ code e2422406831458 = 11218499853666 := by decide
theorem cert_e2422406831458 : check e2422406831458 [[],[]] .chain = true := by decide
def e2422406831470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406831470 : Closed e2422406831470 ∧ code e2422406831470 = 11218499853678 := by decide
theorem cert_e2422406831470 : check e2422406831470 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406831478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406831478 : Closed e2422406831478 ∧ code e2422406831478 = 11218499853686 := by decide
theorem cert_e2422406831478 : check e2422406831478 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406831498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406831498 : Closed e2422406831498 ∧ code e2422406831498 = 11218499853706 := by decide
theorem cert_e2422406831498 : check e2422406831498 [[],[]] .chain = true := by decide
def e2422406831522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406831522 : Closed e2422406831522 ∧ code e2422406831522 = 11218499853730 := by decide
theorem cert_e2422406831522 : check e2422406831522 [[],[]] .chain = true := by decide
def e2422406831534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406831534 : Closed e2422406831534 ∧ code e2422406831534 = 11218499853742 := by decide
theorem cert_e2422406831534 : check e2422406831534 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406831542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422406831542 : Closed e2422406831542 ∧ code e2422406831542 = 11218499853750 := by decide
theorem cert_e2422406831542 : check e2422406831542 [[],[]] .chain = true := by decide
def e2422406831546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406831546 : Closed e2422406831546 ∧ code e2422406831546 = 11218499853754 := by decide
theorem cert_e2422406831546 : check e2422406831546 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406831574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406831574 : Closed e2422406831574 ∧ code e2422406831574 = 11218499853782 := by decide
theorem cert_e2422406831574 : check e2422406831574 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406831578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406831578 : Closed e2422406831578 ∧ code e2422406831578 = 11218499853786 := by decide
def e2422406832814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406832814 : Closed e2422406832814 ∧ code e2422406832814 = 11218499855022 := by decide
theorem cert_e2422406832814 : check e2422406832814 [[],[]] .chain = true := by decide
def e2422406832826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406832826 : Closed e2422406832826 ∧ code e2422406832826 = 11218499855034 := by decide
theorem cert_e2422406832826 : check e2422406832826 [[],[]] .chain = true := by decide
def e2422406832874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406832874 : Closed e2422406832874 ∧ code e2422406832874 = 11218499855082 := by decide
theorem cert_e2422406832874 : check e2422406832874 [[],[]] .chain = true := by decide
def e2422406834350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406834350 : Closed e2422406834350 ∧ code e2422406834350 = 11218499856558 := by decide
theorem cert_e2422406834350 : check e2422406834350 [[],[]] .chain = true := by decide
def e2422406834362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406834362 : Closed e2422406834362 ∧ code e2422406834362 = 11218499856570 := by decide
theorem cert_e2422406834362 : check e2422406834362 [[],[]] .chain = true := by decide
def e2422406834734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406834734 : Closed e2422406834734 ∧ code e2422406834734 = 11218499856942 := by decide
theorem cert_e2422406834734 : check e2422406834734 [[],[]] .chain = true := by decide
def e2422406834914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406834914 : Closed e2422406834914 ∧ code e2422406834914 = 11218499857122 := by decide
theorem cert_e2422406834914 : check e2422406834914 [[],[]] .chain = true := by decide
def e2422406834926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2422406834926 : Closed e2422406834926 ∧ code e2422406834926 = 11218499857134 := by decide
theorem cert_e2422406834926 : check e2422406834926 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406835054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406835054 : Closed e2422406835054 ∧ code e2422406835054 = 11218499857262 := by decide
theorem cert_e2422406835054 : check e2422406835054 [[],[]] .chain = true := by decide
def e2422406835062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406835062 : Closed e2422406835062 ∧ code e2422406835062 = 11218499857270 := by decide
theorem cert_e2422406835062 : check e2422406835062 [[],[]] .chain = true := by decide
def e2422406835082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406835082 : Closed e2422406835082 ∧ code e2422406835082 = 11218499857290 := by decide
theorem cert_e2422406835082 : check e2422406835082 [[],[]] .chain = true := by decide
def e2422406835106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406835106 : Closed e2422406835106 ∧ code e2422406835106 = 11218499857314 := by decide
theorem cert_e2422406835106 : check e2422406835106 [[],[]] .chain = true := by decide
def e2422406835118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406835118 : Closed e2422406835118 ∧ code e2422406835118 = 11218499857326 := by decide
theorem cert_e2422406835118 : check e2422406835118 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406835126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2422406835126 : Closed e2422406835126 ∧ code e2422406835126 = 11218499857334 := by decide
theorem cert_e2422406835126 : check e2422406835126 [[],[]] .chain = true := by decide
def e2422406835130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406835130 : Closed e2422406835130 ∧ code e2422406835130 = 11218499857338 := by decide
theorem cert_e2422406835130 : check e2422406835130 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406835566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406835566 : Closed e2422406835566 ∧ code e2422406835566 = 11218499857774 := by decide
theorem cert_e2422406835566 : check e2422406835566 [[],[]] .chain = true := by decide
def e2422406835574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406835574 : Closed e2422406835574 ∧ code e2422406835574 = 11218499857782 := by decide
theorem cert_e2422406835574 : check e2422406835574 [[],[]] .chain = true := by decide
def e2422406835630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406835630 : Closed e2422406835630 ∧ code e2422406835630 = 11218499857838 := by decide
theorem cert_e2422406835630 : check e2422406835630 [[],[]] .chain = true := by decide
def e2422406835642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406835642 : Closed e2422406835642 ∧ code e2422406835642 = 11218499857850 := by decide
theorem cert_e2422406835642 : check e2422406835642 [[],[]] .chain = true := by decide
def e2422406835670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406835670 : Closed e2422406835670 ∧ code e2422406835670 = 11218499857878 := by decide
theorem cert_e2422406835670 : check e2422406835670 [[],[]] .chain = true := by decide
def e2422406835674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406835674 : Closed e2422406835674 ∧ code e2422406835674 = 11218499857882 := by decide
theorem cert_e2422406835674 : check e2422406835674 [[],[]] .chain = true := by decide
def e2422406835754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406835754 : Closed e2422406835754 ∧ code e2422406835754 = 11218499857962 := by decide
theorem cert_e2422406835754 : check e2422406835754 [[],[]] .chain = true := by decide
def e2422406835850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406835850 : Closed e2422406835850 ∧ code e2422406835850 = 11218499858058 := by decide
theorem cert_e2422406835850 : check e2422406835850 [[],[]] .chain = true := by decide
def e2422406835874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406835874 : Closed e2422406835874 ∧ code e2422406835874 = 11218499858082 := by decide
theorem cert_e2422406835874 : check e2422406835874 [[],[]] .chain = true := by decide
def e2422406835886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406835886 : Closed e2422406835886 ∧ code e2422406835886 = 11218499858094 := by decide
theorem cert_e2422406835886 : check e2422406835886 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406835894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406835894 : Closed e2422406835894 ∧ code e2422406835894 = 11218499858102 := by decide
theorem cert_e2422406835894 : check e2422406835894 [[],[]] .chain = true := by decide
def e2422406835898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406835898 : Closed e2422406835898 ∧ code e2422406835898 = 11218499858106 := by decide
theorem cert_e2422406835898 : check e2422406835898 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406835926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406835926 : Closed e2422406835926 ∧ code e2422406835926 = 11218499858134 := by decide
theorem cert_e2422406835926 : check e2422406835926 [[],[]] .chain = true := by decide
def e2422406835930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406835930 : Closed e2422406835930 ∧ code e2422406835930 = 11218499858138 := by decide
theorem cert_e2422406835930 : check e2422406835930 [[],[]] .chain = true := by decide
def e2422406835946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406835946 : Closed e2422406835946 ∧ code e2422406835946 = 11218499858154 := by decide
theorem cert_e2422406835946 : check e2422406835946 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2422406836566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406836566 : Closed e2422406836566 ∧ code e2422406836566 = 11218499858774 := by decide
theorem cert_e2422406836566 : check e2422406836566 [[],[]] .chain = true := by decide
def e2422406836570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406836570 : Closed e2422406836570 ∧ code e2422406836570 = 11218499858778 := by decide
theorem cert_e2422406836570 : check e2422406836570 [[],[]] .chain = true := by decide
def e2422406836586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406836586 : Closed e2422406836586 ∧ code e2422406836586 = 11218499858794 := by decide
theorem cert_e2422406836586 : check e2422406836586 [[],[]] .chain = true := by decide
def e2422406837334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406837334 : Closed e2422406837334 ∧ code e2422406837334 = 11218499859542 := by decide
theorem cert_e2422406837334 : check e2422406837334 [[],[]] .chain = true := by decide
def e2422406837338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406837338 : Closed e2422406837338 ∧ code e2422406837338 = 11218499859546 := by decide
theorem cert_e2422406837338 : check e2422406837338 [[],[]] .chain = true := by decide
def e2422406837526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406837526 : Closed e2422406837526 ∧ code e2422406837526 = 11218499859734 := by decide
theorem cert_e2422406837526 : check e2422406837526 [[],[]] .chain = true := by decide
def e2422406837602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406837602 : Closed e2422406837602 ∧ code e2422406837602 = 11218499859810 := by decide
theorem cert_e2422406837602 : check e2422406837602 [[],[]] .chain = true := by decide
def e2422406837614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406837614 : Closed e2422406837614 ∧ code e2422406837614 = 11218499859822 := by decide
theorem cert_e2422406837614 : check e2422406837614 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2422406837622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406837622 : Closed e2422406837622 ∧ code e2422406837622 = 11218499859830 := by decide
theorem cert_e2422406837622 : checkPay e2422406837622 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406837642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406837642 : Closed e2422406837642 ∧ code e2422406837642 = 11218499859850 := by decide
theorem cert_e2422406837642 : check e2422406837642 [[],[]] .chain = true := by decide
def e2422406837666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406837666 : Closed e2422406837666 ∧ code e2422406837666 = 11218499859874 := by decide
theorem cert_e2422406837666 : check e2422406837666 [[],[]] .chain = true := by decide
def e2422406837678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406837678 : Closed e2422406837678 ∧ code e2422406837678 = 11218499859886 := by decide
theorem cert_e2422406837678 : check e2422406837678 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406837686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422406837686 : Closed e2422406837686 ∧ code e2422406837686 = 11218499859894 := by decide
theorem cert_e2422406837686 : check e2422406837686 [[],[]] .chain = true := by decide
def e2422406837690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406837690 : Closed e2422406837690 ∧ code e2422406837690 = 11218499859898 := by decide
theorem cert_e2422406837690 : check e2422406837690 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406837718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406837718 : Closed e2422406837718 ∧ code e2422406837718 = 11218499859926 := by decide
theorem cert_e2422406837718 : checkPay e2422406837718 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2422406837722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406837722 : Closed e2422406837722 ∧ code e2422406837722 = 11218499859930 := by decide
theorem cert_e2422406837722 : check e2422406837722 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406837802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406837802 : Closed e2422406837802 ∧ code e2422406837802 = 11218499860010 := by decide
theorem cert_e2422406837802 : check e2422406837802 [[],[]] .chain = true := by decide
def e2422406837898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406837898 : Closed e2422406837898 ∧ code e2422406837898 = 11218499860106 := by decide
theorem cert_e2422406837898 : check e2422406837898 [[],[]] .chain = true := by decide
def e2422406837922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406837922 : Closed e2422406837922 ∧ code e2422406837922 = 11218499860130 := by decide
theorem cert_e2422406837922 : check e2422406837922 [[],[]] .chain = true := by decide
def e2422406837934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406837934 : Closed e2422406837934 ∧ code e2422406837934 = 11218499860142 := by decide
theorem cert_e2422406837934 : check e2422406837934 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406837942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406837942 : Closed e2422406837942 ∧ code e2422406837942 = 11218499860150 := by decide
theorem cert_e2422406837942 : check e2422406837942 [[],[]] .chain = true := by decide
def e2422406837946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406837946 : Closed e2422406837946 ∧ code e2422406837946 = 11218499860154 := by decide
theorem cert_e2422406837946 : check e2422406837946 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406837974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406837974 : Closed e2422406837974 ∧ code e2422406837974 = 11218499860182 := by decide
theorem cert_e2422406837974 : check e2422406837974 [[],[]] .chain = true := by decide
def e2422406837978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406837978 : Closed e2422406837978 ∧ code e2422406837978 = 11218499860186 := by decide
theorem cert_e2422406837978 : check e2422406837978 [[],[]] .chain = true := by decide
def e2422406837994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406837994 : Closed e2422406837994 ∧ code e2422406837994 = 11218499860202 := by decide
theorem cert_e2422406837994 : check e2422406837994 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406838102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406838102 : Closed e2422406838102 ∧ code e2422406838102 = 11218499860310 := by decide
def e2422406838106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406838106 : Closed e2422406838106 ∧ code e2422406838106 = 11218499860314 := by decide
def e2422406838122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))) (.var 0)) (.var 0))))))
theorem wire_e2422406838122 : Closed e2422406838122 ∧ code e2422406838122 = 11218499860330 := by decide
def e2422406840686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 1)) (.var 2))))))
theorem wire_e2422406840686 : Closed e2422406840686 ∧ code e2422406840686 = 11218499862894 := by decide
theorem cert_e2422406840686 : check e2422406840686 [[],[]] .chain = true := by decide
def e2422406840694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0)))))) (.var 2)) (.var 1))))))
theorem wire_e2422406840694 : Closed e2422406840694 ∧ code e2422406840694 = 11218499862902 := by decide
theorem cert_e2422406840694 : check e2422406840694 [[],[]] .chain = true := by decide
def e2422406842222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1)) (.var 2))))))
theorem wire_e2422406842222 : Closed e2422406842222 ∧ code e2422406842222 = 11218499864430 := by decide
theorem cert_e2422406842222 : check e2422406842222 [[],[]] .chain = true := by decide
def e2422406842230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 2)) (.var 1))))))
theorem wire_e2422406842230 : Closed e2422406842230 ∧ code e2422406842230 = 11218499864438 := by decide
theorem cert_e2422406842230 : check e2422406842230 [[],[]] .chain = true := by decide
def e2422406842286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0)) (.var 2))))))
theorem wire_e2422406842286 : Closed e2422406842286 ∧ code e2422406842286 = 11218499864494 := by decide
theorem cert_e2422406842286 : check e2422406842286 [[],[]] .chain = true := by decide
def e2422406842298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 2)) (.var 0))))))
theorem wire_e2422406842298 : Closed e2422406842298 ∧ code e2422406842298 = 11218499864506 := by decide
theorem cert_e2422406842298 : check e2422406842298 [[],[]] .chain = true := by decide
def e2422406842326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 0)) (.var 1))))))
theorem wire_e2422406842326 : Closed e2422406842326 ∧ code e2422406842326 = 11218499864534 := by decide
theorem cert_e2422406842326 : check e2422406842326 [[],[]] .chain = true := by decide
def e2422406842330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 4))))) (.var 1)) (.var 0))))))
theorem wire_e2422406842330 : Closed e2422406842330 ∧ code e2422406842330 = 11218499864538 := by decide
theorem cert_e2422406842330 : check e2422406842330 [[],[]] .chain = true := by decide
def e2422406843758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422406843758 : Closed e2422406843758 ∧ code e2422406843758 = 11218499865966 := by decide
theorem cert_e2422406843758 : check e2422406843758 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406843766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422406843766 : Closed e2422406843766 ∧ code e2422406843766 = 11218499865974 := by decide
theorem cert_e2422406843766 : check e2422406843766 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406845294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406845294 : Closed e2422406845294 ∧ code e2422406845294 = 11218499867502 := by decide
theorem cert_e2422406845294 : check e2422406845294 [[],[]] .chain = true := by decide
def e2422406845302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406845302 : Closed e2422406845302 ∧ code e2422406845302 = 11218499867510 := by decide
theorem cert_e2422406845302 : check e2422406845302 [[],[]] .chain = true := by decide
def e2422406845358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406845358 : Closed e2422406845358 ∧ code e2422406845358 = 11218499867566 := by decide
theorem cert_e2422406845358 : check e2422406845358 [[],[]] .chain = true := by decide
def e2422406845370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406845370 : Closed e2422406845370 ∧ code e2422406845370 = 11218499867578 := by decide
theorem cert_e2422406845370 : check e2422406845370 [[],[]] .chain = true := by decide
def e2422406845398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406845398 : Closed e2422406845398 ∧ code e2422406845398 = 11218499867606 := by decide
theorem cert_e2422406845398 : check e2422406845398 [[],[]] .chain = true := by decide
def e2422406845402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406845402 : Closed e2422406845402 ∧ code e2422406845402 = 11218499867610 := by decide
theorem cert_e2422406845402 : check e2422406845402 [[],[]] .chain = true := by decide
def e2422406845678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406845678 : Closed e2422406845678 ∧ code e2422406845678 = 11218499867886 := by decide
theorem cert_e2422406845678 : check e2422406845678 [[],[]] .chain = true := by decide
def e2422406845686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406845686 : Closed e2422406845686 ∧ code e2422406845686 = 11218499867894 := by decide
theorem cert_e2422406845686 : check e2422406845686 [[],[]] .chain = true := by decide
def e2422406846062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406846062 : Closed e2422406846062 ∧ code e2422406846062 = 11218499868270 := by decide
theorem cert_e2422406846062 : check e2422406846062 [[],[]] .chain = true := by decide
def e2422406846074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406846074 : Closed e2422406846074 ∧ code e2422406846074 = 11218499868282 := by decide
theorem cert_e2422406846074 : check e2422406846074 [[],[]] .chain = true := by decide
def e2422406846262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406846262 : Closed e2422406846262 ∧ code e2422406846262 = 11218499868470 := by decide
theorem cert_e2422406846262 : check e2422406846262 [[],[]] .chain = true := by decide
def e2422406846266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406846266 : Closed e2422406846266 ∧ code e2422406846266 = 11218499868474 := by decide
theorem cert_e2422406846266 : check e2422406846266 [[],[]] .chain = true := by decide
def e2422406846702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406846702 : Closed e2422406846702 ∧ code e2422406846702 = 11218499868910 := by decide
theorem cert_e2422406846702 : check e2422406846702 [[],[]] .chain = true := by decide
def e2422406846710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406846710 : Closed e2422406846710 ∧ code e2422406846710 = 11218499868918 := by decide
theorem cert_e2422406846710 : check e2422406846710 [[],[]] .chain = true := by decide
def e2422406847262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406847262 : Closed e2422406847262 ∧ code e2422406847262 = 11218499869470 := by decide
theorem cert_e2422406847262 : check e2422406847262 [[],[]] .chain = true := by decide
def e2422406847374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406847374 : Closed e2422406847374 ∧ code e2422406847374 = 11218499869582 := by decide
theorem cert_e2422406847374 : check e2422406847374 [[],[]] .chain = true := by decide
def e2422406847598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406847598 : Closed e2422406847598 ∧ code e2422406847598 = 11218499869806 := by decide
theorem cert_e2422406847598 : check e2422406847598 [[],[]] .chain = true := by decide
def e2422406847610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406847610 : Closed e2422406847610 ∧ code e2422406847610 = 11218499869818 := by decide
theorem cert_e2422406847610 : check e2422406847610 [[],[]] .chain = true := by decide
def e2422406847774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406847774 : Closed e2422406847774 ∧ code e2422406847774 = 11218499869982 := by decide
theorem cert_e2422406847774 : check e2422406847774 [[],[]] .chain = true := by decide
def e2422406847942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406847942 : Closed e2422406847942 ∧ code e2422406847942 = 11218499870150 := by decide
theorem cert_e2422406847942 : check e2422406847942 [[],[]] .chain = true := by decide
def e2422406848054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406848054 : Closed e2422406848054 ∧ code e2422406848054 = 11218499870262 := by decide
theorem cert_e2422406848054 : check e2422406848054 [[],[]] .chain = true := by decide
def e2422406848058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406848058 : Closed e2422406848058 ∧ code e2422406848058 = 11218499870266 := by decide
theorem cert_e2422406848058 : check e2422406848058 [[],[]] .chain = true := by decide
def e2422406848142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406848142 : Closed e2422406848142 ∧ code e2422406848142 = 11218499870350 := by decide
theorem cert_e2422406848142 : check e2422406848142 [[],[]] .chain = true := by decide
def e2422406848198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406848198 : Closed e2422406848198 ∧ code e2422406848198 = 11218499870406 := by decide
theorem cert_e2422406848198 : check e2422406848198 [[],[]] .chain = true := by decide
def e2422406852974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422406852974 : Closed e2422406852974 ∧ code e2422406852974 = 11218499875182 := by decide
theorem cert_e2422406852974 : check e2422406852974 [[],[]] .chain = true := by decide
def e2422406852982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422406852982 : Closed e2422406852982 ∧ code e2422406852982 = 11218499875190 := by decide
theorem cert_e2422406852982 : check e2422406852982 [[],[]] .chain = true := by decide
def e2422406854190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406854190 : Closed e2422406854190 ∧ code e2422406854190 = 11218499876398 := by decide
theorem cert_e2422406854190 : check e2422406854190 [[],[]] .chain = true := by decide
def e2422406854370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406854370 : Closed e2422406854370 ∧ code e2422406854370 = 11218499876578 := by decide
theorem cert_e2422406854370 : check e2422406854370 [[],[]] .chain = true := by decide
def e2422406854382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.var 2))))))
theorem wire_e2422406854382 : Closed e2422406854382 ∧ code e2422406854382 = 11218499876590 := by decide
theorem cert_e2422406854382 : check e2422406854382 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406854422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406854422 : Closed e2422406854422 ∧ code e2422406854422 = 11218499876630 := by decide
theorem cert_e2422406854422 : check e2422406854422 [[],[]] .chain = true := by decide
def e2422406854498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406854498 : Closed e2422406854498 ∧ code e2422406854498 = 11218499876706 := by decide
theorem cert_e2422406854498 : check e2422406854498 [[],[]] .chain = true := by decide
end Blc.Floor43
