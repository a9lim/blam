import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2385066593238 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2385066593238 : Closed e2385066593238 ∧ code e2385066593238 = 11181159615446 := by decide
def e2385066593242 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2385066593242 : Closed e2385066593242 ∧ code e2385066593242 = 11181159615450 := by decide
private def t_e2385066593242 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem cert_e2385066593242 : ¬ IsSelfInterpreter e2385066593242 :=
  wSource (t := t_e2385066593242) (replay_sound (ps := []) (t := e2385066593242) (by decide)) (by decide)
def e2385066593518 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2385066593518 : Closed e2385066593518 ∧ code e2385066593518 = 11181159615726 := by decide
def e2385066593526 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2385066593526 : Closed e2385066593526 ∧ code e2385066593526 = 11181159615734 := by decide
def e2385066593902 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2385066593902 : Closed e2385066593902 ∧ code e2385066593902 = 11181159616110 := by decide
theorem cert_e2385066593902 : check e2385066593902 [[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2385066593914 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2385066593914 : Closed e2385066593914 ∧ code e2385066593914 = 11181159616122 := by decide
theorem cert_e2385066593914 : checkPay e2385066593914 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[.left],[.left],[.left,.left],[.left]] 0 [[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.under,.right,.left],[.under,.under,.right,.under,.right],[.under,.under,.right,.under,.right,.right]] = true := by decide
def e2385066594102 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2385066594102 : Closed e2385066594102 ∧ code e2385066594102 = 11181159616310 := by decide
def e2385066594106 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2385066594106 : Closed e2385066594106 ∧ code e2385066594106 = 11181159616314 := by decide
def e2385116179822 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2385116179822 : Closed e2385116179822 ∧ code e2385116179822 = 11181209202030 := by decide
theorem cert_e2385116179822 : check e2385116179822 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116179830 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2385116179830 : Closed e2385116179830 ∧ code e2385116179830 = 11181209202038 := by decide
theorem cert_e2385116179830 : check e2385116179830 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116179886 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2385116179886 : Closed e2385116179886 ∧ code e2385116179886 = 11181209202094 := by decide
theorem cert_e2385116179886 : check e2385116179886 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116179898 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2385116179898 : Closed e2385116179898 ∧ code e2385116179898 = 11181209202106 := by decide
theorem cert_e2385116179898 : check e2385116179898 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116179926 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2385116179926 : Closed e2385116179926 ∧ code e2385116179926 = 11181209202134 := by decide
theorem cert_e2385116179926 : check e2385116179926 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116179930 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2385116179930 : Closed e2385116179930 ∧ code e2385116179930 = 11181209202138 := by decide
theorem cert_e2385116179930 : check e2385116179930 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116180142 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2385116180142 : Closed e2385116180142 ∧ code e2385116180142 = 11181209202350 := by decide
theorem cert_e2385116180142 : check e2385116180142 [[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2385116180154 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2385116180154 : Closed e2385116180154 ∧ code e2385116180154 = 11181209202362 := by decide
theorem cert_e2385116180154 : check e2385116180154 [[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2385116180202 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2385116180202 : Closed e2385116180202 ∧ code e2385116180202 = 11181209202410 := by decide
theorem cert_e2385116180202 : check e2385116180202 [[],[.left,.left],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2385116180310 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2385116180310 : Closed e2385116180310 ∧ code e2385116180310 = 11181209202518 := by decide
theorem cert_e2385116180310 : check e2385116180310 [[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .smaller = true := by decide
def e2385116180314 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2385116180314 : Closed e2385116180314 ∧ code e2385116180314 = 11181209202522 := by decide
theorem cert_e2385116180314 : check e2385116180314 [[],[.left,.left],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2385116180330 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2385116180330 : Closed e2385116180330 ∧ code e2385116180330 = 11181209202538 := by decide
theorem cert_e2385116180330 : check e2385116180330 [[],[.left,.left],[.left],[],[.under,.left,.left]] .smaller = true := by decide
def e2385116181358 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2385116181358 : Closed e2385116181358 ∧ code e2385116181358 = 11181209203566 := by decide
theorem cert_e2385116181358 : check e2385116181358 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116181366 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2385116181366 : Closed e2385116181366 ∧ code e2385116181366 = 11181209203574 := by decide
theorem cert_e2385116181366 : check e2385116181366 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116181422 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2385116181422 : Closed e2385116181422 ∧ code e2385116181422 = 11181209203630 := by decide
theorem cert_e2385116181422 : check e2385116181422 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116181434 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2385116181434 : Closed e2385116181434 ∧ code e2385116181434 = 11181209203642 := by decide
theorem cert_e2385116181434 : check e2385116181434 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116181462 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2385116181462 : Closed e2385116181462 ∧ code e2385116181462 = 11181209203670 := by decide
theorem cert_e2385116181462 : check e2385116181462 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116181466 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2385116181466 : Closed e2385116181466 ∧ code e2385116181466 = 11181209203674 := by decide
theorem cert_e2385116181466 : check e2385116181466 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116181742 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2385116181742 : Closed e2385116181742 ∧ code e2385116181742 = 11181209203950 := by decide
theorem cert_e2385116181742 : check e2385116181742 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116181750 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2385116181750 : Closed e2385116181750 ∧ code e2385116181750 = 11181209203958 := by decide
theorem cert_e2385116181750 : check e2385116181750 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116182126 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2385116182126 : Closed e2385116182126 ∧ code e2385116182126 = 11181209204334 := by decide
theorem cert_e2385116182126 : check e2385116182126 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116182138 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2385116182138 : Closed e2385116182138 ∧ code e2385116182138 = 11181209204346 := by decide
theorem cert_e2385116182138 : check e2385116182138 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116182326 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2385116182326 : Closed e2385116182326 ∧ code e2385116182326 = 11181209204534 := by decide
theorem cert_e2385116182326 : check e2385116182326 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116182330 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2385116182330 : Closed e2385116182330 ∧ code e2385116182330 = 11181209204538 := by decide
theorem cert_e2385116182330 : check e2385116182330 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116182958 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2385116182958 : Closed e2385116182958 ∧ code e2385116182958 = 11181209205166 := by decide
theorem cert_e2385116182958 : check e2385116182958 [[],[.left,.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2385116182970 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2385116182970 : Closed e2385116182970 ∧ code e2385116182970 = 11181209205178 := by decide
theorem cert_e2385116182970 : check e2385116182970 [[],[.left,.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2385116183018 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2385116183018 : Closed e2385116183018 ∧ code e2385116183018 = 11181209205226 := by decide
theorem cert_e2385116183018 : check e2385116183018 [[],[.left,.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2385116183150 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2385116183150 : Closed e2385116183150 ∧ code e2385116183150 = 11181209205358 := by decide
theorem cert_e2385116183150 : check e2385116183150 [[],[.left,.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2385116183162 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2385116183162 : Closed e2385116183162 ∧ code e2385116183162 = 11181209205370 := by decide
theorem cert_e2385116183162 : check e2385116183162 [[],[.left,.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2385116183450 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2385116183450 : Closed e2385116183450 ∧ code e2385116183450 = 11181209205658 := by decide
theorem cert_e2385116183450 : check e2385116183450 [[],[.left,.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2385116183766 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2385116183766 : Closed e2385116183766 ∧ code e2385116183766 = 11181209205974 := by decide
theorem cert_e2385116183766 : check e2385116183766 [[],[.left,.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2385116183770 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2385116183770 : Closed e2385116183770 ∧ code e2385116183770 = 11181209205978 := by decide
theorem cert_e2385116183770 : check e2385116183770 [[],[.left,.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2385116183786 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2385116183786 : Closed e2385116183786 ∧ code e2385116183786 = 11181209205994 := by decide
theorem cert_e2385116183786 : check e2385116183786 [[],[.left,.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2385116183862 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2385116183862 : Closed e2385116183862 ∧ code e2385116183862 = 11181209206070 := by decide
theorem cert_e2385116183862 : check e2385116183862 [[],[.left,.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2385116183866 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2385116183866 : Closed e2385116183866 ∧ code e2385116183866 = 11181209206074 := by decide
theorem cert_e2385116183866 : check e2385116183866 [[],[.left,.left],[.left],[],[.under,.left],[.under]] .three = true := by decide
def e2385116183962 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2385116183962 : Closed e2385116183962 ∧ code e2385116183962 = 11181209206170 := by decide
theorem cert_e2385116183962 : check e2385116183962 [[],[.left,.left],[.left],[],[.under,.left]] .smaller = true := by decide
def e2385116187502 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2385116187502 : Closed e2385116187502 ∧ code e2385116187502 = 11181209209710 := by decide
theorem cert_e2385116187502 : check e2385116187502 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116187510 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2385116187510 : Closed e2385116187510 ∧ code e2385116187510 = 11181209209718 := by decide
theorem cert_e2385116187510 : check e2385116187510 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116187566 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2385116187566 : Closed e2385116187566 ∧ code e2385116187566 = 11181209209774 := by decide
theorem cert_e2385116187566 : check e2385116187566 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116187578 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2385116187578 : Closed e2385116187578 ∧ code e2385116187578 = 11181209209786 := by decide
theorem cert_e2385116187578 : check e2385116187578 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116187606 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2385116187606 : Closed e2385116187606 ∧ code e2385116187606 = 11181209209814 := by decide
theorem cert_e2385116187606 : check e2385116187606 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116187610 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2385116187610 : Closed e2385116187610 ∧ code e2385116187610 = 11181209209818 := by decide
theorem cert_e2385116187610 : check e2385116187610 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116187886 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2385116187886 : Closed e2385116187886 ∧ code e2385116187886 = 11181209210094 := by decide
theorem cert_e2385116187886 : check e2385116187886 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116187894 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2385116187894 : Closed e2385116187894 ∧ code e2385116187894 = 11181209210102 := by decide
theorem cert_e2385116187894 : check e2385116187894 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116188270 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2385116188270 : Closed e2385116188270 ∧ code e2385116188270 = 11181209210478 := by decide
theorem cert_e2385116188270 : check e2385116188270 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116188282 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2385116188282 : Closed e2385116188282 ∧ code e2385116188282 = 11181209210490 := by decide
theorem cert_e2385116188282 : check e2385116188282 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116188470 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2385116188470 : Closed e2385116188470 ∧ code e2385116188470 = 11181209210678 := by decide
theorem cert_e2385116188470 : check e2385116188470 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116188474 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2385116188474 : Closed e2385116188474 ∧ code e2385116188474 = 11181209210682 := by decide
theorem cert_e2385116188474 : check e2385116188474 [[],[.left,.left],[.left],[]] .sourceHead = true := by decide
def e2385116194222 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2385116194222 : Closed e2385116194222 ∧ code e2385116194222 = 11181209216430 := by decide
theorem cert_e2385116194222 : check e2385116194222 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116194234 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2385116194234 : Closed e2385116194234 ∧ code e2385116194234 = 11181209216442 := by decide
theorem cert_e2385116194234 : check e2385116194234 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116194282 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2385116194282 : Closed e2385116194282 ∧ code e2385116194282 = 11181209216490 := by decide
theorem cert_e2385116194282 : check e2385116194282 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116194414 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2385116194414 : Closed e2385116194414 ∧ code e2385116194414 = 11181209216622 := by decide
theorem cert_e2385116194414 : check e2385116194414 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116194426 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2385116194426 : Closed e2385116194426 ∧ code e2385116194426 = 11181209216634 := by decide
theorem cert_e2385116194426 : check e2385116194426 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116194714 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2385116194714 : Closed e2385116194714 ∧ code e2385116194714 = 11181209216922 := by decide
theorem cert_e2385116194714 : check e2385116194714 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116197590 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2385116197590 : Closed e2385116197590 ∧ code e2385116197590 = 11181209219798 := by decide
theorem cert_e2385116197590 : check e2385116197590 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116197594 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2385116197594 : Closed e2385116197594 ∧ code e2385116197594 = 11181209219802 := by decide
theorem cert_e2385116197594 : check e2385116197594 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116197610 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2385116197610 : Closed e2385116197610 ∧ code e2385116197610 = 11181209219818 := by decide
theorem cert_e2385116197610 : check e2385116197610 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116197686 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2385116197686 : Closed e2385116197686 ∧ code e2385116197686 = 11181209219894 := by decide
theorem cert_e2385116197686 : check e2385116197686 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116197690 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2385116197690 : Closed e2385116197690 ∧ code e2385116197690 = 11181209219898 := by decide
theorem cert_e2385116197690 : check e2385116197690 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116197786 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2385116197786 : Closed e2385116197786 ∧ code e2385116197786 = 11181209219994 := by decide
theorem cert_e2385116197786 : check e2385116197786 [[],[.left,.left],[.left],[],[.under]] .smaller = true := by decide
def e2385116313326 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2385116313326 : Closed e2385116313326 ∧ code e2385116313326 = 11181209335534 := by decide
def e2385116313454 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2385116313454 : Closed e2385116313454 ∧ code e2385116313454 = 11181209335662 := by decide
def e2385116313462 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2385116313462 : Closed e2385116313462 ∧ code e2385116313462 = 11181209335670 := by decide
def e2385116314350 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2385116314350 : Closed e2385116314350 ∧ code e2385116314350 = 11181209336558 := by decide
def e2385116314542 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2385116314542 : Closed e2385116314542 ∧ code e2385116314542 = 11181209336750 := by decide
def e2385116314554 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2385116314554 : Closed e2385116314554 ∧ code e2385116314554 = 11181209336762 := by decide
def e2385116314990 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2385116314990 : Closed e2385116314990 ∧ code e2385116314990 = 11181209337198 := by decide
def e2385116314998 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2385116314998 : Closed e2385116314998 ∧ code e2385116314998 = 11181209337206 := by decide
def e2385116315054 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2385116315054 : Closed e2385116315054 ∧ code e2385116315054 = 11181209337262 := by decide
def e2385116315066 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2385116315066 : Closed e2385116315066 ∧ code e2385116315066 = 11181209337274 := by decide
def e2385116315094 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2385116315094 : Closed e2385116315094 ∧ code e2385116315094 = 11181209337302 := by decide
private def t_e2385116315094 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2385116315094 : ¬ IsSelfInterpreter e2385116315094 :=
  wSource (t := t_e2385116315094) (replay_sound (ps := []) (t := e2385116315094) (by decide)) (by decide)
def e2385116315098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2385116315098 : Closed e2385116315098 ∧ code e2385116315098 = 11181209337306 := by decide
private def t_e2385116315098 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2385116315098 : ¬ IsSelfInterpreter e2385116315098 :=
  wSource (t := t_e2385116315098) (replay_sound (ps := []) (t := e2385116315098) (by decide)) (by decide)
def e2385116319470 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2385116319470 : Closed e2385116319470 ∧ code e2385116319470 = 11181209341678 := by decide
theorem cert_e2385116319470 : check e2385116319470 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2385116319598 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2385116319598 : Closed e2385116319598 ∧ code e2385116319598 = 11181209341806 := by decide
theorem cert_e2385116319598 : check e2385116319598 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2385116319606 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2385116319606 : Closed e2385116319606 ∧ code e2385116319606 = 11181209341814 := by decide
theorem cert_e2385116319606 : check e2385116319606 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2385116322286 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2385116322286 : Closed e2385116322286 ∧ code e2385116322286 = 11181209344494 := by decide
theorem cert_e2385116322286 : check e2385116322286 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2385116323054 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2385116323054 : Closed e2385116323054 ∧ code e2385116323054 = 11181209345262 := by decide
theorem cert_e2385116323054 : check e2385116323054 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2385116323062 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2385116323062 : Closed e2385116323062 ∧ code e2385116323062 = 11181209345270 := by decide
theorem cert_e2385116323062 : check e2385116323062 [[],[.left,.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2385116325614 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2385116325614 : Closed e2385116325614 ∧ code e2385116325614 = 11181209347822 := by decide
theorem cert_e2385116325614 : check e2385116325614 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2385116325806 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2385116325806 : Closed e2385116325806 ∧ code e2385116325806 = 11181209348014 := by decide
theorem cert_e2385116325806 : check e2385116325806 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2385116325818 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2385116325818 : Closed e2385116325818 ∧ code e2385116325818 = 11181209348026 := by decide
theorem cert_e2385116325818 : checkPay e2385116325818 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2385116326382 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2385116326382 : Closed e2385116326382 ∧ code e2385116326382 = 11181209348590 := by decide
theorem cert_e2385116326382 : check e2385116326382 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2385116327534 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2385116327534 : Closed e2385116327534 ∧ code e2385116327534 = 11181209349742 := by decide
theorem cert_e2385116327534 : check e2385116327534 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e2385116327546 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2385116327546 : Closed e2385116327546 ∧ code e2385116327546 = 11181209349754 := by decide
theorem cert_e2385116327546 : check e2385116327546 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116328814 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2385116328814 : Closed e2385116328814 ∧ code e2385116328814 = 11181209351022 := by decide
theorem cert_e2385116328814 : check e2385116328814 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2385116328822 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2385116328822 : Closed e2385116328822 ∧ code e2385116328822 = 11181209351030 := by decide
theorem cert_e2385116328822 : check e2385116328822 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116328878 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2385116328878 : Closed e2385116328878 ∧ code e2385116328878 = 11181209351086 := by decide
theorem cert_e2385116328878 : check e2385116328878 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2385116328890 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2385116328890 : Closed e2385116328890 ∧ code e2385116328890 = 11181209351098 := by decide
def e2385116328918 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2385116328918 : Closed e2385116328918 ∧ code e2385116328918 = 11181209351126 := by decide
theorem cert_e2385116328918 : check e2385116328918 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116328922 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2385116328922 : Closed e2385116328922 ∧ code e2385116328922 = 11181209351130 := by decide
theorem cert_e2385116328922 : check e2385116328922 [[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116329198 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2385116329198 : Closed e2385116329198 ∧ code e2385116329198 = 11181209351406 := by decide
theorem cert_e2385116329198 : checkPay e2385116329198 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2385116329206 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2385116329206 : Closed e2385116329206 ∧ code e2385116329206 = 11181209351414 := by decide
theorem cert_e2385116329206 : checkPay e2385116329206 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2385116329582 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2385116329582 : Closed e2385116329582 ∧ code e2385116329582 = 11181209351790 := by decide
theorem cert_e2385116329582 : check e2385116329582 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116329594 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2385116329594 : Closed e2385116329594 ∧ code e2385116329594 = 11181209351802 := by decide
theorem cert_e2385116329594 : check e2385116329594 [[],[.left,.left],[.left],[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116329782 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2385116329782 : Closed e2385116329782 ∧ code e2385116329782 = 11181209351990 := by decide
private def t_e2385116329782 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2385116329782 : ¬ IsSelfInterpreter e2385116329782 :=
  wSource (t := t_e2385116329782) (replay_sound (ps := []) (t := e2385116329782) (by decide)) (by decide)
def e2385116329786 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2385116329786 : Closed e2385116329786 ∧ code e2385116329786 = 11181209351994 := by decide
private def t_e2385116329786 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2385116329786 : ¬ IsSelfInterpreter e2385116329786 :=
  wSource (t := t_e2385116329786) (replay_sound (ps := []) (t := e2385116329786) (by decide)) (by decide)
def e2385116334958 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2385116334958 : Closed e2385116334958 ∧ code e2385116334958 = 11181209357166 := by decide
theorem cert_e2385116334958 : check e2385116334958 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116334966 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2385116334966 : Closed e2385116334966 ∧ code e2385116334966 = 11181209357174 := by decide
theorem cert_e2385116334966 : check e2385116334966 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335022 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2385116335022 : Closed e2385116335022 ∧ code e2385116335022 = 11181209357230 := by decide
theorem cert_e2385116335022 : check e2385116335022 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335034 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2385116335034 : Closed e2385116335034 ∧ code e2385116335034 = 11181209357242 := by decide
theorem cert_e2385116335034 : check e2385116335034 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335062 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2385116335062 : Closed e2385116335062 ∧ code e2385116335062 = 11181209357270 := by decide
theorem cert_e2385116335062 : check e2385116335062 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335066 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2385116335066 : Closed e2385116335066 ∧ code e2385116335066 = 11181209357274 := by decide
theorem cert_e2385116335066 : check e2385116335066 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335342 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2385116335342 : Closed e2385116335342 ∧ code e2385116335342 = 11181209357550 := by decide
theorem cert_e2385116335342 : check e2385116335342 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335350 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2385116335350 : Closed e2385116335350 ∧ code e2385116335350 = 11181209357558 := by decide
theorem cert_e2385116335350 : check e2385116335350 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335726 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2385116335726 : Closed e2385116335726 ∧ code e2385116335726 = 11181209357934 := by decide
theorem cert_e2385116335726 : check e2385116335726 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335738 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2385116335738 : Closed e2385116335738 ∧ code e2385116335738 = 11181209357946 := by decide
theorem cert_e2385116335738 : check e2385116335738 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335926 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2385116335926 : Closed e2385116335926 ∧ code e2385116335926 = 11181209358134 := by decide
theorem cert_e2385116335926 : check e2385116335926 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116335930 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2385116335930 : Closed e2385116335930 ∧ code e2385116335930 = 11181209358138 := by decide
theorem cert_e2385116335930 : check e2385116335930 [[],[.left,.left],[.left],[],[]] .smaller = true := by decide
def e2385116344046 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2385116344046 : Closed e2385116344046 ∧ code e2385116344046 = 11181209366254 := by decide
theorem cert_e2385116344046 : check e2385116344046 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2385116344174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2385116344174 : Closed e2385116344174 ∧ code e2385116344174 = 11181209366382 := by decide
theorem cert_e2385116344174 : check e2385116344174 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2385116344182 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2385116344182 : Closed e2385116344182 ∧ code e2385116344182 = 11181209366390 := by decide
def e2385116346862 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2385116346862 : Closed e2385116346862 ∧ code e2385116346862 = 11181209369070 := by decide
theorem cert_e2385116346862 : check e2385116346862 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2385116347630 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2385116347630 : Closed e2385116347630 ∧ code e2385116347630 = 11181209369838 := by decide
theorem cert_e2385116347630 : check e2385116347630 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2385116347638 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2385116347638 : Closed e2385116347638 ∧ code e2385116347638 = 11181209369846 := by decide
theorem cert_e2385116347638 : check e2385116347638 [[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2385116370670 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2385116370670 : Closed e2385116370670 ∧ code e2385116370670 = 11181209392878 := by decide
theorem cert_e2385116370670 : check e2385116370670 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2385116370862 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2385116370862 : Closed e2385116370862 ∧ code e2385116370862 = 11181209393070 := by decide
theorem cert_e2385116370862 : check e2385116370862 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2385116370874 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2385116370874 : Closed e2385116370874 ∧ code e2385116370874 = 11181209393082 := by decide
theorem cert_e2385116370874 : check e2385116370874 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2385116371438 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2385116371438 : Closed e2385116371438 ∧ code e2385116371438 = 11181209393646 := by decide
theorem cert_e2385116371438 : check e2385116371438 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2385116372590 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2385116372590 : Closed e2385116372590 ∧ code e2385116372590 = 11181209394798 := by decide
theorem cert_e2385116372590 : check e2385116372590 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2385116372602 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2385116372602 : Closed e2385116372602 ∧ code e2385116372602 = 11181209394810 := by decide
theorem cert_e2385116372602 : check e2385116372602 [[],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2385116384110 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2385116384110 : Closed e2385116384110 ∧ code e2385116384110 = 11181209406318 := by decide
theorem cert_e2385116384110 : check e2385116384110 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2385116384118 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2385116384118 : Closed e2385116384118 ∧ code e2385116384118 = 11181209406326 := by decide
theorem cert_e2385116384118 : check e2385116384118 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2385116384174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2385116384174 : Closed e2385116384174 ∧ code e2385116384174 = 11181209406382 := by decide
theorem cert_e2385116384174 : check e2385116384174 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2385116384186 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2385116384186 : Closed e2385116384186 ∧ code e2385116384186 = 11181209406394 := by decide
theorem cert_e2385116384186 : check e2385116384186 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2385116384214 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2385116384214 : Closed e2385116384214 ∧ code e2385116384214 = 11181209406422 := by decide
theorem cert_e2385116384214 : check e2385116384214 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2385116384218 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2385116384218 : Closed e2385116384218 ∧ code e2385116384218 = 11181209406426 := by decide
theorem cert_e2385116384218 : check e2385116384218 [[],[.left,.left],[.left],[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under]] .three = true := by decide
def e2385116384494 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2385116384494 : Closed e2385116384494 ∧ code e2385116384494 = 11181209406702 := by decide
theorem cert_e2385116384494 : check e2385116384494 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116384502 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2385116384502 : Closed e2385116384502 ∧ code e2385116384502 = 11181209406710 := by decide
theorem cert_e2385116384502 : check e2385116384502 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116384878 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2385116384878 : Closed e2385116384878 ∧ code e2385116384878 = 11181209407086 := by decide
theorem cert_e2385116384878 : check e2385116384878 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116384890 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2385116384890 : Closed e2385116384890 ∧ code e2385116384890 = 11181209407098 := by decide
theorem cert_e2385116384890 : check e2385116384890 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116385078 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2385116385078 : Closed e2385116385078 ∧ code e2385116385078 = 11181209407286 := by decide
theorem cert_e2385116385078 : check e2385116385078 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116385082 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2385116385082 : Closed e2385116385082 ∧ code e2385116385082 = 11181209407290 := by decide
theorem cert_e2385116385082 : check e2385116385082 [[],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2385116924782 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2385116924782 : Closed e2385116924782 ∧ code e2385116924782 = 11181209946990 := by decide
theorem cert_e2385116924782 : check e2385116924782 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116924790 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2385116924790 : Closed e2385116924790 ∧ code e2385116924790 = 11181209946998 := by decide
theorem cert_e2385116924790 : check e2385116924790 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116924846 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2385116924846 : Closed e2385116924846 ∧ code e2385116924846 = 11181209947054 := by decide
theorem cert_e2385116924846 : check e2385116924846 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116924858 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2385116924858 : Closed e2385116924858 ∧ code e2385116924858 = 11181209947066 := by decide
theorem cert_e2385116924858 : check e2385116924858 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116924886 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2385116924886 : Closed e2385116924886 ∧ code e2385116924886 = 11181209947094 := by decide
theorem cert_e2385116924886 : check e2385116924886 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116924890 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2385116924890 : Closed e2385116924890 ∧ code e2385116924890 = 11181209947098 := by decide
theorem cert_e2385116924890 : check e2385116924890 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116925166 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2385116925166 : Closed e2385116925166 ∧ code e2385116925166 = 11181209947374 := by decide
theorem cert_e2385116925166 : check e2385116925166 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116925174 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2385116925174 : Closed e2385116925174 ∧ code e2385116925174 = 11181209947382 := by decide
theorem cert_e2385116925174 : check e2385116925174 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116925550 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2385116925550 : Closed e2385116925550 ∧ code e2385116925550 = 11181209947758 := by decide
theorem cert_e2385116925550 : check e2385116925550 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116925562 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2385116925562 : Closed e2385116925562 ∧ code e2385116925562 = 11181209947770 := by decide
theorem cert_e2385116925562 : check e2385116925562 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116925750 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2385116925750 : Closed e2385116925750 ∧ code e2385116925750 = 11181209947958 := by decide
theorem cert_e2385116925750 : check e2385116925750 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2385116925754 : Term := (.app (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2385116925754 : Closed e2385116925754 ∧ code e2385116925754 = 11181209947962 := by decide
theorem cert_e2385116925754 : check e2385116925754 [[],[.left,.left],[.left],[.left],[],[]] .smaller = true := by decide
def e2388004813338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388004813338 : Closed e2388004813338 ∧ code e2388004813338 = 11184097835546 := by decide
theorem cert_e2388004813338 : check e2388004813338 [[],[.left]] .chain = true := by decide
def e2388004821530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388004821530 : Closed e2388004821530 ∧ code e2388004821530 = 11184097843738 := by decide
theorem cert_e2388004821530 : check e2388004821530 [[],[.left]] .chain = true := by decide
def e2388004878874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388004878874 : Closed e2388004878874 ∧ code e2388004878874 = 11184097901082 := by decide
theorem cert_e2388004878874 : check e2388004878874 [[],[.left]] .chain = true := by decide
def e2388004891162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388004891162 : Closed e2388004891162 ∧ code e2388004891162 = 11184097913370 := by decide
theorem cert_e2388004891162 : check e2388004891162 [[],[.left]] .chain = true := by decide
def e2388004919834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388004919834 : Closed e2388004919834 ∧ code e2388004919834 = 11184097942042 := by decide
theorem cert_e2388004919834 : check e2388004919834 [[],[.left]] .chain = true := by decide
def e2388004923930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388004923930 : Closed e2388004923930 ∧ code e2388004923930 = 11184097946138 := by decide
theorem cert_e2388004923930 : check e2388004923930 [[],[.left]] .chain = true := by decide
def e2388005206554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388005206554 : Closed e2388005206554 ∧ code e2388005206554 = 11184098228762 := by decide
theorem cert_e2388005206554 : check e2388005206554 [[],[.left]] .chain = true := by decide
def e2388005214746 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388005214746 : Closed e2388005214746 ∧ code e2388005214746 = 11184098236954 := by decide
theorem cert_e2388005214746 : check e2388005214746 [[],[.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2385066593242
#print axioms Blc.Floor43.cert_e2385116315094
#print axioms Blc.Floor43.cert_e2385116315098
#print axioms Blc.Floor43.cert_e2385116329782
#print axioms Blc.Floor43.cert_e2385116329786
