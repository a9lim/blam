import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406476654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406476654 : Closed e2422406476654 ∧ code e2422406476654 = 11218499498862 := by decide
theorem cert_e2422406476654 : check e2422406476654 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406476662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406476662 : Closed e2422406476662 ∧ code e2422406476662 = 11218499498870 := by decide
theorem cert_e2422406476662 : check e2422406476662 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406476682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406476682 : Closed e2422406476682 ∧ code e2422406476682 = 11218499498890 := by decide
theorem cert_e2422406476682 : check e2422406476682 [[],[]] .chain = true := by decide
def e2422406476706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406476706 : Closed e2422406476706 ∧ code e2422406476706 = 11218499498914 := by decide
theorem cert_e2422406476706 : check e2422406476706 [[],[]] .chain = true := by decide
def e2422406476718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406476718 : Closed e2422406476718 ∧ code e2422406476718 = 11218499498926 := by decide
theorem cert_e2422406476718 : check e2422406476718 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406476726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 1))) (.var 1))))))
theorem wire_e2422406476726 : Closed e2422406476726 ∧ code e2422406476726 = 11218499498934 := by decide
theorem cert_e2422406476726 : check e2422406476726 [[],[]] .chain = true := by decide
def e2422406476730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406476730 : Closed e2422406476730 ∧ code e2422406476730 = 11218499498938 := by decide
theorem cert_e2422406476730 : check e2422406476730 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406476758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406476758 : Closed e2422406476758 ∧ code e2422406476758 = 11218499498966 := by decide
theorem cert_e2422406476758 : check e2422406476758 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406476762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406476762 : Closed e2422406476762 ∧ code e2422406476762 = 11218499498970 := by decide
theorem cert_e2422406476762 : check e2422406476762 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406476830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406476830 : Closed e2422406476830 ∧ code e2422406476830 = 11218499499038 := by decide
theorem cert_e2422406476830 : check e2422406476830 [[],[]] .chain = true := by decide
def e2422406477026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406477026 : Closed e2422406477026 ∧ code e2422406477026 = 11218499499234 := by decide
theorem cert_e2422406477026 : check e2422406477026 [[],[]] .chain = true := by decide
def e2422406477038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406477038 : Closed e2422406477038 ∧ code e2422406477038 = 11218499499246 := by decide
theorem cert_e2422406477038 : check e2422406477038 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406477046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406477046 : Closed e2422406477046 ∧ code e2422406477046 = 11218499499254 := by decide
theorem cert_e2422406477046 : check e2422406477046 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406477314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406477314 : Closed e2422406477314 ∧ code e2422406477314 = 11218499499522 := by decide
theorem cert_e2422406477314 : check e2422406477314 [[],[]] .chain = true := by decide
def e2422406477326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406477326 : Closed e2422406477326 ∧ code e2422406477326 = 11218499499534 := by decide
theorem cert_e2422406477326 : check e2422406477326 [[],[]] .chain = true := by decide
def e2422406477338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406477338 : Closed e2422406477338 ∧ code e2422406477338 = 11218499499546 := by decide
theorem cert_e2422406477338 : check e2422406477338 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406477410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406477410 : Closed e2422406477410 ∧ code e2422406477410 = 11218499499618 := by decide
theorem cert_e2422406477410 : check e2422406477410 [[],[]] .chain = true := by decide
def e2422406477422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406477422 : Closed e2422406477422 ∧ code e2422406477422 = 11218499499630 := by decide
theorem cert_e2422406477422 : check e2422406477422 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406477430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406477430 : Closed e2422406477430 ∧ code e2422406477430 = 11218499499638 := by decide
theorem cert_e2422406477430 : check e2422406477430 [[],[]] .chain = true := by decide
def e2422406477434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406477434 : Closed e2422406477434 ∧ code e2422406477434 = 11218499499642 := by decide
theorem cert_e2422406477434 : check e2422406477434 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406477622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406477622 : Closed e2422406477622 ∧ code e2422406477622 = 11218499499830 := by decide
theorem cert_e2422406477622 : check e2422406477622 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406477626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406477626 : Closed e2422406477626 ∧ code e2422406477626 = 11218499499834 := by decide
theorem cert_e2422406477626 : check e2422406477626 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406480046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.var 2))))))
theorem wire_e2422406480046 : Closed e2422406480046 ∧ code e2422406480046 = 11218499502254 := by decide
theorem cert_e2422406480046 : check e2422406480046 [[],[]] .chain = true := by decide
def e2422406480058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 0))))))
theorem wire_e2422406480058 : Closed e2422406480058 ∧ code e2422406480058 = 11218499502266 := by decide
theorem cert_e2422406480058 : check e2422406480058 [[],[]] .chain = true := by decide
def e2422406480622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0)))) (.var 2)) (.var 2))))))
theorem wire_e2422406480622 : Closed e2422406480622 ∧ code e2422406480622 = 11218499502830 := by decide
theorem cert_e2422406480622 : check e2422406480622 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406480750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422406480750 : Closed e2422406480750 ∧ code e2422406480750 = 11218499502958 := by decide
theorem cert_e2422406480750 : check e2422406480750 [[],[]] .chain = true := by decide
def e2422406480758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422406480758 : Closed e2422406480758 ∧ code e2422406480758 = 11218499502966 := by decide
theorem cert_e2422406480758 : check e2422406480758 [[],[]] .chain = true := by decide
def e2422406480814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422406480814 : Closed e2422406480814 ∧ code e2422406480814 = 11218499503022 := by decide
theorem cert_e2422406480814 : check e2422406480814 [[],[]] .chain = true := by decide
def e2422406480826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422406480826 : Closed e2422406480826 ∧ code e2422406480826 = 11218499503034 := by decide
theorem cert_e2422406480826 : check e2422406480826 [[],[]] .chain = true := by decide
def e2422406480874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 0)) (.var 0))))))
theorem wire_e2422406480874 : Closed e2422406480874 ∧ code e2422406480874 = 11218499503082 := by decide
theorem cert_e2422406480874 : check e2422406480874 [[],[]] .chain = true := by decide
def e2422406481582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406481582 : Closed e2422406481582 ∧ code e2422406481582 = 11218499503790 := by decide
theorem cert_e2422406481582 : check e2422406481582 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406481594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406481594 : Closed e2422406481594 ∧ code e2422406481594 = 11218499503802 := by decide
theorem cert_e2422406481594 : check e2422406481594 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406482158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406482158 : Closed e2422406482158 ∧ code e2422406482158 = 11218499504366 := by decide
theorem cert_e2422406482158 : check e2422406482158 [[],[]] .chain = true := by decide
def e2422406482166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406482166 : Closed e2422406482166 ∧ code e2422406482166 = 11218499504374 := by decide
theorem cert_e2422406482166 : check e2422406482166 [[],[]] .chain = true := by decide
def e2422406482350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406482350 : Closed e2422406482350 ∧ code e2422406482350 = 11218499504558 := by decide
theorem cert_e2422406482350 : check e2422406482350 [[],[]] .chain = true := by decide
def e2422406482362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406482362 : Closed e2422406482362 ∧ code e2422406482362 = 11218499504570 := by decide
theorem cert_e2422406482362 : check e2422406482362 [[],[]] .chain = true := by decide
def e2422406482410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406482410 : Closed e2422406482410 ∧ code e2422406482410 = 11218499504618 := by decide
theorem cert_e2422406482410 : check e2422406482410 [[],[]] .chain = true := by decide
def e2422406482542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406482542 : Closed e2422406482542 ∧ code e2422406482542 = 11218499504750 := by decide
theorem cert_e2422406482542 : check e2422406482542 [[],[]] .chain = true := by decide
def e2422406482554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406482554 : Closed e2422406482554 ∧ code e2422406482554 = 11218499504762 := by decide
theorem cert_e2422406482554 : check e2422406482554 [[],[]] .chain = true := by decide
def e2422406482718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406482718 : Closed e2422406482718 ∧ code e2422406482718 = 11218499504926 := by decide
theorem cert_e2422406482718 : check e2422406482718 [[],[]] .chain = true := by decide
def e2422406482830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406482830 : Closed e2422406482830 ∧ code e2422406482830 = 11218499505038 := by decide
theorem cert_e2422406482830 : check e2422406482830 [[],[]] .chain = true := by decide
def e2422406482842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406482842 : Closed e2422406482842 ∧ code e2422406482842 = 11218499505050 := by decide
theorem cert_e2422406482842 : check e2422406482842 [[],[]] .chain = true := by decide
def e2422406483054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406483054 : Closed e2422406483054 ∧ code e2422406483054 = 11218499505262 := by decide
theorem cert_e2422406483054 : check e2422406483054 [[],[]] .chain = true := by decide
def e2422406483066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406483066 : Closed e2422406483066 ∧ code e2422406483066 = 11218499505274 := by decide
theorem cert_e2422406483066 : check e2422406483066 [[],[]] .chain = true := by decide
def e2422406483230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406483230 : Closed e2422406483230 ∧ code e2422406483230 = 11218499505438 := by decide
theorem cert_e2422406483230 : check e2422406483230 [[],[]] .chain = true := by decide
def e2422406483398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406483398 : Closed e2422406483398 ∧ code e2422406483398 = 11218499505606 := by decide
theorem cert_e2422406483398 : check e2422406483398 [[],[]] .chain = true := by decide
def e2422406483502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406483502 : Closed e2422406483502 ∧ code e2422406483502 = 11218499505710 := by decide
theorem cert_e2422406483502 : check e2422406483502 [[],[]] .chain = true := by decide
def e2422406483682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406483682 : Closed e2422406483682 ∧ code e2422406483682 = 11218499505890 := by decide
theorem cert_e2422406483682 : check e2422406483682 [[],[]] .chain = true := by decide
def e2422406483694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.var 2)) (.var 2))))))
theorem wire_e2422406483694 : Closed e2422406483694 ∧ code e2422406483694 = 11218499505902 := by decide
theorem cert_e2422406483694 : check e2422406483694 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406483734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406483734 : Closed e2422406483734 ∧ code e2422406483734 = 11218499505942 := by decide
theorem cert_e2422406483734 : check e2422406483734 [[],[]] .chain = true := by decide
def e2422406483738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422406483738 : Closed e2422406483738 ∧ code e2422406483738 = 11218499505946 := by decide
theorem cert_e2422406483738 : check e2422406483738 [[],[]] .chain = true := by decide
def e2422406483782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422406483782 : Closed e2422406483782 ∧ code e2422406483782 = 11218499505990 := by decide
theorem cert_e2422406483782 : check e2422406483782 [[],[]] .chain = true := by decide
def e2422406483810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406483810 : Closed e2422406483810 ∧ code e2422406483810 = 11218499506018 := by decide
theorem cert_e2422406483810 : check e2422406483810 [[],[]] .chain = true := by decide
def e2422406483822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 1)) (.var 2))))))
theorem wire_e2422406483822 : Closed e2422406483822 ∧ code e2422406483822 = 11218499506030 := by decide
theorem cert_e2422406483822 : check e2422406483822 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406483830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.var 2)) (.var 1))))))
theorem wire_e2422406483830 : Closed e2422406483830 ∧ code e2422406483830 = 11218499506038 := by decide
theorem cert_e2422406483830 : check e2422406483830 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406486190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406486190 : Closed e2422406486190 ∧ code e2422406486190 = 11218499508398 := by decide
theorem cert_e2422406486190 : check e2422406486190 [[],[]] .chain = true := by decide
def e2422406486202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406486202 : Closed e2422406486202 ∧ code e2422406486202 = 11218499508410 := by decide
theorem cert_e2422406486202 : check e2422406486202 [[],[]] .chain = true := by decide
def e2422406486574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406486574 : Closed e2422406486574 ∧ code e2422406486574 = 11218499508782 := by decide
theorem cert_e2422406486574 : check e2422406486574 [[],[]] .chain = true := by decide
def e2422406486754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406486754 : Closed e2422406486754 ∧ code e2422406486754 = 11218499508962 := by decide
theorem cert_e2422406486754 : check e2422406486754 [[],[]] .chain = true := by decide
def e2422406486766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2422406486766 : Closed e2422406486766 ∧ code e2422406486766 = 11218499508974 := by decide
theorem cert_e2422406486766 : check e2422406486766 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406486894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406486894 : Closed e2422406486894 ∧ code e2422406486894 = 11218499509102 := by decide
theorem cert_e2422406486894 : check e2422406486894 [[],[]] .chain = true := by decide
def e2422406486902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406486902 : Closed e2422406486902 ∧ code e2422406486902 = 11218499509110 := by decide
theorem cert_e2422406486902 : check e2422406486902 [[],[]] .chain = true := by decide
def e2422406486922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406486922 : Closed e2422406486922 ∧ code e2422406486922 = 11218499509130 := by decide
theorem cert_e2422406486922 : check e2422406486922 [[],[]] .chain = true := by decide
def e2422406486946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406486946 : Closed e2422406486946 ∧ code e2422406486946 = 11218499509154 := by decide
theorem cert_e2422406486946 : check e2422406486946 [[],[]] .chain = true := by decide
def e2422406486958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406486958 : Closed e2422406486958 ∧ code e2422406486958 = 11218499509166 := by decide
theorem cert_e2422406486958 : check e2422406486958 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406486966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2422406486966 : Closed e2422406486966 ∧ code e2422406486966 = 11218499509174 := by decide
theorem cert_e2422406486966 : check e2422406486966 [[],[]] .chain = true := by decide
def e2422406486970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406486970 : Closed e2422406486970 ∧ code e2422406486970 = 11218499509178 := by decide
theorem cert_e2422406486970 : check e2422406486970 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406487406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406487406 : Closed e2422406487406 ∧ code e2422406487406 = 11218499509614 := by decide
theorem cert_e2422406487406 : check e2422406487406 [[],[]] .chain = true := by decide
def e2422406487414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406487414 : Closed e2422406487414 ∧ code e2422406487414 = 11218499509622 := by decide
theorem cert_e2422406487414 : check e2422406487414 [[],[]] .chain = true := by decide
def e2422406487470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406487470 : Closed e2422406487470 ∧ code e2422406487470 = 11218499509678 := by decide
theorem cert_e2422406487470 : check e2422406487470 [[],[]] .chain = true := by decide
def e2422406487482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406487482 : Closed e2422406487482 ∧ code e2422406487482 = 11218499509690 := by decide
theorem cert_e2422406487482 : check e2422406487482 [[],[]] .chain = true := by decide
def e2422406487510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406487510 : Closed e2422406487510 ∧ code e2422406487510 = 11218499509718 := by decide
theorem cert_e2422406487510 : check e2422406487510 [[],[]] .chain = true := by decide
def e2422406487514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406487514 : Closed e2422406487514 ∧ code e2422406487514 = 11218499509722 := by decide
theorem cert_e2422406487514 : check e2422406487514 [[],[]] .chain = true := by decide
def e2422406487594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0))))))
theorem wire_e2422406487594 : Closed e2422406487594 ∧ code e2422406487594 = 11218499509802 := by decide
theorem cert_e2422406487594 : check e2422406487594 [[],[]] .chain = true := by decide
def e2422406487690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406487690 : Closed e2422406487690 ∧ code e2422406487690 = 11218499509898 := by decide
theorem cert_e2422406487690 : check e2422406487690 [[],[]] .chain = true := by decide
def e2422406487714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406487714 : Closed e2422406487714 ∧ code e2422406487714 = 11218499509922 := by decide
theorem cert_e2422406487714 : check e2422406487714 [[],[]] .chain = true := by decide
def e2422406487726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0)) (.var 2))))))
theorem wire_e2422406487726 : Closed e2422406487726 ∧ code e2422406487726 = 11218499509934 := by decide
theorem cert_e2422406487726 : check e2422406487726 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406487734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 1)) (.var 1))))))
theorem wire_e2422406487734 : Closed e2422406487734 ∧ code e2422406487734 = 11218499509942 := by decide
theorem cert_e2422406487734 : check e2422406487734 [[],[]] .chain = true := by decide
def e2422406487738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 2)) (.var 0))))))
theorem wire_e2422406487738 : Closed e2422406487738 ∧ code e2422406487738 = 11218499509946 := by decide
theorem cert_e2422406487738 : check e2422406487738 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406487766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 0)) (.var 1))))))
theorem wire_e2422406487766 : Closed e2422406487766 ∧ code e2422406487766 = 11218499509974 := by decide
theorem cert_e2422406487766 : check e2422406487766 [[],[]] .chain = true := by decide
def e2422406487770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 1)) (.var 0))))))
theorem wire_e2422406487770 : Closed e2422406487770 ∧ code e2422406487770 = 11218499509978 := by decide
theorem cert_e2422406487770 : check e2422406487770 [[],[]] .chain = true := by decide
def e2422406487786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 0)) (.var 0))))))
theorem wire_e2422406487786 : Closed e2422406487786 ∧ code e2422406487786 = 11218499509994 := by decide
theorem cert_e2422406487786 : check e2422406487786 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406488110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422406488110 : Closed e2422406488110 ∧ code e2422406488110 = 11218499510318 := by decide
theorem cert_e2422406488110 : check e2422406488110 [[],[]] .chain = true := by decide
def e2422406488302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422406488302 : Closed e2422406488302 ∧ code e2422406488302 = 11218499510510 := by decide
theorem cert_e2422406488302 : check e2422406488302 [[],[]] .chain = true := by decide
def e2422406488314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2422406488314 : Closed e2422406488314 ∧ code e2422406488314 = 11218499510522 := by decide
theorem cert_e2422406488314 : check e2422406488314 [[],[]] .chain = true := by decide
def e2422406488494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422406488494 : Closed e2422406488494 ∧ code e2422406488494 = 11218499510702 := by decide
theorem cert_e2422406488494 : check e2422406488494 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406488686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406488686 : Closed e2422406488686 ∧ code e2422406488686 = 11218499510894 := by decide
theorem cert_e2422406488686 : check e2422406488686 [[],[]] .chain = true := by decide
def e2422406488698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406488698 : Closed e2422406488698 ∧ code e2422406488698 = 11218499510906 := by decide
theorem cert_e2422406488698 : check e2422406488698 [[],[]] .chain = true := by decide
def e2422406488862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422406488862 : Closed e2422406488862 ∧ code e2422406488862 = 11218499511070 := by decide
theorem cert_e2422406488862 : check e2422406488862 [[],[]] .chain = true := by decide
def e2422406489030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2422406489030 : Closed e2422406489030 ∧ code e2422406489030 = 11218499511238 := by decide
theorem cert_e2422406489030 : check e2422406489030 [[],[]] .chain = true := by decide
def e2422406489646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406489646 : Closed e2422406489646 ∧ code e2422406489646 = 11218499511854 := by decide
theorem cert_e2422406489646 : check e2422406489646 [[],[]] .chain = true := by decide
def e2422406489826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406489826 : Closed e2422406489826 ∧ code e2422406489826 = 11218499512034 := by decide
theorem cert_e2422406489826 : check e2422406489826 [[],[]] .chain = true := by decide
def e2422406489838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422406489838 : Closed e2422406489838 ∧ code e2422406489838 = 11218499512046 := by decide
theorem cert_e2422406489838 : check e2422406489838 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406489966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422406489966 : Closed e2422406489966 ∧ code e2422406489966 = 11218499512174 := by decide
theorem cert_e2422406489966 : check e2422406489966 [[],[]] .chain = true := by decide
def e2422406489974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422406489974 : Closed e2422406489974 ∧ code e2422406489974 = 11218499512182 := by decide
theorem cert_e2422406489974 : check e2422406489974 [[],[]] .chain = true := by decide
def e2422406489994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406489994 : Closed e2422406489994 ∧ code e2422406489994 = 11218499512202 := by decide
theorem cert_e2422406489994 : check e2422406489994 [[],[]] .chain = true := by decide
def e2422406490018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406490018 : Closed e2422406490018 ∧ code e2422406490018 = 11218499512226 := by decide
theorem cert_e2422406490018 : check e2422406490018 [[],[]] .chain = true := by decide
def e2422406490030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422406490030 : Closed e2422406490030 ∧ code e2422406490030 = 11218499512238 := by decide
theorem cert_e2422406490030 : check e2422406490030 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406490038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422406490038 : Closed e2422406490038 ∧ code e2422406490038 = 11218499512246 := by decide
theorem cert_e2422406490038 : check e2422406490038 [[],[]] .chain = true := by decide
def e2422406490042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422406490042 : Closed e2422406490042 ∧ code e2422406490042 = 11218499512250 := by decide
theorem cert_e2422406490042 : check e2422406490042 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406490174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406490174 : Closed e2422406490174 ∧ code e2422406490174 = 11218499512382 := by decide
theorem cert_e2422406490174 : check e2422406490174 [[],[]] .chain = true := by decide
def e2422406490594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406490594 : Closed e2422406490594 ∧ code e2422406490594 = 11218499512802 := by decide
theorem cert_e2422406490594 : check e2422406490594 [[],[]] .chain = true := by decide
def e2422406490606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406490606 : Closed e2422406490606 ∧ code e2422406490606 = 11218499512814 := by decide
theorem cert_e2422406490606 : check e2422406490606 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406491374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406491374 : Closed e2422406491374 ∧ code e2422406491374 = 11218499513582 := by decide
theorem cert_e2422406491374 : check e2422406491374 [[],[]] .chain = true := by decide
def e2422406491382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406491382 : Closed e2422406491382 ∧ code e2422406491382 = 11218499513590 := by decide
theorem cert_e2422406491382 : check e2422406491382 [[],[]] .chain = true := by decide
def e2422406491650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406491650 : Closed e2422406491650 ∧ code e2422406491650 = 11218499513858 := by decide
theorem cert_e2422406491650 : check e2422406491650 [[],[]] .chain = true := by decide
def e2422406491662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406491662 : Closed e2422406491662 ∧ code e2422406491662 = 11218499513870 := by decide
theorem cert_e2422406491662 : check e2422406491662 [[],[]] .chain = true := by decide
def e2422406491674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406491674 : Closed e2422406491674 ∧ code e2422406491674 = 11218499513882 := by decide
theorem cert_e2422406491674 : check e2422406491674 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406491746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406491746 : Closed e2422406491746 ∧ code e2422406491746 = 11218499513954 := by decide
theorem cert_e2422406491746 : check e2422406491746 [[],[]] .chain = true := by decide
def e2422406491758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406491758 : Closed e2422406491758 ∧ code e2422406491758 = 11218499513966 := by decide
theorem cert_e2422406491758 : check e2422406491758 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406491766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406491766 : Closed e2422406491766 ∧ code e2422406491766 = 11218499513974 := by decide
theorem cert_e2422406491766 : check e2422406491766 [[],[]] .chain = true := by decide
def e2422406491770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406491770 : Closed e2422406491770 ∧ code e2422406491770 = 11218499513978 := by decide
theorem cert_e2422406491770 : check e2422406491770 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406492270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 1)))) (.var 2))))))
theorem wire_e2422406492270 : Closed e2422406492270 ∧ code e2422406492270 = 11218499514478 := by decide
theorem cert_e2422406492270 : check e2422406492270 [[],[]] .chain = true := by decide
def e2422406492446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 0))) (.lam (.var 3)))))))
theorem wire_e2422406492446 : Closed e2422406492446 ∧ code e2422406492446 = 11218499514654 := by decide
theorem cert_e2422406492446 : check e2422406492446 [[],[]] .chain = true := by decide
def e2422406492642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))) (.lam (.var 0)))))))
theorem wire_e2422406492642 : Closed e2422406492642 ∧ code e2422406492642 = 11218499514850 := by decide
theorem cert_e2422406492642 : check e2422406492642 [[],[]] .chain = true := by decide
def e2422406492654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3))) (.var 2))))))
theorem wire_e2422406492654 : Closed e2422406492654 ∧ code e2422406492654 = 11218499514862 := by decide
theorem cert_e2422406492654 : check e2422406492654 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406493038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406493038 : Closed e2422406493038 ∧ code e2422406493038 = 11218499515246 := by decide
theorem cert_e2422406493038 : check e2422406493038 [[],[]] .chain = true := by decide
def e2422406493046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406493046 : Closed e2422406493046 ∧ code e2422406493046 = 11218499515254 := by decide
theorem cert_e2422406493046 : check e2422406493046 [[],[]] .chain = true := by decide
def e2422406493102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406493102 : Closed e2422406493102 ∧ code e2422406493102 = 11218499515310 := by decide
theorem cert_e2422406493102 : check e2422406493102 [[],[]] .chain = true := by decide
def e2422406493114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406493114 : Closed e2422406493114 ∧ code e2422406493114 = 11218499515322 := by decide
theorem cert_e2422406493114 : check e2422406493114 [[],[]] .chain = true := by decide
def e2422406493142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406493142 : Closed e2422406493142 ∧ code e2422406493142 = 11218499515350 := by decide
theorem cert_e2422406493142 : check e2422406493142 [[],[]] .chain = true := by decide
def e2422406493146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406493146 : Closed e2422406493146 ∧ code e2422406493146 = 11218499515354 := by decide
theorem cert_e2422406493146 : check e2422406493146 [[],[]] .chain = true := by decide
def e2422406493422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406493422 : Closed e2422406493422 ∧ code e2422406493422 = 11218499515630 := by decide
theorem cert_e2422406493422 : check e2422406493422 [[],[]] .chain = true := by decide
def e2422406493430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406493430 : Closed e2422406493430 ∧ code e2422406493430 = 11218499515638 := by decide
theorem cert_e2422406493430 : check e2422406493430 [[],[]] .chain = true := by decide
def e2422406493806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406493806 : Closed e2422406493806 ∧ code e2422406493806 = 11218499516014 := by decide
theorem cert_e2422406493806 : check e2422406493806 [[],[]] .chain = true := by decide
def e2422406493818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406493818 : Closed e2422406493818 ∧ code e2422406493818 = 11218499516026 := by decide
theorem cert_e2422406493818 : check e2422406493818 [[],[]] .chain = true := by decide
def e2422406493958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406493958 : Closed e2422406493958 ∧ code e2422406493958 = 11218499516166 := by decide
theorem cert_e2422406493958 : check e2422406493958 [[],[]] .chain = true := by decide
def e2422406493982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.lam (.var 3)))))))
theorem wire_e2422406493982 : Closed e2422406493982 ∧ code e2422406493982 = 11218499516190 := by decide
theorem cert_e2422406493982 : check e2422406493982 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406494006 : Closed e2422406494006 ∧ code e2422406494006 = 11218499516214 := by decide
theorem cert_e2422406494006 : check e2422406494006 [[],[]] .chain = true := by decide
def e2422406494010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406494010 : Closed e2422406494010 ∧ code e2422406494010 = 11218499516218 := by decide
theorem cert_e2422406494010 : check e2422406494010 [[],[]] .chain = true := by decide
def e2422406494218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 0))))))
theorem wire_e2422406494218 : Closed e2422406494218 ∧ code e2422406494218 = 11218499516426 := by decide
theorem cert_e2422406494218 : check e2422406494218 [[],[]] .chain = true := by decide
def e2422406494254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406494254 : Closed e2422406494254 ∧ code e2422406494254 = 11218499516462 := by decide
theorem cert_e2422406494254 : check e2422406494254 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422406494262 : Closed e2422406494262 ∧ code e2422406494262 = 11218499516470 := by decide
theorem cert_e2422406494262 : check e2422406494262 [[],[]] .chain = true := by decide
def e2422406494266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422406494266 : Closed e2422406494266 ∧ code e2422406494266 = 11218499516474 := by decide
theorem cert_e2422406494266 : check e2422406494266 [[],[]] .chain = true := by decide
def e2422406494314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2422406494314 : Closed e2422406494314 ∧ code e2422406494314 = 11218499516522 := by decide
theorem cert_e2422406494314 : check e2422406494314 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.lam (.var 2)))))))
theorem wire_e2422406494350 : Closed e2422406494350 ∧ code e2422406494350 = 11218499516558 := by decide
theorem cert_e2422406494350 : check e2422406494350 [[],[]] .chain = true := by decide
def e2422406494362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422406494362 : Closed e2422406494362 ∧ code e2422406494362 = 11218499516570 := by decide
theorem cert_e2422406494362 : check e2422406494362 [[],[]] .chain = true := by decide
def e2422406494406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 1))) (.lam (.var 1)))))))
theorem wire_e2422406494406 : Closed e2422406494406 ∧ code e2422406494406 = 11218499516614 := by decide
theorem cert_e2422406494406 : check e2422406494406 [[],[]] .chain = true := by decide
def e2422406494434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406494434 : Closed e2422406494434 ∧ code e2422406494434 = 11218499516642 := by decide
theorem cert_e2422406494434 : check e2422406494434 [[],[]] .chain = true := by decide
def e2422406494446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406494446 : Closed e2422406494446 ∧ code e2422406494446 = 11218499516654 := by decide
theorem cert_e2422406494446 : check e2422406494446 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406494454 : Closed e2422406494454 ∧ code e2422406494454 = 11218499516662 := by decide
theorem cert_e2422406494454 : check e2422406494454 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406494602 : Closed e2422406494602 ∧ code e2422406494602 = 11218499516810 := by decide
theorem cert_e2422406494602 : check e2422406494602 [[],[]] .chain = true := by decide
def e2422406494626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406494626 : Closed e2422406494626 ∧ code e2422406494626 = 11218499516834 := by decide
theorem cert_e2422406494626 : check e2422406494626 [[],[]] .chain = true := by decide
def e2422406494638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2422406494638 : Closed e2422406494638 ∧ code e2422406494638 = 11218499516846 := by decide
theorem cert_e2422406494638 : check e2422406494638 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422406494646 : Closed e2422406494646 ∧ code e2422406494646 = 11218499516854 := by decide
theorem cert_e2422406494646 : check e2422406494646 [[],[]] .chain = true := by decide
def e2422406494650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2422406494650 : Closed e2422406494650 ∧ code e2422406494650 = 11218499516858 := by decide
theorem cert_e2422406494650 : check e2422406494650 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422406494678 : Closed e2422406494678 ∧ code e2422406494678 = 11218499516886 := by decide
theorem cert_e2422406494678 : check e2422406494678 [[],[]] .chain = true := by decide
def e2422406494682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422406494682 : Closed e2422406494682 ∧ code e2422406494682 = 11218499516890 := by decide
theorem cert_e2422406494682 : check e2422406494682 [[],[]] .chain = true := by decide
def e2422406494698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2422406494698 : Closed e2422406494698 ∧ code e2422406494698 = 11218499516906 := by decide
theorem cert_e2422406494698 : check e2422406494698 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406494722 : Closed e2422406494722 ∧ code e2422406494722 = 11218499516930 := by decide
theorem cert_e2422406494722 : check e2422406494722 [[],[]] .chain = true := by decide
def e2422406494734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406494734 : Closed e2422406494734 ∧ code e2422406494734 = 11218499516942 := by decide
theorem cert_e2422406494734 : check e2422406494734 [[],[]] .chain = true := by decide
def e2422406494746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406494746 : Closed e2422406494746 ∧ code e2422406494746 = 11218499516954 := by decide
theorem cert_e2422406494746 : check e2422406494746 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406494818 : Closed e2422406494818 ∧ code e2422406494818 = 11218499517026 := by decide
theorem cert_e2422406494818 : check e2422406494818 [[],[]] .chain = true := by decide
def e2422406494830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406494830 : Closed e2422406494830 ∧ code e2422406494830 = 11218499517038 := by decide
theorem cert_e2422406494830 : check e2422406494830 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406494838 : Closed e2422406494838 ∧ code e2422406494838 = 11218499517046 := by decide
theorem cert_e2422406494838 : check e2422406494838 [[],[]] .chain = true := by decide
def e2422406494842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406494842 : Closed e2422406494842 ∧ code e2422406494842 = 11218499517050 := by decide
theorem cert_e2422406494842 : check e2422406494842 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406494982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.lam (.var 1))))))))
theorem wire_e2422406494982 : Closed e2422406494982 ∧ code e2422406494982 = 11218499517190 := by decide
theorem cert_e2422406494982 : check e2422406494982 [[],[]] .chain = true := by decide
def e2422406495006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406495006 : Closed e2422406495006 ∧ code e2422406495006 = 11218499517214 := by decide
theorem cert_e2422406495006 : check e2422406495006 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406495030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406495030 : Closed e2422406495030 ∧ code e2422406495030 = 11218499517238 := by decide
theorem cert_e2422406495030 : check e2422406495030 [[],[]] .chain = true := by decide
def e2422406495034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406495034 : Closed e2422406495034 ∧ code e2422406495034 = 11218499517242 := by decide
theorem cert_e2422406495034 : check e2422406495034 [[],[]] .chain = true := by decide
end Blc.Floor43
