import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2259520527898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520527898 : Closed e2259520527898 ∧ code e2259520527898 = 11055613550106 := by decide
private def t_e2259520527898 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520527898 : ¬ IsSelfInterpreter e2259520527898 :=
  wSource (t := t_e2259520527898) (replay_sound (ps := []) (t := e2259520527898) (by decide)) (by decide)
def e2259520536774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259520536774 : Closed e2259520536774 ∧ code e2259520536774 = 11055613558982 := by decide
theorem cert_e2259520536774 : check e2259520536774 [[]] .width = true := by decide
def e2259520544794 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259520544794 : Closed e2259520544794 ∧ code e2259520544794 = 11055613567002 := by decide
theorem cert_e2259520544794 : check e2259520544794 [[]] .width = true := by decide
def e2259520544886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259520544886 : Closed e2259520544886 ∧ code e2259520544886 = 11055613567094 := by decide
private def t_e2259520544886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2259520544886 : ¬ IsSelfInterpreter e2259520544886 :=
  wSource (t := t_e2259520544886) (replay_sound (ps := []) (t := e2259520544886) (by decide)) (by decide)
def e2259520545130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259520545130 : Closed e2259520545130 ∧ code e2259520545130 = 11055613567338 := by decide
private def t_e2259520545130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2259520545130 : ¬ IsSelfInterpreter e2259520545130 :=
  wSource (t := t_e2259520545130) (replay_sound (ps := []) (t := e2259520545130) (by decide)) (by decide)
def e2259520545178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259520545178 : Closed e2259520545178 ∧ code e2259520545178 = 11055613567386 := by decide
private def t_e2259520545178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2259520545178 : ¬ IsSelfInterpreter e2259520545178 :=
  wSource (t := t_e2259520545178) (replay_sound (ps := []) (t := e2259520545178) (by decide)) (by decide)
def e2259520549062 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520549062 : Closed e2259520549062 ∧ code e2259520549062 = 11055613571270 := by decide
theorem cert_e2259520549062 : check e2259520549062 [[]] .width = true := by decide
def e2259520556570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520556570 : Closed e2259520556570 ∧ code e2259520556570 = 11055613578778 := by decide
private def t_e2259520556570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520556570 : ¬ IsSelfInterpreter e2259520556570 :=
  wSource (t := t_e2259520556570) (replay_sound (ps := []) (t := e2259520556570) (by decide)) (by decide)
def e2259520565446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520565446 : Closed e2259520565446 ∧ code e2259520565446 = 11055613587654 := by decide
theorem cert_e2259520565446 : check e2259520565446 [[]] .width = true := by decide
def e2259520606406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520606406 : Closed e2259520606406 ∧ code e2259520606406 = 11055613628614 := by decide
theorem cert_e2259520606406 : check e2259520606406 [[]] .width = true := by decide
def e2259520613914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520613914 : Closed e2259520613914 ∧ code e2259520613914 = 11055613636122 := by decide
theorem cert_e2259520613914 : check e2259520613914 [[]] .width = true := by decide
def e2259520616986 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520616986 : Closed e2259520616986 ∧ code e2259520616986 = 11055613639194 := by decide
theorem cert_e2259520616986 : check e2259520616986 [[]] .width = true := by decide
def e2259520655558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520655558 : Closed e2259520655558 ∧ code e2259520655558 = 11055613677766 := by decide
theorem cert_e2259520655558 : check e2259520655558 [[]] .width = true := by decide
def e2259520658970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520658970 : Closed e2259520658970 ∧ code e2259520658970 = 11055613681178 := by decide
theorem cert_e2259520658970 : check e2259520658970 [[]] .width = true := by decide
def e2259520667846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259520667846 : Closed e2259520667846 ∧ code e2259520667846 = 11055613690054 := by decide
theorem cert_e2259520667846 : check e2259520667846 [[]] .width = true := by decide
def e2259520675866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259520675866 : Closed e2259520675866 ∧ code e2259520675866 = 11055613698074 := by decide
theorem cert_e2259520675866 : check e2259520675866 [[]] .width = true := by decide
def e2259520675958 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259520675958 : Closed e2259520675958 ∧ code e2259520675958 = 11055613698166 := by decide
theorem cert_e2259520675958 : check e2259520675958 [[]] .width = true := by decide
def e2259520676202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259520676202 : Closed e2259520676202 ∧ code e2259520676202 = 11055613698410 := by decide
theorem cert_e2259520676202 : check e2259520676202 [[]] .width = true := by decide
def e2259520676250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259520676250 : Closed e2259520676250 ∧ code e2259520676250 = 11055613698458 := by decide
theorem cert_e2259520676250 : check e2259520676250 [[]] .width = true := by decide
def e2259520680134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520680134 : Closed e2259520680134 ∧ code e2259520680134 = 11055613702342 := by decide
theorem cert_e2259520680134 : check e2259520680134 [[]] .width = true := by decide
def e2259520692250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259520692250 : Closed e2259520692250 ∧ code e2259520692250 = 11055613714458 := by decide
theorem cert_e2259520692250 : check e2259520692250 [[]] .width = true := by decide
def e2259520692342 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259520692342 : Closed e2259520692342 ∧ code e2259520692342 = 11055613714550 := by decide
theorem cert_e2259520692342 : check e2259520692342 [[]] .width = true := by decide
def e2259520692586 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259520692586 : Closed e2259520692586 ∧ code e2259520692586 = 11055613714794 := by decide
theorem cert_e2259520692586 : check e2259520692586 [[]] .width = true := by decide
def e2259520692634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259520692634 : Closed e2259520692634 ∧ code e2259520692634 = 11055613714842 := by decide
theorem cert_e2259520692634 : check e2259520692634 [[]] .width = true := by decide
def e2259520701978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520701978 : Closed e2259520701978 ∧ code e2259520701978 = 11055613724186 := by decide
theorem cert_e2259520701978 : check e2259520701978 [[]] .width = true := by decide
def e2259520704710 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520704710 : Closed e2259520704710 ∧ code e2259520704710 = 11055613726918 := by decide
theorem cert_e2259520704710 : check e2259520704710 [[]] .width = true := by decide
def e2259520730650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520730650 : Closed e2259520730650 ∧ code e2259520730650 = 11055613752858 := by decide
private def t_e2259520730650 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520730650 : ¬ IsSelfInterpreter e2259520730650 :=
  wSource (t := t_e2259520730650) (replay_sound (ps := []) (t := e2259520730650) (by decide)) (by decide)
def e2259520731674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520731674 : Closed e2259520731674 ∧ code e2259520731674 = 11055613753882 := by decide
private def t_e2259520731674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520731674 : ¬ IsSelfInterpreter e2259520731674 :=
  wSource (t := t_e2259520731674) (replay_sound (ps := []) (t := e2259520731674) (by decide)) (by decide)
def e2259520753178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520753178 : Closed e2259520753178 ∧ code e2259520753178 = 11055613775386 := by decide
private def t_e2259520753178 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520753178 : ¬ IsSelfInterpreter e2259520753178 :=
  wSource (t := t_e2259520753178) (replay_sound (ps := []) (t := e2259520753178) (by decide)) (by decide)
def e2259520762054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520762054 : Closed e2259520762054 ∧ code e2259520762054 = 11055613784262 := by decide
theorem cert_e2259520762054 : check e2259520762054 [[]] .width = true := by decide
def e2259520767514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259520767514 : Closed e2259520767514 ∧ code e2259520767514 = 11055613789722 := by decide
private def t_e2259520767514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259520767514 : ¬ IsSelfInterpreter e2259520767514 :=
  wSource (t := t_e2259520767514) (replay_sound (ps := []) (t := e2259520767514) (by decide)) (by decide)
def e2259520770246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259520770246 : Closed e2259520770246 ∧ code e2259520770246 = 11055613792454 := by decide
theorem cert_e2259520770246 : check e2259520770246 [[]] .width = true := by decide
def e2259522908358 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259522908358 : Closed e2259522908358 ∧ code e2259522908358 = 11055615930566 := by decide
theorem cert_e2259522908358 : check e2259522908358 [[]] .width = true := by decide
def e2259524481222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259524481222 : Closed e2259524481222 ∧ code e2259524481222 = 11055617503430 := by decide
theorem cert_e2259524481222 : check e2259524481222 [[]] .width = true := by decide
def e2259524497606 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259524497606 : Closed e2259524497606 ∧ code e2259524497606 = 11055617519814 := by decide
theorem cert_e2259524497606 : check e2259524497606 [[]] .width = true := by decide
def e2259525692954 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259525692954 : Closed e2259525692954 ∧ code e2259525692954 = 11055618715162 := by decide
theorem cert_e2259525692954 : check e2259525692954 [[]] .width = true := by decide
def e2259525795866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259525795866 : Closed e2259525795866 ∧ code e2259525795866 = 11055618818074 := by decide
theorem cert_e2259525795866 : check e2259525795866 [[]] .width = true := by decide
def e2259525795958 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259525795958 : Closed e2259525795958 ∧ code e2259525795958 = 11055618818166 := by decide
theorem cert_e2259525795958 : check e2259525795958 [[]] .width = true := by decide
def e2259525796202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259525796202 : Closed e2259525796202 ∧ code e2259525796202 = 11055618818410 := by decide
theorem cert_e2259525796202 : check e2259525796202 [[]] .width = true := by decide
def e2259525796250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259525796250 : Closed e2259525796250 ∧ code e2259525796250 = 11055618818458 := by decide
theorem cert_e2259525796250 : check e2259525796250 [[]] .width = true := by decide
def e2259525797258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259525797258 : Closed e2259525797258 ∧ code e2259525797258 = 11055618819466 := by decide
theorem cert_e2259525797258 : check e2259525797258 [[]] .width = true := by decide
def e2259525797282 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259525797282 : Closed e2259525797282 ∧ code e2259525797282 = 11055618819490 := by decide
theorem cert_e2259525797282 : check e2259525797282 [[]] .width = true := by decide
def e2259525797390 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259525797390 : Closed e2259525797390 ∧ code e2259525797390 = 11055618819598 := by decide
theorem cert_e2259525797390 : check e2259525797390 [[]] .width = true := by decide
def e2259525797402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259525797402 : Closed e2259525797402 ∧ code e2259525797402 = 11055618819610 := by decide
theorem cert_e2259525797402 : check e2259525797402 [[]] .width = true := by decide
def e2259525797474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259525797474 : Closed e2259525797474 ∧ code e2259525797474 = 11055618819682 := by decide
theorem cert_e2259525797474 : check e2259525797474 [[]] .width = true := by decide
def e2259525889562 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259525889562 : Closed e2259525889562 ∧ code e2259525889562 = 11055618911770 := by decide
theorem cert_e2259525889562 : check e2259525889562 [[]] .width = true := by decide
def e2259525891610 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259525891610 : Closed e2259525891610 ∧ code e2259525891610 = 11055618913818 := by decide
theorem cert_e2259525891610 : check e2259525891610 [[]] .width = true := by decide
def e2259525926938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259525926938 : Closed e2259525926938 ∧ code e2259525926938 = 11055618949146 := by decide
theorem cert_e2259525926938 : check e2259525926938 [[]] .width = true := by decide
def e2259525927030 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259525927030 : Closed e2259525927030 ∧ code e2259525927030 = 11055618949238 := by decide
theorem cert_e2259525927030 : check e2259525927030 [[]] .width = true := by decide
def e2259525927274 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259525927274 : Closed e2259525927274 ∧ code e2259525927274 = 11055618949482 := by decide
theorem cert_e2259525927274 : check e2259525927274 [[]] .width = true := by decide
def e2259525927322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259525927322 : Closed e2259525927322 ∧ code e2259525927322 = 11055618949530 := by decide
theorem cert_e2259525927322 : check e2259525927322 [[]] .width = true := by decide
def e2259525928330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259525928330 : Closed e2259525928330 ∧ code e2259525928330 = 11055618950538 := by decide
theorem cert_e2259525928330 : check e2259525928330 [[]] .width = true := by decide
def e2259525928354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259525928354 : Closed e2259525928354 ∧ code e2259525928354 = 11055618950562 := by decide
theorem cert_e2259525928354 : check e2259525928354 [[]] .width = true := by decide
def e2259525928462 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259525928462 : Closed e2259525928462 ∧ code e2259525928462 = 11055618950670 := by decide
theorem cert_e2259525928462 : check e2259525928462 [[]] .width = true := by decide
def e2259525928474 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259525928474 : Closed e2259525928474 ∧ code e2259525928474 = 11055618950682 := by decide
theorem cert_e2259525928474 : check e2259525928474 [[]] .width = true := by decide
def e2259525928546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259525928546 : Closed e2259525928546 ∧ code e2259525928546 = 11055618950754 := by decide
theorem cert_e2259525928546 : check e2259525928546 [[]] .width = true := by decide
def e2259529089222 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259529089222 : Closed e2259529089222 ∧ code e2259529089222 = 11055622111430 := by decide
theorem cert_e2259529089222 : check e2259529089222 [[]] .width = true := by decide
def e2259529154758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259529154758 : Closed e2259529154758 ∧ code e2259529154758 = 11055622176966 := by decide
theorem cert_e2259529154758 : check e2259529154758 [[]] .width = true := by decide
def e2259529330886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259529330886 : Closed e2259529330886 ∧ code e2259529330886 = 11055622353094 := by decide
theorem cert_e2259529330886 : check e2259529330886 [[]] .width = true := by decide
def e2259529362970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259529362970 : Closed e2259529362970 ∧ code e2259529362970 = 11055622385178 := by decide
theorem cert_e2259529362970 : check e2259529362970 [[]] .width = true := by decide
def e2259529613510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259529613510 : Closed e2259529613510 ∧ code e2259529613510 = 11055622635718 := by decide
theorem cert_e2259529613510 : check e2259529613510 [[]] .width = true := by decide
def e2259529687066 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259529687066 : Closed e2259529687066 ∧ code e2259529687066 = 11055622709274 := by decide
theorem cert_e2259529687066 : check e2259529687066 [[]] .width = true := by decide
def e2259529687158 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259529687158 : Closed e2259529687158 ∧ code e2259529687158 = 11055622709366 := by decide
theorem cert_e2259529687158 : check e2259529687158 [[]] .width = true := by decide
def e2259529687402 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259529687402 : Closed e2259529687402 ∧ code e2259529687402 = 11055622709610 := by decide
theorem cert_e2259529687402 : check e2259529687402 [[]] .width = true := by decide
def e2259529687450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259529687450 : Closed e2259529687450 ∧ code e2259529687450 = 11055622709658 := by decide
theorem cert_e2259529687450 : check e2259529687450 [[]] .width = true := by decide
def e2259529699526 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259529699526 : Closed e2259529699526 ∧ code e2259529699526 = 11055622721734 := by decide
theorem cert_e2259529699526 : check e2259529699526 [[]] .width = true := by decide
def e2259529702938 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259529702938 : Closed e2259529702938 ∧ code e2259529702938 = 11055622725146 := by decide
theorem cert_e2259529702938 : check e2259529702938 [[]] .width = true := by decide
def e2259529711814 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259529711814 : Closed e2259529711814 ∧ code e2259529711814 = 11055622734022 := by decide
theorem cert_e2259529711814 : check e2259529711814 [[]] .width = true := by decide
def e2259529719834 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259529719834 : Closed e2259529719834 ∧ code e2259529719834 = 11055622742042 := by decide
theorem cert_e2259529719834 : check e2259529719834 [[]] .width = true := by decide
def e2259529719926 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259529719926 : Closed e2259529719926 ∧ code e2259529719926 = 11055622742134 := by decide
theorem cert_e2259529719926 : check e2259529719926 [[]] .width = true := by decide
def e2259529720170 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259529720170 : Closed e2259529720170 ∧ code e2259529720170 = 11055622742378 := by decide
theorem cert_e2259529720170 : check e2259529720170 [[]] .width = true := by decide
def e2259529720218 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259529720218 : Closed e2259529720218 ∧ code e2259529720218 = 11055622742426 := by decide
theorem cert_e2259529720218 : check e2259529720218 [[]] .width = true := by decide
def e2259529724102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259529724102 : Closed e2259529724102 ∧ code e2259529724102 = 11055622746310 := by decide
theorem cert_e2259529724102 : check e2259529724102 [[]] .width = true := by decide
def e2259529806022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259529806022 : Closed e2259529806022 ∧ code e2259529806022 = 11055622828230 := by decide
theorem cert_e2259529806022 : check e2259529806022 [[]] .width = true := by decide
def e2259529821722 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259529821722 : Closed e2259529821722 ∧ code e2259529821722 = 11055622843930 := by decide
theorem cert_e2259529821722 : check e2259529821722 [[]] .width = true := by decide
def e2259529823770 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259529823770 : Closed e2259529823770 ∧ code e2259529823770 = 11055622845978 := by decide
theorem cert_e2259529823770 : check e2259529823770 [[]] .width = true := by decide
def e2259529941190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259529941190 : Closed e2259529941190 ∧ code e2259529941190 = 11055622963398 := by decide
theorem cert_e2259529941190 : check e2259529941190 [[]] .width = true := by decide
def e2259529961670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259529961670 : Closed e2259529961670 ∧ code e2259529961670 = 11055622983878 := by decide
theorem cert_e2259529961670 : check e2259529961670 [[]] .width = true := by decide
def e2259529965082 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259529965082 : Closed e2259529965082 ∧ code e2259529965082 = 11055622987290 := by decide
theorem cert_e2259529965082 : check e2259529965082 [[]] .width = true := by decide
def e2259529973958 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259529973958 : Closed e2259529973958 ∧ code e2259529973958 = 11055622996166 := by decide
theorem cert_e2259529973958 : check e2259529973958 [[]] .width = true := by decide
def e2259529981978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259529981978 : Closed e2259529981978 ∧ code e2259529981978 = 11055623004186 := by decide
theorem cert_e2259529981978 : check e2259529981978 [[]] .width = true := by decide
def e2259529982070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259529982070 : Closed e2259529982070 ∧ code e2259529982070 = 11055623004278 := by decide
theorem cert_e2259529982070 : check e2259529982070 [[]] .width = true := by decide
def e2259529982314 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259529982314 : Closed e2259529982314 ∧ code e2259529982314 = 11055623004522 := by decide
theorem cert_e2259529982314 : check e2259529982314 [[]] .width = true := by decide
def e2259529982362 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259529982362 : Closed e2259529982362 ∧ code e2259529982362 = 11055623004570 := by decide
theorem cert_e2259529982362 : check e2259529982362 [[]] .width = true := by decide
def e2259529986246 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259529986246 : Closed e2259529986246 ∧ code e2259529986246 = 11055623008454 := by decide
theorem cert_e2259529986246 : check e2259529986246 [[]] .width = true := by decide
def e2259529993754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259529993754 : Closed e2259529993754 ∧ code e2259529993754 = 11055623015962 := by decide
private def t_e2259529993754 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259529993754 : ¬ IsSelfInterpreter e2259529993754 :=
  wSource (t := t_e2259529993754) (replay_sound (ps := []) (t := e2259529993754) (by decide)) (by decide)
def e2259530002630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259530002630 : Closed e2259530002630 ∧ code e2259530002630 = 11055623024838 := by decide
theorem cert_e2259530002630 : check e2259530002630 [[]] .width = true := by decide
def e2259532234950 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259532234950 : Closed e2259532234950 ∧ code e2259532234950 = 11055625257158 := by decide
theorem cert_e2259532234950 : check e2259532234950 [[]] .width = true := by decide
def e2259532300486 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259532300486 : Closed e2259532300486 ∧ code e2259532300486 = 11055625322694 := by decide
theorem cert_e2259532300486 : check e2259532300486 [[]] .width = true := by decide
def e2259534970906 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259534970906 : Closed e2259534970906 ∧ code e2259534970906 = 11055627993114 := by decide
theorem cert_e2259534970906 : check e2259534970906 [[]] .width = true := by decide
def e2259534970998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259534970998 : Closed e2259534970998 ∧ code e2259534970998 = 11055627993206 := by decide
theorem cert_e2259534970998 : check e2259534970998 [[]] .width = true := by decide
def e2259534971242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259534971242 : Closed e2259534971242 ∧ code e2259534971242 = 11055627993450 := by decide
theorem cert_e2259534971242 : check e2259534971242 [[]] .width = true := by decide
def e2259534971290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259534971290 : Closed e2259534971290 ∧ code e2259534971290 = 11055627993498 := by decide
theorem cert_e2259534971290 : check e2259534971290 [[]] .width = true := by decide
def e2259534972298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259534972298 : Closed e2259534972298 ∧ code e2259534972298 = 11055627994506 := by decide
theorem cert_e2259534972298 : check e2259534972298 [[]] .width = true := by decide
def e2259534972322 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259534972322 : Closed e2259534972322 ∧ code e2259534972322 = 11055627994530 := by decide
theorem cert_e2259534972322 : check e2259534972322 [[]] .width = true := by decide
def e2259534972430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259534972430 : Closed e2259534972430 ∧ code e2259534972430 = 11055627994638 := by decide
theorem cert_e2259534972430 : check e2259534972430 [[]] .width = true := by decide
def e2259534972442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259534972442 : Closed e2259534972442 ∧ code e2259534972442 = 11055627994650 := by decide
theorem cert_e2259534972442 : check e2259534972442 [[]] .width = true := by decide
def e2259534972514 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259534972514 : Closed e2259534972514 ∧ code e2259534972514 = 11055627994722 := by decide
theorem cert_e2259534972514 : check e2259534972514 [[]] .width = true := by decide
def e2259535380678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259535380678 : Closed e2259535380678 ∧ code e2259535380678 = 11055628402886 := by decide
theorem cert_e2259535380678 : check e2259535380678 [[]] .width = true := by decide
def e2259535454234 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259535454234 : Closed e2259535454234 ∧ code e2259535454234 = 11055628476442 := by decide
theorem cert_e2259535454234 : check e2259535454234 [[]] .width = true := by decide
def e2259535454326 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259535454326 : Closed e2259535454326 ∧ code e2259535454326 = 11055628476534 := by decide
theorem cert_e2259535454326 : check e2259535454326 [[]] .width = true := by decide
def e2259535454570 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259535454570 : Closed e2259535454570 ∧ code e2259535454570 = 11055628476778 := by decide
theorem cert_e2259535454570 : check e2259535454570 [[]] .width = true := by decide
def e2259535454618 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259535454618 : Closed e2259535454618 ∧ code e2259535454618 = 11055628476826 := by decide
theorem cert_e2259535454618 : check e2259535454618 [[]] .width = true := by decide
def e2259535466694 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259535466694 : Closed e2259535466694 ∧ code e2259535466694 = 11055628488902 := by decide
theorem cert_e2259535466694 : check e2259535466694 [[]] .width = true := by decide
def e2259535470106 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259535470106 : Closed e2259535470106 ∧ code e2259535470106 = 11055628492314 := by decide
theorem cert_e2259535470106 : check e2259535470106 [[]] .width = true := by decide
def e2259535478982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259535478982 : Closed e2259535478982 ∧ code e2259535478982 = 11055628501190 := by decide
theorem cert_e2259535478982 : check e2259535478982 [[]] .width = true := by decide
def e2259535487002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259535487002 : Closed e2259535487002 ∧ code e2259535487002 = 11055628509210 := by decide
theorem cert_e2259535487002 : check e2259535487002 [[]] .width = true := by decide
def e2259535487094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259535487094 : Closed e2259535487094 ∧ code e2259535487094 = 11055628509302 := by decide
theorem cert_e2259535487094 : check e2259535487094 [[]] .width = true := by decide
def e2259535487338 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259535487338 : Closed e2259535487338 ∧ code e2259535487338 = 11055628509546 := by decide
theorem cert_e2259535487338 : check e2259535487338 [[]] .width = true := by decide
def e2259535487386 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259535487386 : Closed e2259535487386 ∧ code e2259535487386 = 11055628509594 := by decide
theorem cert_e2259535487386 : check e2259535487386 [[]] .width = true := by decide
def e2259535491270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259535491270 : Closed e2259535491270 ∧ code e2259535491270 = 11055628513478 := by decide
theorem cert_e2259535491270 : check e2259535491270 [[]] .width = true := by decide
def e2259536314566 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259536314566 : Closed e2259536314566 ∧ code e2259536314566 = 11055629336774 := by decide
theorem cert_e2259536314566 : check e2259536314566 [[]] .width = true := by decide
def e2259536315094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259536315094 : Closed e2259536315094 ∧ code e2259536315094 = 11055629337302 := by decide
theorem cert_e2259536315094 : check e2259536315094 [[]] .width = true := by decide
def e2259536315098 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259536315098 : Closed e2259536315098 ∧ code e2259536315098 = 11055629337306 := by decide
theorem cert_e2259536315098 : check e2259536315098 [[]] .width = true := by decide
def e2259536315114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259536315114 : Closed e2259536315114 ∧ code e2259536315114 = 11055629337322 := by decide
theorem cert_e2259536315114 : check e2259536315114 [[]] .width = true := by decide
def e2259536315190 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))
theorem wire_e2259536315190 : Closed e2259536315190 ∧ code e2259536315190 = 11055629337398 := by decide
theorem cert_e2259536315190 : check e2259536315190 [[]] .width = true := by decide
def e2259536315194 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))
theorem wire_e2259536315194 : Closed e2259536315194 ∧ code e2259536315194 = 11055629337402 := by decide
theorem cert_e2259536315194 : check e2259536315194 [[]] .width = true := by decide
def e2259536315278 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.var 2)))))))
theorem wire_e2259536315278 : Closed e2259536315278 ∧ code e2259536315278 = 11055629337486 := by decide
theorem cert_e2259536315278 : check e2259536315278 [[]] .width = true := by decide
def e2259536315290 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))
theorem wire_e2259536315290 : Closed e2259536315290 ∧ code e2259536315290 = 11055629337498 := by decide
theorem cert_e2259536315290 : check e2259536315290 [[]] .width = true := by decide
def e2259536317210 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))
theorem wire_e2259536317210 : Closed e2259536317210 ∧ code e2259536317210 = 11055629339418 := by decide
theorem cert_e2259536317210 : check e2259536317210 [[]] .width = true := by decide
def e2259536317254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))
theorem wire_e2259536317254 : Closed e2259536317254 ∧ code e2259536317254 = 11055629339462 := by decide
theorem cert_e2259536317254 : check e2259536317254 [[]] .width = true := by decide
def e2259536317366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.app (.var 1) (.var 1)) (.var 1)))))
theorem wire_e2259536317366 : Closed e2259536317366 ∧ code e2259536317366 = 11055629339574 := by decide
theorem cert_e2259536317366 : check e2259536317366 [[]] .width = true := by decide
def e2259536317494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1)))))))
theorem wire_e2259536317494 : Closed e2259536317494 ∧ code e2259536317494 = 11055629339702 := by decide
theorem cert_e2259536317494 : check e2259536317494 [[]] .width = true := by decide
def e2259536317498 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0)))))))
theorem wire_e2259536317498 : Closed e2259536317498 ∧ code e2259536317498 = 11055629339706 := by decide
theorem cert_e2259536317498 : check e2259536317498 [[]] .width = true := by decide
def e2259536317638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259536317638 : Closed e2259536317638 ∧ code e2259536317638 = 11055629339846 := by decide
theorem cert_e2259536317638 : check e2259536317638 [[]] .width = true := by decide
def e2259536317978 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259536317978 : Closed e2259536317978 ∧ code e2259536317978 = 11055629340186 := by decide
theorem cert_e2259536317978 : check e2259536317978 [[]] .width = true := by decide
def e2259536318070 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.lam (.app (.var 1) (.app (.var 1) (.var 1))))))
theorem wire_e2259536318070 : Closed e2259536318070 ∧ code e2259536318070 = 11055629340278 := by decide
theorem cert_e2259536318070 : check e2259536318070 [[]] .width = true := by decide
def e2259536325658 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 0))))
theorem wire_e2259536325658 : Closed e2259536325658 ∧ code e2259536325658 = 11055629347866 := by decide
theorem cert_e2259536325658 : check e2259536325658 [[]] .width = true := by decide
def e2259536325702 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.lam (.var 1)))))
theorem wire_e2259536325702 : Closed e2259536325702 ∧ code e2259536325702 = 11055629347910 := by decide
theorem cert_e2259536325702 : check e2259536325702 [[]] .width = true := by decide
def e2259536325730 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 0)))))
theorem wire_e2259536325730 : Closed e2259536325730 ∧ code e2259536325730 = 11055629347938 := by decide
theorem cert_e2259536325730 : check e2259536325730 [[]] .width = true := by decide
def e2259536325894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 1))))))
theorem wire_e2259536325894 : Closed e2259536325894 ∧ code e2259536325894 = 11055629348102 := by decide
theorem cert_e2259536325894 : check e2259536325894 [[]] .width = true := by decide
def e2259536326686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))))
theorem wire_e2259536326686 : Closed e2259536326686 ∧ code e2259536326686 = 11055629348894 := by decide
theorem cert_e2259536326686 : check e2259536326686 [[]] .width = true := by decide
def e2259536326854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2259536326854 : Closed e2259536326854 ∧ code e2259536326854 = 11055629349062 := by decide
theorem cert_e2259536326854 : check e2259536326854 [[]] .width = true := by decide
def e2259536326882 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 0)))))))
theorem wire_e2259536326882 : Closed e2259536326882 ∧ code e2259536326882 = 11055629349090 := by decide
theorem cert_e2259536326882 : check e2259536326882 [[]] .width = true := by decide
def e2259536327430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 1)))))))
theorem wire_e2259536327430 : Closed e2259536327430 ∧ code e2259536327430 = 11055629349638 := by decide
theorem cert_e2259536327430 : check e2259536327430 [[]] .width = true := by decide
def e2259536638150 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259536638150 : Closed e2259536638150 ∧ code e2259536638150 = 11055629660358 := by decide
theorem cert_e2259536638150 : check e2259536638150 [[]] .width = true := by decide
def e2259536805914 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2259536805914 : Closed e2259536805914 ∧ code e2259536805914 = 11055629828122 := by decide
theorem cert_e2259536805914 : check e2259536805914 [[]] .width = true := by decide
def e2259536806006 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2259536806006 : Closed e2259536806006 ∧ code e2259536806006 = 11055629828214 := by decide
theorem cert_e2259536806006 : check e2259536806006 [[]] .width = true := by decide
def e2259536806250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2259536806250 : Closed e2259536806250 ∧ code e2259536806250 = 11055629828458 := by decide
theorem cert_e2259536806250 : check e2259536806250 [[]] .width = true := by decide
def e2259536806298 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2259536806298 : Closed e2259536806298 ∧ code e2259536806298 = 11055629828506 := by decide
theorem cert_e2259536806298 : check e2259536806298 [[]] .width = true := by decide
def e2259536807306 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2259536807306 : Closed e2259536807306 ∧ code e2259536807306 = 11055629829514 := by decide
theorem cert_e2259536807306 : check e2259536807306 [[]] .width = true := by decide
def e2259536807330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2259536807330 : Closed e2259536807330 ∧ code e2259536807330 = 11055629829538 := by decide
private def t_e2259536807330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2259536807330 : ¬ IsSelfInterpreter e2259536807330 :=
  wSource (t := t_e2259536807330) (replay_sound (ps := []) (t := e2259536807330) (by decide)) (by decide)
def e2259536807438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2259536807438 : Closed e2259536807438 ∧ code e2259536807438 = 11055629829646 := by decide
theorem cert_e2259536807438 : check e2259536807438 [[]] .width = true := by decide
def e2259536807450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259536807450 : Closed e2259536807450 ∧ code e2259536807450 = 11055629829658 := by decide
private def t_e2259536807450 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2259536807450 : ¬ IsSelfInterpreter e2259536807450 :=
  wSource (t := t_e2259536807450) (replay_sound (ps := []) (t := e2259536807450) (by decide)) (by decide)
def e2259536807522 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2259536807522 : Closed e2259536807522 ∧ code e2259536807522 = 11055629829730 := by decide
theorem cert_e2259536807522 : check e2259536807522 [[]] .width = true := by decide
def e2259537019078 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259537019078 : Closed e2259537019078 ∧ code e2259537019078 = 11055630041286 := by decide
theorem cert_e2259537019078 : check e2259537019078 [[]] .width = true := by decide
def e2259537039558 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259537039558 : Closed e2259537039558 ∧ code e2259537039558 = 11055630061766 := by decide
theorem cert_e2259537039558 : check e2259537039558 [[]] .width = true := by decide
def e2259537042970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259537042970 : Closed e2259537042970 ∧ code e2259537042970 = 11055630065178 := by decide
private def t_e2259537042970 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259537042970 : ¬ IsSelfInterpreter e2259537042970 :=
  wSource (t := t_e2259537042970) (replay_sound (ps := []) (t := e2259537042970) (by decide)) (by decide)
def e2259537051846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2259537051846 : Closed e2259537051846 ∧ code e2259537051846 = 11055630074054 := by decide
theorem cert_e2259537051846 : check e2259537051846 [[]] .width = true := by decide
def e2259537059866 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2259537059866 : Closed e2259537059866 ∧ code e2259537059866 = 11055630082074 := by decide
theorem cert_e2259537059866 : check e2259537059866 [[]] .width = true := by decide
def e2259537059958 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2259537059958 : Closed e2259537059958 ∧ code e2259537059958 = 11055630082166 := by decide
private def t_e2259537059958 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2259537059958 : ¬ IsSelfInterpreter e2259537059958 :=
  wSource (t := t_e2259537059958) (replay_sound (ps := []) (t := e2259537059958) (by decide)) (by decide)
def e2259537060202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2259537060202 : Closed e2259537060202 ∧ code e2259537060202 = 11055630082410 := by decide
private def t_e2259537060202 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2259537060202 : ¬ IsSelfInterpreter e2259537060202 :=
  wSource (t := t_e2259537060202) (replay_sound (ps := []) (t := e2259537060202) (by decide)) (by decide)
def e2259537060250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2259537060250 : Closed e2259537060250 ∧ code e2259537060250 = 11055630082458 := by decide
private def t_e2259537060250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2259537060250 : ¬ IsSelfInterpreter e2259537060250 :=
  wSource (t := t_e2259537060250) (replay_sound (ps := []) (t := e2259537060250) (by decide)) (by decide)
def e2259537064134 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259537064134 : Closed e2259537064134 ∧ code e2259537064134 = 11055630086342 := by decide
theorem cert_e2259537064134 : check e2259537064134 [[]] .width = true := by decide
def e2259537071642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2259537071642 : Closed e2259537071642 ∧ code e2259537071642 = 11055630093850 := by decide
private def t_e2259537071642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2259537071642 : ¬ IsSelfInterpreter e2259537071642 :=
  wSource (t := t_e2259537071642) (replay_sound (ps := []) (t := e2259537071642) (by decide)) (by decide)
def e2259537080518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2259537080518 : Closed e2259537080518 ∧ code e2259537080518 = 11055630102726 := by decide
theorem cert_e2259537080518 : check e2259537080518 [[]] .width = true := by decide
def e2259537363142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2259537363142 : Closed e2259537363142 ∧ code e2259537363142 = 11055630385350 := by decide
theorem cert_e2259537363142 : check e2259537363142 [[]] .width = true := by decide
def e2259537363670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))
theorem wire_e2259537363670 : Closed e2259537363670 ∧ code e2259537363670 = 11055630385878 := by decide
theorem cert_e2259537363670 : check e2259537363670 [[]] .width = true := by decide
def e2259537363674 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))
theorem wire_e2259537363674 : Closed e2259537363674 ∧ code e2259537363674 = 11055630385882 := by decide
theorem cert_e2259537363674 : check e2259537363674 [[]] .width = true := by decide
def e2259537363690 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))
theorem wire_e2259537363690 : Closed e2259537363690 ∧ code e2259537363690 = 11055630385898 := by decide
theorem cert_e2259537363690 : check e2259537363690 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2259520527898
#print axioms Blc.Floor43.cert_e2259520544886
#print axioms Blc.Floor43.cert_e2259520545130
#print axioms Blc.Floor43.cert_e2259520545178
#print axioms Blc.Floor43.cert_e2259520556570
#print axioms Blc.Floor43.cert_e2259520730650
#print axioms Blc.Floor43.cert_e2259520731674
#print axioms Blc.Floor43.cert_e2259520753178
#print axioms Blc.Floor43.cert_e2259520767514
#print axioms Blc.Floor43.cert_e2259529993754
#print axioms Blc.Floor43.cert_e2259536807330
#print axioms Blc.Floor43.cert_e2259536807450
#print axioms Blc.Floor43.cert_e2259537042970
#print axioms Blc.Floor43.cert_e2259537059958
#print axioms Blc.Floor43.cert_e2259537060202
#print axioms Blc.Floor43.cert_e2259537060250
#print axioms Blc.Floor43.cert_e2259537071642
