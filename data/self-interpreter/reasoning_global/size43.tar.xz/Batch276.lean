import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2407061507690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0))))))
theorem wire_e2407061507690 : Closed e2407061507690 ∧ code e2407061507690 = 11203154529898 := by decide
theorem cert_e2407061507690 : check e2407061507690 [[],[]] .chain = true := by decide
def e2407061507726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2407061507726 : Closed e2407061507726 ∧ code e2407061507726 = 11203154529934 := by decide
theorem cert_e2407061507726 : check e2407061507726 [[],[]] .chain = true := by decide
def e2407061507738 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 0)))))))
theorem wire_e2407061507738 : Closed e2407061507738 ∧ code e2407061507738 = 11203154529946 := by decide
theorem cert_e2407061507738 : check e2407061507738 [[],[]] .chain = true := by decide
def e2407061507782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2407061507782 : Closed e2407061507782 ∧ code e2407061507782 = 11203154529990 := by decide
theorem cert_e2407061507782 : check e2407061507782 [[],[]] .chain = true := by decide
def e2407061508334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2407061508334 : Closed e2407061508334 ∧ code e2407061508334 = 11203154530542 := by decide
theorem cert_e2407061508334 : check e2407061508334 [[],[]] .chain = true := by decide
def e2407061508342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2407061508342 : Closed e2407061508342 ∧ code e2407061508342 = 11203154530550 := by decide
theorem cert_e2407061508342 : check e2407061508342 [[],[]] .chain = true := by decide
def e2407061508822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2407061508822 : Closed e2407061508822 ∧ code e2407061508822 = 11203154531030 := by decide
theorem cert_e2407061508822 : check e2407061508822 [[],[]] .chain = true := by decide
def e2407061508826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2407061508826 : Closed e2407061508826 ∧ code e2407061508826 = 11203154531034 := by decide
theorem cert_e2407061508826 : check e2407061508826 [[],[]] .chain = true := by decide
def e2407061508842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2407061508842 : Closed e2407061508842 ∧ code e2407061508842 = 11203154531050 := by decide
theorem cert_e2407061508842 : check e2407061508842 [[],[]] .chain = true := by decide
def e2407061508918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2407061508918 : Closed e2407061508918 ∧ code e2407061508918 = 11203154531126 := by decide
theorem cert_e2407061508918 : check e2407061508918 [[],[]] .chain = true := by decide
def e2407061508922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2407061508922 : Closed e2407061508922 ∧ code e2407061508922 = 11203154531130 := by decide
theorem cert_e2407061508922 : check e2407061508922 [[],[]] .chain = true := by decide
def e2407061509006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 2))))))))
theorem wire_e2407061509006 : Closed e2407061509006 ∧ code e2407061509006 = 11203154531214 := by decide
theorem cert_e2407061509006 : check e2407061509006 [[],[]] .chain = true := by decide
def e2407061509018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061509018 : Closed e2407061509018 ∧ code e2407061509018 = 11203154531226 := by decide
theorem cert_e2407061509018 : check e2407061509018 [[],[]] .chain = true := by decide
def e2407061510262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2407061510262 : Closed e2407061510262 ∧ code e2407061510262 = 11203154532470 := by decide
theorem cert_e2407061510262 : check e2407061510262 [[],[]] .chain = true := by decide
def e2407061510506 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2407061510506 : Closed e2407061510506 ∧ code e2407061510506 = 11203154532714 := by decide
theorem cert_e2407061510506 : check e2407061510506 [[],[]] .chain = true := by decide
def e2407061510542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2407061510542 : Closed e2407061510542 ∧ code e2407061510542 = 11203154532750 := by decide
theorem cert_e2407061510542 : check e2407061510542 [[],[]] .chain = true := by decide
def e2407061510554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061510554 : Closed e2407061510554 ∧ code e2407061510554 = 11203154532762 := by decide
theorem cert_e2407061510554 : check e2407061510554 [[],[]] .chain = true := by decide
def e2407061510598 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2407061510598 : Closed e2407061510598 ∧ code e2407061510598 = 11203154532806 := by decide
theorem cert_e2407061510598 : check e2407061510598 [[],[]] .chain = true := by decide
def e2407061523310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2407061523310 : Closed e2407061523310 ∧ code e2407061523310 = 11203154545518 := by decide
theorem cert_e2407061523310 : check e2407061523310 [[],[]] .smaller = true := by decide
def e2407061523318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2407061523318 : Closed e2407061523318 ∧ code e2407061523318 = 11203154545526 := by decide
theorem cert_e2407061523318 : check e2407061523318 [[],[]] .smaller = true := by decide
def e2407061523374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2407061523374 : Closed e2407061523374 ∧ code e2407061523374 = 11203154545582 := by decide
theorem cert_e2407061523374 : check e2407061523374 [[],[]] .smaller = true := by decide
def e2407061523386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2407061523386 : Closed e2407061523386 ∧ code e2407061523386 = 11203154545594 := by decide
theorem cert_e2407061523386 : check e2407061523386 [[],[]] .smaller = true := by decide
def e2407061523414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2407061523414 : Closed e2407061523414 ∧ code e2407061523414 = 11203154545622 := by decide
theorem cert_e2407061523414 : check e2407061523414 [[],[]] .smaller = true := by decide
def e2407061523418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2407061523418 : Closed e2407061523418 ∧ code e2407061523418 = 11203154545626 := by decide
theorem cert_e2407061523418 : check e2407061523418 [[],[]] .smaller = true := by decide
def e2407061523694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2407061523694 : Closed e2407061523694 ∧ code e2407061523694 = 11203154545902 := by decide
theorem cert_e2407061523694 : check e2407061523694 [[],[]] .smaller = true := by decide
def e2407061523702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2407061523702 : Closed e2407061523702 ∧ code e2407061523702 = 11203154545910 := by decide
theorem cert_e2407061523702 : check e2407061523702 [[],[]] .smaller = true := by decide
def e2407061524078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2407061524078 : Closed e2407061524078 ∧ code e2407061524078 = 11203154546286 := by decide
theorem cert_e2407061524078 : check e2407061524078 [[],[]] .smaller = true := by decide
def e2407061524090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2407061524090 : Closed e2407061524090 ∧ code e2407061524090 = 11203154546298 := by decide
theorem cert_e2407061524090 : check e2407061524090 [[],[]] .smaller = true := by decide
def e2407061524278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2407061524278 : Closed e2407061524278 ∧ code e2407061524278 = 11203154546486 := by decide
theorem cert_e2407061524278 : check e2407061524278 [[],[]] .smaller = true := by decide
def e2407061524282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2407061524282 : Closed e2407061524282 ∧ code e2407061524282 = 11203154546490 := by decide
theorem cert_e2407061524282 : check e2407061524282 [[],[]] .smaller = true := by decide
def e2407061564782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2407061564782 : Closed e2407061564782 ∧ code e2407061564782 = 11203154586990 := by decide
theorem cert_e2407061564782 : check e2407061564782 [[],[]] .chain = true := by decide
def e2407061564790 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2407061564790 : Closed e2407061564790 ∧ code e2407061564790 = 11203154586998 := by decide
theorem cert_e2407061564790 : check e2407061564790 [[],[]] .chain = true := by decide
def e2407061564846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2407061564846 : Closed e2407061564846 ∧ code e2407061564846 = 11203154587054 := by decide
theorem cert_e2407061564846 : check e2407061564846 [[],[]] .chain = true := by decide
def e2407061564858 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2407061564858 : Closed e2407061564858 ∧ code e2407061564858 = 11203154587066 := by decide
theorem cert_e2407061564858 : check e2407061564858 [[],[]] .chain = true := by decide
def e2407061564886 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2407061564886 : Closed e2407061564886 ∧ code e2407061564886 = 11203154587094 := by decide
theorem cert_e2407061564886 : check e2407061564886 [[],[]] .chain = true := by decide
def e2407061564890 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2407061564890 : Closed e2407061564890 ∧ code e2407061564890 = 11203154587098 := by decide
theorem cert_e2407061564890 : check e2407061564890 [[],[]] .chain = true := by decide
def e2407061565102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2407061565102 : Closed e2407061565102 ∧ code e2407061565102 = 11203154587310 := by decide
theorem cert_e2407061565102 : check e2407061565102 [[],[]] .chain = true := by decide
def e2407061565114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2407061565114 : Closed e2407061565114 ∧ code e2407061565114 = 11203154587322 := by decide
theorem cert_e2407061565114 : check e2407061565114 [[],[]] .chain = true := by decide
def e2407061565162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2407061565162 : Closed e2407061565162 ∧ code e2407061565162 = 11203154587370 := by decide
theorem cert_e2407061565162 : check e2407061565162 [[],[]] .chain = true := by decide
def e2407061565270 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2407061565270 : Closed e2407061565270 ∧ code e2407061565270 = 11203154587478 := by decide
theorem cert_e2407061565270 : check e2407061565270 [[],[]] .chain = true := by decide
def e2407061565274 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2407061565274 : Closed e2407061565274 ∧ code e2407061565274 = 11203154587482 := by decide
theorem cert_e2407061565274 : check e2407061565274 [[],[]] .chain = true := by decide
def e2407061565290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2407061565290 : Closed e2407061565290 ∧ code e2407061565290 = 11203154587498 := by decide
theorem cert_e2407061565290 : check e2407061565290 [[],[]] .chain = true := by decide
def e2407061566318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2407061566318 : Closed e2407061566318 ∧ code e2407061566318 = 11203154588526 := by decide
theorem cert_e2407061566318 : check e2407061566318 [[],[]] .chain = true := by decide
def e2407061566326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2407061566326 : Closed e2407061566326 ∧ code e2407061566326 = 11203154588534 := by decide
theorem cert_e2407061566326 : check e2407061566326 [[],[]] .chain = true := by decide
def e2407061566382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2407061566382 : Closed e2407061566382 ∧ code e2407061566382 = 11203154588590 := by decide
theorem cert_e2407061566382 : check e2407061566382 [[],[]] .chain = true := by decide
def e2407061566394 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2407061566394 : Closed e2407061566394 ∧ code e2407061566394 = 11203154588602 := by decide
theorem cert_e2407061566394 : check e2407061566394 [[],[]] .chain = true := by decide
def e2407061566422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2407061566422 : Closed e2407061566422 ∧ code e2407061566422 = 11203154588630 := by decide
theorem cert_e2407061566422 : check e2407061566422 [[],[]] .chain = true := by decide
def e2407061566426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2407061566426 : Closed e2407061566426 ∧ code e2407061566426 = 11203154588634 := by decide
theorem cert_e2407061566426 : check e2407061566426 [[],[]] .chain = true := by decide
def e2407061566702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2407061566702 : Closed e2407061566702 ∧ code e2407061566702 = 11203154588910 := by decide
theorem cert_e2407061566702 : check e2407061566702 [[],[]] .chain = true := by decide
def e2407061566710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2407061566710 : Closed e2407061566710 ∧ code e2407061566710 = 11203154588918 := by decide
theorem cert_e2407061566710 : check e2407061566710 [[],[]] .chain = true := by decide
def e2407061567086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407061567086 : Closed e2407061567086 ∧ code e2407061567086 = 11203154589294 := by decide
theorem cert_e2407061567086 : check e2407061567086 [[],[]] .chain = true := by decide
def e2407061567098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407061567098 : Closed e2407061567098 ∧ code e2407061567098 = 11203154589306 := by decide
theorem cert_e2407061567098 : check e2407061567098 [[],[]] .chain = true := by decide
def e2407061567286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407061567286 : Closed e2407061567286 ∧ code e2407061567286 = 11203154589494 := by decide
theorem cert_e2407061567286 : check e2407061567286 [[],[]] .chain = true := by decide
def e2407061567290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407061567290 : Closed e2407061567290 ∧ code e2407061567290 = 11203154589498 := by decide
theorem cert_e2407061567290 : check e2407061567290 [[],[]] .chain = true := by decide
def e2407061567726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2407061567726 : Closed e2407061567726 ∧ code e2407061567726 = 11203154589934 := by decide
theorem cert_e2407061567726 : check e2407061567726 [[],[]] .chain = true := by decide
def e2407061567734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2407061567734 : Closed e2407061567734 ∧ code e2407061567734 = 11203154589942 := by decide
theorem cert_e2407061567734 : check e2407061567734 [[],[]] .chain = true := by decide
def e2407061567918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2407061567918 : Closed e2407061567918 ∧ code e2407061567918 = 11203154590126 := by decide
theorem cert_e2407061567918 : check e2407061567918 [[],[]] .chain = true := by decide
def e2407061567930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2407061567930 : Closed e2407061567930 ∧ code e2407061567930 = 11203154590138 := by decide
theorem cert_e2407061567930 : check e2407061567930 [[],[]] .chain = true := by decide
def e2407061567978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2407061567978 : Closed e2407061567978 ∧ code e2407061567978 = 11203154590186 := by decide
theorem cert_e2407061567978 : check e2407061567978 [[],[]] .chain = true := by decide
def e2407061568110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407061568110 : Closed e2407061568110 ∧ code e2407061568110 = 11203154590318 := by decide
theorem cert_e2407061568110 : check e2407061568110 [[],[]] .chain = true := by decide
def e2407061568122 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407061568122 : Closed e2407061568122 ∧ code e2407061568122 = 11203154590330 := by decide
theorem cert_e2407061568122 : check e2407061568122 [[],[]] .chain = true := by decide
def e2407061568286 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2407061568286 : Closed e2407061568286 ∧ code e2407061568286 = 11203154590494 := by decide
theorem cert_e2407061568286 : check e2407061568286 [[],[]] .chain = true := by decide
def e2407061568398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2407061568398 : Closed e2407061568398 ∧ code e2407061568398 = 11203154590606 := by decide
theorem cert_e2407061568398 : check e2407061568398 [[],[]] .chain = true := by decide
def e2407061568410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061568410 : Closed e2407061568410 ∧ code e2407061568410 = 11203154590618 := by decide
theorem cert_e2407061568410 : check e2407061568410 [[],[]] .chain = true := by decide
def e2407061568630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2407061568630 : Closed e2407061568630 ∧ code e2407061568630 = 11203154590838 := by decide
theorem cert_e2407061568630 : check e2407061568630 [[],[]] .chain = true := by decide
def e2407061568726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2407061568726 : Closed e2407061568726 ∧ code e2407061568726 = 11203154590934 := by decide
theorem cert_e2407061568726 : check e2407061568726 [[],[]] .chain = true := by decide
def e2407061568730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2407061568730 : Closed e2407061568730 ∧ code e2407061568730 = 11203154590938 := by decide
theorem cert_e2407061568730 : check e2407061568730 [[],[]] .chain = true := by decide
def e2407061568746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2407061568746 : Closed e2407061568746 ∧ code e2407061568746 = 11203154590954 := by decide
theorem cert_e2407061568746 : check e2407061568746 [[],[]] .chain = true := by decide
def e2407061568822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407061568822 : Closed e2407061568822 ∧ code e2407061568822 = 11203154591030 := by decide
theorem cert_e2407061568822 : check e2407061568822 [[],[]] .chain = true := by decide
def e2407061568826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407061568826 : Closed e2407061568826 ∧ code e2407061568826 = 11203154591034 := by decide
theorem cert_e2407061568826 : check e2407061568826 [[],[]] .chain = true := by decide
def e2407061568910 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2407061568910 : Closed e2407061568910 ∧ code e2407061568910 = 11203154591118 := by decide
theorem cert_e2407061568910 : check e2407061568910 [[],[]] .chain = true := by decide
def e2407061568922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061568922 : Closed e2407061568922 ∧ code e2407061568922 = 11203154591130 := by decide
theorem cert_e2407061568922 : check e2407061568922 [[],[]] .chain = true := by decide
def e2407061570526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2407061570526 : Closed e2407061570526 ∧ code e2407061570526 = 11203154592734 := by decide
theorem cert_e2407061570526 : check e2407061570526 [[],[]] .chain = true := by decide
def e2407061570542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2407061570542 : Closed e2407061570542 ∧ code e2407061570542 = 11203154592750 := by decide
theorem cert_e2407061570542 : check e2407061570542 [[],[]] .chain = true := by decide
def e2407061572462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2407061572462 : Closed e2407061572462 ∧ code e2407061572462 = 11203154594670 := by decide
theorem cert_e2407061572462 : check e2407061572462 [[],[]] .chain = true := by decide
def e2407061572470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2407061572470 : Closed e2407061572470 ∧ code e2407061572470 = 11203154594678 := by decide
theorem cert_e2407061572470 : check e2407061572470 [[],[]] .chain = true := by decide
def e2407061572526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2407061572526 : Closed e2407061572526 ∧ code e2407061572526 = 11203154594734 := by decide
theorem cert_e2407061572526 : check e2407061572526 [[],[]] .chain = true := by decide
def e2407061572538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2407061572538 : Closed e2407061572538 ∧ code e2407061572538 = 11203154594746 := by decide
theorem cert_e2407061572538 : check e2407061572538 [[],[]] .chain = true := by decide
def e2407061572566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2407061572566 : Closed e2407061572566 ∧ code e2407061572566 = 11203154594774 := by decide
theorem cert_e2407061572566 : check e2407061572566 [[],[]] .chain = true := by decide
def e2407061572570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2407061572570 : Closed e2407061572570 ∧ code e2407061572570 = 11203154594778 := by decide
theorem cert_e2407061572570 : check e2407061572570 [[],[]] .chain = true := by decide
def e2407061572846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2407061572846 : Closed e2407061572846 ∧ code e2407061572846 = 11203154595054 := by decide
theorem cert_e2407061572846 : check e2407061572846 [[],[]] .chain = true := by decide
def e2407061572854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2407061572854 : Closed e2407061572854 ∧ code e2407061572854 = 11203154595062 := by decide
theorem cert_e2407061572854 : check e2407061572854 [[],[]] .chain = true := by decide
def e2407061573230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407061573230 : Closed e2407061573230 ∧ code e2407061573230 = 11203154595438 := by decide
theorem cert_e2407061573230 : check e2407061573230 [[],[]] .chain = true := by decide
def e2407061573242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407061573242 : Closed e2407061573242 ∧ code e2407061573242 = 11203154595450 := by decide
theorem cert_e2407061573242 : check e2407061573242 [[],[]] .chain = true := by decide
def e2407061573430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407061573430 : Closed e2407061573430 ∧ code e2407061573430 = 11203154595638 := by decide
theorem cert_e2407061573430 : check e2407061573430 [[],[]] .chain = true := by decide
def e2407061573434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407061573434 : Closed e2407061573434 ∧ code e2407061573434 = 11203154595642 := by decide
theorem cert_e2407061573434 : check e2407061573434 [[],[]] .chain = true := by decide
def e2407061578206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2407061578206 : Closed e2407061578206 ∧ code e2407061578206 = 11203154600414 := by decide
theorem cert_e2407061578206 : check e2407061578206 [[],[]] .chain = true := by decide
def e2407061578230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2407061578230 : Closed e2407061578230 ∧ code e2407061578230 = 11203154600438 := by decide
theorem cert_e2407061578230 : check e2407061578230 [[],[]] .chain = true := by decide
def e2407061579182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2407061579182 : Closed e2407061579182 ∧ code e2407061579182 = 11203154601390 := by decide
theorem cert_e2407061579182 : check e2407061579182 [[],[]] .chain = true := by decide
def e2407061579194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2407061579194 : Closed e2407061579194 ∧ code e2407061579194 = 11203154601402 := by decide
theorem cert_e2407061579194 : check e2407061579194 [[],[]] .chain = true := by decide
def e2407061579242 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2407061579242 : Closed e2407061579242 ∧ code e2407061579242 = 11203154601450 := by decide
theorem cert_e2407061579242 : check e2407061579242 [[],[]] .chain = true := by decide
def e2407061579374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407061579374 : Closed e2407061579374 ∧ code e2407061579374 = 11203154601582 := by decide
theorem cert_e2407061579374 : check e2407061579374 [[],[]] .chain = true := by decide
def e2407061579386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407061579386 : Closed e2407061579386 ∧ code e2407061579386 = 11203154601594 := by decide
theorem cert_e2407061579386 : check e2407061579386 [[],[]] .chain = true := by decide
def e2407061579550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2407061579550 : Closed e2407061579550 ∧ code e2407061579550 = 11203154601758 := by decide
theorem cert_e2407061579550 : check e2407061579550 [[],[]] .chain = true := by decide
def e2407061579662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2407061579662 : Closed e2407061579662 ∧ code e2407061579662 = 11203154601870 := by decide
theorem cert_e2407061579662 : check e2407061579662 [[],[]] .chain = true := by decide
def e2407061579674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407061579674 : Closed e2407061579674 ∧ code e2407061579674 = 11203154601882 := by decide
theorem cert_e2407061579674 : check e2407061579674 [[],[]] .chain = true := by decide
def e2407061582062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2)))))))))
theorem wire_e2407061582062 : Closed e2407061582062 ∧ code e2407061582062 = 11203154604270 := by decide
theorem cert_e2407061582062 : check e2407061582062 [[],[]] .chain = true := by decide
def e2407061582070 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1)))))))))
theorem wire_e2407061582070 : Closed e2407061582070 ∧ code e2407061582070 = 11203154604278 := by decide
theorem cert_e2407061582070 : check e2407061582070 [[],[]] .chain = true := by decide
def e2407061582550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2407061582550 : Closed e2407061582550 ∧ code e2407061582550 = 11203154604758 := by decide
theorem cert_e2407061582550 : check e2407061582550 [[],[]] .chain = true := by decide
def e2407061582554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2407061582554 : Closed e2407061582554 ∧ code e2407061582554 = 11203154604762 := by decide
theorem cert_e2407061582554 : check e2407061582554 [[],[]] .chain = true := by decide
def e2407061582570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2407061582570 : Closed e2407061582570 ∧ code e2407061582570 = 11203154604778 := by decide
theorem cert_e2407061582570 : check e2407061582570 [[],[]] .chain = true := by decide
def e2407061582646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2407061582646 : Closed e2407061582646 ∧ code e2407061582646 = 11203154604854 := by decide
theorem cert_e2407061582646 : check e2407061582646 [[],[]] .chain = true := by decide
def e2407061582650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2407061582650 : Closed e2407061582650 ∧ code e2407061582650 = 11203154604858 := by decide
theorem cert_e2407061582650 : check e2407061582650 [[],[]] .chain = true := by decide
def e2407061582734 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2407061582734 : Closed e2407061582734 ∧ code e2407061582734 = 11203154604942 := by decide
theorem cert_e2407061582734 : check e2407061582734 [[],[]] .chain = true := by decide
def e2407061582746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407061582746 : Closed e2407061582746 ∧ code e2407061582746 = 11203154604954 := by decide
theorem cert_e2407061582746 : check e2407061582746 [[],[]] .chain = true := by decide
def e2407061673646 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2407061673646 : Closed e2407061673646 ∧ code e2407061673646 = 11203154695854 := by decide
theorem cert_e2407061673646 : check e2407061673646 [[],[]] .chain = true := by decide
def e2407061673658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2407061673658 : Closed e2407061673658 ∧ code e2407061673658 = 11203154695866 := by decide
theorem cert_e2407061673658 : check e2407061673658 [[],[]] .chain = true := by decide
def e2407061673706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2407061673706 : Closed e2407061673706 ∧ code e2407061673706 = 11203154695914 := by decide
theorem cert_e2407061673706 : check e2407061673706 [[],[]] .chain = true := by decide
def e2407061673898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2407061673898 : Closed e2407061673898 ∧ code e2407061673898 = 11203154696106 := by decide
theorem cert_e2407061673898 : check e2407061673898 [[],[]] .chain = true := by decide
def e2407061674222 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2407061674222 : Closed e2407061674222 ∧ code e2407061674222 = 11203154696430 := by decide
theorem cert_e2407061674222 : check e2407061674222 [[],[]] .chain = true := by decide
def e2407061674230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2407061674230 : Closed e2407061674230 ∧ code e2407061674230 = 11203154696438 := by decide
theorem cert_e2407061674230 : check e2407061674230 [[],[]] .chain = true := by decide
def e2407061674414 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2407061674414 : Closed e2407061674414 ∧ code e2407061674414 = 11203154696622 := by decide
theorem cert_e2407061674414 : check e2407061674414 [[],[]] .chain = true := by decide
def e2407061674426 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2407061674426 : Closed e2407061674426 ∧ code e2407061674426 = 11203154696634 := by decide
theorem cert_e2407061674426 : check e2407061674426 [[],[]] .chain = true := by decide
def e2407061674474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2407061674474 : Closed e2407061674474 ∧ code e2407061674474 = 11203154696682 := by decide
theorem cert_e2407061674474 : check e2407061674474 [[],[]] .chain = true := by decide
def e2407061674606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2407061674606 : Closed e2407061674606 ∧ code e2407061674606 = 11203154696814 := by decide
theorem cert_e2407061674606 : check e2407061674606 [[],[]] .chain = true := by decide
def e2407061674618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2407061674618 : Closed e2407061674618 ∧ code e2407061674618 = 11203154696826 := by decide
theorem cert_e2407061674618 : check e2407061674618 [[],[]] .chain = true := by decide
def e2407061674782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2407061674782 : Closed e2407061674782 ∧ code e2407061674782 = 11203154696990 := by decide
theorem cert_e2407061674782 : check e2407061674782 [[],[]] .chain = true := by decide
def e2407061674894 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2407061674894 : Closed e2407061674894 ∧ code e2407061674894 = 11203154697102 := by decide
theorem cert_e2407061674894 : check e2407061674894 [[],[]] .chain = true := by decide
def e2407061674906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061674906 : Closed e2407061674906 ∧ code e2407061674906 = 11203154697114 := by decide
theorem cert_e2407061674906 : check e2407061674906 [[],[]] .chain = true := by decide
def e2407061675118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2407061675118 : Closed e2407061675118 ∧ code e2407061675118 = 11203154697326 := by decide
theorem cert_e2407061675118 : check e2407061675118 [[],[]] .chain = true := by decide
def e2407061675130 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2407061675130 : Closed e2407061675130 ∧ code e2407061675130 = 11203154697338 := by decide
theorem cert_e2407061675130 : check e2407061675130 [[],[]] .chain = true := by decide
def e2407061675294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2407061675294 : Closed e2407061675294 ∧ code e2407061675294 = 11203154697502 := by decide
theorem cert_e2407061675294 : check e2407061675294 [[],[]] .chain = true := by decide
def e2407061675462 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2407061675462 : Closed e2407061675462 ∧ code e2407061675462 = 11203154697670 := by decide
theorem cert_e2407061675462 : check e2407061675462 [[],[]] .chain = true := by decide
def e2407061675574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2407061675574 : Closed e2407061675574 ∧ code e2407061675574 = 11203154697782 := by decide
theorem cert_e2407061675574 : check e2407061675574 [[],[]] .chain = true := by decide
def e2407061675578 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2407061675578 : Closed e2407061675578 ∧ code e2407061675578 = 11203154697786 := by decide
theorem cert_e2407061675578 : check e2407061675578 [[],[]] .chain = true := by decide
def e2407061675626 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)))))))
theorem wire_e2407061675626 : Closed e2407061675626 ∧ code e2407061675626 = 11203154697834 := by decide
theorem cert_e2407061675626 : check e2407061675626 [[],[]] .chain = true := by decide
def e2407061675662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2407061675662 : Closed e2407061675662 ∧ code e2407061675662 = 11203154697870 := by decide
theorem cert_e2407061675662 : check e2407061675662 [[],[]] .chain = true := by decide
def e2407061675674 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061675674 : Closed e2407061675674 ∧ code e2407061675674 = 11203154697882 := by decide
theorem cert_e2407061675674 : check e2407061675674 [[],[]] .chain = true := by decide
def e2407061675718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2407061675718 : Closed e2407061675718 ∧ code e2407061675718 = 11203154697926 := by decide
theorem cert_e2407061675718 : check e2407061675718 [[],[]] .chain = true := by decide
def e2407061676510 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3)))))))))
theorem wire_e2407061676510 : Closed e2407061676510 ∧ code e2407061676510 = 11203154698718 := by decide
theorem cert_e2407061676510 : check e2407061676510 [[],[]] .chain = true := by decide
def e2407061676534 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1)))))))))
theorem wire_e2407061676534 : Closed e2407061676534 ∧ code e2407061676534 = 11203154698742 := by decide
theorem cert_e2407061676534 : check e2407061676534 [[],[]] .chain = true := by decide
def e2407061677486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2407061677486 : Closed e2407061677486 ∧ code e2407061677486 = 11203154699694 := by decide
theorem cert_e2407061677486 : check e2407061677486 [[],[]] .chain = true := by decide
def e2407061677498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2407061677498 : Closed e2407061677498 ∧ code e2407061677498 = 11203154699706 := by decide
theorem cert_e2407061677498 : check e2407061677498 [[],[]] .chain = true := by decide
def e2407061677546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2407061677546 : Closed e2407061677546 ∧ code e2407061677546 = 11203154699754 := by decide
theorem cert_e2407061677546 : check e2407061677546 [[],[]] .chain = true := by decide
def e2407061677678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2407061677678 : Closed e2407061677678 ∧ code e2407061677678 = 11203154699886 := by decide
theorem cert_e2407061677678 : check e2407061677678 [[],[]] .chain = true := by decide
def e2407061677690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2407061677690 : Closed e2407061677690 ∧ code e2407061677690 = 11203154699898 := by decide
theorem cert_e2407061677690 : check e2407061677690 [[],[]] .chain = true := by decide
def e2407061677854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2407061677854 : Closed e2407061677854 ∧ code e2407061677854 = 11203154700062 := by decide
theorem cert_e2407061677854 : check e2407061677854 [[],[]] .chain = true := by decide
def e2407061677966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2407061677966 : Closed e2407061677966 ∧ code e2407061677966 = 11203154700174 := by decide
theorem cert_e2407061677966 : check e2407061677966 [[],[]] .chain = true := by decide
def e2407061677978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407061677978 : Closed e2407061677978 ∧ code e2407061677978 = 11203154700186 := by decide
theorem cert_e2407061677978 : check e2407061677978 [[],[]] .chain = true := by decide
def e2407061680926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2407061680926 : Closed e2407061680926 ∧ code e2407061680926 = 11203154703134 := by decide
theorem cert_e2407061680926 : check e2407061680926 [[],[]] .chain = true := by decide
def e2407061681094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2407061681094 : Closed e2407061681094 ∧ code e2407061681094 = 11203154703302 := by decide
theorem cert_e2407061681094 : check e2407061681094 [[],[]] .chain = true := by decide
def e2407061682294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2407061682294 : Closed e2407061682294 ∧ code e2407061682294 = 11203154704502 := by decide
theorem cert_e2407061682294 : check e2407061682294 [[],[]] .chain = true := by decide
def e2407061682538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2407061682538 : Closed e2407061682538 ∧ code e2407061682538 = 11203154704746 := by decide
theorem cert_e2407061682538 : check e2407061682538 [[],[]] .chain = true := by decide
def e2407061682574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2407061682574 : Closed e2407061682574 ∧ code e2407061682574 = 11203154704782 := by decide
theorem cert_e2407061682574 : check e2407061682574 [[],[]] .chain = true := by decide
def e2407061682586 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2407061682586 : Closed e2407061682586 ∧ code e2407061682586 = 11203154704794 := by decide
theorem cert_e2407061682586 : check e2407061682586 [[],[]] .chain = true := by decide
def e2407061682630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2407061682630 : Closed e2407061682630 ∧ code e2407061682630 = 11203154704838 := by decide
theorem cert_e2407061682630 : check e2407061682630 [[],[]] .chain = true := by decide
def e2407061728086 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2407061728086 : Closed e2407061728086 ∧ code e2407061728086 = 11203154750294 := by decide
theorem cert_e2407061728086 : check e2407061728086 [[],[]] .chain = true := by decide
def e2407061728090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2407061728090 : Closed e2407061728090 ∧ code e2407061728090 = 11203154750298 := by decide
theorem cert_e2407061728090 : check e2407061728090 [[],[]] .chain = true := by decide
def e2407061728106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2407061728106 : Closed e2407061728106 ∧ code e2407061728106 = 11203154750314 := by decide
theorem cert_e2407061728106 : check e2407061728106 [[],[]] .chain = true := by decide
def e2407061728170 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0)))))))
theorem wire_e2407061728170 : Closed e2407061728170 ∧ code e2407061728170 = 11203154750378 := by decide
theorem cert_e2407061728170 : check e2407061728170 [[],[]] .chain = true := by decide
def e2407061728374 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2407061728374 : Closed e2407061728374 ∧ code e2407061728374 = 11203154750582 := by decide
theorem cert_e2407061728374 : check e2407061728374 [[],[]] .chain = true := by decide
def e2407061728470 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2407061728470 : Closed e2407061728470 ∧ code e2407061728470 = 11203154750678 := by decide
theorem cert_e2407061728470 : check e2407061728470 [[],[]] .chain = true := by decide
def e2407061728474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2407061728474 : Closed e2407061728474 ∧ code e2407061728474 = 11203154750682 := by decide
theorem cert_e2407061728474 : check e2407061728474 [[],[]] .chain = true := by decide
def e2407061728490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2407061728490 : Closed e2407061728490 ∧ code e2407061728490 = 11203154750698 := by decide
theorem cert_e2407061728490 : check e2407061728490 [[],[]] .chain = true := by decide
def e2407061728566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2407061728566 : Closed e2407061728566 ∧ code e2407061728566 = 11203154750774 := by decide
theorem cert_e2407061728566 : check e2407061728566 [[],[]] .chain = true := by decide
def e2407061728570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2407061728570 : Closed e2407061728570 ∧ code e2407061728570 = 11203154750778 := by decide
theorem cert_e2407061728570 : check e2407061728570 [[],[]] .chain = true := by decide
def e2407061728654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2407061728654 : Closed e2407061728654 ∧ code e2407061728654 = 11203154750862 := by decide
theorem cert_e2407061728654 : check e2407061728654 [[],[]] .chain = true := by decide
def e2407061728666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2407061728666 : Closed e2407061728666 ∧ code e2407061728666 = 11203154750874 := by decide
theorem cert_e2407061728666 : check e2407061728666 [[],[]] .chain = true := by decide
def e2407061728822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2407061728822 : Closed e2407061728822 ∧ code e2407061728822 = 11203154751030 := by decide
theorem cert_e2407061728822 : check e2407061728822 [[],[]] .chain = true := by decide
def e2407061728826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2407061728826 : Closed e2407061728826 ∧ code e2407061728826 = 11203154751034 := by decide
theorem cert_e2407061728826 : check e2407061728826 [[],[]] .chain = true := by decide
end Blc.Floor43
