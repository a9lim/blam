import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422407407062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2422407407062 : Closed e2422407407062 ∧ code e2422407407062 = 11218500429270 := by decide
theorem cert_e2422407407062 : check e2422407407062 [[],[]] .chain = true := by decide
def e2422407407066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2422407407066 : Closed e2422407407066 ∧ code e2422407407066 = 11218500429274 := by decide
theorem cert_e2422407407066 : check e2422407407066 [[],[]] .chain = true := by decide
def e2422407407082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2422407407082 : Closed e2422407407082 ∧ code e2422407407082 = 11218500429290 := by decide
theorem cert_e2422407407082 : check e2422407407082 [[],[]] .sourceHead = true := by decide
def e2422407407106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))))
theorem wire_e2422407407106 : Closed e2422407407106 ∧ code e2422407407106 = 11218500429314 := by decide
theorem cert_e2422407407106 : check e2422407407106 [[],[]] .chain = true := by decide
def e2422407407118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2422407407118 : Closed e2422407407118 ∧ code e2422407407118 = 11218500429326 := by decide
theorem cert_e2422407407118 : check e2422407407118 [[],[]] .chain = true := by decide
def e2422407407130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422407407130 : Closed e2422407407130 ∧ code e2422407407130 = 11218500429338 := by decide
theorem cert_e2422407407130 : check e2422407407130 [[],[]] .sourceHead = true := by decide
def e2422407407202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422407407202 : Closed e2422407407202 ∧ code e2422407407202 = 11218500429410 := by decide
theorem cert_e2422407407202 : check e2422407407202 [[],[]] .chain = true := by decide
def e2422407407214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2422407407214 : Closed e2422407407214 ∧ code e2422407407214 = 11218500429422 := by decide
theorem cert_e2422407407214 : check e2422407407214 [[],[]] .sourceHead = true := by decide
def e2422407407222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2422407407222 : Closed e2422407407222 ∧ code e2422407407222 = 11218500429430 := by decide
theorem cert_e2422407407222 : check e2422407407222 [[],[]] .chain = true := by decide
def e2422407407226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2422407407226 : Closed e2422407407226 ∧ code e2422407407226 = 11218500429434 := by decide
theorem cert_e2422407407226 : check e2422407407226 [[],[]] .sourceHead = true := by decide
def e2422407407366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407407366 : Closed e2422407407366 ∧ code e2422407407366 = 11218500429574 := by decide
theorem cert_e2422407407366 : check e2422407407366 [[],[]] .chain = true := by decide
def e2422407407390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2422407407390 : Closed e2422407407390 ∧ code e2422407407390 = 11218500429598 := by decide
theorem cert_e2422407407390 : check e2422407407390 [[],[]] .sourceHead = true := by decide
def e2422407407414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407407414 : Closed e2422407407414 ∧ code e2422407407414 = 11218500429622 := by decide
theorem cert_e2422407407414 : check e2422407407414 [[],[]] .chain = true := by decide
def e2422407407418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407407418 : Closed e2422407407418 ∧ code e2422407407418 = 11218500429626 := by decide
theorem cert_e2422407407418 : check e2422407407418 [[],[]] .chain = true := by decide
def e2422407407490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407407490 : Closed e2422407407490 ∧ code e2422407407490 = 11218500429698 := by decide
theorem cert_e2422407407490 : check e2422407407490 [[],[]] .sourceHead = true := by decide
def e2422407407502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2422407407502 : Closed e2422407407502 ∧ code e2422407407502 = 11218500429710 := by decide
theorem cert_e2422407407502 : check e2422407407502 [[],[]] .sourceHead = true := by decide
def e2422407407514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407407514 : Closed e2422407407514 ∧ code e2422407407514 = 11218500429722 := by decide
theorem cert_e2422407407514 : check e2422407407514 [[],[]] .sourceHead = true := by decide
def e2422407409694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.lam (.lam (.var 3)))))))))
theorem wire_e2422407409694 : Closed e2422407409694 ∧ code e2422407409694 = 11218500431902 := by decide
theorem cert_e2422407409694 : check e2422407409694 [[],[]] .chain = true := by decide
def e2422407409890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422407409890 : Closed e2422407409890 ∧ code e2422407409890 = 11218500432098 := by decide
theorem cert_e2422407409890 : check e2422407409890 [[],[]] .chain = true := by decide
def e2422407409902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 2))))))))
theorem wire_e2422407409902 : Closed e2422407409902 ∧ code e2422407409902 = 11218500432110 := by decide
theorem cert_e2422407409902 : check e2422407409902 [[],[]] .chain = true := by decide
def e2422407409910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.app (.var 2) (.var 1))))))))
theorem wire_e2422407409910 : Closed e2422407409910 ∧ code e2422407409910 = 11218500432118 := by decide
theorem cert_e2422407409910 : check e2422407409910 [[],[]] .chain = true := by decide
def e2422407410390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2422407410390 : Closed e2422407410390 ∧ code e2422407410390 = 11218500432598 := by decide
theorem cert_e2422407410390 : check e2422407410390 [[],[]] .chain = true := by decide
def e2422407410394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2422407410394 : Closed e2422407410394 ∧ code e2422407410394 = 11218500432602 := by decide
theorem cert_e2422407410394 : check e2422407410394 [[],[]] .chain = true := by decide
def e2422407410410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2422407410410 : Closed e2422407410410 ∧ code e2422407410410 = 11218500432618 := by decide
theorem cert_e2422407410410 : check e2422407410410 [[],[]] .chain = true := by decide
def e2422407410438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.lam (.var 1)))))))))
theorem wire_e2422407410438 : Closed e2422407410438 ∧ code e2422407410438 = 11218500432646 := by decide
theorem cert_e2422407410438 : check e2422407410438 [[],[]] .chain = true := by decide
def e2422407410462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2422407410462 : Closed e2422407410462 ∧ code e2422407410462 = 11218500432670 := by decide
theorem cert_e2422407410462 : check e2422407410462 [[],[]] .sourceHead = true := by decide
def e2422407410486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2422407410486 : Closed e2422407410486 ∧ code e2422407410486 = 11218500432694 := by decide
theorem cert_e2422407410486 : check e2422407410486 [[],[]] .chain = true := by decide
def e2422407410490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2422407410490 : Closed e2422407410490 ∧ code e2422407410490 = 11218500432698 := by decide
theorem cert_e2422407410490 : check e2422407410490 [[],[]] .chain = true := by decide
def e2422407410586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407410586 : Closed e2422407410586 ∧ code e2422407410586 = 11218500432794 := by decide
theorem cert_e2422407410586 : check e2422407410586 [[],[]] .chain = true := by decide
def e2422407410630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2422407410630 : Closed e2422407410630 ∧ code e2422407410630 = 11218500432838 := by decide
theorem cert_e2422407410630 : check e2422407410630 [[],[]] .sourceHead = true := by decide
def e2422407411830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.lam (.app (.var 1) (.var 1))))))))
theorem wire_e2422407411830 : Closed e2422407411830 ∧ code e2422407411830 = 11218500434038 := by decide
theorem cert_e2422407411830 : check e2422407411830 [[],[]] .sourceHead = true := by decide
def e2422407412074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0)))))))
theorem wire_e2422407412074 : Closed e2422407412074 ∧ code e2422407412074 = 11218500434282 := by decide
theorem cert_e2422407412074 : check e2422407412074 [[],[]] .sourceHead = true := by decide
def e2422407412098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.lam (.lam (.var 0)))))))))
theorem wire_e2422407412098 : Closed e2422407412098 ∧ code e2422407412098 = 11218500434306 := by decide
theorem cert_e2422407412098 : check e2422407412098 [[],[]] .sourceHead = true := by decide
def e2422407412110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2422407412110 : Closed e2422407412110 ∧ code e2422407412110 = 11218500434318 := by decide
theorem cert_e2422407412110 : check e2422407412110 [[],[]] .sourceHead = true := by decide
def e2422407412122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0))))))))
theorem wire_e2422407412122 : Closed e2422407412122 ∧ code e2422407412122 = 11218500434330 := by decide
theorem cert_e2422407412122 : check e2422407412122 [[],[]] .sourceHead = true := by decide
def e2422407412166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2422407412166 : Closed e2422407412166 ∧ code e2422407412166 = 11218500434374 := by decide
theorem cert_e2422407412166 : check e2422407412166 [[],[]] .sourceHead = true := by decide
def e2422407430998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 0)) (.var 1))))))
theorem wire_e2422407430998 : Closed e2422407430998 ∧ code e2422407430998 = 11218500453206 := by decide
theorem cert_e2422407430998 : check e2422407430998 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407431002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))) (.var 1)) (.var 0))))))
theorem wire_e2422407431002 : Closed e2422407431002 ∧ code e2422407431002 = 11218500453210 := by decide
theorem cert_e2422407431002 : check e2422407431002 [[],[],[.under,.under,.left,.left]] .width = true := by decide
def e2422407431382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407431382 : Closed e2422407431382 ∧ code e2422407431382 = 11218500453590 := by decide
theorem cert_e2422407431382 : check e2422407431382 [[],[]] .chain = true := by decide
def e2422407431386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407431386 : Closed e2422407431386 ∧ code e2422407431386 = 11218500453594 := by decide
theorem cert_e2422407431386 : check e2422407431386 [[],[]] .chain = true := by decide
def e2422407431402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407431402 : Closed e2422407431402 ∧ code e2422407431402 = 11218500453610 := by decide
theorem cert_e2422407431402 : check e2422407431402 [[],[]] .chain = true := by decide
def e2422407431478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407431478 : Closed e2422407431478 ∧ code e2422407431478 = 11218500453686 := by decide
theorem cert_e2422407431478 : check e2422407431478 [[],[]] .chain = true := by decide
def e2422407431482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407431482 : Closed e2422407431482 ∧ code e2422407431482 = 11218500453690 := by decide
theorem cert_e2422407431482 : check e2422407431482 [[],[]] .chain = true := by decide
def e2422407431578 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407431578 : Closed e2422407431578 ∧ code e2422407431578 = 11218500453786 := by decide
theorem cert_e2422407431578 : check e2422407431578 [[],[]] .chain = true := by decide
def e2422407432118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 3))))) (.var 1)) (.var 1))))))
theorem wire_e2422407432118 : Closed e2422407432118 ∧ code e2422407432118 = 11218500454326 := by decide
theorem cert_e2422407432118 : check e2422407432118 [[],[]] .chain = true := by decide
def e2422407432150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 4))))) (.var 0)) (.var 1))))))
theorem wire_e2422407432150 : Closed e2422407432150 ∧ code e2422407432150 = 11218500454358 := by decide
theorem cert_e2422407432150 : check e2422407432150 [[],[]] .chain = true := by decide
def e2422407432154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.lam (.var 4))))) (.var 1)) (.var 0))))))
theorem wire_e2422407432154 : Closed e2422407432154 ∧ code e2422407432154 = 11218500454362 := by decide
theorem cert_e2422407432154 : check e2422407432154 [[],[]] .chain = true := by decide
def e2422407433686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 0)) (.var 1))))))
theorem wire_e2422407433686 : Closed e2422407433686 ∧ code e2422407433686 = 11218500455894 := by decide
theorem cert_e2422407433686 : check e2422407433686 [[],[]] .chain = true := by decide
def e2422407433690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 2))))) (.var 1)) (.var 0))))))
theorem wire_e2422407433690 : Closed e2422407433690 ∧ code e2422407433690 = 11218500455898 := by decide
theorem cert_e2422407433690 : check e2422407433690 [[],[]] .chain = true := by decide
def e2422407433706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 3))))) (.var 0)) (.var 0))))))
theorem wire_e2422407433706 : Closed e2422407433706 ∧ code e2422407433706 = 11218500455914 := by decide
theorem cert_e2422407433706 : check e2422407433706 [[],[]] .chain = true := by decide
def e2422407433942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e2422407433942 : Closed e2422407433942 ∧ code e2422407433942 = 11218500456150 := by decide
private def t_e2422407433942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 0)) (.var 1))))))
theorem cert_e2422407433942 : ¬ IsSelfInterpreter e2422407433942 :=
  wSource (t := t_e2422407433942) (replay_sound (ps := []) (t := e2422407433942) (by decide)) (by decide)
def e2422407433946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e2422407433946 : Closed e2422407433946 ∧ code e2422407433946 = 11218500456154 := by decide
private def t_e2422407433946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 1) (.var 1))))) (.var 1)) (.var 0))))))
theorem cert_e2422407433946 : ¬ IsSelfInterpreter e2422407433946 :=
  wSource (t := t_e2422407433946) (replay_sound (ps := []) (t := e2422407433946) (by decide)) (by decide)
def e2422407434070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422407434070 : Closed e2422407434070 ∧ code e2422407434070 = 11218500456278 := by decide
theorem cert_e2422407434070 : check e2422407434070 [[],[]] .chain = true := by decide
def e2422407434074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422407434074 : Closed e2422407434074 ∧ code e2422407434074 = 11218500456282 := by decide
theorem cert_e2422407434074 : check e2422407434074 [[],[]] .chain = true := by decide
def e2422407434154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 0))))) (.var 0)) (.var 0))))))
theorem wire_e2422407434154 : Closed e2422407434154 ∧ code e2422407434154 = 11218500456362 := by decide
theorem cert_e2422407434154 : check e2422407434154 [[],[]] .chain = true := by decide
def e2422407435118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422407435118 : Closed e2422407435118 ∧ code e2422407435118 = 11218500457326 := by decide
theorem cert_e2422407435118 : check e2422407435118 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422407435126 : Closed e2422407435126 ∧ code e2422407435126 = 11218500457334 := by decide
theorem cert_e2422407435126 : check e2422407435126 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422407435182 : Closed e2422407435182 ∧ code e2422407435182 = 11218500457390 := by decide
theorem cert_e2422407435182 : check e2422407435182 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422407435194 : Closed e2422407435194 ∧ code e2422407435194 = 11218500457402 := by decide
theorem cert_e2422407435194 : check e2422407435194 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422407435222 : Closed e2422407435222 ∧ code e2422407435222 = 11218500457430 := by decide
theorem cert_e2422407435222 : check e2422407435222 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422407435226 : Closed e2422407435226 ∧ code e2422407435226 = 11218500457434 := by decide
theorem cert_e2422407435226 : check e2422407435226 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422407435502 : Closed e2422407435502 ∧ code e2422407435502 = 11218500457710 := by decide
theorem cert_e2422407435502 : check e2422407435502 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435510 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422407435510 : Closed e2422407435510 ∧ code e2422407435510 = 11218500457718 := by decide
theorem cert_e2422407435510 : check e2422407435510 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422407435886 : Closed e2422407435886 ∧ code e2422407435886 = 11218500458094 := by decide
theorem cert_e2422407435886 : check e2422407435886 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407435898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422407435898 : Closed e2422407435898 ∧ code e2422407435898 = 11218500458106 := by decide
theorem cert_e2422407435898 : check e2422407435898 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407436086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407436086 : Closed e2422407436086 ∧ code e2422407436086 = 11218500458294 := by decide
theorem cert_e2422407436086 : check e2422407436086 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407436090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407436090 : Closed e2422407436090 ∧ code e2422407436090 = 11218500458298 := by decide
theorem cert_e2422407436090 : check e2422407436090 [[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407436726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2422407436726 : Closed e2422407436726 ∧ code e2422407436726 = 11218500458934 := by decide
theorem cert_e2422407436726 : check e2422407436726 [[],[]] .chain = true := by decide
def e2422407436758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2422407436758 : Closed e2422407436758 ∧ code e2422407436758 = 11218500458966 := by decide
theorem cert_e2422407436758 : check e2422407436758 [[],[]] .chain = true := by decide
def e2422407436762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2422407436762 : Closed e2422407436762 ∧ code e2422407436762 = 11218500458970 := by decide
theorem cert_e2422407436762 : check e2422407436762 [[],[]] .chain = true := by decide
def e2422407436918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407436918 : Closed e2422407436918 ∧ code e2422407436918 = 11218500459126 := by decide
theorem cert_e2422407436918 : check e2422407436918 [[],[]] .chain = true := by decide
def e2422407437110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407437110 : Closed e2422407437110 ∧ code e2422407437110 = 11218500459318 := by decide
theorem cert_e2422407437110 : check e2422407437110 [[],[]] .chain = true := by decide
def e2422407437114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 1)))) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407437114 : Closed e2422407437114 ∧ code e2422407437114 = 11218500459322 := by decide
theorem cert_e2422407437114 : check e2422407437114 [[],[]] .chain = true := by decide
def e2422407437430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.lam (.var 2))) (.var 1))))))
theorem wire_e2422407437430 : Closed e2422407437430 ∧ code e2422407437430 = 11218500459638 := by decide
theorem cert_e2422407437430 : check e2422407437430 [[],[]] .chain = true := by decide
def e2422407437526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407437526 : Closed e2422407437526 ∧ code e2422407437526 = 11218500459734 := by decide
theorem cert_e2422407437526 : check e2422407437526 [[],[]] .chain = true := by decide
def e2422407437530 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407437530 : Closed e2422407437530 ∧ code e2422407437530 = 11218500459738 := by decide
theorem cert_e2422407437530 : check e2422407437530 [[],[]] .chain = true := by decide
def e2422407437546 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407437546 : Closed e2422407437546 ∧ code e2422407437546 = 11218500459754 := by decide
theorem cert_e2422407437546 : check e2422407437546 [[],[]] .chain = true := by decide
def e2422407437622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407437622 : Closed e2422407437622 ∧ code e2422407437622 = 11218500459830 := by decide
theorem cert_e2422407437622 : check e2422407437622 [[],[]] .chain = true := by decide
def e2422407437626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407437626 : Closed e2422407437626 ∧ code e2422407437626 = 11218500459834 := by decide
theorem cert_e2422407437626 : check e2422407437626 [[],[]] .chain = true := by decide
def e2422407437710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.lam (.var 2)))))))
theorem wire_e2422407437710 : Closed e2422407437710 ∧ code e2422407437710 = 11218500459918 := by decide
theorem cert_e2422407437710 : check e2422407437710 [[],[]] .chain = true := by decide
def e2422407437722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407437722 : Closed e2422407437722 ∧ code e2422407437722 = 11218500459930 := by decide
theorem cert_e2422407437722 : check e2422407437722 [[],[]] .chain = true := by decide
def e2422407437878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407437878 : Closed e2422407437878 ∧ code e2422407437878 = 11218500460086 := by decide
theorem cert_e2422407437878 : check e2422407437878 [[],[]] .chain = true := by decide
def e2422407437882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407437882 : Closed e2422407437882 ∧ code e2422407437882 = 11218500460090 := by decide
theorem cert_e2422407437882 : check e2422407437882 [[],[]] .chain = true := by decide
def e2422407437930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0))) (.var 0))))))
theorem wire_e2422407437930 : Closed e2422407437930 ∧ code e2422407437930 = 11218500460138 := by decide
theorem cert_e2422407437930 : check e2422407437930 [[],[]] .chain = true := by decide
def e2422407437966 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407437966 : Closed e2422407437966 ∧ code e2422407437966 = 11218500460174 := by decide
theorem cert_e2422407437966 : check e2422407437966 [[],[]] .chain = true := by decide
def e2422407437978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407437978 : Closed e2422407437978 ∧ code e2422407437978 = 11218500460186 := by decide
theorem cert_e2422407437978 : check e2422407437978 [[],[]] .chain = true := by decide
def e2422407438022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407438022 : Closed e2422407438022 ∧ code e2422407438022 = 11218500460230 := by decide
theorem cert_e2422407438022 : check e2422407438022 [[],[]] .chain = true := by decide
def e2422407441750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422407441750 : Closed e2422407441750 ∧ code e2422407441750 = 11218500463958 := by decide
private def t_e2422407441750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)) (.var 1))))))
theorem cert_e2422407441750 : ¬ IsSelfInterpreter e2422407441750 :=
  wSource (t := t_e2422407441750) (replay_sound (ps := []) (t := e2422407441750) (by decide)) (by decide)
def e2422407441754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422407441754 : Closed e2422407441754 ∧ code e2422407441754 = 11218500463962 := by decide
private def t_e2422407441754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 1)) (.var 0))))))
theorem cert_e2422407441754 : ¬ IsSelfInterpreter e2422407441754 :=
  wSource (t := t_e2422407441754) (replay_sound (ps := []) (t := e2422407441754) (by decide)) (by decide)
def e2422407442902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 0)) (.var 1))))))
theorem wire_e2422407442902 : Closed e2422407442902 ∧ code e2422407442902 = 11218500465110 := by decide
theorem cert_e2422407442902 : check e2422407442902 [[],[]] .chain = true := by decide
def e2422407442906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 2))))) (.var 1)) (.var 0))))))
theorem wire_e2422407442906 : Closed e2422407442906 ∧ code e2422407442906 = 11218500465114 := by decide
theorem cert_e2422407442906 : check e2422407442906 [[],[]] .chain = true := by decide
def e2422407442922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.lam (.var 3))))) (.var 0)) (.var 0))))))
theorem wire_e2422407442922 : Closed e2422407442922 ∧ code e2422407442922 = 11218500465130 := by decide
theorem cert_e2422407442922 : check e2422407442922 [[],[]] .chain = true := by decide
def e2422407443286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422407443286 : Closed e2422407443286 ∧ code e2422407443286 = 11218500465494 := by decide
private def t_e2422407443286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)) (.var 1))))))
theorem cert_e2422407443286 : ¬ IsSelfInterpreter e2422407443286 :=
  wSource (t := t_e2422407443286) (replay_sound (ps := []) (t := e2422407443286) (by decide)) (by decide)
def e2422407443290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422407443290 : Closed e2422407443290 ∧ code e2422407443290 = 11218500465498 := by decide
private def t_e2422407443290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 1)) (.var 0))))))
theorem cert_e2422407443290 : ¬ IsSelfInterpreter e2422407443290 :=
  wSource (t := t_e2422407443290) (replay_sound (ps := []) (t := e2422407443290) (by decide)) (by decide)
def e2422407443670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2422407443670 : Closed e2422407443670 ∧ code e2422407443670 = 11218500465878 := by decide
private def t_e2422407443670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))) (.var 1))))))
theorem cert_e2422407443670 : ¬ IsSelfInterpreter e2422407443670 :=
  wSource (t := t_e2422407443670) (replay_sound (ps := []) (t := e2422407443670) (by decide)) (by decide)
def e2422407443674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2422407443674 : Closed e2422407443674 ∧ code e2422407443674 = 11218500465882 := by decide
private def t_e2422407443674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1))) (.var 0))))))
theorem cert_e2422407443674 : ¬ IsSelfInterpreter e2422407443674 :=
  wSource (t := t_e2422407443674) (replay_sound (ps := []) (t := e2422407443674) (by decide)) (by decide)
def e2422407443690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2422407443690 : Closed e2422407443690 ∧ code e2422407443690 = 11218500465898 := by decide
private def t_e2422407443690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0))) (.var 0))))))
theorem cert_e2422407443690 : ¬ IsSelfInterpreter e2422407443690 :=
  wSource (t := t_e2422407443690) (replay_sound (ps := []) (t := e2422407443690) (by decide)) (by decide)
def e2422407443766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407443766 : Closed e2422407443766 ∧ code e2422407443766 = 11218500465974 := by decide
private def t_e2422407443766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem cert_e2422407443766 : ¬ IsSelfInterpreter e2422407443766 :=
  wSource (t := t_e2422407443766) (replay_sound (ps := []) (t := e2422407443766) (by decide)) (by decide)
def e2422407443770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407443770 : Closed e2422407443770 ∧ code e2422407443770 = 11218500465978 := by decide
private def t_e2422407443770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem cert_e2422407443770 : ¬ IsSelfInterpreter e2422407443770 :=
  wSource (t := t_e2422407443770) (replay_sound (ps := []) (t := e2422407443770) (by decide)) (by decide)
def e2422407443866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407443866 : Closed e2422407443866 ∧ code e2422407443866 = 11218500466074 := by decide
private def t_e2422407443866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem cert_e2422407443866 : ¬ IsSelfInterpreter e2422407443866 :=
  wSource (t := t_e2422407443866) (replay_sound (ps := []) (t := e2422407443866) (by decide)) (by decide)
def e2422407444022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407444022 : Closed e2422407444022 ∧ code e2422407444022 = 11218500466230 := by decide
theorem cert_e2422407444022 : check e2422407444022 [[],[]] .chain = true := by decide
def e2422407444026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407444026 : Closed e2422407444026 ∧ code e2422407444026 = 11218500466234 := by decide
theorem cert_e2422407444026 : check e2422407444026 [[],[]] .chain = true := by decide
def e2422407444110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407444110 : Closed e2422407444110 ∧ code e2422407444110 = 11218500466318 := by decide
theorem cert_e2422407444110 : check e2422407444110 [[],[]] .chain = true := by decide
def e2422407444166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 1)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407444166 : Closed e2422407444166 ∧ code e2422407444166 = 11218500466374 := by decide
theorem cert_e2422407444166 : check e2422407444166 [[],[]] .chain = true := by decide
def e2422407444250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407444250 : Closed e2422407444250 ∧ code e2422407444250 = 11218500466458 := by decide
theorem cert_e2422407444250 : check e2422407444250 [[],[]] .chain = true := by decide
def e2422407444294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 0) (.var 2)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407444294 : Closed e2422407444294 ∧ code e2422407444294 = 11218500466502 := by decide
theorem cert_e2422407444294 : check e2422407444294 [[],[]] .chain = true := by decide
def e2422407444662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 0))))) (.var 1)) (.var 1))))))
theorem wire_e2422407444662 : Closed e2422407444662 ∧ code e2422407444662 = 11218500466870 := by decide
theorem cert_e2422407444662 : check e2422407444662 [[],[]] .chain = true := by decide
def e2422407444694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 0)) (.var 1))))))
theorem wire_e2422407444694 : Closed e2422407444694 ∧ code e2422407444694 = 11218500466902 := by decide
theorem cert_e2422407444694 : check e2422407444694 [[],[]] .chain = true := by decide
def e2422407444698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.lam (.var 1))))) (.var 1)) (.var 0))))))
theorem wire_e2422407444698 : Closed e2422407444698 ∧ code e2422407444698 = 11218500466906 := by decide
theorem cert_e2422407444698 : check e2422407444698 [[],[]] .chain = true := by decide
def e2422407445046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422407445046 : Closed e2422407445046 ∧ code e2422407445046 = 11218500467254 := by decide
theorem cert_e2422407445046 : check e2422407445046 [[],[]] .chain = true := by decide
def e2422407445050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422407445050 : Closed e2422407445050 ∧ code e2422407445050 = 11218500467258 := by decide
theorem cert_e2422407445050 : check e2422407445050 [[],[]] .chain = true := by decide
def e2422407445134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422407445134 : Closed e2422407445134 ∧ code e2422407445134 = 11218500467342 := by decide
theorem cert_e2422407445134 : check e2422407445134 [[],[]] .chain = true := by decide
def e2422407445190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 0)))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422407445190 : Closed e2422407445190 ∧ code e2422407445190 = 11218500467398 := by decide
theorem cert_e2422407445190 : check e2422407445190 [[],[]] .chain = true := by decide
def e2422407445270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422407445270 : Closed e2422407445270 ∧ code e2422407445270 = 11218500467478 := by decide
theorem cert_e2422407445270 : check e2422407445270 [[],[]] .chain = true := by decide
def e2422407445346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422407445346 : Closed e2422407445346 ∧ code e2422407445346 = 11218500467554 := by decide
theorem cert_e2422407445346 : check e2422407445346 [[],[]] .chain = true := by decide
def e2422407445358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 1)) (.var 2))))))
theorem wire_e2422407445358 : Closed e2422407445358 ∧ code e2422407445358 = 11218500467566 := by decide
theorem cert_e2422407445358 : check e2422407445358 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .smaller = true := by decide
def e2422407445366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 1)))) (.var 2)) (.var 1))))))
theorem wire_e2422407445366 : Closed e2422407445366 ∧ code e2422407445366 = 11218500467574 := by decide
theorem cert_e2422407445366 : check e2422407445366 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407445386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407445386 : Closed e2422407445386 ∧ code e2422407445386 = 11218500467594 := by decide
theorem cert_e2422407445386 : check e2422407445386 [[],[]] .chain = true := by decide
def e2422407445410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407445410 : Closed e2422407445410 ∧ code e2422407445410 = 11218500467618 := by decide
theorem cert_e2422407445410 : check e2422407445410 [[],[]] .chain = true := by decide
def e2422407445422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 0)) (.var 2))))))
theorem wire_e2422407445422 : Closed e2422407445422 ∧ code e2422407445422 = 11218500467630 := by decide
theorem cert_e2422407445422 : check e2422407445422 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407445430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 1)) (.var 1))))))
theorem wire_e2422407445430 : Closed e2422407445430 ∧ code e2422407445430 = 11218500467638 := by decide
theorem cert_e2422407445430 : check e2422407445430 [[],[]] .chain = true := by decide
def e2422407445434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2422407445434 : Closed e2422407445434 ∧ code e2422407445434 = 11218500467642 := by decide
theorem cert_e2422407445434 : check e2422407445434 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407445462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2422407445462 : Closed e2422407445462 ∧ code e2422407445462 = 11218500467670 := by decide
theorem cert_e2422407445462 : check e2422407445462 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407445466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2422407445466 : Closed e2422407445466 ∧ code e2422407445466 = 11218500467674 := by decide
theorem cert_e2422407445466 : check e2422407445466 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407445590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 0)) (.var 1))))))
theorem wire_e2422407445590 : Closed e2422407445590 ∧ code e2422407445590 = 11218500467798 := by decide
theorem cert_e2422407445590 : check e2422407445590 [[],[]] .chain = true := by decide
def e2422407445594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 0))))) (.var 1)) (.var 0))))))
theorem wire_e2422407445594 : Closed e2422407445594 ∧ code e2422407445594 = 11218500467802 := by decide
theorem cert_e2422407445594 : check e2422407445594 [[],[]] .chain = true := by decide
def e2422407445610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.lam (.var 1))))) (.var 0)) (.var 0))))))
theorem wire_e2422407445610 : Closed e2422407445610 ∧ code e2422407445610 = 11218500467818 := by decide
theorem cert_e2422407445610 : check e2422407445610 [[],[]] .chain = true := by decide
def e2422407445786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2422407445786 : Closed e2422407445786 ∧ code e2422407445786 = 11218500467994 := by decide
theorem cert_e2422407445786 : check e2422407445786 [[],[]] .chain = true := by decide
def e2422407445830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 0)))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2422407445830 : Closed e2422407445830 ∧ code e2422407445830 = 11218500468038 := by decide
theorem cert_e2422407445830 : check e2422407445830 [[],[]] .chain = true := by decide
def e2422407445898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422407445898 : Closed e2422407445898 ∧ code e2422407445898 = 11218500468106 := by decide
theorem cert_e2422407445898 : check e2422407445898 [[],[]] .chain = true := by decide
def e2422407445922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422407445922 : Closed e2422407445922 ∧ code e2422407445922 = 11218500468130 := by decide
theorem cert_e2422407445922 : check e2422407445922 [[],[]] .chain = true := by decide
def e2422407445934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2422407445934 : Closed e2422407445934 ∧ code e2422407445934 = 11218500468142 := by decide
theorem cert_e2422407445934 : check e2422407445934 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407445942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 1)) (.var 1))))))
theorem wire_e2422407445942 : Closed e2422407445942 ∧ code e2422407445942 = 11218500468150 := by decide
theorem cert_e2422407445942 : check e2422407445942 [[],[]] .chain = true := by decide
def e2422407445946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2422407445946 : Closed e2422407445946 ∧ code e2422407445946 = 11218500468154 := by decide
theorem cert_e2422407445946 : check e2422407445946 [[],[],[.under,.under,.left,.left],[.under,.under,.left]] .chain = true := by decide
def e2422407445974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 0)) (.var 1))))))
theorem wire_e2422407445974 : Closed e2422407445974 ∧ code e2422407445974 = 11218500468182 := by decide
theorem cert_e2422407445974 : check e2422407445974 [[],[]] .chain = true := by decide
def e2422407445978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 2)))) (.var 1)) (.var 0))))))
theorem wire_e2422407445978 : Closed e2422407445978 ∧ code e2422407445978 = 11218500468186 := by decide
theorem cert_e2422407445978 : check e2422407445978 [[],[]] .chain = true := by decide
def e2422407445994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2422407445994 : Closed e2422407445994 ∧ code e2422407445994 = 11218500468202 := by decide
theorem cert_e2422407445994 : check e2422407445994 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407446230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2422407446230 : Closed e2422407446230 ∧ code e2422407446230 = 11218500468438 := by decide
theorem cert_e2422407446230 : check e2422407446230 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407446234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2422407446234 : Closed e2422407446234 ∧ code e2422407446234 = 11218500468442 := by decide
theorem cert_e2422407446234 : check e2422407446234 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407446250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2422407446250 : Closed e2422407446250 ∧ code e2422407446250 = 11218500468458 := by decide
theorem cert_e2422407446250 : check e2422407446250 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2422407447478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.app (.var 1) (.var 1)))) (.var 1))))))
theorem wire_e2422407447478 : Closed e2422407447478 ∧ code e2422407447478 = 11218500469686 := by decide
theorem cert_e2422407447478 : check e2422407447478 [[],[]] .chain = true := by decide
def e2422407447482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2422407447482 : Closed e2422407447482 ∧ code e2422407447482 = 11218500469690 := by decide
theorem cert_e2422407447482 : check e2422407447482 [[],[]] .chain = true := by decide
def e2422407447514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2422407447514 : Closed e2422407447514 ∧ code e2422407447514 = 11218500469722 := by decide
theorem cert_e2422407447514 : check e2422407447514 [[],[]] .chain = true := by decide
def e2422407448182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 1))) (.app (.var 1) (.var 1)))))))
theorem wire_e2422407448182 : Closed e2422407448182 ∧ code e2422407448182 = 11218500470390 := by decide
theorem cert_e2422407448182 : check e2422407448182 [[],[]] .chain = true := by decide
def e2422407448374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407448374 : Closed e2422407448374 ∧ code e2422407448374 = 11218500470582 := by decide
theorem cert_e2422407448374 : check e2422407448374 [[],[]] .chain = true := by decide
def e2422407448378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.lam (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407448378 : Closed e2422407448378 ∧ code e2422407448378 = 11218500470586 := by decide
theorem cert_e2422407448378 : check e2422407448378 [[],[]] .chain = true := by decide
def e2422407449430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2422407449430 : Closed e2422407449430 ∧ code e2422407449430 = 11218500471638 := by decide
theorem cert_e2422407449430 : check e2422407449430 [[],[]] .chain = true := by decide
def e2422407449434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2422407449434 : Closed e2422407449434 ∧ code e2422407449434 = 11218500471642 := by decide
theorem cert_e2422407449434 : check e2422407449434 [[],[]] .chain = true := by decide
def e2422407449450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2422407449450 : Closed e2422407449450 ∧ code e2422407449450 = 11218500471658 := by decide
theorem cert_e2422407449450 : check e2422407449450 [[],[]] .chain = true := by decide
def e2422407449514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0))))))
theorem wire_e2422407449514 : Closed e2422407449514 ∧ code e2422407449514 = 11218500471722 := by decide
theorem cert_e2422407449514 : check e2422407449514 [[],[]] .chain = true := by decide
def e2422407449718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422407449718 : Closed e2422407449718 ∧ code e2422407449718 = 11218500471926 := by decide
theorem cert_e2422407449718 : check e2422407449718 [[],[]] .chain = true := by decide
def e2422407449814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422407449814 : Closed e2422407449814 ∧ code e2422407449814 = 11218500472022 := by decide
theorem cert_e2422407449814 : check e2422407449814 [[],[]] .chain = true := by decide
def e2422407449818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0))))))
theorem wire_e2422407449818 : Closed e2422407449818 ∧ code e2422407449818 = 11218500472026 := by decide
theorem cert_e2422407449818 : check e2422407449818 [[],[]] .chain = true := by decide
def e2422407449834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0))))))
theorem wire_e2422407449834 : Closed e2422407449834 ∧ code e2422407449834 = 11218500472042 := by decide
theorem cert_e2422407449834 : check e2422407449834 [[],[]] .chain = true := by decide
def e2422407449910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422407449910 : Closed e2422407449910 ∧ code e2422407449910 = 11218500472118 := by decide
theorem cert_e2422407449910 : check e2422407449910 [[],[]] .chain = true := by decide
def e2422407449914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422407449914 : Closed e2422407449914 ∧ code e2422407449914 = 11218500472122 := by decide
theorem cert_e2422407449914 : check e2422407449914 [[],[]] .chain = true := by decide
def e2422407449998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422407449998 : Closed e2422407449998 ∧ code e2422407449998 = 11218500472206 := by decide
theorem cert_e2422407449998 : check e2422407449998 [[],[]] .chain = true := by decide
def e2422407450010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0)))))))
theorem wire_e2422407450010 : Closed e2422407450010 ∧ code e2422407450010 = 11218500472218 := by decide
theorem cert_e2422407450010 : check e2422407450010 [[],[]] .chain = true := by decide
def e2422407450166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2422407450166 : Closed e2422407450166 ∧ code e2422407450166 = 11218500472374 := by decide
theorem cert_e2422407450166 : check e2422407450166 [[],[]] .chain = true := by decide
def e2422407450170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2422407450170 : Closed e2422407450170 ∧ code e2422407450170 = 11218500472378 := by decide
theorem cert_e2422407450170 : check e2422407450170 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422407433942
#print axioms Blc.Floor43.cert_e2422407433946
#print axioms Blc.Floor43.cert_e2422407441750
#print axioms Blc.Floor43.cert_e2422407441754
#print axioms Blc.Floor43.cert_e2422407443286
#print axioms Blc.Floor43.cert_e2422407443290
#print axioms Blc.Floor43.cert_e2422407443670
#print axioms Blc.Floor43.cert_e2422407443674
#print axioms Blc.Floor43.cert_e2422407443690
#print axioms Blc.Floor43.cert_e2422407443766
#print axioms Blc.Floor43.cert_e2422407443770
#print axioms Blc.Floor43.cert_e2422407443866
