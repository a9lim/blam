import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373933690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373933690 : Closed e2422373933690 ∧ code e2422373933690 = 11218466955898 := by decide
theorem cert_e2422373933690 : check e2422373933690 [[],[]] .smaller = true := by decide
def e2422373933854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3))))))))
theorem wire_e2422373933854 : Closed e2422373933854 ∧ code e2422373933854 = 11218466956062 := by decide
theorem cert_e2422373933854 : check e2422373933854 [[],[]] .smaller = true := by decide
def e2422373933878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373933878 : Closed e2422373933878 ∧ code e2422373933878 = 11218466956086 := by decide
theorem cert_e2422373933878 : check e2422373933878 [[],[]] .smaller = true := by decide
def e2422373933882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373933882 : Closed e2422373933882 ∧ code e2422373933882 = 11218466956090 := by decide
theorem cert_e2422373933882 : check e2422373933882 [[],[]] .smaller = true := by decide
def e2422373933978 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 2)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373933978 : Closed e2422373933978 ∧ code e2422373933978 = 11218466956186 := by decide
theorem cert_e2422373933978 : check e2422373933978 [[],[]] .smaller = true := by decide
def e2422373934022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1))))))))
theorem wire_e2422373934022 : Closed e2422373934022 ∧ code e2422373934022 = 11218466956230 := by decide
theorem cert_e2422373934022 : check e2422373934022 [[],[]] .smaller = true := by decide
def e2422373934046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 3)))) (.var 3)))))))
theorem wire_e2422373934046 : Closed e2422373934046 ∧ code e2422373934046 = 11218466956254 := by decide
theorem cert_e2422373934046 : check e2422373934046 [[],[]] .three = true := by decide
def e2422373934062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 4)))) (.var 2)))))))
theorem wire_e2422373934062 : Closed e2422373934062 ∧ code e2422373934062 = 11218466956270 := by decide
theorem cert_e2422373934062 : check e2422373934062 [[],[]] .three = true := by decide
def e2422373934506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))) (.var 0)))))))
theorem wire_e2422373934506 : Closed e2422373934506 ∧ code e2422373934506 = 11218466956714 := by decide
theorem cert_e2422373934506 : check e2422373934506 [[],[]] .smaller = true := by decide
def e2422373934602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 0)))))) (.var 0)))))))
theorem wire_e2422373934602 : Closed e2422373934602 ∧ code e2422373934602 = 11218466956810 := by decide
theorem cert_e2422373934602 : check e2422373934602 [[],[]] .smaller = true := by decide
def e2422373934638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2)))))))
theorem wire_e2422373934638 : Closed e2422373934638 ∧ code e2422373934638 = 11218466956846 := by decide
theorem cert_e2422373934638 : check e2422373934638 [[],[]] .smaller = true := by decide
def e2422373934646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.var 1)))))))
theorem wire_e2422373934646 : Closed e2422373934646 ∧ code e2422373934646 = 11218466956854 := by decide
theorem cert_e2422373934646 : check e2422373934646 [[],[]] .smaller = true := by decide
def e2422373934650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373934650 : Closed e2422373934650 ∧ code e2422373934650 = 11218466956858 := by decide
theorem cert_e2422373934650 : check e2422373934650 [[],[]] .smaller = true := by decide
def e2422373934698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373934698 : Closed e2422373934698 ∧ code e2422373934698 = 11218466956906 := by decide
theorem cert_e2422373934698 : check e2422373934698 [[],[]] .smaller = true := by decide
def e2422373934722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.var 0)))))))))
theorem wire_e2422373934722 : Closed e2422373934722 ∧ code e2422373934722 = 11218466956930 := by decide
theorem cert_e2422373934722 : check e2422373934722 [[],[]] .smaller = true := by decide
def e2422373934734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.var 2))))))))
theorem wire_e2422373934734 : Closed e2422373934734 ∧ code e2422373934734 = 11218466956942 := by decide
theorem cert_e2422373934734 : check e2422373934734 [[],[]] .smaller = true := by decide
def e2422373934746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373934746 : Closed e2422373934746 ∧ code e2422373934746 = 11218466956954 := by decide
theorem cert_e2422373934746 : check e2422373934746 [[],[]] .smaller = true := by decide
def e2422373934790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373934790 : Closed e2422373934790 ∧ code e2422373934790 = 11218466956998 := by decide
theorem cert_e2422373934790 : check e2422373934790 [[],[]] .smaller = true := by decide
def e2422373934814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 3)))))))
theorem wire_e2422373934814 : Closed e2422373934814 ∧ code e2422373934814 = 11218466957022 := by decide
theorem cert_e2422373934814 : check e2422373934814 [[],[]] .three = true := by decide
def e2422373934818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0))))))))
theorem wire_e2422373934818 : Closed e2422373934818 ∧ code e2422373934818 = 11218466957026 := by decide
theorem cert_e2422373934818 : check e2422373934818 [[],[]] .smaller = true := by decide
def e2422373934830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2)))))))
theorem wire_e2422373934830 : Closed e2422373934830 ∧ code e2422373934830 = 11218466957038 := by decide
theorem cert_e2422373934830 : check e2422373934830 [[],[]] .smaller = true := by decide
def e2422373934838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 3)))) (.var 1)))))))
theorem wire_e2422373934838 : Closed e2422373934838 ∧ code e2422373934838 = 11218466957046 := by decide
theorem cert_e2422373934838 : check e2422373934838 [[],[]] .three = true := by decide
def e2422373934874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))) (.var 0)))))))
theorem wire_e2422373934874 : Closed e2422373934874 ∧ code e2422373934874 = 11218466957082 := by decide
theorem cert_e2422373934874 : check e2422373934874 [[],[]] .smaller = true := by decide
def e2422373934918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.lam (.var 1))))))))
theorem wire_e2422373934918 : Closed e2422373934918 ∧ code e2422373934918 = 11218466957126 := by decide
theorem cert_e2422373934918 : check e2422373934918 [[],[]] .smaller = true := by decide
def e2422373934942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 3)))))))
theorem wire_e2422373934942 : Closed e2422373934942 ∧ code e2422373934942 = 11218466957150 := by decide
theorem cert_e2422373934942 : check e2422373934942 [[],[]] .three = true := by decide
def e2422373934970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 3)))) (.var 0)))))))
theorem wire_e2422373934970 : Closed e2422373934970 ∧ code e2422373934970 = 11218466957178 := by decide
theorem cert_e2422373934970 : check e2422373934970 [[],[]] .three = true := by decide
def e2422373934986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373934986 : Closed e2422373934986 ∧ code e2422373934986 = 11218466957194 := by decide
theorem cert_e2422373934986 : check e2422373934986 [[],[]] .smaller = true := by decide
def e2422373935010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373935010 : Closed e2422373935010 ∧ code e2422373935010 = 11218466957218 := by decide
theorem cert_e2422373935010 : check e2422373935010 [[],[]] .smaller = true := by decide
def e2422373935022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2)))))))
theorem wire_e2422373935022 : Closed e2422373935022 ∧ code e2422373935022 = 11218466957230 := by decide
theorem cert_e2422373935022 : check e2422373935022 [[],[]] .smaller = true := by decide
def e2422373935034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0)))))))
theorem wire_e2422373935034 : Closed e2422373935034 ∧ code e2422373935034 = 11218466957242 := by decide
theorem cert_e2422373935034 : check e2422373935034 [[],[]] .smaller = true := by decide
def e2422373935062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 0)))) (.var 1)))))))
theorem wire_e2422373935062 : Closed e2422373935062 ∧ code e2422373935062 = 11218466957270 := by decide
theorem cert_e2422373935062 : check e2422373935062 [[],[]] .three = true := by decide
def e2422373935066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.app (.var 3) (.var 1)))) (.var 0)))))))
theorem wire_e2422373935066 : Closed e2422373935066 ∧ code e2422373935066 = 11218466957274 := by decide
theorem cert_e2422373935066 : check e2422373935066 [[],[]] .three = true := by decide
def e2422373935130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373935130 : Closed e2422373935130 ∧ code e2422373935130 = 11218466957338 := by decide
theorem cert_e2422373935130 : check e2422373935130 [[],[]] .smaller = true := by decide
def e2422373935166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4)))))))))
theorem wire_e2422373935166 : Closed e2422373935166 ∧ code e2422373935166 = 11218466957374 := by decide
theorem cert_e2422373935166 : check e2422373935166 [[],[]] .smaller = true := by decide
def e2422373935214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373935214 : Closed e2422373935214 ∧ code e2422373935214 = 11218466957422 := by decide
theorem cert_e2422373935214 : check e2422373935214 [[],[]] .smaller = true := by decide
def e2422373935222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 1) (.var 1)))))))))
theorem wire_e2422373935222 : Closed e2422373935222 ∧ code e2422373935222 = 11218466957430 := by decide
theorem cert_e2422373935222 : check e2422373935222 [[],[]] .smaller = true := by decide
def e2422373935226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373935226 : Closed e2422373935226 ∧ code e2422373935226 = 11218466957434 := by decide
theorem cert_e2422373935226 : check e2422373935226 [[],[]] .smaller = true := by decide
def e2422373935466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 0))))))))
theorem wire_e2422373935466 : Closed e2422373935466 ∧ code e2422373935466 = 11218466957674 := by decide
theorem cert_e2422373935466 : check e2422373935466 [[],[]] .smaller = true := by decide
def e2422373935490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373935490 : Closed e2422373935490 ∧ code e2422373935490 = 11218466957698 := by decide
theorem cert_e2422373935490 : check e2422373935490 [[],[]] .smaller = true := by decide
def e2422373935502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2422373935502 : Closed e2422373935502 ∧ code e2422373935502 = 11218466957710 := by decide
theorem cert_e2422373935502 : check e2422373935502 [[],[]] .smaller = true := by decide
def e2422373935514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 0) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373935514 : Closed e2422373935514 ∧ code e2422373935514 = 11218466957722 := by decide
theorem cert_e2422373935514 : check e2422373935514 [[],[]] .smaller = true := by decide
def e2422373935558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2422373935558 : Closed e2422373935558 ∧ code e2422373935558 = 11218466957766 := by decide
theorem cert_e2422373935558 : check e2422373935558 [[],[]] .smaller = true := by decide
def e2422373935582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 3))))))))
theorem wire_e2422373935582 : Closed e2422373935582 ∧ code e2422373935582 = 11218466957790 := by decide
theorem cert_e2422373935582 : check e2422373935582 [[],[]] .three = true := by decide
def e2422373935586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2422373935586 : Closed e2422373935586 ∧ code e2422373935586 = 11218466957794 := by decide
theorem cert_e2422373935586 : check e2422373935586 [[],[]] .smaller = true := by decide
def e2422373935598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2))))))))
theorem wire_e2422373935598 : Closed e2422373935598 ∧ code e2422373935598 = 11218466957806 := by decide
theorem cert_e2422373935598 : check e2422373935598 [[],[]] .smaller = true := by decide
def e2422373935606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.app (.var 3) (.var 1))))))))
theorem wire_e2422373935606 : Closed e2422373935606 ∧ code e2422373935606 = 11218466957814 := by decide
theorem cert_e2422373935606 : check e2422373935606 [[],[]] .three = true := by decide
def e2422373936182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373936182 : Closed e2422373936182 ∧ code e2422373936182 = 11218466958390 := by decide
theorem cert_e2422373936182 : check e2422373936182 [[],[]] .smaller = true := by decide
def e2422373936186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373936186 : Closed e2422373936186 ∧ code e2422373936186 = 11218466958394 := by decide
theorem cert_e2422373936186 : check e2422373936186 [[],[]] .smaller = true := by decide
def e2422373936326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2422373936326 : Closed e2422373936326 ∧ code e2422373936326 = 11218466958534 := by decide
theorem cert_e2422373936326 : check e2422373936326 [[],[]] .smaller = true := by decide
def e2422373936350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373936350 : Closed e2422373936350 ∧ code e2422373936350 = 11218466958558 := by decide
theorem cert_e2422373936350 : check e2422373936350 [[],[]] .three = true := by decide
def e2422373936378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373936378 : Closed e2422373936378 ∧ code e2422373936378 = 11218466958586 := by decide
theorem cert_e2422373936378 : check e2422373936378 [[],[]] .three = true := by decide
def e2422373936654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373936654 : Closed e2422373936654 ∧ code e2422373936654 = 11218466958862 := by decide
theorem cert_e2422373936654 : check e2422373936654 [[],[]] .smaller = true := by decide
def e2422373936702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.lam (.var 4))))))))
theorem wire_e2422373936702 : Closed e2422373936702 ∧ code e2422373936702 = 11218466958910 := by decide
theorem cert_e2422373936702 : check e2422373936702 [[],[]] .three = true := by decide
def e2422373936738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373936738 : Closed e2422373936738 ∧ code e2422373936738 = 11218466958946 := by decide
theorem cert_e2422373936738 : check e2422373936738 [[],[]] .smaller = true := by decide
def e2422373936750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373936750 : Closed e2422373936750 ∧ code e2422373936750 = 11218466958958 := by decide
theorem cert_e2422373936750 : check e2422373936750 [[],[]] .smaller = true := by decide
def e2422373936762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373936762 : Closed e2422373936762 ∧ code e2422373936762 = 11218466958970 := by decide
theorem cert_e2422373936762 : check e2422373936762 [[],[]] .smaller = true := by decide
def e2422373936926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.lam (.var 3))))))))
theorem wire_e2422373936926 : Closed e2422373936926 ∧ code e2422373936926 = 11218466959134 := by decide
theorem cert_e2422373936926 : check e2422373936926 [[],[]] .three = true := by decide
def e2422373936950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373936950 : Closed e2422373936950 ∧ code e2422373936950 = 11218466959158 := by decide
theorem cert_e2422373936950 : check e2422373936950 [[],[]] .three = true := by decide
def e2422373936954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 3))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373936954 : Closed e2422373936954 ∧ code e2422373936954 = 11218466959162 := by decide
theorem cert_e2422373936954 : check e2422373936954 [[],[]] .three = true := by decide
def e2422373937270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1)))))))
theorem wire_e2422373937270 : Closed e2422373937270 ∧ code e2422373937270 = 11218466959478 := by decide
theorem cert_e2422373937270 : check e2422373937270 [[],[]] .smaller = true := by decide
def e2422373937274 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0)))))))
theorem wire_e2422373937274 : Closed e2422373937274 ∧ code e2422373937274 = 11218466959482 := by decide
theorem cert_e2422373937274 : check e2422373937274 [[],[]] .smaller = true := by decide
def e2422373937462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373937462 : Closed e2422373937462 ∧ code e2422373937462 = 11218466959670 := by decide
theorem cert_e2422373937462 : check e2422373937462 [[],[]] .smaller = true := by decide
def e2422373937466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373937466 : Closed e2422373937466 ∧ code e2422373937466 = 11218466959674 := by decide
theorem cert_e2422373937466 : check e2422373937466 [[],[]] .smaller = true := by decide
def e2422373937550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2))))))))
theorem wire_e2422373937550 : Closed e2422373937550 ∧ code e2422373937550 = 11218466959758 := by decide
theorem cert_e2422373937550 : check e2422373937550 [[],[]] .smaller = true := by decide
def e2422373937606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1))))))))
theorem wire_e2422373937606 : Closed e2422373937606 ∧ code e2422373937606 = 11218466959814 := by decide
theorem cert_e2422373937606 : check e2422373937606 [[],[]] .smaller = true := by decide
def e2422373937630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 2)))) (.var 3)))))))
theorem wire_e2422373937630 : Closed e2422373937630 ∧ code e2422373937630 = 11218466959838 := by decide
theorem cert_e2422373937630 : check e2422373937630 [[],[]] .three = true := by decide
def e2422373937654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.lam (.var 4)))) (.var 1)))))))
theorem wire_e2422373937654 : Closed e2422373937654 ∧ code e2422373937654 = 11218466959862 := by decide
theorem cert_e2422373937654 : check e2422373937654 [[],[]] .three = true := by decide
def e2422373937942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1)))))))
theorem wire_e2422373937942 : Closed e2422373937942 ∧ code e2422373937942 = 11218466960150 := by decide
theorem cert_e2422373937942 : check e2422373937942 [[],[]] .smaller = true := by decide
def e2422373938014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 3)))))))
theorem wire_e2422373938014 : Closed e2422373938014 ∧ code e2422373938014 = 11218466960222 := by decide
theorem cert_e2422373938014 : check e2422373938014 [[],[]] .three = true := by decide
def e2422373938018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0))))))))
theorem wire_e2422373938018 : Closed e2422373938018 ∧ code e2422373938018 = 11218466960226 := by decide
theorem cert_e2422373938018 : check e2422373938018 [[],[]] .smaller = true := by decide
def e2422373938030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2)))))))
theorem wire_e2422373938030 : Closed e2422373938030 ∧ code e2422373938030 = 11218466960238 := by decide
theorem cert_e2422373938030 : check e2422373938030 [[],[]] .smaller = true := by decide
def e2422373938038 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1)))))))
theorem wire_e2422373938038 : Closed e2422373938038 ∧ code e2422373938038 = 11218466960246 := by decide
theorem cert_e2422373938038 : check e2422373938038 [[],[]] .smaller = true := by decide
def e2422373938042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 3)))) (.var 0)))))))
theorem wire_e2422373938042 : Closed e2422373938042 ∧ code e2422373938042 = 11218466960250 := by decide
theorem cert_e2422373938042 : check e2422373938042 [[],[]] .three = true := by decide
def e2422373938058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373938058 : Closed e2422373938058 ∧ code e2422373938058 = 11218466960266 := by decide
theorem cert_e2422373938058 : check e2422373938058 [[],[]] .smaller = true := by decide
def e2422373938082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373938082 : Closed e2422373938082 ∧ code e2422373938082 = 11218466960290 := by decide
theorem cert_e2422373938082 : check e2422373938082 [[],[]] .smaller = true := by decide
def e2422373938094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2)))))))
theorem wire_e2422373938094 : Closed e2422373938094 ∧ code e2422373938094 = 11218466960302 := by decide
theorem cert_e2422373938094 : check e2422373938094 [[],[]] .smaller = true := by decide
def e2422373938106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0)))))))
theorem wire_e2422373938106 : Closed e2422373938106 ∧ code e2422373938106 = 11218466960314 := by decide
theorem cert_e2422373938106 : check e2422373938106 [[],[]] .smaller = true := by decide
def e2422373938134 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1)))))))
theorem wire_e2422373938134 : Closed e2422373938134 ∧ code e2422373938134 = 11218466960342 := by decide
theorem cert_e2422373938134 : check e2422373938134 [[],[]] .smaller = true := by decide
def e2422373938138 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0)))))))
theorem wire_e2422373938138 : Closed e2422373938138 ∧ code e2422373938138 = 11218466960346 := by decide
theorem cert_e2422373938138 : check e2422373938138 [[],[]] .smaller = true := by decide
def e2422373938154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.app (.var 3) (.var 0)))) (.var 0)))))))
theorem wire_e2422373938154 : Closed e2422373938154 ∧ code e2422373938154 = 11218466960362 := by decide
theorem cert_e2422373938154 : check e2422373938154 [[],[]] .three = true := by decide
def e2422373938206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3)))))))))
theorem wire_e2422373938206 : Closed e2422373938206 ∧ code e2422373938206 = 11218466960414 := by decide
theorem cert_e2422373938206 : check e2422373938206 [[],[]] .smaller = true := by decide
def e2422373938398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373938398 : Closed e2422373938398 ∧ code e2422373938398 = 11218466960606 := by decide
theorem cert_e2422373938398 : check e2422373938398 [[],[]] .three = true := by decide
def e2422373938402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2422373938402 : Closed e2422373938402 ∧ code e2422373938402 = 11218466960610 := by decide
theorem cert_e2422373938402 : check e2422373938402 [[],[]] .smaller = true := by decide
def e2422373938414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373938414 : Closed e2422373938414 ∧ code e2422373938414 = 11218466960622 := by decide
theorem cert_e2422373938414 : check e2422373938414 [[],[]] .smaller = true := by decide
def e2422373938422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373938422 : Closed e2422373938422 ∧ code e2422373938422 = 11218466960630 := by decide
theorem cert_e2422373938422 : check e2422373938422 [[],[]] .smaller = true := by decide
def e2422373938426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373938426 : Closed e2422373938426 ∧ code e2422373938426 = 11218466960634 := by decide
theorem cert_e2422373938426 : check e2422373938426 [[],[]] .three = true := by decide
def e2422373938702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373938702 : Closed e2422373938702 ∧ code e2422373938702 = 11218466960910 := by decide
theorem cert_e2422373938702 : check e2422373938702 [[],[]] .smaller = true := by decide
def e2422373938750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.lam (.var 4))))))))
theorem wire_e2422373938750 : Closed e2422373938750 ∧ code e2422373938750 = 11218466960958 := by decide
theorem cert_e2422373938750 : check e2422373938750 [[],[]] .three = true := by decide
def e2422373938786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373938786 : Closed e2422373938786 ∧ code e2422373938786 = 11218466960994 := by decide
theorem cert_e2422373938786 : check e2422373938786 [[],[]] .smaller = true := by decide
def e2422373938798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373938798 : Closed e2422373938798 ∧ code e2422373938798 = 11218466961006 := by decide
theorem cert_e2422373938798 : check e2422373938798 [[],[]] .smaller = true := by decide
def e2422373938810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373938810 : Closed e2422373938810 ∧ code e2422373938810 = 11218466961018 := by decide
theorem cert_e2422373938810 : check e2422373938810 [[],[]] .smaller = true := by decide
def e2422373938998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373938998 : Closed e2422373938998 ∧ code e2422373938998 = 11218466961206 := by decide
theorem cert_e2422373938998 : check e2422373938998 [[],[]] .smaller = true := by decide
def e2422373939002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373939002 : Closed e2422373939002 ∧ code e2422373939002 = 11218466961210 := by decide
theorem cert_e2422373939002 : check e2422373939002 [[],[]] .smaller = true := by decide
def e2422373939086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.lam (.var 2))))))))
theorem wire_e2422373939086 : Closed e2422373939086 ∧ code e2422373939086 = 11218466961294 := by decide
theorem cert_e2422373939086 : check e2422373939086 [[],[]] .three = true := by decide
def e2422373939098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 3))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373939098 : Closed e2422373939098 ∧ code e2422373939098 = 11218466961306 := by decide
theorem cert_e2422373939098 : check e2422373939098 [[],[]] .three = true := by decide
def e2422373939258 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.lam (.var 2))))) (.var 0)))))))
theorem wire_e2422373939258 : Closed e2422373939258 ∧ code e2422373939258 = 11218466961466 := by decide
theorem cert_e2422373939258 : check e2422373939258 [[],[]] .three = true := by decide
def e2422373939306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.app (.var 0) (.var 0))))) (.var 0)))))))
theorem wire_e2422373939306 : Closed e2422373939306 ∧ code e2422373939306 = 11218466961514 := by decide
theorem cert_e2422373939306 : check e2422373939306 [[],[]] .three = true := by decide
def e2422373939354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 0)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373939354 : Closed e2422373939354 ∧ code e2422373939354 = 11218466961562 := by decide
theorem cert_e2422373939354 : check e2422373939354 [[],[]] .three = true := by decide
def e2422373939398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 1)))) (.lam (.var 1))))))))
theorem wire_e2422373939398 : Closed e2422373939398 ∧ code e2422373939398 = 11218466961606 := by decide
theorem cert_e2422373939398 : check e2422373939398 [[],[]] .three = true := by decide
def e2422373939422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 1)))) (.var 3)))))))
theorem wire_e2422373939422 : Closed e2422373939422 ∧ code e2422373939422 = 11218466961630 := by decide
theorem cert_e2422373939422 : check e2422373939422 [[],[]] .three = true := by decide
def e2422373939438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 2)))) (.var 2)))))))
theorem wire_e2422373939438 : Closed e2422373939438 ∧ code e2422373939438 = 11218466961646 := by decide
theorem cert_e2422373939438 : check e2422373939438 [[],[]] .three = true := by decide
def e2422373939446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 3)))) (.var 1)))))))
theorem wire_e2422373939446 : Closed e2422373939446 ∧ code e2422373939446 = 11218466961654 := by decide
theorem cert_e2422373939446 : check e2422373939446 [[],[]] .three = true := by decide
def e2422373939450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.lam (.var 4)))) (.var 0)))))))
theorem wire_e2422373939450 : Closed e2422373939450 ∧ code e2422373939450 = 11218466961658 := by decide
theorem cert_e2422373939450 : check e2422373939450 [[],[]] .three = true := by decide
def e2422373939594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))) (.var 0)))))))
theorem wire_e2422373939594 : Closed e2422373939594 ∧ code e2422373939594 = 11218466961802 := by decide
theorem cert_e2422373939594 : check e2422373939594 [[],[]] .three = true := by decide
def e2422373939618 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))) (.lam (.var 0))))))))
theorem wire_e2422373939618 : Closed e2422373939618 ∧ code e2422373939618 = 11218466961826 := by decide
theorem cert_e2422373939618 : check e2422373939618 [[],[]] .three = true := by decide
def e2422373939630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 0)))) (.var 2)))))))
theorem wire_e2422373939630 : Closed e2422373939630 ∧ code e2422373939630 = 11218466961838 := by decide
theorem cert_e2422373939630 : check e2422373939630 [[],[]] .three = true := by decide
def e2422373939638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 1)))) (.var 1)))))))
theorem wire_e2422373939638 : Closed e2422373939638 ∧ code e2422373939638 = 11218466961846 := by decide
theorem cert_e2422373939638 : check e2422373939638 [[],[]] .three = true := by decide
def e2422373939642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 0) (.var 2)))) (.var 0)))))))
theorem wire_e2422373939642 : Closed e2422373939642 ∧ code e2422373939642 = 11218466961850 := by decide
theorem cert_e2422373939642 : check e2422373939642 [[],[]] .three = true := by decide
def e2422373939670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 0)))) (.var 1)))))))
theorem wire_e2422373939670 : Closed e2422373939670 ∧ code e2422373939670 = 11218466961878 := by decide
theorem cert_e2422373939670 : check e2422373939670 [[],[]] .three = true := by decide
def e2422373939674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 1) (.var 1)))) (.var 0)))))))
theorem wire_e2422373939674 : Closed e2422373939674 ∧ code e2422373939674 = 11218466961882 := by decide
theorem cert_e2422373939674 : check e2422373939674 [[],[]] .three = true := by decide
def e2422373939690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.app (.var 2) (.var 0)))) (.var 0)))))))
theorem wire_e2422373939690 : Closed e2422373939690 ∧ code e2422373939690 = 11218466961898 := by decide
theorem cert_e2422373939690 : check e2422373939690 [[],[]] .three = true := by decide
def e2422373939726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.lam (.var 2)))))))))
theorem wire_e2422373939726 : Closed e2422373939726 ∧ code e2422373939726 = 11218466961934 := by decide
theorem cert_e2422373939726 : check e2422373939726 [[],[]] .three = true := by decide
def e2422373939738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373939738 : Closed e2422373939738 ∧ code e2422373939738 = 11218466961946 := by decide
theorem cert_e2422373939738 : check e2422373939738 [[],[]] .three = true := by decide
def e2422373939774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.lam (.var 4))))))))
theorem wire_e2422373939774 : Closed e2422373939774 ∧ code e2422373939774 = 11218466961982 := by decide
theorem cert_e2422373939774 : check e2422373939774 [[],[]] .three = true := by decide
def e2422373939810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2422373939810 : Closed e2422373939810 ∧ code e2422373939810 = 11218466962018 := by decide
theorem cert_e2422373939810 : check e2422373939810 [[],[]] .three = true := by decide
def e2422373939822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373939822 : Closed e2422373939822 ∧ code e2422373939822 = 11218466962030 := by decide
theorem cert_e2422373939822 : check e2422373939822 [[],[]] .three = true := by decide
def e2422373939830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 1) (.var 1))))))))
theorem wire_e2422373939830 : Closed e2422373939830 ∧ code e2422373939830 = 11218466962038 := by decide
theorem cert_e2422373939830 : check e2422373939830 [[],[]] .three = true := by decide
def e2422373939834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373939834 : Closed e2422373939834 ∧ code e2422373939834 = 11218466962042 := by decide
theorem cert_e2422373939834 : check e2422373939834 [[],[]] .three = true := by decide
def e2422373939998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.lam (.var 3))))))))
theorem wire_e2422373939998 : Closed e2422373939998 ∧ code e2422373939998 = 11218466962206 := by decide
theorem cert_e2422373939998 : check e2422373939998 [[],[]] .three = true := by decide
def e2422373940022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373940022 : Closed e2422373940022 ∧ code e2422373940022 = 11218466962230 := by decide
theorem cert_e2422373940022 : check e2422373940022 [[],[]] .three = true := by decide
def e2422373940026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 1))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373940026 : Closed e2422373940026 ∧ code e2422373940026 = 11218466962234 := by decide
theorem cert_e2422373940026 : check e2422373940026 [[],[]] .three = true := by decide
def e2422373940110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.lam (.var 2))))))))
theorem wire_e2422373940110 : Closed e2422373940110 ∧ code e2422373940110 = 11218466962318 := by decide
theorem cert_e2422373940110 : check e2422373940110 [[],[]] .three = true := by decide
def e2422373940122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 2))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373940122 : Closed e2422373940122 ∧ code e2422373940122 = 11218466962330 := by decide
theorem cert_e2422373940122 : check e2422373940122 [[],[]] .three = true := by decide
def e2422373940166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 3))) (.lam (.var 1))))))))
theorem wire_e2422373940166 : Closed e2422373940166 ∧ code e2422373940166 = 11218466962374 := by decide
theorem cert_e2422373940166 : check e2422373940166 [[],[]] .three = true := by decide
def e2422373942238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e2422373942238 : Closed e2422373942238 ∧ code e2422373942238 = 11218466964446 := by decide
theorem cert_e2422373942238 : check e2422373942238 [[],[]] .smaller = true := by decide
def e2422373942254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e2422373942254 : Closed e2422373942254 ∧ code e2422373942254 = 11218466964462 := by decide
theorem cert_e2422373942254 : check e2422373942254 [[],[]] .smaller = true := by decide
def e2422373944174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2422373944174 : Closed e2422373944174 ∧ code e2422373944174 = 11218466966382 := by decide
theorem cert_e2422373944174 : check e2422373944174 [[],[]] .smaller = true := by decide
def e2422373944182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2422373944182 : Closed e2422373944182 ∧ code e2422373944182 = 11218466966390 := by decide
theorem cert_e2422373944182 : check e2422373944182 [[],[]] .smaller = true := by decide
def e2422373944238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2422373944238 : Closed e2422373944238 ∧ code e2422373944238 = 11218466966446 := by decide
theorem cert_e2422373944238 : check e2422373944238 [[],[]] .smaller = true := by decide
def e2422373944250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2422373944250 : Closed e2422373944250 ∧ code e2422373944250 = 11218466966458 := by decide
theorem cert_e2422373944250 : check e2422373944250 [[],[]] .smaller = true := by decide
def e2422373944278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2422373944278 : Closed e2422373944278 ∧ code e2422373944278 = 11218466966486 := by decide
theorem cert_e2422373944278 : check e2422373944278 [[],[]] .smaller = true := by decide
def e2422373944282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2422373944282 : Closed e2422373944282 ∧ code e2422373944282 = 11218466966490 := by decide
theorem cert_e2422373944282 : check e2422373944282 [[],[]] .smaller = true := by decide
def e2422373944558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422373944558 : Closed e2422373944558 ∧ code e2422373944558 = 11218466966766 := by decide
theorem cert_e2422373944558 : check e2422373944558 [[],[]] .smaller = true := by decide
def e2422373944566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422373944566 : Closed e2422373944566 ∧ code e2422373944566 = 11218466966774 := by decide
theorem cert_e2422373944566 : check e2422373944566 [[],[]] .smaller = true := by decide
def e2422373944942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373944942 : Closed e2422373944942 ∧ code e2422373944942 = 11218466967150 := by decide
theorem cert_e2422373944942 : check e2422373944942 [[],[]] .smaller = true := by decide
def e2422373944954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373944954 : Closed e2422373944954 ∧ code e2422373944954 = 11218466967162 := by decide
theorem cert_e2422373944954 : check e2422373944954 [[],[]] .smaller = true := by decide
def e2422373945118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.lam (.var 3))))))))))
theorem wire_e2422373945118 : Closed e2422373945118 ∧ code e2422373945118 = 11218466967326 := by decide
theorem cert_e2422373945118 : check e2422373945118 [[],[]] .smaller = true := by decide
def e2422373945142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373945142 : Closed e2422373945142 ∧ code e2422373945142 = 11218466967350 := by decide
theorem cert_e2422373945142 : check e2422373945142 [[],[]] .smaller = true := by decide
def e2422373945146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373945146 : Closed e2422373945146 ∧ code e2422373945146 = 11218466967354 := by decide
theorem cert_e2422373945146 : check e2422373945146 [[],[]] .smaller = true := by decide
def e2422373945278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 3) (.var 4)))))))))
theorem wire_e2422373945278 : Closed e2422373945278 ∧ code e2422373945278 = 11218466967486 := by decide
theorem cert_e2422373945278 : check e2422373945278 [[],[]] .three = true := by decide
def e2422373945310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.app (.var 4) (.var 3)))))))))
theorem wire_e2422373945310 : Closed e2422373945310 ∧ code e2422373945310 = 11218466967518 := by decide
theorem cert_e2422373945310 : check e2422373945310 [[],[]] .three = true := by decide
def e2422373952342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2422373952342 : Closed e2422373952342 ∧ code e2422373952342 = 11218466974550 := by decide
theorem cert_e2422373952342 : check e2422373952342 [[],[]] .smaller = true := by decide
def e2422373952346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2422373952346 : Closed e2422373952346 ∧ code e2422373952346 = 11218466974554 := by decide
theorem cert_e2422373952346 : check e2422373952346 [[],[]] .smaller = true := by decide
def e2422373952362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2422373952362 : Closed e2422373952362 ∧ code e2422373952362 = 11218466974570 := by decide
theorem cert_e2422373952362 : check e2422373952362 [[],[]] .smaller = true := by decide
def e2422373952426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422373952426 : Closed e2422373952426 ∧ code e2422373952426 = 11218466974634 := by decide
theorem cert_e2422373952426 : check e2422373952426 [[],[]] .smaller = true := by decide
def e2422373952534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 1))))))))
theorem wire_e2422373952534 : Closed e2422373952534 ∧ code e2422373952534 = 11218466974742 := by decide
theorem cert_e2422373952534 : check e2422373952534 [[],[]] .smaller = true := by decide
def e2422373952606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 3))))))))
theorem wire_e2422373952606 : Closed e2422373952606 ∧ code e2422373952606 = 11218466974814 := by decide
theorem cert_e2422373952606 : check e2422373952606 [[],[]] .three = true := by decide
def e2422373952630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e2422373952630 : Closed e2422373952630 ∧ code e2422373952630 = 11218466974838 := by decide
theorem cert_e2422373952630 : check e2422373952630 [[],[]] .smaller = true := by decide
def e2422373952726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e2422373952726 : Closed e2422373952726 ∧ code e2422373952726 = 11218466974934 := by decide
theorem cert_e2422373952726 : check e2422373952726 [[],[]] .smaller = true := by decide
def e2422373952730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e2422373952730 : Closed e2422373952730 ∧ code e2422373952730 = 11218466974938 := by decide
theorem cert_e2422373952730 : check e2422373952730 [[],[]] .smaller = true := by decide
def e2422373952746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e2422373952746 : Closed e2422373952746 ∧ code e2422373952746 = 11218466974954 := by decide
theorem cert_e2422373952746 : check e2422373952746 [[],[]] .smaller = true := by decide
def e2422373952822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373952822 : Closed e2422373952822 ∧ code e2422373952822 = 11218466975030 := by decide
theorem cert_e2422373952822 : check e2422373952822 [[],[]] .smaller = true := by decide
def e2422373952826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373952826 : Closed e2422373952826 ∧ code e2422373952826 = 11218466975034 := by decide
theorem cert_e2422373952826 : check e2422373952826 [[],[]] .smaller = true := by decide
def e2422373952898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373952898 : Closed e2422373952898 ∧ code e2422373952898 = 11218466975106 := by decide
theorem cert_e2422373952898 : check e2422373952898 [[],[]] .smaller = true := by decide
def e2422373952910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e2422373952910 : Closed e2422373952910 ∧ code e2422373952910 = 11218466975118 := by decide
theorem cert_e2422373952910 : check e2422373952910 [[],[]] .smaller = true := by decide
def e2422373952922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373952922 : Closed e2422373952922 ∧ code e2422373952922 = 11218466975130 := by decide
theorem cert_e2422373952922 : check e2422373952922 [[],[]] .smaller = true := by decide
def e2422373952990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2422373952990 : Closed e2422373952990 ∧ code e2422373952990 = 11218466975198 := by decide
theorem cert_e2422373952990 : check e2422373952990 [[],[]] .three = true := by decide
def e2422373952994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422373952994 : Closed e2422373952994 ∧ code e2422373952994 = 11218466975202 := by decide
theorem cert_e2422373952994 : check e2422373952994 [[],[]] .three = true := by decide
def e2422373953006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2422373953006 : Closed e2422373953006 ∧ code e2422373953006 = 11218466975214 := by decide
theorem cert_e2422373953006 : check e2422373953006 [[],[]] .three = true := by decide
def e2422373953034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.app (.var 1) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422373953034 : Closed e2422373953034 ∧ code e2422373953034 = 11218466975242 := by decide
theorem cert_e2422373953034 : check e2422373953034 [[],[]] .smaller = true := by decide
end Blc.Floor43
