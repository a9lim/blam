import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598477271838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598477271838 : Closed e598477271838 ∧ code e598477271838 = 9394570294046 := by decide
theorem cert_e598477271838 : check e598477271838 [[.under],[.under,.left]] .chain = true := by decide
def e598477272006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598477272006 : Closed e598477272006 ∧ code e598477272006 = 9394570294214 := by decide
theorem cert_e598477272006 : check e598477272006 [[.under],[.under,.left]] .chain = true := by decide
def e598477273486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598477273486 : Closed e598477273486 ∧ code e598477273486 = 9394570295694 := by decide
theorem cert_e598477273486 : check e598477273486 [[.under],[.under,.left]] .chain = true := by decide
def e598477273542 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598477273542 : Closed e598477273542 ∧ code e598477273542 = 9394570295750 := by decide
theorem cert_e598477273542 : check e598477273542 [[.under],[.under,.left]] .chain = true := by decide
def e598477310830 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e598477310830 : Closed e598477310830 ∧ code e598477310830 = 9394570333038 := by decide
theorem cert_e598477310830 : check e598477310830 [[.under],[.under,.left]] .smaller = true := by decide
def e598477310838 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e598477310838 : Closed e598477310838 ∧ code e598477310838 = 9394570333046 := by decide
theorem cert_e598477310838 : check e598477310838 [[.under],[.under,.left]] .smaller = true := by decide
def e598477310894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e598477310894 : Closed e598477310894 ∧ code e598477310894 = 9394570333102 := by decide
theorem cert_e598477310894 : check e598477310894 [[.under],[.under,.left]] .smaller = true := by decide
def e598477310906 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e598477310906 : Closed e598477310906 ∧ code e598477310906 = 9394570333114 := by decide
theorem cert_e598477310906 : check e598477310906 [[.under],[.under,.left]] .smaller = true := by decide
def e598477310934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e598477310934 : Closed e598477310934 ∧ code e598477310934 = 9394570333142 := by decide
theorem cert_e598477310934 : check e598477310934 [[.under],[.under,.left]] .smaller = true := by decide
def e598477310938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e598477310938 : Closed e598477310938 ∧ code e598477310938 = 9394570333146 := by decide
theorem cert_e598477310938 : check e598477310938 [[.under],[.under,.left]] .smaller = true := by decide
def e598477311214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e598477311214 : Closed e598477311214 ∧ code e598477311214 = 9394570333422 := by decide
theorem cert_e598477311214 : check e598477311214 [[.under],[.under,.left]] .smaller = true := by decide
def e598477311222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e598477311222 : Closed e598477311222 ∧ code e598477311222 = 9394570333430 := by decide
theorem cert_e598477311222 : check e598477311222 [[.under],[.under,.left]] .smaller = true := by decide
def e598477311598 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e598477311598 : Closed e598477311598 ∧ code e598477311598 = 9394570333806 := by decide
theorem cert_e598477311598 : check e598477311598 [[.under],[.under,.left]] .smaller = true := by decide
def e598477311610 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e598477311610 : Closed e598477311610 ∧ code e598477311610 = 9394570333818 := by decide
theorem cert_e598477311610 : check e598477311610 [[.under],[.under,.left]] .smaller = true := by decide
def e598477311798 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e598477311798 : Closed e598477311798 ∧ code e598477311798 = 9394570334006 := by decide
theorem cert_e598477311798 : check e598477311798 [[.under],[.under,.left]] .smaller = true := by decide
def e598477311802 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e598477311802 : Closed e598477311802 ∧ code e598477311802 = 9394570334010 := by decide
theorem cert_e598477311802 : check e598477311802 [[.under],[.under,.left]] .smaller = true := by decide
def e598477319278 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598477319278 : Closed e598477319278 ∧ code e598477319278 = 9394570341486 := by decide
theorem cert_e598477319278 : check e598477319278 [[.under],[.under,.left]] .chain = true := by decide
def e598477319290 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598477319290 : Closed e598477319290 ∧ code e598477319290 = 9394570341498 := by decide
theorem cert_e598477319290 : check e598477319290 [[.under],[.under,.left]] .chain = true := by decide
def e598477319454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598477319454 : Closed e598477319454 ∧ code e598477319454 = 9394570341662 := by decide
theorem cert_e598477319454 : check e598477319454 [[.under],[.under,.left]] .chain = true := by decide
def e598477319622 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598477319622 : Closed e598477319622 ∧ code e598477319622 = 9394570341830 := by decide
theorem cert_e598477319622 : check e598477319622 [[.under],[.under,.left]] .chain = true := by decide
def e598477319962 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e598477319962 : Closed e598477319962 ∧ code e598477319962 = 9394570342170 := by decide
theorem cert_e598477319962 : check e598477319962 [[.under],[.under,.left]] .chain = true := by decide
def e598477320006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e598477320006 : Closed e598477320006 ∧ code e598477320006 = 9394570342214 := by decide
theorem cert_e598477320006 : check e598477320006 [[.under],[.under,.left]] .chain = true := by decide
def e598477320990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598477320990 : Closed e598477320990 ∧ code e598477320990 = 9394570343198 := by decide
theorem cert_e598477320990 : check e598477320990 [[.under],[.under,.left]] .chain = true := by decide
def e598477321158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598477321158 : Closed e598477321158 ∧ code e598477321158 = 9394570343366 := by decide
theorem cert_e598477321158 : check e598477321158 [[.under],[.under,.left]] .chain = true := by decide
def e598477323462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e598477323462 : Closed e598477323462 ∧ code e598477323462 = 9394570345670 := by decide
theorem cert_e598477323462 : check e598477323462 [[.under],[.under,.left]] .chain = true := by decide
def e598477346358 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598477346358 : Closed e598477346358 ∧ code e598477346358 = 9394570368566 := by decide
theorem cert_e598477346358 : check e598477346358 [[.under],[.under,.left]] .chain = true := by decide
def e598477346362 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598477346362 : Closed e598477346362 ∧ code e598477346362 = 9394570368570 := by decide
theorem cert_e598477346362 : check e598477346362 [[.under],[.under,.left]] .chain = true := by decide
def e598477346446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598477346446 : Closed e598477346446 ∧ code e598477346446 = 9394570368654 := by decide
theorem cert_e598477346446 : check e598477346446 [[.under],[.under,.left]] .chain = true := by decide
def e598477346502 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598477346502 : Closed e598477346502 ∧ code e598477346502 = 9394570368710 := by decide
theorem cert_e598477346502 : check e598477346502 [[.under],[.under,.left]] .chain = true := by decide
def e598477346586 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e598477346586 : Closed e598477346586 ∧ code e598477346586 = 9394570368794 := by decide
theorem cert_e598477346586 : check e598477346586 [[.under],[.under,.left]] .chain = true := by decide
def e598477346630 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e598477346630 : Closed e598477346630 ∧ code e598477346630 = 9394570368838 := by decide
theorem cert_e598477346630 : check e598477346630 [[.under],[.under,.left]] .chain = true := by decide
def e598477347214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598477347214 : Closed e598477347214 ∧ code e598477347214 = 9394570369422 := by decide
theorem cert_e598477347214 : check e598477347214 [[.under],[.under,.left]] .chain = true := by decide
def e598477347270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598477347270 : Closed e598477347270 ∧ code e598477347270 = 9394570369478 := by decide
theorem cert_e598477347270 : check e598477347270 [[.under],[.under,.left]] .chain = true := by decide
def e598477348038 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e598477348038 : Closed e598477348038 ∧ code e598477348038 = 9394570370246 := by decide
theorem cert_e598477348038 : check e598477348038 [[.under],[.under,.left]] .chain = true := by decide
def e598478444782 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e598478444782 : Closed e598478444782 ∧ code e598478444782 = 9394571466990 := by decide
theorem cert_e598478444782 : check e598478444782 [[.under],[.under,.left]] .chain = true := by decide
def e598478444790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e598478444790 : Closed e598478444790 ∧ code e598478444790 = 9394571466998 := by decide
theorem cert_e598478444790 : check e598478444790 [[.under],[.under,.left]] .chain = true := by decide
def e598478445342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e598478445342 : Closed e598478445342 ∧ code e598478445342 = 9394571467550 := by decide
theorem cert_e598478445342 : check e598478445342 [[.under],[.under,.left]] .chain = true := by decide
def e598478445454 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e598478445454 : Closed e598478445454 ∧ code e598478445454 = 9394571467662 := by decide
theorem cert_e598478445454 : check e598478445454 [[.under],[.under,.left]] .chain = true := by decide
def e598478445678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598478445678 : Closed e598478445678 ∧ code e598478445678 = 9394571467886 := by decide
theorem cert_e598478445678 : check e598478445678 [[.under],[.under,.left]] .chain = true := by decide
def e598478445690 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598478445690 : Closed e598478445690 ∧ code e598478445690 = 9394571467898 := by decide
theorem cert_e598478445690 : check e598478445690 [[.under],[.under,.left]] .chain = true := by decide
def e598478445854 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598478445854 : Closed e598478445854 ∧ code e598478445854 = 9394571468062 := by decide
theorem cert_e598478445854 : check e598478445854 [[.under],[.under,.left]] .chain = true := by decide
def e598478446022 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598478446022 : Closed e598478446022 ∧ code e598478446022 = 9394571468230 := by decide
theorem cert_e598478446022 : check e598478446022 [[.under],[.under,.left]] .chain = true := by decide
def e598478446134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598478446134 : Closed e598478446134 ∧ code e598478446134 = 9394571468342 := by decide
theorem cert_e598478446134 : check e598478446134 [[.under],[.under,.left]] .chain = true := by decide
def e598478446138 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598478446138 : Closed e598478446138 ∧ code e598478446138 = 9394571468346 := by decide
theorem cert_e598478446138 : check e598478446138 [[.under],[.under,.left]] .chain = true := by decide
def e598478446222 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598478446222 : Closed e598478446222 ∧ code e598478446222 = 9394571468430 := by decide
theorem cert_e598478446222 : check e598478446222 [[.under],[.under,.left]] .chain = true := by decide
def e598478446278 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598478446278 : Closed e598478446278 ∧ code e598478446278 = 9394571468486 := by decide
theorem cert_e598478446278 : check e598478446278 [[.under],[.under,.left]] .chain = true := by decide
def e598478448414 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e598478448414 : Closed e598478448414 ∧ code e598478448414 = 9394571470622 := by decide
theorem cert_e598478448414 : check e598478448414 [[.under],[.under,.left]] .chain = true := by decide
def e598478448526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e598478448526 : Closed e598478448526 ∧ code e598478448526 = 9394571470734 := by decide
theorem cert_e598478448526 : check e598478448526 [[.under],[.under,.left]] .chain = true := by decide
def e598478451486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598478451486 : Closed e598478451486 ∧ code e598478451486 = 9394571473694 := by decide
theorem cert_e598478451486 : check e598478451486 [[.under],[.under,.left]] .chain = true := by decide
def e598478451654 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598478451654 : Closed e598478451654 ∧ code e598478451654 = 9394571473862 := by decide
theorem cert_e598478451654 : check e598478451654 [[.under],[.under,.left]] .chain = true := by decide
def e598478453134 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598478453134 : Closed e598478453134 ∧ code e598478453134 = 9394571475342 := by decide
theorem cert_e598478453134 : check e598478453134 [[.under],[.under,.left]] .chain = true := by decide
def e598478453190 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598478453190 : Closed e598478453190 ∧ code e598478453190 = 9394571475398 := by decide
theorem cert_e598478453190 : check e598478453190 [[.under],[.under,.left]] .chain = true := by decide
def e598483146462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e598483146462 : Closed e598483146462 ∧ code e598483146462 = 9394576168670 := by decide
theorem cert_e598483146462 : check e598483146462 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483146486 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e598483146486 : Closed e598483146486 ∧ code e598483146486 = 9394576168694 := by decide
theorem cert_e598483146486 : check e598483146486 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483146590 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e598483146590 : Closed e598483146590 ∧ code e598483146590 = 9394576168798 := by decide
theorem cert_e598483146590 : check e598483146590 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483146618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e598483146618 : Closed e598483146618 ∧ code e598483146618 = 9394576168826 := by decide
theorem cert_e598483146618 : check e598483146618 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483146710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e598483146710 : Closed e598483146710 ∧ code e598483146710 = 9394576168918 := by decide
theorem cert_e598483146710 : check e598483146710 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483146714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e598483146714 : Closed e598483146714 ∧ code e598483146714 = 9394576168922 := by decide
theorem cert_e598483146714 : check e598483146714 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483147230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e598483147230 : Closed e598483147230 ∧ code e598483147230 = 9394576169438 := by decide
theorem cert_e598483147230 : check e598483147230 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483147254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e598483147254 : Closed e598483147254 ∧ code e598483147254 = 9394576169462 := by decide
theorem cert_e598483147254 : check e598483147254 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483147998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e598483147998 : Closed e598483147998 ∧ code e598483147998 = 9394576170206 := by decide
theorem cert_e598483147998 : check e598483147998 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483148026 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e598483148026 : Closed e598483148026 ∧ code e598483148026 = 9394576170234 := by decide
theorem cert_e598483148026 : check e598483148026 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483148598 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e598483148598 : Closed e598483148598 ∧ code e598483148598 = 9394576170806 := by decide
theorem cert_e598483148598 : check e598483148598 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483148602 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e598483148602 : Closed e598483148602 ∧ code e598483148602 = 9394576170810 := by decide
theorem cert_e598483148602 : check e598483148602 [[.under],[.under,.left],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483163374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e598483163374 : Closed e598483163374 ∧ code e598483163374 = 9394576185582 := by decide
theorem cert_e598483163374 : check e598483163374 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598483163382 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e598483163382 : Closed e598483163382 ∧ code e598483163382 = 9394576185590 := by decide
theorem cert_e598483163382 : check e598483163382 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598483163934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e598483163934 : Closed e598483163934 ∧ code e598483163934 = 9394576186142 := by decide
theorem cert_e598483163934 : check e598483163934 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598483164046 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e598483164046 : Closed e598483164046 ∧ code e598483164046 = 9394576186254 := by decide
theorem cert_e598483164046 : check e598483164046 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598483164270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e598483164270 : Closed e598483164270 ∧ code e598483164270 = 9394576186478 := by decide
theorem cert_e598483164270 : check e598483164270 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e598483164282 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e598483164282 : Closed e598483164282 ∧ code e598483164282 = 9394576186490 := by decide
theorem cert_e598483164282 : check e598483164282 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e598483164446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e598483164446 : Closed e598483164446 ∧ code e598483164446 = 9394576186654 := by decide
theorem cert_e598483164446 : check e598483164446 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under]] .sourceHead = true := by decide
def e598483164614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e598483164614 : Closed e598483164614 ∧ code e598483164614 = 9394576186822 := by decide
private def t_e598483164614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem cert_e598483164614 : ¬ IsSelfInterpreter e598483164614 :=
  wSource (t := t_e598483164614) (replay_sound (ps := []) (t := e598483164614) (by decide)) (by decide)
def e598483164726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598483164726 : Closed e598483164726 ∧ code e598483164726 = 9394576186934 := by decide
theorem cert_e598483164726 : check e598483164726 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e598483164730 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598483164730 : Closed e598483164730 ∧ code e598483164730 = 9394576186938 := by decide
theorem cert_e598483164730 : check e598483164730 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under,.left]] .chain = true := by decide
def e598483164814 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598483164814 : Closed e598483164814 ∧ code e598483164814 = 9394576187022 := by decide
theorem cert_e598483164814 : check e598483164814 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e598483164870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598483164870 : Closed e598483164870 ∧ code e598483164870 = 9394576187078 := by decide
private def t_e598483164870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem cert_e598483164870 : ¬ IsSelfInterpreter e598483164870 :=
  wSource (t := t_e598483164870) (replay_sound (ps := []) (t := e598483164870) (by decide)) (by decide)
def e598483167006 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e598483167006 : Closed e598483167006 ∧ code e598483167006 = 9394576189214 := by decide
theorem cert_e598483167006 : check e598483167006 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598483167118 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e598483167118 : Closed e598483167118 ∧ code e598483167118 = 9394576189326 := by decide
theorem cert_e598483167118 : check e598483167118 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e598483170078 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598483170078 : Closed e598483170078 ∧ code e598483170078 = 9394576192286 := by decide
theorem cert_e598483170078 : checkPay e598483170078 [[.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e598483170246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598483170246 : Closed e598483170246 ∧ code e598483170246 = 9394576192454 := by decide
theorem cert_e598483170246 : check e598483170246 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.under,.left]] .chain = true := by decide
def e598483171726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598483171726 : Closed e598483171726 ∧ code e598483171726 = 9394576193934 := by decide
theorem cert_e598483171726 : check e598483171726 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e598483171782 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598483171782 : Closed e598483171782 ∧ code e598483171782 = 9394576193990 := by decide
theorem cert_e598483171782 : check e598483171782 [[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e598617059526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617059526 : Closed e598617059526 ∧ code e598617059526 = 9394710081734 := by decide
theorem cert_e598617059526 : check e598617059526 [[.under]] .width = true := by decide
def e598617075910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617075910 : Closed e598617075910 ∧ code e598617075910 = 9394710098118 := by decide
theorem cert_e598617075910 : check e598617075910 [[.under]] .width = true := by decide
def e598617190598 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617190598 : Closed e598617190598 ∧ code e598617190598 = 9394710212806 := by decide
theorem cert_e598617190598 : check e598617190598 [[.under]] .width = true := by decide
def e598617215174 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617215174 : Closed e598617215174 ∧ code e598617215174 = 9394710237382 := by decide
theorem cert_e598617215174 : check e598617215174 [[.under]] .width = true := by decide
def e598617272518 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617272518 : Closed e598617272518 ∧ code e598617272518 = 9394710294726 := by decide
theorem cert_e598617272518 : check e598617272518 [[.under]] .width = true := by decide
def e598617280710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617280710 : Closed e598617280710 ∧ code e598617280710 = 9394710302918 := by decide
theorem cert_e598617280710 : check e598617280710 [[.under]] .width = true := by decide
def e598617845958 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617845958 : Closed e598617845958 ∧ code e598617845958 = 9394710868166 := by decide
theorem cert_e598617845958 : check e598617845958 [[.under]] .width = true := by decide
def e598617862342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598617862342 : Closed e598617862342 ∧ code e598617862342 = 9394710884550 := by decide
theorem cert_e598617862342 : check e598617862342 [[.under]] .width = true := by decide
def e598618632390 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598618632390 : Closed e598618632390 ∧ code e598618632390 = 9394711654598 := by decide
theorem cert_e598618632390 : check e598618632390 [[.under]] .width = true := by decide
def e598618656966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598618656966 : Closed e598618656966 ∧ code e598618656966 = 9394711679174 := by decide
theorem cert_e598618656966 : check e598618656966 [[.under]] .width = true := by decide
def e598619041990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598619041990 : Closed e598619041990 ∧ code e598619041990 = 9394712064198 := by decide
theorem cert_e598619041990 : check e598619041990 [[.under]] .width = true := by decide
def e598619050182 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e598619050182 : Closed e598619050182 ∧ code e598619050182 = 9394712072390 := by decide
theorem cert_e598619050182 : check e598619050182 [[.under]] .width = true := by decide
def e598661442926 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e598661442926 : Closed e598661442926 ∧ code e598661442926 = 9394754465134 := by decide
theorem cert_e598661442926 : check e598661442926 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661442934 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e598661442934 : Closed e598661442934 ∧ code e598661442934 = 9394754465142 := by decide
theorem cert_e598661442934 : check e598661442934 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661442990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e598661442990 : Closed e598661442990 ∧ code e598661442990 = 9394754465198 := by decide
theorem cert_e598661442990 : check e598661442990 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e598661443002 : Closed e598661443002 ∧ code e598661443002 = 9394754465210 := by decide
theorem cert_e598661443002 : check e598661443002 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443030 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e598661443030 : Closed e598661443030 ∧ code e598661443030 = 9394754465238 := by decide
theorem cert_e598661443030 : check e598661443030 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443034 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e598661443034 : Closed e598661443034 ∧ code e598661443034 = 9394754465242 := by decide
theorem cert_e598661443034 : check e598661443034 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443246 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e598661443246 : Closed e598661443246 ∧ code e598661443246 = 9394754465454 := by decide
theorem cert_e598661443246 : check e598661443246 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443258 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e598661443258 : Closed e598661443258 ∧ code e598661443258 = 9394754465466 := by decide
theorem cert_e598661443258 : check e598661443258 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e598661443306 : Closed e598661443306 ∧ code e598661443306 = 9394754465514 := by decide
theorem cert_e598661443306 : check e598661443306 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443414 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e598661443414 : Closed e598661443414 ∧ code e598661443414 = 9394754465622 := by decide
theorem cert_e598661443414 : check e598661443414 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443418 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e598661443418 : Closed e598661443418 ∧ code e598661443418 = 9394754465626 := by decide
theorem cert_e598661443418 : check e598661443418 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661443434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e598661443434 : Closed e598661443434 ∧ code e598661443434 = 9394754465642 := by decide
theorem cert_e598661443434 : check e598661443434 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e598661444462 : Closed e598661444462 ∧ code e598661444462 = 9394754466670 := by decide
theorem cert_e598661444462 : check e598661444462 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444470 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e598661444470 : Closed e598661444470 ∧ code e598661444470 = 9394754466678 := by decide
theorem cert_e598661444470 : check e598661444470 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444526 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e598661444526 : Closed e598661444526 ∧ code e598661444526 = 9394754466734 := by decide
theorem cert_e598661444526 : check e598661444526 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444538 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e598661444538 : Closed e598661444538 ∧ code e598661444538 = 9394754466746 := by decide
theorem cert_e598661444538 : check e598661444538 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444566 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e598661444566 : Closed e598661444566 ∧ code e598661444566 = 9394754466774 := by decide
theorem cert_e598661444566 : check e598661444566 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444570 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e598661444570 : Closed e598661444570 ∧ code e598661444570 = 9394754466778 := by decide
theorem cert_e598661444570 : check e598661444570 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444846 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e598661444846 : Closed e598661444846 ∧ code e598661444846 = 9394754467054 := by decide
theorem cert_e598661444846 : check e598661444846 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661444854 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e598661444854 : Closed e598661444854 ∧ code e598661444854 = 9394754467062 := by decide
theorem cert_e598661444854 : check e598661444854 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661445230 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e598661445230 : Closed e598661445230 ∧ code e598661445230 = 9394754467438 := by decide
theorem cert_e598661445230 : check e598661445230 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661445242 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e598661445242 : Closed e598661445242 ∧ code e598661445242 = 9394754467450 := by decide
theorem cert_e598661445242 : check e598661445242 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661445430 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e598661445430 : Closed e598661445430 ∧ code e598661445430 = 9394754467638 := by decide
theorem cert_e598661445430 : check e598661445430 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661445434 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e598661445434 : Closed e598661445434 ∧ code e598661445434 = 9394754467642 := by decide
theorem cert_e598661445434 : check e598661445434 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e598661446062 : Closed e598661446062 ∧ code e598661446062 = 9394754468270 := by decide
theorem cert_e598661446062 : check e598661446062 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446074 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e598661446074 : Closed e598661446074 ∧ code e598661446074 = 9394754468282 := by decide
theorem cert_e598661446074 : check e598661446074 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446122 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e598661446122 : Closed e598661446122 ∧ code e598661446122 = 9394754468330 := by decide
theorem cert_e598661446122 : check e598661446122 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446254 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e598661446254 : Closed e598661446254 ∧ code e598661446254 = 9394754468462 := by decide
theorem cert_e598661446254 : check e598661446254 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446266 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e598661446266 : Closed e598661446266 ∧ code e598661446266 = 9394754468474 := by decide
theorem cert_e598661446266 : check e598661446266 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446554 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e598661446554 : Closed e598661446554 ∧ code e598661446554 = 9394754468762 := by decide
theorem cert_e598661446554 : check e598661446554 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e598661446870 : Closed e598661446870 ∧ code e598661446870 = 9394754469078 := by decide
theorem cert_e598661446870 : check e598661446870 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446874 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e598661446874 : Closed e598661446874 ∧ code e598661446874 = 9394754469082 := by decide
theorem cert_e598661446874 : check e598661446874 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446890 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e598661446890 : Closed e598661446890 ∧ code e598661446890 = 9394754469098 := by decide
theorem cert_e598661446890 : check e598661446890 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e598661446966 : Closed e598661446966 ∧ code e598661446966 = 9394754469174 := by decide
theorem cert_e598661446966 : check e598661446966 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661446970 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e598661446970 : Closed e598661446970 ∧ code e598661446970 = 9394754469178 := by decide
theorem cert_e598661446970 : check e598661446970 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661447066 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e598661447066 : Closed e598661447066 ∧ code e598661447066 = 9394754469274 := by decide
theorem cert_e598661447066 : check e598661447066 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450606 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598661450606 : Closed e598661450606 ∧ code e598661450606 = 9394754472814 := by decide
theorem cert_e598661450606 : check e598661450606 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598661450614 : Closed e598661450614 ∧ code e598661450614 = 9394754472822 := by decide
theorem cert_e598661450614 : check e598661450614 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598661450670 : Closed e598661450670 ∧ code e598661450670 = 9394754472878 := by decide
theorem cert_e598661450670 : check e598661450670 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450682 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598661450682 : Closed e598661450682 ∧ code e598661450682 = 9394754472890 := by decide
theorem cert_e598661450682 : check e598661450682 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450710 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598661450710 : Closed e598661450710 ∧ code e598661450710 = 9394754472918 := by decide
theorem cert_e598661450710 : check e598661450710 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598661450714 : Closed e598661450714 ∧ code e598661450714 = 9394754472922 := by decide
theorem cert_e598661450714 : check e598661450714 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450990 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e598661450990 : Closed e598661450990 ∧ code e598661450990 = 9394754473198 := by decide
theorem cert_e598661450990 : check e598661450990 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661450998 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e598661450998 : Closed e598661450998 ∧ code e598661450998 = 9394754473206 := by decide
theorem cert_e598661450998 : check e598661450998 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661451374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e598661451374 : Closed e598661451374 ∧ code e598661451374 = 9394754473582 := by decide
theorem cert_e598661451374 : check e598661451374 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661451386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e598661451386 : Closed e598661451386 ∧ code e598661451386 = 9394754473594 := by decide
theorem cert_e598661451386 : check e598661451386 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661451574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e598661451574 : Closed e598661451574 ∧ code e598661451574 = 9394754473782 := by decide
theorem cert_e598661451574 : check e598661451574 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661451578 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e598661451578 : Closed e598661451578 ∧ code e598661451578 = 9394754473786 := by decide
theorem cert_e598661451578 : check e598661451578 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661457326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e598661457326 : Closed e598661457326 ∧ code e598661457326 = 9394754479534 := by decide
theorem cert_e598661457326 : check e598661457326 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661457338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e598661457338 : Closed e598661457338 ∧ code e598661457338 = 9394754479546 := by decide
theorem cert_e598661457338 : check e598661457338 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661457386 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e598661457386 : Closed e598661457386 ∧ code e598661457386 = 9394754479594 := by decide
theorem cert_e598661457386 : check e598661457386 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661457518 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e598661457518 : Closed e598661457518 ∧ code e598661457518 = 9394754479726 := by decide
theorem cert_e598661457518 : check e598661457518 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661457530 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e598661457530 : Closed e598661457530 ∧ code e598661457530 = 9394754479738 := by decide
theorem cert_e598661457530 : check e598661457530 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661457818 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e598661457818 : Closed e598661457818 ∧ code e598661457818 = 9394754480026 := by decide
theorem cert_e598661457818 : check e598661457818 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661460694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e598661460694 : Closed e598661460694 ∧ code e598661460694 = 9394754482902 := by decide
theorem cert_e598661460694 : check e598661460694 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661460698 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e598661460698 : Closed e598661460698 ∧ code e598661460698 = 9394754482906 := by decide
theorem cert_e598661460698 : check e598661460698 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661460714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e598661460714 : Closed e598661460714 ∧ code e598661460714 = 9394754482922 := by decide
theorem cert_e598661460714 : check e598661460714 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661460790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e598661460790 : Closed e598661460790 ∧ code e598661460790 = 9394754482998 := by decide
theorem cert_e598661460790 : check e598661460790 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661460794 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e598661460794 : Closed e598661460794 ∧ code e598661460794 = 9394754483002 := by decide
theorem cert_e598661460794 : check e598661460794 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661460890 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e598661460890 : Closed e598661460890 ∧ code e598661460890 = 9394754483098 := by decide
theorem cert_e598661460890 : check e598661460890 [[.under],[.under,.left],[.under]] .smaller = true := by decide
def e598661598062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e598661598062 : Closed e598661598062 ∧ code e598661598062 = 9394754620270 := by decide
theorem cert_e598661598062 : check e598661598062 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598070 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e598661598070 : Closed e598661598070 ∧ code e598661598070 = 9394754620278 := by decide
theorem cert_e598661598070 : check e598661598070 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598126 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e598661598126 : Closed e598661598126 ∧ code e598661598126 = 9394754620334 := by decide
theorem cert_e598661598126 : check e598661598126 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598138 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e598661598138 : Closed e598661598138 ∧ code e598661598138 = 9394754620346 := by decide
theorem cert_e598661598138 : check e598661598138 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598166 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e598661598166 : Closed e598661598166 ∧ code e598661598166 = 9394754620374 := by decide
theorem cert_e598661598166 : check e598661598166 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e598661598170 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e598661598170 : Closed e598661598170 ∧ code e598661598170 = 9394754620378 := by decide
theorem cert_e598661598170 : check e598661598170 [[.under],[.under,.left],[.under],[.under]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e598483164614
#print axioms Blc.Floor43.cert_e598483164870
