import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418888733498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2418888733498 : Closed e2418888733498 ∧ code e2418888733498 = 11214981755706 := by decide
theorem cert_e2418888733498 : check e2418888733498 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418888733594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2418888733594 : Closed e2418888733594 ∧ code e2418888733594 = 11214981755802 := by decide
theorem cert_e2418888733594 : check e2418888733594 [[],[],[.under,.under,.left]] .chain = true := by decide
def e2418888870766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418888870766 : Closed e2418888870766 ∧ code e2418888870766 = 11214981892974 := by decide
theorem cert_e2418888870766 : check e2418888870766 [[],[]] .sourceHead = true := by decide
def e2418888870774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418888870774 : Closed e2418888870774 ∧ code e2418888870774 = 11214981892982 := by decide
theorem cert_e2418888870774 : check e2418888870774 [[],[]] .sourceHead = true := by decide
def e2418888870830 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418888870830 : Closed e2418888870830 ∧ code e2418888870830 = 11214981893038 := by decide
theorem cert_e2418888870830 : check e2418888870830 [[],[]] .sourceHead = true := by decide
def e2418888870842 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418888870842 : Closed e2418888870842 ∧ code e2418888870842 = 11214981893050 := by decide
theorem cert_e2418888870842 : check e2418888870842 [[],[]] .sourceHead = true := by decide
def e2418888870870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418888870870 : Closed e2418888870870 ∧ code e2418888870870 = 11214981893078 := by decide
theorem cert_e2418888870870 : check e2418888870870 [[],[]] .sourceHead = true := by decide
def e2418888870874 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418888870874 : Closed e2418888870874 ∧ code e2418888870874 = 11214981893082 := by decide
theorem cert_e2418888870874 : check e2418888870874 [[],[]] .sourceHead = true := by decide
def e2418888871150 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418888871150 : Closed e2418888871150 ∧ code e2418888871150 = 11214981893358 := by decide
theorem cert_e2418888871150 : check e2418888871150 [[],[]] .sourceHead = true := by decide
def e2418888871158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418888871158 : Closed e2418888871158 ∧ code e2418888871158 = 11214981893366 := by decide
theorem cert_e2418888871158 : check e2418888871158 [[],[]] .sourceHead = true := by decide
def e2418888871534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418888871534 : Closed e2418888871534 ∧ code e2418888871534 = 11214981893742 := by decide
theorem cert_e2418888871534 : check e2418888871534 [[],[]] .sourceHead = true := by decide
def e2418888871546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418888871546 : Closed e2418888871546 ∧ code e2418888871546 = 11214981893754 := by decide
theorem cert_e2418888871546 : check e2418888871546 [[],[]] .sourceHead = true := by decide
def e2418888871734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418888871734 : Closed e2418888871734 ∧ code e2418888871734 = 11214981893942 := by decide
theorem cert_e2418888871734 : check e2418888871734 [[],[]] .sourceHead = true := by decide
def e2418888871738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418888871738 : Closed e2418888871738 ∧ code e2418888871738 = 11214981893946 := by decide
theorem cert_e2418888871738 : check e2418888871738 [[],[]] .sourceHead = true := by decide
def e2418889460590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418889460590 : Closed e2418889460590 ∧ code e2418889460590 = 11214982482798 := by decide
theorem cert_e2418889460590 : check e2418889460590 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2418889460598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418889460598 : Closed e2418889460598 ∧ code e2418889460598 = 11214982482806 := by decide
theorem cert_e2418889460598 : check e2418889460598 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2418889460654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418889460654 : Closed e2418889460654 ∧ code e2418889460654 = 11214982482862 := by decide
theorem cert_e2418889460654 : check e2418889460654 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[],[.left],[.left],[.left],[],[.under,.left,.left],[.under,.left,.left,.left]] .chain = true := by decide
def e2418889460666 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418889460666 : Closed e2418889460666 ∧ code e2418889460666 = 11214982482874 := by decide
theorem cert_e2418889460666 : check e2418889460666 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left],[.left],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left,.left]] .chain = true := by decide
def e2418889460694 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418889460694 : Closed e2418889460694 ∧ code e2418889460694 = 11214982482902 := by decide
theorem cert_e2418889460694 : check e2418889460694 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left]] .sourceHead = true := by decide
def e2418889460698 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418889460698 : Closed e2418889460698 ∧ code e2418889460698 = 11214982482906 := by decide
theorem cert_e2418889460698 : check e2418889460698 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2418889460974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418889460974 : Closed e2418889460974 ∧ code e2418889460974 = 11214982483182 := by decide
theorem cert_e2418889460974 : check e2418889460974 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2418889460982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418889460982 : Closed e2418889460982 ∧ code e2418889460982 = 11214982483190 := by decide
theorem cert_e2418889460982 : check e2418889460982 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2418889461358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418889461358 : Closed e2418889461358 ∧ code e2418889461358 = 11214982483566 := by decide
theorem cert_e2418889461358 : check e2418889461358 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2418889461370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418889461370 : Closed e2418889461370 ∧ code e2418889461370 = 11214982483578 := by decide
theorem cert_e2418889461370 : check e2418889461370 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2418889461558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418889461558 : Closed e2418889461558 ∧ code e2418889461558 = 11214982483766 := by decide
theorem cert_e2418889461558 : check e2418889461558 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2418889461562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418889461562 : Closed e2418889461562 ∧ code e2418889461562 = 11214982483770 := by decide
theorem cert_e2418889461562 : check e2418889461562 [[],[],[.left],[.left,.left],[.left,.left],[.left],[],[],[],[.under,.left],[.under,.left],[.under],[.under,.under],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2418939047278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e2418939047278 : Closed e2418939047278 ∧ code e2418939047278 = 11215032069486 := by decide
theorem cert_e2418939047278 : check e2418939047278 [[],[]] .smaller = true := by decide
def e2418939047286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e2418939047286 : Closed e2418939047286 ∧ code e2418939047286 = 11215032069494 := by decide
theorem cert_e2418939047286 : check e2418939047286 [[],[]] .smaller = true := by decide
def e2418939047342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e2418939047342 : Closed e2418939047342 ∧ code e2418939047342 = 11215032069550 := by decide
theorem cert_e2418939047342 : check e2418939047342 [[],[]] .smaller = true := by decide
def e2418939047354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e2418939047354 : Closed e2418939047354 ∧ code e2418939047354 = 11215032069562 := by decide
theorem cert_e2418939047354 : check e2418939047354 [[],[]] .smaller = true := by decide
def e2418939047382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e2418939047382 : Closed e2418939047382 ∧ code e2418939047382 = 11215032069590 := by decide
theorem cert_e2418939047382 : check e2418939047382 [[],[]] .smaller = true := by decide
def e2418939047386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e2418939047386 : Closed e2418939047386 ∧ code e2418939047386 = 11215032069594 := by decide
theorem cert_e2418939047386 : check e2418939047386 [[],[]] .smaller = true := by decide
def e2418939047598 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e2418939047598 : Closed e2418939047598 ∧ code e2418939047598 = 11215032069806 := by decide
theorem cert_e2418939047598 : check e2418939047598 [[],[]] .smaller = true := by decide
def e2418939047610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e2418939047610 : Closed e2418939047610 ∧ code e2418939047610 = 11215032069818 := by decide
theorem cert_e2418939047610 : check e2418939047610 [[],[]] .smaller = true := by decide
def e2418939047658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e2418939047658 : Closed e2418939047658 ∧ code e2418939047658 = 11215032069866 := by decide
theorem cert_e2418939047658 : check e2418939047658 [[],[]] .smaller = true := by decide
def e2418939047766 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e2418939047766 : Closed e2418939047766 ∧ code e2418939047766 = 11215032069974 := by decide
theorem cert_e2418939047766 : check e2418939047766 [[],[]] .smaller = true := by decide
def e2418939047770 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e2418939047770 : Closed e2418939047770 ∧ code e2418939047770 = 11215032069978 := by decide
theorem cert_e2418939047770 : check e2418939047770 [[],[]] .smaller = true := by decide
def e2418939047786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e2418939047786 : Closed e2418939047786 ∧ code e2418939047786 = 11215032069994 := by decide
theorem cert_e2418939047786 : check e2418939047786 [[],[]] .smaller = true := by decide
def e2418939048814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2418939048814 : Closed e2418939048814 ∧ code e2418939048814 = 11215032071022 := by decide
theorem cert_e2418939048814 : check e2418939048814 [[],[]] .smaller = true := by decide
def e2418939048822 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2418939048822 : Closed e2418939048822 ∧ code e2418939048822 = 11215032071030 := by decide
theorem cert_e2418939048822 : check e2418939048822 [[],[]] .smaller = true := by decide
def e2418939048878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2418939048878 : Closed e2418939048878 ∧ code e2418939048878 = 11215032071086 := by decide
theorem cert_e2418939048878 : check e2418939048878 [[],[]] .smaller = true := by decide
def e2418939048890 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2418939048890 : Closed e2418939048890 ∧ code e2418939048890 = 11215032071098 := by decide
theorem cert_e2418939048890 : check e2418939048890 [[],[]] .smaller = true := by decide
def e2418939048918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2418939048918 : Closed e2418939048918 ∧ code e2418939048918 = 11215032071126 := by decide
theorem cert_e2418939048918 : check e2418939048918 [[],[]] .smaller = true := by decide
def e2418939048922 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2418939048922 : Closed e2418939048922 ∧ code e2418939048922 = 11215032071130 := by decide
theorem cert_e2418939048922 : check e2418939048922 [[],[]] .smaller = true := by decide
def e2418939049198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2418939049198 : Closed e2418939049198 ∧ code e2418939049198 = 11215032071406 := by decide
theorem cert_e2418939049198 : check e2418939049198 [[],[]] .smaller = true := by decide
def e2418939049206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2418939049206 : Closed e2418939049206 ∧ code e2418939049206 = 11215032071414 := by decide
theorem cert_e2418939049206 : check e2418939049206 [[],[]] .smaller = true := by decide
def e2418939049582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418939049582 : Closed e2418939049582 ∧ code e2418939049582 = 11215032071790 := by decide
theorem cert_e2418939049582 : check e2418939049582 [[],[]] .smaller = true := by decide
def e2418939049594 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418939049594 : Closed e2418939049594 ∧ code e2418939049594 = 11215032071802 := by decide
theorem cert_e2418939049594 : check e2418939049594 [[],[]] .smaller = true := by decide
def e2418939049782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418939049782 : Closed e2418939049782 ∧ code e2418939049782 = 11215032071990 := by decide
theorem cert_e2418939049782 : check e2418939049782 [[],[]] .smaller = true := by decide
def e2418939049786 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418939049786 : Closed e2418939049786 ∧ code e2418939049786 = 11215032071994 := by decide
theorem cert_e2418939049786 : check e2418939049786 [[],[]] .smaller = true := by decide
def e2418939050414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2418939050414 : Closed e2418939050414 ∧ code e2418939050414 = 11215032072622 := by decide
theorem cert_e2418939050414 : check e2418939050414 [[],[]] .smaller = true := by decide
def e2418939050426 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2418939050426 : Closed e2418939050426 ∧ code e2418939050426 = 11215032072634 := by decide
theorem cert_e2418939050426 : check e2418939050426 [[],[]] .smaller = true := by decide
def e2418939050474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2418939050474 : Closed e2418939050474 ∧ code e2418939050474 = 11215032072682 := by decide
theorem cert_e2418939050474 : check e2418939050474 [[],[]] .smaller = true := by decide
def e2418939050606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2418939050606 : Closed e2418939050606 ∧ code e2418939050606 = 11215032072814 := by decide
theorem cert_e2418939050606 : check e2418939050606 [[],[]] .smaller = true := by decide
def e2418939050618 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2418939050618 : Closed e2418939050618 ∧ code e2418939050618 = 11215032072826 := by decide
theorem cert_e2418939050618 : check e2418939050618 [[],[]] .smaller = true := by decide
def e2418939050906 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418939050906 : Closed e2418939050906 ∧ code e2418939050906 = 11215032073114 := by decide
theorem cert_e2418939050906 : check e2418939050906 [[],[]] .smaller = true := by decide
def e2418939051222 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2418939051222 : Closed e2418939051222 ∧ code e2418939051222 = 11215032073430 := by decide
theorem cert_e2418939051222 : check e2418939051222 [[],[]] .smaller = true := by decide
def e2418939051226 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2418939051226 : Closed e2418939051226 ∧ code e2418939051226 = 11215032073434 := by decide
theorem cert_e2418939051226 : check e2418939051226 [[],[]] .smaller = true := by decide
def e2418939051242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2418939051242 : Closed e2418939051242 ∧ code e2418939051242 = 11215032073450 := by decide
theorem cert_e2418939051242 : check e2418939051242 [[],[]] .smaller = true := by decide
def e2418939051318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2418939051318 : Closed e2418939051318 ∧ code e2418939051318 = 11215032073526 := by decide
theorem cert_e2418939051318 : check e2418939051318 [[],[]] .smaller = true := by decide
def e2418939051322 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2418939051322 : Closed e2418939051322 ∧ code e2418939051322 = 11215032073530 := by decide
theorem cert_e2418939051322 : check e2418939051322 [[],[]] .smaller = true := by decide
def e2418939051418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2418939051418 : Closed e2418939051418 ∧ code e2418939051418 = 11215032073626 := by decide
theorem cert_e2418939051418 : check e2418939051418 [[],[]] .smaller = true := by decide
def e2418939054958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418939054958 : Closed e2418939054958 ∧ code e2418939054958 = 11215032077166 := by decide
theorem cert_e2418939054958 : check e2418939054958 [[],[]] .smaller = true := by decide
def e2418939054966 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418939054966 : Closed e2418939054966 ∧ code e2418939054966 = 11215032077174 := by decide
theorem cert_e2418939054966 : check e2418939054966 [[],[]] .smaller = true := by decide
def e2418939055022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418939055022 : Closed e2418939055022 ∧ code e2418939055022 = 11215032077230 := by decide
theorem cert_e2418939055022 : check e2418939055022 [[],[]] .smaller = true := by decide
def e2418939055034 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418939055034 : Closed e2418939055034 ∧ code e2418939055034 = 11215032077242 := by decide
theorem cert_e2418939055034 : check e2418939055034 [[],[]] .smaller = true := by decide
def e2418939055062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418939055062 : Closed e2418939055062 ∧ code e2418939055062 = 11215032077270 := by decide
theorem cert_e2418939055062 : check e2418939055062 [[],[]] .smaller = true := by decide
def e2418939055066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418939055066 : Closed e2418939055066 ∧ code e2418939055066 = 11215032077274 := by decide
theorem cert_e2418939055066 : check e2418939055066 [[],[]] .smaller = true := by decide
def e2418939055342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418939055342 : Closed e2418939055342 ∧ code e2418939055342 = 11215032077550 := by decide
theorem cert_e2418939055342 : check e2418939055342 [[],[]] .smaller = true := by decide
def e2418939055350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418939055350 : Closed e2418939055350 ∧ code e2418939055350 = 11215032077558 := by decide
theorem cert_e2418939055350 : check e2418939055350 [[],[]] .smaller = true := by decide
def e2418939055726 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418939055726 : Closed e2418939055726 ∧ code e2418939055726 = 11215032077934 := by decide
theorem cert_e2418939055726 : check e2418939055726 [[],[]] .smaller = true := by decide
def e2418939055738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418939055738 : Closed e2418939055738 ∧ code e2418939055738 = 11215032077946 := by decide
theorem cert_e2418939055738 : check e2418939055738 [[],[]] .smaller = true := by decide
def e2418939055926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418939055926 : Closed e2418939055926 ∧ code e2418939055926 = 11215032078134 := by decide
theorem cert_e2418939055926 : check e2418939055926 [[],[]] .smaller = true := by decide
def e2418939055930 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418939055930 : Closed e2418939055930 ∧ code e2418939055930 = 11215032078138 := by decide
theorem cert_e2418939055930 : check e2418939055930 [[],[]] .smaller = true := by decide
def e2418939061678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e2418939061678 : Closed e2418939061678 ∧ code e2418939061678 = 11215032083886 := by decide
theorem cert_e2418939061678 : check e2418939061678 [[],[]] .smaller = true := by decide
def e2418939061690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e2418939061690 : Closed e2418939061690 ∧ code e2418939061690 = 11215032083898 := by decide
theorem cert_e2418939061690 : check e2418939061690 [[],[]] .smaller = true := by decide
def e2418939061738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e2418939061738 : Closed e2418939061738 ∧ code e2418939061738 = 11215032083946 := by decide
theorem cert_e2418939061738 : check e2418939061738 [[],[]] .smaller = true := by decide
def e2418939061870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418939061870 : Closed e2418939061870 ∧ code e2418939061870 = 11215032084078 := by decide
theorem cert_e2418939061870 : check e2418939061870 [[],[]] .smaller = true := by decide
def e2418939061882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418939061882 : Closed e2418939061882 ∧ code e2418939061882 = 11215032084090 := by decide
theorem cert_e2418939061882 : check e2418939061882 [[],[]] .smaller = true := by decide
def e2418939062170 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418939062170 : Closed e2418939062170 ∧ code e2418939062170 = 11215032084378 := by decide
theorem cert_e2418939062170 : check e2418939062170 [[],[]] .smaller = true := by decide
def e2418939065046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2418939065046 : Closed e2418939065046 ∧ code e2418939065046 = 11215032087254 := by decide
theorem cert_e2418939065046 : check e2418939065046 [[],[]] .smaller = true := by decide
def e2418939065050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2418939065050 : Closed e2418939065050 ∧ code e2418939065050 = 11215032087258 := by decide
theorem cert_e2418939065050 : check e2418939065050 [[],[]] .smaller = true := by decide
def e2418939065066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2418939065066 : Closed e2418939065066 ∧ code e2418939065066 = 11215032087274 := by decide
theorem cert_e2418939065066 : check e2418939065066 [[],[]] .smaller = true := by decide
def e2418939065142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418939065142 : Closed e2418939065142 ∧ code e2418939065142 = 11215032087350 := by decide
theorem cert_e2418939065142 : check e2418939065142 [[],[]] .smaller = true := by decide
def e2418939065146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418939065146 : Closed e2418939065146 ∧ code e2418939065146 = 11215032087354 := by decide
theorem cert_e2418939065146 : check e2418939065146 [[],[]] .smaller = true := by decide
def e2418939065242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2418939065242 : Closed e2418939065242 ∧ code e2418939065242 = 11215032087450 := by decide
theorem cert_e2418939065242 : check e2418939065242 [[],[]] .smaller = true := by decide
def e2418939180782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))
theorem wire_e2418939180782 : Closed e2418939180782 ∧ code e2418939180782 = 11215032202990 := by decide
theorem cert_e2418939180782 : check e2418939180782 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2418939180910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))
theorem wire_e2418939180910 : Closed e2418939180910 ∧ code e2418939180910 = 11215032203118 := by decide
theorem cert_e2418939180910 : check e2418939180910 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2418939180918 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))
theorem wire_e2418939180918 : Closed e2418939180918 ∧ code e2418939180918 = 11215032203126 := by decide
theorem cert_e2418939180918 : check e2418939180918 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2418939181806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))
theorem wire_e2418939181806 : Closed e2418939181806 ∧ code e2418939181806 = 11215032204014 := by decide
theorem cert_e2418939181806 : check e2418939181806 [[],[]] .sourceHead = true := by decide
def e2418939181998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))
theorem wire_e2418939181998 : Closed e2418939181998 ∧ code e2418939181998 = 11215032204206 := by decide
theorem cert_e2418939181998 : check e2418939181998 [[],[]] .sourceHead = true := by decide
def e2418939182010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))
theorem wire_e2418939182010 : Closed e2418939182010 ∧ code e2418939182010 = 11215032204218 := by decide
theorem cert_e2418939182010 : check e2418939182010 [[],[]] .sourceHead = true := by decide
def e2418939182446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2418939182446 : Closed e2418939182446 ∧ code e2418939182446 = 11215032204654 := by decide
theorem cert_e2418939182446 : check e2418939182446 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2418939182454 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2418939182454 : Closed e2418939182454 ∧ code e2418939182454 = 11215032204662 := by decide
def e2418939182510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2418939182510 : Closed e2418939182510 ∧ code e2418939182510 = 11215032204718 := by decide
theorem cert_e2418939182510 : check e2418939182510 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2418939182522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2418939182522 : Closed e2418939182522 ∧ code e2418939182522 = 11215032204730 := by decide
theorem cert_e2418939182522 : check e2418939182522 [[],[],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2418939182550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2418939182550 : Closed e2418939182550 ∧ code e2418939182550 = 11215032204758 := by decide
private def t_e2418939182550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))
theorem cert_e2418939182550 : ¬ IsSelfInterpreter e2418939182550 :=
  wSource (t := t_e2418939182550) (replay_sound (ps := []) (t := e2418939182550) (by decide)) (by decide)
def e2418939182554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2418939182554 : Closed e2418939182554 ∧ code e2418939182554 = 11215032204762 := by decide
private def t_e2418939182554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))
theorem cert_e2418939182554 : ¬ IsSelfInterpreter e2418939182554 :=
  wSource (t := t_e2418939182554) (replay_sound (ps := []) (t := e2418939182554) (by decide)) (by decide)
def e2418939186926 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2418939186926 : Closed e2418939186926 ∧ code e2418939186926 = 11215032209134 := by decide
theorem cert_e2418939186926 : check e2418939186926 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418939187054 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2418939187054 : Closed e2418939187054 ∧ code e2418939187054 = 11215032209262 := by decide
theorem cert_e2418939187054 : check e2418939187054 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2418939187062 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2418939187062 : Closed e2418939187062 ∧ code e2418939187062 = 11215032209270 := by decide
theorem cert_e2418939187062 : check e2418939187062 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2418939189742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2418939189742 : Closed e2418939189742 ∧ code e2418939189742 = 11215032211950 := by decide
theorem cert_e2418939189742 : check e2418939189742 [[.left,.left],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2418939190510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418939190510 : Closed e2418939190510 ∧ code e2418939190510 = 11215032212718 := by decide
theorem cert_e2418939190510 : check e2418939190510 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2418939190518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418939190518 : Closed e2418939190518 ∧ code e2418939190518 = 11215032212726 := by decide
theorem cert_e2418939190518 : check e2418939190518 [[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .identityHead = true := by decide
def e2418939193070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2418939193070 : Closed e2418939193070 ∧ code e2418939193070 = 11215032215278 := by decide
theorem cert_e2418939193070 : checkPay e2418939193070 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.left],[],[],[.left,.left],[.left],[],[.left],[],[],[.left],[],[.under,.left]] = true := by decide
def e2418939193262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2418939193262 : Closed e2418939193262 ∧ code e2418939193262 = 11215032215470 := by decide
theorem cert_e2418939193262 : checkPay e2418939193262 [[.left,.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left,.right],[.under,.left,.left,.left,.right,.under,.under,.left,.right],[.under,.right],[.under,.right,.under,.under,.left,.right]] = true := by decide
def e2418939193274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2418939193274 : Closed e2418939193274 ∧ code e2418939193274 = 11215032215482 := by decide
theorem cert_e2418939193274 : checkPay e2418939193274 [[.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2418939193838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2418939193838 : Closed e2418939193838 ∧ code e2418939193838 = 11215032216046 := by decide
theorem cert_e2418939193838 : checkPay e2418939193838 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2418939194990 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418939194990 : Closed e2418939194990 ∧ code e2418939194990 = 11215032217198 := by decide
theorem cert_e2418939194990 : checkPay e2418939194990 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.right,.right]] = true := by decide
def e2418939195002 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418939195002 : Closed e2418939195002 ∧ code e2418939195002 = 11215032217210 := by decide
theorem cert_e2418939195002 : checkPay e2418939195002 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.under,.under,.left,.right],[.under,.under,.left,.right,.under,.under,.right],[.under,.under,.right,.left],[.under,.under,.right],[.under,.under,.right,.under,.right]] = true := by decide
def e2418939196270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2418939196270 : Closed e2418939196270 ∧ code e2418939196270 = 11215032218478 := by decide
theorem cert_e2418939196270 : check e2418939196270 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939196278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2418939196278 : Closed e2418939196278 ∧ code e2418939196278 = 11215032218486 := by decide
theorem cert_e2418939196278 : check e2418939196278 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939196334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2418939196334 : Closed e2418939196334 ∧ code e2418939196334 = 11215032218542 := by decide
theorem cert_e2418939196334 : check e2418939196334 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939196346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2418939196346 : Closed e2418939196346 ∧ code e2418939196346 = 11215032218554 := by decide
theorem cert_e2418939196346 : check e2418939196346 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939196374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2418939196374 : Closed e2418939196374 ∧ code e2418939196374 = 11215032218582 := by decide
theorem cert_e2418939196374 : check e2418939196374 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939196378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2418939196378 : Closed e2418939196378 ∧ code e2418939196378 = 11215032218586 := by decide
theorem cert_e2418939196378 : check e2418939196378 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939196654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2418939196654 : Closed e2418939196654 ∧ code e2418939196654 = 11215032218862 := by decide
theorem cert_e2418939196654 : check e2418939196654 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939196662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2418939196662 : Closed e2418939196662 ∧ code e2418939196662 = 11215032218870 := by decide
theorem cert_e2418939196662 : check e2418939196662 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939197038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2418939197038 : Closed e2418939197038 ∧ code e2418939197038 = 11215032219246 := by decide
theorem cert_e2418939197038 : check e2418939197038 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939197050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2418939197050 : Closed e2418939197050 ∧ code e2418939197050 = 11215032219258 := by decide
theorem cert_e2418939197050 : check e2418939197050 [[],[],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939197238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2418939197238 : Closed e2418939197238 ∧ code e2418939197238 = 11215032219446 := by decide
private def t_e2418939197238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem cert_e2418939197238 : ¬ IsSelfInterpreter e2418939197238 :=
  wSource (t := t_e2418939197238) (replay_sound (ps := []) (t := e2418939197238) (by decide)) (by decide)
def e2418939197242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2418939197242 : Closed e2418939197242 ∧ code e2418939197242 = 11215032219450 := by decide
private def t_e2418939197242 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem cert_e2418939197242 : ¬ IsSelfInterpreter e2418939197242 :=
  wSource (t := t_e2418939197242) (replay_sound (ps := []) (t := e2418939197242) (by decide)) (by decide)
def e2418939202414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418939202414 : Closed e2418939202414 ∧ code e2418939202414 = 11215032224622 := by decide
theorem cert_e2418939202414 : check e2418939202414 [[],[]] .smaller = true := by decide
def e2418939202422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418939202422 : Closed e2418939202422 ∧ code e2418939202422 = 11215032224630 := by decide
theorem cert_e2418939202422 : check e2418939202422 [[],[]] .smaller = true := by decide
def e2418939202478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418939202478 : Closed e2418939202478 ∧ code e2418939202478 = 11215032224686 := by decide
theorem cert_e2418939202478 : check e2418939202478 [[],[]] .smaller = true := by decide
def e2418939202490 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418939202490 : Closed e2418939202490 ∧ code e2418939202490 = 11215032224698 := by decide
theorem cert_e2418939202490 : check e2418939202490 [[],[]] .smaller = true := by decide
def e2418939202518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418939202518 : Closed e2418939202518 ∧ code e2418939202518 = 11215032224726 := by decide
theorem cert_e2418939202518 : check e2418939202518 [[],[]] .smaller = true := by decide
def e2418939202522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418939202522 : Closed e2418939202522 ∧ code e2418939202522 = 11215032224730 := by decide
theorem cert_e2418939202522 : check e2418939202522 [[],[]] .smaller = true := by decide
def e2418939202798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418939202798 : Closed e2418939202798 ∧ code e2418939202798 = 11215032225006 := by decide
theorem cert_e2418939202798 : check e2418939202798 [[],[]] .smaller = true := by decide
def e2418939202806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418939202806 : Closed e2418939202806 ∧ code e2418939202806 = 11215032225014 := by decide
theorem cert_e2418939202806 : check e2418939202806 [[],[]] .smaller = true := by decide
def e2418939203182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418939203182 : Closed e2418939203182 ∧ code e2418939203182 = 11215032225390 := by decide
theorem cert_e2418939203182 : check e2418939203182 [[],[]] .smaller = true := by decide
def e2418939203194 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418939203194 : Closed e2418939203194 ∧ code e2418939203194 = 11215032225402 := by decide
theorem cert_e2418939203194 : check e2418939203194 [[],[]] .smaller = true := by decide
def e2418939203382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418939203382 : Closed e2418939203382 ∧ code e2418939203382 = 11215032225590 := by decide
theorem cert_e2418939203382 : check e2418939203382 [[],[]] .smaller = true := by decide
def e2418939203386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418939203386 : Closed e2418939203386 ∧ code e2418939203386 = 11215032225594 := by decide
theorem cert_e2418939203386 : check e2418939203386 [[],[]] .smaller = true := by decide
def e2418939211502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2418939211502 : Closed e2418939211502 ∧ code e2418939211502 = 11215032233710 := by decide
theorem cert_e2418939211502 : check e2418939211502 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418939211630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2418939211630 : Closed e2418939211630 ∧ code e2418939211630 = 11215032233838 := by decide
theorem cert_e2418939211630 : check e2418939211630 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418939211638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2418939211638 : Closed e2418939211638 ∧ code e2418939211638 = 11215032233846 := by decide
theorem cert_e2418939211638 : check e2418939211638 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2418939214318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2418939214318 : Closed e2418939214318 ∧ code e2418939214318 = 11215032236526 := by decide
theorem cert_e2418939214318 : check e2418939214318 [[.left,.left],[.left,.left],[.left],[],[]] .identityHead = true := by decide
def e2418939215086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2418939215086 : Closed e2418939215086 ∧ code e2418939215086 = 11215032237294 := by decide
theorem cert_e2418939215086 : check e2418939215086 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418939215094 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2418939215094 : Closed e2418939215094 ∧ code e2418939215094 = 11215032237302 := by decide
theorem cert_e2418939215094 : check e2418939215094 [[.left,.left],[.left,.left],[.left],[],[],[.left,.left,.left],[.left,.left],[.left],[.left],[],[.left],[]] .identityHead = true := by decide
def e2418939238126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2418939238126 : Closed e2418939238126 ∧ code e2418939238126 = 11215032260334 := by decide
theorem cert_e2418939238126 : check e2418939238126 [[],[]] .sourceHead = true := by decide
def e2418939238318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2418939238318 : Closed e2418939238318 ∧ code e2418939238318 = 11215032260526 := by decide
theorem cert_e2418939238318 : check e2418939238318 [[],[]] .sourceHead = true := by decide
def e2418939238330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2418939238330 : Closed e2418939238330 ∧ code e2418939238330 = 11215032260538 := by decide
theorem cert_e2418939238330 : check e2418939238330 [[],[]] .sourceHead = true := by decide
def e2418939238894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2418939238894 : Closed e2418939238894 ∧ code e2418939238894 = 11215032261102 := by decide
theorem cert_e2418939238894 : check e2418939238894 [[],[]] .sourceHead = true := by decide
def e2418939240046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2418939240046 : Closed e2418939240046 ∧ code e2418939240046 = 11215032262254 := by decide
theorem cert_e2418939240046 : check e2418939240046 [[],[]] .sourceHead = true := by decide
def e2418939240058 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2418939240058 : Closed e2418939240058 ∧ code e2418939240058 = 11215032262266 := by decide
theorem cert_e2418939240058 : check e2418939240058 [[],[]] .sourceHead = true := by decide
def e2418939251566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2418939251566 : Closed e2418939251566 ∧ code e2418939251566 = 11215032273774 := by decide
theorem cert_e2418939251566 : check e2418939251566 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939251574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2418939251574 : Closed e2418939251574 ∧ code e2418939251574 = 11215032273782 := by decide
theorem cert_e2418939251574 : check e2418939251574 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939251630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2418939251630 : Closed e2418939251630 ∧ code e2418939251630 = 11215032273838 := by decide
theorem cert_e2418939251630 : check e2418939251630 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939251642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2418939251642 : Closed e2418939251642 ∧ code e2418939251642 = 11215032273850 := by decide
theorem cert_e2418939251642 : check e2418939251642 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939251670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2418939251670 : Closed e2418939251670 ∧ code e2418939251670 = 11215032273878 := by decide
theorem cert_e2418939251670 : check e2418939251670 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939251674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2418939251674 : Closed e2418939251674 ∧ code e2418939251674 = 11215032273882 := by decide
theorem cert_e2418939251674 : check e2418939251674 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939251950 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2418939251950 : Closed e2418939251950 ∧ code e2418939251950 = 11215032274158 := by decide
theorem cert_e2418939251950 : check e2418939251950 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939251958 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2418939251958 : Closed e2418939251958 ∧ code e2418939251958 = 11215032274166 := by decide
theorem cert_e2418939251958 : check e2418939251958 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939252334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2418939252334 : Closed e2418939252334 ∧ code e2418939252334 = 11215032274542 := by decide
theorem cert_e2418939252334 : check e2418939252334 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939252346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2418939252346 : Closed e2418939252346 ∧ code e2418939252346 = 11215032274554 := by decide
theorem cert_e2418939252346 : check e2418939252346 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939252534 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2418939252534 : Closed e2418939252534 ∧ code e2418939252534 = 11215032274742 := by decide
theorem cert_e2418939252534 : check e2418939252534 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939252538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2418939252538 : Closed e2418939252538 ∧ code e2418939252538 = 11215032274746 := by decide
theorem cert_e2418939252538 : check e2418939252538 [[],[],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2418939792238 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2418939792238 : Closed e2418939792238 ∧ code e2418939792238 = 11215032814446 := by decide
theorem cert_e2418939792238 : check e2418939792238 [[],[]] .smaller = true := by decide
def e2418939792246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2418939792246 : Closed e2418939792246 ∧ code e2418939792246 = 11215032814454 := by decide
theorem cert_e2418939792246 : check e2418939792246 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2418939182550
#print axioms Blc.Floor43.cert_e2418939182554
#print axioms Blc.Floor43.cert_e2418939197238
#print axioms Blc.Floor43.cert_e2418939197242
