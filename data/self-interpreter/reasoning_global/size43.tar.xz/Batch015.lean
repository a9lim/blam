import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e602935440238 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e602935440238 : Closed e602935440238 ∧ code e602935440238 = 9399028462446 := by decide
theorem cert_e602935440238 : check e602935440238 [[.under],[.under]] .chain = true := by decide
def e602935440246 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e602935440246 : Closed e602935440246 ∧ code e602935440246 = 9399028462454 := by decide
theorem cert_e602935440246 : check e602935440246 [[.under],[.under]] .chain = true := by decide
def e602935440302 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e602935440302 : Closed e602935440302 ∧ code e602935440302 = 9399028462510 := by decide
theorem cert_e602935440302 : check e602935440302 [[.under],[.under]] .chain = true := by decide
def e602935440314 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e602935440314 : Closed e602935440314 ∧ code e602935440314 = 9399028462522 := by decide
theorem cert_e602935440314 : check e602935440314 [[.under],[.under]] .chain = true := by decide
def e602935440342 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e602935440342 : Closed e602935440342 ∧ code e602935440342 = 9399028462550 := by decide
theorem cert_e602935440342 : check e602935440342 [[.under],[.under]] .chain = true := by decide
def e602935440346 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e602935440346 : Closed e602935440346 ∧ code e602935440346 = 9399028462554 := by decide
theorem cert_e602935440346 : check e602935440346 [[.under],[.under]] .chain = true := by decide
def e602935440622 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e602935440622 : Closed e602935440622 ∧ code e602935440622 = 9399028462830 := by decide
theorem cert_e602935440622 : check e602935440622 [[.under],[.under]] .chain = true := by decide
def e602935440630 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e602935440630 : Closed e602935440630 ∧ code e602935440630 = 9399028462838 := by decide
theorem cert_e602935440630 : check e602935440630 [[.under],[.under]] .chain = true := by decide
def e602935441006 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e602935441006 : Closed e602935441006 ∧ code e602935441006 = 9399028463214 := by decide
theorem cert_e602935441006 : check e602935441006 [[.under],[.under]] .chain = true := by decide
def e602935441018 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e602935441018 : Closed e602935441018 ∧ code e602935441018 = 9399028463226 := by decide
theorem cert_e602935441018 : check e602935441018 [[.under],[.under]] .chain = true := by decide
def e602935441206 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e602935441206 : Closed e602935441206 ∧ code e602935441206 = 9399028463414 := by decide
theorem cert_e602935441206 : check e602935441206 [[.under],[.under]] .chain = true := by decide
def e602935441210 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e602935441210 : Closed e602935441210 ∧ code e602935441210 = 9399028463418 := by decide
theorem cert_e602935441210 : check e602935441210 [[.under],[.under]] .chain = true := by decide
def e602935441838 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e602935441838 : Closed e602935441838 ∧ code e602935441838 = 9399028464046 := by decide
theorem cert_e602935441838 : check e602935441838 [[.under],[.under]] .chain = true := by decide
def e602935441850 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e602935441850 : Closed e602935441850 ∧ code e602935441850 = 9399028464058 := by decide
theorem cert_e602935441850 : check e602935441850 [[.under],[.under]] .chain = true := by decide
def e602935441898 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e602935441898 : Closed e602935441898 ∧ code e602935441898 = 9399028464106 := by decide
theorem cert_e602935441898 : check e602935441898 [[.under],[.under]] .chain = true := by decide
def e602935442030 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e602935442030 : Closed e602935442030 ∧ code e602935442030 = 9399028464238 := by decide
theorem cert_e602935442030 : check e602935442030 [[.under],[.under]] .chain = true := by decide
def e602935442042 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e602935442042 : Closed e602935442042 ∧ code e602935442042 = 9399028464250 := by decide
theorem cert_e602935442042 : check e602935442042 [[.under],[.under]] .chain = true := by decide
def e602935442330 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e602935442330 : Closed e602935442330 ∧ code e602935442330 = 9399028464538 := by decide
theorem cert_e602935442330 : check e602935442330 [[.under],[.under]] .chain = true := by decide
def e602935442646 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e602935442646 : Closed e602935442646 ∧ code e602935442646 = 9399028464854 := by decide
theorem cert_e602935442646 : check e602935442646 [[.under],[.under]] .chain = true := by decide
def e602935442650 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e602935442650 : Closed e602935442650 ∧ code e602935442650 = 9399028464858 := by decide
theorem cert_e602935442650 : check e602935442650 [[.under],[.under]] .chain = true := by decide
def e602935442666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e602935442666 : Closed e602935442666 ∧ code e602935442666 = 9399028464874 := by decide
theorem cert_e602935442666 : check e602935442666 [[.under],[.under]] .chain = true := by decide
def e602935442742 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e602935442742 : Closed e602935442742 ∧ code e602935442742 = 9399028464950 := by decide
theorem cert_e602935442742 : check e602935442742 [[.under],[.under]] .chain = true := by decide
def e602935442746 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e602935442746 : Closed e602935442746 ∧ code e602935442746 = 9399028464954 := by decide
theorem cert_e602935442746 : check e602935442746 [[.under],[.under]] .chain = true := by decide
def e602935442842 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e602935442842 : Closed e602935442842 ∧ code e602935442842 = 9399028465050 := by decide
theorem cert_e602935442842 : check e602935442842 [[.under],[.under]] .chain = true := by decide
def e602935446382 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e602935446382 : Closed e602935446382 ∧ code e602935446382 = 9399028468590 := by decide
theorem cert_e602935446382 : check e602935446382 [[.under],[.under]] .chain = true := by decide
def e602935446390 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e602935446390 : Closed e602935446390 ∧ code e602935446390 = 9399028468598 := by decide
theorem cert_e602935446390 : check e602935446390 [[.under],[.under]] .chain = true := by decide
def e602935446446 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e602935446446 : Closed e602935446446 ∧ code e602935446446 = 9399028468654 := by decide
theorem cert_e602935446446 : check e602935446446 [[.under],[.under]] .chain = true := by decide
def e602935446458 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e602935446458 : Closed e602935446458 ∧ code e602935446458 = 9399028468666 := by decide
theorem cert_e602935446458 : check e602935446458 [[.under],[.under]] .chain = true := by decide
def e602935446486 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e602935446486 : Closed e602935446486 ∧ code e602935446486 = 9399028468694 := by decide
theorem cert_e602935446486 : check e602935446486 [[.under],[.under]] .chain = true := by decide
def e602935446490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e602935446490 : Closed e602935446490 ∧ code e602935446490 = 9399028468698 := by decide
theorem cert_e602935446490 : check e602935446490 [[.under],[.under]] .chain = true := by decide
def e602935446766 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e602935446766 : Closed e602935446766 ∧ code e602935446766 = 9399028468974 := by decide
theorem cert_e602935446766 : check e602935446766 [[.under],[.under]] .chain = true := by decide
def e602935446774 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e602935446774 : Closed e602935446774 ∧ code e602935446774 = 9399028468982 := by decide
theorem cert_e602935446774 : check e602935446774 [[.under],[.under]] .chain = true := by decide
def e602935447150 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e602935447150 : Closed e602935447150 ∧ code e602935447150 = 9399028469358 := by decide
theorem cert_e602935447150 : check e602935447150 [[.under],[.under]] .chain = true := by decide
def e602935447162 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e602935447162 : Closed e602935447162 ∧ code e602935447162 = 9399028469370 := by decide
theorem cert_e602935447162 : check e602935447162 [[.under],[.under]] .chain = true := by decide
def e602935447350 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e602935447350 : Closed e602935447350 ∧ code e602935447350 = 9399028469558 := by decide
theorem cert_e602935447350 : check e602935447350 [[.under],[.under]] .chain = true := by decide
def e602935447354 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e602935447354 : Closed e602935447354 ∧ code e602935447354 = 9399028469562 := by decide
theorem cert_e602935447354 : check e602935447354 [[.under],[.under]] .chain = true := by decide
def e602935453102 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e602935453102 : Closed e602935453102 ∧ code e602935453102 = 9399028475310 := by decide
theorem cert_e602935453102 : check e602935453102 [[.under],[.under]] .chain = true := by decide
def e602935453114 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e602935453114 : Closed e602935453114 ∧ code e602935453114 = 9399028475322 := by decide
theorem cert_e602935453114 : check e602935453114 [[.under],[.under]] .chain = true := by decide
def e602935453162 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e602935453162 : Closed e602935453162 ∧ code e602935453162 = 9399028475370 := by decide
theorem cert_e602935453162 : check e602935453162 [[.under],[.under]] .chain = true := by decide
def e602935453294 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e602935453294 : Closed e602935453294 ∧ code e602935453294 = 9399028475502 := by decide
theorem cert_e602935453294 : check e602935453294 [[.under],[.under]] .chain = true := by decide
def e602935453306 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e602935453306 : Closed e602935453306 ∧ code e602935453306 = 9399028475514 := by decide
theorem cert_e602935453306 : check e602935453306 [[.under],[.under]] .chain = true := by decide
def e602935453594 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e602935453594 : Closed e602935453594 ∧ code e602935453594 = 9399028475802 := by decide
theorem cert_e602935453594 : check e602935453594 [[.under],[.under]] .chain = true := by decide
def e602935456470 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e602935456470 : Closed e602935456470 ∧ code e602935456470 = 9399028478678 := by decide
theorem cert_e602935456470 : check e602935456470 [[.under],[.under]] .chain = true := by decide
def e602935456474 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e602935456474 : Closed e602935456474 ∧ code e602935456474 = 9399028478682 := by decide
theorem cert_e602935456474 : check e602935456474 [[.under],[.under]] .chain = true := by decide
def e602935456490 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e602935456490 : Closed e602935456490 ∧ code e602935456490 = 9399028478698 := by decide
theorem cert_e602935456490 : check e602935456490 [[.under],[.under]] .chain = true := by decide
def e602935456566 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e602935456566 : Closed e602935456566 ∧ code e602935456566 = 9399028478774 := by decide
theorem cert_e602935456566 : check e602935456566 [[.under],[.under]] .chain = true := by decide
def e602935456570 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e602935456570 : Closed e602935456570 ∧ code e602935456570 = 9399028478778 := by decide
theorem cert_e602935456570 : check e602935456570 [[.under],[.under]] .chain = true := by decide
def e602935456666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e602935456666 : Closed e602935456666 ∧ code e602935456666 = 9399028478874 := by decide
theorem cert_e602935456666 : check e602935456666 [[.under],[.under]] .chain = true := by decide
def e602935593838 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e602935593838 : Closed e602935593838 ∧ code e602935593838 = 9399028616046 := by decide
theorem cert_e602935593838 : check e602935593838 [[.under],[.under]] .chain = true := by decide
def e602935593846 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e602935593846 : Closed e602935593846 ∧ code e602935593846 = 9399028616054 := by decide
theorem cert_e602935593846 : check e602935593846 [[.under],[.under]] .chain = true := by decide
def e602935593902 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e602935593902 : Closed e602935593902 ∧ code e602935593902 = 9399028616110 := by decide
theorem cert_e602935593902 : check e602935593902 [[.under],[.under]] .chain = true := by decide
def e602935593914 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e602935593914 : Closed e602935593914 ∧ code e602935593914 = 9399028616122 := by decide
theorem cert_e602935593914 : check e602935593914 [[.under],[.under]] .chain = true := by decide
def e602935593942 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e602935593942 : Closed e602935593942 ∧ code e602935593942 = 9399028616150 := by decide
theorem cert_e602935593942 : check e602935593942 [[.under],[.under]] .chain = true := by decide
def e602935593946 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e602935593946 : Closed e602935593946 ∧ code e602935593946 = 9399028616154 := by decide
theorem cert_e602935593946 : check e602935593946 [[.under],[.under]] .chain = true := by decide
def e602935594222 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e602935594222 : Closed e602935594222 ∧ code e602935594222 = 9399028616430 := by decide
theorem cert_e602935594222 : check e602935594222 [[.under],[.under]] .chain = true := by decide
def e602935594230 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e602935594230 : Closed e602935594230 ∧ code e602935594230 = 9399028616438 := by decide
theorem cert_e602935594230 : check e602935594230 [[.under],[.under]] .chain = true := by decide
def e602935594606 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e602935594606 : Closed e602935594606 ∧ code e602935594606 = 9399028616814 := by decide
theorem cert_e602935594606 : check e602935594606 [[.under],[.under]] .chain = true := by decide
def e602935594618 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e602935594618 : Closed e602935594618 ∧ code e602935594618 = 9399028616826 := by decide
theorem cert_e602935594618 : check e602935594618 [[.under],[.under]] .chain = true := by decide
def e602935594806 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e602935594806 : Closed e602935594806 ∧ code e602935594806 = 9399028617014 := by decide
theorem cert_e602935594806 : check e602935594806 [[.under],[.under]] .chain = true := by decide
def e602935594810 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e602935594810 : Closed e602935594810 ∧ code e602935594810 = 9399028617018 := by decide
theorem cert_e602935594810 : check e602935594810 [[.under],[.under]] .chain = true := by decide
def e602936183662 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e602936183662 : Closed e602936183662 ∧ code e602936183662 = 9399029205870 := by decide
theorem cert_e602936183662 : check e602936183662 [[.under],[.under]] .sourceHead = true := by decide
def e602936183670 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e602936183670 : Closed e602936183670 ∧ code e602936183670 = 9399029205878 := by decide
theorem cert_e602936183670 : check e602936183670 [[.under],[.under]] .sourceHead = true := by decide
def e602936183726 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e602936183726 : Closed e602936183726 ∧ code e602936183726 = 9399029205934 := by decide
theorem cert_e602936183726 : check e602936183726 [[.under],[.under]] .sourceHead = true := by decide
def e602936183738 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e602936183738 : Closed e602936183738 ∧ code e602936183738 = 9399029205946 := by decide
theorem cert_e602936183738 : check e602936183738 [[.under],[.under]] .sourceHead = true := by decide
def e602936183766 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e602936183766 : Closed e602936183766 ∧ code e602936183766 = 9399029205974 := by decide
theorem cert_e602936183766 : check e602936183766 [[.under],[.under]] .sourceHead = true := by decide
def e602936183770 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e602936183770 : Closed e602936183770 ∧ code e602936183770 = 9399029205978 := by decide
theorem cert_e602936183770 : check e602936183770 [[.under],[.under]] .sourceHead = true := by decide
def e602936184046 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e602936184046 : Closed e602936184046 ∧ code e602936184046 = 9399029206254 := by decide
theorem cert_e602936184046 : check e602936184046 [[.under],[.under]] .sourceHead = true := by decide
def e602936184054 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e602936184054 : Closed e602936184054 ∧ code e602936184054 = 9399029206262 := by decide
theorem cert_e602936184054 : check e602936184054 [[.under],[.under]] .sourceHead = true := by decide
def e602936184430 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e602936184430 : Closed e602936184430 ∧ code e602936184430 = 9399029206638 := by decide
theorem cert_e602936184430 : check e602936184430 [[.under],[.under]] .sourceHead = true := by decide
def e602936184442 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e602936184442 : Closed e602936184442 ∧ code e602936184442 = 9399029206650 := by decide
theorem cert_e602936184442 : check e602936184442 [[.under],[.under]] .sourceHead = true := by decide
def e602936184630 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e602936184630 : Closed e602936184630 ∧ code e602936184630 = 9399029206838 := by decide
theorem cert_e602936184630 : check e602936184630 [[.under],[.under]] .sourceHead = true := by decide
def e602936184634 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e602936184634 : Closed e602936184634 ∧ code e602936184634 = 9399029206842 := by decide
theorem cert_e602936184634 : check e602936184634 [[.under],[.under]] .sourceHead = true := by decide
def e603006786414 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e603006786414 : Closed e603006786414 ∧ code e603006786414 = 9399099808622 := by decide
theorem cert_e603006786414 : check e603006786414 [[.under]] .sourceHead = true := by decide
def e603006786422 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e603006786422 : Closed e603006786422 ∧ code e603006786422 = 9399099808630 := by decide
theorem cert_e603006786422 : check e603006786422 [[.under]] .sourceHead = true := by decide
def e603006786486 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e603006786486 : Closed e603006786486 ∧ code e603006786486 = 9399099808694 := by decide
theorem cert_e603006786486 : check e603006786486 [[.under]] .sourceHead = true := by decide
def e603006786926 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e603006786926 : Closed e603006786926 ∧ code e603006786926 = 9399099809134 := by decide
theorem cert_e603006786926 : check e603006786926 [[.under]] .sourceHead = true := by decide
def e603006786934 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e603006786934 : Closed e603006786934 ∧ code e603006786934 = 9399099809142 := by decide
theorem cert_e603006786934 : check e603006786934 [[.under]] .sourceHead = true := by decide
def e603006786990 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e603006786990 : Closed e603006786990 ∧ code e603006786990 = 9399099809198 := by decide
theorem cert_e603006786990 : check e603006786990 [[.under]] .sourceHead = true := by decide
def e603006787002 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e603006787002 : Closed e603006787002 ∧ code e603006787002 = 9399099809210 := by decide
theorem cert_e603006787002 : check e603006787002 [[.under]] .sourceHead = true := by decide
def e603006787030 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e603006787030 : Closed e603006787030 ∧ code e603006787030 = 9399099809238 := by decide
theorem cert_e603006787030 : check e603006787030 [[.under]] .sourceHead = true := by decide
def e603006787034 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e603006787034 : Closed e603006787034 ∧ code e603006787034 = 9399099809242 := by decide
theorem cert_e603006787034 : check e603006787034 [[.under]] .sourceHead = true := by decide
def e603006787254 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e603006787254 : Closed e603006787254 ∧ code e603006787254 = 9399099809462 := by decide
theorem cert_e603006787254 : check e603006787254 [[.under]] .sourceHead = true := by decide
def e603006787286 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e603006787286 : Closed e603006787286 ∧ code e603006787286 = 9399099809494 := by decide
theorem cert_e603006787286 : check e603006787286 [[.under]] .sourceHead = true := by decide
def e603006787290 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e603006787290 : Closed e603006787290 ∧ code e603006787290 = 9399099809498 := by decide
theorem cert_e603006787290 : check e603006787290 [[.under]] .sourceHead = true := by decide
def e603006789486 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e603006789486 : Closed e603006789486 ∧ code e603006789486 = 9399099811694 := by decide
theorem cert_e603006789486 : check e603006789486 [[.under]] .sourceHead = true := by decide
def e603006789494 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e603006789494 : Closed e603006789494 ∧ code e603006789494 = 9399099811702 := by decide
theorem cert_e603006789494 : check e603006789494 [[.under]] .sourceHead = true := by decide
def e603006789558 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e603006789558 : Closed e603006789558 ∧ code e603006789558 = 9399099811766 := by decide
theorem cert_e603006789558 : check e603006789558 [[.under]] .sourceHead = true := by decide
def e603006790894 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e603006790894 : Closed e603006790894 ∧ code e603006790894 = 9399099813102 := by decide
theorem cert_e603006790894 : check e603006790894 [[.under]] .sourceHead = true := by decide
def e603006790902 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e603006790902 : Closed e603006790902 ∧ code e603006790902 = 9399099813110 := by decide
theorem cert_e603006790902 : check e603006790902 [[.under]] .sourceHead = true := by decide
def e603006791286 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e603006791286 : Closed e603006791286 ∧ code e603006791286 = 9399099813494 := by decide
theorem cert_e603006791286 : check e603006791286 [[.under]] .sourceHead = true := by decide
def e603006792558 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e603006792558 : Closed e603006792558 ∧ code e603006792558 = 9399099814766 := by decide
theorem cert_e603006792558 : check e603006792558 [[.under]] .sourceHead = true := by decide
def e603006792566 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e603006792566 : Closed e603006792566 ∧ code e603006792566 = 9399099814774 := by decide
theorem cert_e603006792566 : check e603006792566 [[.under]] .sourceHead = true := by decide
def e603006792622 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e603006792622 : Closed e603006792622 ∧ code e603006792622 = 9399099814830 := by decide
theorem cert_e603006792622 : check e603006792622 [[.under]] .sourceHead = true := by decide
def e603006792634 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e603006792634 : Closed e603006792634 ∧ code e603006792634 = 9399099814842 := by decide
theorem cert_e603006792634 : check e603006792634 [[.under]] .sourceHead = true := by decide
def e603006792662 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e603006792662 : Closed e603006792662 ∧ code e603006792662 = 9399099814870 := by decide
theorem cert_e603006792662 : check e603006792662 [[.under]] .sourceHead = true := by decide
def e603006792666 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e603006792666 : Closed e603006792666 ∧ code e603006792666 = 9399099814874 := by decide
theorem cert_e603006792666 : check e603006792666 [[.under]] .sourceHead = true := by decide
def e603006792942 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e603006792942 : Closed e603006792942 ∧ code e603006792942 = 9399099815150 := by decide
theorem cert_e603006792942 : check e603006792942 [[.under]] .sourceHead = true := by decide
def e603006792950 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e603006792950 : Closed e603006792950 ∧ code e603006792950 = 9399099815158 := by decide
theorem cert_e603006792950 : check e603006792950 [[.under]] .sourceHead = true := by decide
def e603006793326 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e603006793326 : Closed e603006793326 ∧ code e603006793326 = 9399099815534 := by decide
theorem cert_e603006793326 : check e603006793326 [[.under]] .sourceHead = true := by decide
def e603006793338 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e603006793338 : Closed e603006793338 ∧ code e603006793338 = 9399099815546 := by decide
theorem cert_e603006793338 : check e603006793338 [[.under]] .sourceHead = true := by decide
def e603006793526 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e603006793526 : Closed e603006793526 ∧ code e603006793526 = 9399099815734 := by decide
theorem cert_e603006793526 : check e603006793526 [[.under]] .sourceHead = true := by decide
def e603006793530 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e603006793530 : Closed e603006793530 ∧ code e603006793530 = 9399099815738 := by decide
theorem cert_e603006793530 : check e603006793530 [[.under]] .sourceHead = true := by decide
def e603006794166 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e603006794166 : Closed e603006794166 ∧ code e603006794166 = 9399099816374 := by decide
theorem cert_e603006794166 : check e603006794166 [[.under]] .sourceHead = true := by decide
def e603006794198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e603006794198 : Closed e603006794198 ∧ code e603006794198 = 9399099816406 := by decide
theorem cert_e603006794198 : check e603006794198 [[.under]] .sourceHead = true := by decide
def e603006794202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e603006794202 : Closed e603006794202 ∧ code e603006794202 = 9399099816410 := by decide
theorem cert_e603006794202 : check e603006794202 [[.under]] .sourceHead = true := by decide
def e603006794358 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e603006794358 : Closed e603006794358 ∧ code e603006794358 = 9399099816566 := by decide
theorem cert_e603006794358 : check e603006794358 [[.under]] .sourceHead = true := by decide
def e603006794550 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e603006794550 : Closed e603006794550 ∧ code e603006794550 = 9399099816758 := by decide
theorem cert_e603006794550 : check e603006794550 [[.under]] .sourceHead = true := by decide
def e603006794554 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e603006794554 : Closed e603006794554 ∧ code e603006794554 = 9399099816762 := by decide
theorem cert_e603006794554 : check e603006794554 [[.under]] .sourceHead = true := by decide
def e603006801774 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e603006801774 : Closed e603006801774 ∧ code e603006801774 = 9399099823982 := by decide
theorem cert_e603006801774 : check e603006801774 [[.under]] .sourceHead = true := by decide
def e603006801782 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e603006801782 : Closed e603006801782 ∧ code e603006801782 = 9399099823990 := by decide
theorem cert_e603006801782 : check e603006801782 [[.under]] .sourceHead = true := by decide
def e603006801846 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e603006801846 : Closed e603006801846 ∧ code e603006801846 = 9399099824054 := by decide
theorem cert_e603006801846 : check e603006801846 [[.under]] .sourceHead = true := by decide
def e603006803182 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e603006803182 : Closed e603006803182 ∧ code e603006803182 = 9399099825390 := by decide
theorem cert_e603006803182 : check e603006803182 [[.under]] .sourceHead = true := by decide
def e603006803190 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e603006803190 : Closed e603006803190 ∧ code e603006803190 = 9399099825398 := by decide
theorem cert_e603006803190 : check e603006803190 [[.under]] .sourceHead = true := by decide
def e603006803574 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e603006803574 : Closed e603006803574 ∧ code e603006803574 = 9399099825782 := by decide
theorem cert_e603006803574 : check e603006803574 [[.under]] .sourceHead = true := by decide
def e603006815086 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e603006815086 : Closed e603006815086 ∧ code e603006815086 = 9399099837294 := by decide
theorem cert_e603006815086 : check e603006815086 [[.under]] .sourceHead = true := by decide
def e603006815094 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e603006815094 : Closed e603006815094 ∧ code e603006815094 = 9399099837302 := by decide
theorem cert_e603006815094 : check e603006815094 [[.under]] .sourceHead = true := by decide
def e603006815150 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e603006815150 : Closed e603006815150 ∧ code e603006815150 = 9399099837358 := by decide
theorem cert_e603006815150 : check e603006815150 [[.under]] .sourceHead = true := by decide
def e603006815162 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e603006815162 : Closed e603006815162 ∧ code e603006815162 = 9399099837370 := by decide
theorem cert_e603006815162 : check e603006815162 [[.under]] .sourceHead = true := by decide
def e603006815190 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e603006815190 : Closed e603006815190 ∧ code e603006815190 = 9399099837398 := by decide
theorem cert_e603006815190 : check e603006815190 [[.under]] .sourceHead = true := by decide
def e603006815194 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e603006815194 : Closed e603006815194 ∧ code e603006815194 = 9399099837402 := by decide
theorem cert_e603006815194 : check e603006815194 [[.under]] .sourceHead = true := by decide
def e603006815470 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e603006815470 : Closed e603006815470 ∧ code e603006815470 = 9399099837678 := by decide
theorem cert_e603006815470 : check e603006815470 [[.under]] .sourceHead = true := by decide
def e603006815478 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e603006815478 : Closed e603006815478 ∧ code e603006815478 = 9399099837686 := by decide
theorem cert_e603006815478 : check e603006815478 [[.under]] .sourceHead = true := by decide
def e603006815854 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e603006815854 : Closed e603006815854 ∧ code e603006815854 = 9399099838062 := by decide
theorem cert_e603006815854 : check e603006815854 [[.under]] .sourceHead = true := by decide
def e603006815866 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e603006815866 : Closed e603006815866 ∧ code e603006815866 = 9399099838074 := by decide
theorem cert_e603006815866 : check e603006815866 [[.under]] .sourceHead = true := by decide
def e603006816054 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e603006816054 : Closed e603006816054 ∧ code e603006816054 = 9399099838262 := by decide
theorem cert_e603006816054 : check e603006816054 [[.under]] .sourceHead = true := by decide
def e603006816058 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e603006816058 : Closed e603006816058 ∧ code e603006816058 = 9399099838266 := by decide
theorem cert_e603006816058 : check e603006816058 [[.under]] .sourceHead = true := by decide
def e603006821814 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e603006821814 : Closed e603006821814 ∧ code e603006821814 = 9399099844022 := by decide
theorem cert_e603006821814 : check e603006821814 [[.under]] .sourceHead = true := by decide
def e603006821846 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e603006821846 : Closed e603006821846 ∧ code e603006821846 = 9399099844054 := by decide
theorem cert_e603006821846 : check e603006821846 [[.under]] .sourceHead = true := by decide
def e603006821850 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e603006821850 : Closed e603006821850 ∧ code e603006821850 = 9399099844058 := by decide
theorem cert_e603006821850 : check e603006821850 [[.under]] .sourceHead = true := by decide
def e603006822006 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e603006822006 : Closed e603006822006 ∧ code e603006822006 = 9399099844214 := by decide
theorem cert_e603006822006 : check e603006822006 [[.under]] .sourceHead = true := by decide
def e603006822198 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e603006822198 : Closed e603006822198 ∧ code e603006822198 = 9399099844406 := by decide
theorem cert_e603006822198 : check e603006822198 [[.under]] .sourceHead = true := by decide
def e603006822202 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e603006822202 : Closed e603006822202 ∧ code e603006822202 = 9399099844410 := by decide
theorem cert_e603006822202 : check e603006822202 [[.under]] .sourceHead = true := by decide
def e603007159150 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e603007159150 : Closed e603007159150 ∧ code e603007159150 = 9399100181358 := by decide
theorem cert_e603007159150 : check e603007159150 [[.under]] .sourceHead = true := by decide
def e603007159158 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e603007159158 : Closed e603007159158 ∧ code e603007159158 = 9399100181366 := by decide
theorem cert_e603007159158 : check e603007159158 [[.under]] .sourceHead = true := by decide
def e603007159214 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e603007159214 : Closed e603007159214 ∧ code e603007159214 = 9399100181422 := by decide
theorem cert_e603007159214 : check e603007159214 [[.under]] .sourceHead = true := by decide
def e603007159226 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e603007159226 : Closed e603007159226 ∧ code e603007159226 = 9399100181434 := by decide
theorem cert_e603007159226 : check e603007159226 [[.under]] .sourceHead = true := by decide
def e603007159254 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e603007159254 : Closed e603007159254 ∧ code e603007159254 = 9399100181462 := by decide
theorem cert_e603007159254 : check e603007159254 [[.under]] .sourceHead = true := by decide
def e603007159258 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e603007159258 : Closed e603007159258 ∧ code e603007159258 = 9399100181466 := by decide
theorem cert_e603007159258 : check e603007159258 [[.under]] .sourceHead = true := by decide
def e603007159534 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e603007159534 : Closed e603007159534 ∧ code e603007159534 = 9399100181742 := by decide
theorem cert_e603007159534 : check e603007159534 [[.under]] .sourceHead = true := by decide
def e603007159542 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e603007159542 : Closed e603007159542 ∧ code e603007159542 = 9399100181750 := by decide
theorem cert_e603007159542 : check e603007159542 [[.under]] .sourceHead = true := by decide
def e603007159918 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e603007159918 : Closed e603007159918 ∧ code e603007159918 = 9399100182126 := by decide
theorem cert_e603007159918 : check e603007159918 [[.under]] .sourceHead = true := by decide
def e603007159930 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e603007159930 : Closed e603007159930 ∧ code e603007159930 = 9399100182138 := by decide
theorem cert_e603007159930 : check e603007159930 [[.under]] .sourceHead = true := by decide
def e603007160118 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e603007160118 : Closed e603007160118 ∧ code e603007160118 = 9399100182326 := by decide
theorem cert_e603007160118 : check e603007160118 [[.under]] .sourceHead = true := by decide
def e603007160122 : Term := (.lam (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e603007160122 : Closed e603007160122 ∧ code e603007160122 = 9399100182330 := by decide
theorem cert_e603007160122 : check e603007160122 [[.under]] .sourceHead = true := by decide
def e604528633370 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528633370 : Closed e604528633370 ∧ code e604528633370 = 9400621655578 := by decide
theorem cert_e604528633370 : check e604528633370 [[.under]] .width = true := by decide
def e604528666138 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528666138 : Closed e604528666138 ∧ code e604528666138 = 9400621688346 := by decide
theorem cert_e604528666138 : check e604528666138 [[.under]] .width = true := by decide
def e604528895514 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528895514 : Closed e604528895514 ∧ code e604528895514 = 9400621917722 := by decide
theorem cert_e604528895514 : check e604528895514 [[.under]] .width = true := by decide
def e604528944666 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604528944666 : Closed e604528944666 ∧ code e604528944666 = 9400621966874 := by decide
theorem cert_e604528944666 : check e604528944666 [[.under]] .width = true := by decide
def e604529059354 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604529059354 : Closed e604529059354 ∧ code e604529059354 = 9400622081562 := by decide
theorem cert_e604529059354 : check e604529059354 [[.under]] .width = true := by decide
def e604529075738 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604529075738 : Closed e604529075738 ∧ code e604529075738 = 9400622097946 := by decide
theorem cert_e604529075738 : check e604529075738 [[.under]] .width = true := by decide
def e604530206234 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604530206234 : Closed e604530206234 ∧ code e604530206234 = 9400623228442 := by decide
theorem cert_e604530206234 : check e604530206234 [[.under]] .width = true := by decide
def e604530239002 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604530239002 : Closed e604530239002 ∧ code e604530239002 = 9400623261210 := by decide
theorem cert_e604530239002 : check e604530239002 [[.under]] .width = true := by decide
def e604531779098 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604531779098 : Closed e604531779098 ∧ code e604531779098 = 9400624801306 := by decide
theorem cert_e604531779098 : check e604531779098 [[.under]] .width = true := by decide
def e604531828250 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604531828250 : Closed e604531828250 ∧ code e604531828250 = 9400624850458 := by decide
theorem cert_e604531828250 : check e604531828250 [[.under]] .width = true := by decide
def e604532598298 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604532598298 : Closed e604532598298 ∧ code e604532598298 = 9400625620506 := by decide
theorem cert_e604532598298 : check e604532598298 [[.under]] .width = true := by decide
def e604532614682 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e604532614682 : Closed e604532614682 ∧ code e604532614682 = 9400625636890 := by decide
theorem cert_e604532614682 : check e604532614682 [[.under]] .width = true := by decide
def e604634131822 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e604634131822 : Closed e604634131822 ∧ code e604634131822 = 9400727154030 := by decide
theorem cert_e604634131822 : check e604634131822 [[.under],[.under]] .three = true := by decide
def e604634131830 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e604634131830 : Closed e604634131830 ∧ code e604634131830 = 9400727154038 := by decide
theorem cert_e604634131830 : check e604634131830 [[.under],[.under]] .three = true := by decide
def e604634131886 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e604634131886 : Closed e604634131886 ∧ code e604634131886 = 9400727154094 := by decide
theorem cert_e604634131886 : check e604634131886 [[.under],[.under]] .three = true := by decide
def e604634131898 : Term := (.lam (.app (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e604634131898 : Closed e604634131898 ∧ code e604634131898 = 9400727154106 := by decide
theorem cert_e604634131898 : check e604634131898 [[.under],[.under]] .three = true := by decide
end Blc.Floor43
