import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411629798330 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 0))))))
theorem wire_e2411629798330 : Closed e2411629798330 ∧ code e2411629798330 = 11207722820538 := by decide
theorem cert_e2411629798330 : check e2411629798330 [[],[]] .chain = true := by decide
def e2411629798358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 0)) (.var 1))))))
theorem wire_e2411629798358 : Closed e2411629798358 ∧ code e2411629798358 = 11207722820566 := by decide
theorem cert_e2411629798358 : check e2411629798358 [[],[]] .chain = true := by decide
def e2411629798362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 0))))))
theorem wire_e2411629798362 : Closed e2411629798362 ∧ code e2411629798362 = 11207722820570 := by decide
theorem cert_e2411629798362 : check e2411629798362 [[],[]] .chain = true := by decide
def e2411629799662 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2411629799662 : Closed e2411629799662 ∧ code e2411629799662 = 11207722821870 := by decide
theorem cert_e2411629799662 : check e2411629799662 [[],[]] .chain = true := by decide
def e2411629799670 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2411629799670 : Closed e2411629799670 ∧ code e2411629799670 = 11207722821878 := by decide
theorem cert_e2411629799670 : check e2411629799670 [[],[]] .chain = true := by decide
def e2411629800222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2411629800222 : Closed e2411629800222 ∧ code e2411629800222 = 11207722822430 := by decide
theorem cert_e2411629800222 : check e2411629800222 [[],[]] .chain = true := by decide
def e2411629800334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2411629800334 : Closed e2411629800334 ∧ code e2411629800334 = 11207722822542 := by decide
theorem cert_e2411629800334 : check e2411629800334 [[],[]] .chain = true := by decide
def e2411629800558 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2411629800558 : Closed e2411629800558 ∧ code e2411629800558 = 11207722822766 := by decide
theorem cert_e2411629800558 : check e2411629800558 [[],[]] .chain = true := by decide
def e2411629800570 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2411629800570 : Closed e2411629800570 ∧ code e2411629800570 = 11207722822778 := by decide
theorem cert_e2411629800570 : check e2411629800570 [[],[]] .chain = true := by decide
def e2411629800734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2411629800734 : Closed e2411629800734 ∧ code e2411629800734 = 11207722822942 := by decide
theorem cert_e2411629800734 : check e2411629800734 [[],[]] .chain = true := by decide
def e2411629800902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2411629800902 : Closed e2411629800902 ∧ code e2411629800902 = 11207722823110 := by decide
theorem cert_e2411629800902 : check e2411629800902 [[],[]] .chain = true := by decide
def e2411629801014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629801014 : Closed e2411629801014 ∧ code e2411629801014 = 11207722823222 := by decide
theorem cert_e2411629801014 : check e2411629801014 [[],[]] .chain = true := by decide
def e2411629801018 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629801018 : Closed e2411629801018 ∧ code e2411629801018 = 11207722823226 := by decide
theorem cert_e2411629801018 : check e2411629801018 [[],[]] .chain = true := by decide
def e2411629801102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629801102 : Closed e2411629801102 ∧ code e2411629801102 = 11207722823310 := by decide
theorem cert_e2411629801102 : check e2411629801102 [[],[]] .chain = true := by decide
def e2411629801158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629801158 : Closed e2411629801158 ∧ code e2411629801158 = 11207722823366 := by decide
theorem cert_e2411629801158 : check e2411629801158 [[],[]] .chain = true := by decide
def e2411629801838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2411629801838 : Closed e2411629801838 ∧ code e2411629801838 = 11207722824046 := by decide
theorem cert_e2411629801838 : check e2411629801838 [[],[]] .chain = true := by decide
def e2411629801846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2411629801846 : Closed e2411629801846 ∧ code e2411629801846 = 11207722824054 := by decide
theorem cert_e2411629801846 : check e2411629801846 [[],[]] .chain = true := by decide
def e2411629801902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2411629801902 : Closed e2411629801902 ∧ code e2411629801902 = 11207722824110 := by decide
theorem cert_e2411629801902 : check e2411629801902 [[],[]] .chain = true := by decide
def e2411629801914 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 0))))))
theorem wire_e2411629801914 : Closed e2411629801914 ∧ code e2411629801914 = 11207722824122 := by decide
theorem cert_e2411629801914 : check e2411629801914 [[],[]] .chain = true := by decide
def e2411629801962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 0))))))
theorem wire_e2411629801962 : Closed e2411629801962 ∧ code e2411629801962 = 11207722824170 := by decide
theorem cert_e2411629801962 : check e2411629801962 [[],[]] .chain = true := by decide
def e2411629802606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2411629802606 : Closed e2411629802606 ∧ code e2411629802606 = 11207722824814 := by decide
theorem cert_e2411629802606 : check e2411629802606 [[],[]] .chain = true := by decide
def e2411629802618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2411629802618 : Closed e2411629802618 ∧ code e2411629802618 = 11207722824826 := by decide
theorem cert_e2411629802618 : check e2411629802618 [[],[]] .chain = true := by decide
def e2411629802782 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2411629802782 : Closed e2411629802782 ∧ code e2411629802782 = 11207722824990 := by decide
theorem cert_e2411629802782 : check e2411629802782 [[],[]] .chain = true := by decide
def e2411629802950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2411629802950 : Closed e2411629802950 ∧ code e2411629802950 = 11207722825158 := by decide
theorem cert_e2411629802950 : check e2411629802950 [[],[]] .chain = true := by decide
def e2411629803054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2411629803054 : Closed e2411629803054 ∧ code e2411629803054 = 11207722825262 := by decide
theorem cert_e2411629803054 : check e2411629803054 [[],[]] .chain = true := by decide
def e2411629803234 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2411629803234 : Closed e2411629803234 ∧ code e2411629803234 = 11207722825442 := by decide
theorem cert_e2411629803234 : check e2411629803234 [[],[]] .chain = true := by decide
def e2411629803246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e2411629803246 : Closed e2411629803246 ∧ code e2411629803246 = 11207722825454 := by decide
theorem cert_e2411629803246 : check e2411629803246 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629803286 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629803286 : Closed e2411629803286 ∧ code e2411629803286 = 11207722825494 := by decide
theorem cert_e2411629803286 : check e2411629803286 [[],[]] .chain = true := by decide
def e2411629803290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629803290 : Closed e2411629803290 ∧ code e2411629803290 = 11207722825498 := by decide
theorem cert_e2411629803290 : check e2411629803290 [[],[]] .chain = true := by decide
def e2411629803334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629803334 : Closed e2411629803334 ∧ code e2411629803334 = 11207722825542 := by decide
theorem cert_e2411629803334 : check e2411629803334 [[],[]] .chain = true := by decide
def e2411629803362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629803362 : Closed e2411629803362 ∧ code e2411629803362 = 11207722825570 := by decide
theorem cert_e2411629803362 : check e2411629803362 [[],[]] .chain = true := by decide
def e2411629803374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2411629803374 : Closed e2411629803374 ∧ code e2411629803374 = 11207722825582 := by decide
theorem cert_e2411629803374 : check e2411629803374 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629803382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2411629803382 : Closed e2411629803382 ∧ code e2411629803382 = 11207722825590 := by decide
theorem cert_e2411629803382 : check e2411629803382 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629803702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 1))))))
theorem wire_e2411629803702 : Closed e2411629803702 ∧ code e2411629803702 = 11207722825910 := by decide
theorem cert_e2411629803702 : check e2411629803702 [[],[]] .chain = true := by decide
def e2411629803734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 0)) (.var 1))))))
theorem wire_e2411629803734 : Closed e2411629803734 ∧ code e2411629803734 = 11207722825942 := by decide
theorem cert_e2411629803734 : check e2411629803734 [[],[]] .chain = true := by decide
def e2411629803738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 1)))) (.var 1)) (.var 0))))))
theorem wire_e2411629803738 : Closed e2411629803738 ∧ code e2411629803738 = 11207722825946 := by decide
theorem cert_e2411629803738 : check e2411629803738 [[],[]] .chain = true := by decide
def e2411629803754 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 0)) (.var 0))))))
theorem wire_e2411629803754 : Closed e2411629803754 ∧ code e2411629803754 = 11207722825962 := by decide
theorem cert_e2411629803754 : check e2411629803754 [[],[]] .chain = true := by decide
def e2411629804086 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2411629804086 : Closed e2411629804086 ∧ code e2411629804086 = 11207722826294 := by decide
theorem cert_e2411629804086 : check e2411629804086 [[],[]] .chain = true := by decide
def e2411629804090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2411629804090 : Closed e2411629804090 ∧ code e2411629804090 = 11207722826298 := by decide
theorem cert_e2411629804090 : check e2411629804090 [[],[]] .chain = true := by decide
def e2411629804174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2411629804174 : Closed e2411629804174 ∧ code e2411629804174 = 11207722826382 := by decide
theorem cert_e2411629804174 : check e2411629804174 [[],[]] .chain = true := by decide
def e2411629804230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2411629804230 : Closed e2411629804230 ∧ code e2411629804230 = 11207722826438 := by decide
theorem cert_e2411629804230 : check e2411629804230 [[],[]] .chain = true := by decide
def e2411629804310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2411629804310 : Closed e2411629804310 ∧ code e2411629804310 = 11207722826518 := by decide
theorem cert_e2411629804310 : check e2411629804310 [[],[]] .chain = true := by decide
def e2411629804314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 1))) (.var 0))))))
theorem wire_e2411629804314 : Closed e2411629804314 ∧ code e2411629804314 = 11207722826522 := by decide
theorem cert_e2411629804314 : check e2411629804314 [[],[]] .chain = true := by decide
def e2411629804358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 1)))))))
theorem wire_e2411629804358 : Closed e2411629804358 ∧ code e2411629804358 = 11207722826566 := by decide
theorem cert_e2411629804358 : check e2411629804358 [[],[]] .chain = true := by decide
def e2411629804386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2411629804386 : Closed e2411629804386 ∧ code e2411629804386 = 11207722826594 := by decide
theorem cert_e2411629804386 : check e2411629804386 [[],[]] .chain = true := by decide
def e2411629804398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2411629804398 : Closed e2411629804398 ∧ code e2411629804398 = 11207722826606 := by decide
theorem cert_e2411629804398 : check e2411629804398 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2411629804406 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2411629804406 : Closed e2411629804406 ∧ code e2411629804406 = 11207722826614 := by decide
theorem cert_e2411629804406 : check e2411629804406 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411629804470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2411629804470 : Closed e2411629804470 ∧ code e2411629804470 = 11207722826678 := by decide
theorem cert_e2411629804470 : check e2411629804470 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2411629807342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2411629807342 : Closed e2411629807342 ∧ code e2411629807342 = 11207722829550 := by decide
theorem cert_e2411629807342 : check e2411629807342 [[],[]] .chain = true := by decide
def e2411629807350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 3)))) (.var 1))))))
theorem wire_e2411629807350 : Closed e2411629807350 ∧ code e2411629807350 = 11207722829558 := by decide
theorem cert_e2411629807350 : check e2411629807350 [[],[]] .chain = true := by decide
def e2411629807534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2411629807534 : Closed e2411629807534 ∧ code e2411629807534 = 11207722829742 := by decide
theorem cert_e2411629807534 : check e2411629807534 [[],[]] .chain = true := by decide
def e2411629807574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 0)))) (.var 1))))))
theorem wire_e2411629807574 : Closed e2411629807574 ∧ code e2411629807574 = 11207722829782 := by decide
theorem cert_e2411629807574 : check e2411629807574 [[],[]] .chain = true := by decide
def e2411629808878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629808878 : Closed e2411629808878 ∧ code e2411629808878 = 11207722831086 := by decide
theorem cert_e2411629808878 : check e2411629808878 [[],[]] .chain = true := by decide
def e2411629808886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629808886 : Closed e2411629808886 ∧ code e2411629808886 = 11207722831094 := by decide
theorem cert_e2411629808886 : check e2411629808886 [[],[]] .chain = true := by decide
def e2411629809262 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629809262 : Closed e2411629809262 ∧ code e2411629809262 = 11207722831470 := by decide
theorem cert_e2411629809262 : check e2411629809262 [[],[]] .chain = true := by decide
def e2411629809274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629809274 : Closed e2411629809274 ∧ code e2411629809274 = 11207722831482 := by decide
theorem cert_e2411629809274 : check e2411629809274 [[],[]] .chain = true := by decide
def e2411629809462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629809462 : Closed e2411629809462 ∧ code e2411629809462 = 11207722831670 := by decide
theorem cert_e2411629809462 : check e2411629809462 [[],[]] .chain = true := by decide
def e2411629809466 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629809466 : Closed e2411629809466 ∧ code e2411629809466 = 11207722831674 := by decide
theorem cert_e2411629809466 : check e2411629809466 [[],[]] .chain = true := by decide
def e2411629811950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 2)))) (.var 2))))))
theorem wire_e2411629811950 : Closed e2411629811950 ∧ code e2411629811950 = 11207722834158 := by decide
theorem cert_e2411629811950 : check e2411629811950 [[],[]] .chain = true := by decide
def e2411629811958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 3)))) (.var 1))))))
theorem wire_e2411629811958 : Closed e2411629811958 ∧ code e2411629811958 = 11207722834166 := by decide
theorem cert_e2411629811958 : check e2411629811958 [[],[]] .chain = true := by decide
def e2411629812510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 3)))))))
theorem wire_e2411629812510 : Closed e2411629812510 ∧ code e2411629812510 = 11207722834718 := by decide
theorem cert_e2411629812510 : check e2411629812510 [[],[]] .chain = true := by decide
def e2411629812622 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 2)))))))
theorem wire_e2411629812622 : Closed e2411629812622 ∧ code e2411629812622 = 11207722834830 := by decide
theorem cert_e2411629812622 : check e2411629812622 [[],[]] .chain = true := by decide
def e2411629812846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2411629812846 : Closed e2411629812846 ∧ code e2411629812846 = 11207722835054 := by decide
theorem cert_e2411629812846 : check e2411629812846 [[],[]] .chain = true := by decide
def e2411629812858 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411629812858 : Closed e2411629812858 ∧ code e2411629812858 = 11207722835066 := by decide
theorem cert_e2411629812858 : check e2411629812858 [[],[]] .chain = true := by decide
def e2411629813022 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2411629813022 : Closed e2411629813022 ∧ code e2411629813022 = 11207722835230 := by decide
theorem cert_e2411629813022 : check e2411629813022 [[],[]] .chain = true := by decide
def e2411629813190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411629813190 : Closed e2411629813190 ∧ code e2411629813190 = 11207722835398 := by decide
theorem cert_e2411629813190 : check e2411629813190 [[],[]] .chain = true := by decide
def e2411629813302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2411629813302 : Closed e2411629813302 ∧ code e2411629813302 = 11207722835510 := by decide
theorem cert_e2411629813302 : check e2411629813302 [[],[]] .chain = true := by decide
def e2411629813306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2411629813306 : Closed e2411629813306 ∧ code e2411629813306 = 11207722835514 := by decide
theorem cert_e2411629813306 : check e2411629813306 [[],[]] .chain = true := by decide
def e2411629813390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2411629813390 : Closed e2411629813390 ∧ code e2411629813390 = 11207722835598 := by decide
theorem cert_e2411629813390 : check e2411629813390 [[],[]] .chain = true := by decide
def e2411629813446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2411629813446 : Closed e2411629813446 ∧ code e2411629813446 = 11207722835654 := by decide
theorem cert_e2411629813446 : check e2411629813446 [[],[]] .chain = true := by decide
def e2411629815582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 3))))))))
theorem wire_e2411629815582 : Closed e2411629815582 ∧ code e2411629815582 = 11207722837790 := by decide
theorem cert_e2411629815582 : check e2411629815582 [[],[]] .chain = true := by decide
def e2411629815694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 2))))))))
theorem wire_e2411629815694 : Closed e2411629815694 ∧ code e2411629815694 = 11207722837902 := by decide
theorem cert_e2411629815694 : check e2411629815694 [[],[]] .chain = true := by decide
def e2411629818078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2411629818078 : Closed e2411629818078 ∧ code e2411629818078 = 11207722840286 := by decide
theorem cert_e2411629818078 : check e2411629818078 [[],[]] .chain = true := by decide
def e2411629818106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2411629818106 : Closed e2411629818106 ∧ code e2411629818106 = 11207722840314 := by decide
theorem cert_e2411629818106 : check e2411629818106 [[],[]] .chain = true := by decide
def e2411629818654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2411629818654 : Closed e2411629818654 ∧ code e2411629818654 = 11207722840862 := by decide
theorem cert_e2411629818654 : check e2411629818654 [[],[]] .chain = true := by decide
def e2411629818822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2411629818822 : Closed e2411629818822 ∧ code e2411629818822 = 11207722841030 := by decide
theorem cert_e2411629818822 : check e2411629818822 [[],[]] .chain = true := by decide
def e2411629820014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2411629820014 : Closed e2411629820014 ∧ code e2411629820014 = 11207722842222 := by decide
theorem cert_e2411629820014 : check e2411629820014 [[],[]] .chain = true := by decide
def e2411629820026 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2411629820026 : Closed e2411629820026 ∧ code e2411629820026 = 11207722842234 := by decide
theorem cert_e2411629820026 : check e2411629820026 [[],[]] .chain = true := by decide
def e2411629820302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411629820302 : Closed e2411629820302 ∧ code e2411629820302 = 11207722842510 := by decide
theorem cert_e2411629820302 : check e2411629820302 [[],[]] .chain = true := by decide
def e2411629820358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411629820358 : Closed e2411629820358 ∧ code e2411629820358 = 11207722842566 := by decide
theorem cert_e2411629820358 : check e2411629820358 [[],[]] .chain = true := by decide
def e2411629822446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2411629822446 : Closed e2411629822446 ∧ code e2411629822446 = 11207722844654 := by decide
theorem cert_e2411629822446 : check e2411629822446 [[],[]] .chain = true := by decide
def e2411629822454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2411629822454 : Closed e2411629822454 ∧ code e2411629822454 = 11207722844662 := by decide
theorem cert_e2411629822454 : check e2411629822454 [[],[]] .chain = true := by decide
def e2411629822830 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2411629822830 : Closed e2411629822830 ∧ code e2411629822830 = 11207722845038 := by decide
theorem cert_e2411629822830 : check e2411629822830 [[],[]] .chain = true := by decide
def e2411629822842 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.var 3)))) (.var 0))))))
theorem wire_e2411629822842 : Closed e2411629822842 ∧ code e2411629822842 = 11207722845050 := by decide
theorem cert_e2411629822842 : check e2411629822842 [[],[]] .chain = true := by decide
def e2411629822894 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2411629822894 : Closed e2411629822894 ∧ code e2411629822894 = 11207722845102 := by decide
theorem cert_e2411629822894 : check e2411629822894 [[],[]] .chain = true := by decide
def e2411629822954 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 0)))) (.var 0))))))
theorem wire_e2411629822954 : Closed e2411629822954 ∧ code e2411629822954 = 11207722845162 := by decide
theorem cert_e2411629822954 : check e2411629822954 [[],[]] .chain = true := by decide
def e2411629823214 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629823214 : Closed e2411629823214 ∧ code e2411629823214 = 11207722845422 := by decide
theorem cert_e2411629823214 : check e2411629823214 [[],[]] .chain = true := by decide
def e2411629823222 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629823222 : Closed e2411629823222 ∧ code e2411629823222 = 11207722845430 := by decide
theorem cert_e2411629823222 : check e2411629823222 [[],[]] .chain = true := by decide
def e2411629823598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411629823598 : Closed e2411629823598 ∧ code e2411629823598 = 11207722845806 := by decide
theorem cert_e2411629823598 : check e2411629823598 [[],[]] .chain = true := by decide
def e2411629823610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411629823610 : Closed e2411629823610 ∧ code e2411629823610 = 11207722845818 := by decide
theorem cert_e2411629823610 : check e2411629823610 [[],[]] .chain = true := by decide
def e2411629823774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2411629823774 : Closed e2411629823774 ∧ code e2411629823774 = 11207722845982 := by decide
theorem cert_e2411629823774 : check e2411629823774 [[],[]] .chain = true := by decide
def e2411629823886 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2411629823886 : Closed e2411629823886 ∧ code e2411629823886 = 11207722846094 := by decide
theorem cert_e2411629823886 : check e2411629823886 [[],[]] .chain = true := by decide
def e2411629823898 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.lam (.var 3))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629823898 : Closed e2411629823898 ∧ code e2411629823898 = 11207722846106 := by decide
theorem cert_e2411629823898 : check e2411629823898 [[],[]] .chain = true := by decide
def e2411629825134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 1)))) (.var 2))))))
theorem wire_e2411629825134 : Closed e2411629825134 ∧ code e2411629825134 = 11207722847342 := by decide
theorem cert_e2411629825134 : check e2411629825134 [[],[]] .chain = true := by decide
def e2411629825146 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.lam (.var 3)))) (.var 0))))))
theorem wire_e2411629825146 : Closed e2411629825146 ∧ code e2411629825146 = 11207722847354 := by decide
theorem cert_e2411629825146 : check e2411629825146 [[],[]] .chain = true := by decide
def e2411629825310 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0))) (.lam (.var 3)))))))
theorem wire_e2411629825310 : Closed e2411629825310 ∧ code e2411629825310 = 11207722847518 := by decide
theorem cert_e2411629825310 : check e2411629825310 [[],[]] .chain = true := by decide
def e2411629825478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 1)))))))
theorem wire_e2411629825478 : Closed e2411629825478 ∧ code e2411629825478 = 11207722847686 := by decide
theorem cert_e2411629825478 : check e2411629825478 [[],[]] .chain = true := by decide
def e2411629825582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2411629825582 : Closed e2411629825582 ∧ code e2411629825582 = 11207722847790 := by decide
theorem cert_e2411629825582 : check e2411629825582 [[],[]] .chain = true := by decide
def e2411629825762 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2411629825762 : Closed e2411629825762 ∧ code e2411629825762 = 11207722847970 := by decide
theorem cert_e2411629825762 : check e2411629825762 [[],[]] .chain = true := by decide
def e2411629825774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2411629825774 : Closed e2411629825774 ∧ code e2411629825774 = 11207722847982 := by decide
theorem cert_e2411629825774 : check e2411629825774 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629825814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411629825814 : Closed e2411629825814 ∧ code e2411629825814 = 11207722848022 := by decide
theorem cert_e2411629825814 : check e2411629825814 [[],[]] .chain = true := by decide
def e2411629825818 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411629825818 : Closed e2411629825818 ∧ code e2411629825818 = 11207722848026 := by decide
theorem cert_e2411629825818 : check e2411629825818 [[],[]] .chain = true := by decide
def e2411629825862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411629825862 : Closed e2411629825862 ∧ code e2411629825862 = 11207722848070 := by decide
theorem cert_e2411629825862 : check e2411629825862 [[],[]] .chain = true := by decide
def e2411629825890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411629825890 : Closed e2411629825890 ∧ code e2411629825890 = 11207722848098 := by decide
theorem cert_e2411629825890 : check e2411629825890 [[],[]] .chain = true := by decide
def e2411629825902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2411629825902 : Closed e2411629825902 ∧ code e2411629825902 = 11207722848110 := by decide
theorem cert_e2411629825902 : check e2411629825902 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629825910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2411629825910 : Closed e2411629825910 ∧ code e2411629825910 = 11207722848118 := by decide
theorem cert_e2411629825910 : check e2411629825910 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629826270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2411629826270 : Closed e2411629826270 ∧ code e2411629826270 = 11207722848478 := by decide
theorem cert_e2411629826270 : check e2411629826270 [[],[]] .chain = true := by decide
def e2411629826298 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2411629826298 : Closed e2411629826298 ∧ code e2411629826298 = 11207722848506 := by decide
theorem cert_e2411629826298 : check e2411629826298 [[],[]] .chain = true := by decide
def e2411629826846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2411629826846 : Closed e2411629826846 ∧ code e2411629826846 = 11207722849054 := by decide
theorem cert_e2411629826846 : check e2411629826846 [[],[]] .chain = true := by decide
def e2411629827014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2411629827014 : Closed e2411629827014 ∧ code e2411629827014 = 11207722849222 := by decide
theorem cert_e2411629827014 : check e2411629827014 [[],[]] .chain = true := by decide
def e2411629828158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2411629828158 : Closed e2411629828158 ∧ code e2411629828158 = 11207722850366 := by decide
theorem cert_e2411629828158 : check e2411629828158 [[],[]] .chain = true := by decide
def e2411629828578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2411629828578 : Closed e2411629828578 ∧ code e2411629828578 = 11207722850786 := by decide
theorem cert_e2411629828578 : check e2411629828578 [[],[]] .chain = true := by decide
def e2411629828590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2411629828590 : Closed e2411629828590 ∧ code e2411629828590 = 11207722850798 := by decide
theorem cert_e2411629828590 : check e2411629828590 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629829150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2411629829150 : Closed e2411629829150 ∧ code e2411629829150 = 11207722851358 := by decide
theorem cert_e2411629829150 : check e2411629829150 [[],[]] .chain = true := by decide
def e2411629829174 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411629829174 : Closed e2411629829174 ∧ code e2411629829174 = 11207722851382 := by decide
theorem cert_e2411629829174 : check e2411629829174 [[],[]] .chain = true := by decide
def e2411629829178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411629829178 : Closed e2411629829178 ∧ code e2411629829178 = 11207722851386 := by decide
theorem cert_e2411629829178 : check e2411629829178 [[],[]] .chain = true := by decide
def e2411629829318 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411629829318 : Closed e2411629829318 ∧ code e2411629829318 = 11207722851526 := by decide
theorem cert_e2411629829318 : check e2411629829318 [[],[]] .chain = true := by decide
def e2411629829346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411629829346 : Closed e2411629829346 ∧ code e2411629829346 = 11207722851554 := by decide
theorem cert_e2411629829346 : check e2411629829346 [[],[]] .chain = true := by decide
def e2411629829358 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629829358 : Closed e2411629829358 ∧ code e2411629829358 = 11207722851566 := by decide
theorem cert_e2411629829358 : check e2411629829358 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629829366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629829366 : Closed e2411629829366 ∧ code e2411629829366 = 11207722851574 := by decide
theorem cert_e2411629829366 : check e2411629829366 [[.left,.left],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2411629830390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.lam (.var 3)))) (.var 1))))))
theorem wire_e2411629830390 : Closed e2411629830390 ∧ code e2411629830390 = 11207722852598 := by decide
theorem cert_e2411629830390 : check e2411629830390 [[],[]] .chain = true := by decide
def e2411629830582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2411629830582 : Closed e2411629830582 ∧ code e2411629830582 = 11207722852790 := by decide
theorem cert_e2411629830582 : check e2411629830582 [[],[]] .chain = true := by decide
def e2411629830586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2411629830586 : Closed e2411629830586 ∧ code e2411629830586 = 11207722852794 := by decide
theorem cert_e2411629830586 : check e2411629830586 [[],[]] .chain = true := by decide
def e2411629830614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2411629830614 : Closed e2411629830614 ∧ code e2411629830614 = 11207722852822 := by decide
theorem cert_e2411629830614 : check e2411629830614 [[],[]] .chain = true := by decide
def e2411629830634 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2411629830634 : Closed e2411629830634 ∧ code e2411629830634 = 11207722852842 := by decide
theorem cert_e2411629830634 : check e2411629830634 [[],[]] .chain = true := by decide
def e2411629830774 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629830774 : Closed e2411629830774 ∧ code e2411629830774 = 11207722852982 := by decide
theorem cert_e2411629830774 : check e2411629830774 [[],[]] .chain = true := by decide
def e2411629830966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411629830966 : Closed e2411629830966 ∧ code e2411629830966 = 11207722853174 := by decide
theorem cert_e2411629830966 : check e2411629830966 [[],[]] .chain = true := by decide
def e2411629830970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411629830970 : Closed e2411629830970 ∧ code e2411629830970 = 11207722853178 := by decide
theorem cert_e2411629830970 : check e2411629830970 [[],[]] .chain = true := by decide
def e2411629831054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.lam (.var 2)))))))
theorem wire_e2411629831054 : Closed e2411629831054 ∧ code e2411629831054 = 11207722853262 := by decide
theorem cert_e2411629831054 : check e2411629831054 [[],[]] .chain = true := by decide
def e2411629831066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411629831066 : Closed e2411629831066 ∧ code e2411629831066 = 11207722853274 := by decide
theorem cert_e2411629831066 : check e2411629831066 [[],[]] .chain = true := by decide
def e2411629831734 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2411629831734 : Closed e2411629831734 ∧ code e2411629831734 = 11207722853942 := by decide
theorem cert_e2411629831734 : check e2411629831734 [[],[]] .chain = true := by decide
def e2411629831738 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2411629831738 : Closed e2411629831738 ∧ code e2411629831738 = 11207722853946 := by decide
theorem cert_e2411629831738 : check e2411629831738 [[],[]] .chain = true := by decide
def e2411629831822 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2411629831822 : Closed e2411629831822 ∧ code e2411629831822 = 11207722854030 := by decide
theorem cert_e2411629831822 : check e2411629831822 [[],[]] .chain = true := by decide
def e2411629831878 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2411629831878 : Closed e2411629831878 ∧ code e2411629831878 = 11207722854086 := by decide
theorem cert_e2411629831878 : check e2411629831878 [[],[]] .chain = true := by decide
def e2411629831958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2411629831958 : Closed e2411629831958 ∧ code e2411629831958 = 11207722854166 := by decide
theorem cert_e2411629831958 : check e2411629831958 [[],[]] .chain = true := by decide
def e2411629831962 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2411629831962 : Closed e2411629831962 ∧ code e2411629831962 = 11207722854170 := by decide
theorem cert_e2411629831962 : check e2411629831962 [[],[]] .chain = true := by decide
def e2411629832006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2411629832006 : Closed e2411629832006 ∧ code e2411629832006 = 11207722854214 := by decide
theorem cert_e2411629832006 : check e2411629832006 [[],[]] .chain = true := by decide
def e2411629832034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2411629832034 : Closed e2411629832034 ∧ code e2411629832034 = 11207722854242 := by decide
theorem cert_e2411629832034 : check e2411629832034 [[],[]] .chain = true := by decide
def e2411629832046 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2411629832046 : Closed e2411629832046 ∧ code e2411629832046 = 11207722854254 := by decide
theorem cert_e2411629832046 : check e2411629832046 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411629832054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2411629832054 : Closed e2411629832054 ∧ code e2411629832054 = 11207722854262 := by decide
theorem cert_e2411629832054 : check e2411629832054 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411629832118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2411629832118 : Closed e2411629832118 ∧ code e2411629832118 = 11207722854326 := by decide
theorem cert_e2411629832118 : check e2411629832118 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411629832302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 0) (.var 2))))))))
theorem wire_e2411629832302 : Closed e2411629832302 ∧ code e2411629832302 = 11207722854510 := by decide
theorem cert_e2411629832302 : check e2411629832302 [[],[]] .chain = true := by decide
def e2411629832314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.lam (.app (.var 2) (.var 0))))))))
theorem wire_e2411629832314 : Closed e2411629832314 ∧ code e2411629832314 = 11207722854522 := by decide
theorem cert_e2411629832314 : check e2411629832314 [[],[]] .chain = true := by decide
def e2411629832590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2411629832590 : Closed e2411629832590 ∧ code e2411629832590 = 11207722854798 := by decide
theorem cert_e2411629832590 : check e2411629832590 [[],[]] .chain = true := by decide
def e2411629832646 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2411629832646 : Closed e2411629832646 ∧ code e2411629832646 = 11207722854854 := by decide
theorem cert_e2411629832646 : check e2411629832646 [[],[]] .chain = true := by decide
def e2411629833246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.lam (.var 3))))))))
theorem wire_e2411629833246 : Closed e2411629833246 ∧ code e2411629833246 = 11207722855454 := by decide
theorem cert_e2411629833246 : check e2411629833246 [[],[]] .chain = true := by decide
def e2411629833270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411629833270 : Closed e2411629833270 ∧ code e2411629833270 = 11207722855478 := by decide
theorem cert_e2411629833270 : check e2411629833270 [[],[]] .chain = true := by decide
def e2411629833274 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411629833274 : Closed e2411629833274 ∧ code e2411629833274 = 11207722855482 := by decide
theorem cert_e2411629833274 : check e2411629833274 [[],[]] .chain = true := by decide
def e2411629833414 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411629833414 : Closed e2411629833414 ∧ code e2411629833414 = 11207722855622 := by decide
theorem cert_e2411629833414 : check e2411629833414 [[],[]] .chain = true := by decide
def e2411629833442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411629833442 : Closed e2411629833442 ∧ code e2411629833442 = 11207722855650 := by decide
theorem cert_e2411629833442 : check e2411629833442 [[],[]] .chain = true := by decide
def e2411629833454 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2411629833454 : Closed e2411629833454 ∧ code e2411629833454 = 11207722855662 := by decide
theorem cert_e2411629833454 : check e2411629833454 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411629833462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2411629833462 : Closed e2411629833462 ∧ code e2411629833462 = 11207722855670 := by decide
theorem cert_e2411629833462 : check e2411629833462 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2411629833846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2411629833846 : Closed e2411629833846 ∧ code e2411629833846 = 11207722856054 := by decide
theorem cert_e2411629833846 : check e2411629833846 [[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2411629840238 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2411629840238 : Closed e2411629840238 ∧ code e2411629840238 = 11207722862446 := by decide
theorem cert_e2411629840238 : check e2411629840238 [[],[]] .chain = true := by decide
def e2411629840246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2411629840246 : Closed e2411629840246 ∧ code e2411629840246 = 11207722862454 := by decide
theorem cert_e2411629840246 : check e2411629840246 [[],[]] .chain = true := by decide
def e2411629840302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e2411629840302 : Closed e2411629840302 ∧ code e2411629840302 = 11207722862510 := by decide
theorem cert_e2411629840302 : check e2411629840302 [[],[]] .chain = true := by decide
def e2411629840314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e2411629840314 : Closed e2411629840314 ∧ code e2411629840314 = 11207722862522 := by decide
theorem cert_e2411629840314 : check e2411629840314 [[],[]] .chain = true := by decide
def e2411629840342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))
theorem wire_e2411629840342 : Closed e2411629840342 ∧ code e2411629840342 = 11207722862550 := by decide
theorem cert_e2411629840342 : check e2411629840342 [[],[]] .chain = true := by decide
def e2411629840346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))
theorem wire_e2411629840346 : Closed e2411629840346 ∧ code e2411629840346 = 11207722862554 := by decide
theorem cert_e2411629840346 : check e2411629840346 [[],[]] .chain = true := by decide
def e2411629841838 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.app (.var 0) (.var 1)))) (.var 0)) (.var 2))))))
theorem wire_e2411629841838 : Closed e2411629841838 ∧ code e2411629841838 = 11207722864046 := by decide
theorem cert_e2411629841838 : check e2411629841838 [[],[]] .chain = true := by decide
end Blc.Floor43
