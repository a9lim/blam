import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2405436982690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405436982690 : Closed e2405436982690 ∧ code e2405436982690 = 11201530004898 := by decide
theorem cert_e2405436982690 : check e2405436982690 [[]] .width = true := by decide
def e2405436982798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405436982798 : Closed e2405436982798 ∧ code e2405436982798 = 11201530005006 := by decide
theorem cert_e2405436982798 : check e2405436982798 [[]] .width = true := by decide
def e2405436982810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405436982810 : Closed e2405436982810 ∧ code e2405436982810 = 11201530005018 := by decide
theorem cert_e2405436982810 : check e2405436982810 [[]] .width = true := by decide
def e2405436982882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405436982882 : Closed e2405436982882 ∧ code e2405436982882 = 11201530005090 := by decide
theorem cert_e2405436982882 : check e2405436982882 [[]] .width = true := by decide
def e2405437259974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405437259974 : Closed e2405437259974 ∧ code e2405437259974 = 11201530282182 := by decide
theorem cert_e2405437259974 : check e2405437259974 [[]] .width = true := by decide
def e2405437419718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405437419718 : Closed e2405437419718 ∧ code e2405437419718 = 11201530441926 := by decide
theorem cert_e2405437419718 : check e2405437419718 [[]] .width = true := by decide
def e2405437440026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405437440026 : Closed e2405437440026 ∧ code e2405437440026 = 11201530462234 := by decide
theorem cert_e2405437440026 : check e2405437440026 [[]] .width = true := by decide
def e2405437440118 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405437440118 : Closed e2405437440118 ∧ code e2405437440118 = 11201530462326 := by decide
theorem cert_e2405437440118 : check e2405437440118 [[]] .width = true := by decide
def e2405437440362 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405437440362 : Closed e2405437440362 ∧ code e2405437440362 = 11201530462570 := by decide
theorem cert_e2405437440362 : check e2405437440362 [[]] .width = true := by decide
def e2405437440410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405437440410 : Closed e2405437440410 ∧ code e2405437440410 = 11201530462618 := by decide
theorem cert_e2405437440410 : check e2405437440410 [[]] .width = true := by decide
def e2405437441418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405437441418 : Closed e2405437441418 ∧ code e2405437441418 = 11201530463626 := by decide
theorem cert_e2405437441418 : check e2405437441418 [[]] .width = true := by decide
def e2405437441442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405437441442 : Closed e2405437441442 ∧ code e2405437441442 = 11201530463650 := by decide
theorem cert_e2405437441442 : check e2405437441442 [[]] .width = true := by decide
def e2405437441550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405437441550 : Closed e2405437441550 ∧ code e2405437441550 = 11201530463758 := by decide
theorem cert_e2405437441550 : check e2405437441550 [[]] .width = true := by decide
def e2405437441562 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405437441562 : Closed e2405437441562 ∧ code e2405437441562 = 11201530463770 := by decide
theorem cert_e2405437441562 : check e2405437441562 [[]] .width = true := by decide
def e2405437441634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405437441634 : Closed e2405437441634 ∧ code e2405437441634 = 11201530463842 := by decide
theorem cert_e2405437441634 : check e2405437441634 [[]] .width = true := by decide
def e2405437456582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405437456582 : Closed e2405437456582 ∧ code e2405437456582 = 11201530478790 := by decide
theorem cert_e2405437456582 : check e2405437456582 [[]] .width = true := by decide
def e2405442220230 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405442220230 : Closed e2405442220230 ∧ code e2405442220230 = 11201535242438 := by decide
theorem cert_e2405442220230 : check e2405442220230 [[]] .width = true := by decide
def e2405442236614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.lam (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405442236614 : Closed e2405442236614 ∧ code e2405442236614 = 11201535258822 := by decide
theorem cert_e2405442236614 : check e2405442236614 [[]] .width = true := by decide
def e2405443219654 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443219654 : Closed e2405443219654 ∧ code e2405443219654 = 11201536241862 := by decide
theorem cert_e2405443219654 : check e2405443219654 [[]] .width = true := by decide
def e2405443227846 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443227846 : Closed e2405443227846 ∧ code e2405443227846 = 11201536250054 := by decide
theorem cert_e2405443227846 : check e2405443227846 [[]] .width = true := by decide
def e2405443231258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443231258 : Closed e2405443231258 ∧ code e2405443231258 = 11201536253466 := by decide
theorem cert_e2405443231258 : check e2405443231258 [[]] .width = true := by decide
def e2405443237402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 0) (.var 3)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443237402 : Closed e2405443237402 ∧ code e2405443237402 = 11201536259610 := by decide
theorem cert_e2405443237402 : check e2405443237402 [[]] .width = true := by decide
def e2405443260614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443260614 : Closed e2405443260614 ∧ code e2405443260614 = 11201536282822 := by decide
theorem cert_e2405443260614 : check e2405443260614 [[]] .width = true := by decide
def e2405443264026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443264026 : Closed e2405443264026 ∧ code e2405443264026 = 11201536286234 := by decide
theorem cert_e2405443264026 : check e2405443264026 [[]] .width = true := by decide
def e2405443271194 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 1) (.var 3)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443271194 : Closed e2405443271194 ∧ code e2405443271194 = 11201536293402 := by decide
theorem cert_e2405443271194 : check e2405443271194 [[]] .width = true := by decide
def e2405443294746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443294746 : Closed e2405443294746 ∧ code e2405443294746 = 11201536316954 := by decide
theorem cert_e2405443294746 : check e2405443294746 [[]] .width = true := by decide
def e2405443295770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.app (.var 3) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443295770 : Closed e2405443295770 ∧ code e2405443295770 = 11201536317978 := by decide
theorem cert_e2405443295770 : check e2405443295770 [[]] .width = true := by decide
def e2405443362842 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405443362842 : Closed e2405443362842 ∧ code e2405443362842 = 11201536385050 := by decide
theorem cert_e2405443362842 : check e2405443362842 [[]] .width = true := by decide
def e2405443362934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405443362934 : Closed e2405443362934 ∧ code e2405443362934 = 11201536385142 := by decide
theorem cert_e2405443362934 : check e2405443362934 [[]] .width = true := by decide
def e2405443363178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405443363178 : Closed e2405443363178 ∧ code e2405443363178 = 11201536385386 := by decide
theorem cert_e2405443363178 : check e2405443363178 [[]] .width = true := by decide
def e2405443363226 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405443363226 : Closed e2405443363226 ∧ code e2405443363226 = 11201536385434 := by decide
theorem cert_e2405443363226 : check e2405443363226 [[]] .width = true := by decide
def e2405443367110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443367110 : Closed e2405443367110 ∧ code e2405443367110 = 11201536389318 := by decide
theorem cert_e2405443367110 : check e2405443367110 [[]] .width = true := by decide
def e2405443416262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443416262 : Closed e2405443416262 ∧ code e2405443416262 = 11201536438470 := by decide
theorem cert_e2405443416262 : check e2405443416262 [[]] .width = true := by decide
def e2405443424454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443424454 : Closed e2405443424454 ∧ code e2405443424454 = 11201536446662 := by decide
theorem cert_e2405443424454 : check e2405443424454 [[]] .width = true := by decide
def e2405443427866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443427866 : Closed e2405443427866 ∧ code e2405443427866 = 11201536450074 := by decide
theorem cert_e2405443427866 : check e2405443427866 [[]] .width = true := by decide
def e2405443434010 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.app (.var 3) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443434010 : Closed e2405443434010 ∧ code e2405443434010 = 11201536456218 := by decide
theorem cert_e2405443434010 : check e2405443434010 [[]] .width = true := by decide
def e2405443502278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405443502278 : Closed e2405443502278 ∧ code e2405443502278 = 11201536524486 := by decide
theorem cert_e2405443502278 : check e2405443502278 [[]] .width = true := by decide
def e2405443502806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405443502806 : Closed e2405443502806 ∧ code e2405443502806 = 11201536525014 := by decide
theorem cert_e2405443502806 : check e2405443502806 [[]] .width = true := by decide
def e2405443502810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405443502810 : Closed e2405443502810 ∧ code e2405443502810 = 11201536525018 := by decide
theorem cert_e2405443502810 : check e2405443502810 [[]] .width = true := by decide
def e2405443502826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405443502826 : Closed e2405443502826 ∧ code e2405443502826 = 11201536525034 := by decide
theorem cert_e2405443502826 : check e2405443502826 [[]] .width = true := by decide
def e2405443502902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405443502902 : Closed e2405443502902 ∧ code e2405443502902 = 11201536525110 := by decide
theorem cert_e2405443502902 : check e2405443502902 [[]] .width = true := by decide
def e2405443502906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405443502906 : Closed e2405443502906 ∧ code e2405443502906 = 11201536525114 := by decide
theorem cert_e2405443502906 : check e2405443502906 [[]] .width = true := by decide
def e2405443502990 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405443502990 : Closed e2405443502990 ∧ code e2405443502990 = 11201536525198 := by decide
theorem cert_e2405443502990 : check e2405443502990 [[]] .width = true := by decide
def e2405443503002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405443503002 : Closed e2405443503002 ∧ code e2405443503002 = 11201536525210 := by decide
theorem cert_e2405443503002 : check e2405443503002 [[]] .width = true := by decide
def e2405443504922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405443504922 : Closed e2405443504922 ∧ code e2405443504922 = 11201536527130 := by decide
theorem cert_e2405443504922 : check e2405443504922 [[]] .width = true := by decide
def e2405443504966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405443504966 : Closed e2405443504966 ∧ code e2405443504966 = 11201536527174 := by decide
theorem cert_e2405443504966 : check e2405443504966 [[]] .width = true := by decide
def e2405443505206 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405443505206 : Closed e2405443505206 ∧ code e2405443505206 = 11201536527414 := by decide
theorem cert_e2405443505206 : check e2405443505206 [[]] .width = true := by decide
def e2405443505210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405443505210 : Closed e2405443505210 ∧ code e2405443505210 = 11201536527418 := by decide
theorem cert_e2405443505210 : check e2405443505210 [[]] .width = true := by decide
def e2405443505350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405443505350 : Closed e2405443505350 ∧ code e2405443505350 = 11201536527558 := by decide
theorem cert_e2405443505350 : check e2405443505350 [[]] .width = true := by decide
def e2405443534874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405443534874 : Closed e2405443534874 ∧ code e2405443534874 = 11201536557082 := by decide
theorem cert_e2405443534874 : check e2405443534874 [[]] .width = true := by decide
def e2405443534966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405443534966 : Closed e2405443534966 ∧ code e2405443534966 = 11201536557174 := by decide
theorem cert_e2405443534966 : check e2405443534966 [[]] .width = true := by decide
def e2405443535210 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405443535210 : Closed e2405443535210 ∧ code e2405443535210 = 11201536557418 := by decide
theorem cert_e2405443535210 : check e2405443535210 [[]] .width = true := by decide
def e2405443535258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405443535258 : Closed e2405443535258 ∧ code e2405443535258 = 11201536557466 := by decide
theorem cert_e2405443535258 : check e2405443535258 [[]] .width = true := by decide
def e2405443536266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405443536266 : Closed e2405443536266 ∧ code e2405443536266 = 11201536558474 := by decide
theorem cert_e2405443536266 : check e2405443536266 [[]] .width = true := by decide
def e2405443536290 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405443536290 : Closed e2405443536290 ∧ code e2405443536290 = 11201536558498 := by decide
theorem cert_e2405443536290 : check e2405443536290 [[]] .width = true := by decide
def e2405443536398 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405443536398 : Closed e2405443536398 ∧ code e2405443536398 = 11201536558606 := by decide
theorem cert_e2405443536398 : check e2405443536398 [[]] .width = true := by decide
def e2405443536410 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405443536410 : Closed e2405443536410 ∧ code e2405443536410 = 11201536558618 := by decide
theorem cert_e2405443536410 : check e2405443536410 [[]] .width = true := by decide
def e2405443536482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405443536482 : Closed e2405443536482 ∧ code e2405443536482 = 11201536558690 := by decide
theorem cert_e2405443536482 : check e2405443536482 [[]] .width = true := by decide
def e2405443592218 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405443592218 : Closed e2405443592218 ∧ code e2405443592218 = 11201536614426 := by decide
theorem cert_e2405443592218 : check e2405443592218 [[]] .width = true := by decide
def e2405443592310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2405443592310 : Closed e2405443592310 ∧ code e2405443592310 = 11201536614518 := by decide
theorem cert_e2405443592310 : check e2405443592310 [[]] .width = true := by decide
def e2405443592554 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2405443592554 : Closed e2405443592554 ∧ code e2405443592554 = 11201536614762 := by decide
theorem cert_e2405443592554 : check e2405443592554 [[]] .width = true := by decide
def e2405443592602 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2405443592602 : Closed e2405443592602 ∧ code e2405443592602 = 11201536614810 := by decide
theorem cert_e2405443592602 : check e2405443592602 [[]] .width = true := by decide
def e2405443621062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443621062 : Closed e2405443621062 ∧ code e2405443621062 = 11201536643270 := by decide
theorem cert_e2405443621062 : check e2405443621062 [[]] .width = true := by decide
def e2405443624474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443624474 : Closed e2405443624474 ∧ code e2405443624474 = 11201536646682 := by decide
theorem cert_e2405443624474 : check e2405443624474 [[]] .width = true := by decide
def e2405443631642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.app (.var 3) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443631642 : Closed e2405443631642 ∧ code e2405443631642 = 11201536653850 := by decide
theorem cert_e2405443631642 : check e2405443631642 [[]] .width = true := by decide
def e2405443633350 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.var 1)))))))
theorem wire_e2405443633350 : Closed e2405443633350 ∧ code e2405443633350 = 11201536655558 := by decide
theorem cert_e2405443633350 : check e2405443633350 [[]] .width = true := by decide
def e2405443633878 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))
theorem wire_e2405443633878 : Closed e2405443633878 ∧ code e2405443633878 = 11201536656086 := by decide
theorem cert_e2405443633878 : check e2405443633878 [[]] .width = true := by decide
def e2405443633882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))
theorem wire_e2405443633882 : Closed e2405443633882 ∧ code e2405443633882 = 11201536656090 := by decide
theorem cert_e2405443633882 : check e2405443633882 [[]] .width = true := by decide
def e2405443633898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))
theorem wire_e2405443633898 : Closed e2405443633898 ∧ code e2405443633898 = 11201536656106 := by decide
theorem cert_e2405443633898 : check e2405443633898 [[]] .width = true := by decide
def e2405443633974 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))
theorem wire_e2405443633974 : Closed e2405443633974 ∧ code e2405443633974 = 11201536656182 := by decide
theorem cert_e2405443633974 : check e2405443633974 [[]] .width = true := by decide
def e2405443633978 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))
theorem wire_e2405443633978 : Closed e2405443633978 ∧ code e2405443633978 = 11201536656186 := by decide
theorem cert_e2405443633978 : check e2405443633978 [[]] .width = true := by decide
def e2405443634062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.lam (.var 2))))))
theorem wire_e2405443634062 : Closed e2405443634062 ∧ code e2405443634062 = 11201536656270 := by decide
theorem cert_e2405443634062 : check e2405443634062 [[]] .width = true := by decide
def e2405443634074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))
theorem wire_e2405443634074 : Closed e2405443634074 ∧ code e2405443634074 = 11201536656282 := by decide
theorem cert_e2405443634074 : check e2405443634074 [[]] .width = true := by decide
def e2405443635994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))
theorem wire_e2405443635994 : Closed e2405443635994 ∧ code e2405443635994 = 11201536658202 := by decide
theorem cert_e2405443635994 : check e2405443635994 [[]] .width = true := by decide
def e2405443636038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))
theorem wire_e2405443636038 : Closed e2405443636038 ∧ code e2405443636038 = 11201536658246 := by decide
theorem cert_e2405443636038 : check e2405443636038 [[]] .width = true := by decide
def e2405443636278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))
theorem wire_e2405443636278 : Closed e2405443636278 ∧ code e2405443636278 = 11201536658486 := by decide
theorem cert_e2405443636278 : check e2405443636278 [[]] .width = true := by decide
def e2405443636282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))
theorem wire_e2405443636282 : Closed e2405443636282 ∧ code e2405443636282 = 11201536658490 := by decide
theorem cert_e2405443636282 : check e2405443636282 [[]] .width = true := by decide
def e2405443636422 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405443636422 : Closed e2405443636422 ∧ code e2405443636422 = 11201536658630 := by decide
theorem cert_e2405443636422 : check e2405443636422 [[]] .width = true := by decide
def e2405443682502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405443682502 : Closed e2405443682502 ∧ code e2405443682502 = 11201536704710 := by decide
theorem cert_e2405443682502 : check e2405443682502 [[]] .width = true := by decide
def e2405443711174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2405443711174 : Closed e2405443711174 ∧ code e2405443711174 = 11201536733382 := by decide
theorem cert_e2405443711174 : check e2405443711174 [[]] .width = true := by decide
def e2405443731482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2405443731482 : Closed e2405443731482 ∧ code e2405443731482 = 11201536753690 := by decide
theorem cert_e2405443731482 : check e2405443731482 [[]] .width = true := by decide
def e2405443731574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2405443731574 : Closed e2405443731574 ∧ code e2405443731574 = 11201536753782 := by decide
theorem cert_e2405443731574 : check e2405443731574 [[]] .width = true := by decide
def e2405443731818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2405443731818 : Closed e2405443731818 ∧ code e2405443731818 = 11201536754026 := by decide
theorem cert_e2405443731818 : check e2405443731818 [[]] .width = true := by decide
def e2405443731866 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2405443731866 : Closed e2405443731866 ∧ code e2405443731866 = 11201536754074 := by decide
theorem cert_e2405443731866 : check e2405443731866 [[]] .width = true := by decide
def e2405443732874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2405443732874 : Closed e2405443732874 ∧ code e2405443732874 = 11201536755082 := by decide
theorem cert_e2405443732874 : check e2405443732874 [[]] .width = true := by decide
def e2405443732898 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2405443732898 : Closed e2405443732898 ∧ code e2405443732898 = 11201536755106 := by decide
theorem cert_e2405443732898 : check e2405443732898 [[]] .width = true := by decide
def e2405443733006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2405443733006 : Closed e2405443733006 ∧ code e2405443733006 = 11201536755214 := by decide
theorem cert_e2405443733006 : check e2405443733006 [[]] .width = true := by decide
def e2405443733018 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2405443733018 : Closed e2405443733018 ∧ code e2405443733018 = 11201536755226 := by decide
theorem cert_e2405443733018 : check e2405443733018 [[]] .width = true := by decide
def e2405443733090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2405443733090 : Closed e2405443733090 ∧ code e2405443733090 = 11201536755298 := by decide
theorem cert_e2405443733090 : check e2405443733090 [[]] .width = true := by decide
def e2405443748038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e2405443748038 : Closed e2405443748038 ∧ code e2405443748038 = 11201536770246 := by decide
theorem cert_e2405443748038 : check e2405443748038 [[]] .width = true := by decide
def e2405443778074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443778074 : Closed e2405443778074 ∧ code e2405443778074 = 11201536800282 := by decide
theorem cert_e2405443778074 : check e2405443778074 [[]] .width = true := by decide
def e2405443779098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 3) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2405443779098 : Closed e2405443779098 ∧ code e2405443779098 = 11201536801306 := by decide
theorem cert_e2405443779098 : check e2405443779098 [[]] .width = true := by decide
def e2405685091182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))
theorem wire_e2405685091182 : Closed e2405685091182 ∧ code e2405685091182 = 11201778113390 := by decide
theorem cert_e2405685091182 : check e2405685091182 [[],[]] .chain = true := by decide
def e2405685091190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))
theorem wire_e2405685091190 : Closed e2405685091190 ∧ code e2405685091190 = 11201778113398 := by decide
theorem cert_e2405685091190 : check e2405685091190 [[],[]] .chain = true := by decide
def e2405685091254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))
theorem wire_e2405685091254 : Closed e2405685091254 ∧ code e2405685091254 = 11201778113462 := by decide
theorem cert_e2405685091254 : check e2405685091254 [[],[]] .chain = true := by decide
def e2405685091694 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2405685091694 : Closed e2405685091694 ∧ code e2405685091694 = 11201778113902 := by decide
theorem cert_e2405685091694 : check e2405685091694 [[],[]] .chain = true := by decide
def e2405685091702 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2405685091702 : Closed e2405685091702 ∧ code e2405685091702 = 11201778113910 := by decide
theorem cert_e2405685091702 : check e2405685091702 [[],[]] .chain = true := by decide
def e2405685091758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2405685091758 : Closed e2405685091758 ∧ code e2405685091758 = 11201778113966 := by decide
theorem cert_e2405685091758 : check e2405685091758 [[],[]] .chain = true := by decide
def e2405685091770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2405685091770 : Closed e2405685091770 ∧ code e2405685091770 = 11201778113978 := by decide
theorem cert_e2405685091770 : check e2405685091770 [[],[]] .chain = true := by decide
def e2405685091798 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2405685091798 : Closed e2405685091798 ∧ code e2405685091798 = 11201778114006 := by decide
theorem cert_e2405685091798 : check e2405685091798 [[],[]] .chain = true := by decide
def e2405685091802 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2405685091802 : Closed e2405685091802 ∧ code e2405685091802 = 11201778114010 := by decide
theorem cert_e2405685091802 : check e2405685091802 [[],[]] .chain = true := by decide
def e2405685092022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2405685092022 : Closed e2405685092022 ∧ code e2405685092022 = 11201778114230 := by decide
theorem cert_e2405685092022 : check e2405685092022 [[],[]] .chain = true := by decide
def e2405685092054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2405685092054 : Closed e2405685092054 ∧ code e2405685092054 = 11201778114262 := by decide
theorem cert_e2405685092054 : check e2405685092054 [[],[]] .chain = true := by decide
def e2405685092058 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2405685092058 : Closed e2405685092058 ∧ code e2405685092058 = 11201778114266 := by decide
theorem cert_e2405685092058 : check e2405685092058 [[],[]] .chain = true := by decide
def e2405685094254 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2405685094254 : Closed e2405685094254 ∧ code e2405685094254 = 11201778116462 := by decide
theorem cert_e2405685094254 : check e2405685094254 [[],[]] .chain = true := by decide
def e2405685094262 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2405685094262 : Closed e2405685094262 ∧ code e2405685094262 = 11201778116470 := by decide
theorem cert_e2405685094262 : check e2405685094262 [[],[]] .chain = true := by decide
def e2405685094326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2405685094326 : Closed e2405685094326 ∧ code e2405685094326 = 11201778116534 := by decide
theorem cert_e2405685094326 : check e2405685094326 [[],[]] .chain = true := by decide
def e2405685095662 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2405685095662 : Closed e2405685095662 ∧ code e2405685095662 = 11201778117870 := by decide
theorem cert_e2405685095662 : check e2405685095662 [[],[]] .chain = true := by decide
def e2405685095670 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2405685095670 : Closed e2405685095670 ∧ code e2405685095670 = 11201778117878 := by decide
theorem cert_e2405685095670 : check e2405685095670 [[],[]] .chain = true := by decide
def e2405685096054 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2405685096054 : Closed e2405685096054 ∧ code e2405685096054 = 11201778118262 := by decide
theorem cert_e2405685096054 : check e2405685096054 [[],[]] .chain = true := by decide
def e2405685097326 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2405685097326 : Closed e2405685097326 ∧ code e2405685097326 = 11201778119534 := by decide
theorem cert_e2405685097326 : check e2405685097326 [[],[]] .chain = true := by decide
def e2405685097334 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2405685097334 : Closed e2405685097334 ∧ code e2405685097334 = 11201778119542 := by decide
theorem cert_e2405685097334 : check e2405685097334 [[],[]] .chain = true := by decide
def e2405685097390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2405685097390 : Closed e2405685097390 ∧ code e2405685097390 = 11201778119598 := by decide
theorem cert_e2405685097390 : check e2405685097390 [[],[]] .chain = true := by decide
def e2405685097402 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2405685097402 : Closed e2405685097402 ∧ code e2405685097402 = 11201778119610 := by decide
theorem cert_e2405685097402 : check e2405685097402 [[],[]] .chain = true := by decide
def e2405685097430 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2405685097430 : Closed e2405685097430 ∧ code e2405685097430 = 11201778119638 := by decide
theorem cert_e2405685097430 : check e2405685097430 [[],[]] .chain = true := by decide
def e2405685097434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2405685097434 : Closed e2405685097434 ∧ code e2405685097434 = 11201778119642 := by decide
theorem cert_e2405685097434 : check e2405685097434 [[],[]] .chain = true := by decide
def e2405685097710 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2405685097710 : Closed e2405685097710 ∧ code e2405685097710 = 11201778119918 := by decide
theorem cert_e2405685097710 : check e2405685097710 [[],[]] .chain = true := by decide
def e2405685097718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2405685097718 : Closed e2405685097718 ∧ code e2405685097718 = 11201778119926 := by decide
theorem cert_e2405685097718 : check e2405685097718 [[],[]] .chain = true := by decide
def e2405685098094 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2405685098094 : Closed e2405685098094 ∧ code e2405685098094 = 11201778120302 := by decide
theorem cert_e2405685098094 : check e2405685098094 [[],[]] .chain = true := by decide
def e2405685098106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2405685098106 : Closed e2405685098106 ∧ code e2405685098106 = 11201778120314 := by decide
theorem cert_e2405685098106 : check e2405685098106 [[],[]] .chain = true := by decide
def e2405685098294 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2405685098294 : Closed e2405685098294 ∧ code e2405685098294 = 11201778120502 := by decide
theorem cert_e2405685098294 : check e2405685098294 [[],[]] .chain = true := by decide
def e2405685098298 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2405685098298 : Closed e2405685098298 ∧ code e2405685098298 = 11201778120506 := by decide
theorem cert_e2405685098298 : check e2405685098298 [[],[]] .chain = true := by decide
def e2405685098934 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))
theorem wire_e2405685098934 : Closed e2405685098934 ∧ code e2405685098934 = 11201778121142 := by decide
theorem cert_e2405685098934 : check e2405685098934 [[],[]] .chain = true := by decide
def e2405685098966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))
theorem wire_e2405685098966 : Closed e2405685098966 ∧ code e2405685098966 = 11201778121174 := by decide
theorem cert_e2405685098966 : check e2405685098966 [[],[]] .chain = true := by decide
def e2405685098970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))
theorem wire_e2405685098970 : Closed e2405685098970 ∧ code e2405685098970 = 11201778121178 := by decide
theorem cert_e2405685098970 : check e2405685098970 [[],[]] .chain = true := by decide
def e2405685099126 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))
theorem wire_e2405685099126 : Closed e2405685099126 ∧ code e2405685099126 = 11201778121334 := by decide
theorem cert_e2405685099126 : check e2405685099126 [[],[]] .chain = true := by decide
def e2405685099318 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))
theorem wire_e2405685099318 : Closed e2405685099318 ∧ code e2405685099318 = 11201778121526 := by decide
theorem cert_e2405685099318 : check e2405685099318 [[],[]] .chain = true := by decide
def e2405685099322 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))
theorem wire_e2405685099322 : Closed e2405685099322 ∧ code e2405685099322 = 11201778121530 := by decide
theorem cert_e2405685099322 : check e2405685099322 [[],[]] .chain = true := by decide
def e2405685106542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2405685106542 : Closed e2405685106542 ∧ code e2405685106542 = 11201778128750 := by decide
theorem cert_e2405685106542 : check e2405685106542 [[],[]] .chain = true := by decide
def e2405685106550 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2405685106550 : Closed e2405685106550 ∧ code e2405685106550 = 11201778128758 := by decide
theorem cert_e2405685106550 : check e2405685106550 [[],[]] .chain = true := by decide
def e2405685106614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2405685106614 : Closed e2405685106614 ∧ code e2405685106614 = 11201778128822 := by decide
theorem cert_e2405685106614 : check e2405685106614 [[],[]] .chain = true := by decide
def e2405685107950 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2405685107950 : Closed e2405685107950 ∧ code e2405685107950 = 11201778130158 := by decide
theorem cert_e2405685107950 : check e2405685107950 [[],[]] .chain = true := by decide
def e2405685107958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2405685107958 : Closed e2405685107958 ∧ code e2405685107958 = 11201778130166 := by decide
theorem cert_e2405685107958 : check e2405685107958 [[],[]] .chain = true := by decide
def e2405685108342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2405685108342 : Closed e2405685108342 ∧ code e2405685108342 = 11201778130550 := by decide
theorem cert_e2405685108342 : check e2405685108342 [[],[]] .chain = true := by decide
def e2405685119854 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2405685119854 : Closed e2405685119854 ∧ code e2405685119854 = 11201778142062 := by decide
theorem cert_e2405685119854 : check e2405685119854 [[],[]] .chain = true := by decide
def e2405685119862 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2405685119862 : Closed e2405685119862 ∧ code e2405685119862 = 11201778142070 := by decide
theorem cert_e2405685119862 : check e2405685119862 [[],[]] .chain = true := by decide
def e2405685119918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2405685119918 : Closed e2405685119918 ∧ code e2405685119918 = 11201778142126 := by decide
theorem cert_e2405685119918 : check e2405685119918 [[],[]] .chain = true := by decide
def e2405685119930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2405685119930 : Closed e2405685119930 ∧ code e2405685119930 = 11201778142138 := by decide
theorem cert_e2405685119930 : check e2405685119930 [[],[]] .chain = true := by decide
def e2405685119958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2405685119958 : Closed e2405685119958 ∧ code e2405685119958 = 11201778142166 := by decide
theorem cert_e2405685119958 : check e2405685119958 [[],[]] .chain = true := by decide
def e2405685119962 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2405685119962 : Closed e2405685119962 ∧ code e2405685119962 = 11201778142170 := by decide
theorem cert_e2405685119962 : check e2405685119962 [[],[]] .chain = true := by decide
def e2405685120238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2405685120238 : Closed e2405685120238 ∧ code e2405685120238 = 11201778142446 := by decide
theorem cert_e2405685120238 : check e2405685120238 [[],[]] .chain = true := by decide
def e2405685120246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2405685120246 : Closed e2405685120246 ∧ code e2405685120246 = 11201778142454 := by decide
theorem cert_e2405685120246 : check e2405685120246 [[],[]] .chain = true := by decide
def e2405685120622 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2405685120622 : Closed e2405685120622 ∧ code e2405685120622 = 11201778142830 := by decide
theorem cert_e2405685120622 : check e2405685120622 [[],[]] .chain = true := by decide
def e2405685120634 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2405685120634 : Closed e2405685120634 ∧ code e2405685120634 = 11201778142842 := by decide
theorem cert_e2405685120634 : check e2405685120634 [[],[]] .chain = true := by decide
def e2405685120822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2405685120822 : Closed e2405685120822 ∧ code e2405685120822 = 11201778143030 := by decide
theorem cert_e2405685120822 : check e2405685120822 [[],[]] .chain = true := by decide
def e2405685120826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2405685120826 : Closed e2405685120826 ∧ code e2405685120826 = 11201778143034 := by decide
theorem cert_e2405685120826 : check e2405685120826 [[],[]] .chain = true := by decide
def e2405685126582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2405685126582 : Closed e2405685126582 ∧ code e2405685126582 = 11201778148790 := by decide
theorem cert_e2405685126582 : check e2405685126582 [[],[]] .chain = true := by decide
def e2405685126614 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2405685126614 : Closed e2405685126614 ∧ code e2405685126614 = 11201778148822 := by decide
theorem cert_e2405685126614 : check e2405685126614 [[],[]] .chain = true := by decide
def e2405685126618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2405685126618 : Closed e2405685126618 ∧ code e2405685126618 = 11201778148826 := by decide
theorem cert_e2405685126618 : check e2405685126618 [[],[]] .chain = true := by decide
def e2405685126774 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2405685126774 : Closed e2405685126774 ∧ code e2405685126774 = 11201778148982 := by decide
theorem cert_e2405685126774 : check e2405685126774 [[],[]] .chain = true := by decide
def e2405685126966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2405685126966 : Closed e2405685126966 ∧ code e2405685126966 = 11201778149174 := by decide
theorem cert_e2405685126966 : check e2405685126966 [[],[]] .chain = true := by decide
def e2405685126970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2405685126970 : Closed e2405685126970 ∧ code e2405685126970 = 11201778149178 := by decide
theorem cert_e2405685126970 : check e2405685126970 [[],[]] .chain = true := by decide
def e2405685463918 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2405685463918 : Closed e2405685463918 ∧ code e2405685463918 = 11201778486126 := by decide
theorem cert_e2405685463918 : check e2405685463918 [[],[],[.under]] .smaller = true := by decide
def e2405685463926 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2405685463926 : Closed e2405685463926 ∧ code e2405685463926 = 11201778486134 := by decide
theorem cert_e2405685463926 : check e2405685463926 [[],[],[.under]] .smaller = true := by decide
def e2405685463982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2405685463982 : Closed e2405685463982 ∧ code e2405685463982 = 11201778486190 := by decide
theorem cert_e2405685463982 : check e2405685463982 [[],[],[.under]] .smaller = true := by decide
def e2405685463994 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2405685463994 : Closed e2405685463994 ∧ code e2405685463994 = 11201778486202 := by decide
theorem cert_e2405685463994 : check e2405685463994 [[],[],[.under]] .smaller = true := by decide
def e2405685464022 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2405685464022 : Closed e2405685464022 ∧ code e2405685464022 = 11201778486230 := by decide
theorem cert_e2405685464022 : check e2405685464022 [[],[],[.under]] .smaller = true := by decide
def e2405685464026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2405685464026 : Closed e2405685464026 ∧ code e2405685464026 = 11201778486234 := by decide
theorem cert_e2405685464026 : check e2405685464026 [[],[],[.under]] .smaller = true := by decide
def e2405685464302 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2405685464302 : Closed e2405685464302 ∧ code e2405685464302 = 11201778486510 := by decide
theorem cert_e2405685464302 : check e2405685464302 [[],[],[.under]] .smaller = true := by decide
def e2405685464310 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.lam (.var 3)))))) (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2405685464310 : Closed e2405685464310 ∧ code e2405685464310 = 11201778486518 := by decide
theorem cert_e2405685464310 : check e2405685464310 [[],[],[.under]] .smaller = true := by decide
end Blc.Floor43
