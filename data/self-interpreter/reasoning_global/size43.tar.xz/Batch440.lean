import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422376266990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422376266990 : Closed e2422376266990 ∧ code e2422376266990 = 11218469289198 := by decide
theorem cert_e2422376266990 : check e2422376266990 [[],[]] .smaller = true := by decide
def e2422376266998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.lam (.app (.var 3) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422376266998 : Closed e2422376266998 ∧ code e2422376266998 = 11218469289206 := by decide
theorem cert_e2422376266998 : check e2422376266998 [[],[]] .smaller = true := by decide
def e2422376323806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3)))))))))
theorem wire_e2422376323806 : Closed e2422376323806 ∧ code e2422376323806 = 11218469346014 := by decide
theorem cert_e2422376323806 : check e2422376323806 [[],[]] .smaller = true := by decide
def e2422376323830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1)))))))))
theorem wire_e2422376323830 : Closed e2422376323830 ∧ code e2422376323830 = 11218469346038 := by decide
theorem cert_e2422376323830 : check e2422376323830 [[],[]] .smaller = true := by decide
def e2422376323934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3)))))))))
theorem wire_e2422376323934 : Closed e2422376323934 ∧ code e2422376323934 = 11218469346142 := by decide
theorem cert_e2422376323934 : check e2422376323934 [[],[]] .smaller = true := by decide
def e2422376323950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2)))))))))
theorem wire_e2422376323950 : Closed e2422376323950 ∧ code e2422376323950 = 11218469346158 := by decide
theorem cert_e2422376323950 : check e2422376323950 [[],[]] .smaller = true := by decide
def e2422376323958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1)))))))))
theorem wire_e2422376323958 : Closed e2422376323958 ∧ code e2422376323958 = 11218469346166 := by decide
theorem cert_e2422376323958 : check e2422376323958 [[],[]] .smaller = true := by decide
def e2422376323962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0)))))))))
theorem wire_e2422376323962 : Closed e2422376323962 ∧ code e2422376323962 = 11218469346170 := by decide
theorem cert_e2422376323962 : check e2422376323962 [[],[]] .smaller = true := by decide
def e2422376324022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1)))))))))
theorem wire_e2422376324022 : Closed e2422376324022 ∧ code e2422376324022 = 11218469346230 := by decide
theorem cert_e2422376324022 : check e2422376324022 [[],[]] .smaller = true := by decide
def e2422376324054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1)))))))))
theorem wire_e2422376324054 : Closed e2422376324054 ∧ code e2422376324054 = 11218469346262 := by decide
theorem cert_e2422376324054 : check e2422376324054 [[],[]] .smaller = true := by decide
def e2422376324058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0)))))))))
theorem wire_e2422376324058 : Closed e2422376324058 ∧ code e2422376324058 = 11218469346266 := by decide
theorem cert_e2422376324058 : check e2422376324058 [[],[]] .smaller = true := by decide
def e2422376324446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3)))))))))
theorem wire_e2422376324446 : Closed e2422376324446 ∧ code e2422376324446 = 11218469346654 := by decide
theorem cert_e2422376324446 : check e2422376324446 [[],[]] .smaller = true := by decide
def e2422376324462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2422376324462 : Closed e2422376324462 ∧ code e2422376324462 = 11218469346670 := by decide
theorem cert_e2422376324462 : check e2422376324462 [[],[]] .smaller = true := by decide
def e2422376324470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2422376324470 : Closed e2422376324470 ∧ code e2422376324470 = 11218469346678 := by decide
theorem cert_e2422376324470 : check e2422376324470 [[],[]] .smaller = true := by decide
def e2422376324474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0)))))))))
theorem wire_e2422376324474 : Closed e2422376324474 ∧ code e2422376324474 = 11218469346682 := by decide
theorem cert_e2422376324474 : check e2422376324474 [[],[]] .smaller = true := by decide
def e2422376324526 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2422376324526 : Closed e2422376324526 ∧ code e2422376324526 = 11218469346734 := by decide
theorem cert_e2422376324526 : check e2422376324526 [[],[]] .smaller = true := by decide
def e2422376324538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2422376324538 : Closed e2422376324538 ∧ code e2422376324538 = 11218469346746 := by decide
theorem cert_e2422376324538 : check e2422376324538 [[],[]] .smaller = true := by decide
def e2422376324566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2422376324566 : Closed e2422376324566 ∧ code e2422376324566 = 11218469346774 := by decide
theorem cert_e2422376324566 : check e2422376324566 [[],[]] .smaller = true := by decide
def e2422376324570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2422376324570 : Closed e2422376324570 ∧ code e2422376324570 = 11218469346778 := by decide
theorem cert_e2422376324570 : check e2422376324570 [[],[]] .smaller = true := by decide
def e2422376324586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0)))))))))
theorem wire_e2422376324586 : Closed e2422376324586 ∧ code e2422376324586 = 11218469346794 := by decide
theorem cert_e2422376324586 : check e2422376324586 [[],[]] .smaller = true := by decide
def e2422376324790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1)))))))))
theorem wire_e2422376324790 : Closed e2422376324790 ∧ code e2422376324790 = 11218469346998 := by decide
theorem cert_e2422376324790 : check e2422376324790 [[],[]] .smaller = true := by decide
def e2422376324822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1)))))))))
theorem wire_e2422376324822 : Closed e2422376324822 ∧ code e2422376324822 = 11218469347030 := by decide
theorem cert_e2422376324822 : check e2422376324822 [[],[]] .smaller = true := by decide
def e2422376324826 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0)))))))))
theorem wire_e2422376324826 : Closed e2422376324826 ∧ code e2422376324826 = 11218469347034 := by decide
theorem cert_e2422376324826 : check e2422376324826 [[],[]] .smaller = true := by decide
def e2422376324950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2422376324950 : Closed e2422376324950 ∧ code e2422376324950 = 11218469347158 := by decide
theorem cert_e2422376324950 : check e2422376324950 [[],[]] .smaller = true := by decide
def e2422376324954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2422376324954 : Closed e2422376324954 ∧ code e2422376324954 = 11218469347162 := by decide
theorem cert_e2422376324954 : check e2422376324954 [[],[]] .smaller = true := by decide
def e2422376324970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2422376324970 : Closed e2422376324970 ∧ code e2422376324970 = 11218469347178 := by decide
theorem cert_e2422376324970 : check e2422376324970 [[],[]] .smaller = true := by decide
def e2422376326110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 3)))))))))
theorem wire_e2422376326110 : Closed e2422376326110 ∧ code e2422376326110 = 11218469348318 := by decide
theorem cert_e2422376326110 : check e2422376326110 [[],[]] .smaller = true := by decide
def e2422376326126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.lam (.var 4))) (.var 2)))))))))
theorem wire_e2422376326126 : Closed e2422376326126 ∧ code e2422376326126 = 11218469348334 := by decide
theorem cert_e2422376326126 : check e2422376326126 [[],[]] .smaller = true := by decide
def e2422376326878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)))))))))
theorem wire_e2422376326878 : Closed e2422376326878 ∧ code e2422376326878 = 11218469349086 := by decide
theorem cert_e2422376326878 : check e2422376326878 [[],[]] .smaller = true := by decide
def e2422376326902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)))))))))
theorem wire_e2422376326902 : Closed e2422376326902 ∧ code e2422376326902 = 11218469349110 := by decide
theorem cert_e2422376326902 : check e2422376326902 [[],[]] .smaller = true := by decide
def e2422376327006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3)))))))))
theorem wire_e2422376327006 : Closed e2422376327006 ∧ code e2422376327006 = 11218469349214 := by decide
theorem cert_e2422376327006 : check e2422376327006 [[],[]] .smaller = true := by decide
def e2422376327022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2)))))))))
theorem wire_e2422376327022 : Closed e2422376327022 ∧ code e2422376327022 = 11218469349230 := by decide
theorem cert_e2422376327022 : check e2422376327022 [[],[]] .smaller = true := by decide
def e2422376327030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)))))))))
theorem wire_e2422376327030 : Closed e2422376327030 ∧ code e2422376327030 = 11218469349238 := by decide
theorem cert_e2422376327030 : check e2422376327030 [[],[]] .smaller = true := by decide
def e2422376327034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0)))))))))
theorem wire_e2422376327034 : Closed e2422376327034 ∧ code e2422376327034 = 11218469349242 := by decide
theorem cert_e2422376327034 : check e2422376327034 [[],[]] .smaller = true := by decide
def e2422376327094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)))))))))
theorem wire_e2422376327094 : Closed e2422376327094 ∧ code e2422376327094 = 11218469349302 := by decide
theorem cert_e2422376327094 : check e2422376327094 [[],[]] .smaller = true := by decide
def e2422376327126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1)))))))))
theorem wire_e2422376327126 : Closed e2422376327126 ∧ code e2422376327126 = 11218469349334 := by decide
theorem cert_e2422376327126 : check e2422376327126 [[],[]] .smaller = true := by decide
def e2422376327130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0)))))))))
theorem wire_e2422376327130 : Closed e2422376327130 ∧ code e2422376327130 = 11218469349338 := by decide
theorem cert_e2422376327130 : check e2422376327130 [[],[]] .smaller = true := by decide
def e2422376327646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3))))))))))
theorem wire_e2422376327646 : Closed e2422376327646 ∧ code e2422376327646 = 11218469349854 := by decide
theorem cert_e2422376327646 : check e2422376327646 [[],[]] .smaller = true := by decide
def e2422376327670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1))))))))))
theorem wire_e2422376327670 : Closed e2422376327670 ∧ code e2422376327670 = 11218469349878 := by decide
theorem cert_e2422376327670 : check e2422376327670 [[],[]] .smaller = true := by decide
def e2422376328414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376328414 : Closed e2422376328414 ∧ code e2422376328414 = 11218469350622 := by decide
theorem cert_e2422376328414 : check e2422376328414 [[],[]] .smaller = true := by decide
def e2422376328430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422376328430 : Closed e2422376328430 ∧ code e2422376328430 = 11218469350638 := by decide
theorem cert_e2422376328430 : check e2422376328430 [[],[]] .smaller = true := by decide
def e2422376328438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422376328438 : Closed e2422376328438 ∧ code e2422376328438 = 11218469350646 := by decide
theorem cert_e2422376328438 : check e2422376328438 [[],[]] .smaller = true := by decide
def e2422376328442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376328442 : Closed e2422376328442 ∧ code e2422376328442 = 11218469350650 := by decide
theorem cert_e2422376328442 : check e2422376328442 [[],[]] .smaller = true := by decide
def e2422376328766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 4))))))))))
theorem wire_e2422376328766 : Closed e2422376328766 ∧ code e2422376328766 = 11218469350974 := by decide
theorem cert_e2422376328766 : check e2422376328766 [[],[]] .smaller = true := by decide
def e2422376328822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422376328822 : Closed e2422376328822 ∧ code e2422376328822 = 11218469351030 := by decide
theorem cert_e2422376328822 : check e2422376328822 [[],[]] .smaller = true := by decide
def e2422376328990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.lam (.var 3))))))))))
theorem wire_e2422376328990 : Closed e2422376328990 ∧ code e2422376328990 = 11218469351198 := by decide
theorem cert_e2422376328990 : check e2422376328990 [[],[]] .smaller = true := by decide
def e2422376329014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376329014 : Closed e2422376329014 ∧ code e2422376329014 = 11218469351222 := by decide
theorem cert_e2422376329014 : check e2422376329014 [[],[]] .smaller = true := by decide
def e2422376329018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376329018 : Closed e2422376329018 ∧ code e2422376329018 = 11218469351226 := by decide
theorem cert_e2422376329018 : check e2422376329018 [[],[]] .smaller = true := by decide
def e2422376329694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 2))) (.var 3)))))))))
theorem wire_e2422376329694 : Closed e2422376329694 ∧ code e2422376329694 = 11218469351902 := by decide
theorem cert_e2422376329694 : check e2422376329694 [[],[]] .smaller = true := by decide
def e2422376329718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.lam (.var 4))) (.var 1)))))))))
theorem wire_e2422376329718 : Closed e2422376329718 ∧ code e2422376329718 = 11218469351926 := by decide
theorem cert_e2422376329718 : check e2422376329718 [[],[]] .smaller = true := by decide
def e2422376330078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3)))))))))
theorem wire_e2422376330078 : Closed e2422376330078 ∧ code e2422376330078 = 11218469352286 := by decide
theorem cert_e2422376330078 : check e2422376330078 [[],[]] .smaller = true := by decide
def e2422376330094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2422376330094 : Closed e2422376330094 ∧ code e2422376330094 = 11218469352302 := by decide
theorem cert_e2422376330094 : check e2422376330094 [[],[]] .smaller = true := by decide
def e2422376330102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2422376330102 : Closed e2422376330102 ∧ code e2422376330102 = 11218469352310 := by decide
theorem cert_e2422376330102 : check e2422376330102 [[],[]] .smaller = true := by decide
def e2422376330106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0)))))))))
theorem wire_e2422376330106 : Closed e2422376330106 ∧ code e2422376330106 = 11218469352314 := by decide
theorem cert_e2422376330106 : check e2422376330106 [[],[]] .smaller = true := by decide
def e2422376330158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2422376330158 : Closed e2422376330158 ∧ code e2422376330158 = 11218469352366 := by decide
theorem cert_e2422376330158 : check e2422376330158 [[],[]] .smaller = true := by decide
def e2422376330170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2422376330170 : Closed e2422376330170 ∧ code e2422376330170 = 11218469352378 := by decide
theorem cert_e2422376330170 : check e2422376330170 [[],[]] .smaller = true := by decide
def e2422376330198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2422376330198 : Closed e2422376330198 ∧ code e2422376330198 = 11218469352406 := by decide
theorem cert_e2422376330198 : check e2422376330198 [[],[]] .smaller = true := by decide
def e2422376330202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2422376330202 : Closed e2422376330202 ∧ code e2422376330202 = 11218469352410 := by decide
theorem cert_e2422376330202 : check e2422376330202 [[],[]] .smaller = true := by decide
def e2422376330218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0)))))))))
theorem wire_e2422376330218 : Closed e2422376330218 ∧ code e2422376330218 = 11218469352426 := by decide
theorem cert_e2422376330218 : check e2422376330218 [[],[]] .smaller = true := by decide
def e2422376330462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3))))))))))
theorem wire_e2422376330462 : Closed e2422376330462 ∧ code e2422376330462 = 11218469352670 := by decide
theorem cert_e2422376330462 : check e2422376330462 [[],[]] .smaller = true := by decide
def e2422376330478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2422376330478 : Closed e2422376330478 ∧ code e2422376330478 = 11218469352686 := by decide
theorem cert_e2422376330478 : check e2422376330478 [[],[]] .smaller = true := by decide
def e2422376330486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2422376330486 : Closed e2422376330486 ∧ code e2422376330486 = 11218469352694 := by decide
theorem cert_e2422376330486 : check e2422376330486 [[],[]] .smaller = true := by decide
def e2422376330490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0))))))))))
theorem wire_e2422376330490 : Closed e2422376330490 ∧ code e2422376330490 = 11218469352698 := by decide
theorem cert_e2422376330490 : check e2422376330490 [[],[]] .smaller = true := by decide
def e2422376330814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.lam (.var 4))))))))))
theorem wire_e2422376330814 : Closed e2422376330814 ∧ code e2422376330814 = 11218469353022 := by decide
theorem cert_e2422376330814 : check e2422376330814 [[],[]] .smaller = true := by decide
def e2422376330862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2422376330862 : Closed e2422376330862 ∧ code e2422376330862 = 11218469353070 := by decide
theorem cert_e2422376330862 : check e2422376330862 [[],[]] .smaller = true := by decide
def e2422376330874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2422376330874 : Closed e2422376330874 ∧ code e2422376330874 = 11218469353082 := by decide
theorem cert_e2422376330874 : check e2422376330874 [[],[]] .smaller = true := by decide
def e2422376331062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376331062 : Closed e2422376331062 ∧ code e2422376331062 = 11218469353270 := by decide
theorem cert_e2422376331062 : check e2422376331062 [[],[]] .smaller = true := by decide
def e2422376331066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376331066 : Closed e2422376331066 ∧ code e2422376331066 = 11218469353274 := by decide
theorem cert_e2422376331066 : check e2422376331066 [[],[]] .smaller = true := by decide
def e2422376331150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.lam (.var 2))))))))))
theorem wire_e2422376331150 : Closed e2422376331150 ∧ code e2422376331150 = 11218469353358 := by decide
theorem cert_e2422376331150 : check e2422376331150 [[],[]] .smaller = true := by decide
def e2422376331162 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376331162 : Closed e2422376331162 ∧ code e2422376331162 = 11218469353370 := by decide
theorem cert_e2422376331162 : check e2422376331162 [[],[]] .smaller = true := by decide
def e2422376331486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 3)))))))))
theorem wire_e2422376331486 : Closed e2422376331486 ∧ code e2422376331486 = 11218469353694 := by decide
theorem cert_e2422376331486 : check e2422376331486 [[],[]] .smaller = true := by decide
def e2422376331514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.lam (.var 4))) (.var 0)))))))))
theorem wire_e2422376331514 : Closed e2422376331514 ∧ code e2422376331514 = 11218469353722 := by decide
theorem cert_e2422376331514 : check e2422376331514 [[],[]] .smaller = true := by decide
def e2422376331702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1)))))))))
theorem wire_e2422376331702 : Closed e2422376331702 ∧ code e2422376331702 = 11218469353910 := by decide
theorem cert_e2422376331702 : check e2422376331702 [[],[]] .smaller = true := by decide
def e2422376331734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1)))))))))
theorem wire_e2422376331734 : Closed e2422376331734 ∧ code e2422376331734 = 11218469353942 := by decide
theorem cert_e2422376331734 : check e2422376331734 [[],[]] .smaller = true := by decide
def e2422376331738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0)))))))))
theorem wire_e2422376331738 : Closed e2422376331738 ∧ code e2422376331738 = 11218469353946 := by decide
theorem cert_e2422376331738 : check e2422376331738 [[],[]] .smaller = true := by decide
def e2422376331838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 4))))))))))
theorem wire_e2422376331838 : Closed e2422376331838 ∧ code e2422376331838 = 11218469354046 := by decide
theorem cert_e2422376331838 : check e2422376331838 [[],[]] .smaller = true := by decide
def e2422376331894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422376331894 : Closed e2422376331894 ∧ code e2422376331894 = 11218469354102 := by decide
theorem cert_e2422376331894 : check e2422376331894 [[],[]] .smaller = true := by decide
def e2422376332086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376332086 : Closed e2422376332086 ∧ code e2422376332086 = 11218469354294 := by decide
theorem cert_e2422376332086 : check e2422376332086 [[],[]] .smaller = true := by decide
def e2422376332090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376332090 : Closed e2422376332090 ∧ code e2422376332090 = 11218469354298 := by decide
theorem cert_e2422376332090 : check e2422376332090 [[],[]] .smaller = true := by decide
def e2422376332230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 3)) (.lam (.var 1))))))))))
theorem wire_e2422376332230 : Closed e2422376332230 ∧ code e2422376332230 = 11218469354438 := by decide
theorem cert_e2422376332230 : check e2422376332230 [[],[]] .smaller = true := by decide
def e2422376332398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 1))) (.var 2)))))))))
theorem wire_e2422376332398 : Closed e2422376332398 ∧ code e2422376332398 = 11218469354606 := by decide
theorem cert_e2422376332398 : check e2422376332398 [[],[]] .smaller = true := by decide
def e2422376332406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 2))) (.var 1)))))))))
theorem wire_e2422376332406 : Closed e2422376332406 ∧ code e2422376332406 = 11218469354614 := by decide
theorem cert_e2422376332406 : check e2422376332406 [[],[]] .smaller = true := by decide
def e2422376332410 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.lam (.var 3))) (.var 0)))))))))
theorem wire_e2422376332410 : Closed e2422376332410 ∧ code e2422376332410 = 11218469354618 := by decide
theorem cert_e2422376332410 : check e2422376332410 [[],[]] .smaller = true := by decide
def e2422376332502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2422376332502 : Closed e2422376332502 ∧ code e2422376332502 = 11218469354710 := by decide
theorem cert_e2422376332502 : check e2422376332502 [[],[]] .smaller = true := by decide
def e2422376332506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2422376332506 : Closed e2422376332506 ∧ code e2422376332506 = 11218469354714 := by decide
theorem cert_e2422376332506 : check e2422376332506 [[],[]] .smaller = true := by decide
def e2422376332522 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2422376332522 : Closed e2422376332522 ∧ code e2422376332522 = 11218469354730 := by decide
theorem cert_e2422376332522 : check e2422376332522 [[],[]] .smaller = true := by decide
def e2422376332574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.lam (.var 3))))))))))
theorem wire_e2422376332574 : Closed e2422376332574 ∧ code e2422376332574 = 11218469354782 := by decide
theorem cert_e2422376332574 : check e2422376332574 [[],[]] .smaller = true := by decide
def e2422376332598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422376332598 : Closed e2422376332598 ∧ code e2422376332598 = 11218469354806 := by decide
theorem cert_e2422376332598 : check e2422376332598 [[],[]] .smaller = true := by decide
def e2422376332602 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422376332602 : Closed e2422376332602 ∧ code e2422376332602 = 11218469354810 := by decide
theorem cert_e2422376332602 : check e2422376332602 [[],[]] .smaller = true := by decide
def e2422376332686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.lam (.var 2))))))))))
theorem wire_e2422376332686 : Closed e2422376332686 ∧ code e2422376332686 = 11218469354894 := by decide
theorem cert_e2422376332686 : check e2422376332686 [[],[]] .smaller = true := by decide
def e2422376332698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422376332698 : Closed e2422376332698 ∧ code e2422376332698 = 11218469354906 := by decide
theorem cert_e2422376332698 : check e2422376332698 [[],[]] .smaller = true := by decide
def e2422376332742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 3) (.var 2)) (.lam (.var 1))))))))))
theorem wire_e2422376332742 : Closed e2422376332742 ∧ code e2422376332742 = 11218469354950 := by decide
theorem cert_e2422376332742 : check e2422376332742 [[],[]] .smaller = true := by decide
def e2422376339166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3))))))))))
theorem wire_e2422376339166 : Closed e2422376339166 ∧ code e2422376339166 = 11218469361374 := by decide
theorem cert_e2422376339166 : check e2422376339166 [[],[]] .smaller = true := by decide
def e2422376339190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1))))))))))
theorem wire_e2422376339190 : Closed e2422376339190 ∧ code e2422376339190 = 11218469361398 := by decide
theorem cert_e2422376339190 : check e2422376339190 [[],[]] .smaller = true := by decide
def e2422376339294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3))))))))))
theorem wire_e2422376339294 : Closed e2422376339294 ∧ code e2422376339294 = 11218469361502 := by decide
theorem cert_e2422376339294 : check e2422376339294 [[],[]] .smaller = true := by decide
def e2422376339310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2))))))))))
theorem wire_e2422376339310 : Closed e2422376339310 ∧ code e2422376339310 = 11218469361518 := by decide
theorem cert_e2422376339310 : check e2422376339310 [[],[]] .smaller = true := by decide
def e2422376339318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1))))))))))
theorem wire_e2422376339318 : Closed e2422376339318 ∧ code e2422376339318 = 11218469361526 := by decide
theorem cert_e2422376339318 : check e2422376339318 [[],[]] .smaller = true := by decide
def e2422376339322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0))))))))))
theorem wire_e2422376339322 : Closed e2422376339322 ∧ code e2422376339322 = 11218469361530 := by decide
theorem cert_e2422376339322 : check e2422376339322 [[],[]] .smaller = true := by decide
def e2422376339382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1))))))))))
theorem wire_e2422376339382 : Closed e2422376339382 ∧ code e2422376339382 = 11218469361590 := by decide
theorem cert_e2422376339382 : check e2422376339382 [[],[]] .smaller = true := by decide
def e2422376339414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1))))))))))
theorem wire_e2422376339414 : Closed e2422376339414 ∧ code e2422376339414 = 11218469361622 := by decide
theorem cert_e2422376339414 : check e2422376339414 [[],[]] .smaller = true := by decide
def e2422376339418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0))))))))))
theorem wire_e2422376339418 : Closed e2422376339418 ∧ code e2422376339418 = 11218469361626 := by decide
theorem cert_e2422376339418 : check e2422376339418 [[],[]] .smaller = true := by decide
def e2422376339934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3)))))))))))
theorem wire_e2422376339934 : Closed e2422376339934 ∧ code e2422376339934 = 11218469362142 := by decide
theorem cert_e2422376339934 : check e2422376339934 [[],[]] .smaller = true := by decide
def e2422376339958 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1)))))))))))
theorem wire_e2422376339958 : Closed e2422376339958 ∧ code e2422376339958 = 11218469362166 := by decide
theorem cert_e2422376339958 : check e2422376339958 [[],[]] .smaller = true := by decide
def e2422376340702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422376340702 : Closed e2422376340702 ∧ code e2422376340702 = 11218469362910 := by decide
theorem cert_e2422376340702 : check e2422376340702 [[],[]] .smaller = true := by decide
def e2422376340718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422376340718 : Closed e2422376340718 ∧ code e2422376340718 = 11218469362926 := by decide
theorem cert_e2422376340718 : check e2422376340718 [[],[]] .smaller = true := by decide
def e2422376340726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422376340726 : Closed e2422376340726 ∧ code e2422376340726 = 11218469362934 := by decide
theorem cert_e2422376340726 : check e2422376340726 [[],[]] .smaller = true := by decide
def e2422376340730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422376340730 : Closed e2422376340730 ∧ code e2422376340730 = 11218469362938 := by decide
theorem cert_e2422376340730 : check e2422376340730 [[],[]] .smaller = true := by decide
def e2422376341054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 4)))))))))))
theorem wire_e2422376341054 : Closed e2422376341054 ∧ code e2422376341054 = 11218469363262 := by decide
theorem cert_e2422376341054 : check e2422376341054 [[],[]] .smaller = true := by decide
def e2422376341110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422376341110 : Closed e2422376341110 ∧ code e2422376341110 = 11218469363318 := by decide
theorem cert_e2422376341110 : check e2422376341110 [[],[]] .smaller = true := by decide
def e2422376341278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.lam (.var 3)))))))))))
theorem wire_e2422376341278 : Closed e2422376341278 ∧ code e2422376341278 = 11218469363486 := by decide
theorem cert_e2422376341278 : check e2422376341278 [[],[]] .smaller = true := by decide
def e2422376341302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376341302 : Closed e2422376341302 ∧ code e2422376341302 = 11218469363510 := by decide
theorem cert_e2422376341302 : check e2422376341302 [[],[]] .smaller = true := by decide
def e2422376341306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376341306 : Closed e2422376341306 ∧ code e2422376341306 = 11218469363514 := by decide
theorem cert_e2422376341306 : check e2422376341306 [[],[]] .smaller = true := by decide
def e2422376352606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3))))))))))
theorem wire_e2422376352606 : Closed e2422376352606 ∧ code e2422376352606 = 11218469374814 := by decide
theorem cert_e2422376352606 : check e2422376352606 [[],[]] .smaller = true := by decide
def e2422376352622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2422376352622 : Closed e2422376352622 ∧ code e2422376352622 = 11218469374830 := by decide
theorem cert_e2422376352622 : check e2422376352622 [[],[]] .smaller = true := by decide
def e2422376352630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2422376352630 : Closed e2422376352630 ∧ code e2422376352630 = 11218469374838 := by decide
theorem cert_e2422376352630 : check e2422376352630 [[],[]] .smaller = true := by decide
def e2422376352634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0))))))))))
theorem wire_e2422376352634 : Closed e2422376352634 ∧ code e2422376352634 = 11218469374842 := by decide
theorem cert_e2422376352634 : check e2422376352634 [[],[]] .smaller = true := by decide
def e2422376352686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2422376352686 : Closed e2422376352686 ∧ code e2422376352686 = 11218469374894 := by decide
theorem cert_e2422376352686 : check e2422376352686 [[],[]] .smaller = true := by decide
def e2422376352698 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2422376352698 : Closed e2422376352698 ∧ code e2422376352698 = 11218469374906 := by decide
theorem cert_e2422376352698 : check e2422376352698 [[],[]] .smaller = true := by decide
def e2422376352726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2422376352726 : Closed e2422376352726 ∧ code e2422376352726 = 11218469374934 := by decide
theorem cert_e2422376352726 : check e2422376352726 [[],[]] .smaller = true := by decide
def e2422376352730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2422376352730 : Closed e2422376352730 ∧ code e2422376352730 = 11218469374938 := by decide
theorem cert_e2422376352730 : check e2422376352730 [[],[]] .smaller = true := by decide
def e2422376352746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0))))))))))
theorem wire_e2422376352746 : Closed e2422376352746 ∧ code e2422376352746 = 11218469374954 := by decide
theorem cert_e2422376352746 : check e2422376352746 [[],[]] .smaller = true := by decide
def e2422376352990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3)))))))))))
theorem wire_e2422376352990 : Closed e2422376352990 ∧ code e2422376352990 = 11218469375198 := by decide
theorem cert_e2422376352990 : check e2422376352990 [[],[]] .smaller = true := by decide
def e2422376353006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2422376353006 : Closed e2422376353006 ∧ code e2422376353006 = 11218469375214 := by decide
theorem cert_e2422376353006 : check e2422376353006 [[],[]] .smaller = true := by decide
def e2422376353014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2422376353014 : Closed e2422376353014 ∧ code e2422376353014 = 11218469375222 := by decide
theorem cert_e2422376353014 : check e2422376353014 [[],[]] .smaller = true := by decide
def e2422376353018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0)))))))))))
theorem wire_e2422376353018 : Closed e2422376353018 ∧ code e2422376353018 = 11218469375226 := by decide
theorem cert_e2422376353018 : check e2422376353018 [[],[]] .smaller = true := by decide
def e2422376353342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.lam (.var 4)))))))))))
theorem wire_e2422376353342 : Closed e2422376353342 ∧ code e2422376353342 = 11218469375550 := by decide
theorem cert_e2422376353342 : check e2422376353342 [[],[]] .smaller = true := by decide
def e2422376353390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2422376353390 : Closed e2422376353390 ∧ code e2422376353390 = 11218469375598 := by decide
theorem cert_e2422376353390 : check e2422376353390 [[],[]] .smaller = true := by decide
def e2422376353402 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2422376353402 : Closed e2422376353402 ∧ code e2422376353402 = 11218469375610 := by decide
theorem cert_e2422376353402 : check e2422376353402 [[],[]] .smaller = true := by decide
def e2422376353590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376353590 : Closed e2422376353590 ∧ code e2422376353590 = 11218469375798 := by decide
theorem cert_e2422376353590 : check e2422376353590 [[],[]] .smaller = true := by decide
def e2422376353594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376353594 : Closed e2422376353594 ∧ code e2422376353594 = 11218469375802 := by decide
theorem cert_e2422376353594 : check e2422376353594 [[],[]] .smaller = true := by decide
def e2422376353678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.lam (.var 2)))))))))))
theorem wire_e2422376353678 : Closed e2422376353678 ∧ code e2422376353678 = 11218469375886 := by decide
theorem cert_e2422376353678 : check e2422376353678 [[],[]] .smaller = true := by decide
def e2422376353690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376353690 : Closed e2422376353690 ∧ code e2422376353690 = 11218469375898 := by decide
theorem cert_e2422376353690 : check e2422376353690 [[],[]] .smaller = true := by decide
def e2422376359350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))))))))))
theorem wire_e2422376359350 : Closed e2422376359350 ∧ code e2422376359350 = 11218469381558 := by decide
theorem cert_e2422376359350 : check e2422376359350 [[],[]] .smaller = true := by decide
def e2422376359382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))))))))))
theorem wire_e2422376359382 : Closed e2422376359382 ∧ code e2422376359382 = 11218469381590 := by decide
theorem cert_e2422376359382 : check e2422376359382 [[],[]] .smaller = true := by decide
def e2422376359386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))))))))))
theorem wire_e2422376359386 : Closed e2422376359386 ∧ code e2422376359386 = 11218469381594 := by decide
theorem cert_e2422376359386 : check e2422376359386 [[],[]] .smaller = true := by decide
def e2422376359486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 4)))))))))))
theorem wire_e2422376359486 : Closed e2422376359486 ∧ code e2422376359486 = 11218469381694 := by decide
theorem cert_e2422376359486 : check e2422376359486 [[],[]] .smaller = true := by decide
def e2422376359542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1)))))))))))
theorem wire_e2422376359542 : Closed e2422376359542 ∧ code e2422376359542 = 11218469381750 := by decide
theorem cert_e2422376359542 : check e2422376359542 [[],[]] .smaller = true := by decide
def e2422376359734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376359734 : Closed e2422376359734 ∧ code e2422376359734 = 11218469381942 := by decide
theorem cert_e2422376359734 : check e2422376359734 [[],[]] .smaller = true := by decide
def e2422376359738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376359738 : Closed e2422376359738 ∧ code e2422376359738 = 11218469381946 := by decide
theorem cert_e2422376359738 : check e2422376359738 [[],[]] .smaller = true := by decide
def e2422376359878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 3) (.lam (.var 1)))))))))))
theorem wire_e2422376359878 : Closed e2422376359878 ∧ code e2422376359878 = 11218469382086 := by decide
theorem cert_e2422376359878 : check e2422376359878 [[],[]] .smaller = true := by decide
def e2422376362710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2422376362710 : Closed e2422376362710 ∧ code e2422376362710 = 11218469384918 := by decide
theorem cert_e2422376362710 : check e2422376362710 [[],[]] .smaller = true := by decide
def e2422376362714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2422376362714 : Closed e2422376362714 ∧ code e2422376362714 = 11218469384922 := by decide
theorem cert_e2422376362714 : check e2422376362714 [[],[]] .smaller = true := by decide
def e2422376362730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2422376362730 : Closed e2422376362730 ∧ code e2422376362730 = 11218469384938 := by decide
theorem cert_e2422376362730 : check e2422376362730 [[],[]] .smaller = true := by decide
def e2422376362782 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.lam (.var 3)))))))))))
theorem wire_e2422376362782 : Closed e2422376362782 ∧ code e2422376362782 = 11218469384990 := by decide
theorem cert_e2422376362782 : check e2422376362782 [[],[]] .smaller = true := by decide
def e2422376362806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2422376362806 : Closed e2422376362806 ∧ code e2422376362806 = 11218469385014 := by decide
theorem cert_e2422376362806 : check e2422376362806 [[],[]] .smaller = true := by decide
def e2422376362810 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2422376362810 : Closed e2422376362810 ∧ code e2422376362810 = 11218469385018 := by decide
theorem cert_e2422376362810 : check e2422376362810 [[],[]] .smaller = true := by decide
def e2422376362894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.lam (.var 2)))))))))))
theorem wire_e2422376362894 : Closed e2422376362894 ∧ code e2422376362894 = 11218469385102 := by decide
theorem cert_e2422376362894 : check e2422376362894 [[],[]] .smaller = true := by decide
def e2422376362906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422376362906 : Closed e2422376362906 ∧ code e2422376362906 = 11218469385114 := by decide
theorem cert_e2422376362906 : check e2422376362906 [[],[]] .smaller = true := by decide
def e2422376362950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.app (.var 2) (.lam (.var 1)))))))))))
theorem wire_e2422376362950 : Closed e2422376362950 ∧ code e2422376362950 = 11218469385158 := by decide
theorem cert_e2422376362950 : check e2422376362950 [[],[]] .smaller = true := by decide
def e2422376585902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2422376585902 : Closed e2422376585902 ∧ code e2422376585902 = 11218469608110 := by decide
theorem cert_e2422376585902 : check e2422376585902 [[],[]] .smaller = true := by decide
def e2422376585914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2422376585914 : Closed e2422376585914 ∧ code e2422376585914 = 11218469608122 := by decide
theorem cert_e2422376585914 : check e2422376585914 [[],[]] .smaller = true := by decide
def e2422376585962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2422376585962 : Closed e2422376585962 ∧ code e2422376585962 = 11218469608170 := by decide
theorem cert_e2422376585962 : check e2422376585962 [[],[]] .smaller = true := by decide
def e2422376586154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422376586154 : Closed e2422376586154 ∧ code e2422376586154 = 11218469608362 := by decide
theorem cert_e2422376586154 : check e2422376586154 [[],[]] .smaller = true := by decide
def e2422376586922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422376586922 : Closed e2422376586922 ∧ code e2422376586922 = 11218469609130 := by decide
theorem cert_e2422376586922 : check e2422376586922 [[],[]] .smaller = true := by decide
def e2422376587438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0)) (.var 2))))))))
theorem wire_e2422376587438 : Closed e2422376587438 ∧ code e2422376587438 = 11218469609646 := by decide
theorem cert_e2422376587438 : check e2422376587438 [[],[]] .smaller = true := by decide
def e2422376587450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2)) (.var 0))))))))
theorem wire_e2422376587450 : Closed e2422376587450 ∧ code e2422376587450 = 11218469609658 := by decide
theorem cert_e2422376587450 : check e2422376587450 [[],[]] .smaller = true := by decide
def e2422376587998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 1)) (.var 3))))))))
theorem wire_e2422376587998 : Closed e2422376587998 ∧ code e2422376587998 = 11218469610206 := by decide
theorem cert_e2422376587998 : check e2422376587998 [[],[]] .three = true := by decide
def e2422376588014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 2)) (.var 2))))))))
theorem wire_e2422376588014 : Closed e2422376588014 ∧ code e2422376588014 = 11218469610222 := by decide
theorem cert_e2422376588014 : check e2422376588014 [[],[]] .smaller = true := by decide
def e2422376588022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 0))) (.var 3)) (.var 1))))))))
theorem wire_e2422376588022 : Closed e2422376588022 ∧ code e2422376588022 = 11218469610230 := by decide
theorem cert_e2422376588022 : check e2422376588022 [[],[]] .three = true := by decide
def e2422376588126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.lam (.var 1))) (.var 0)) (.var 3))))))))
theorem wire_e2422376588126 : Closed e2422376588126 ∧ code e2422376588126 = 11218469610334 := by decide
theorem cert_e2422376588126 : check e2422376588126 [[],[]] .three = true := by decide
end Blc.Floor43
