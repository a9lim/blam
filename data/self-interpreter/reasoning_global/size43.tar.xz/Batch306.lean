import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2411630216438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630216438 : Closed e2411630216438 ∧ code e2411630216438 = 11207723238646 := by decide
theorem cert_e2411630216438 : check e2411630216438 [[],[]] .chain = true := by decide
def e2411630216814 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630216814 : Closed e2411630216814 ∧ code e2411630216814 = 11207723239022 := by decide
theorem cert_e2411630216814 : check e2411630216814 [[],[]] .chain = true := by decide
def e2411630216826 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 1)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630216826 : Closed e2411630216826 ∧ code e2411630216826 = 11207723239034 := by decide
theorem cert_e2411630216826 : check e2411630216826 [[],[]] .chain = true := by decide
def e2411630216990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 3)))))))
theorem wire_e2411630216990 : Closed e2411630216990 ∧ code e2411630216990 = 11207723239198 := by decide
theorem cert_e2411630216990 : check e2411630216990 [[],[]] .chain = true := by decide
def e2411630217102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.lam (.var 2)))))))
theorem wire_e2411630217102 : Closed e2411630217102 ∧ code e2411630217102 = 11207723239310 := by decide
theorem cert_e2411630217102 : check e2411630217102 [[],[]] .chain = true := by decide
def e2411630217114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630217114 : Closed e2411630217114 ∧ code e2411630217114 = 11207723239322 := by decide
theorem cert_e2411630217114 : check e2411630217114 [[],[]] .chain = true := by decide
def e2411630218350 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))) (.var 2))))))
theorem wire_e2411630218350 : Closed e2411630218350 ∧ code e2411630218350 = 11207723240558 := by decide
theorem cert_e2411630218350 : check e2411630218350 [[],[]] .chain = true := by decide
def e2411630218362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))) (.var 0))))))
theorem wire_e2411630218362 : Closed e2411630218362 ∧ code e2411630218362 = 11207723240570 := by decide
theorem cert_e2411630218362 : check e2411630218362 [[],[]] .chain = true := by decide
def e2411630218526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.var 3)))))))
theorem wire_e2411630218526 : Closed e2411630218526 ∧ code e2411630218526 = 11207723240734 := by decide
theorem cert_e2411630218526 : check e2411630218526 [[],[]] .chain = true := by decide
def e2411630218694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2411630218694 : Closed e2411630218694 ∧ code e2411630218694 = 11207723240902 := by decide
theorem cert_e2411630218694 : check e2411630218694 [[],[]] .chain = true := by decide
def e2411630218798 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2411630218798 : Closed e2411630218798 ∧ code e2411630218798 = 11207723241006 := by decide
theorem cert_e2411630218798 : check e2411630218798 [[],[]] .chain = true := by decide
def e2411630218978 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2411630218978 : Closed e2411630218978 ∧ code e2411630218978 = 11207723241186 := by decide
theorem cert_e2411630218978 : check e2411630218978 [[],[]] .chain = true := by decide
def e2411630218990 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2411630218990 : Closed e2411630218990 ∧ code e2411630218990 = 11207723241198 := by decide
theorem cert_e2411630218990 : checkPay e2411630218990 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630219030 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2411630219030 : Closed e2411630219030 ∧ code e2411630219030 = 11207723241238 := by decide
theorem cert_e2411630219030 : check e2411630219030 [[],[]] .chain = true := by decide
def e2411630219034 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2411630219034 : Closed e2411630219034 ∧ code e2411630219034 = 11207723241242 := by decide
theorem cert_e2411630219034 : check e2411630219034 [[],[]] .chain = true := by decide
def e2411630219078 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2411630219078 : Closed e2411630219078 ∧ code e2411630219078 = 11207723241286 := by decide
theorem cert_e2411630219078 : check e2411630219078 [[],[]] .chain = true := by decide
def e2411630219106 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2411630219106 : Closed e2411630219106 ∧ code e2411630219106 = 11207723241314 := by decide
theorem cert_e2411630219106 : check e2411630219106 [[],[]] .chain = true := by decide
def e2411630219118 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2411630219118 : Closed e2411630219118 ∧ code e2411630219118 = 11207723241326 := by decide
theorem cert_e2411630219118 : checkPay e2411630219118 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e2411630219126 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 1))))))
theorem wire_e2411630219126 : Closed e2411630219126 ∧ code e2411630219126 = 11207723241334 := by decide
theorem cert_e2411630219126 : checkPay e2411630219126 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left,.left],[.left],[],[.under,.left],[.under,.left,.left,.left,.right]] = true := by decide
def e2411630219486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 3))))))))
theorem wire_e2411630219486 : Closed e2411630219486 ∧ code e2411630219486 = 11207723241694 := by decide
theorem cert_e2411630219486 : check e2411630219486 [[],[]] .chain = true := by decide
def e2411630219514 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.app (.var 3) (.var 0))))))))
theorem wire_e2411630219514 : Closed e2411630219514 ∧ code e2411630219514 = 11207723241722 := by decide
theorem cert_e2411630219514 : check e2411630219514 [[],[]] .chain = true := by decide
def e2411630220062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.var 3))))))))
theorem wire_e2411630220062 : Closed e2411630220062 ∧ code e2411630220062 = 11207723242270 := by decide
theorem cert_e2411630220062 : check e2411630220062 [[],[]] .chain = true := by decide
def e2411630220230 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 1))))))))
theorem wire_e2411630220230 : Closed e2411630220230 ∧ code e2411630220230 = 11207723242438 := by decide
theorem cert_e2411630220230 : check e2411630220230 [[],[]] .chain = true := by decide
def e2411630221374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.lam (.var 4))))))))
theorem wire_e2411630221374 : Closed e2411630221374 ∧ code e2411630221374 = 11207723243582 := by decide
theorem cert_e2411630221374 : check e2411630221374 [[],[]] .chain = true := by decide
def e2411630221794 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2411630221794 : Closed e2411630221794 ∧ code e2411630221794 = 11207723244002 := by decide
theorem cert_e2411630221794 : check e2411630221794 [[],[]] .chain = true := by decide
def e2411630221806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 2)))))))
theorem wire_e2411630221806 : Closed e2411630221806 ∧ code e2411630221806 = 11207723244014 := by decide
theorem cert_e2411630221806 : checkPay e2411630221806 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630222366 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 3))))))))
theorem wire_e2411630222366 : Closed e2411630222366 ∧ code e2411630222366 = 11207723244574 := by decide
theorem cert_e2411630222366 : check e2411630222366 [[],[]] .chain = true := by decide
def e2411630222390 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411630222390 : Closed e2411630222390 ∧ code e2411630222390 = 11207723244598 := by decide
theorem cert_e2411630222390 : check e2411630222390 [[],[]] .chain = true := by decide
def e2411630222394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411630222394 : Closed e2411630222394 ∧ code e2411630222394 = 11207723244602 := by decide
theorem cert_e2411630222394 : check e2411630222394 [[],[]] .chain = true := by decide
def e2411630222534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411630222534 : Closed e2411630222534 ∧ code e2411630222534 = 11207723244742 := by decide
theorem cert_e2411630222534 : check e2411630222534 [[],[]] .chain = true := by decide
def e2411630222562 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411630222562 : Closed e2411630222562 ∧ code e2411630222562 = 11207723244770 := by decide
theorem cert_e2411630222562 : check e2411630222562 [[],[]] .chain = true := by decide
def e2411630222574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630222574 : Closed e2411630222574 ∧ code e2411630222574 = 11207723244782 := by decide
theorem cert_e2411630222574 : checkPay e2411630222574 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[]] = true := by decide
def e2411630222582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630222582 : Closed e2411630222582 ∧ code e2411630222582 = 11207723244790 := by decide
theorem cert_e2411630222582 : checkPay e2411630222582 [[.left,.left],[.left,.left],[.left],[]] 0 [[],[.left],[],[.under,.under,.right]] = true := by decide
def e2411630223598 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 2))))) (.var 2))))))
theorem wire_e2411630223598 : Closed e2411630223598 ∧ code e2411630223598 = 11207723245806 := by decide
theorem cert_e2411630223598 : check e2411630223598 [[],[]] .chain = true := by decide
def e2411630223610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.lam (.var 4))))) (.var 0))))))
theorem wire_e2411630223610 : Closed e2411630223610 ∧ code e2411630223610 = 11207723245818 := by decide
theorem cert_e2411630223610 : check e2411630223610 [[],[]] .chain = true := by decide
def e2411630223982 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630223982 : Closed e2411630223982 ∧ code e2411630223982 = 11207723246190 := by decide
theorem cert_e2411630223982 : check e2411630223982 [[],[]] .chain = true := by decide
def e2411630223994 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 0)))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630223994 : Closed e2411630223994 ∧ code e2411630223994 = 11207723246202 := by decide
theorem cert_e2411630223994 : check e2411630223994 [[],[]] .chain = true := by decide
def e2411630224158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.lam (.var 3)))))))
theorem wire_e2411630224158 : Closed e2411630224158 ∧ code e2411630224158 = 11207723246366 := by decide
theorem cert_e2411630224158 : check e2411630224158 [[],[]] .chain = true := by decide
def e2411630224326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.lam (.var 1)))))))
theorem wire_e2411630224326 : Closed e2411630224326 ∧ code e2411630224326 = 11207723246534 := by decide
theorem cert_e2411630224326 : check e2411630224326 [[],[]] .chain = true := by decide
def e2411630224942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))) (.var 2))))))
theorem wire_e2411630224942 : Closed e2411630224942 ∧ code e2411630224942 = 11207723247150 := by decide
theorem cert_e2411630224942 : check e2411630224942 [[],[]] .chain = true := by decide
def e2411630225122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2411630225122 : Closed e2411630225122 ∧ code e2411630225122 = 11207723247330 := by decide
theorem cert_e2411630225122 : check e2411630225122 [[],[]] .chain = true := by decide
def e2411630225134 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2411630225134 : Closed e2411630225134 ∧ code e2411630225134 = 11207723247342 := by decide
theorem cert_e2411630225134 : checkPay e2411630225134 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right],[.right,.left],[.right]] = true := by decide
def e2411630225290 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2411630225290 : Closed e2411630225290 ∧ code e2411630225290 = 11207723247498 := by decide
theorem cert_e2411630225290 : check e2411630225290 [[],[]] .chain = true := by decide
def e2411630225314 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2411630225314 : Closed e2411630225314 ∧ code e2411630225314 = 11207723247522 := by decide
theorem cert_e2411630225314 : check e2411630225314 [[],[]] .chain = true := by decide
def e2411630225326 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2411630225326 : Closed e2411630225326 ∧ code e2411630225326 = 11207723247534 := by decide
theorem cert_e2411630225326 : checkPay e2411630225326 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2411630225338 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2411630225338 : Closed e2411630225338 ∧ code e2411630225338 = 11207723247546 := by decide
theorem cert_e2411630225338 : checkPay e2411630225338 [[.left,.left],[.left,.left],[.left],[]] 0 [[.right]] = true := by decide
def e2411630225470 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2411630225470 : Closed e2411630225470 ∧ code e2411630225470 = 11207723247678 := by decide
theorem cert_e2411630225470 : check e2411630225470 [[],[]] .chain = true := by decide
def e2411630225890 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2411630225890 : Closed e2411630225890 ∧ code e2411630225890 = 11207723248098 := by decide
theorem cert_e2411630225890 : check e2411630225890 [[],[]] .chain = true := by decide
def e2411630225902 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2411630225902 : Closed e2411630225902 ∧ code e2411630225902 = 11207723248110 := by decide
theorem cert_e2411630225902 : checkPay e2411630225902 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630226958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2411630226958 : Closed e2411630226958 ∧ code e2411630226958 = 11207723249166 := by decide
theorem cert_e2411630226958 : check e2411630226958 [[],[]] .chain = true := by decide
def e2411630227042 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2411630227042 : Closed e2411630227042 ∧ code e2411630227042 = 11207723249250 := by decide
theorem cert_e2411630227042 : check e2411630227042 [[],[]] .chain = true := by decide
def e2411630227054 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630227054 : Closed e2411630227054 ∧ code e2411630227054 = 11207723249262 := by decide
theorem cert_e2411630227054 : checkPay e2411630227054 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630227066 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630227066 : Closed e2411630227066 ∧ code e2411630227066 = 11207723249274 := by decide
theorem cert_e2411630227066 : checkPay e2411630227066 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630227574 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2411630227574 : Closed e2411630227574 ∧ code e2411630227574 = 11207723249782 := by decide
theorem cert_e2411630227574 : check e2411630227574 [[],[]] .chain = true := by decide
def e2411630227578 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2411630227578 : Closed e2411630227578 ∧ code e2411630227578 = 11207723249786 := by decide
theorem cert_e2411630227578 : check e2411630227578 [[],[]] .chain = true := by decide
def e2411630227674 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))) (.var 0))))))
theorem wire_e2411630227674 : Closed e2411630227674 ∧ code e2411630227674 = 11207723249882 := by decide
theorem cert_e2411630227674 : check e2411630227674 [[],[]] .chain = true := by decide
def e2411630227690 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))) (.var 0))))))
theorem wire_e2411630227690 : Closed e2411630227690 ∧ code e2411630227690 = 11207723249898 := by decide
theorem cert_e2411630227690 : check e2411630227690 [[],[]] .chain = true := by decide
def e2411630227766 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630227766 : Closed e2411630227766 ∧ code e2411630227766 = 11207723249974 := by decide
theorem cert_e2411630227766 : check e2411630227766 [[],[]] .chain = true := by decide
def e2411630227770 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630227770 : Closed e2411630227770 ∧ code e2411630227770 = 11207723249978 := by decide
theorem cert_e2411630227770 : check e2411630227770 [[],[]] .chain = true := by decide
def e2411630227854 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2411630227854 : Closed e2411630227854 ∧ code e2411630227854 = 11207723250062 := by decide
theorem cert_e2411630227854 : check e2411630227854 [[],[]] .chain = true := by decide
def e2411630227866 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2411630227866 : Closed e2411630227866 ∧ code e2411630227866 = 11207723250074 := by decide
theorem cert_e2411630227866 : check e2411630227866 [[],[]] .chain = true := by decide
def e2411630227910 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2411630227910 : Closed e2411630227910 ∧ code e2411630227910 = 11207723250118 := by decide
theorem cert_e2411630227910 : check e2411630227910 [[],[]] .chain = true := by decide
def e2411630228246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2411630228246 : Closed e2411630228246 ∧ code e2411630228246 = 11207723250454 := by decide
theorem cert_e2411630228246 : check e2411630228246 [[],[]] .chain = true := by decide
def e2411630228250 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))) (.var 0))))))
theorem wire_e2411630228250 : Closed e2411630228250 ∧ code e2411630228250 = 11207723250458 := by decide
theorem cert_e2411630228250 : check e2411630228250 [[],[]] .chain = true := by decide
def e2411630228294 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 1)))))))
theorem wire_e2411630228294 : Closed e2411630228294 ∧ code e2411630228294 = 11207723250502 := by decide
theorem cert_e2411630228294 : check e2411630228294 [[],[]] .chain = true := by decide
def e2411630228322 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2411630228322 : Closed e2411630228322 ∧ code e2411630228322 = 11207723250530 := by decide
theorem cert_e2411630228322 : check e2411630228322 [[],[]] .chain = true := by decide
def e2411630228334 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2411630228334 : Closed e2411630228334 ∧ code e2411630228334 = 11207723250542 := by decide
theorem cert_e2411630228334 : checkPay e2411630228334 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630228342 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2411630228342 : Closed e2411630228342 ∧ code e2411630228342 = 11207723250550 := by decide
theorem cert_e2411630228342 : checkPay e2411630228342 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630228362 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2411630228362 : Closed e2411630228362 ∧ code e2411630228362 = 11207723250570 := by decide
theorem cert_e2411630228362 : check e2411630228362 [[],[]] .chain = true := by decide
def e2411630228386 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2411630228386 : Closed e2411630228386 ∧ code e2411630228386 = 11207723250594 := by decide
theorem cert_e2411630228386 : check e2411630228386 [[],[]] .chain = true := by decide
def e2411630228398 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2411630228398 : Closed e2411630228398 ∧ code e2411630228398 = 11207723250606 := by decide
theorem cert_e2411630228398 : checkPay e2411630228398 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630228410 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2411630228410 : Closed e2411630228410 ∧ code e2411630228410 = 11207723250618 := by decide
theorem cert_e2411630228410 : checkPay e2411630228410 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630228438 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2411630228438 : Closed e2411630228438 ∧ code e2411630228438 = 11207723250646 := by decide
theorem cert_e2411630228438 : checkPay e2411630228438 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630228442 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2411630228442 : Closed e2411630228442 ∧ code e2411630228442 = 11207723250650 := by decide
theorem cert_e2411630228442 : checkPay e2411630228442 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630228510 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 3))))))))
theorem wire_e2411630228510 : Closed e2411630228510 ∧ code e2411630228510 = 11207723250718 := by decide
theorem cert_e2411630228510 : check e2411630228510 [[],[]] .chain = true := by decide
def e2411630228534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 1))))))))
theorem wire_e2411630228534 : Closed e2411630228534 ∧ code e2411630228534 = 11207723250742 := by decide
theorem cert_e2411630228534 : check e2411630228534 [[],[]] .chain = true := by decide
def e2411630228538 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 1) (.var 0))))))))
theorem wire_e2411630228538 : Closed e2411630228538 ∧ code e2411630228538 = 11207723250746 := by decide
theorem cert_e2411630228538 : check e2411630228538 [[],[]] .chain = true := by decide
def e2411630228678 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2411630228678 : Closed e2411630228678 ∧ code e2411630228678 = 11207723250886 := by decide
theorem cert_e2411630228678 : check e2411630228678 [[],[]] .chain = true := by decide
def e2411630228706 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2411630228706 : Closed e2411630228706 ∧ code e2411630228706 = 11207723250914 := by decide
theorem cert_e2411630228706 : check e2411630228706 [[],[]] .chain = true := by decide
def e2411630228718 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2411630228718 : Closed e2411630228718 ∧ code e2411630228718 = 11207723250926 := by decide
theorem cert_e2411630228718 : checkPay e2411630228718 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630228726 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2411630228726 : Closed e2411630228726 ∧ code e2411630228726 = 11207723250934 := by decide
theorem cert_e2411630228726 : checkPay e2411630228726 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630229006 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.lam (.var 2))))))))
theorem wire_e2411630229006 : Closed e2411630229006 ∧ code e2411630229006 = 11207723251214 := by decide
theorem cert_e2411630229006 : check e2411630229006 [[],[]] .chain = true := by decide
def e2411630229090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2411630229090 : Closed e2411630229090 ∧ code e2411630229090 = 11207723251298 := by decide
theorem cert_e2411630229090 : check e2411630229090 [[],[]] .chain = true := by decide
def e2411630229102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2411630229102 : Closed e2411630229102 ∧ code e2411630229102 = 11207723251310 := by decide
theorem cert_e2411630229102 : checkPay e2411630229102 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630229114 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2411630229114 : Closed e2411630229114 ∧ code e2411630229114 = 11207723251322 := by decide
theorem cert_e2411630229114 : checkPay e2411630229114 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630229302 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2411630229302 : Closed e2411630229302 ∧ code e2411630229302 = 11207723251510 := by decide
theorem cert_e2411630229302 : checkPay e2411630229302 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630229306 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2411630229306 : Closed e2411630229306 ∧ code e2411630229306 = 11207723251514 := by decide
theorem cert_e2411630229306 : checkPay e2411630229306 [[.left,.left],[.left,.left],[.left],[]] 0 [[]] = true := by decide
def e2411630234462 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2411630234462 : Closed e2411630234462 ∧ code e2411630234462 = 11207723256670 := by decide
theorem cert_e2411630234462 : check e2411630234462 [[],[]] .chain = true := by decide
def e2411630234478 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2411630234478 : Closed e2411630234478 ∧ code e2411630234478 = 11207723256686 := by decide
theorem cert_e2411630234478 : check e2411630234478 [[],[]] .smaller = true := by decide
def e2411630234486 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2411630234486 : Closed e2411630234486 ∧ code e2411630234486 = 11207723256694 := by decide
theorem cert_e2411630234486 : check e2411630234486 [[],[]] .smaller = true := by decide
def e2411630234490 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2411630234490 : Closed e2411630234490 ∧ code e2411630234490 = 11207723256698 := by decide
theorem cert_e2411630234490 : check e2411630234490 [[],[]] .chain = true := by decide
def e2411630234542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2411630234542 : Closed e2411630234542 ∧ code e2411630234542 = 11207723256750 := by decide
theorem cert_e2411630234542 : check e2411630234542 [[],[]] .smaller = true := by decide
def e2411630234554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2411630234554 : Closed e2411630234554 ∧ code e2411630234554 = 11207723256762 := by decide
theorem cert_e2411630234554 : check e2411630234554 [[],[]] .smaller = true := by decide
def e2411630234582 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2411630234582 : Closed e2411630234582 ∧ code e2411630234582 = 11207723256790 := by decide
theorem cert_e2411630234582 : check e2411630234582 [[],[]] .smaller = true := by decide
def e2411630234586 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2411630234586 : Closed e2411630234586 ∧ code e2411630234586 = 11207723256794 := by decide
theorem cert_e2411630234586 : check e2411630234586 [[],[]] .smaller = true := by decide
def e2411630234602 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2411630234602 : Closed e2411630234602 ∧ code e2411630234602 = 11207723256810 := by decide
theorem cert_e2411630234602 : check e2411630234602 [[],[]] .chain = true := by decide
def e2411630234846 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630234846 : Closed e2411630234846 ∧ code e2411630234846 = 11207723257054 := by decide
theorem cert_e2411630234846 : check e2411630234846 [[],[]] .chain = true := by decide
def e2411630234862 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2411630234862 : Closed e2411630234862 ∧ code e2411630234862 = 11207723257070 := by decide
theorem cert_e2411630234862 : check e2411630234862 [[],[]] .smaller = true := by decide
def e2411630234870 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2411630234870 : Closed e2411630234870 ∧ code e2411630234870 = 11207723257078 := by decide
theorem cert_e2411630234870 : check e2411630234870 [[],[]] .smaller = true := by decide
def e2411630234874 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630234874 : Closed e2411630234874 ∧ code e2411630234874 = 11207723257082 := by decide
theorem cert_e2411630234874 : check e2411630234874 [[],[]] .chain = true := by decide
def e2411630235198 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.lam (.var 4)))))))))
theorem wire_e2411630235198 : Closed e2411630235198 ∧ code e2411630235198 = 11207723257406 := by decide
theorem cert_e2411630235198 : check e2411630235198 [[],[]] .chain = true := by decide
def e2411630235246 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2411630235246 : Closed e2411630235246 ∧ code e2411630235246 = 11207723257454 := by decide
theorem cert_e2411630235246 : check e2411630235246 [[],[]] .smaller = true := by decide
def e2411630235258 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2411630235258 : Closed e2411630235258 ∧ code e2411630235258 = 11207723257466 := by decide
theorem cert_e2411630235258 : check e2411630235258 [[],[]] .smaller = true := by decide
def e2411630235446 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630235446 : Closed e2411630235446 ∧ code e2411630235446 = 11207723257654 := by decide
theorem cert_e2411630235446 : check e2411630235446 [[],[]] .smaller = true := by decide
def e2411630235450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630235450 : Closed e2411630235450 ∧ code e2411630235450 = 11207723257658 := by decide
theorem cert_e2411630235450 : check e2411630235450 [[],[]] .smaller = true := by decide
def e2411630235534 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.lam (.var 2)))))))))
theorem wire_e2411630235534 : Closed e2411630235534 ∧ code e2411630235534 = 11207723257742 := by decide
theorem cert_e2411630235534 : check e2411630235534 [[],[]] .chain = true := by decide
def e2411630235546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630235546 : Closed e2411630235546 ∧ code e2411630235546 = 11207723257754 := by decide
theorem cert_e2411630235546 : check e2411630235546 [[],[]] .chain = true := by decide
def e2411630242926 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2411630242926 : Closed e2411630242926 ∧ code e2411630242926 = 11207723265134 := by decide
theorem cert_e2411630242926 : check e2411630242926 [[],[]] .chain = true := by decide
def e2411630242938 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2411630242938 : Closed e2411630242938 ∧ code e2411630242938 = 11207723265146 := by decide
theorem cert_e2411630242938 : check e2411630242938 [[],[]] .chain = true := by decide
def e2411630243102 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2411630243102 : Closed e2411630243102 ∧ code e2411630243102 = 11207723265310 := by decide
theorem cert_e2411630243102 : check e2411630243102 [[],[]] .chain = true := by decide
def e2411630243270 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2411630243270 : Closed e2411630243270 ∧ code e2411630243270 = 11207723265478 := by decide
theorem cert_e2411630243270 : check e2411630243270 [[],[]] .chain = true := by decide
def e2411630243374 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411630243374 : Closed e2411630243374 ∧ code e2411630243374 = 11207723265582 := by decide
theorem cert_e2411630243374 : check e2411630243374 [[],[]] .chain = true := by decide
def e2411630243554 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411630243554 : Closed e2411630243554 ∧ code e2411630243554 = 11207723265762 := by decide
theorem cert_e2411630243554 : check e2411630243554 [[],[]] .chain = true := by decide
def e2411630243566 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 2)))))))
theorem wire_e2411630243566 : Closed e2411630243566 ∧ code e2411630243566 = 11207723265774 := by decide
theorem cert_e2411630243566 : checkPay e2411630243566 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630243606 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630243606 : Closed e2411630243606 ∧ code e2411630243606 = 11207723265814 := by decide
theorem cert_e2411630243606 : check e2411630243606 [[],[]] .chain = true := by decide
def e2411630243610 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630243610 : Closed e2411630243610 ∧ code e2411630243610 = 11207723265818 := by decide
theorem cert_e2411630243610 : check e2411630243610 [[],[]] .chain = true := by decide
def e2411630243654 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630243654 : Closed e2411630243654 ∧ code e2411630243654 = 11207723265862 := by decide
theorem cert_e2411630243654 : check e2411630243654 [[],[]] .chain = true := by decide
def e2411630243682 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630243682 : Closed e2411630243682 ∧ code e2411630243682 = 11207723265890 := by decide
theorem cert_e2411630243682 : check e2411630243682 [[],[]] .chain = true := by decide
def e2411630243694 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 2)))))))
theorem wire_e2411630243694 : Closed e2411630243694 ∧ code e2411630243694 = 11207723265902 := by decide
theorem cert_e2411630243694 : checkPay e2411630243694 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630243702 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 1)))))))
theorem wire_e2411630243702 : Closed e2411630243702 ∧ code e2411630243702 = 11207723265910 := by decide
theorem cert_e2411630243702 : checkPay e2411630243702 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630244062 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 0) (.var 3)))))))))
theorem wire_e2411630244062 : Closed e2411630244062 ∧ code e2411630244062 = 11207723266270 := by decide
theorem cert_e2411630244062 : check e2411630244062 [[],[]] .chain = true := by decide
def e2411630244090 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.app (.var 3) (.var 0)))))))))
theorem wire_e2411630244090 : Closed e2411630244090 ∧ code e2411630244090 = 11207723266298 := by decide
theorem cert_e2411630244090 : check e2411630244090 [[],[]] .chain = true := by decide
def e2411630244638 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2411630244638 : Closed e2411630244638 ∧ code e2411630244638 = 11207723266846 := by decide
theorem cert_e2411630244638 : check e2411630244638 [[],[]] .chain = true := by decide
def e2411630244806 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2411630244806 : Closed e2411630244806 ∧ code e2411630244806 = 11207723267014 := by decide
theorem cert_e2411630244806 : check e2411630244806 [[],[]] .chain = true := by decide
def e2411630245950 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.lam (.var 4)))))))))
theorem wire_e2411630245950 : Closed e2411630245950 ∧ code e2411630245950 = 11207723268158 := by decide
theorem cert_e2411630245950 : check e2411630245950 [[],[]] .chain = true := by decide
def e2411630246370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411630246370 : Closed e2411630246370 ∧ code e2411630246370 = 11207723268578 := by decide
theorem cert_e2411630246370 : check e2411630246370 [[],[]] .chain = true := by decide
def e2411630246382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 2))))))))
theorem wire_e2411630246382 : Closed e2411630246382 ∧ code e2411630246382 = 11207723268590 := by decide
theorem cert_e2411630246382 : checkPay e2411630246382 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630246942 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 3)))))))))
theorem wire_e2411630246942 : Closed e2411630246942 ∧ code e2411630246942 = 11207723269150 := by decide
theorem cert_e2411630246942 : check e2411630246942 [[],[]] .chain = true := by decide
def e2411630246966 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630246966 : Closed e2411630246966 ∧ code e2411630246966 = 11207723269174 := by decide
theorem cert_e2411630246966 : check e2411630246966 [[],[]] .chain = true := by decide
def e2411630246970 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630246970 : Closed e2411630246970 ∧ code e2411630246970 = 11207723269178 := by decide
theorem cert_e2411630246970 : check e2411630246970 [[],[]] .chain = true := by decide
def e2411630247110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2411630247110 : Closed e2411630247110 ∧ code e2411630247110 = 11207723269318 := by decide
theorem cert_e2411630247110 : check e2411630247110 [[],[]] .chain = true := by decide
def e2411630247138 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))))
theorem wire_e2411630247138 : Closed e2411630247138 ∧ code e2411630247138 = 11207723269346 := by decide
theorem cert_e2411630247138 : check e2411630247138 [[],[]] .chain = true := by decide
def e2411630247150 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 2))))))))
theorem wire_e2411630247150 : Closed e2411630247150 ∧ code e2411630247150 = 11207723269358 := by decide
theorem cert_e2411630247150 : checkPay e2411630247150 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630247158 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 1))))))))
theorem wire_e2411630247158 : Closed e2411630247158 ∧ code e2411630247158 = 11207723269366 := by decide
theorem cert_e2411630247158 : checkPay e2411630247158 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630269998 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2411630269998 : Closed e2411630269998 ∧ code e2411630269998 = 11207723292206 := by decide
theorem cert_e2411630269998 : check e2411630269998 [[],[]] .chain = true := by decide
def e2411630270178 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2411630270178 : Closed e2411630270178 ∧ code e2411630270178 = 11207723292386 := by decide
theorem cert_e2411630270178 : check e2411630270178 [[],[]] .chain = true := by decide
def e2411630270190 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2411630270190 : Closed e2411630270190 ∧ code e2411630270190 = 11207723292398 := by decide
theorem cert_e2411630270190 : checkPay e2411630270190 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630270346 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2411630270346 : Closed e2411630270346 ∧ code e2411630270346 = 11207723292554 := by decide
theorem cert_e2411630270346 : check e2411630270346 [[],[]] .chain = true := by decide
def e2411630270370 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2411630270370 : Closed e2411630270370 ∧ code e2411630270370 = 11207723292578 := by decide
theorem cert_e2411630270370 : check e2411630270370 [[],[]] .chain = true := by decide
def e2411630270382 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2411630270382 : Closed e2411630270382 ∧ code e2411630270382 = 11207723292590 := by decide
theorem cert_e2411630270382 : checkPay e2411630270382 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630270394 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2411630270394 : Closed e2411630270394 ∧ code e2411630270394 = 11207723292602 := by decide
theorem cert_e2411630270394 : checkPay e2411630270394 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630270526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2411630270526 : Closed e2411630270526 ∧ code e2411630270526 = 11207723292734 := by decide
theorem cert_e2411630270526 : check e2411630270526 [[],[]] .chain = true := by decide
def e2411630270946 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2411630270946 : Closed e2411630270946 ∧ code e2411630270946 = 11207723293154 := by decide
theorem cert_e2411630270946 : check e2411630270946 [[],[]] .chain = true := by decide
def e2411630270958 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2411630270958 : Closed e2411630270958 ∧ code e2411630270958 = 11207723293166 := by decide
theorem cert_e2411630270958 : checkPay e2411630270958 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630272014 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2411630272014 : Closed e2411630272014 ∧ code e2411630272014 = 11207723294222 := by decide
theorem cert_e2411630272014 : check e2411630272014 [[],[]] .chain = true := by decide
def e2411630272098 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2411630272098 : Closed e2411630272098 ∧ code e2411630272098 = 11207723294306 := by decide
theorem cert_e2411630272098 : check e2411630272098 [[],[]] .chain = true := by decide
def e2411630272110 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2411630272110 : Closed e2411630272110 ∧ code e2411630272110 = 11207723294318 := by decide
theorem cert_e2411630272110 : checkPay e2411630272110 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630272122 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2411630272122 : Closed e2411630272122 ∧ code e2411630272122 = 11207723294330 := by decide
theorem cert_e2411630272122 : checkPay e2411630272122 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630281430 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2411630281430 : Closed e2411630281430 ∧ code e2411630281430 = 11207723303638 := by decide
theorem cert_e2411630281430 : checkPay e2411630281430 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630281434 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2411630281434 : Closed e2411630281434 ∧ code e2411630281434 = 11207723303642 := by decide
theorem cert_e2411630281434 : checkPay e2411630281434 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630281450 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2411630281450 : Closed e2411630281450 ∧ code e2411630281450 = 11207723303658 := by decide
theorem cert_e2411630281450 : checkPay e2411630281450 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630281526 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2411630281526 : Closed e2411630281526 ∧ code e2411630281526 = 11207723303734 := by decide
theorem cert_e2411630281526 : checkPay e2411630281526 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630281530 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2411630281530 : Closed e2411630281530 ∧ code e2411630281530 = 11207723303738 := by decide
theorem cert_e2411630281530 : checkPay e2411630281530 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630281614 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 2)))))))))
theorem wire_e2411630281614 : Closed e2411630281614 ∧ code e2411630281614 = 11207723303822 := by decide
theorem cert_e2411630281614 : check e2411630281614 [[],[]] .chain = true := by decide
def e2411630281626 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2411630281626 : Closed e2411630281626 ∧ code e2411630281626 = 11207723303834 := by decide
theorem cert_e2411630281626 : checkPay e2411630281626 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2411630283542 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1)))))))
theorem wire_e2411630283542 : Closed e2411630283542 ∧ code e2411630283542 = 11207723305750 := by decide
theorem cert_e2411630283542 : check e2411630283542 [[],[]] .chain = true := by decide
def e2411630283546 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2411630283546 : Closed e2411630283546 ∧ code e2411630283546 = 11207723305754 := by decide
theorem cert_e2411630283546 : check e2411630283546 [[],[]] .chain = true := by decide
def e2411630283590 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2411630283590 : Closed e2411630283590 ∧ code e2411630283590 = 11207723305798 := by decide
theorem cert_e2411630283590 : check e2411630283590 [[],[]] .chain = true := by decide
def e2411630283618 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0))))))))
theorem wire_e2411630283618 : Closed e2411630283618 ∧ code e2411630283618 = 11207723305826 := by decide
theorem cert_e2411630283618 : check e2411630283618 [[],[]] .chain = true := by decide
def e2411630283630 : Term := (.app (.lam (.app (.var 0) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2411630283630 : Closed e2411630283630 ∧ code e2411630283630 = 11207723305838 := by decide
theorem cert_e2411630283630 : checkPay e2411630283630 [[.left,.left],[.left,.left],[.left],[]] 0 [] = true := by decide
end Blc.Floor43
