import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2388198568134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388198568134 : Closed e2388198568134 ∧ code e2388198568134 = 11184291590342 := by decide
theorem cert_e2388198568134 : check e2388198568134 [[]] .width = true := by decide
def e2388198580762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388198580762 : Closed e2388198580762 ∧ code e2388198580762 = 11184291602970 := by decide
private def t_e2388198580762 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388198580762 : ¬ IsSelfInterpreter e2388198580762 :=
  wSource (t := t_e2388198580762) (replay_sound (ps := []) (t := e2388198580762) (by decide)) (by decide)
def e2388198582298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388198582298 : Closed e2388198582298 ∧ code e2388198582298 = 11184291604506 := by decide
theorem cert_e2388198582298 : check e2388198582298 [[]] .width = true := by decide
def e2388198588442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388198588442 : Closed e2388198588442 ∧ code e2388198588442 = 11184291610650 := by decide
theorem cert_e2388198588442 : check e2388198588442 [[]] .width = true := by decide
def e2388198588534 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388198588534 : Closed e2388198588534 ∧ code e2388198588534 = 11184291610742 := by decide
theorem cert_e2388198588534 : check e2388198588534 [[]] .width = true := by decide
def e2388198588778 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388198588778 : Closed e2388198588778 ∧ code e2388198588778 = 11184291610986 := by decide
theorem cert_e2388198588778 : check e2388198588778 [[]] .width = true := by decide
def e2388198588826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388198588826 : Closed e2388198588826 ∧ code e2388198588826 = 11184291611034 := by decide
theorem cert_e2388198588826 : check e2388198588826 [[]] .width = true := by decide
def e2388198589834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388198589834 : Closed e2388198589834 ∧ code e2388198589834 = 11184291612042 := by decide
theorem cert_e2388198589834 : check e2388198589834 [[]] .width = true := by decide
def e2388198589858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388198589858 : Closed e2388198589858 ∧ code e2388198589858 = 11184291612066 := by decide
private def t_e2388198589858 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2388198589858 : ¬ IsSelfInterpreter e2388198589858 :=
  wSource (t := t_e2388198589858) (replay_sound (ps := []) (t := e2388198589858) (by decide)) (by decide)
def e2388198589966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388198589966 : Closed e2388198589966 ∧ code e2388198589966 = 11184291612174 := by decide
theorem cert_e2388198589966 : check e2388198589966 [[]] .width = true := by decide
def e2388198589978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388198589978 : Closed e2388198589978 ∧ code e2388198589978 = 11184291612186 := by decide
private def t_e2388198589978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2388198589978 : ¬ IsSelfInterpreter e2388198589978 :=
  wSource (t := t_e2388198589978) (replay_sound (ps := []) (t := e2388198589978) (by decide)) (by decide)
def e2388198590050 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388198590050 : Closed e2388198590050 ∧ code e2388198590050 = 11184291612258 := by decide
theorem cert_e2388198590050 : check e2388198590050 [[]] .width = true := by decide
def e2388199070234 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199070234 : Closed e2388199070234 ∧ code e2388199070234 = 11184292092442 := by decide
theorem cert_e2388199070234 : check e2388199070234 [[]] .width = true := by decide
def e2388199074330 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199074330 : Closed e2388199074330 ∧ code e2388199074330 = 11184292096538 := by decide
theorem cert_e2388199074330 : check e2388199074330 [[]] .width = true := by decide
def e2388199266842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199266842 : Closed e2388199266842 ∧ code e2388199266842 = 11184292289050 := by decide
theorem cert_e2388199266842 : check e2388199266842 [[]] .width = true := by decide
def e2388199270938 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199270938 : Closed e2388199270938 ∧ code e2388199270938 = 11184292293146 := by decide
theorem cert_e2388199270938 : check e2388199270938 [[]] .width = true := by decide
def e2388199356954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199356954 : Closed e2388199356954 ∧ code e2388199356954 = 11184292379162 := by decide
theorem cert_e2388199356954 : check e2388199356954 [[]] .width = true := by decide
def e2388199392794 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199392794 : Closed e2388199392794 ∧ code e2388199392794 = 11184292415002 := by decide
theorem cert_e2388199392794 : check e2388199392794 [[]] .width = true := by decide
def e2388199395526 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388199395526 : Closed e2388199395526 ∧ code e2388199395526 = 11184292417734 := by decide
theorem cert_e2388199395526 : check e2388199395526 [[]] .width = true := by decide
def e2388199414298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199414298 : Closed e2388199414298 ∧ code e2388199414298 = 11184292436506 := by decide
theorem cert_e2388199414298 : check e2388199414298 [[]] .width = true := by decide
def e2388199425562 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199425562 : Closed e2388199425562 ∧ code e2388199425562 = 11184292447770 := by decide
theorem cert_e2388199425562 : check e2388199425562 [[]] .width = true := by decide
def e2388199428294 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388199428294 : Closed e2388199428294 ∧ code e2388199428294 = 11184292450502 := by decide
theorem cert_e2388199428294 : check e2388199428294 [[]] .width = true := by decide
def e2388199758362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199758362 : Closed e2388199758362 ∧ code e2388199758362 = 11184292780570 := by decide
theorem cert_e2388199758362 : check e2388199758362 [[]] .width = true := by decide
def e2388199827482 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388199827482 : Closed e2388199827482 ∧ code e2388199827482 = 11184292849690 := by decide
theorem cert_e2388199827482 : check e2388199827482 [[]] .width = true := by decide
def e2388199836186 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199836186 : Closed e2388199836186 ∧ code e2388199836186 = 11184292858394 := by decide
theorem cert_e2388199836186 : check e2388199836186 [[]] .width = true := by decide
def e2388199843866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388199843866 : Closed e2388199843866 ∧ code e2388199843866 = 11184292866074 := by decide
theorem cert_e2388199843866 : check e2388199843866 [[]] .width = true := by decide
def e2388199848474 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199848474 : Closed e2388199848474 ∧ code e2388199848474 = 11184292870682 := by decide
theorem cert_e2388199848474 : check e2388199848474 [[]] .width = true := by decide
def e2388199856666 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199856666 : Closed e2388199856666 ∧ code e2388199856666 = 11184292878874 := by decide
theorem cert_e2388199856666 : check e2388199856666 [[]] .width = true := by decide
def e2388199877146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199877146 : Closed e2388199877146 ∧ code e2388199877146 = 11184292899354 := by decide
theorem cert_e2388199877146 : check e2388199877146 [[]] .width = true := by decide
def e2388199901722 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199901722 : Closed e2388199901722 ∧ code e2388199901722 = 11184292923930 := by decide
theorem cert_e2388199901722 : check e2388199901722 [[]] .width = true := by decide
def e2388199909402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388199909402 : Closed e2388199909402 ∧ code e2388199909402 = 11184292931610 := by decide
theorem cert_e2388199909402 : check e2388199909402 [[]] .width = true := by decide
def e2388199914010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199914010 : Closed e2388199914010 ∧ code e2388199914010 = 11184292936218 := by decide
theorem cert_e2388199914010 : check e2388199914010 [[]] .width = true := by decide
def e2388199926298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199926298 : Closed e2388199926298 ∧ code e2388199926298 = 11184292948506 := by decide
private def t_e2388199926298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388199926298 : ¬ IsSelfInterpreter e2388199926298 :=
  wSource (t := t_e2388199926298) (replay_sound (ps := []) (t := e2388199926298) (by decide)) (by decide)
def e2388199954970 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199954970 : Closed e2388199954970 ∧ code e2388199954970 = 11184292977178 := by decide
theorem cert_e2388199954970 : check e2388199954970 [[]] .width = true := by decide
def e2388199959066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388199959066 : Closed e2388199959066 ∧ code e2388199959066 = 11184292981274 := by decide
private def t_e2388199959066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388199959066 : ¬ IsSelfInterpreter e2388199959066 :=
  wSource (t := t_e2388199959066) (replay_sound (ps := []) (t := e2388199959066) (by decide)) (by decide)
def e2388200028698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200028698 : Closed e2388200028698 ∧ code e2388200028698 = 11184293050906 := by decide
theorem cert_e2388200028698 : check e2388200028698 [[]] .width = true := by decide
def e2388200113690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200113690 : Closed e2388200113690 ∧ code e2388200113690 = 11184293135898 := by decide
theorem cert_e2388200113690 : check e2388200113690 [[]] .width = true := by decide
def e2388200116422 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388200116422 : Closed e2388200116422 ∧ code e2388200116422 = 11184293138630 := by decide
theorem cert_e2388200116422 : check e2388200116422 [[]] .width = true := by decide
def e2388200220698 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388200220698 : Closed e2388200220698 ∧ code e2388200220698 = 11184293242906 := by decide
theorem cert_e2388200220698 : check e2388200220698 [[]] .width = true := by decide
def e2388200229402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200229402 : Closed e2388200229402 ∧ code e2388200229402 = 11184293251610 := by decide
theorem cert_e2388200229402 : check e2388200229402 [[]] .width = true := by decide
def e2388200237082 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388200237082 : Closed e2388200237082 ∧ code e2388200237082 = 11184293259290 := by decide
theorem cert_e2388200237082 : check e2388200237082 [[]] .width = true := by decide
def e2388200241690 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200241690 : Closed e2388200241690 ∧ code e2388200241690 = 11184293263898 := by decide
theorem cert_e2388200241690 : check e2388200241690 [[]] .width = true := by decide
def e2388200249882 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200249882 : Closed e2388200249882 ∧ code e2388200249882 = 11184293272090 := by decide
theorem cert_e2388200249882 : check e2388200249882 [[]] .width = true := by decide
def e2388200392730 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388200392730 : Closed e2388200392730 ∧ code e2388200392730 = 11184293414938 := by decide
theorem cert_e2388200392730 : check e2388200392730 [[]] .width = true := by decide
def e2388200394266 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200394266 : Closed e2388200394266 ∧ code e2388200394266 = 11184293416474 := by decide
theorem cert_e2388200394266 : check e2388200394266 [[]] .width = true := by decide
def e2388200398874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388200398874 : Closed e2388200398874 ∧ code e2388200398874 = 11184293421082 := by decide
theorem cert_e2388200398874 : check e2388200398874 [[]] .width = true := by decide
def e2388200398966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388200398966 : Closed e2388200398966 ∧ code e2388200398966 = 11184293421174 := by decide
theorem cert_e2388200398966 : check e2388200398966 [[]] .width = true := by decide
def e2388200399210 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388200399210 : Closed e2388200399210 ∧ code e2388200399210 = 11184293421418 := by decide
theorem cert_e2388200399210 : check e2388200399210 [[]] .width = true := by decide
def e2388200399258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388200399258 : Closed e2388200399258 ∧ code e2388200399258 = 11184293421466 := by decide
theorem cert_e2388200399258 : check e2388200399258 [[]] .width = true := by decide
def e2388200403142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388200403142 : Closed e2388200403142 ∧ code e2388200403142 = 11184293425350 := by decide
theorem cert_e2388200403142 : check e2388200403142 [[]] .width = true := by decide
def e2388200415770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200415770 : Closed e2388200415770 ∧ code e2388200415770 = 11184293437978 := by decide
theorem cert_e2388200415770 : check e2388200415770 [[]] .width = true := by decide
def e2388200417306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388200417306 : Closed e2388200417306 ∧ code e2388200417306 = 11184293439514 := by decide
theorem cert_e2388200417306 : check e2388200417306 [[]] .width = true := by decide
def e2388200423450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388200423450 : Closed e2388200423450 ∧ code e2388200423450 = 11184293445658 := by decide
theorem cert_e2388200423450 : check e2388200423450 [[]] .width = true := by decide
def e2388200423542 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388200423542 : Closed e2388200423542 ∧ code e2388200423542 = 11184293445750 := by decide
theorem cert_e2388200423542 : check e2388200423542 [[]] .width = true := by decide
def e2388200423786 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388200423786 : Closed e2388200423786 ∧ code e2388200423786 = 11184293445994 := by decide
theorem cert_e2388200423786 : check e2388200423786 [[]] .width = true := by decide
def e2388200423834 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388200423834 : Closed e2388200423834 ∧ code e2388200423834 = 11184293446042 := by decide
theorem cert_e2388200423834 : check e2388200423834 [[]] .width = true := by decide
def e2388200424842 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388200424842 : Closed e2388200424842 ∧ code e2388200424842 = 11184293447050 := by decide
theorem cert_e2388200424842 : check e2388200424842 [[]] .width = true := by decide
def e2388200424866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388200424866 : Closed e2388200424866 ∧ code e2388200424866 = 11184293447074 := by decide
theorem cert_e2388200424866 : check e2388200424866 [[]] .width = true := by decide
def e2388200424974 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388200424974 : Closed e2388200424974 ∧ code e2388200424974 = 11184293447182 := by decide
theorem cert_e2388200424974 : check e2388200424974 [[]] .width = true := by decide
def e2388200424986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388200424986 : Closed e2388200424986 ∧ code e2388200424986 = 11184293447194 := by decide
theorem cert_e2388200424986 : check e2388200424986 [[]] .width = true := by decide
def e2388200425058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388200425058 : Closed e2388200425058 ∧ code e2388200425058 = 11184293447266 := by decide
theorem cert_e2388200425058 : check e2388200425058 [[]] .width = true := by decide
def e2388200536602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200536602 : Closed e2388200536602 ∧ code e2388200536602 = 11184293558810 := by decide
private def t_e2388200536602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200536602 : ¬ IsSelfInterpreter e2388200536602 :=
  wSource (t := t_e2388200536602) (replay_sound (ps := []) (t := e2388200536602) (by decide)) (by decide)
def e2388200572442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200572442 : Closed e2388200572442 ∧ code e2388200572442 = 11184293594650 := by decide
private def t_e2388200572442 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200572442 : ¬ IsSelfInterpreter e2388200572442 :=
  wSource (t := t_e2388200572442) (replay_sound (ps := []) (t := e2388200572442) (by decide)) (by decide)
def e2388200575174 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388200575174 : Closed e2388200575174 ∧ code e2388200575174 = 11184293597382 := by decide
theorem cert_e2388200575174 : check e2388200575174 [[]] .width = true := by decide
def e2388200622618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200622618 : Closed e2388200622618 ∧ code e2388200622618 = 11184293644826 := by decide
private def t_e2388200622618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200622618 : ¬ IsSelfInterpreter e2388200622618 :=
  wSource (t := t_e2388200622618) (replay_sound (ps := []) (t := e2388200622618) (by decide)) (by decide)
def e2388200630298 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388200630298 : Closed e2388200630298 ∧ code e2388200630298 = 11184293652506 := by decide
theorem cert_e2388200630298 : check e2388200630298 [[]] .width = true := by decide
def e2388200634906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200634906 : Closed e2388200634906 ∧ code e2388200634906 = 11184293657114 := by decide
private def t_e2388200634906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200634906 : ¬ IsSelfInterpreter e2388200634906 :=
  wSource (t := t_e2388200634906) (replay_sound (ps := []) (t := e2388200634906) (by decide)) (by decide)
def e2388200647194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200647194 : Closed e2388200647194 ∧ code e2388200647194 = 11184293669402 := by decide
private def t_e2388200647194 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200647194 : ¬ IsSelfInterpreter e2388200647194 :=
  wSource (t := t_e2388200647194) (replay_sound (ps := []) (t := e2388200647194) (by decide)) (by decide)
def e2388200654874 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388200654874 : Closed e2388200654874 ∧ code e2388200654874 = 11184293677082 := by decide
theorem cert_e2388200654874 : check e2388200654874 [[]] .width = true := by decide
def e2388200656410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200656410 : Closed e2388200656410 ∧ code e2388200656410 = 11184293678618 := by decide
private def t_e2388200656410 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200656410 : ¬ IsSelfInterpreter e2388200656410 :=
  wSource (t := t_e2388200656410) (replay_sound (ps := []) (t := e2388200656410) (by decide)) (by decide)
def e2388200661018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388200661018 : Closed e2388200661018 ∧ code e2388200661018 = 11184293683226 := by decide
theorem cert_e2388200661018 : check e2388200661018 [[]] .width = true := by decide
def e2388200661110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388200661110 : Closed e2388200661110 ∧ code e2388200661110 = 11184293683318 := by decide
private def t_e2388200661110 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem cert_e2388200661110 : ¬ IsSelfInterpreter e2388200661110 :=
  wSource (t := t_e2388200661110) (replay_sound (ps := []) (t := e2388200661110) (by decide)) (by decide)
def e2388200661354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388200661354 : Closed e2388200661354 ∧ code e2388200661354 = 11184293683562 := by decide
private def t_e2388200661354 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem cert_e2388200661354 : ¬ IsSelfInterpreter e2388200661354 :=
  wSource (t := t_e2388200661354) (replay_sound (ps := []) (t := e2388200661354) (by decide)) (by decide)
def e2388200661402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388200661402 : Closed e2388200661402 ∧ code e2388200661402 = 11184293683610 := by decide
private def t_e2388200661402 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem cert_e2388200661402 : ¬ IsSelfInterpreter e2388200661402 :=
  wSource (t := t_e2388200661402) (replay_sound (ps := []) (t := e2388200661402) (by decide)) (by decide)
def e2388200665286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388200665286 : Closed e2388200665286 ∧ code e2388200665286 = 11184293687494 := by decide
theorem cert_e2388200665286 : check e2388200665286 [[]] .width = true := by decide
def e2388200677914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200677914 : Closed e2388200677914 ∧ code e2388200677914 = 11184293700122 := by decide
private def t_e2388200677914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200677914 : ¬ IsSelfInterpreter e2388200677914 :=
  wSource (t := t_e2388200677914) (replay_sound (ps := []) (t := e2388200677914) (by decide)) (by decide)
def e2388200679450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388200679450 : Closed e2388200679450 ∧ code e2388200679450 = 11184293701658 := by decide
theorem cert_e2388200679450 : check e2388200679450 [[]] .width = true := by decide
def e2388200685594 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388200685594 : Closed e2388200685594 ∧ code e2388200685594 = 11184293707802 := by decide
theorem cert_e2388200685594 : check e2388200685594 [[]] .width = true := by decide
def e2388200685686 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388200685686 : Closed e2388200685686 ∧ code e2388200685686 = 11184293707894 := by decide
theorem cert_e2388200685686 : check e2388200685686 [[]] .width = true := by decide
def e2388200685930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388200685930 : Closed e2388200685930 ∧ code e2388200685930 = 11184293708138 := by decide
theorem cert_e2388200685930 : check e2388200685930 [[]] .width = true := by decide
def e2388200685978 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388200685978 : Closed e2388200685978 ∧ code e2388200685978 = 11184293708186 := by decide
theorem cert_e2388200685978 : check e2388200685978 [[]] .width = true := by decide
def e2388200686986 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388200686986 : Closed e2388200686986 ∧ code e2388200686986 = 11184293709194 := by decide
theorem cert_e2388200686986 : check e2388200686986 [[]] .width = true := by decide
def e2388200687010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388200687010 : Closed e2388200687010 ∧ code e2388200687010 = 11184293709218 := by decide
private def t_e2388200687010 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2388200687010 : ¬ IsSelfInterpreter e2388200687010 :=
  wSource (t := t_e2388200687010) (replay_sound (ps := []) (t := e2388200687010) (by decide)) (by decide)
def e2388200687118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388200687118 : Closed e2388200687118 ∧ code e2388200687118 = 11184293709326 := by decide
theorem cert_e2388200687118 : check e2388200687118 [[]] .width = true := by decide
def e2388200687130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388200687130 : Closed e2388200687130 ∧ code e2388200687130 = 11184293709338 := by decide
private def t_e2388200687130 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2388200687130 : ¬ IsSelfInterpreter e2388200687130 :=
  wSource (t := t_e2388200687130) (replay_sound (ps := []) (t := e2388200687130) (by decide)) (by decide)
def e2388200687202 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388200687202 : Closed e2388200687202 ∧ code e2388200687202 = 11184293709410 := by decide
theorem cert_e2388200687202 : check e2388200687202 [[]] .width = true := by decide
def e2388200839706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200839706 : Closed e2388200839706 ∧ code e2388200839706 = 11184293861914 := by decide
private def t_e2388200839706 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200839706 : ¬ IsSelfInterpreter e2388200839706 :=
  wSource (t := t_e2388200839706) (replay_sound (ps := []) (t := e2388200839706) (by decide)) (by decide)
def e2388200843802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388200843802 : Closed e2388200843802 ∧ code e2388200843802 = 11184293866010 := by decide
private def t_e2388200843802 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388200843802 : ¬ IsSelfInterpreter e2388200843802 :=
  wSource (t := t_e2388200843802) (replay_sound (ps := []) (t := e2388200843802) (by decide)) (by decide)
def e2388206139930 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206139930 : Closed e2388206139930 ∧ code e2388206139930 = 11184299162138 := by decide
private def t_e2388206139930 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388206139930 : ¬ IsSelfInterpreter e2388206139930 :=
  wSource (t := t_e2388206139930) (replay_sound (ps := [[],[.left],[.left]]) (t := e2388206139930) (by decide)) (by decide)
def e2388206148122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206148122 : Closed e2388206148122 ∧ code e2388206148122 = 11184299170330 := by decide
def e2388206205466 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206205466 : Closed e2388206205466 ∧ code e2388206205466 = 11184299227674 := by decide
private def t_e2388206205466 : Term := (.app (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2388206205466 : ¬ IsSelfInterpreter e2388206205466 :=
  wSource (t := t_e2388206205466) (replay_sound (ps := [[],[.left],[.left]]) (t := e2388206205466) (by decide)) (by decide)
def e2388206217754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206217754 : Closed e2388206217754 ∧ code e2388206217754 = 11184299239962 := by decide
def e2388206246426 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206246426 : Closed e2388206246426 ∧ code e2388206246426 = 11184299268634 := by decide
def e2388206250522 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206250522 : Closed e2388206250522 ∧ code e2388206250522 = 11184299272730 := by decide
def e2388206533146 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206533146 : Closed e2388206533146 ∧ code e2388206533146 = 11184299555354 := by decide
def e2388206541338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206541338 : Closed e2388206541338 ∧ code e2388206541338 = 11184299563546 := by decide
def e2388206926362 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206926362 : Closed e2388206926362 ∧ code e2388206926362 = 11184299948570 := by decide
def e2388206938650 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388206938650 : Closed e2388206938650 ∧ code e2388206938650 = 11184299960858 := by decide
def e2388207131162 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388207131162 : Closed e2388207131162 ∧ code e2388207131162 = 11184300153370 := by decide
theorem cert_e2388207131162 : check e2388207131162 [[],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2388207135258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388207135258 : Closed e2388207135258 ∧ code e2388207135258 = 11184300157466 := by decide
theorem cert_e2388207135258 : check e2388207135258 [[],[.left],[.left],[],[],[],[]] .sourceHead = true := by decide
def e2388207200282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388207200282 : Closed e2388207200282 ∧ code e2388207200282 = 11184300222490 := by decide
theorem cert_e2388207200282 : check e2388207200282 [[]] .width = true := by decide
def e2388207265818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388207265818 : Closed e2388207265818 ∧ code e2388207265818 = 11184300288026 := by decide
theorem cert_e2388207265818 : check e2388207265818 [[]] .width = true := by decide
def e2388215130138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388215130138 : Closed e2388215130138 ∧ code e2388215130138 = 11184308152346 := by decide
theorem cert_e2388215130138 : check e2388215130138 [[]] .width = true := by decide
def e2388215162906 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388215162906 : Closed e2388215162906 ∧ code e2388215162906 = 11184308185114 := by decide
theorem cert_e2388215162906 : check e2388215162906 [[]] .width = true := by decide
def e2388215249434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388215249434 : Closed e2388215249434 ∧ code e2388215249434 = 11184308271642 := by decide
theorem cert_e2388215249434 : check e2388215249434 [[]] .width = true := by decide
def e2388215392282 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388215392282 : Closed e2388215392282 ∧ code e2388215392282 = 11184308414490 := by decide
theorem cert_e2388215392282 : check e2388215392282 [[]] .width = true := by decide
def e2388215433754 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388215433754 : Closed e2388215433754 ∧ code e2388215433754 = 11184308455962 := by decide
theorem cert_e2388215433754 : check e2388215433754 [[]] .width = true := by decide
def e2388215441434 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388215441434 : Closed e2388215441434 ∧ code e2388215441434 = 11184308463642 := by decide
theorem cert_e2388215441434 : check e2388215441434 [[]] .width = true := by decide
def e2388215446042 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388215446042 : Closed e2388215446042 ∧ code e2388215446042 = 11184308468250 := by decide
theorem cert_e2388215446042 : check e2388215446042 [[]] .width = true := by decide
def e2388215487002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388215487002 : Closed e2388215487002 ∧ code e2388215487002 = 11184308509210 := by decide
theorem cert_e2388215487002 : check e2388215487002 [[]] .width = true := by decide
def e2388215556122 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388215556122 : Closed e2388215556122 ∧ code e2388215556122 = 11184308578330 := by decide
theorem cert_e2388215556122 : check e2388215556122 [[]] .width = true := by decide
def e2388215564826 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388215564826 : Closed e2388215564826 ∧ code e2388215564826 = 11184308587034 := by decide
theorem cert_e2388215564826 : check e2388215564826 [[]] .width = true := by decide
def e2388215572506 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388215572506 : Closed e2388215572506 ∧ code e2388215572506 = 11184308594714 := by decide
theorem cert_e2388215572506 : check e2388215572506 [[]] .width = true := by decide
def e2388215577114 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388215577114 : Closed e2388215577114 ∧ code e2388215577114 = 11184308599322 := by decide
theorem cert_e2388215577114 : check e2388215577114 [[]] .width = true := by decide
def e2388215585306 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388215585306 : Closed e2388215585306 ∧ code e2388215585306 = 11184308607514 := by decide
theorem cert_e2388215585306 : check e2388215585306 [[]] .width = true := by decide
def e2388216703002 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388216703002 : Closed e2388216703002 ∧ code e2388216703002 = 11184309725210 := by decide
theorem cert_e2388216703002 : check e2388216703002 [[]] .width = true := by decide
def e2388216735770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388216735770 : Closed e2388216735770 ∧ code e2388216735770 = 11184309757978 := by decide
theorem cert_e2388216735770 : check e2388216735770 [[]] .width = true := by decide
def e2388217887258 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388217887258 : Closed e2388217887258 ∧ code e2388217887258 = 11184310909466 := by decide
theorem cert_e2388217887258 : check e2388217887258 [[]] .width = true := by decide
def e2388218070554 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388218070554 : Closed e2388218070554 ∧ code e2388218070554 = 11184311092762 := by decide
theorem cert_e2388218070554 : check e2388218070554 [[]] .width = true := by decide
def e2388218073286 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388218073286 : Closed e2388218073286 ∧ code e2388218073286 = 11184311095494 := by decide
theorem cert_e2388218073286 : check e2388218073286 [[]] .width = true := by decide
def e2388218275866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388218275866 : Closed e2388218275866 ∧ code e2388218275866 = 11184311298074 := by decide
theorem cert_e2388218275866 : check e2388218275866 [[]] .width = true := by decide
def e2388218317338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388218317338 : Closed e2388218317338 ∧ code e2388218317338 = 11184311339546 := by decide
theorem cert_e2388218317338 : check e2388218317338 [[]] .width = true := by decide
def e2388218325018 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388218325018 : Closed e2388218325018 ∧ code e2388218325018 = 11184311347226 := by decide
theorem cert_e2388218325018 : check e2388218325018 [[]] .width = true := by decide
def e2388218329626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388218329626 : Closed e2388218329626 ∧ code e2388218329626 = 11184311351834 := by decide
theorem cert_e2388218329626 : check e2388218329626 [[]] .width = true := by decide
def e2388218742810 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388218742810 : Closed e2388218742810 ∧ code e2388218742810 = 11184311765018 := by decide
theorem cert_e2388218742810 : check e2388218742810 [[]] .width = true := by decide
def e2388218744346 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388218744346 : Closed e2388218744346 ∧ code e2388218744346 = 11184311766554 := by decide
theorem cert_e2388218744346 : check e2388218744346 [[]] .width = true := by decide
def e2388218748954 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388218748954 : Closed e2388218748954 ∧ code e2388218748954 = 11184311771162 := by decide
theorem cert_e2388218748954 : check e2388218748954 [[]] .width = true := by decide
def e2388218749046 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388218749046 : Closed e2388218749046 ∧ code e2388218749046 = 11184311771254 := by decide
theorem cert_e2388218749046 : check e2388218749046 [[]] .width = true := by decide
def e2388218749290 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388218749290 : Closed e2388218749290 ∧ code e2388218749290 = 11184311771498 := by decide
theorem cert_e2388218749290 : check e2388218749290 [[]] .width = true := by decide
def e2388218749338 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388218749338 : Closed e2388218749338 ∧ code e2388218749338 = 11184311771546 := by decide
theorem cert_e2388218749338 : check e2388218749338 [[]] .width = true := by decide
def e2388218753222 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388218753222 : Closed e2388218753222 ∧ code e2388218753222 = 11184311775430 := by decide
theorem cert_e2388218753222 : check e2388218753222 [[]] .width = true := by decide
def e2388218765850 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388218765850 : Closed e2388218765850 ∧ code e2388218765850 = 11184311788058 := by decide
theorem cert_e2388218765850 : check e2388218765850 [[]] .width = true := by decide
def e2388218767386 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388218767386 : Closed e2388218767386 ∧ code e2388218767386 = 11184311789594 := by decide
theorem cert_e2388218767386 : check e2388218767386 [[]] .width = true := by decide
def e2388218773530 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388218773530 : Closed e2388218773530 ∧ code e2388218773530 = 11184311795738 := by decide
theorem cert_e2388218773530 : check e2388218773530 [[]] .width = true := by decide
def e2388218773622 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2388218773622 : Closed e2388218773622 ∧ code e2388218773622 = 11184311795830 := by decide
theorem cert_e2388218773622 : check e2388218773622 [[]] .width = true := by decide
def e2388218773866 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2388218773866 : Closed e2388218773866 ∧ code e2388218773866 = 11184311796074 := by decide
theorem cert_e2388218773866 : check e2388218773866 [[]] .width = true := by decide
def e2388218773914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2388218773914 : Closed e2388218773914 ∧ code e2388218773914 = 11184311796122 := by decide
theorem cert_e2388218773914 : check e2388218773914 [[]] .width = true := by decide
def e2388218774922 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2388218774922 : Closed e2388218774922 ∧ code e2388218774922 = 11184311797130 := by decide
theorem cert_e2388218774922 : check e2388218774922 [[]] .width = true := by decide
def e2388218774946 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2388218774946 : Closed e2388218774946 ∧ code e2388218774946 = 11184311797154 := by decide
theorem cert_e2388218774946 : check e2388218774946 [[]] .width = true := by decide
def e2388218775054 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2388218775054 : Closed e2388218775054 ∧ code e2388218775054 = 11184311797262 := by decide
theorem cert_e2388218775054 : check e2388218775054 [[]] .width = true := by decide
def e2388218775066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388218775066 : Closed e2388218775066 ∧ code e2388218775066 = 11184311797274 := by decide
theorem cert_e2388218775066 : check e2388218775066 [[]] .width = true := by decide
def e2388218775138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2388218775138 : Closed e2388218775138 ∧ code e2388218775138 = 11184311797346 := by decide
theorem cert_e2388218775138 : check e2388218775138 [[]] .width = true := by decide
def e2388218903066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388218903066 : Closed e2388218903066 ∧ code e2388218903066 = 11184311925274 := by decide
theorem cert_e2388218903066 : check e2388218903066 [[]] .width = true := by decide
def e2388218988058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388218988058 : Closed e2388218988058 ∧ code e2388218988058 = 11184312010266 := by decide
theorem cert_e2388218988058 : check e2388218988058 [[]] .width = true := by decide
def e2388218990790 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388218990790 : Closed e2388218990790 ∧ code e2388218990790 = 11184312012998 := by decide
theorem cert_e2388218990790 : check e2388218990790 [[]] .width = true := by decide
def e2388219095066 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388219095066 : Closed e2388219095066 ∧ code e2388219095066 = 11184312117274 := by decide
theorem cert_e2388219095066 : check e2388219095066 [[]] .width = true := by decide
def e2388219103770 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388219103770 : Closed e2388219103770 ∧ code e2388219103770 = 11184312125978 := by decide
theorem cert_e2388219103770 : check e2388219103770 [[]] .width = true := by decide
def e2388219111450 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388219111450 : Closed e2388219111450 ∧ code e2388219111450 = 11184312133658 := by decide
theorem cert_e2388219111450 : check e2388219111450 [[]] .width = true := by decide
def e2388219116058 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388219116058 : Closed e2388219116058 ∧ code e2388219116058 = 11184312138266 := by decide
theorem cert_e2388219116058 : check e2388219116058 [[]] .width = true := by decide
def e2388219124250 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388219124250 : Closed e2388219124250 ∧ code e2388219124250 = 11184312146458 := by decide
theorem cert_e2388219124250 : check e2388219124250 [[]] .width = true := by decide
def e2388219267098 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.var 0))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388219267098 : Closed e2388219267098 ∧ code e2388219267098 = 11184312289306 := by decide
theorem cert_e2388219267098 : check e2388219267098 [[]] .width = true := by decide
def e2388219268634 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.lam (.var 2))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388219268634 : Closed e2388219268634 ∧ code e2388219268634 = 11184312290842 := by decide
theorem cert_e2388219268634 : check e2388219268634 [[]] .width = true := by decide
def e2388219273242 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2388219273242 : Closed e2388219273242 ∧ code e2388219273242 = 11184312295450 := by decide
theorem cert_e2388219273242 : check e2388219273242 [[]] .width = true := by decide
def e2388219273334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2388219273334 : Closed e2388219273334 ∧ code e2388219273334 = 11184312295542 := by decide
theorem cert_e2388219273334 : check e2388219273334 [[]] .width = true := by decide
def e2388219273578 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2388219273578 : Closed e2388219273578 ∧ code e2388219273578 = 11184312295786 := by decide
theorem cert_e2388219273578 : check e2388219273578 [[]] .width = true := by decide
def e2388219273626 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2388219273626 : Closed e2388219273626 ∧ code e2388219273626 = 11184312295834 := by decide
theorem cert_e2388219273626 : check e2388219273626 [[]] .width = true := by decide
def e2388219277510 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.lam (.var 1)))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2388219277510 : Closed e2388219277510 ∧ code e2388219277510 = 11184312299718 := by decide
theorem cert_e2388219277510 : check e2388219277510 [[]] .width = true := by decide
def e2388219290138 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.lam (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2388219290138 : Closed e2388219290138 ∧ code e2388219290138 = 11184312312346 := by decide
theorem cert_e2388219290138 : check e2388219290138 [[]] .width = true := by decide
def e2388219291674 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2388219291674 : Closed e2388219291674 ∧ code e2388219291674 = 11184312313882 := by decide
theorem cert_e2388219291674 : check e2388219291674 [[]] .width = true := by decide
def e2388219297818 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2388219297818 : Closed e2388219297818 ∧ code e2388219297818 = 11184312320026 := by decide
theorem cert_e2388219297818 : check e2388219297818 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2388198580762
#print axioms Blc.Floor43.cert_e2388198589858
#print axioms Blc.Floor43.cert_e2388198589978
#print axioms Blc.Floor43.cert_e2388199926298
#print axioms Blc.Floor43.cert_e2388199959066
#print axioms Blc.Floor43.cert_e2388200536602
#print axioms Blc.Floor43.cert_e2388200572442
#print axioms Blc.Floor43.cert_e2388200622618
#print axioms Blc.Floor43.cert_e2388200634906
#print axioms Blc.Floor43.cert_e2388200647194
#print axioms Blc.Floor43.cert_e2388200656410
#print axioms Blc.Floor43.cert_e2388200661110
#print axioms Blc.Floor43.cert_e2388200661354
#print axioms Blc.Floor43.cert_e2388200661402
#print axioms Blc.Floor43.cert_e2388200677914
#print axioms Blc.Floor43.cert_e2388200687010
#print axioms Blc.Floor43.cert_e2388200687130
#print axioms Blc.Floor43.cert_e2388200839706
#print axioms Blc.Floor43.cert_e2388200843802
#print axioms Blc.Floor43.cert_e2388206139930
#print axioms Blc.Floor43.cert_e2388206205466
