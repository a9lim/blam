import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e759404695150 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e759404695150 : Closed e759404695150 ∧ code e759404695150 = 9555497717358 := by decide
theorem cert_e759404695150 : check e759404695150 [] .sourceHead = true := by decide
def e759404695162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e759404695162 : Closed e759404695162 ∧ code e759404695162 = 9555497717370 := by decide
theorem cert_e759404695162 : check e759404695162 [] .sourceHead = true := by decide
def e759404695350 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e759404695350 : Closed e759404695350 ∧ code e759404695350 = 9555497717558 := by decide
theorem cert_e759404695350 : check e759404695350 [] .sourceHead = true := by decide
def e759404695354 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e759404695354 : Closed e759404695354 ∧ code e759404695354 = 9555497717562 := by decide
theorem cert_e759404695354 : check e759404695354 [] .sourceHead = true := by decide
def e759404735854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e759404735854 : Closed e759404735854 ∧ code e759404735854 = 9555497758062 := by decide
theorem cert_e759404735854 : check e759404735854 [] .sourceHead = true := by decide
def e759404735862 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e759404735862 : Closed e759404735862 ∧ code e759404735862 = 9555497758070 := by decide
theorem cert_e759404735862 : check e759404735862 [] .sourceHead = true := by decide
def e759404735918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e759404735918 : Closed e759404735918 ∧ code e759404735918 = 9555497758126 := by decide
theorem cert_e759404735918 : check e759404735918 [] .sourceHead = true := by decide
def e759404735930 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e759404735930 : Closed e759404735930 ∧ code e759404735930 = 9555497758138 := by decide
theorem cert_e759404735930 : check e759404735930 [] .sourceHead = true := by decide
def e759404735958 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e759404735958 : Closed e759404735958 ∧ code e759404735958 = 9555497758166 := by decide
theorem cert_e759404735958 : check e759404735958 [] .sourceHead = true := by decide
def e759404735962 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e759404735962 : Closed e759404735962 ∧ code e759404735962 = 9555497758170 := by decide
theorem cert_e759404735962 : check e759404735962 [] .sourceHead = true := by decide
def e759404736174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e759404736174 : Closed e759404736174 ∧ code e759404736174 = 9555497758382 := by decide
theorem cert_e759404736174 : check e759404736174 [] .sourceHead = true := by decide
def e759404736186 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e759404736186 : Closed e759404736186 ∧ code e759404736186 = 9555497758394 := by decide
theorem cert_e759404736186 : check e759404736186 [] .sourceHead = true := by decide
def e759404736234 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e759404736234 : Closed e759404736234 ∧ code e759404736234 = 9555497758442 := by decide
theorem cert_e759404736234 : check e759404736234 [] .sourceHead = true := by decide
def e759404736342 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e759404736342 : Closed e759404736342 ∧ code e759404736342 = 9555497758550 := by decide
theorem cert_e759404736342 : check e759404736342 [] .sourceHead = true := by decide
def e759404736346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e759404736346 : Closed e759404736346 ∧ code e759404736346 = 9555497758554 := by decide
theorem cert_e759404736346 : check e759404736346 [] .sourceHead = true := by decide
def e759404736362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e759404736362 : Closed e759404736362 ∧ code e759404736362 = 9555497758570 := by decide
theorem cert_e759404736362 : check e759404736362 [] .sourceHead = true := by decide
def e759404737390 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e759404737390 : Closed e759404737390 ∧ code e759404737390 = 9555497759598 := by decide
theorem cert_e759404737390 : check e759404737390 [] .sourceHead = true := by decide
def e759404737398 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e759404737398 : Closed e759404737398 ∧ code e759404737398 = 9555497759606 := by decide
theorem cert_e759404737398 : check e759404737398 [] .sourceHead = true := by decide
def e759404737454 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e759404737454 : Closed e759404737454 ∧ code e759404737454 = 9555497759662 := by decide
theorem cert_e759404737454 : check e759404737454 [] .sourceHead = true := by decide
def e759404737466 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e759404737466 : Closed e759404737466 ∧ code e759404737466 = 9555497759674 := by decide
theorem cert_e759404737466 : check e759404737466 [] .sourceHead = true := by decide
def e759404737494 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e759404737494 : Closed e759404737494 ∧ code e759404737494 = 9555497759702 := by decide
theorem cert_e759404737494 : check e759404737494 [] .sourceHead = true := by decide
def e759404737498 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e759404737498 : Closed e759404737498 ∧ code e759404737498 = 9555497759706 := by decide
theorem cert_e759404737498 : check e759404737498 [] .sourceHead = true := by decide
def e759404737774 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e759404737774 : Closed e759404737774 ∧ code e759404737774 = 9555497759982 := by decide
theorem cert_e759404737774 : check e759404737774 [] .sourceHead = true := by decide
def e759404737782 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e759404737782 : Closed e759404737782 ∧ code e759404737782 = 9555497759990 := by decide
theorem cert_e759404737782 : check e759404737782 [] .sourceHead = true := by decide
def e759404738158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404738158 : Closed e759404738158 ∧ code e759404738158 = 9555497760366 := by decide
theorem cert_e759404738158 : check e759404738158 [] .sourceHead = true := by decide
def e759404738170 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404738170 : Closed e759404738170 ∧ code e759404738170 = 9555497760378 := by decide
theorem cert_e759404738170 : check e759404738170 [] .sourceHead = true := by decide
def e759404738358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404738358 : Closed e759404738358 ∧ code e759404738358 = 9555497760566 := by decide
theorem cert_e759404738358 : check e759404738358 [] .sourceHead = true := by decide
def e759404738362 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404738362 : Closed e759404738362 ∧ code e759404738362 = 9555497760570 := by decide
theorem cert_e759404738362 : check e759404738362 [] .sourceHead = true := by decide
def e759404738798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 2))) (.var 2))))))))
theorem wire_e759404738798 : Closed e759404738798 ∧ code e759404738798 = 9555497761006 := by decide
theorem cert_e759404738798 : check e759404738798 [] .sourceHead = true := by decide
def e759404738806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 1))))))))
theorem wire_e759404738806 : Closed e759404738806 ∧ code e759404738806 = 9555497761014 := by decide
theorem cert_e759404738806 : check e759404738806 [] .sourceHead = true := by decide
def e759404738990 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e759404738990 : Closed e759404738990 ∧ code e759404738990 = 9555497761198 := by decide
theorem cert_e759404738990 : check e759404738990 [] .sourceHead = true := by decide
def e759404739002 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e759404739002 : Closed e759404739002 ∧ code e759404739002 = 9555497761210 := by decide
theorem cert_e759404739002 : check e759404739002 [] .sourceHead = true := by decide
def e759404739050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e759404739050 : Closed e759404739050 ∧ code e759404739050 = 9555497761258 := by decide
theorem cert_e759404739050 : check e759404739050 [] .sourceHead = true := by decide
def e759404739182 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404739182 : Closed e759404739182 ∧ code e759404739182 = 9555497761390 := by decide
theorem cert_e759404739182 : check e759404739182 [] .sourceHead = true := by decide
def e759404739194 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404739194 : Closed e759404739194 ∧ code e759404739194 = 9555497761402 := by decide
theorem cert_e759404739194 : check e759404739194 [] .sourceHead = true := by decide
def e759404739358 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e759404739358 : Closed e759404739358 ∧ code e759404739358 = 9555497761566 := by decide
theorem cert_e759404739358 : check e759404739358 [] .sourceHead = true := by decide
def e759404739470 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e759404739470 : Closed e759404739470 ∧ code e759404739470 = 9555497761678 := by decide
theorem cert_e759404739470 : check e759404739470 [] .sourceHead = true := by decide
def e759404739482 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404739482 : Closed e759404739482 ∧ code e759404739482 = 9555497761690 := by decide
theorem cert_e759404739482 : check e759404739482 [] .sourceHead = true := by decide
def e759404739702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 1))))))))
theorem wire_e759404739702 : Closed e759404739702 ∧ code e759404739702 = 9555497761910 := by decide
theorem cert_e759404739702 : check e759404739702 [] .sourceHead = true := by decide
def e759404739798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e759404739798 : Closed e759404739798 ∧ code e759404739798 = 9555497762006 := by decide
theorem cert_e759404739798 : check e759404739798 [] .sourceHead = true := by decide
def e759404739802 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e759404739802 : Closed e759404739802 ∧ code e759404739802 = 9555497762010 := by decide
theorem cert_e759404739802 : check e759404739802 [] .sourceHead = true := by decide
def e759404739818 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e759404739818 : Closed e759404739818 ∧ code e759404739818 = 9555497762026 := by decide
theorem cert_e759404739818 : check e759404739818 [] .sourceHead = true := by decide
def e759404739894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404739894 : Closed e759404739894 ∧ code e759404739894 = 9555497762102 := by decide
theorem cert_e759404739894 : check e759404739894 [] .sourceHead = true := by decide
def e759404739898 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404739898 : Closed e759404739898 ∧ code e759404739898 = 9555497762106 := by decide
theorem cert_e759404739898 : check e759404739898 [] .sourceHead = true := by decide
def e759404739982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e759404739982 : Closed e759404739982 ∧ code e759404739982 = 9555497762190 := by decide
theorem cert_e759404739982 : check e759404739982 [] .sourceHead = true := by decide
def e759404739994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404739994 : Closed e759404739994 ∧ code e759404739994 = 9555497762202 := by decide
theorem cert_e759404739994 : check e759404739994 [] .sourceHead = true := by decide
def e759404741598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e759404741598 : Closed e759404741598 ∧ code e759404741598 = 9555497763806 := by decide
theorem cert_e759404741598 : check e759404741598 [] .sourceHead = true := by decide
def e759404741614 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e759404741614 : Closed e759404741614 ∧ code e759404741614 = 9555497763822 := by decide
theorem cert_e759404741614 : check e759404741614 [] .sourceHead = true := by decide
def e759404743534 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e759404743534 : Closed e759404743534 ∧ code e759404743534 = 9555497765742 := by decide
theorem cert_e759404743534 : check e759404743534 [] .sourceHead = true := by decide
def e759404743542 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e759404743542 : Closed e759404743542 ∧ code e759404743542 = 9555497765750 := by decide
theorem cert_e759404743542 : check e759404743542 [] .sourceHead = true := by decide
def e759404743598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e759404743598 : Closed e759404743598 ∧ code e759404743598 = 9555497765806 := by decide
theorem cert_e759404743598 : check e759404743598 [] .sourceHead = true := by decide
def e759404743610 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e759404743610 : Closed e759404743610 ∧ code e759404743610 = 9555497765818 := by decide
theorem cert_e759404743610 : check e759404743610 [] .sourceHead = true := by decide
def e759404743638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e759404743638 : Closed e759404743638 ∧ code e759404743638 = 9555497765846 := by decide
theorem cert_e759404743638 : check e759404743638 [] .sourceHead = true := by decide
def e759404743642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e759404743642 : Closed e759404743642 ∧ code e759404743642 = 9555497765850 := by decide
theorem cert_e759404743642 : check e759404743642 [] .sourceHead = true := by decide
def e759404743918 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e759404743918 : Closed e759404743918 ∧ code e759404743918 = 9555497766126 := by decide
theorem cert_e759404743918 : check e759404743918 [] .sourceHead = true := by decide
def e759404743926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e759404743926 : Closed e759404743926 ∧ code e759404743926 = 9555497766134 := by decide
theorem cert_e759404743926 : check e759404743926 [] .sourceHead = true := by decide
def e759404744302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e759404744302 : Closed e759404744302 ∧ code e759404744302 = 9555497766510 := by decide
theorem cert_e759404744302 : check e759404744302 [] .sourceHead = true := by decide
def e759404744314 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e759404744314 : Closed e759404744314 ∧ code e759404744314 = 9555497766522 := by decide
theorem cert_e759404744314 : check e759404744314 [] .sourceHead = true := by decide
def e759404744502 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e759404744502 : Closed e759404744502 ∧ code e759404744502 = 9555497766710 := by decide
theorem cert_e759404744502 : check e759404744502 [] .sourceHead = true := by decide
def e759404744506 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e759404744506 : Closed e759404744506 ∧ code e759404744506 = 9555497766714 := by decide
theorem cert_e759404744506 : check e759404744506 [] .sourceHead = true := by decide
def e759404749278 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e759404749278 : Closed e759404749278 ∧ code e759404749278 = 9555497771486 := by decide
theorem cert_e759404749278 : check e759404749278 [] .sourceHead = true := by decide
def e759404749302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e759404749302 : Closed e759404749302 ∧ code e759404749302 = 9555497771510 := by decide
theorem cert_e759404749302 : check e759404749302 [] .sourceHead = true := by decide
def e759404750254 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e759404750254 : Closed e759404750254 ∧ code e759404750254 = 9555497772462 := by decide
theorem cert_e759404750254 : check e759404750254 [] .sourceHead = true := by decide
def e759404750266 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e759404750266 : Closed e759404750266 ∧ code e759404750266 = 9555497772474 := by decide
theorem cert_e759404750266 : check e759404750266 [] .sourceHead = true := by decide
def e759404750314 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e759404750314 : Closed e759404750314 ∧ code e759404750314 = 9555497772522 := by decide
theorem cert_e759404750314 : check e759404750314 [] .sourceHead = true := by decide
def e759404750446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e759404750446 : Closed e759404750446 ∧ code e759404750446 = 9555497772654 := by decide
theorem cert_e759404750446 : check e759404750446 [] .sourceHead = true := by decide
def e759404750458 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e759404750458 : Closed e759404750458 ∧ code e759404750458 = 9555497772666 := by decide
theorem cert_e759404750458 : check e759404750458 [] .sourceHead = true := by decide
def e759404750622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e759404750622 : Closed e759404750622 ∧ code e759404750622 = 9555497772830 := by decide
theorem cert_e759404750622 : check e759404750622 [] .sourceHead = true := by decide
def e759404750734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e759404750734 : Closed e759404750734 ∧ code e759404750734 = 9555497772942 := by decide
theorem cert_e759404750734 : check e759404750734 [] .sourceHead = true := by decide
def e759404750746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404750746 : Closed e759404750746 ∧ code e759404750746 = 9555497772954 := by decide
theorem cert_e759404750746 : check e759404750746 [] .sourceHead = true := by decide
def e759404753134 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e759404753134 : Closed e759404753134 ∧ code e759404753134 = 9555497775342 := by decide
theorem cert_e759404753134 : check e759404753134 [] .sourceHead = true := by decide
def e759404753142 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e759404753142 : Closed e759404753142 ∧ code e759404753142 = 9555497775350 := by decide
theorem cert_e759404753142 : check e759404753142 [] .sourceHead = true := by decide
def e759404753622 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e759404753622 : Closed e759404753622 ∧ code e759404753622 = 9555497775830 := by decide
theorem cert_e759404753622 : check e759404753622 [] .sourceHead = true := by decide
def e759404753626 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e759404753626 : Closed e759404753626 ∧ code e759404753626 = 9555497775834 := by decide
theorem cert_e759404753626 : check e759404753626 [] .sourceHead = true := by decide
def e759404753642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e759404753642 : Closed e759404753642 ∧ code e759404753642 = 9555497775850 := by decide
theorem cert_e759404753642 : check e759404753642 [] .sourceHead = true := by decide
def e759404753718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e759404753718 : Closed e759404753718 ∧ code e759404753718 = 9555497775926 := by decide
theorem cert_e759404753718 : check e759404753718 [] .sourceHead = true := by decide
def e759404753722 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e759404753722 : Closed e759404753722 ∧ code e759404753722 = 9555497775930 := by decide
theorem cert_e759404753722 : check e759404753722 [] .sourceHead = true := by decide
def e759404753806 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e759404753806 : Closed e759404753806 ∧ code e759404753806 = 9555497776014 := by decide
theorem cert_e759404753806 : check e759404753806 [] .sourceHead = true := by decide
def e759404753818 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404753818 : Closed e759404753818 ∧ code e759404753818 = 9555497776026 := by decide
theorem cert_e759404753818 : check e759404753818 [] .sourceHead = true := by decide
def e759404844718 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e759404844718 : Closed e759404844718 ∧ code e759404844718 = 9555497866926 := by decide
theorem cert_e759404844718 : check e759404844718 [] .sourceHead = true := by decide
def e759404844730 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e759404844730 : Closed e759404844730 ∧ code e759404844730 = 9555497866938 := by decide
theorem cert_e759404844730 : check e759404844730 [] .sourceHead = true := by decide
def e759404844778 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e759404844778 : Closed e759404844778 ∧ code e759404844778 = 9555497866986 := by decide
theorem cert_e759404844778 : check e759404844778 [] .sourceHead = true := by decide
def e759404844970 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e759404844970 : Closed e759404844970 ∧ code e759404844970 = 9555497867178 := by decide
theorem cert_e759404844970 : check e759404844970 [] .sourceHead = true := by decide
def e759404845294 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))))
theorem wire_e759404845294 : Closed e759404845294 ∧ code e759404845294 = 9555497867502 := by decide
theorem cert_e759404845294 : check e759404845294 [] .sourceHead = true := by decide
def e759404845302 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 1))))))))
theorem wire_e759404845302 : Closed e759404845302 ∧ code e759404845302 = 9555497867510 := by decide
theorem cert_e759404845302 : check e759404845302 [] .sourceHead = true := by decide
def e759404845486 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e759404845486 : Closed e759404845486 ∧ code e759404845486 = 9555497867694 := by decide
theorem cert_e759404845486 : check e759404845486 [] .sourceHead = true := by decide
def e759404845498 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e759404845498 : Closed e759404845498 ∧ code e759404845498 = 9555497867706 := by decide
theorem cert_e759404845498 : check e759404845498 [] .sourceHead = true := by decide
def e759404845546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e759404845546 : Closed e759404845546 ∧ code e759404845546 = 9555497867754 := by decide
theorem cert_e759404845546 : check e759404845546 [] .sourceHead = true := by decide
def e759404845678 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e759404845678 : Closed e759404845678 ∧ code e759404845678 = 9555497867886 := by decide
theorem cert_e759404845678 : check e759404845678 [] .sourceHead = true := by decide
def e759404845690 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e759404845690 : Closed e759404845690 ∧ code e759404845690 = 9555497867898 := by decide
theorem cert_e759404845690 : check e759404845690 [] .sourceHead = true := by decide
def e759404845854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e759404845854 : Closed e759404845854 ∧ code e759404845854 = 9555497868062 := by decide
theorem cert_e759404845854 : check e759404845854 [] .sourceHead = true := by decide
def e759404845966 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e759404845966 : Closed e759404845966 ∧ code e759404845966 = 9555497868174 := by decide
theorem cert_e759404845966 : check e759404845966 [] .sourceHead = true := by decide
def e759404845978 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404845978 : Closed e759404845978 ∧ code e759404845978 = 9555497868186 := by decide
theorem cert_e759404845978 : check e759404845978 [] .sourceHead = true := by decide
def e759404846190 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 1))) (.var 2))))))))
theorem wire_e759404846190 : Closed e759404846190 ∧ code e759404846190 = 9555497868398 := by decide
theorem cert_e759404846190 : check e759404846190 [] .sourceHead = true := by decide
def e759404846202 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.var 3))) (.var 0))))))))
theorem wire_e759404846202 : Closed e759404846202 ∧ code e759404846202 = 9555497868410 := by decide
theorem cert_e759404846202 : check e759404846202 [] .sourceHead = true := by decide
def e759404846366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e759404846366 : Closed e759404846366 ∧ code e759404846366 = 9555497868574 := by decide
theorem cert_e759404846366 : check e759404846366 [] .sourceHead = true := by decide
def e759404846534 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e759404846534 : Closed e759404846534 ∧ code e759404846534 = 9555497868742 := by decide
theorem cert_e759404846534 : check e759404846534 [] .sourceHead = true := by decide
def e759404846646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e759404846646 : Closed e759404846646 ∧ code e759404846646 = 9555497868854 := by decide
theorem cert_e759404846646 : check e759404846646 [] .sourceHead = true := by decide
def e759404846650 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e759404846650 : Closed e759404846650 ∧ code e759404846650 = 9555497868858 := by decide
theorem cert_e759404846650 : check e759404846650 [] .sourceHead = true := by decide
def e759404846698 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e759404846698 : Closed e759404846698 ∧ code e759404846698 = 9555497868906 := by decide
theorem cert_e759404846698 : check e759404846698 [] .sourceHead = true := by decide
def e759404846734 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e759404846734 : Closed e759404846734 ∧ code e759404846734 = 9555497868942 := by decide
theorem cert_e759404846734 : check e759404846734 [] .sourceHead = true := by decide
def e759404846746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404846746 : Closed e759404846746 ∧ code e759404846746 = 9555497868954 := by decide
theorem cert_e759404846746 : check e759404846746 [] .sourceHead = true := by decide
def e759404846790 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e759404846790 : Closed e759404846790 ∧ code e759404846790 = 9555497868998 := by decide
theorem cert_e759404846790 : check e759404846790 [] .sourceHead = true := by decide
def e759404847582 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e759404847582 : Closed e759404847582 ∧ code e759404847582 = 9555497869790 := by decide
theorem cert_e759404847582 : check e759404847582 [] .sourceHead = true := by decide
def e759404847606 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e759404847606 : Closed e759404847606 ∧ code e759404847606 = 9555497869814 := by decide
theorem cert_e759404847606 : check e759404847606 [] .sourceHead = true := by decide
def e759404848558 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e759404848558 : Closed e759404848558 ∧ code e759404848558 = 9555497870766 := by decide
theorem cert_e759404848558 : check e759404848558 [] .sourceHead = true := by decide
def e759404848570 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e759404848570 : Closed e759404848570 ∧ code e759404848570 = 9555497870778 := by decide
theorem cert_e759404848570 : check e759404848570 [] .sourceHead = true := by decide
def e759404848618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e759404848618 : Closed e759404848618 ∧ code e759404848618 = 9555497870826 := by decide
theorem cert_e759404848618 : check e759404848618 [] .sourceHead = true := by decide
def e759404848750 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e759404848750 : Closed e759404848750 ∧ code e759404848750 = 9555497870958 := by decide
theorem cert_e759404848750 : check e759404848750 [] .sourceHead = true := by decide
def e759404848762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e759404848762 : Closed e759404848762 ∧ code e759404848762 = 9555497870970 := by decide
theorem cert_e759404848762 : check e759404848762 [] .sourceHead = true := by decide
def e759404848926 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e759404848926 : Closed e759404848926 ∧ code e759404848926 = 9555497871134 := by decide
theorem cert_e759404848926 : check e759404848926 [] .sourceHead = true := by decide
def e759404849038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e759404849038 : Closed e759404849038 ∧ code e759404849038 = 9555497871246 := by decide
theorem cert_e759404849038 : check e759404849038 [] .sourceHead = true := by decide
def e759404849050 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404849050 : Closed e759404849050 ∧ code e759404849050 = 9555497871258 := by decide
theorem cert_e759404849050 : check e759404849050 [] .sourceHead = true := by decide
def e759404851998 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e759404851998 : Closed e759404851998 ∧ code e759404851998 = 9555497874206 := by decide
theorem cert_e759404851998 : check e759404851998 [] .sourceHead = true := by decide
def e759404852166 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e759404852166 : Closed e759404852166 ∧ code e759404852166 = 9555497874374 := by decide
theorem cert_e759404852166 : check e759404852166 [] .sourceHead = true := by decide
def e759404853366 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e759404853366 : Closed e759404853366 ∧ code e759404853366 = 9555497875574 := by decide
theorem cert_e759404853366 : check e759404853366 [] .sourceHead = true := by decide
def e759404853610 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e759404853610 : Closed e759404853610 ∧ code e759404853610 = 9555497875818 := by decide
theorem cert_e759404853610 : check e759404853610 [] .sourceHead = true := by decide
def e759404853646 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e759404853646 : Closed e759404853646 ∧ code e759404853646 = 9555497875854 := by decide
theorem cert_e759404853646 : check e759404853646 [] .sourceHead = true := by decide
def e759404853658 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404853658 : Closed e759404853658 ∧ code e759404853658 = 9555497875866 := by decide
theorem cert_e759404853658 : check e759404853658 [] .sourceHead = true := by decide
def e759404853702 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e759404853702 : Closed e759404853702 ∧ code e759404853702 = 9555497875910 := by decide
theorem cert_e759404853702 : check e759404853702 [] .sourceHead = true := by decide
def e759404899158 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e759404899158 : Closed e759404899158 ∧ code e759404899158 = 9555497921366 := by decide
theorem cert_e759404899158 : check e759404899158 [] .sourceHead = true := by decide
def e759404899162 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e759404899162 : Closed e759404899162 ∧ code e759404899162 = 9555497921370 := by decide
theorem cert_e759404899162 : check e759404899162 [] .sourceHead = true := by decide
def e759404899178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e759404899178 : Closed e759404899178 ∧ code e759404899178 = 9555497921386 := by decide
theorem cert_e759404899178 : check e759404899178 [] .sourceHead = true := by decide
def e759404899242 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e759404899242 : Closed e759404899242 ∧ code e759404899242 = 9555497921450 := by decide
theorem cert_e759404899242 : check e759404899242 [] .sourceHead = true := by decide
def e759404899446 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 1))))))))
theorem wire_e759404899446 : Closed e759404899446 ∧ code e759404899446 = 9555497921654 := by decide
theorem cert_e759404899446 : check e759404899446 [] .sourceHead = true := by decide
def e759404899542 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e759404899542 : Closed e759404899542 ∧ code e759404899542 = 9555497921750 := by decide
theorem cert_e759404899542 : check e759404899542 [] .sourceHead = true := by decide
def e759404899546 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e759404899546 : Closed e759404899546 ∧ code e759404899546 = 9555497921754 := by decide
theorem cert_e759404899546 : check e759404899546 [] .sourceHead = true := by decide
def e759404899562 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e759404899562 : Closed e759404899562 ∧ code e759404899562 = 9555497921770 := by decide
theorem cert_e759404899562 : check e759404899562 [] .sourceHead = true := by decide
def e759404899638 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e759404899638 : Closed e759404899638 ∧ code e759404899638 = 9555497921846 := by decide
theorem cert_e759404899638 : check e759404899638 [] .sourceHead = true := by decide
def e759404899642 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e759404899642 : Closed e759404899642 ∧ code e759404899642 = 9555497921850 := by decide
theorem cert_e759404899642 : check e759404899642 [] .sourceHead = true := by decide
def e759404899726 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e759404899726 : Closed e759404899726 ∧ code e759404899726 = 9555497921934 := by decide
theorem cert_e759404899726 : check e759404899726 [] .sourceHead = true := by decide
def e759404899738 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404899738 : Closed e759404899738 ∧ code e759404899738 = 9555497921946 := by decide
theorem cert_e759404899738 : check e759404899738 [] .sourceHead = true := by decide
def e759404899894 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 1))))))))
theorem wire_e759404899894 : Closed e759404899894 ∧ code e759404899894 = 9555497922102 := by decide
theorem cert_e759404899894 : check e759404899894 [] .sourceHead = true := by decide
def e759404899898 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 2))) (.var 0))))))))
theorem wire_e759404899898 : Closed e759404899898 ∧ code e759404899898 = 9555497922106 := by decide
theorem cert_e759404899898 : check e759404899898 [] .sourceHead = true := by decide
def e759404899946 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e759404899946 : Closed e759404899946 ∧ code e759404899946 = 9555497922154 := by decide
theorem cert_e759404899946 : check e759404899946 [] .sourceHead = true := by decide
def e759404899982 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e759404899982 : Closed e759404899982 ∧ code e759404899982 = 9555497922190 := by decide
theorem cert_e759404899982 : check e759404899982 [] .sourceHead = true := by decide
def e759404899994 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e759404899994 : Closed e759404899994 ∧ code e759404899994 = 9555497922202 := by decide
theorem cert_e759404899994 : check e759404899994 [] .sourceHead = true := by decide
def e759404900038 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e759404900038 : Closed e759404900038 ∧ code e759404900038 = 9555497922246 := by decide
theorem cert_e759404900038 : check e759404900038 [] .sourceHead = true := by decide
def e759404900590 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e759404900590 : Closed e759404900590 ∧ code e759404900590 = 9555497922798 := by decide
theorem cert_e759404900590 : check e759404900590 [] .sourceHead = true := by decide
def e759404900598 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e759404900598 : Closed e759404900598 ∧ code e759404900598 = 9555497922806 := by decide
theorem cert_e759404900598 : check e759404900598 [] .sourceHead = true := by decide
def e759404901078 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e759404901078 : Closed e759404901078 ∧ code e759404901078 = 9555497923286 := by decide
theorem cert_e759404901078 : check e759404901078 [] .sourceHead = true := by decide
def e759404901082 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e759404901082 : Closed e759404901082 ∧ code e759404901082 = 9555497923290 := by decide
theorem cert_e759404901082 : check e759404901082 [] .sourceHead = true := by decide
def e759404901098 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e759404901098 : Closed e759404901098 ∧ code e759404901098 = 9555497923306 := by decide
theorem cert_e759404901098 : check e759404901098 [] .sourceHead = true := by decide
def e759404901174 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e759404901174 : Closed e759404901174 ∧ code e759404901174 = 9555497923382 := by decide
theorem cert_e759404901174 : check e759404901174 [] .sourceHead = true := by decide
def e759404901178 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e759404901178 : Closed e759404901178 ∧ code e759404901178 = 9555497923386 := by decide
theorem cert_e759404901178 : check e759404901178 [] .sourceHead = true := by decide
def e759404901262 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e759404901262 : Closed e759404901262 ∧ code e759404901262 = 9555497923470 := by decide
theorem cert_e759404901262 : check e759404901262 [] .sourceHead = true := by decide
def e759404901274 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404901274 : Closed e759404901274 ∧ code e759404901274 = 9555497923482 := by decide
theorem cert_e759404901274 : check e759404901274 [] .sourceHead = true := by decide
def e759404902518 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e759404902518 : Closed e759404902518 ∧ code e759404902518 = 9555497924726 := by decide
theorem cert_e759404902518 : check e759404902518 [] .sourceHead = true := by decide
def e759404902762 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e759404902762 : Closed e759404902762 ∧ code e759404902762 = 9555497924970 := by decide
theorem cert_e759404902762 : check e759404902762 [] .sourceHead = true := by decide
def e759404902798 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e759404902798 : Closed e759404902798 ∧ code e759404902798 = 9555497925006 := by decide
theorem cert_e759404902798 : check e759404902798 [] .sourceHead = true := by decide
def e759404902810 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e759404902810 : Closed e759404902810 ∧ code e759404902810 = 9555497925018 := by decide
theorem cert_e759404902810 : check e759404902810 [] .sourceHead = true := by decide
def e759404902854 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e759404902854 : Closed e759404902854 ∧ code e759404902854 = 9555497925062 := by decide
theorem cert_e759404902854 : check e759404902854 [] .sourceHead = true := by decide
def e759406800314 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))))
theorem wire_e759406800314 : Closed e759406800314 ∧ code e759406800314 = 9555499822522 := by decide
theorem cert_e759406800314 : check e759406800314 [] .sourceHead = true := by decide
def e759406800346 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))))
theorem wire_e759406800346 : Closed e759406800346 ∧ code e759406800346 = 9555499822554 := by decide
theorem cert_e759406800346 : check e759406800346 [] .sourceHead = true := by decide
def e759406800570 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))))
theorem wire_e759406800570 : Closed e759406800570 ∧ code e759406800570 = 9555499822778 := by decide
theorem cert_e759406800570 : check e759406800570 [] .sourceHead = true := by decide
def e759406800618 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))))
theorem wire_e759406800618 : Closed e759406800618 ∧ code e759406800618 = 9555499822826 := by decide
theorem cert_e759406800618 : check e759406800618 [] .sourceHead = true := by decide
def e759406800730 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))))
theorem wire_e759406800730 : Closed e759406800730 ∧ code e759406800730 = 9555499822938 := by decide
theorem cert_e759406800730 : check e759406800730 [] .sourceHead = true := by decide
def e759406800746 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))))
theorem wire_e759406800746 : Closed e759406800746 ∧ code e759406800746 = 9555499822954 := by decide
theorem cert_e759406800746 : check e759406800746 [] .sourceHead = true := by decide
def e759406801850 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))))
theorem wire_e759406801850 : Closed e759406801850 ∧ code e759406801850 = 9555499824058 := by decide
theorem cert_e759406801850 : check e759406801850 [] .sourceHead = true := by decide
def e759406801882 : Term := (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))))
theorem wire_e759406801882 : Closed e759406801882 ∧ code e759406801882 = 9555499824090 := by decide
theorem cert_e759406801882 : check e759406801882 [] .sourceHead = true := by decide
end Blc.Floor43
