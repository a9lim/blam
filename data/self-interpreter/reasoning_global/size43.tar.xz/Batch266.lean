import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2406051501706 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0))))
theorem wire_e2406051501706 : Closed e2406051501706 ∧ code e2406051501706 = 11202144523914 := by decide
theorem cert_e2406051501706 : check e2406051501706 [[]] .width = true := by decide
def e2406051501730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406051501730 : Closed e2406051501730 ∧ code e2406051501730 = 11202144523938 := by decide
theorem cert_e2406051501730 : check e2406051501730 [[]] .width = true := by decide
def e2406051502090 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.var 0))))) (.var 0))))
theorem wire_e2406051502090 : Closed e2406051502090 ∧ code e2406051502090 = 11202144524298 := by decide
theorem cert_e2406051502090 : check e2406051502090 [[]] .width = true := by decide
def e2406051502138 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 2)))) (.var 0))))
theorem wire_e2406051502138 : Closed e2406051502138 ∧ code e2406051502138 = 11202144524346 := by decide
theorem cert_e2406051502138 : check e2406051502138 [[]] .width = true := by decide
def e2406051502186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.app (.var 0) (.var 0)))) (.var 0))))
theorem wire_e2406051502186 : Closed e2406051502186 ∧ code e2406051502186 = 11202144524394 := by decide
theorem cert_e2406051502186 : check e2406051502186 [[]] .width = true := by decide
def e2406051502234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.app (.var 0) (.var 0)))))
theorem wire_e2406051502234 : Closed e2406051502234 ∧ code e2406051502234 = 11202144524442 := by decide
theorem cert_e2406051502234 : check e2406051502234 [[]] .width = true := by decide
def e2406051502278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 1))) (.lam (.var 1)))))
theorem wire_e2406051502278 : Closed e2406051502278 ∧ code e2406051502278 = 11202144524486 := by decide
theorem cert_e2406051502278 : check e2406051502278 [[]] .width = true := by decide
def e2406051502474 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))))
theorem wire_e2406051502474 : Closed e2406051502474 ∧ code e2406051502474 = 11202144524682 := by decide
theorem cert_e2406051502474 : check e2406051502474 [[]] .width = true := by decide
def e2406051502498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 0)))))
theorem wire_e2406051502498 : Closed e2406051502498 ∧ code e2406051502498 = 11202144524706 := by decide
theorem cert_e2406051502498 : check e2406051502498 [[]] .width = true := by decide
def e2406051502594 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0)))))))
theorem wire_e2406051502594 : Closed e2406051502594 ∧ code e2406051502594 = 11202144524802 := by decide
theorem cert_e2406051502594 : check e2406051502594 [[]] .width = true := by decide
def e2406051502606 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2))))))
theorem wire_e2406051502606 : Closed e2406051502606 ∧ code e2406051502606 = 11202144524814 := by decide
theorem cert_e2406051502606 : check e2406051502606 [[]] .width = true := by decide
def e2406051502618 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406051502618 : Closed e2406051502618 ∧ code e2406051502618 = 11202144524826 := by decide
theorem cert_e2406051502618 : check e2406051502618 [[]] .width = true := by decide
def e2406051502690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406051502690 : Closed e2406051502690 ∧ code e2406051502690 = 11202144524898 := by decide
theorem cert_e2406051502690 : check e2406051502690 [[]] .width = true := by decide
def e2406051504154 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2406051504154 : Closed e2406051504154 ∧ code e2406051504154 = 11202144526362 := by decide
theorem cert_e2406051504154 : check e2406051504154 [[]] .width = true := by decide
def e2406051504238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))))
theorem wire_e2406051504238 : Closed e2406051504238 ∧ code e2406051504238 = 11202144526446 := by decide
theorem cert_e2406051504238 : check e2406051504238 [[]] .width = true := by decide
def e2406051504246 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.var 1)))))))
theorem wire_e2406051504246 : Closed e2406051504246 ∧ code e2406051504246 = 11202144526454 := by decide
theorem cert_e2406051504246 : check e2406051504246 [[]] .width = true := by decide
def e2406051504250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.var 0)))))))
theorem wire_e2406051504250 : Closed e2406051504250 ∧ code e2406051504250 = 11202144526458 := by decide
theorem cert_e2406051504250 : check e2406051504250 [[]] .width = true := by decide
def e2406051504490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))))
theorem wire_e2406051504490 : Closed e2406051504490 ∧ code e2406051504490 = 11202144526698 := by decide
theorem cert_e2406051504490 : check e2406051504490 [[]] .width = true := by decide
def e2406051504526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.var 2)))))))
theorem wire_e2406051504526 : Closed e2406051504526 ∧ code e2406051504526 = 11202144526734 := by decide
theorem cert_e2406051504526 : check e2406051504526 [[]] .width = true := by decide
def e2406051504538 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))))
theorem wire_e2406051504538 : Closed e2406051504538 ∧ code e2406051504538 = 11202144526746 := by decide
theorem cert_e2406051504538 : check e2406051504538 [[]] .width = true := by decide
def e2406051504582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 1) (.lam (.var 1)))))))
theorem wire_e2406051504582 : Closed e2406051504582 ∧ code e2406051504582 = 11202144526790 := by decide
theorem cert_e2406051504582 : check e2406051504582 [[]] .width = true := by decide
def e2406051505546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))
theorem wire_e2406051505546 : Closed e2406051505546 ∧ code e2406051505546 = 11202144527754 := by decide
theorem cert_e2406051505546 : check e2406051505546 [[]] .width = true := by decide
def e2406051505570 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))
theorem wire_e2406051505570 : Closed e2406051505570 ∧ code e2406051505570 = 11202144527778 := by decide
theorem cert_e2406051505570 : check e2406051505570 [[]] .width = true := by decide
def e2406051505666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.var 0))))))))
theorem wire_e2406051505666 : Closed e2406051505666 ∧ code e2406051505666 = 11202144527874 := by decide
theorem cert_e2406051505666 : check e2406051505666 [[]] .width = true := by decide
def e2406051505678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 2)))))))
theorem wire_e2406051505678 : Closed e2406051505678 ∧ code e2406051505678 = 11202144527886 := by decide
theorem cert_e2406051505678 : check e2406051505678 [[]] .width = true := by decide
def e2406051505690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406051505690 : Closed e2406051505690 ∧ code e2406051505690 = 11202144527898 := by decide
theorem cert_e2406051505690 : check e2406051505690 [[]] .width = true := by decide
def e2406051505762 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))
theorem wire_e2406051505762 : Closed e2406051505762 ∧ code e2406051505762 = 11202144527970 := by decide
theorem cert_e2406051505762 : check e2406051505762 [[]] .width = true := by decide
def e2406051551746 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.var 0))))))
theorem wire_e2406051551746 : Closed e2406051551746 ∧ code e2406051551746 = 11202144573954 := by decide
theorem cert_e2406051551746 : check e2406051551746 [[]] .width = true := by decide
def e2406051551770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406051551770 : Closed e2406051551770 ∧ code e2406051551770 = 11202144573978 := by decide
theorem cert_e2406051551770 : check e2406051551770 [[]] .width = true := by decide
def e2406104477038 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2406104477038 : Closed e2406104477038 ∧ code e2406104477038 = 11202197499246 := by decide
theorem cert_e2406104477038 : check e2406104477038 [[],[]] .chain = true := by decide
def e2406104477046 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2406104477046 : Closed e2406104477046 ∧ code e2406104477046 = 11202197499254 := by decide
theorem cert_e2406104477046 : check e2406104477046 [[],[]] .chain = true := by decide
def e2406104477102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2406104477102 : Closed e2406104477102 ∧ code e2406104477102 = 11202197499310 := by decide
theorem cert_e2406104477102 : check e2406104477102 [[],[]] .chain = true := by decide
def e2406104477114 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2406104477114 : Closed e2406104477114 ∧ code e2406104477114 = 11202197499322 := by decide
theorem cert_e2406104477114 : check e2406104477114 [[],[]] .chain = true := by decide
def e2406104477142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2406104477142 : Closed e2406104477142 ∧ code e2406104477142 = 11202197499350 := by decide
theorem cert_e2406104477142 : check e2406104477142 [[],[]] .chain = true := by decide
def e2406104477146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2406104477146 : Closed e2406104477146 ∧ code e2406104477146 = 11202197499354 := by decide
theorem cert_e2406104477146 : check e2406104477146 [[],[]] .chain = true := by decide
def e2406104477358 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2406104477358 : Closed e2406104477358 ∧ code e2406104477358 = 11202197499566 := by decide
theorem cert_e2406104477358 : check e2406104477358 [[],[]] .chain = true := by decide
def e2406104477370 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2406104477370 : Closed e2406104477370 ∧ code e2406104477370 = 11202197499578 := by decide
theorem cert_e2406104477370 : check e2406104477370 [[],[]] .chain = true := by decide
def e2406104477418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2406104477418 : Closed e2406104477418 ∧ code e2406104477418 = 11202197499626 := by decide
theorem cert_e2406104477418 : check e2406104477418 [[],[]] .chain = true := by decide
def e2406104477526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2406104477526 : Closed e2406104477526 ∧ code e2406104477526 = 11202197499734 := by decide
theorem cert_e2406104477526 : check e2406104477526 [[],[]] .chain = true := by decide
def e2406104477530 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2406104477530 : Closed e2406104477530 ∧ code e2406104477530 = 11202197499738 := by decide
theorem cert_e2406104477530 : check e2406104477530 [[],[]] .chain = true := by decide
def e2406104477546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2406104477546 : Closed e2406104477546 ∧ code e2406104477546 = 11202197499754 := by decide
theorem cert_e2406104477546 : check e2406104477546 [[],[]] .chain = true := by decide
def e2406104478574 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2406104478574 : Closed e2406104478574 ∧ code e2406104478574 = 11202197500782 := by decide
theorem cert_e2406104478574 : check e2406104478574 [[],[]] .chain = true := by decide
def e2406104478582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2406104478582 : Closed e2406104478582 ∧ code e2406104478582 = 11202197500790 := by decide
theorem cert_e2406104478582 : check e2406104478582 [[],[]] .chain = true := by decide
def e2406104478638 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2406104478638 : Closed e2406104478638 ∧ code e2406104478638 = 11202197500846 := by decide
theorem cert_e2406104478638 : check e2406104478638 [[],[]] .chain = true := by decide
def e2406104478650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2406104478650 : Closed e2406104478650 ∧ code e2406104478650 = 11202197500858 := by decide
theorem cert_e2406104478650 : check e2406104478650 [[],[]] .chain = true := by decide
def e2406104478678 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2406104478678 : Closed e2406104478678 ∧ code e2406104478678 = 11202197500886 := by decide
theorem cert_e2406104478678 : check e2406104478678 [[],[]] .chain = true := by decide
def e2406104478682 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2406104478682 : Closed e2406104478682 ∧ code e2406104478682 = 11202197500890 := by decide
theorem cert_e2406104478682 : check e2406104478682 [[],[]] .chain = true := by decide
def e2406104478958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2406104478958 : Closed e2406104478958 ∧ code e2406104478958 = 11202197501166 := by decide
theorem cert_e2406104478958 : check e2406104478958 [[],[]] .chain = true := by decide
def e2406104478966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2406104478966 : Closed e2406104478966 ∧ code e2406104478966 = 11202197501174 := by decide
theorem cert_e2406104478966 : check e2406104478966 [[],[]] .chain = true := by decide
def e2406104479342 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2406104479342 : Closed e2406104479342 ∧ code e2406104479342 = 11202197501550 := by decide
theorem cert_e2406104479342 : check e2406104479342 [[],[]] .chain = true := by decide
def e2406104479354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2406104479354 : Closed e2406104479354 ∧ code e2406104479354 = 11202197501562 := by decide
theorem cert_e2406104479354 : check e2406104479354 [[],[]] .chain = true := by decide
def e2406104479542 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2406104479542 : Closed e2406104479542 ∧ code e2406104479542 = 11202197501750 := by decide
theorem cert_e2406104479542 : check e2406104479542 [[],[]] .chain = true := by decide
def e2406104479546 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2406104479546 : Closed e2406104479546 ∧ code e2406104479546 = 11202197501754 := by decide
theorem cert_e2406104479546 : check e2406104479546 [[],[]] .chain = true := by decide
def e2406104480174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2406104480174 : Closed e2406104480174 ∧ code e2406104480174 = 11202197502382 := by decide
theorem cert_e2406104480174 : check e2406104480174 [[],[]] .chain = true := by decide
def e2406104480186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2406104480186 : Closed e2406104480186 ∧ code e2406104480186 = 11202197502394 := by decide
theorem cert_e2406104480186 : check e2406104480186 [[],[]] .chain = true := by decide
def e2406104480234 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2406104480234 : Closed e2406104480234 ∧ code e2406104480234 = 11202197502442 := by decide
theorem cert_e2406104480234 : check e2406104480234 [[],[]] .chain = true := by decide
def e2406104480366 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2406104480366 : Closed e2406104480366 ∧ code e2406104480366 = 11202197502574 := by decide
theorem cert_e2406104480366 : check e2406104480366 [[],[]] .chain = true := by decide
def e2406104480378 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2406104480378 : Closed e2406104480378 ∧ code e2406104480378 = 11202197502586 := by decide
theorem cert_e2406104480378 : check e2406104480378 [[],[]] .chain = true := by decide
def e2406104480666 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2406104480666 : Closed e2406104480666 ∧ code e2406104480666 = 11202197502874 := by decide
theorem cert_e2406104480666 : check e2406104480666 [[],[]] .chain = true := by decide
def e2406104480982 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2406104480982 : Closed e2406104480982 ∧ code e2406104480982 = 11202197503190 := by decide
theorem cert_e2406104480982 : check e2406104480982 [[],[]] .chain = true := by decide
def e2406104480986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2406104480986 : Closed e2406104480986 ∧ code e2406104480986 = 11202197503194 := by decide
theorem cert_e2406104480986 : check e2406104480986 [[],[]] .chain = true := by decide
def e2406104481002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2406104481002 : Closed e2406104481002 ∧ code e2406104481002 = 11202197503210 := by decide
theorem cert_e2406104481002 : check e2406104481002 [[],[]] .chain = true := by decide
def e2406104481078 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2406104481078 : Closed e2406104481078 ∧ code e2406104481078 = 11202197503286 := by decide
theorem cert_e2406104481078 : check e2406104481078 [[],[]] .chain = true := by decide
def e2406104481082 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2406104481082 : Closed e2406104481082 ∧ code e2406104481082 = 11202197503290 := by decide
theorem cert_e2406104481082 : check e2406104481082 [[],[]] .chain = true := by decide
def e2406104481178 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2406104481178 : Closed e2406104481178 ∧ code e2406104481178 = 11202197503386 := by decide
theorem cert_e2406104481178 : check e2406104481178 [[],[]] .chain = true := by decide
def e2406104484718 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2406104484718 : Closed e2406104484718 ∧ code e2406104484718 = 11202197506926 := by decide
theorem cert_e2406104484718 : check e2406104484718 [[],[]] .chain = true := by decide
def e2406104484726 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2406104484726 : Closed e2406104484726 ∧ code e2406104484726 = 11202197506934 := by decide
theorem cert_e2406104484726 : check e2406104484726 [[],[]] .chain = true := by decide
def e2406104484782 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2406104484782 : Closed e2406104484782 ∧ code e2406104484782 = 11202197506990 := by decide
theorem cert_e2406104484782 : check e2406104484782 [[],[]] .chain = true := by decide
def e2406104484794 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2406104484794 : Closed e2406104484794 ∧ code e2406104484794 = 11202197507002 := by decide
theorem cert_e2406104484794 : check e2406104484794 [[],[]] .chain = true := by decide
def e2406104484822 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2406104484822 : Closed e2406104484822 ∧ code e2406104484822 = 11202197507030 := by decide
theorem cert_e2406104484822 : check e2406104484822 [[],[]] .chain = true := by decide
def e2406104484826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2406104484826 : Closed e2406104484826 ∧ code e2406104484826 = 11202197507034 := by decide
theorem cert_e2406104484826 : check e2406104484826 [[],[]] .chain = true := by decide
def e2406104485102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2406104485102 : Closed e2406104485102 ∧ code e2406104485102 = 11202197507310 := by decide
theorem cert_e2406104485102 : check e2406104485102 [[],[]] .chain = true := by decide
def e2406104485110 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2406104485110 : Closed e2406104485110 ∧ code e2406104485110 = 11202197507318 := by decide
theorem cert_e2406104485110 : check e2406104485110 [[],[]] .chain = true := by decide
def e2406104485486 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2406104485486 : Closed e2406104485486 ∧ code e2406104485486 = 11202197507694 := by decide
theorem cert_e2406104485486 : check e2406104485486 [[],[]] .chain = true := by decide
def e2406104485498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2406104485498 : Closed e2406104485498 ∧ code e2406104485498 = 11202197507706 := by decide
theorem cert_e2406104485498 : check e2406104485498 [[],[]] .chain = true := by decide
def e2406104485686 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2406104485686 : Closed e2406104485686 ∧ code e2406104485686 = 11202197507894 := by decide
theorem cert_e2406104485686 : check e2406104485686 [[],[]] .chain = true := by decide
def e2406104485690 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2406104485690 : Closed e2406104485690 ∧ code e2406104485690 = 11202197507898 := by decide
theorem cert_e2406104485690 : check e2406104485690 [[],[]] .chain = true := by decide
def e2406104491438 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2406104491438 : Closed e2406104491438 ∧ code e2406104491438 = 11202197513646 := by decide
theorem cert_e2406104491438 : check e2406104491438 [[],[]] .chain = true := by decide
def e2406104491450 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2406104491450 : Closed e2406104491450 ∧ code e2406104491450 = 11202197513658 := by decide
theorem cert_e2406104491450 : check e2406104491450 [[],[]] .chain = true := by decide
def e2406104491498 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2406104491498 : Closed e2406104491498 ∧ code e2406104491498 = 11202197513706 := by decide
theorem cert_e2406104491498 : check e2406104491498 [[],[]] .chain = true := by decide
def e2406104491630 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2406104491630 : Closed e2406104491630 ∧ code e2406104491630 = 11202197513838 := by decide
theorem cert_e2406104491630 : check e2406104491630 [[],[]] .chain = true := by decide
def e2406104491642 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2406104491642 : Closed e2406104491642 ∧ code e2406104491642 = 11202197513850 := by decide
theorem cert_e2406104491642 : check e2406104491642 [[],[]] .chain = true := by decide
def e2406104491930 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2406104491930 : Closed e2406104491930 ∧ code e2406104491930 = 11202197514138 := by decide
theorem cert_e2406104491930 : check e2406104491930 [[],[]] .chain = true := by decide
def e2406104494806 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2406104494806 : Closed e2406104494806 ∧ code e2406104494806 = 11202197517014 := by decide
theorem cert_e2406104494806 : check e2406104494806 [[],[]] .chain = true := by decide
def e2406104494810 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2406104494810 : Closed e2406104494810 ∧ code e2406104494810 = 11202197517018 := by decide
theorem cert_e2406104494810 : check e2406104494810 [[],[]] .chain = true := by decide
def e2406104494826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2406104494826 : Closed e2406104494826 ∧ code e2406104494826 = 11202197517034 := by decide
theorem cert_e2406104494826 : check e2406104494826 [[],[]] .chain = true := by decide
def e2406104494902 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2406104494902 : Closed e2406104494902 ∧ code e2406104494902 = 11202197517110 := by decide
theorem cert_e2406104494902 : check e2406104494902 [[],[]] .chain = true := by decide
def e2406104494906 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2406104494906 : Closed e2406104494906 ∧ code e2406104494906 = 11202197517114 := by decide
theorem cert_e2406104494906 : check e2406104494906 [[],[]] .chain = true := by decide
def e2406104495002 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2406104495002 : Closed e2406104495002 ∧ code e2406104495002 = 11202197517210 := by decide
theorem cert_e2406104495002 : check e2406104495002 [[],[]] .chain = true := by decide
def e2406104632174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2406104632174 : Closed e2406104632174 ∧ code e2406104632174 = 11202197654382 := by decide
theorem cert_e2406104632174 : check e2406104632174 [[],[]] .chain = true := by decide
def e2406104632182 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2406104632182 : Closed e2406104632182 ∧ code e2406104632182 = 11202197654390 := by decide
theorem cert_e2406104632182 : check e2406104632182 [[],[]] .chain = true := by decide
def e2406104632238 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2406104632238 : Closed e2406104632238 ∧ code e2406104632238 = 11202197654446 := by decide
theorem cert_e2406104632238 : check e2406104632238 [[],[]] .chain = true := by decide
def e2406104632250 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2406104632250 : Closed e2406104632250 ∧ code e2406104632250 = 11202197654458 := by decide
theorem cert_e2406104632250 : check e2406104632250 [[],[]] .chain = true := by decide
def e2406104632278 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2406104632278 : Closed e2406104632278 ∧ code e2406104632278 = 11202197654486 := by decide
theorem cert_e2406104632278 : check e2406104632278 [[],[]] .chain = true := by decide
def e2406104632282 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2406104632282 : Closed e2406104632282 ∧ code e2406104632282 = 11202197654490 := by decide
theorem cert_e2406104632282 : check e2406104632282 [[],[]] .chain = true := by decide
def e2406104632558 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2406104632558 : Closed e2406104632558 ∧ code e2406104632558 = 11202197654766 := by decide
theorem cert_e2406104632558 : check e2406104632558 [[],[]] .chain = true := by decide
def e2406104632566 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2406104632566 : Closed e2406104632566 ∧ code e2406104632566 = 11202197654774 := by decide
theorem cert_e2406104632566 : check e2406104632566 [[],[]] .chain = true := by decide
def e2406104632942 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2406104632942 : Closed e2406104632942 ∧ code e2406104632942 = 11202197655150 := by decide
theorem cert_e2406104632942 : check e2406104632942 [[],[]] .chain = true := by decide
def e2406104632954 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2406104632954 : Closed e2406104632954 ∧ code e2406104632954 = 11202197655162 := by decide
theorem cert_e2406104632954 : check e2406104632954 [[],[]] .chain = true := by decide
def e2406104633142 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2406104633142 : Closed e2406104633142 ∧ code e2406104633142 = 11202197655350 := by decide
theorem cert_e2406104633142 : check e2406104633142 [[],[]] .chain = true := by decide
def e2406104633146 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2406104633146 : Closed e2406104633146 ∧ code e2406104633146 = 11202197655354 := by decide
theorem cert_e2406104633146 : check e2406104633146 [[],[]] .chain = true := by decide
def e2406105221998 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2406105221998 : Closed e2406105221998 ∧ code e2406105221998 = 11202198244206 := by decide
theorem cert_e2406105221998 : check e2406105221998 [[],[],[]] .smaller = true := by decide
def e2406105222006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2406105222006 : Closed e2406105222006 ∧ code e2406105222006 = 11202198244214 := by decide
theorem cert_e2406105222006 : check e2406105222006 [[],[],[]] .smaller = true := by decide
def e2406105222062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2406105222062 : Closed e2406105222062 ∧ code e2406105222062 = 11202198244270 := by decide
theorem cert_e2406105222062 : check e2406105222062 [[],[],[]] .smaller = true := by decide
def e2406105222074 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2406105222074 : Closed e2406105222074 ∧ code e2406105222074 = 11202198244282 := by decide
theorem cert_e2406105222074 : check e2406105222074 [[],[],[]] .smaller = true := by decide
def e2406105222102 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2406105222102 : Closed e2406105222102 ∧ code e2406105222102 = 11202198244310 := by decide
theorem cert_e2406105222102 : check e2406105222102 [[],[],[]] .smaller = true := by decide
def e2406105222106 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2406105222106 : Closed e2406105222106 ∧ code e2406105222106 = 11202198244314 := by decide
theorem cert_e2406105222106 : check e2406105222106 [[],[],[]] .smaller = true := by decide
def e2406105222382 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2406105222382 : Closed e2406105222382 ∧ code e2406105222382 = 11202198244590 := by decide
theorem cert_e2406105222382 : check e2406105222382 [[],[],[]] .smaller = true := by decide
def e2406105222390 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2406105222390 : Closed e2406105222390 ∧ code e2406105222390 = 11202198244598 := by decide
theorem cert_e2406105222390 : check e2406105222390 [[],[],[]] .smaller = true := by decide
def e2406105222766 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2406105222766 : Closed e2406105222766 ∧ code e2406105222766 = 11202198244974 := by decide
theorem cert_e2406105222766 : check e2406105222766 [[],[],[]] .smaller = true := by decide
def e2406105222778 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2406105222778 : Closed e2406105222778 ∧ code e2406105222778 = 11202198244986 := by decide
theorem cert_e2406105222778 : check e2406105222778 [[],[],[]] .smaller = true := by decide
def e2406105222966 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2406105222966 : Closed e2406105222966 ∧ code e2406105222966 = 11202198245174 := by decide
theorem cert_e2406105222966 : check e2406105222966 [[],[],[]] .smaller = true := by decide
def e2406105222970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2406105222970 : Closed e2406105222970 ∧ code e2406105222970 = 11202198245178 := by decide
theorem cert_e2406105222970 : check e2406105222970 [[],[],[]] .smaller = true := by decide
def e2406129041434 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406129041434 : Closed e2406129041434 ∧ code e2406129041434 = 11202222063642 := by decide
theorem cert_e2406129041434 : check e2406129041434 [[]] .width = true := by decide
def e2406129041526 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406129041526 : Closed e2406129041526 ∧ code e2406129041526 = 11202222063734 := by decide
theorem cert_e2406129041526 : check e2406129041526 [[]] .width = true := by decide
def e2406129041770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406129041770 : Closed e2406129041770 ∧ code e2406129041770 = 11202222063978 := by decide
theorem cert_e2406129041770 : check e2406129041770 [[]] .width = true := by decide
def e2406129041818 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406129041818 : Closed e2406129041818 ∧ code e2406129041818 = 11202222064026 := by decide
theorem cert_e2406129041818 : check e2406129041818 [[]] .width = true := by decide
def e2406129042826 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406129042826 : Closed e2406129042826 ∧ code e2406129042826 = 11202222065034 := by decide
theorem cert_e2406129042826 : check e2406129042826 [[]] .width = true := by decide
def e2406129042850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406129042850 : Closed e2406129042850 ∧ code e2406129042850 = 11202222065058 := by decide
theorem cert_e2406129042850 : check e2406129042850 [[]] .width = true := by decide
def e2406129042958 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406129042958 : Closed e2406129042958 ∧ code e2406129042958 = 11202222065166 := by decide
theorem cert_e2406129042958 : check e2406129042958 [[]] .width = true := by decide
def e2406129042970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406129042970 : Closed e2406129042970 ∧ code e2406129042970 = 11202222065178 := by decide
theorem cert_e2406129042970 : check e2406129042970 [[]] .width = true := by decide
def e2406129043042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406129043042 : Closed e2406129043042 ∧ code e2406129043042 = 11202222065250 := by decide
theorem cert_e2406129043042 : check e2406129043042 [[]] .width = true := by decide
def e2406129365190 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.lam (.var 2))))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406129365190 : Closed e2406129365190 ∧ code e2406129365190 = 11202222387398 := by decide
theorem cert_e2406129365190 : check e2406129365190 [[]] .width = true := by decide
def e2406129434650 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2406129434650 : Closed e2406129434650 ∧ code e2406129434650 = 11202222456858 := by decide
theorem cert_e2406129434650 : check e2406129434650 [[]] .width = true := by decide
def e2406129434742 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2406129434742 : Closed e2406129434742 ∧ code e2406129434742 = 11202222456950 := by decide
theorem cert_e2406129434742 : check e2406129434742 [[]] .width = true := by decide
def e2406129434986 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2406129434986 : Closed e2406129434986 ∧ code e2406129434986 = 11202222457194 := by decide
theorem cert_e2406129434986 : check e2406129434986 [[]] .width = true := by decide
def e2406129435034 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2406129435034 : Closed e2406129435034 ∧ code e2406129435034 = 11202222457242 := by decide
theorem cert_e2406129435034 : check e2406129435034 [[]] .width = true := by decide
def e2406129436042 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2406129436042 : Closed e2406129436042 ∧ code e2406129436042 = 11202222458250 := by decide
theorem cert_e2406129436042 : check e2406129436042 [[]] .width = true := by decide
def e2406129436066 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2406129436066 : Closed e2406129436066 ∧ code e2406129436066 = 11202222458274 := by decide
theorem cert_e2406129436066 : check e2406129436066 [[]] .width = true := by decide
def e2406129436174 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2406129436174 : Closed e2406129436174 ∧ code e2406129436174 = 11202222458382 := by decide
theorem cert_e2406129436174 : check e2406129436174 [[]] .width = true := by decide
def e2406129436186 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406129436186 : Closed e2406129436186 ∧ code e2406129436186 = 11202222458394 := by decide
theorem cert_e2406129436186 : check e2406129436186 [[]] .width = true := by decide
def e2406129436258 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2406129436258 : Closed e2406129436258 ∧ code e2406129436258 = 11202222458466 := by decide
theorem cert_e2406129436258 : check e2406129436258 [[]] .width = true := by decide
def e2406143932442 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406143932442 : Closed e2406143932442 ∧ code e2406143932442 = 11202236954650 := by decide
theorem cert_e2406143932442 : check e2406143932442 [[]] .width = true := by decide
def e2406143944730 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406143944730 : Closed e2406143944730 ∧ code e2406143944730 = 11202236966938 := by decide
theorem cert_e2406143944730 : check e2406143944730 [[]] .width = true := by decide
def e2406143946266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406143946266 : Closed e2406143946266 ∧ code e2406143946266 = 11202236968474 := by decide
theorem cert_e2406143946266 : check e2406143946266 [[]] .width = true := by decide
def e2406143993882 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406143993882 : Closed e2406143993882 ∧ code e2406143993882 = 11202237016090 := by decide
theorem cert_e2406143993882 : check e2406143993882 [[]] .width = true := by decide
def e2406143995418 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406143995418 : Closed e2406143995418 ∧ code e2406143995418 = 11202237017626 := by decide
theorem cert_e2406143995418 : check e2406143995418 [[]] .width = true := by decide
def e2406143998490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406143998490 : Closed e2406143998490 ∧ code e2406143998490 = 11202237020698 := by decide
theorem cert_e2406143998490 : check e2406143998490 [[]] .width = true := by decide
def e2406144190490 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144190490 : Closed e2406144190490 ∧ code e2406144190490 = 11202237212698 := by decide
theorem cert_e2406144190490 : check e2406144190490 [[]] .width = true := by decide
def e2406144192026 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406144192026 : Closed e2406144192026 ∧ code e2406144192026 = 11202237214234 := by decide
theorem cert_e2406144192026 : check e2406144192026 [[]] .width = true := by decide
def e2406144195098 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406144195098 : Closed e2406144195098 ∧ code e2406144195098 = 11202237217306 := by decide
theorem cert_e2406144195098 : check e2406144195098 [[]] .width = true := by decide
def e2406144207386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406144207386 : Closed e2406144207386 ∧ code e2406144207386 = 11202237229594 := by decide
private def t_e2406144207386 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2406144207386 : ¬ IsSelfInterpreter e2406144207386 :=
  wSource (t := t_e2406144207386) (replay_sound (ps := []) (t := e2406144207386) (by decide)) (by decide)
def e2406144325658 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144325658 : Closed e2406144325658 ∧ code e2406144325658 = 11202237347866 := by decide
theorem cert_e2406144325658 : check e2406144325658 [[]] .width = true := by decide
def e2406144466970 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2406144466970 : Closed e2406144466970 ∧ code e2406144466970 = 11202237489178 := by decide
theorem cert_e2406144466970 : check e2406144466970 [[]] .width = true := by decide
def e2406144467062 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1)))))
theorem wire_e2406144467062 : Closed e2406144467062 ∧ code e2406144467062 = 11202237489270 := by decide
theorem cert_e2406144467062 : check e2406144467062 [[]] .width = true := by decide
def e2406144467306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0))))
theorem wire_e2406144467306 : Closed e2406144467306 ∧ code e2406144467306 = 11202237489514 := by decide
theorem cert_e2406144467306 : check e2406144467306 [[]] .width = true := by decide
def e2406144467354 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0)))))
theorem wire_e2406144467354 : Closed e2406144467354 ∧ code e2406144467354 = 11202237489562 := by decide
theorem cert_e2406144467354 : check e2406144467354 [[]] .width = true := by decide
def e2406144504006 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406144504006 : Closed e2406144504006 ∧ code e2406144504006 = 11202237526214 := by decide
theorem cert_e2406144504006 : check e2406144504006 [[]] .width = true := by decide
def e2406144522266 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 2))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144522266 : Closed e2406144522266 ∧ code e2406144522266 = 11202237544474 := by decide
theorem cert_e2406144522266 : check e2406144522266 [[]] .width = true := by decide
def e2406144528582 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406144528582 : Closed e2406144528582 ∧ code e2406144528582 = 11202237550790 := by decide
theorem cert_e2406144528582 : check e2406144528582 [[]] .width = true := by decide
def e2406144718874 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144718874 : Closed e2406144718874 ∧ code e2406144718874 = 11202237741082 := by decide
theorem cert_e2406144718874 : check e2406144718874 [[]] .width = true := by decide
def e2406144731162 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144731162 : Closed e2406144731162 ∧ code e2406144731162 = 11202237753370 := by decide
theorem cert_e2406144731162 : check e2406144731162 [[]] .width = true := by decide
def e2406144732698 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406144732698 : Closed e2406144732698 ∧ code e2406144732698 = 11202237754906 := by decide
theorem cert_e2406144732698 : check e2406144732698 [[]] .width = true := by decide
def e2406144780314 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144780314 : Closed e2406144780314 ∧ code e2406144780314 = 11202237802522 := by decide
theorem cert_e2406144780314 : check e2406144780314 [[]] .width = true := by decide
def e2406144781850 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406144781850 : Closed e2406144781850 ∧ code e2406144781850 = 11202237804058 := by decide
theorem cert_e2406144781850 : check e2406144781850 [[]] .width = true := by decide
def e2406144784922 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406144784922 : Closed e2406144784922 ∧ code e2406144784922 = 11202237807130 := by decide
theorem cert_e2406144784922 : check e2406144784922 [[]] .width = true := by decide
def e2406144864454 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2406144864454 : Closed e2406144864454 ∧ code e2406144864454 = 11202237886662 := by decide
theorem cert_e2406144864454 : check e2406144864454 [[]] .width = true := by decide
def e2406144915482 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144915482 : Closed e2406144915482 ∧ code e2406144915482 = 11202237937690 := by decide
theorem cert_e2406144915482 : check e2406144915482 [[]] .width = true := by decide
def e2406144927770 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2406144927770 : Closed e2406144927770 ∧ code e2406144927770 = 11202237949978 := by decide
theorem cert_e2406144927770 : check e2406144927770 [[]] .width = true := by decide
def e2406144929306 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2406144929306 : Closed e2406144929306 ∧ code e2406144929306 = 11202237951514 := by decide
theorem cert_e2406144929306 : check e2406144929306 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2406144207386
