import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2392345265690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345265690 : Closed e2392345265690 ∧ code e2392345265690 = 11188438287898 := by decide
private def t_e2392345265690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345265690 : ¬ IsSelfInterpreter e2392345265690 :=
  wSource (t := t_e2392345265690) (replay_sound (ps := []) (t := e2392345265690) (by decide)) (by decide)
def e2392345268422 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392345268422 : Closed e2392345268422 ∧ code e2392345268422 = 11188438290630 := by decide
theorem cert_e2392345268422 : check e2392345268422 [[]] .width = true := by decide
def e2392345423386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345423386 : Closed e2392345423386 ∧ code e2392345423386 = 11188438445594 := by decide
private def t_e2392345423386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345423386 : ¬ IsSelfInterpreter e2392345423386 :=
  wSource (t := t_e2392345423386) (replay_sound (ps := []) (t := e2392345423386) (by decide)) (by decide)
def e2392345458714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392345458714 : Closed e2392345458714 ∧ code e2392345458714 = 11188438480922 := by decide
theorem cert_e2392345458714 : check e2392345458714 [[]] .width = true := by decide
def e2392345469466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345469466 : Closed e2392345469466 ∧ code e2392345469466 = 11188438491674 := by decide
private def t_e2392345469466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345469466 : ¬ IsSelfInterpreter e2392345469466 :=
  wSource (t := t_e2392345469466) (replay_sound (ps := []) (t := e2392345469466) (by decide)) (by decide)
def e2392345471002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392345471002 : Closed e2392345471002 ∧ code e2392345471002 = 11188438493210 := by decide
theorem cert_e2392345471002 : check e2392345471002 [[]] .width = true := by decide
def e2392345472538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345472538 : Closed e2392345472538 ∧ code e2392345472538 = 11188438494746 := by decide
private def t_e2392345472538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345472538 : ¬ IsSelfInterpreter e2392345472538 :=
  wSource (t := t_e2392345472538) (replay_sound (ps := []) (t := e2392345472538) (by decide)) (by decide)
def e2392345512474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345512474 : Closed e2392345512474 ∧ code e2392345512474 = 11188438534682 := by decide
private def t_e2392345512474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345512474 : ¬ IsSelfInterpreter e2392345512474 :=
  wSource (t := t_e2392345512474) (replay_sound (ps := []) (t := e2392345512474) (by decide)) (by decide)
def e2392345518618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345518618 : Closed e2392345518618 ∧ code e2392345518618 = 11188438540826 := by decide
private def t_e2392345518618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345518618 : ¬ IsSelfInterpreter e2392345518618 :=
  wSource (t := t_e2392345518618) (replay_sound (ps := []) (t := e2392345518618) (by decide)) (by decide)
def e2392345520154 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392345520154 : Closed e2392345520154 ∧ code e2392345520154 = 11188438542362 := by decide
theorem cert_e2392345520154 : check e2392345520154 [[]] .width = true := by decide
def e2392345521690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345521690 : Closed e2392345521690 ∧ code e2392345521690 = 11188438543898 := by decide
private def t_e2392345521690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345521690 : ¬ IsSelfInterpreter e2392345521690 :=
  wSource (t := t_e2392345521690) (replay_sound (ps := []) (t := e2392345521690) (by decide)) (by decide)
def e2392345524762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345524762 : Closed e2392345524762 ∧ code e2392345524762 = 11188438546970 := by decide
private def t_e2392345524762 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345524762 : ¬ IsSelfInterpreter e2392345524762 :=
  wSource (t := t_e2392345524762) (replay_sound (ps := []) (t := e2392345524762) (by decide)) (by decide)
def e2392345558554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345558554 : Closed e2392345558554 ∧ code e2392345558554 = 11188438580762 := by decide
private def t_e2392345558554 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.var 4)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345558554 : ¬ IsSelfInterpreter e2392345558554 :=
  wSource (t := t_e2392345558554) (replay_sound (ps := []) (t := e2392345558554) (by decide)) (by decide)
def e2392345604294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392345604294 : Closed e2392345604294 ∧ code e2392345604294 = 11188438626502 := by decide
theorem cert_e2392345604294 : check e2392345604294 [[]] .width = true := by decide
def e2392345655322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392345655322 : Closed e2392345655322 ∧ code e2392345655322 = 11188438677530 := by decide
theorem cert_e2392345655322 : check e2392345655322 [[]] .width = true := by decide
def e2392345666074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345666074 : Closed e2392345666074 ∧ code e2392345666074 = 11188438688282 := by decide
private def t_e2392345666074 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345666074 : ¬ IsSelfInterpreter e2392345666074 :=
  wSource (t := t_e2392345666074) (replay_sound (ps := []) (t := e2392345666074) (by decide)) (by decide)
def e2392345667610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392345667610 : Closed e2392345667610 ∧ code e2392345667610 = 11188438689818 := by decide
theorem cert_e2392345667610 : check e2392345667610 [[]] .width = true := by decide
def e2392345669146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345669146 : Closed e2392345669146 ∧ code e2392345669146 = 11188438691354 := by decide
private def t_e2392345669146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345669146 : ¬ IsSelfInterpreter e2392345669146 :=
  wSource (t := t_e2392345669146) (replay_sound (ps := []) (t := e2392345669146) (by decide)) (by decide)
def e2392345772058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392345772058 : Closed e2392345772058 ∧ code e2392345772058 = 11188438794266 := by decide
theorem cert_e2392345772058 : check e2392345772058 [[]] .width = true := by decide
def e2392345772150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392345772150 : Closed e2392345772150 ∧ code e2392345772150 = 11188438794358 := by decide
theorem cert_e2392345772150 : check e2392345772150 [[]] .width = true := by decide
def e2392345772394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392345772394 : Closed e2392345772394 ∧ code e2392345772394 = 11188438794602 := by decide
theorem cert_e2392345772394 : check e2392345772394 [[]] .width = true := by decide
def e2392345772442 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392345772442 : Closed e2392345772442 ∧ code e2392345772442 = 11188438794650 := by decide
theorem cert_e2392345772442 : check e2392345772442 [[]] .width = true := by decide
def e2392345773450 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392345773450 : Closed e2392345773450 ∧ code e2392345773450 = 11188438795658 := by decide
theorem cert_e2392345773450 : check e2392345773450 [[]] .width = true := by decide
def e2392345773474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392345773474 : Closed e2392345773474 ∧ code e2392345773474 = 11188438795682 := by decide
private def t_e2392345773474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392345773474 : ¬ IsSelfInterpreter e2392345773474 :=
  wSource (t := t_e2392345773474) (replay_sound (ps := []) (t := e2392345773474) (by decide)) (by decide)
def e2392345773582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392345773582 : Closed e2392345773582 ∧ code e2392345773582 = 11188438795790 := by decide
theorem cert_e2392345773582 : check e2392345773582 [[]] .width = true := by decide
def e2392345773594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392345773594 : Closed e2392345773594 ∧ code e2392345773594 = 11188438795802 := by decide
private def t_e2392345773594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392345773594 : ¬ IsSelfInterpreter e2392345773594 :=
  wSource (t := t_e2392345773594) (replay_sound (ps := []) (t := e2392345773594) (by decide)) (by decide)
def e2392345773666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392345773666 : Closed e2392345773666 ∧ code e2392345773666 = 11188438795874 := by decide
theorem cert_e2392345773666 : check e2392345773666 [[]] .width = true := by decide
def e2392345939482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345939482 : Closed e2392345939482 ∧ code e2392345939482 = 11188438961690 := by decide
private def t_e2392345939482 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345939482 : ¬ IsSelfInterpreter e2392345939482 :=
  wSource (t := t_e2392345939482) (replay_sound (ps := []) (t := e2392345939482) (by decide)) (by decide)
def e2392345948358 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392345948358 : Closed e2392345948358 ∧ code e2392345948358 = 11188438970566 := by decide
theorem cert_e2392345948358 : check e2392345948358 [[]] .width = true := by decide
def e2392345960986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345960986 : Closed e2392345960986 ∧ code e2392345960986 = 11188438983194 := by decide
private def t_e2392345960986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345960986 : ¬ IsSelfInterpreter e2392345960986 :=
  wSource (t := t_e2392345960986) (replay_sound (ps := []) (t := e2392345960986) (by decide)) (by decide)
def e2392345962522 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392345962522 : Closed e2392345962522 ∧ code e2392345962522 = 11188438984730 := by decide
theorem cert_e2392345962522 : check e2392345962522 [[]] .width = true := by decide
def e2392345964058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345964058 : Closed e2392345964058 ∧ code e2392345964058 = 11188438986266 := by decide
private def t_e2392345964058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345964058 : ¬ IsSelfInterpreter e2392345964058 :=
  wSource (t := t_e2392345964058) (replay_sound (ps := []) (t := e2392345964058) (by decide)) (by decide)
def e2392345967130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392345967130 : Closed e2392345967130 ∧ code e2392345967130 = 11188438989338 := by decide
private def t_e2392345967130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392345967130 : ¬ IsSelfInterpreter e2392345967130 :=
  wSource (t := t_e2392345967130) (replay_sound (ps := []) (t := e2392345967130) (by decide)) (by decide)
def e2392345968666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392345968666 : Closed e2392345968666 ∧ code e2392345968666 = 11188438990874 := by decide
theorem cert_e2392345968666 : check e2392345968666 [[]] .width = true := by decide
def e2392345968758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392345968758 : Closed e2392345968758 ∧ code e2392345968758 = 11188438990966 := by decide
theorem cert_e2392345968758 : check e2392345968758 [[]] .width = true := by decide
def e2392345969002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392345969002 : Closed e2392345969002 ∧ code e2392345969002 = 11188438991210 := by decide
theorem cert_e2392345969002 : check e2392345969002 [[]] .width = true := by decide
def e2392345969050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392345969050 : Closed e2392345969050 ∧ code e2392345969050 = 11188438991258 := by decide
theorem cert_e2392345969050 : check e2392345969050 [[]] .width = true := by decide
def e2392345970058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392345970058 : Closed e2392345970058 ∧ code e2392345970058 = 11188438992266 := by decide
theorem cert_e2392345970058 : check e2392345970058 [[]] .width = true := by decide
def e2392345970082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392345970082 : Closed e2392345970082 ∧ code e2392345970082 = 11188438992290 := by decide
private def t_e2392345970082 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392345970082 : ¬ IsSelfInterpreter e2392345970082 :=
  wSource (t := t_e2392345970082) (replay_sound (ps := []) (t := e2392345970082) (by decide)) (by decide)
def e2392345970190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392345970190 : Closed e2392345970190 ∧ code e2392345970190 = 11188438992398 := by decide
theorem cert_e2392345970190 : check e2392345970190 [[]] .width = true := by decide
def e2392345970202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392345970202 : Closed e2392345970202 ∧ code e2392345970202 = 11188438992410 := by decide
private def t_e2392345970202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392345970202 : ¬ IsSelfInterpreter e2392345970202 :=
  wSource (t := t_e2392345970202) (replay_sound (ps := []) (t := e2392345970202) (by decide)) (by decide)
def e2392345970274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392345970274 : Closed e2392345970274 ∧ code e2392345970274 = 11188438992482 := by decide
theorem cert_e2392345970274 : check e2392345970274 [[]] .width = true := by decide
def e2392346097178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346097178 : Closed e2392346097178 ∧ code e2392346097178 = 11188439119386 := by decide
private def t_e2392346097178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346097178 : ¬ IsSelfInterpreter e2392346097178 :=
  wSource (t := t_e2392346097178) (replay_sound (ps := []) (t := e2392346097178) (by decide)) (by decide)
def e2392346098202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346098202 : Closed e2392346098202 ∧ code e2392346098202 = 11188439120410 := by decide
private def t_e2392346098202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346098202 : ¬ IsSelfInterpreter e2392346098202 :=
  wSource (t := t_e2392346098202) (replay_sound (ps := []) (t := e2392346098202) (by decide)) (by decide)
def e2392346146330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346146330 : Closed e2392346146330 ∧ code e2392346146330 = 11188439168538 := by decide
private def t_e2392346146330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346146330 : ¬ IsSelfInterpreter e2392346146330 :=
  wSource (t := t_e2392346146330) (replay_sound (ps := []) (t := e2392346146330) (by decide)) (by decide)
def e2392346147354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346147354 : Closed e2392346147354 ∧ code e2392346147354 = 11188439169562 := by decide
private def t_e2392346147354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346147354 : ¬ IsSelfInterpreter e2392346147354 :=
  wSource (t := t_e2392346147354) (replay_sound (ps := []) (t := e2392346147354) (by decide)) (by decide)
def e2392346168858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346168858 : Closed e2392346168858 ∧ code e2392346168858 = 11188439191066 := by decide
private def t_e2392346168858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346168858 : ¬ IsSelfInterpreter e2392346168858 :=
  wSource (t := t_e2392346168858) (replay_sound (ps := []) (t := e2392346168858) (by decide)) (by decide)
def e2392346177734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392346177734 : Closed e2392346177734 ∧ code e2392346177734 = 11188439199942 := by decide
theorem cert_e2392346177734 : check e2392346177734 [[]] .width = true := by decide
def e2392346183194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346183194 : Closed e2392346183194 ∧ code e2392346183194 = 11188439205402 := by decide
private def t_e2392346183194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346183194 : ¬ IsSelfInterpreter e2392346183194 :=
  wSource (t := t_e2392346183194) (replay_sound (ps := []) (t := e2392346183194) (by decide)) (by decide)
def e2392346185926 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392346185926 : Closed e2392346185926 ∧ code e2392346185926 = 11188439208134 := by decide
theorem cert_e2392346185926 : check e2392346185926 [[]] .width = true := by decide
def e2392346269210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346269210 : Closed e2392346269210 ∧ code e2392346269210 = 11188439291418 := by decide
private def t_e2392346269210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346269210 : ¬ IsSelfInterpreter e2392346269210 :=
  wSource (t := t_e2392346269210) (replay_sound (ps := []) (t := e2392346269210) (by decide)) (by decide)
def e2392346286106 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392346286106 : Closed e2392346286106 ∧ code e2392346286106 = 11188439308314 := by decide
theorem cert_e2392346286106 : check e2392346286106 [[]] .width = true := by decide
def e2392346288666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346288666 : Closed e2392346288666 ∧ code e2392346288666 = 11188439310874 := by decide
private def t_e2392346288666 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346288666 : ¬ IsSelfInterpreter e2392346288666 :=
  wSource (t := t_e2392346288666) (replay_sound (ps := []) (t := e2392346288666) (by decide)) (by decide)
def e2392346290202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392346290202 : Closed e2392346290202 ∧ code e2392346290202 = 11188439312410 := by decide
theorem cert_e2392346290202 : check e2392346290202 [[]] .width = true := by decide
def e2392346291738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346291738 : Closed e2392346291738 ∧ code e2392346291738 = 11188439313946 := by decide
private def t_e2392346291738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346291738 : ¬ IsSelfInterpreter e2392346291738 :=
  wSource (t := t_e2392346291738) (replay_sound (ps := []) (t := e2392346291738) (by decide)) (by decide)
def e2392346293786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346293786 : Closed e2392346293786 ∧ code e2392346293786 = 11188439315994 := by decide
private def t_e2392346293786 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346293786 : ¬ IsSelfInterpreter e2392346293786 :=
  wSource (t := t_e2392346293786) (replay_sound (ps := []) (t := e2392346293786) (by decide)) (by decide)
def e2392346298906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346298906 : Closed e2392346298906 ∧ code e2392346298906 = 11188439321114 := by decide
private def t_e2392346298906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346298906 : ¬ IsSelfInterpreter e2392346298906 :=
  wSource (t := t_e2392346298906) (replay_sound (ps := []) (t := e2392346298906) (by decide)) (by decide)
def e2392346305050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346305050 : Closed e2392346305050 ∧ code e2392346305050 = 11188439327258 := by decide
private def t_e2392346305050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346305050 : ¬ IsSelfInterpreter e2392346305050 :=
  wSource (t := t_e2392346305050) (replay_sound (ps := []) (t := e2392346305050) (by decide)) (by decide)
def e2392346306586 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392346306586 : Closed e2392346306586 ∧ code e2392346306586 = 11188439328794 := by decide
theorem cert_e2392346306586 : check e2392346306586 [[]] .width = true := by decide
def e2392346308122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346308122 : Closed e2392346308122 ∧ code e2392346308122 = 11188439330330 := by decide
private def t_e2392346308122 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346308122 : ¬ IsSelfInterpreter e2392346308122 :=
  wSource (t := t_e2392346308122) (replay_sound (ps := []) (t := e2392346308122) (by decide)) (by decide)
def e2392346311194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346311194 : Closed e2392346311194 ∧ code e2392346311194 = 11188439333402 := by decide
private def t_e2392346311194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346311194 : ¬ IsSelfInterpreter e2392346311194 :=
  wSource (t := t_e2392346311194) (replay_sound (ps := []) (t := e2392346311194) (by decide)) (by decide)
def e2392346318362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346318362 : Closed e2392346318362 ∧ code e2392346318362 = 11188439340570 := by decide
private def t_e2392346318362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346318362 : ¬ IsSelfInterpreter e2392346318362 :=
  wSource (t := t_e2392346318362) (replay_sound (ps := []) (t := e2392346318362) (by decide)) (by decide)
def e2392346319386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346319386 : Closed e2392346319386 ∧ code e2392346319386 = 11188439341594 := by decide
private def t_e2392346319386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346319386 : ¬ IsSelfInterpreter e2392346319386 :=
  wSource (t := t_e2392346319386) (replay_sound (ps := []) (t := e2392346319386) (by decide)) (by decide)
def e2392346336794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346336794 : Closed e2392346336794 ∧ code e2392346336794 = 11188439359002 := by decide
private def t_e2392346336794 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346336794 : ¬ IsSelfInterpreter e2392346336794 :=
  wSource (t := t_e2392346336794) (replay_sound (ps := []) (t := e2392346336794) (by decide)) (by decide)
def e2392346357958 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392346357958 : Closed e2392346357958 ∧ code e2392346357958 = 11188439380166 := by decide
theorem cert_e2392346357958 : check e2392346357958 [[]] .width = true := by decide
def e2392346384410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392346384410 : Closed e2392346384410 ∧ code e2392346384410 = 11188439406618 := by decide
theorem cert_e2392346384410 : check e2392346384410 [[]] .width = true := by decide
def e2392346386970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346386970 : Closed e2392346386970 ∧ code e2392346386970 = 11188439409178 := by decide
private def t_e2392346386970 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346386970 : ¬ IsSelfInterpreter e2392346386970 :=
  wSource (t := t_e2392346386970) (replay_sound (ps := []) (t := e2392346386970) (by decide)) (by decide)
def e2392346388506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392346388506 : Closed e2392346388506 ∧ code e2392346388506 = 11188439410714 := by decide
theorem cert_e2392346388506 : check e2392346388506 [[]] .width = true := by decide
def e2392346390042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346390042 : Closed e2392346390042 ∧ code e2392346390042 = 11188439412250 := by decide
private def t_e2392346390042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346390042 : ¬ IsSelfInterpreter e2392346390042 :=
  wSource (t := t_e2392346390042) (replay_sound (ps := []) (t := e2392346390042) (by decide)) (by decide)
def e2392346392090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346392090 : Closed e2392346392090 ∧ code e2392346392090 = 11188439414298 := by decide
private def t_e2392346392090 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346392090 : ¬ IsSelfInterpreter e2392346392090 :=
  wSource (t := t_e2392346392090) (replay_sound (ps := []) (t := e2392346392090) (by decide)) (by decide)
def e2392346427418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392346427418 : Closed e2392346427418 ∧ code e2392346427418 = 11188439449626 := by decide
theorem cert_e2392346427418 : check e2392346427418 [[]] .width = true := by decide
def e2392346427510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392346427510 : Closed e2392346427510 ∧ code e2392346427510 = 11188439449718 := by decide
theorem cert_e2392346427510 : check e2392346427510 [[]] .width = true := by decide
def e2392346427754 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392346427754 : Closed e2392346427754 ∧ code e2392346427754 = 11188439449962 := by decide
theorem cert_e2392346427754 : check e2392346427754 [[]] .width = true := by decide
def e2392346427802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392346427802 : Closed e2392346427802 ∧ code e2392346427802 = 11188439450010 := by decide
theorem cert_e2392346427802 : check e2392346427802 [[]] .width = true := by decide
def e2392346428810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392346428810 : Closed e2392346428810 ∧ code e2392346428810 = 11188439451018 := by decide
theorem cert_e2392346428810 : check e2392346428810 [[]] .width = true := by decide
def e2392346428834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392346428834 : Closed e2392346428834 ∧ code e2392346428834 = 11188439451042 := by decide
private def t_e2392346428834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392346428834 : ¬ IsSelfInterpreter e2392346428834 :=
  wSource (t := t_e2392346428834) (replay_sound (ps := []) (t := e2392346428834) (by decide)) (by decide)
def e2392346428942 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392346428942 : Closed e2392346428942 ∧ code e2392346428942 = 11188439451150 := by decide
theorem cert_e2392346428942 : check e2392346428942 [[]] .width = true := by decide
def e2392346428954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392346428954 : Closed e2392346428954 ∧ code e2392346428954 = 11188439451162 := by decide
private def t_e2392346428954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392346428954 : ¬ IsSelfInterpreter e2392346428954 :=
  wSource (t := t_e2392346428954) (replay_sound (ps := []) (t := e2392346428954) (by decide)) (by decide)
def e2392346429026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392346429026 : Closed e2392346429026 ∧ code e2392346429026 = 11188439451234 := by decide
theorem cert_e2392346429026 : check e2392346429026 [[]] .width = true := by decide
def e2392346463770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346463770 : Closed e2392346463770 ∧ code e2392346463770 = 11188439485978 := by decide
private def t_e2392346463770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346463770 : ¬ IsSelfInterpreter e2392346463770 :=
  wSource (t := t_e2392346463770) (replay_sound (ps := []) (t := e2392346463770) (by decide)) (by decide)
def e2392346472646 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392346472646 : Closed e2392346472646 ∧ code e2392346472646 = 11188439494854 := by decide
theorem cert_e2392346472646 : check e2392346472646 [[]] .width = true := by decide
def e2392346485274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346485274 : Closed e2392346485274 ∧ code e2392346485274 = 11188439507482 := by decide
private def t_e2392346485274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346485274 : ¬ IsSelfInterpreter e2392346485274 :=
  wSource (t := t_e2392346485274) (replay_sound (ps := []) (t := e2392346485274) (by decide)) (by decide)
def e2392346486810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392346486810 : Closed e2392346486810 ∧ code e2392346486810 = 11188439509018 := by decide
theorem cert_e2392346486810 : check e2392346486810 [[]] .width = true := by decide
def e2392346488346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346488346 : Closed e2392346488346 ∧ code e2392346488346 = 11188439510554 := by decide
private def t_e2392346488346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346488346 : ¬ IsSelfInterpreter e2392346488346 :=
  wSource (t := t_e2392346488346) (replay_sound (ps := []) (t := e2392346488346) (by decide)) (by decide)
def e2392346491418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346491418 : Closed e2392346491418 ∧ code e2392346491418 = 11188439513626 := by decide
private def t_e2392346491418 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346491418 : ¬ IsSelfInterpreter e2392346491418 :=
  wSource (t := t_e2392346491418) (replay_sound (ps := []) (t := e2392346491418) (by decide)) (by decide)
def e2392346492954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392346492954 : Closed e2392346492954 ∧ code e2392346492954 = 11188439515162 := by decide
theorem cert_e2392346492954 : check e2392346492954 [[]] .width = true := by decide
def e2392346493046 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392346493046 : Closed e2392346493046 ∧ code e2392346493046 = 11188439515254 := by decide
theorem cert_e2392346493046 : check e2392346493046 [[]] .width = true := by decide
def e2392346493290 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392346493290 : Closed e2392346493290 ∧ code e2392346493290 = 11188439515498 := by decide
theorem cert_e2392346493290 : check e2392346493290 [[]] .width = true := by decide
def e2392346493338 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392346493338 : Closed e2392346493338 ∧ code e2392346493338 = 11188439515546 := by decide
theorem cert_e2392346493338 : check e2392346493338 [[]] .width = true := by decide
def e2392346494346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392346494346 : Closed e2392346494346 ∧ code e2392346494346 = 11188439516554 := by decide
theorem cert_e2392346494346 : check e2392346494346 [[]] .width = true := by decide
def e2392346494370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392346494370 : Closed e2392346494370 ∧ code e2392346494370 = 11188439516578 := by decide
private def t_e2392346494370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392346494370 : ¬ IsSelfInterpreter e2392346494370 :=
  wSource (t := t_e2392346494370) (replay_sound (ps := []) (t := e2392346494370) (by decide)) (by decide)
def e2392346494478 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392346494478 : Closed e2392346494478 ∧ code e2392346494478 = 11188439516686 := by decide
theorem cert_e2392346494478 : check e2392346494478 [[]] .width = true := by decide
def e2392346494490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392346494490 : Closed e2392346494490 ∧ code e2392346494490 = 11188439516698 := by decide
private def t_e2392346494490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392346494490 : ¬ IsSelfInterpreter e2392346494490 :=
  wSource (t := t_e2392346494490) (replay_sound (ps := []) (t := e2392346494490) (by decide)) (by decide)
def e2392346494562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392346494562 : Closed e2392346494562 ∧ code e2392346494562 = 11188439516770 := by decide
theorem cert_e2392346494562 : check e2392346494562 [[]] .width = true := by decide
def e2392346539546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346539546 : Closed e2392346539546 ∧ code e2392346539546 = 11188439561754 := by decide
private def t_e2392346539546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346539546 : ¬ IsSelfInterpreter e2392346539546 :=
  wSource (t := t_e2392346539546) (replay_sound (ps := []) (t := e2392346539546) (by decide)) (by decide)
def e2392346540570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392346540570 : Closed e2392346540570 ∧ code e2392346540570 = 11188439562778 := by decide
private def t_e2392346540570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392346540570 : ¬ IsSelfInterpreter e2392346540570 :=
  wSource (t := t_e2392346540570) (replay_sound (ps := []) (t := e2392346540570) (by decide)) (by decide)
def e2392347864602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347864602 : Closed e2392347864602 ∧ code e2392347864602 = 11188440886810 := by decide
private def t_e2392347864602 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347864602 : ¬ IsSelfInterpreter e2392347864602 :=
  wSource (t := t_e2392347864602) (replay_sound (ps := []) (t := e2392347864602) (by decide)) (by decide)
def e2392347866650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347866650 : Closed e2392347866650 ∧ code e2392347866650 = 11188440888858 := by decide
private def t_e2392347866650 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347866650 : ¬ IsSelfInterpreter e2392347866650 :=
  wSource (t := t_e2392347866650) (replay_sound (ps := []) (t := e2392347866650) (by decide)) (by decide)
def e2392347880986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347880986 : Closed e2392347880986 ∧ code e2392347880986 = 11188440903194 := by decide
private def t_e2392347880986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347880986 : ¬ IsSelfInterpreter e2392347880986 :=
  wSource (t := t_e2392347880986) (replay_sound (ps := []) (t := e2392347880986) (by decide)) (by decide)
def e2392347884058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347884058 : Closed e2392347884058 ∧ code e2392347884058 = 11188440906266 := by decide
private def t_e2392347884058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347884058 : ¬ IsSelfInterpreter e2392347884058 :=
  wSource (t := t_e2392347884058) (replay_sound (ps := []) (t := e2392347884058) (by decide)) (by decide)
def e2392347891226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347891226 : Closed e2392347891226 ∧ code e2392347891226 = 11188440913434 := by decide
private def t_e2392347891226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347891226 : ¬ IsSelfInterpreter e2392347891226 :=
  wSource (t := t_e2392347891226) (replay_sound (ps := []) (t := e2392347891226) (by decide)) (by decide)
def e2392347892250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347892250 : Closed e2392347892250 ∧ code e2392347892250 = 11188440914458 := by decide
private def t_e2392347892250 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347892250 : ¬ IsSelfInterpreter e2392347892250 :=
  wSource (t := t_e2392347892250) (replay_sound (ps := []) (t := e2392347892250) (by decide)) (by decide)
def e2392347962906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347962906 : Closed e2392347962906 ∧ code e2392347962906 = 11188440985114 := by decide
private def t_e2392347962906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347962906 : ¬ IsSelfInterpreter e2392347962906 :=
  wSource (t := t_e2392347962906) (replay_sound (ps := []) (t := e2392347962906) (by decide)) (by decide)
def e2392347964954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392347964954 : Closed e2392347964954 ∧ code e2392347964954 = 11188440987162 := by decide
private def t_e2392347964954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392347964954 : ¬ IsSelfInterpreter e2392347964954 :=
  wSource (t := t_e2392347964954) (replay_sound (ps := []) (t := e2392347964954) (by decide)) (by decide)
def e2392348061210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392348061210 : Closed e2392348061210 ∧ code e2392348061210 = 11188441083418 := by decide
private def t_e2392348061210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392348061210 : ¬ IsSelfInterpreter e2392348061210 :=
  wSource (t := t_e2392348061210) (replay_sound (ps := []) (t := e2392348061210) (by decide)) (by decide)
def e2392348064282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392348064282 : Closed e2392348064282 ∧ code e2392348064282 = 11188441086490 := by decide
private def t_e2392348064282 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392348064282 : ¬ IsSelfInterpreter e2392348064282 :=
  wSource (t := t_e2392348064282) (replay_sound (ps := []) (t := e2392348064282) (by decide)) (by decide)
def e2392348112410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392348112410 : Closed e2392348112410 ∧ code e2392348112410 = 11188441134618 := by decide
private def t_e2392348112410 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392348112410 : ¬ IsSelfInterpreter e2392348112410 :=
  wSource (t := t_e2392348112410) (replay_sound (ps := []) (t := e2392348112410) (by decide)) (by decide)
def e2392348113434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392348113434 : Closed e2392348113434 ∧ code e2392348113434 = 11188441135642 := by decide
private def t_e2392348113434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392348113434 : ¬ IsSelfInterpreter e2392348113434 :=
  wSource (t := t_e2392348113434) (replay_sound (ps := []) (t := e2392348113434) (by decide)) (by decide)
def e2392348129306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392348129306 : Closed e2392348129306 ∧ code e2392348129306 = 11188441151514 := by decide
theorem cert_e2392348129306 : check e2392348129306 [[]] .width = true := by decide
def e2392348145690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392348145690 : Closed e2392348145690 ∧ code e2392348145690 = 11188441167898 := by decide
theorem cert_e2392348145690 : check e2392348145690 [[]] .width = true := by decide
def e2392350111770 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350111770 : Closed e2392350111770 ∧ code e2392350111770 = 11188443133978 := by decide
theorem cert_e2392350111770 : check e2392350111770 [[]] .width = true := by decide
def e2392350119962 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350119962 : Closed e2392350119962 ∧ code e2392350119962 = 11188443142170 := by decide
theorem cert_e2392350119962 : check e2392350119962 [[]] .width = true := by decide
def e2392350141978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350141978 : Closed e2392350141978 ∧ code e2392350141978 = 11188443164186 := by decide
private def t_e2392350141978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350141978 : ¬ IsSelfInterpreter e2392350141978 :=
  wSource (t := t_e2392350141978) (replay_sound (ps := []) (t := e2392350141978) (by decide)) (by decide)
def e2392350177306 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350177306 : Closed e2392350177306 ∧ code e2392350177306 = 11188443199514 := by decide
theorem cert_e2392350177306 : check e2392350177306 [[]] .width = true := by decide
def e2392350188058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350188058 : Closed e2392350188058 ∧ code e2392350188058 = 11188443210266 := by decide
private def t_e2392350188058 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350188058 : ¬ IsSelfInterpreter e2392350188058 :=
  wSource (t := t_e2392350188058) (replay_sound (ps := []) (t := e2392350188058) (by decide)) (by decide)
def e2392350189594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350189594 : Closed e2392350189594 ∧ code e2392350189594 = 11188443211802 := by decide
theorem cert_e2392350189594 : check e2392350189594 [[]] .width = true := by decide
def e2392350191130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350191130 : Closed e2392350191130 ∧ code e2392350191130 = 11188443213338 := by decide
private def t_e2392350191130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350191130 : ¬ IsSelfInterpreter e2392350191130 :=
  wSource (t := t_e2392350191130) (replay_sound (ps := []) (t := e2392350191130) (by decide)) (by decide)
def e2392350201370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350201370 : Closed e2392350201370 ∧ code e2392350201370 = 11188443223578 := by decide
private def t_e2392350201370 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350201370 : ¬ IsSelfInterpreter e2392350201370 :=
  wSource (t := t_e2392350201370) (replay_sound (ps := []) (t := e2392350201370) (by decide)) (by decide)
def e2392350218266 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350218266 : Closed e2392350218266 ∧ code e2392350218266 = 11188443240474 := by decide
theorem cert_e2392350218266 : check e2392350218266 [[]] .width = true := by decide
def e2392350220826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350220826 : Closed e2392350220826 ∧ code e2392350220826 = 11188443243034 := by decide
private def t_e2392350220826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350220826 : ¬ IsSelfInterpreter e2392350220826 :=
  wSource (t := t_e2392350220826) (replay_sound (ps := []) (t := e2392350220826) (by decide)) (by decide)
def e2392350222362 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350222362 : Closed e2392350222362 ∧ code e2392350222362 = 11188443244570 := by decide
theorem cert_e2392350222362 : check e2392350222362 [[]] .width = true := by decide
def e2392350223898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350223898 : Closed e2392350223898 ∧ code e2392350223898 = 11188443246106 := by decide
private def t_e2392350223898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350223898 : ¬ IsSelfInterpreter e2392350223898 :=
  wSource (t := t_e2392350223898) (replay_sound (ps := []) (t := e2392350223898) (by decide)) (by decide)
def e2392350225946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350225946 : Closed e2392350225946 ∧ code e2392350225946 = 11188443248154 := by decide
private def t_e2392350225946 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350225946 : ¬ IsSelfInterpreter e2392350225946 :=
  wSource (t := t_e2392350225946) (replay_sound (ps := []) (t := e2392350225946) (by decide)) (by decide)
def e2392350504986 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350504986 : Closed e2392350504986 ∧ code e2392350504986 = 11188443527194 := by decide
theorem cert_e2392350504986 : check e2392350504986 [[]] .width = true := by decide
def e2392350513178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350513178 : Closed e2392350513178 ∧ code e2392350513178 = 11188443535386 := by decide
theorem cert_e2392350513178 : check e2392350513178 [[]] .width = true := by decide
def e2392350801434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350801434 : Closed e2392350801434 ∧ code e2392350801434 = 11188443823642 := by decide
private def t_e2392350801434 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350801434 : ¬ IsSelfInterpreter e2392350801434 :=
  wSource (t := t_e2392350801434) (replay_sound (ps := []) (t := e2392350801434) (by decide)) (by decide)
def e2392350847174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392350847174 : Closed e2392350847174 ∧ code e2392350847174 = 11188443869382 := by decide
theorem cert_e2392350847174 : check e2392350847174 [[]] .width = true := by decide
def e2392350898202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350898202 : Closed e2392350898202 ∧ code e2392350898202 = 11188443920410 := by decide
theorem cert_e2392350898202 : check e2392350898202 [[]] .width = true := by decide
def e2392350908954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350908954 : Closed e2392350908954 ∧ code e2392350908954 = 11188443931162 := by decide
private def t_e2392350908954 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350908954 : ¬ IsSelfInterpreter e2392350908954 :=
  wSource (t := t_e2392350908954) (replay_sound (ps := []) (t := e2392350908954) (by decide)) (by decide)
def e2392350910490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392350910490 : Closed e2392350910490 ∧ code e2392350910490 = 11188443932698 := by decide
theorem cert_e2392350910490 : check e2392350910490 [[]] .width = true := by decide
def e2392350912026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392350912026 : Closed e2392350912026 ∧ code e2392350912026 = 11188443934234 := by decide
private def t_e2392350912026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392350912026 : ¬ IsSelfInterpreter e2392350912026 :=
  wSource (t := t_e2392350912026) (replay_sound (ps := []) (t := e2392350912026) (by decide)) (by decide)
def e2392351014938 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392351014938 : Closed e2392351014938 ∧ code e2392351014938 = 11188444037146 := by decide
theorem cert_e2392351014938 : check e2392351014938 [[]] .width = true := by decide
def e2392351015030 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392351015030 : Closed e2392351015030 ∧ code e2392351015030 = 11188444037238 := by decide
theorem cert_e2392351015030 : check e2392351015030 [[]] .width = true := by decide
def e2392351015274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392351015274 : Closed e2392351015274 ∧ code e2392351015274 = 11188444037482 := by decide
theorem cert_e2392351015274 : check e2392351015274 [[]] .width = true := by decide
def e2392351015322 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392351015322 : Closed e2392351015322 ∧ code e2392351015322 = 11188444037530 := by decide
theorem cert_e2392351015322 : check e2392351015322 [[]] .width = true := by decide
def e2392351016330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392351016330 : Closed e2392351016330 ∧ code e2392351016330 = 11188444038538 := by decide
theorem cert_e2392351016330 : check e2392351016330 [[]] .width = true := by decide
def e2392351016354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392351016354 : Closed e2392351016354 ∧ code e2392351016354 = 11188444038562 := by decide
private def t_e2392351016354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392351016354 : ¬ IsSelfInterpreter e2392351016354 :=
  wSource (t := t_e2392351016354) (replay_sound (ps := []) (t := e2392351016354) (by decide)) (by decide)
def e2392351016462 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392351016462 : Closed e2392351016462 ∧ code e2392351016462 = 11188444038670 := by decide
theorem cert_e2392351016462 : check e2392351016462 [[]] .width = true := by decide
def e2392351016474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392351016474 : Closed e2392351016474 ∧ code e2392351016474 = 11188444038682 := by decide
private def t_e2392351016474 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392351016474 : ¬ IsSelfInterpreter e2392351016474 :=
  wSource (t := t_e2392351016474) (replay_sound (ps := []) (t := e2392351016474) (by decide)) (by decide)
def e2392351016546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392351016546 : Closed e2392351016546 ∧ code e2392351016546 = 11188444038754 := by decide
theorem cert_e2392351016546 : check e2392351016546 [[]] .width = true := by decide
def e2392351055386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392351055386 : Closed e2392351055386 ∧ code e2392351055386 = 11188444077594 := by decide
private def t_e2392351055386 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392351055386 : ¬ IsSelfInterpreter e2392351055386 :=
  wSource (t := t_e2392351055386) (replay_sound (ps := []) (t := e2392351055386) (by decide)) (by decide)
def e2392351076550 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.lam (.var 1)))))
theorem wire_e2392351076550 : Closed e2392351076550 ∧ code e2392351076550 = 11188444098758 := by decide
theorem cert_e2392351076550 : check e2392351076550 [[]] .width = true := by decide
def e2392351103002 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392351103002 : Closed e2392351103002 ∧ code e2392351103002 = 11188444125210 := by decide
theorem cert_e2392351103002 : check e2392351103002 [[]] .width = true := by decide
def e2392351105562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392351105562 : Closed e2392351105562 ∧ code e2392351105562 = 11188444127770 := by decide
private def t_e2392351105562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392351105562 : ¬ IsSelfInterpreter e2392351105562 :=
  wSource (t := t_e2392351105562) (replay_sound (ps := []) (t := e2392351105562) (by decide)) (by decide)
def e2392351107098 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392351107098 : Closed e2392351107098 ∧ code e2392351107098 = 11188444129306 := by decide
theorem cert_e2392351107098 : check e2392351107098 [[]] .width = true := by decide
def e2392351108634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392351108634 : Closed e2392351108634 ∧ code e2392351108634 = 11188444130842 := by decide
private def t_e2392351108634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392351108634 : ¬ IsSelfInterpreter e2392351108634 :=
  wSource (t := t_e2392351108634) (replay_sound (ps := []) (t := e2392351108634) (by decide)) (by decide)
def e2392351110682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392351110682 : Closed e2392351110682 ∧ code e2392351110682 = 11188444132890 := by decide
private def t_e2392351110682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392351110682 : ¬ IsSelfInterpreter e2392351110682 :=
  wSource (t := t_e2392351110682) (replay_sound (ps := []) (t := e2392351110682) (by decide)) (by decide)
def e2392351146010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e2392351146010 : Closed e2392351146010 ∧ code e2392351146010 = 11188444168218 := by decide
theorem cert_e2392351146010 : check e2392351146010 [[]] .width = true := by decide
def e2392351146102 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e2392351146102 : Closed e2392351146102 ∧ code e2392351146102 = 11188444168310 := by decide
theorem cert_e2392351146102 : check e2392351146102 [[]] .width = true := by decide
def e2392351146346 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e2392351146346 : Closed e2392351146346 ∧ code e2392351146346 = 11188444168554 := by decide
theorem cert_e2392351146346 : check e2392351146346 [[]] .width = true := by decide
def e2392351146394 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e2392351146394 : Closed e2392351146394 ∧ code e2392351146394 = 11188444168602 := by decide
theorem cert_e2392351146394 : check e2392351146394 [[]] .width = true := by decide
def e2392351147402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.lam (.var 0))) (.var 0))))
theorem wire_e2392351147402 : Closed e2392351147402 ∧ code e2392351147402 = 11188444169610 := by decide
theorem cert_e2392351147402 : check e2392351147402 [[]] .width = true := by decide
def e2392351147426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem wire_e2392351147426 : Closed e2392351147426 ∧ code e2392351147426 = 11188444169634 := by decide
private def t_e2392351147426 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))))
theorem cert_e2392351147426 : ¬ IsSelfInterpreter e2392351147426 :=
  wSource (t := t_e2392351147426) (replay_sound (ps := []) (t := e2392351147426) (by decide)) (by decide)
def e2392351147534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.var 2))))))
theorem wire_e2392351147534 : Closed e2392351147534 ∧ code e2392351147534 = 11188444169742 := by decide
theorem cert_e2392351147534 : check e2392351147534 [[]] .width = true := by decide
def e2392351147546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e2392351147546 : Closed e2392351147546 ∧ code e2392351147546 = 11188444169754 := by decide
private def t_e2392351147546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem cert_e2392351147546 : ¬ IsSelfInterpreter e2392351147546 :=
  wSource (t := t_e2392351147546) (replay_sound (ps := []) (t := e2392351147546) (by decide)) (by decide)
def e2392351147618 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.var 0))))))
theorem wire_e2392351147618 : Closed e2392351147618 ∧ code e2392351147618 = 11188444169826 := by decide
theorem cert_e2392351147618 : check e2392351147618 [[]] .width = true := by decide
def e2392355993626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392355993626 : Closed e2392355993626 ∧ code e2392355993626 = 11188449015834 := by decide
theorem cert_e2392355993626 : check e2392355993626 [[]] .width = true := by decide
def e2392356018202 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392356018202 : Closed e2392356018202 ∧ code e2392356018202 = 11188449040410 := by decide
theorem cert_e2392356018202 : check e2392356018202 [[]] .width = true := by decide
def e2392356957722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2392356957722 : Closed e2392356957722 ∧ code e2392356957722 = 11188449979930 := by decide
private def t_e2392356957722 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2392356957722 : ¬ IsSelfInterpreter e2392356957722 :=
  wSource (t := t_e2392356957722) (replay_sound (ps := []) (t := e2392356957722) (by decide)) (by decide)
def e2392356993050 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2392356993050 : Closed e2392356993050 ∧ code e2392356993050 = 11188450015258 := by decide
theorem cert_e2392356993050 : check e2392356993050 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2392345265690
#print axioms Blc.Floor43.cert_e2392345423386
#print axioms Blc.Floor43.cert_e2392345469466
#print axioms Blc.Floor43.cert_e2392345472538
#print axioms Blc.Floor43.cert_e2392345512474
#print axioms Blc.Floor43.cert_e2392345518618
#print axioms Blc.Floor43.cert_e2392345521690
#print axioms Blc.Floor43.cert_e2392345524762
#print axioms Blc.Floor43.cert_e2392345558554
#print axioms Blc.Floor43.cert_e2392345666074
#print axioms Blc.Floor43.cert_e2392345669146
#print axioms Blc.Floor43.cert_e2392345773474
#print axioms Blc.Floor43.cert_e2392345773594
#print axioms Blc.Floor43.cert_e2392345939482
#print axioms Blc.Floor43.cert_e2392345960986
#print axioms Blc.Floor43.cert_e2392345964058
#print axioms Blc.Floor43.cert_e2392345967130
#print axioms Blc.Floor43.cert_e2392345970082
#print axioms Blc.Floor43.cert_e2392345970202
#print axioms Blc.Floor43.cert_e2392346097178
#print axioms Blc.Floor43.cert_e2392346098202
#print axioms Blc.Floor43.cert_e2392346146330
#print axioms Blc.Floor43.cert_e2392346147354
#print axioms Blc.Floor43.cert_e2392346168858
#print axioms Blc.Floor43.cert_e2392346183194
#print axioms Blc.Floor43.cert_e2392346269210
#print axioms Blc.Floor43.cert_e2392346288666
#print axioms Blc.Floor43.cert_e2392346291738
#print axioms Blc.Floor43.cert_e2392346293786
#print axioms Blc.Floor43.cert_e2392346298906
#print axioms Blc.Floor43.cert_e2392346305050
#print axioms Blc.Floor43.cert_e2392346308122
#print axioms Blc.Floor43.cert_e2392346311194
#print axioms Blc.Floor43.cert_e2392346318362
#print axioms Blc.Floor43.cert_e2392346319386
#print axioms Blc.Floor43.cert_e2392346336794
#print axioms Blc.Floor43.cert_e2392346386970
#print axioms Blc.Floor43.cert_e2392346390042
#print axioms Blc.Floor43.cert_e2392346392090
#print axioms Blc.Floor43.cert_e2392346428834
#print axioms Blc.Floor43.cert_e2392346428954
#print axioms Blc.Floor43.cert_e2392346463770
#print axioms Blc.Floor43.cert_e2392346485274
#print axioms Blc.Floor43.cert_e2392346488346
#print axioms Blc.Floor43.cert_e2392346491418
#print axioms Blc.Floor43.cert_e2392346494370
#print axioms Blc.Floor43.cert_e2392346494490
#print axioms Blc.Floor43.cert_e2392346539546
#print axioms Blc.Floor43.cert_e2392346540570
#print axioms Blc.Floor43.cert_e2392347864602
#print axioms Blc.Floor43.cert_e2392347866650
#print axioms Blc.Floor43.cert_e2392347880986
#print axioms Blc.Floor43.cert_e2392347884058
#print axioms Blc.Floor43.cert_e2392347891226
#print axioms Blc.Floor43.cert_e2392347892250
#print axioms Blc.Floor43.cert_e2392347962906
#print axioms Blc.Floor43.cert_e2392347964954
#print axioms Blc.Floor43.cert_e2392348061210
#print axioms Blc.Floor43.cert_e2392348064282
#print axioms Blc.Floor43.cert_e2392348112410
#print axioms Blc.Floor43.cert_e2392348113434
#print axioms Blc.Floor43.cert_e2392350141978
#print axioms Blc.Floor43.cert_e2392350188058
#print axioms Blc.Floor43.cert_e2392350191130
#print axioms Blc.Floor43.cert_e2392350201370
#print axioms Blc.Floor43.cert_e2392350220826
#print axioms Blc.Floor43.cert_e2392350223898
#print axioms Blc.Floor43.cert_e2392350225946
#print axioms Blc.Floor43.cert_e2392350801434
#print axioms Blc.Floor43.cert_e2392350908954
#print axioms Blc.Floor43.cert_e2392350912026
#print axioms Blc.Floor43.cert_e2392351016354
#print axioms Blc.Floor43.cert_e2392351016474
#print axioms Blc.Floor43.cert_e2392351055386
#print axioms Blc.Floor43.cert_e2392351105562
#print axioms Blc.Floor43.cert_e2392351108634
#print axioms Blc.Floor43.cert_e2392351110682
#print axioms Blc.Floor43.cert_e2392351147426
#print axioms Blc.Floor43.cert_e2392351147546
#print axioms Blc.Floor43.cert_e2392356957722
