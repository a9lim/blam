import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2419190854894 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2419190854894 : Closed e2419190854894 ∧ code e2419190854894 = 11215283877102 := by decide
def e2419190854902 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2419190854902 : Closed e2419190854902 ∧ code e2419190854902 = 11215283877110 := by decide
def e2419190855182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem wire_e2419190855182 : Closed e2419190855182 ∧ code e2419190855182 = 11215283877390 := by decide
private def t_e2419190855182 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.lam (.var 2)))))))))
theorem cert_e2419190855182 : ¬ IsSelfInterpreter e2419190855182 :=
  wSource (t := t_e2419190855182) (replay_sound (ps := []) (t := e2419190855182) (by decide)) (by decide)
def e2419190855266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2419190855266 : Closed e2419190855266 ∧ code e2419190855266 = 11215283877474 := by decide
private def t_e2419190855266 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 0)))))))))
theorem cert_e2419190855266 : ¬ IsSelfInterpreter e2419190855266 :=
  wSource (t := t_e2419190855266) (replay_sound (ps := []) (t := e2419190855266) (by decide)) (by decide)
def e2419190855278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2419190855278 : Closed e2419190855278 ∧ code e2419190855278 = 11215283877486 := by decide
private def t_e2419190855278 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem cert_e2419190855278 : ¬ IsSelfInterpreter e2419190855278 :=
  wSource (t := t_e2419190855278) (replay_sound (ps := []) (t := e2419190855278) (by decide)) (by decide)
def e2419190855290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2419190855290 : Closed e2419190855290 ∧ code e2419190855290 = 11215283877498 := by decide
private def t_e2419190855290 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem cert_e2419190855290 : ¬ IsSelfInterpreter e2419190855290 :=
  wSource (t := t_e2419190855290) (replay_sound (ps := []) (t := e2419190855290) (by decide)) (by decide)
def e2419190855478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2419190855478 : Closed e2419190855478 ∧ code e2419190855478 = 11215283877686 := by decide
private def t_e2419190855478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem cert_e2419190855478 : ¬ IsSelfInterpreter e2419190855478 :=
  wSource (t := t_e2419190855478) (replay_sound (ps := []) (t := e2419190855478) (by decide)) (by decide)
def e2419190855482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2419190855482 : Closed e2419190855482 ∧ code e2419190855482 = 11215283877690 := by decide
private def t_e2419190855482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem cert_e2419190855482 : ¬ IsSelfInterpreter e2419190855482 :=
  wSource (t := t_e2419190855482) (replay_sound (ps := []) (t := e2419190855482) (by decide)) (by decide)
def e2419190860654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419190860654 : Closed e2419190860654 ∧ code e2419190860654 = 11215283882862 := by decide
theorem cert_e2419190860654 : check e2419190860654 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190860662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419190860662 : Closed e2419190860662 ∧ code e2419190860662 = 11215283882870 := by decide
theorem cert_e2419190860662 : check e2419190860662 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190860718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419190860718 : Closed e2419190860718 ∧ code e2419190860718 = 11215283882926 := by decide
theorem cert_e2419190860718 : check e2419190860718 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190860730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419190860730 : Closed e2419190860730 ∧ code e2419190860730 = 11215283882938 := by decide
theorem cert_e2419190860730 : check e2419190860730 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190860758 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419190860758 : Closed e2419190860758 ∧ code e2419190860758 = 11215283882966 := by decide
theorem cert_e2419190860758 : check e2419190860758 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190860762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419190860762 : Closed e2419190860762 ∧ code e2419190860762 = 11215283882970 := by decide
theorem cert_e2419190860762 : check e2419190860762 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190861038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419190861038 : Closed e2419190861038 ∧ code e2419190861038 = 11215283883246 := by decide
theorem cert_e2419190861038 : check e2419190861038 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190861046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419190861046 : Closed e2419190861046 ∧ code e2419190861046 = 11215283883254 := by decide
theorem cert_e2419190861046 : check e2419190861046 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190861422 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419190861422 : Closed e2419190861422 ∧ code e2419190861422 = 11215283883630 := by decide
theorem cert_e2419190861422 : check e2419190861422 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190861434 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419190861434 : Closed e2419190861434 ∧ code e2419190861434 = 11215283883642 := by decide
theorem cert_e2419190861434 : check e2419190861434 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190861622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419190861622 : Closed e2419190861622 ∧ code e2419190861622 = 11215283883830 := by decide
theorem cert_e2419190861622 : check e2419190861622 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190861626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419190861626 : Closed e2419190861626 ∧ code e2419190861626 = 11215283883834 := by decide
theorem cert_e2419190861626 : check e2419190861626 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190869550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2419190869550 : Closed e2419190869550 ∧ code e2419190869550 = 11215283891758 := by decide
theorem cert_e2419190869550 : check e2419190869550 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190869730 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2419190869730 : Closed e2419190869730 ∧ code e2419190869730 = 11215283891938 := by decide
theorem cert_e2419190869730 : check e2419190869730 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190869742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 2))))))))
theorem wire_e2419190869742 : Closed e2419190869742 ∧ code e2419190869742 = 11215283891950 := by decide
theorem cert_e2419190869742 : check e2419190869742 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190869782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2419190869782 : Closed e2419190869782 ∧ code e2419190869782 = 11215283891990 := by decide
theorem cert_e2419190869782 : check e2419190869782 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190869858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2419190869858 : Closed e2419190869858 ∧ code e2419190869858 = 11215283892066 := by decide
theorem cert_e2419190869858 : check e2419190869858 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190869870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 2))))))))
theorem wire_e2419190869870 : Closed e2419190869870 ∧ code e2419190869870 = 11215283892078 := by decide
theorem cert_e2419190869870 : check e2419190869870 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190869878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 2)) (.var 1))))))))
theorem wire_e2419190869878 : Closed e2419190869878 ∧ code e2419190869878 = 11215283892086 := by decide
theorem cert_e2419190869878 : check e2419190869878 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190872126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 4))))))))))
theorem wire_e2419190872126 : Closed e2419190872126 ∧ code e2419190872126 = 11215283894334 := by decide
theorem cert_e2419190872126 : check e2419190872126 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190872546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2419190872546 : Closed e2419190872546 ∧ code e2419190872546 = 11215283894754 := by decide
theorem cert_e2419190872546 : check e2419190872546 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190872558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419190872558 : Closed e2419190872558 ∧ code e2419190872558 = 11215283894766 := by decide
theorem cert_e2419190872558 : check e2419190872558 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190873118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.lam (.var 3))))))))))
theorem wire_e2419190873118 : Closed e2419190873118 ∧ code e2419190873118 = 11215283895326 := by decide
theorem cert_e2419190873118 : check e2419190873118 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190873314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2419190873314 : Closed e2419190873314 ∧ code e2419190873314 = 11215283895522 := by decide
theorem cert_e2419190873314 : check e2419190873314 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190873326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419190873326 : Closed e2419190873326 ∧ code e2419190873326 = 11215283895534 := by decide
theorem cert_e2419190873326 : check e2419190873326 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190873334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419190873334 : Closed e2419190873334 ∧ code e2419190873334 = 11215283895542 := by decide
theorem cert_e2419190873334 : check e2419190873334 [[],[],[.left],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419190896174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2419190896174 : Closed e2419190896174 ∧ code e2419190896174 = 11215283918382 := by decide
theorem cert_e2419190896174 : check e2419190896174 [[],[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2419190896354 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2419190896354 : Closed e2419190896354 ∧ code e2419190896354 = 11215283918562 := by decide
theorem cert_e2419190896354 : check e2419190896354 [[],[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2419190896366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2419190896366 : Closed e2419190896366 ∧ code e2419190896366 = 11215283918574 := by decide
def e2419190896522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419190896522 : Closed e2419190896522 ∧ code e2419190896522 = 11215283918730 := by decide
theorem cert_e2419190896522 : check e2419190896522 [[],[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2419190896546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419190896546 : Closed e2419190896546 ∧ code e2419190896546 = 11215283918754 := by decide
theorem cert_e2419190896546 : check e2419190896546 [[],[],[.left],[.left],[.left],[],[],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.left,.left],[.under,.left]] .sourceHead = true := by decide
def e2419190896558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2419190896558 : Closed e2419190896558 ∧ code e2419190896558 = 11215283918766 := by decide
def e2419190896570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2419190896570 : Closed e2419190896570 ∧ code e2419190896570 = 11215283918778 := by decide
private def t_e2419190896570 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem cert_e2419190896570 : ¬ IsSelfInterpreter e2419190896570 :=
  wSource (t := t_e2419190896570) (replay_sound (ps := []) (t := e2419190896570) (by decide)) (by decide)
def e2419190896702 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2419190896702 : Closed e2419190896702 ∧ code e2419190896702 = 11215283918910 := by decide
theorem cert_e2419190896702 : check e2419190896702 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under],[.under]] .smaller = true := by decide
def e2419190897122 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2419190897122 : Closed e2419190897122 ∧ code e2419190897122 = 11215283919330 := by decide
theorem cert_e2419190897122 : check e2419190897122 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2419190897134 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419190897134 : Closed e2419190897134 ∧ code e2419190897134 = 11215283919342 := by decide
theorem cert_e2419190897134 : check e2419190897134 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2419190898190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2419190898190 : Closed e2419190898190 ∧ code e2419190898190 = 11215283920398 := by decide
theorem cert_e2419190898190 : check e2419190898190 [[],[],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under]] .three = true := by decide
def e2419190898274 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419190898274 : Closed e2419190898274 ∧ code e2419190898274 = 11215283920482 := by decide
def e2419190898286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419190898286 : Closed e2419190898286 ∧ code e2419190898286 = 11215283920494 := by decide
def e2419190898298 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419190898298 : Closed e2419190898298 ∧ code e2419190898298 = 11215283920506 := by decide
def e2419190909718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2419190909718 : Closed e2419190909718 ∧ code e2419190909718 = 11215283931926 := by decide
def e2419190909794 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2419190909794 : Closed e2419190909794 ∧ code e2419190909794 = 11215283932002 := by decide
def e2419190909806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2419190909806 : Closed e2419190909806 ∧ code e2419190909806 = 11215283932014 := by decide
def e2419190909814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2419190909814 : Closed e2419190909814 ∧ code e2419190909814 = 11215283932022 := by decide
def e2419190909834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2419190909834 : Closed e2419190909834 ∧ code e2419190909834 = 11215283932042 := by decide
def e2419190909858 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2419190909858 : Closed e2419190909858 ∧ code e2419190909858 = 11215283932066 := by decide
def e2419190909870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2419190909870 : Closed e2419190909870 ∧ code e2419190909870 = 11215283932078 := by decide
def e2419190909882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2419190909882 : Closed e2419190909882 ∧ code e2419190909882 = 11215283932090 := by decide
private def t_e2419190909882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem cert_e2419190909882 : ¬ IsSelfInterpreter e2419190909882 :=
  wSource (t := t_e2419190909882) (replay_sound (ps := []) (t := e2419190909882) (by decide)) (by decide)
def e2419190909910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2419190909910 : Closed e2419190909910 ∧ code e2419190909910 = 11215283932118 := by decide
def e2419190909914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2419190909914 : Closed e2419190909914 ∧ code e2419190909914 = 11215283932122 := by decide
private def t_e2419190909914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem cert_e2419190909914 : ¬ IsSelfInterpreter e2419190909914 :=
  wSource (t := t_e2419190909914) (replay_sound (ps := []) (t := e2419190909914) (by decide)) (by decide)
def e2419190909982 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2419190909982 : Closed e2419190909982 ∧ code e2419190909982 = 11215283932190 := by decide
def e2419190910178 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2419190910178 : Closed e2419190910178 ∧ code e2419190910178 = 11215283932386 := by decide
def e2419190910190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419190910190 : Closed e2419190910190 ∧ code e2419190910190 = 11215283932398 := by decide
def e2419190910198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419190910198 : Closed e2419190910198 ∧ code e2419190910198 = 11215283932406 := by decide
def e2419190910478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2419190910478 : Closed e2419190910478 ∧ code e2419190910478 = 11215283932686 := by decide
def e2419190910562 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2419190910562 : Closed e2419190910562 ∧ code e2419190910562 = 11215283932770 := by decide
def e2419190910574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419190910574 : Closed e2419190910574 ∧ code e2419190910574 = 11215283932782 := by decide
def e2419190910586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419190910586 : Closed e2419190910586 ∧ code e2419190910586 = 11215283932794 := by decide
def e2419190910774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419190910774 : Closed e2419190910774 ∧ code e2419190910774 = 11215283932982 := by decide
def e2419190910778 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419190910778 : Closed e2419190910778 ∧ code e2419190910778 = 11215283932986 := by decide
def e2419191450478 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419191450478 : Closed e2419191450478 ∧ code e2419191450478 = 11215284472686 := by decide
def e2419191450486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419191450486 : Closed e2419191450486 ∧ code e2419191450486 = 11215284472694 := by decide
def e2419191450542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419191450542 : Closed e2419191450542 ∧ code e2419191450542 = 11215284472750 := by decide
def e2419191450554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419191450554 : Closed e2419191450554 ∧ code e2419191450554 = 11215284472762 := by decide
private def t_e2419191450554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem cert_e2419191450554 : ¬ IsSelfInterpreter e2419191450554 :=
  wSource (t := t_e2419191450554) (replay_sound (ps := []) (t := e2419191450554) (by decide)) (by decide)
def e2419191450582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419191450582 : Closed e2419191450582 ∧ code e2419191450582 = 11215284472790 := by decide
def e2419191450586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419191450586 : Closed e2419191450586 ∧ code e2419191450586 = 11215284472794 := by decide
private def t_e2419191450586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem cert_e2419191450586 : ¬ IsSelfInterpreter e2419191450586 :=
  wSource (t := t_e2419191450586) (replay_sound (ps := []) (t := e2419191450586) (by decide)) (by decide)
def e2419191450862 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419191450862 : Closed e2419191450862 ∧ code e2419191450862 = 11215284473070 := by decide
theorem cert_e2419191450862 : check e2419191450862 [[],[],[.left],[.left],[.left],[.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2419191450870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419191450870 : Closed e2419191450870 ∧ code e2419191450870 = 11215284473078 := by decide
theorem cert_e2419191450870 : check e2419191450870 [[],[],[.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[]] .sourceHead = true := by decide
def e2419191451246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419191451246 : Closed e2419191451246 ∧ code e2419191451246 = 11215284473454 := by decide
theorem cert_e2419191451246 : check e2419191451246 [[],[],[.left],[.left],[.left],[.left],[.left],[],[],[.under,.left],[.under,.left],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e2419191451258 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419191451258 : Closed e2419191451258 ∧ code e2419191451258 = 11215284473466 := by decide
theorem cert_e2419191451258 : checkPay e2419191451258 [[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left]] 0 [[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.under,.right,.left],[.under,.under,.right,.under,.right],[.under,.under,.right,.under,.right,.right]] = true := by decide
def e2419191451446 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419191451446 : Closed e2419191451446 ∧ code e2419191451446 = 11215284473654 := by decide
theorem cert_e2419191451446 : check e2419191451446 [[],[],[.left],[.left],[.left],[.left],[.left],[],[],[.left],[.left],[],[],[.under]] .sourceHead = true := by decide
def e2419191451450 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419191451450 : Closed e2419191451450 ∧ code e2419191451450 = 11215284473658 := by decide
def e2419193809774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e2419193809774 : Closed e2419193809774 ∧ code e2419193809774 = 11215286831982 := by decide
theorem cert_e2419193809774 : check e2419193809774 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .chain = true := by decide
def e2419193809782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e2419193809782 : Closed e2419193809782 ∧ code e2419193809782 = 11215286831990 := by decide
theorem cert_e2419193809782 : check e2419193809782 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left]] .chain = true := by decide
def e2419193809838 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e2419193809838 : Closed e2419193809838 ∧ code e2419193809838 = 11215286832046 := by decide
theorem cert_e2419193809838 : check e2419193809838 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left]] .chain = true := by decide
def e2419193809850 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e2419193809850 : Closed e2419193809850 ∧ code e2419193809850 = 11215286832058 := by decide
theorem cert_e2419193809850 : check e2419193809850 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left]] .chain = true := by decide
def e2419193809878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e2419193809878 : Closed e2419193809878 ∧ code e2419193809878 = 11215286832086 := by decide
theorem cert_e2419193809878 : check e2419193809878 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2419193809882 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e2419193809882 : Closed e2419193809882 ∧ code e2419193809882 = 11215286832090 := by decide
theorem cert_e2419193809882 : check e2419193809882 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left,.left,.left]] .chain = true := by decide
def e2419193810158 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419193810158 : Closed e2419193810158 ∧ code e2419193810158 = 11215286832366 := by decide
theorem cert_e2419193810158 : check e2419193810158 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419193810166 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419193810166 : Closed e2419193810166 ∧ code e2419193810166 = 11215286832374 := by decide
theorem cert_e2419193810166 : check e2419193810166 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left],[]] .sourceHead = true := by decide
def e2419193810542 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419193810542 : Closed e2419193810542 ∧ code e2419193810542 = 11215286832750 := by decide
theorem cert_e2419193810542 : check e2419193810542 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2419193810554 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419193810554 : Closed e2419193810554 ∧ code e2419193810554 = 11215286832762 := by decide
theorem cert_e2419193810554 : check e2419193810554 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left],[.left,.left],[.left],[],[]] .sourceHead = true := by decide
def e2419193810742 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419193810742 : Closed e2419193810742 ∧ code e2419193810742 = 11215286832950 := by decide
theorem cert_e2419193810742 : check e2419193810742 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under]] .three = true := by decide
def e2419193810746 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419193810746 : Closed e2419193810746 ∧ code e2419193810746 = 11215286832954 := by decide
theorem cert_e2419193810746 : check e2419193810746 [[],[],[.left],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under]] .three = true := by decide
def e2419288181614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2419288181614 : Closed e2419288181614 ∧ code e2419288181614 = 11215381203822 := by decide
theorem cert_e2419288181614 : check e2419288181614 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2419288181622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2419288181622 : Closed e2419288181622 ∧ code e2419288181622 = 11215381203830 := by decide
theorem cert_e2419288181622 : check e2419288181622 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2419288181678 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2419288181678 : Closed e2419288181678 ∧ code e2419288181678 = 11215381203886 := by decide
theorem cert_e2419288181678 : check e2419288181678 [[],[.left],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2419288181690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2419288181690 : Closed e2419288181690 ∧ code e2419288181690 = 11215381203898 := by decide
theorem cert_e2419288181690 : check e2419288181690 [[],[.left],[.left],[],[.under,.left,.left,.left]] .chain = true := by decide
def e2419288181718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2419288181718 : Closed e2419288181718 ∧ code e2419288181718 = 11215381203926 := by decide
theorem cert_e2419288181718 : checkPay e2419288181718 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [] = true := by decide
def e2419288181722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2419288181722 : Closed e2419288181722 ∧ code e2419288181722 = 11215381203930 := by decide
theorem cert_e2419288181722 : check e2419288181722 [[],[.left],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left]] .chain = true := by decide
def e2419288181998 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2419288181998 : Closed e2419288181998 ∧ code e2419288181998 = 11215381204206 := by decide
theorem cert_e2419288181998 : check e2419288181998 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2419288182006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2419288182006 : Closed e2419288182006 ∧ code e2419288182006 = 11215381204214 := by decide
theorem cert_e2419288182006 : check e2419288182006 [[],[.left],[.left],[]] .sourceHead = true := by decide
def e2419288182382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2419288182382 : Closed e2419288182382 ∧ code e2419288182382 = 11215381204590 := by decide
theorem cert_e2419288182382 : check e2419288182382 [[],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2419288182394 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2419288182394 : Closed e2419288182394 ∧ code e2419288182394 = 11215381204602 := by decide
theorem cert_e2419288182394 : check e2419288182394 [[],[.left],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2419288182582 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2419288182582 : Closed e2419288182582 ∧ code e2419288182582 = 11215381204790 := by decide
theorem cert_e2419288182582 : check e2419288182582 [[],[.left],[.left],[],[.under]] .three = true := by decide
def e2419288182586 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2419288182586 : Closed e2419288182586 ∧ code e2419288182586 = 11215381204794 := by decide
theorem cert_e2419288182586 : check e2419288182586 [[],[.left],[.left],[],[.under]] .three = true := by decide
def e2422361599342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))))
theorem wire_e2422361599342 : Closed e2422361599342 ∧ code e2422361599342 = 11218454621550 := by decide
theorem cert_e2422361599342 : check e2422361599342 [[],[]] .smaller = true := by decide
def e2422361599350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))))
theorem wire_e2422361599350 : Closed e2422361599350 ∧ code e2422361599350 = 11218454621558 := by decide
theorem cert_e2422361599350 : check e2422361599350 [[],[]] .smaller = true := by decide
def e2422361599406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))))
theorem wire_e2422361599406 : Closed e2422361599406 ∧ code e2422361599406 = 11218454621614 := by decide
theorem cert_e2422361599406 : check e2422361599406 [[],[]] .smaller = true := by decide
def e2422361599418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))))
theorem wire_e2422361599418 : Closed e2422361599418 ∧ code e2422361599418 = 11218454621626 := by decide
theorem cert_e2422361599418 : check e2422361599418 [[],[]] .smaller = true := by decide
def e2422361599446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))))
theorem wire_e2422361599446 : Closed e2422361599446 ∧ code e2422361599446 = 11218454621654 := by decide
theorem cert_e2422361599446 : check e2422361599446 [[],[]] .smaller = true := by decide
def e2422361599450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))))
theorem wire_e2422361599450 : Closed e2422361599450 ∧ code e2422361599450 = 11218454621658 := by decide
theorem cert_e2422361599450 : check e2422361599450 [[],[]] .smaller = true := by decide
def e2422361599662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))))
theorem wire_e2422361599662 : Closed e2422361599662 ∧ code e2422361599662 = 11218454621870 := by decide
theorem cert_e2422361599662 : check e2422361599662 [[],[]] .smaller = true := by decide
def e2422361599674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))))
theorem wire_e2422361599674 : Closed e2422361599674 ∧ code e2422361599674 = 11218454621882 := by decide
theorem cert_e2422361599674 : check e2422361599674 [[],[]] .smaller = true := by decide
def e2422361599722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))))
theorem wire_e2422361599722 : Closed e2422361599722 ∧ code e2422361599722 = 11218454621930 := by decide
theorem cert_e2422361599722 : check e2422361599722 [[],[]] .smaller = true := by decide
def e2422361599830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))))
theorem wire_e2422361599830 : Closed e2422361599830 ∧ code e2422361599830 = 11218454622038 := by decide
theorem cert_e2422361599830 : check e2422361599830 [[],[]] .smaller = true := by decide
def e2422361599834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))))
theorem wire_e2422361599834 : Closed e2422361599834 ∧ code e2422361599834 = 11218454622042 := by decide
theorem cert_e2422361599834 : check e2422361599834 [[],[]] .smaller = true := by decide
def e2422361599850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))))
theorem wire_e2422361599850 : Closed e2422361599850 ∧ code e2422361599850 = 11218454622058 := by decide
theorem cert_e2422361599850 : check e2422361599850 [[],[]] .smaller = true := by decide
def e2422361600878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))))
theorem wire_e2422361600878 : Closed e2422361600878 ∧ code e2422361600878 = 11218454623086 := by decide
theorem cert_e2422361600878 : check e2422361600878 [[],[]] .smaller = true := by decide
def e2422361600886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))))
theorem wire_e2422361600886 : Closed e2422361600886 ∧ code e2422361600886 = 11218454623094 := by decide
theorem cert_e2422361600886 : check e2422361600886 [[],[]] .smaller = true := by decide
def e2422361600942 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))))
theorem wire_e2422361600942 : Closed e2422361600942 ∧ code e2422361600942 = 11218454623150 := by decide
theorem cert_e2422361600942 : check e2422361600942 [[],[]] .smaller = true := by decide
def e2422361600954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))))
theorem wire_e2422361600954 : Closed e2422361600954 ∧ code e2422361600954 = 11218454623162 := by decide
theorem cert_e2422361600954 : check e2422361600954 [[],[]] .smaller = true := by decide
def e2422361600982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))))
theorem wire_e2422361600982 : Closed e2422361600982 ∧ code e2422361600982 = 11218454623190 := by decide
theorem cert_e2422361600982 : check e2422361600982 [[],[]] .smaller = true := by decide
def e2422361600986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))))
theorem wire_e2422361600986 : Closed e2422361600986 ∧ code e2422361600986 = 11218454623194 := by decide
theorem cert_e2422361600986 : check e2422361600986 [[],[]] .smaller = true := by decide
def e2422361601262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))))
theorem wire_e2422361601262 : Closed e2422361601262 ∧ code e2422361601262 = 11218454623470 := by decide
theorem cert_e2422361601262 : check e2422361601262 [[],[]] .smaller = true := by decide
def e2422361601270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))))
theorem wire_e2422361601270 : Closed e2422361601270 ∧ code e2422361601270 = 11218454623478 := by decide
theorem cert_e2422361601270 : check e2422361601270 [[],[]] .smaller = true := by decide
def e2422361601646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422361601646 : Closed e2422361601646 ∧ code e2422361601646 = 11218454623854 := by decide
theorem cert_e2422361601646 : check e2422361601646 [[],[]] .smaller = true := by decide
def e2422361601658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422361601658 : Closed e2422361601658 ∧ code e2422361601658 = 11218454623866 := by decide
theorem cert_e2422361601658 : check e2422361601658 [[],[]] .smaller = true := by decide
def e2422361601846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422361601846 : Closed e2422361601846 ∧ code e2422361601846 = 11218454624054 := by decide
theorem cert_e2422361601846 : check e2422361601846 [[],[]] .smaller = true := by decide
def e2422361601850 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422361601850 : Closed e2422361601850 ∧ code e2422361601850 = 11218454624058 := by decide
theorem cert_e2422361601850 : check e2422361601850 [[],[]] .smaller = true := by decide
def e2422361602478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))))
theorem wire_e2422361602478 : Closed e2422361602478 ∧ code e2422361602478 = 11218454624686 := by decide
theorem cert_e2422361602478 : check e2422361602478 [[],[]] .smaller = true := by decide
def e2422361602490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))))
theorem wire_e2422361602490 : Closed e2422361602490 ∧ code e2422361602490 = 11218454624698 := by decide
theorem cert_e2422361602490 : check e2422361602490 [[],[]] .smaller = true := by decide
def e2422361602538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))))
theorem wire_e2422361602538 : Closed e2422361602538 ∧ code e2422361602538 = 11218454624746 := by decide
theorem cert_e2422361602538 : check e2422361602538 [[],[]] .smaller = true := by decide
def e2422361602670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))))
theorem wire_e2422361602670 : Closed e2422361602670 ∧ code e2422361602670 = 11218454624878 := by decide
theorem cert_e2422361602670 : check e2422361602670 [[],[]] .smaller = true := by decide
def e2422361602682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))))
theorem wire_e2422361602682 : Closed e2422361602682 ∧ code e2422361602682 = 11218454624890 := by decide
theorem cert_e2422361602682 : check e2422361602682 [[],[]] .smaller = true := by decide
def e2422361602970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422361602970 : Closed e2422361602970 ∧ code e2422361602970 = 11218454625178 := by decide
theorem cert_e2422361602970 : check e2422361602970 [[],[]] .smaller = true := by decide
def e2422361603286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))))
theorem wire_e2422361603286 : Closed e2422361603286 ∧ code e2422361603286 = 11218454625494 := by decide
theorem cert_e2422361603286 : check e2422361603286 [[],[]] .smaller = true := by decide
def e2422361603290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))))
theorem wire_e2422361603290 : Closed e2422361603290 ∧ code e2422361603290 = 11218454625498 := by decide
theorem cert_e2422361603290 : check e2422361603290 [[],[]] .smaller = true := by decide
def e2422361603306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))))
theorem wire_e2422361603306 : Closed e2422361603306 ∧ code e2422361603306 = 11218454625514 := by decide
theorem cert_e2422361603306 : check e2422361603306 [[],[]] .smaller = true := by decide
def e2422361603382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))))
theorem wire_e2422361603382 : Closed e2422361603382 ∧ code e2422361603382 = 11218454625590 := by decide
theorem cert_e2422361603382 : check e2422361603382 [[],[]] .smaller = true := by decide
def e2422361603386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))))
theorem wire_e2422361603386 : Closed e2422361603386 ∧ code e2422361603386 = 11218454625594 := by decide
theorem cert_e2422361603386 : check e2422361603386 [[],[]] .smaller = true := by decide
def e2422361603482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))))
theorem wire_e2422361603482 : Closed e2422361603482 ∧ code e2422361603482 = 11218454625690 := by decide
theorem cert_e2422361603482 : check e2422361603482 [[],[]] .smaller = true := by decide
def e2422361607022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))))
theorem wire_e2422361607022 : Closed e2422361607022 ∧ code e2422361607022 = 11218454629230 := by decide
theorem cert_e2422361607022 : check e2422361607022 [[],[]] .smaller = true := by decide
def e2422361607030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))))
theorem wire_e2422361607030 : Closed e2422361607030 ∧ code e2422361607030 = 11218454629238 := by decide
theorem cert_e2422361607030 : check e2422361607030 [[],[]] .smaller = true := by decide
def e2422361607086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))))
theorem wire_e2422361607086 : Closed e2422361607086 ∧ code e2422361607086 = 11218454629294 := by decide
theorem cert_e2422361607086 : check e2422361607086 [[],[]] .smaller = true := by decide
def e2422361607098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))))
theorem wire_e2422361607098 : Closed e2422361607098 ∧ code e2422361607098 = 11218454629306 := by decide
theorem cert_e2422361607098 : check e2422361607098 [[],[]] .smaller = true := by decide
def e2422361607126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))))
theorem wire_e2422361607126 : Closed e2422361607126 ∧ code e2422361607126 = 11218454629334 := by decide
theorem cert_e2422361607126 : check e2422361607126 [[],[]] .smaller = true := by decide
def e2422361607130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))))
theorem wire_e2422361607130 : Closed e2422361607130 ∧ code e2422361607130 = 11218454629338 := by decide
theorem cert_e2422361607130 : check e2422361607130 [[],[]] .smaller = true := by decide
def e2422361607406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))))
theorem wire_e2422361607406 : Closed e2422361607406 ∧ code e2422361607406 = 11218454629614 := by decide
theorem cert_e2422361607406 : check e2422361607406 [[],[]] .smaller = true := by decide
def e2422361607414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))))
theorem wire_e2422361607414 : Closed e2422361607414 ∧ code e2422361607414 = 11218454629622 := by decide
theorem cert_e2422361607414 : check e2422361607414 [[],[]] .smaller = true := by decide
def e2422361607790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))))
theorem wire_e2422361607790 : Closed e2422361607790 ∧ code e2422361607790 = 11218454629998 := by decide
theorem cert_e2422361607790 : check e2422361607790 [[],[]] .smaller = true := by decide
def e2422361607802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))))
theorem wire_e2422361607802 : Closed e2422361607802 ∧ code e2422361607802 = 11218454630010 := by decide
theorem cert_e2422361607802 : check e2422361607802 [[],[]] .smaller = true := by decide
def e2422361607990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))))
theorem wire_e2422361607990 : Closed e2422361607990 ∧ code e2422361607990 = 11218454630198 := by decide
theorem cert_e2422361607990 : check e2422361607990 [[],[]] .smaller = true := by decide
def e2422361607994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))))
theorem wire_e2422361607994 : Closed e2422361607994 ∧ code e2422361607994 = 11218454630202 := by decide
theorem cert_e2422361607994 : check e2422361607994 [[],[]] .smaller = true := by decide
def e2422361613742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))))
theorem wire_e2422361613742 : Closed e2422361613742 ∧ code e2422361613742 = 11218454635950 := by decide
theorem cert_e2422361613742 : check e2422361613742 [[],[]] .smaller = true := by decide
def e2422361613754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))))
theorem wire_e2422361613754 : Closed e2422361613754 ∧ code e2422361613754 = 11218454635962 := by decide
theorem cert_e2422361613754 : check e2422361613754 [[],[]] .smaller = true := by decide
def e2422361613802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))))
theorem wire_e2422361613802 : Closed e2422361613802 ∧ code e2422361613802 = 11218454636010 := by decide
theorem cert_e2422361613802 : check e2422361613802 [[],[]] .smaller = true := by decide
def e2422361613934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))))
theorem wire_e2422361613934 : Closed e2422361613934 ∧ code e2422361613934 = 11218454636142 := by decide
theorem cert_e2422361613934 : check e2422361613934 [[],[]] .smaller = true := by decide
def e2422361613946 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))))
theorem wire_e2422361613946 : Closed e2422361613946 ∧ code e2422361613946 = 11218454636154 := by decide
theorem cert_e2422361613946 : check e2422361613946 [[],[]] .smaller = true := by decide
def e2422361614234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))))
theorem wire_e2422361614234 : Closed e2422361614234 ∧ code e2422361614234 = 11218454636442 := by decide
theorem cert_e2422361614234 : check e2422361614234 [[],[]] .smaller = true := by decide
def e2422361617110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))))
theorem wire_e2422361617110 : Closed e2422361617110 ∧ code e2422361617110 = 11218454639318 := by decide
theorem cert_e2422361617110 : check e2422361617110 [[],[]] .smaller = true := by decide
def e2422361617114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))))
theorem wire_e2422361617114 : Closed e2422361617114 ∧ code e2422361617114 = 11218454639322 := by decide
theorem cert_e2422361617114 : check e2422361617114 [[],[]] .smaller = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2419190855182
#print axioms Blc.Floor43.cert_e2419190855266
#print axioms Blc.Floor43.cert_e2419190855278
#print axioms Blc.Floor43.cert_e2419190855290
#print axioms Blc.Floor43.cert_e2419190855478
#print axioms Blc.Floor43.cert_e2419190855482
#print axioms Blc.Floor43.cert_e2419190896570
#print axioms Blc.Floor43.cert_e2419190909882
#print axioms Blc.Floor43.cert_e2419190909914
#print axioms Blc.Floor43.cert_e2419191450554
#print axioms Blc.Floor43.cert_e2419191450586
