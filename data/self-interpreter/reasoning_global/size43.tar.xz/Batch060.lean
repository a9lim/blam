import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e756102846490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756102846490 : Closed e756102846490 ∧ code e756102846490 = 9552195868698 := by decide
theorem cert_e756102846490 : check e756102846490 [] .sourceHead = true := by decide
def e756103241242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103241242 : Closed e756103241242 ∧ code e756103241242 = 9552196263450 := by decide
theorem cert_e756103241242 : check e756103241242 [] .sourceHead = true := by decide
def e756103245338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103245338 : Closed e756103245338 ∧ code e756103245338 = 9552196267546 := by decide
theorem cert_e756103245338 : check e756103245338 [] .sourceHead = true := by decide
def e756103736858 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103736858 : Closed e756103736858 ∧ code e756103736858 = 9552196759066 := by decide
theorem cert_e756103736858 : check e756103736858 [] .sourceHead = true := by decide
def e756103738906 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103738906 : Closed e756103738906 ∧ code e756103738906 = 9552196761114 := by decide
theorem cert_e756103738906 : check e756103738906 [] .sourceHead = true := by decide
def e756103753242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103753242 : Closed e756103753242 ∧ code e756103753242 = 9552196775450 := by decide
theorem cert_e756103753242 : check e756103753242 [] .sourceHead = true := by decide
def e756103756314 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103756314 : Closed e756103756314 ∧ code e756103756314 = 9552196778522 := by decide
theorem cert_e756103756314 : check e756103756314 [] .sourceHead = true := by decide
def e756103763482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103763482 : Closed e756103763482 ∧ code e756103763482 = 9552196785690 := by decide
theorem cert_e756103763482 : check e756103763482 [] .sourceHead = true := by decide
def e756103764506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103764506 : Closed e756103764506 ∧ code e756103764506 = 9552196786714 := by decide
theorem cert_e756103764506 : check e756103764506 [] .sourceHead = true := by decide
def e756103835162 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103835162 : Closed e756103835162 ∧ code e756103835162 = 9552196857370 := by decide
theorem cert_e756103835162 : check e756103835162 [] .sourceHead = true := by decide
def e756103837210 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103837210 : Closed e756103837210 ∧ code e756103837210 = 9552196859418 := by decide
theorem cert_e756103837210 : check e756103837210 [] .sourceHead = true := by decide
def e756103933466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103933466 : Closed e756103933466 ∧ code e756103933466 = 9552196955674 := by decide
theorem cert_e756103933466 : check e756103933466 [] .sourceHead = true := by decide
def e756103936538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103936538 : Closed e756103936538 ∧ code e756103936538 = 9552196958746 := by decide
theorem cert_e756103936538 : check e756103936538 [] .sourceHead = true := by decide
def e756103962650 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756103962650 : Closed e756103962650 ∧ code e756103962650 = 9552196984858 := by decide
theorem cert_e756103962650 : check e756103962650 [] .sourceHead = true := by decide
def e756103962742 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756103962742 : Closed e756103962742 ∧ code e756103962742 = 9552196984950 := by decide
theorem cert_e756103962742 : check e756103962742 [] .sourceHead = true := by decide
def e756103962986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756103962986 : Closed e756103962986 ∧ code e756103962986 = 9552196985194 := by decide
theorem cert_e756103962986 : check e756103962986 [] .sourceHead = true := by decide
def e756103963034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756103963034 : Closed e756103963034 ∧ code e756103963034 = 9552196985242 := by decide
theorem cert_e756103963034 : check e756103963034 [] .sourceHead = true := by decide
def e756103964186 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756103964186 : Closed e756103964186 ∧ code e756103964186 = 9552196986394 := by decide
theorem cert_e756103964186 : check e756103964186 [] .sourceHead = true := by decide
def e756103984666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103984666 : Closed e756103984666 ∧ code e756103984666 = 9552197006874 := by decide
theorem cert_e756103984666 : check e756103984666 [] .sourceHead = true := by decide
def e756103985690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756103985690 : Closed e756103985690 ∧ code e756103985690 = 9552197007898 := by decide
theorem cert_e756103985690 : check e756103985690 [] .sourceHead = true := by decide
def e756103995418 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756103995418 : Closed e756103995418 ∧ code e756103995418 = 9552197017626 := by decide
theorem cert_e756103995418 : check e756103995418 [] .sourceHead = true := by decide
def e756103995510 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756103995510 : Closed e756103995510 ∧ code e756103995510 = 9552197017718 := by decide
theorem cert_e756103995510 : check e756103995510 [] .sourceHead = true := by decide
def e756103995754 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756103995754 : Closed e756103995754 ∧ code e756103995754 = 9552197017962 := by decide
theorem cert_e756103995754 : check e756103995754 [] .sourceHead = true := by decide
def e756103995802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756103995802 : Closed e756103995802 ∧ code e756103995802 = 9552197018010 := by decide
theorem cert_e756103995802 : check e756103995802 [] .sourceHead = true := by decide
def e756103996954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756103996954 : Closed e756103996954 ∧ code e756103996954 = 9552197019162 := by decide
theorem cert_e756103996954 : check e756103996954 [] .sourceHead = true := by decide
def e756105207322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105207322 : Closed e756105207322 ∧ code e756105207322 = 9552198229530 := by decide
theorem cert_e756105207322 : check e756105207322 [] .sourceHead = true := by decide
def e756105213466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105213466 : Closed e756105213466 ∧ code e756105213466 = 9552198235674 := by decide
theorem cert_e756105213466 : check e756105213466 [] .sourceHead = true := by decide
def e756105457178 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105457178 : Closed e756105457178 ∧ code e756105457178 = 9552198479386 := by decide
theorem cert_e756105457178 : check e756105457178 [] .sourceHead = true := by decide
def e756105460250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105460250 : Closed e756105460250 ∧ code e756105460250 = 9552198482458 := by decide
theorem cert_e756105460250 : check e756105460250 [] .sourceHead = true := by decide
def e756105472538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105472538 : Closed e756105472538 ∧ code e756105472538 = 9552198494746 := by decide
theorem cert_e756105472538 : check e756105472538 [] .sourceHead = true := by decide
def e756105506330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105506330 : Closed e756105506330 ∧ code e756105506330 = 9552198528538 := by decide
theorem cert_e756105506330 : check e756105506330 [] .sourceHead = true := by decide
def e756105509402 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105509402 : Closed e756105509402 ∧ code e756105509402 = 9552198531610 := by decide
theorem cert_e756105509402 : check e756105509402 [] .sourceHead = true := by decide
def e756105535514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756105535514 : Closed e756105535514 ∧ code e756105535514 = 9552198557722 := by decide
theorem cert_e756105535514 : check e756105535514 [] .sourceHead = true := by decide
def e756105535606 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756105535606 : Closed e756105535606 ∧ code e756105535606 = 9552198557814 := by decide
theorem cert_e756105535606 : check e756105535606 [] .sourceHead = true := by decide
def e756105535850 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756105535850 : Closed e756105535850 ∧ code e756105535850 = 9552198558058 := by decide
theorem cert_e756105535850 : check e756105535850 [] .sourceHead = true := by decide
def e756105535898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756105535898 : Closed e756105535898 ∧ code e756105535898 = 9552198558106 := by decide
theorem cert_e756105535898 : check e756105535898 [] .sourceHead = true := by decide
def e756105537050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756105537050 : Closed e756105537050 ∧ code e756105537050 = 9552198559258 := by decide
theorem cert_e756105537050 : check e756105537050 [] .sourceHead = true := by decide
def e756105551386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105551386 : Closed e756105551386 ∧ code e756105551386 = 9552198573594 := by decide
theorem cert_e756105551386 : check e756105551386 [] .sourceHead = true := by decide
def e756105572550 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756105572550 : Closed e756105572550 ∧ code e756105572550 = 9552198594758 := by decide
theorem cert_e756105572550 : check e756105572550 [] .sourceHead = true := by decide
def e756105580058 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105580058 : Closed e756105580058 ∧ code e756105580058 = 9552198602266 := by decide
theorem cert_e756105580058 : check e756105580058 [] .sourceHead = true := by decide
def e756105583130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756105583130 : Closed e756105583130 ∧ code e756105583130 = 9552198605338 := by decide
theorem cert_e756105583130 : check e756105583130 [] .sourceHead = true := by decide
def e756105584666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756105584666 : Closed e756105584666 ∧ code e756105584666 = 9552198606874 := by decide
theorem cert_e756105584666 : check e756105584666 [] .sourceHead = true := by decide
def e756105584758 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756105584758 : Closed e756105584758 ∧ code e756105584758 = 9552198606966 := by decide
theorem cert_e756105584758 : check e756105584758 [] .sourceHead = true := by decide
def e756105585002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756105585002 : Closed e756105585002 ∧ code e756105585002 = 9552198607210 := by decide
theorem cert_e756105585002 : check e756105585002 [] .sourceHead = true := by decide
def e756105585050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756105585050 : Closed e756105585050 ∧ code e756105585050 = 9552198607258 := by decide
theorem cert_e756105585050 : check e756105585050 [] .sourceHead = true := by decide
def e756105586202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756105586202 : Closed e756105586202 ∧ code e756105586202 = 9552198608410 := by decide
theorem cert_e756105586202 : check e756105586202 [] .sourceHead = true := by decide
def e756105588934 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756105588934 : Closed e756105588934 ∧ code e756105588934 = 9552198611142 := by decide
theorem cert_e756105588934 : check e756105588934 [] .sourceHead = true := by decide
def e756105590810 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756105590810 : Closed e756105590810 ∧ code e756105590810 = 9552198613018 := by decide
theorem cert_e756105590810 : check e756105590810 [] .sourceHead = true := by decide
def e756106194458 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106194458 : Closed e756106194458 ∧ code e756106194458 = 9552199216666 := by decide
theorem cert_e756106194458 : check e756106194458 [] .sourceHead = true := by decide
def e756106196506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106196506 : Closed e756106196506 ∧ code e756106196506 = 9552199218714 := by decide
theorem cert_e756106196506 : check e756106196506 [] .sourceHead = true := by decide
def e756106319386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106319386 : Closed e756106319386 ∧ code e756106319386 = 9552199341594 := by decide
theorem cert_e756106319386 : check e756106319386 [] .sourceHead = true := by decide
def e756106320410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106320410 : Closed e756106320410 ∧ code e756106320410 = 9552199342618 := by decide
theorem cert_e756106320410 : check e756106320410 [] .sourceHead = true := by decide
def e756106324506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106324506 : Closed e756106324506 ∧ code e756106324506 = 9552199346714 := by decide
theorem cert_e756106324506 : check e756106324506 [] .sourceHead = true := by decide
def e756106343962 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106343962 : Closed e756106343962 ∧ code e756106343962 = 9552199366170 := by decide
theorem cert_e756106343962 : check e756106343962 [] .sourceHead = true := by decide
def e756106344986 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106344986 : Closed e756106344986 ∧ code e756106344986 = 9552199367194 := by decide
theorem cert_e756106344986 : check e756106344986 [] .sourceHead = true := by decide
def e756106354714 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756106354714 : Closed e756106354714 ∧ code e756106354714 = 9552199376922 := by decide
theorem cert_e756106354714 : check e756106354714 [] .sourceHead = true := by decide
def e756106354806 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756106354806 : Closed e756106354806 ∧ code e756106354806 = 9552199377014 := by decide
theorem cert_e756106354806 : check e756106354806 [] .sourceHead = true := by decide
def e756106355050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756106355050 : Closed e756106355050 ∧ code e756106355050 = 9552199377258 := by decide
theorem cert_e756106355050 : check e756106355050 [] .sourceHead = true := by decide
def e756106355098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756106355098 : Closed e756106355098 ∧ code e756106355098 = 9552199377306 := by decide
theorem cert_e756106355098 : check e756106355098 [] .sourceHead = true := by decide
def e756106356250 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756106356250 : Closed e756106356250 ∧ code e756106356250 = 9552199378458 := by decide
theorem cert_e756106356250 : check e756106356250 [] .sourceHead = true := by decide
def e756106366490 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106366490 : Closed e756106366490 ∧ code e756106366490 = 9552199388698 := by decide
theorem cert_e756106366490 : check e756106366490 [] .sourceHead = true := by decide
def e756106369562 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756106369562 : Closed e756106369562 ∧ code e756106369562 = 9552199391770 := by decide
theorem cert_e756106369562 : check e756106369562 [] .sourceHead = true := by decide
def e756106371098 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756106371098 : Closed e756106371098 ∧ code e756106371098 = 9552199393306 := by decide
theorem cert_e756106371098 : check e756106371098 [] .sourceHead = true := by decide
def e756106371190 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756106371190 : Closed e756106371190 ∧ code e756106371190 = 9552199393398 := by decide
theorem cert_e756106371190 : check e756106371190 [] .sourceHead = true := by decide
def e756106371434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756106371434 : Closed e756106371434 ∧ code e756106371434 = 9552199393642 := by decide
theorem cert_e756106371434 : check e756106371434 [] .sourceHead = true := by decide
def e756106371482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756106371482 : Closed e756106371482 ∧ code e756106371482 = 9552199393690 := by decide
theorem cert_e756106371482 : check e756106371482 [] .sourceHead = true := by decide
def e756106372634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756106372634 : Closed e756106372634 ∧ code e756106372634 = 9552199394842 := by decide
theorem cert_e756106372634 : check e756106372634 [] .sourceHead = true := by decide
def e756106375366 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756106375366 : Closed e756106375366 ∧ code e756106375366 = 9552199397574 := by decide
theorem cert_e756106375366 : check e756106375366 [] .sourceHead = true := by decide
def e756106377242 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756106377242 : Closed e756106377242 ∧ code e756106377242 = 9552199399450 := by decide
theorem cert_e756106377242 : check e756106377242 [] .sourceHead = true := by decide
def e756106385434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756106385434 : Closed e756106385434 ∧ code e756106385434 = 9552199407642 := by decide
theorem cert_e756106385434 : check e756106385434 [] .sourceHead = true := by decide
def e756107669018 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756107669018 : Closed e756107669018 ∧ code e756107669018 = 9552200691226 := by decide
theorem cert_e756107669018 : check e756107669018 [] .sourceHead = true := by decide
def e756107672090 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756107672090 : Closed e756107672090 ∧ code e756107672090 = 9552200694298 := by decide
theorem cert_e756107672090 : check e756107672090 [] .sourceHead = true := by decide
def e756107696666 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756107696666 : Closed e756107696666 ∧ code e756107696666 = 9552200718874 := by decide
theorem cert_e756107696666 : check e756107696666 [] .sourceHead = true := by decide
def e756108029466 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108029466 : Closed e756108029466 ∧ code e756108029466 = 9552201051674 := by decide
theorem cert_e756108029466 : check e756108029466 [] .sourceHead = true := by decide
def e756108031514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108031514 : Closed e756108031514 ∧ code e756108031514 = 9552201053722 := by decide
theorem cert_e756108031514 : check e756108031514 [] .sourceHead = true := by decide
def e756108127770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108127770 : Closed e756108127770 ∧ code e756108127770 = 9552201149978 := by decide
theorem cert_e756108127770 : check e756108127770 [] .sourceHead = true := by decide
def e756108130842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108130842 : Closed e756108130842 ∧ code e756108130842 = 9552201153050 := by decide
theorem cert_e756108130842 : check e756108130842 [] .sourceHead = true := by decide
def e756108178970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108178970 : Closed e756108178970 ∧ code e756108178970 = 9552201201178 := by decide
theorem cert_e756108178970 : check e756108178970 [] .sourceHead = true := by decide
def e756108179994 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108179994 : Closed e756108179994 ∧ code e756108179994 = 9552201202202 := by decide
theorem cert_e756108179994 : check e756108179994 [] .sourceHead = true := by decide
def e756108668442 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108668442 : Closed e756108668442 ∧ code e756108668442 = 9552201690650 := by decide
theorem cert_e756108668442 : check e756108668442 [] .sourceHead = true := by decide
def e756108671514 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108671514 : Closed e756108671514 ∧ code e756108671514 = 9552201693722 := by decide
theorem cert_e756108671514 : check e756108671514 [] .sourceHead = true := by decide
def e756108683802 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108683802 : Closed e756108683802 ∧ code e756108683802 = 9552201706010 := by decide
theorem cert_e756108683802 : check e756108683802 [] .sourceHead = true := by decide
def e756108732954 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108732954 : Closed e756108732954 ∧ code e756108732954 = 9552201755162 := by decide
theorem cert_e756108732954 : check e756108732954 [] .sourceHead = true := by decide
def e756108815898 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 2)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108815898 : Closed e756108815898 ∧ code e756108815898 = 9552201838106 := by decide
theorem cert_e756108815898 : check e756108815898 [] .sourceHead = true := by decide
def e756108817946 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.lam (.var 3)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108817946 : Closed e756108817946 ∧ code e756108817946 = 9552201840154 := by decide
theorem cert_e756108817946 : check e756108817946 [] .sourceHead = true := by decide
def e756108865050 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108865050 : Closed e756108865050 ∧ code e756108865050 = 9552201887258 := by decide
theorem cert_e756108865050 : check e756108865050 [] .sourceHead = true := by decide
def e756108868122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108868122 : Closed e756108868122 ∧ code e756108868122 = 9552201890330 := by decide
theorem cert_e756108868122 : check e756108868122 [] .sourceHead = true := by decide
def e756108880410 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108880410 : Closed e756108880410 ∧ code e756108880410 = 9552201902618 := by decide
theorem cert_e756108880410 : check e756108880410 [] .sourceHead = true := by decide
def e756108914202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108914202 : Closed e756108914202 ∧ code e756108914202 = 9552201936410 := by decide
theorem cert_e756108914202 : check e756108914202 [] .sourceHead = true := by decide
def e756108917274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108917274 : Closed e756108917274 ∧ code e756108917274 = 9552201939482 := by decide
theorem cert_e756108917274 : check e756108917274 [] .sourceHead = true := by decide
def e756108943386 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756108943386 : Closed e756108943386 ∧ code e756108943386 = 9552201965594 := by decide
theorem cert_e756108943386 : check e756108943386 [] .sourceHead = true := by decide
def e756108943478 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756108943478 : Closed e756108943478 ∧ code e756108943478 = 9552201965686 := by decide
theorem cert_e756108943478 : check e756108943478 [] .sourceHead = true := by decide
def e756108943722 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756108943722 : Closed e756108943722 ∧ code e756108943722 = 9552201965930 := by decide
theorem cert_e756108943722 : check e756108943722 [] .sourceHead = true := by decide
def e756108943770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756108943770 : Closed e756108943770 ∧ code e756108943770 = 9552201965978 := by decide
theorem cert_e756108943770 : check e756108943770 [] .sourceHead = true := by decide
def e756108944922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756108944922 : Closed e756108944922 ∧ code e756108944922 = 9552201967130 := by decide
theorem cert_e756108944922 : check e756108944922 [] .sourceHead = true := by decide
def e756108959258 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108959258 : Closed e756108959258 ∧ code e756108959258 = 9552201981466 := by decide
theorem cert_e756108959258 : check e756108959258 [] .sourceHead = true := by decide
def e756108980422 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756108980422 : Closed e756108980422 ∧ code e756108980422 = 9552202002630 := by decide
theorem cert_e756108980422 : check e756108980422 [] .sourceHead = true := by decide
def e756108987930 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108987930 : Closed e756108987930 ∧ code e756108987930 = 9552202010138 := by decide
theorem cert_e756108987930 : check e756108987930 [] .sourceHead = true := by decide
def e756108991002 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756108991002 : Closed e756108991002 ∧ code e756108991002 = 9552202013210 := by decide
theorem cert_e756108991002 : check e756108991002 [] .sourceHead = true := by decide
def e756108992538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756108992538 : Closed e756108992538 ∧ code e756108992538 = 9552202014746 := by decide
theorem cert_e756108992538 : check e756108992538 [] .sourceHead = true := by decide
def e756108992630 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756108992630 : Closed e756108992630 ∧ code e756108992630 = 9552202014838 := by decide
theorem cert_e756108992630 : check e756108992630 [] .sourceHead = true := by decide
def e756108992874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756108992874 : Closed e756108992874 ∧ code e756108992874 = 9552202015082 := by decide
theorem cert_e756108992874 : check e756108992874 [] .sourceHead = true := by decide
def e756108992922 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756108992922 : Closed e756108992922 ∧ code e756108992922 = 9552202015130 := by decide
theorem cert_e756108992922 : check e756108992922 [] .sourceHead = true := by decide
def e756108994074 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756108994074 : Closed e756108994074 ∧ code e756108994074 = 9552202016282 := by decide
theorem cert_e756108994074 : check e756108994074 [] .sourceHead = true := by decide
def e756108996806 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756108996806 : Closed e756108996806 ∧ code e756108996806 = 9552202019014 := by decide
theorem cert_e756108996806 : check e756108996806 [] .sourceHead = true := by decide
def e756108998682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756108998682 : Closed e756108998682 ∧ code e756108998682 = 9552202020890 := by decide
theorem cert_e756108998682 : check e756108998682 [] .sourceHead = true := by decide
def e756109045274 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 1)))) (.var 2)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109045274 : Closed e756109045274 ∧ code e756109045274 = 9552202067482 := by decide
theorem cert_e756109045274 : check e756109045274 [] .sourceHead = true := by decide
def e756109048346 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.lam (.var 3)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109048346 : Closed e756109048346 ∧ code e756109048346 = 9552202070554 := by decide
theorem cert_e756109048346 : check e756109048346 [] .sourceHead = true := by decide
def e756109090330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.lam (.var 3))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109090330 : Closed e756109090330 ∧ code e756109090330 = 9552202112538 := by decide
theorem cert_e756109090330 : check e756109090330 [] .sourceHead = true := by decide
def e756109111494 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756109111494 : Closed e756109111494 ∧ code e756109111494 = 9552202133702 := by decide
theorem cert_e756109111494 : check e756109111494 [] .sourceHead = true := by decide
def e756109133338 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109133338 : Closed e756109133338 ∧ code e756109133338 = 9552202155546 := by decide
theorem cert_e756109133338 : check e756109133338 [] .sourceHead = true := by decide
def e756109136070 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756109136070 : Closed e756109136070 ∧ code e756109136070 = 9552202158278 := by decide
theorem cert_e756109136070 : check e756109136070 [] .sourceHead = true := by decide
def e756109162010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.var 1)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109162010 : Closed e756109162010 ∧ code e756109162010 = 9552202184218 := by decide
theorem cert_e756109162010 : check e756109162010 [] .sourceHead = true := by decide
def e756109163034 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 2)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109163034 : Closed e756109163034 ∧ code e756109163034 = 9552202185242 := by decide
theorem cert_e756109163034 : check e756109163034 [] .sourceHead = true := by decide
def e756109175322 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 0)))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109175322 : Closed e756109175322 ∧ code e756109175322 = 9552202197530 := by decide
theorem cert_e756109175322 : check e756109175322 [] .sourceHead = true := by decide
def e756109184538 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109184538 : Closed e756109184538 ∧ code e756109184538 = 9552202206746 := by decide
theorem cert_e756109184538 : check e756109184538 [] .sourceHead = true := by decide
def e756109187610 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109187610 : Closed e756109187610 ∧ code e756109187610 = 9552202209818 := by decide
theorem cert_e756109187610 : check e756109187610 [] .sourceHead = true := by decide
def e756109189146 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756109189146 : Closed e756109189146 ∧ code e756109189146 = 9552202211354 := by decide
theorem cert_e756109189146 : check e756109189146 [] .sourceHead = true := by decide
def e756109189238 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756109189238 : Closed e756109189238 ∧ code e756109189238 = 9552202211446 := by decide
theorem cert_e756109189238 : check e756109189238 [] .sourceHead = true := by decide
def e756109189482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756109189482 : Closed e756109189482 ∧ code e756109189482 = 9552202211690 := by decide
theorem cert_e756109189482 : check e756109189482 [] .sourceHead = true := by decide
def e756109189530 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756109189530 : Closed e756109189530 ∧ code e756109189530 = 9552202211738 := by decide
theorem cert_e756109189530 : check e756109189530 [] .sourceHead = true := by decide
def e756109190682 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756109190682 : Closed e756109190682 ∧ code e756109190682 = 9552202212890 := by decide
theorem cert_e756109190682 : check e756109190682 [] .sourceHead = true := by decide
def e756109193414 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756109193414 : Closed e756109193414 ∧ code e756109193414 = 9552202215622 := by decide
theorem cert_e756109193414 : check e756109193414 [] .sourceHead = true := by decide
def e756109195290 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756109195290 : Closed e756109195290 ∧ code e756109195290 = 9552202217498 := by decide
theorem cert_e756109195290 : check e756109195290 [] .sourceHead = true := by decide
def e756109198874 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.lam (.var 1))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109198874 : Closed e756109198874 ∧ code e756109198874 = 9552202221082 := by decide
theorem cert_e756109198874 : check e756109198874 [] .sourceHead = true := by decide
def e756109201606 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756109201606 : Closed e756109201606 ∧ code e756109201606 = 9552202223814 := by decide
theorem cert_e756109201606 : check e756109201606 [] .sourceHead = true := by decide
def e756109207578 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0)))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756109207578 : Closed e756109207578 ∧ code e756109207578 = 9552202229786 := by decide
theorem cert_e756109207578 : check e756109207578 [] .sourceHead = true := by decide
def e756109401626 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 1) (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109401626 : Closed e756109401626 ∧ code e756109401626 = 9552202423834 := by decide
theorem cert_e756109401626 : check e756109401626 [] .sourceHead = true := by decide
def e756109407770 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109407770 : Closed e756109407770 ∧ code e756109407770 = 9552202429978 := by decide
theorem cert_e756109407770 : check e756109407770 [] .sourceHead = true := by decide
def e756109651482 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109651482 : Closed e756109651482 ∧ code e756109651482 = 9552202673690 := by decide
theorem cert_e756109651482 : check e756109651482 [] .sourceHead = true := by decide
def e756109654554 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109654554 : Closed e756109654554 ∧ code e756109654554 = 9552202676762 := by decide
theorem cert_e756109654554 : check e756109654554 [] .sourceHead = true := by decide
def e756109666842 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109666842 : Closed e756109666842 ∧ code e756109666842 = 9552202689050 := by decide
theorem cert_e756109666842 : check e756109666842 [] .sourceHead = true := by decide
def e756109700634 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109700634 : Closed e756109700634 ∧ code e756109700634 = 9552202722842 := by decide
theorem cert_e756109700634 : check e756109700634 [] .sourceHead = true := by decide
def e756109703706 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109703706 : Closed e756109703706 ∧ code e756109703706 = 9552202725914 := by decide
theorem cert_e756109703706 : check e756109703706 [] .sourceHead = true := by decide
def e756109729818 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756109729818 : Closed e756109729818 ∧ code e756109729818 = 9552202752026 := by decide
theorem cert_e756109729818 : check e756109729818 [] .sourceHead = true := by decide
def e756109729910 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756109729910 : Closed e756109729910 ∧ code e756109729910 = 9552202752118 := by decide
theorem cert_e756109729910 : check e756109729910 [] .sourceHead = true := by decide
def e756109730154 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756109730154 : Closed e756109730154 ∧ code e756109730154 = 9552202752362 := by decide
theorem cert_e756109730154 : check e756109730154 [] .sourceHead = true := by decide
def e756109730202 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756109730202 : Closed e756109730202 ∧ code e756109730202 = 9552202752410 := by decide
theorem cert_e756109730202 : check e756109730202 [] .sourceHead = true := by decide
def e756109731354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756109731354 : Closed e756109731354 ∧ code e756109731354 = 9552202753562 := by decide
theorem cert_e756109731354 : check e756109731354 [] .sourceHead = true := by decide
def e756109745690 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109745690 : Closed e756109745690 ∧ code e756109745690 = 9552202767898 := by decide
theorem cert_e756109745690 : check e756109745690 [] .sourceHead = true := by decide
def e756109766854 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756109766854 : Closed e756109766854 ∧ code e756109766854 = 9552202789062 := by decide
theorem cert_e756109766854 : check e756109766854 [] .sourceHead = true := by decide
def e756109774362 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109774362 : Closed e756109774362 ∧ code e756109774362 = 9552202796570 := by decide
theorem cert_e756109774362 : check e756109774362 [] .sourceHead = true := by decide
def e756109777434 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756109777434 : Closed e756109777434 ∧ code e756109777434 = 9552202799642 := by decide
theorem cert_e756109777434 : check e756109777434 [] .sourceHead = true := by decide
def e756109778970 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756109778970 : Closed e756109778970 ∧ code e756109778970 = 9552202801178 := by decide
theorem cert_e756109778970 : check e756109778970 [] .sourceHead = true := by decide
def e756109779062 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756109779062 : Closed e756109779062 ∧ code e756109779062 = 9552202801270 := by decide
theorem cert_e756109779062 : check e756109779062 [] .sourceHead = true := by decide
def e756109779306 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.app (.var 0) (.var 0)) (.var 0)))))
theorem wire_e756109779306 : Closed e756109779306 ∧ code e756109779306 = 9552202801514 := by decide
theorem cert_e756109779306 : check e756109779306 [] .sourceHead = true := by decide
def e756109779354 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.app (.var 0) (.var 0))))))
theorem wire_e756109779354 : Closed e756109779354 ∧ code e756109779354 = 9552202801562 := by decide
theorem cert_e756109779354 : check e756109779354 [] .sourceHead = true := by decide
def e756109780506 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756109780506 : Closed e756109780506 ∧ code e756109780506 = 9552202802714 := by decide
theorem cert_e756109780506 : check e756109780506 [] .sourceHead = true := by decide
def e756109783238 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756109783238 : Closed e756109783238 ∧ code e756109783238 = 9552202805446 := by decide
theorem cert_e756109783238 : check e756109783238 [] .sourceHead = true := by decide
def e756109785114 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2))))))) (.lam (.lam (.app (.var 0) (.var 0))))))
theorem wire_e756109785114 : Closed e756109785114 ∧ code e756109785114 = 9552202807322 := by decide
theorem cert_e756109785114 : check e756109785114 [] .sourceHead = true := by decide
def e756110532122 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.var 3)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756110532122 : Closed e756110532122 ∧ code e756110532122 = 9552203554330 := by decide
theorem cert_e756110532122 : check e756110532122 [] .sourceHead = true := by decide
def e756110553286 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756110553286 : Closed e756110553286 ∧ code e756110553286 = 9552203575494 := by decide
theorem cert_e756110553286 : check e756110553286 [] .sourceHead = true := by decide
def e756110575130 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756110575130 : Closed e756110575130 ∧ code e756110575130 = 9552203597338 := by decide
theorem cert_e756110575130 : check e756110575130 [] .sourceHead = true := by decide
def e756110577862 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e756110577862 : Closed e756110577862 ∧ code e756110577862 = 9552203600070 := by decide
theorem cert_e756110577862 : check e756110577862 [] .sourceHead = true := by decide
def e756110882330 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 1)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756110882330 : Closed e756110882330 ∧ code e756110882330 = 9552203904538 := by decide
theorem cert_e756110882330 : check e756110882330 [] .sourceHead = true := by decide
def e756110944794 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 0))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756110944794 : Closed e756110944794 ∧ code e756110944794 = 9552203967002 := by decide
theorem cert_e756110944794 : check e756110944794 [] .sourceHead = true := by decide
def e756110954010 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.var 2)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756110954010 : Closed e756110954010 ∧ code e756110954010 = 9552203976218 := by decide
theorem cert_e756110954010 : check e756110954010 [] .sourceHead = true := by decide
def e756110957082 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 0)))))))) (.lam (.app (.var 0) (.var 0)))))
theorem wire_e756110957082 : Closed e756110957082 ∧ code e756110957082 = 9552203979290 := by decide
theorem cert_e756110957082 : check e756110957082 [] .sourceHead = true := by decide
def e756110958618 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.lam (.app (.var 0) (.var 0)))))))
theorem wire_e756110958618 : Closed e756110958618 ∧ code e756110958618 = 9552203980826 := by decide
theorem cert_e756110958618 : check e756110958618 [] .sourceHead = true := by decide
def e756110958710 : Term := (.lam (.app (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))) (.lam (.lam (.app (.var 1) (.var 1))))))
theorem wire_e756110958710 : Closed e756110958710 ∧ code e756110958710 = 9552203980918 := by decide
theorem cert_e756110958710 : check e756110958710 [] .sourceHead = true := by decide
end Blc.Floor43
