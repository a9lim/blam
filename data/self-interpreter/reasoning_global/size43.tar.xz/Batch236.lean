import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2393373566690 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.lam (.var 0)))))))
theorem wire_e2393373566690 : Closed e2393373566690 ∧ code e2393373566690 = 11189466588898 := by decide
theorem cert_e2393373566690 : check e2393373566690 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373566702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 2))))))
theorem wire_e2393373566702 : Closed e2393373566702 ∧ code e2393373566702 = 11189466588910 := by decide
theorem cert_e2393373566702 : check e2393373566702 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373566830 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 1)))) (.var 2))))))
theorem wire_e2393373566830 : Closed e2393373566830 ∧ code e2393373566830 = 11189466589038 := by decide
theorem cert_e2393373566830 : check e2393373566830 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373566838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 1))))))
theorem wire_e2393373566838 : Closed e2393373566838 ∧ code e2393373566838 = 11189466589046 := by decide
theorem cert_e2393373566838 : check e2393373566838 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373566858 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2393373566858 : Closed e2393373566858 ∧ code e2393373566858 = 11189466589066 := by decide
theorem cert_e2393373566858 : check e2393373566858 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373566882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2393373566882 : Closed e2393373566882 ∧ code e2393373566882 = 11189466589090 := by decide
theorem cert_e2393373566882 : check e2393373566882 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373566894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 2))))))
theorem wire_e2393373566894 : Closed e2393373566894 ∧ code e2393373566894 = 11189466589102 := by decide
theorem cert_e2393373566894 : check e2393373566894 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373566902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 1))))))
theorem wire_e2393373566902 : Closed e2393373566902 ∧ code e2393373566902 = 11189466589110 := by decide
theorem cert_e2393373566902 : check e2393373566902 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373566906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 2)))) (.var 0))))))
theorem wire_e2393373566906 : Closed e2393373566906 ∧ code e2393373566906 = 11189466589114 := by decide
theorem cert_e2393373566906 : checkPay e2393373566906 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393373567038 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.lam (.lam (.var 4))))))))
theorem wire_e2393373567038 : Closed e2393373567038 ∧ code e2393373567038 = 11189466589246 := by decide
theorem cert_e2393373567038 : check e2393373567038 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373567458 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2393373567458 : Closed e2393373567458 ∧ code e2393373567458 = 11189466589666 := by decide
theorem cert_e2393373567458 : check e2393373567458 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373567470 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 2)))))))
theorem wire_e2393373567470 : Closed e2393373567470 ∧ code e2393373567470 = 11189466589678 := by decide
theorem cert_e2393373567470 : check e2393373567470 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left],[],[],[.left],[.left,.left],[.left],[],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393373568238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373568238 : Closed e2393373568238 ∧ code e2393373568238 = 11189466590446 := by decide
theorem cert_e2393373568238 : check e2393373568238 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393373568246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373568246 : Closed e2393373568246 ∧ code e2393373568246 = 11189466590454 := by decide
theorem cert_e2393373568246 : check e2393373568246 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2393373568526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.lam (.var 2))))))))
theorem wire_e2393373568526 : Closed e2393373568526 ∧ code e2393373568526 = 11189466590734 := by decide
theorem cert_e2393373568526 : check e2393373568526 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373568538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373568538 : Closed e2393373568538 ∧ code e2393373568538 = 11189466590746 := by decide
theorem cert_e2393373568538 : check e2393373568538 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left]] .identityHead = true := by decide
def e2393373568610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373568610 : Closed e2393373568610 ∧ code e2393373568610 = 11189466590818 := by decide
theorem cert_e2393373568610 : check e2393373568610 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373568622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373568622 : Closed e2393373568622 ∧ code e2393373568622 = 11189466590830 := by decide
theorem cert_e2393373568622 : check e2393373568622 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373568630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373568630 : Closed e2393373568630 ∧ code e2393373568630 = 11189466590838 := by decide
theorem cert_e2393373568630 : check e2393373568630 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2393373568634 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373568634 : Closed e2393373568634 ∧ code e2393373568634 = 11189466590842 := by decide
theorem cert_e2393373568634 : check e2393373568634 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left]] .identityHead = true := by decide
def e2393373569902 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 1)))) (.var 2))))))
theorem wire_e2393373569902 : Closed e2393373569902 ∧ code e2393373569902 = 11189466592110 := by decide
theorem cert_e2393373569902 : check e2393373569902 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373569910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 1))))))
theorem wire_e2393373569910 : Closed e2393373569910 ∧ code e2393373569910 = 11189466592118 := by decide
theorem cert_e2393373569910 : check e2393373569910 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373569966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 0)))) (.var 2))))))
theorem wire_e2393373569966 : Closed e2393373569966 ∧ code e2393373569966 = 11189466592174 := by decide
theorem cert_e2393373569966 : check e2393373569966 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373569978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 1) (.var 2)))) (.var 0))))))
theorem wire_e2393373569978 : Closed e2393373569978 ∧ code e2393373569978 = 11189466592186 := by decide
theorem cert_e2393373569978 : checkPay e2393373569978 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right,.right],[.right,.right,.under,.under,.left,.right,.right,.right]] = true := by decide
def e2393373570006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 1))))))
theorem wire_e2393373570006 : Closed e2393373570006 ∧ code e2393373570006 = 11189466592214 := by decide
theorem cert_e2393373570006 : check e2393373570006 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373570010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 1)))) (.var 0))))))
theorem wire_e2393373570010 : Closed e2393373570010 ∧ code e2393373570010 = 11189466592218 := by decide
theorem cert_e2393373570010 : checkPay e2393373570010 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.right,.left],[.right],[.right,.under,.left,.right,.right,.left],[.right,.under,.left,.right,.right],[.right,.under,.left,.right,.right,.under,.left,.right,.right]] = true := by decide
def e2393373570286 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2393373570286 : Closed e2393373570286 ∧ code e2393373570286 = 11189466592494 := by decide
def e2393373570294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2393373570294 : Closed e2393373570294 ∧ code e2393373570294 = 11189466592502 := by decide
def e2393373570670 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373570670 : Closed e2393373570670 ∧ code e2393373570670 = 11189466592878 := by decide
theorem cert_e2393373570670 : check e2393373570670 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373570682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 1))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373570682 : Closed e2393373570682 ∧ code e2393373570682 = 11189466592890 := by decide
def e2393373570870 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373570870 : Closed e2393373570870 ∧ code e2393373570870 = 11189466593078 := by decide
theorem cert_e2393373570870 : check e2393373570870 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373570874 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373570874 : Closed e2393373570874 ∧ code e2393373570874 = 11189466593082 := by decide
theorem cert_e2393373570874 : check e2393373570874 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left,.left,.left],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .sourceHead = true := by decide
def e2393373571130 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.lam (.var 2))))) (.var 0))))))
theorem wire_e2393373571130 : Closed e2393373571130 ∧ code e2393373571130 = 11189466593338 := by decide
theorem cert_e2393373571130 : check e2393373571130 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373571178 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.app (.var 0) (.var 0))))) (.var 0))))))
theorem wire_e2393373571178 : Closed e2393373571178 ∧ code e2393373571178 = 11189466593386 := by decide
theorem cert_e2393373571178 : checkPay e2393373571178 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2393373571226 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 0)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373571226 : Closed e2393373571226 ∧ code e2393373571226 = 11189466593434 := by decide
theorem cert_e2393373571226 : check e2393373571226 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373571270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.lam (.var 1)))) (.lam (.var 1)))))))
theorem wire_e2393373571270 : Closed e2393373571270 ∧ code e2393373571270 = 11189466593478 := by decide
theorem cert_e2393373571270 : check e2393373571270 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373571466 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))) (.var 0))))))
theorem wire_e2393373571466 : Closed e2393373571466 ∧ code e2393373571466 = 11189466593674 := by decide
theorem cert_e2393373571466 : check e2393373571466 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373571490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.lam (.var 0)))))))
theorem wire_e2393373571490 : Closed e2393373571490 ∧ code e2393373571490 = 11189466593698 := by decide
theorem cert_e2393373571490 : check e2393373571490 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373571502 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2393373571502 : Closed e2393373571502 ∧ code e2393373571502 = 11189466593710 := by decide
theorem cert_e2393373571502 : check e2393373571502 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373571510 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 1))))))
theorem wire_e2393373571510 : Closed e2393373571510 ∧ code e2393373571510 = 11189466593718 := by decide
theorem cert_e2393373571510 : check e2393373571510 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373571514 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 2)))) (.var 0))))))
theorem wire_e2393373571514 : Closed e2393373571514 ∧ code e2393373571514 = 11189466593722 := by decide
theorem cert_e2393373571514 : checkPay e2393373571514 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left,.left,.right]] = true := by decide
def e2393373571542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 1))))))
theorem wire_e2393373571542 : Closed e2393373571542 ∧ code e2393373571542 = 11189466593750 := by decide
theorem cert_e2393373571542 : check e2393373571542 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373571546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 1)))) (.var 0))))))
theorem wire_e2393373571546 : Closed e2393373571546 ∧ code e2393373571546 = 11189466593754 := by decide
theorem cert_e2393373571546 : checkPay e2393373571546 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.right,.left],[.under,.left,.right],[.under,.left,.right,.under,.left,.right]] = true := by decide
def e2393373571562 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.app (.var 2) (.var 0)))) (.var 0))))))
theorem wire_e2393373571562 : Closed e2393373571562 ∧ code e2393373571562 = 11189466593770 := by decide
theorem cert_e2393373571562 : checkPay e2393373571562 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] 0 [[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left,.left],[.under,.left,.left,.left,.left,.left,.left],[.under,.left,.right,.left],[.under,.left,.right],[.under,.left,.right,.under,.left,.left,.left],[.under,.left,.right,.under,.left,.left],[.under,.left,.right,.under,.left]] = true := by decide
def e2393373571598 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.lam (.var 2))))))))
theorem wire_e2393373571598 : Closed e2393373571598 ∧ code e2393373571598 = 11189466593806 := by decide
theorem cert_e2393373571598 : check e2393373571598 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373571610 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2393373571610 : Closed e2393373571610 ∧ code e2393373571610 = 11189466593818 := by decide
theorem cert_e2393373571610 : check e2393373571610 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2393373571682 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2393373571682 : Closed e2393373571682 ∧ code e2393373571682 = 11189466593890 := by decide
theorem cert_e2393373571682 : check e2393373571682 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373571694 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2393373571694 : Closed e2393373571694 ∧ code e2393373571694 = 11189466593902 := by decide
theorem cert_e2393373571694 : check e2393373571694 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373571702 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 1)))))))
theorem wire_e2393373571702 : Closed e2393373571702 ∧ code e2393373571702 = 11189466593910 := by decide
theorem cert_e2393373571702 : check e2393373571702 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2393373571706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2393373571706 : Closed e2393373571706 ∧ code e2393373571706 = 11189466593914 := by decide
theorem cert_e2393373571706 : check e2393373571706 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left]] .identityHead = true := by decide
def e2393373571894 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373571894 : Closed e2393373571894 ∧ code e2393373571894 = 11189466594102 := by decide
theorem cert_e2393373571894 : check e2393373571894 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373571898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373571898 : Closed e2393373571898 ∧ code e2393373571898 = 11189466594106 := by decide
def e2393373571994 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373571994 : Closed e2393373571994 ∧ code e2393373571994 = 11189466594202 := by decide
theorem cert_e2393373571994 : check e2393373571994 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373575134 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.app (.var 3) (.var 3))))))))
theorem wire_e2393373575134 : Closed e2393373575134 ∧ code e2393373575134 = 11189466597342 := by decide
theorem cert_e2393373575134 : check e2393373575134 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373578798 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2393373578798 : Closed e2393373578798 ∧ code e2393373578798 = 11189466601006 := by decide
theorem cert_e2393373578798 : check e2393373578798 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373578978 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2393373578978 : Closed e2393373578978 ∧ code e2393373578978 = 11189466601186 := by decide
theorem cert_e2393373578978 : check e2393373578978 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373578990 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 2)))))))
theorem wire_e2393373578990 : Closed e2393373578990 ∧ code e2393373578990 = 11189466601198 := by decide
theorem cert_e2393373578990 : check e2393373578990 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373579118 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 1)) (.var 2)))))))
theorem wire_e2393373579118 : Closed e2393373579118 ∧ code e2393373579118 = 11189466601326 := by decide
def e2393373579126 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 1)))))))
theorem wire_e2393373579126 : Closed e2393373579126 ∧ code e2393373579126 = 11189466601334 := by decide
def e2393373579146 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373579146 : Closed e2393373579146 ∧ code e2393373579146 = 11189466601354 := by decide
theorem cert_e2393373579146 : check e2393373579146 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373579170 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373579170 : Closed e2393373579170 ∧ code e2393373579170 = 11189466601378 := by decide
theorem cert_e2393373579170 : check e2393373579170 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373579182 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 2)))))))
theorem wire_e2393373579182 : Closed e2393373579182 ∧ code e2393373579182 = 11189466601390 := by decide
theorem cert_e2393373579182 : check e2393373579182 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2393373579190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 1)))))))
theorem wire_e2393373579190 : Closed e2393373579190 ∧ code e2393373579190 = 11189466601398 := by decide
def e2393373579194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.app (.var 2) (.var 2)) (.var 0)))))))
theorem wire_e2393373579194 : Closed e2393373579194 ∧ code e2393373579194 = 11189466601402 := by decide
theorem cert_e2393373579194 : check e2393373579194 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373579326 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.lam (.lam (.var 4)))))))))
theorem wire_e2393373579326 : Closed e2393373579326 ∧ code e2393373579326 = 11189466601534 := by decide
theorem cert_e2393373579326 : check e2393373579326 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373579746 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.lam (.var 0)))))))))
theorem wire_e2393373579746 : Closed e2393373579746 ∧ code e2393373579746 = 11189466601954 := by decide
theorem cert_e2393373579746 : check e2393373579746 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373579758 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 2))))))))
theorem wire_e2393373579758 : Closed e2393373579758 ∧ code e2393373579758 = 11189466601966 := by decide
theorem cert_e2393373579758 : check e2393373579758 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373580526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373580526 : Closed e2393373580526 ∧ code e2393373580526 = 11189466602734 := by decide
def e2393373580534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373580534 : Closed e2393373580534 ∧ code e2393373580534 = 11189466602742 := by decide
def e2393373580814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373580814 : Closed e2393373580814 ∧ code e2393373580814 = 11189466603022 := by decide
theorem cert_e2393373580814 : check e2393373580814 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373580826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373580826 : Closed e2393373580826 ∧ code e2393373580826 = 11189466603034 := by decide
theorem cert_e2393373580826 : check e2393373580826 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left]] .width = true := by decide
def e2393373580898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373580898 : Closed e2393373580898 ∧ code e2393373580898 = 11189466603106 := by decide
theorem cert_e2393373580898 : check e2393373580898 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373580910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373580910 : Closed e2393373580910 ∧ code e2393373580910 = 11189466603118 := by decide
theorem cert_e2393373580910 : check e2393373580910 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393373580918 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373580918 : Closed e2393373580918 ∧ code e2393373580918 = 11189466603126 := by decide
theorem cert_e2393373580918 : check e2393373580918 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393373580922 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373580922 : Closed e2393373580922 ∧ code e2393373580922 = 11189466603130 := by decide
theorem cert_e2393373580922 : check e2393373580922 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left],[.left],[],[.left]] .identityHead = true := by decide
def e2393373592430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2393373592430 : Closed e2393373592430 ∧ code e2393373592430 = 11189466614638 := by decide
theorem cert_e2393373592430 : check e2393373592430 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373592438 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2393373592438 : Closed e2393373592438 ∧ code e2393373592438 = 11189466614646 := by decide
theorem cert_e2393373592438 : check e2393373592438 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373592494 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2393373592494 : Closed e2393373592494 ∧ code e2393373592494 = 11189466614702 := by decide
theorem cert_e2393373592494 : check e2393373592494 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373592506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2393373592506 : Closed e2393373592506 ∧ code e2393373592506 = 11189466614714 := by decide
theorem cert_e2393373592506 : check e2393373592506 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373592534 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2393373592534 : Closed e2393373592534 ∧ code e2393373592534 = 11189466614742 := by decide
theorem cert_e2393373592534 : check e2393373592534 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373592538 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2393373592538 : Closed e2393373592538 ∧ code e2393373592538 = 11189466614746 := by decide
theorem cert_e2393373592538 : check e2393373592538 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373592814 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2393373592814 : Closed e2393373592814 ∧ code e2393373592814 = 11189466615022 := by decide
theorem cert_e2393373592814 : check e2393373592814 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373592822 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2393373592822 : Closed e2393373592822 ∧ code e2393373592822 = 11189466615030 := by decide
theorem cert_e2393373592822 : check e2393373592822 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373593198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373593198 : Closed e2393373593198 ∧ code e2393373593198 = 11189466615406 := by decide
def e2393373593210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373593210 : Closed e2393373593210 ∧ code e2393373593210 = 11189466615418 := by decide
def e2393373593398 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373593398 : Closed e2393373593398 ∧ code e2393373593398 = 11189466615606 := by decide
def e2393373593402 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373593402 : Closed e2393373593402 ∧ code e2393373593402 = 11189466615610 := by decide
def e2393373598174 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.var 3))))))))
theorem wire_e2393373598174 : Closed e2393373598174 ∧ code e2393373598174 = 11189466620382 := by decide
theorem cert_e2393373598174 : checkPay e2393373598174 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e2393373598198 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 3) (.var 1))))))))
theorem wire_e2393373598198 : Closed e2393373598198 ∧ code e2393373598198 = 11189466620406 := by decide
theorem cert_e2393373598198 : check e2393373598198 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2393373599114 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 0)))))))
theorem wire_e2393373599114 : Closed e2393373599114 ∧ code e2393373599114 = 11189466621322 := by decide
theorem cert_e2393373599114 : check e2393373599114 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373599138 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 0))))))))
theorem wire_e2393373599138 : Closed e2393373599138 ∧ code e2393373599138 = 11189466621346 := by decide
theorem cert_e2393373599138 : check e2393373599138 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373599150 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2393373599150 : Closed e2393373599150 ∧ code e2393373599150 = 11189466621358 := by decide
theorem cert_e2393373599150 : check e2393373599150 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373599158 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 1)))))))
theorem wire_e2393373599158 : Closed e2393373599158 ∧ code e2393373599158 = 11189466621366 := by decide
theorem cert_e2393373599158 : check e2393373599158 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373599162 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2393373599162 : Closed e2393373599162 ∧ code e2393373599162 = 11189466621370 := by decide
theorem cert_e2393373599162 : check e2393373599162 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373599190 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 1)))))))
theorem wire_e2393373599190 : Closed e2393373599190 ∧ code e2393373599190 = 11189466621398 := by decide
def e2393373599194 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 1)) (.var 0)))))))
theorem wire_e2393373599194 : Closed e2393373599194 ∧ code e2393373599194 = 11189466621402 := by decide
theorem cert_e2393373599194 : check e2393373599194 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373599210 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2393373599210 : Closed e2393373599210 ∧ code e2393373599210 = 11189466621418 := by decide
theorem cert_e2393373599210 : check e2393373599210 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373599246 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 2)))))))))
theorem wire_e2393373599246 : Closed e2393373599246 ∧ code e2393373599246 = 11189466621454 := by decide
theorem cert_e2393373599246 : check e2393373599246 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373599258 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 0)))))))))
theorem wire_e2393373599258 : Closed e2393373599258 ∧ code e2393373599258 = 11189466621466 := by decide
theorem cert_e2393373599258 : check e2393373599258 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373599330 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 0)))))))))
theorem wire_e2393373599330 : Closed e2393373599330 ∧ code e2393373599330 = 11189466621538 := by decide
theorem cert_e2393373599330 : check e2393373599330 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373599342 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2393373599342 : Closed e2393373599342 ∧ code e2393373599342 = 11189466621550 := by decide
theorem cert_e2393373599342 : check e2393373599342 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373599350 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 1))))))))
theorem wire_e2393373599350 : Closed e2393373599350 ∧ code e2393373599350 = 11189466621558 := by decide
theorem cert_e2393373599350 : check e2393373599350 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373599354 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2393373599354 : Closed e2393373599354 ∧ code e2393373599354 = 11189466621562 := by decide
theorem cert_e2393373599354 : check e2393373599354 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373599542 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373599542 : Closed e2393373599542 ∧ code e2393373599542 = 11189466621750 := by decide
def e2393373599546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373599546 : Closed e2393373599546 ∧ code e2393373599546 = 11189466621754 := by decide
def e2393373599642 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2393373599642 : Closed e2393373599642 ∧ code e2393373599642 = 11189466621850 := by decide
theorem cert_e2393373599642 : check e2393373599642 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373607734 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373607734 : Closed e2393373607734 ∧ code e2393373607734 = 11189466629942 := by decide
theorem cert_e2393373607734 : check e2393373607734 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373607738 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373607738 : Closed e2393373607738 ∧ code e2393373607738 = 11189466629946 := by decide
theorem cert_e2393373607738 : check e2393373607738 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373607834 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 0)))))))
theorem wire_e2393373607834 : Closed e2393373607834 ∧ code e2393373607834 = 11189466630042 := by decide
theorem cert_e2393373607834 : check e2393373607834 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373609270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373609270 : Closed e2393373609270 ∧ code e2393373609270 = 11189466631478 := by decide
private def t_e2393373609270 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem cert_e2393373609270 : ¬ IsSelfInterpreter e2393373609270 :=
  wSource (t := t_e2393373609270) (replay_sound (ps := []) (t := e2393373609270) (by decide)) (by decide)
def e2393373609274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373609274 : Closed e2393373609274 ∧ code e2393373609274 = 11189466631482 := by decide
private def t_e2393373609274 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 0) (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem cert_e2393373609274 : ¬ IsSelfInterpreter e2393373609274 :=
  wSource (t := t_e2393373609274) (replay_sound (ps := []) (t := e2393373609274) (by decide)) (by decide)
def e2393373609710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))
theorem wire_e2393373609710 : Closed e2393373609710 ∧ code e2393373609710 = 11189466631918 := by decide
theorem cert_e2393373609710 : checkPay e2393373609710 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e2393373609718 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))
theorem wire_e2393373609718 : Closed e2393373609718 ∧ code e2393373609718 = 11189466631926 := by decide
theorem cert_e2393373609718 : checkPay e2393373609718 [[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left]] 0 [] = true := by decide
def e2393373609838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))
theorem wire_e2393373609838 : Closed e2393373609838 ∧ code e2393373609838 = 11189466632046 := by decide
theorem cert_e2393373609838 : check e2393373609838 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2393373609850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))
theorem wire_e2393373609850 : Closed e2393373609850 ∧ code e2393373609850 = 11189466632058 := by decide
theorem cert_e2393373609850 : check e2393373609850 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373609910 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))
theorem wire_e2393373609910 : Closed e2393373609910 ∧ code e2393373609910 = 11189466632118 := by decide
theorem cert_e2393373609910 : check e2393373609910 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left]] .chain = true := by decide
def e2393373609914 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))
theorem wire_e2393373609914 : Closed e2393373609914 ∧ code e2393373609914 = 11189466632122 := by decide
theorem cert_e2393373609914 : check e2393373609914 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left],[.under,.under,.left],[.under,.under]] .three = true := by decide
def e2393373610710 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2393373610710 : Closed e2393373610710 ∧ code e2393373610710 = 11189466632918 := by decide
theorem cert_e2393373610710 : check e2393373610710 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373610714 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2393373610714 : Closed e2393373610714 ∧ code e2393373610714 = 11189466632922 := by decide
theorem cert_e2393373610714 : check e2393373610714 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373610730 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2393373610730 : Closed e2393373610730 ∧ code e2393373610730 = 11189466632938 := by decide
theorem cert_e2393373610730 : check e2393373610730 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373610806 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2393373610806 : Closed e2393373610806 ∧ code e2393373610806 = 11189466633014 := by decide
theorem cert_e2393373610806 : check e2393373610806 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373610810 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2393373610810 : Closed e2393373610810 ∧ code e2393373610810 = 11189466633018 := by decide
theorem cert_e2393373610810 : check e2393373610810 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373610906 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 0))) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2393373610906 : Closed e2393373610906 ∧ code e2393373610906 = 11189466633114 := by decide
theorem cert_e2393373610906 : check e2393373610906 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373612430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2393373612430 : Closed e2393373612430 ∧ code e2393373612430 = 11189466634638 := by decide
theorem cert_e2393373612430 : check e2393373612430 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373612486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2393373612486 : Closed e2393373612486 ∧ code e2393373612486 = 11189466634694 := by decide
theorem cert_e2393373612486 : check e2393373612486 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373613254 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2393373613254 : Closed e2393373613254 ∧ code e2393373613254 = 11189466635462 := by decide
theorem cert_e2393373613254 : check e2393373613254 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617238 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 0))) (.var 1))))))
theorem wire_e2393373617238 : Closed e2393373617238 ∧ code e2393373617238 = 11189466639446 := by decide
theorem cert_e2393373617238 : check e2393373617238 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373617242 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))) (.var 0))))))
theorem wire_e2393373617242 : Closed e2393373617242 ∧ code e2393373617242 = 11189466639450 := by decide
theorem cert_e2393373617242 : check e2393373617242 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617430 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2393373617430 : Closed e2393373617430 ∧ code e2393373617430 = 11189466639638 := by decide
theorem cert_e2393373617430 : check e2393373617430 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373617506 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2393373617506 : Closed e2393373617506 ∧ code e2393373617506 = 11189466639714 := by decide
theorem cert_e2393373617506 : check e2393373617506 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617518 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))
theorem wire_e2393373617518 : Closed e2393373617518 ∧ code e2393373617518 = 11189466639726 := by decide
theorem cert_e2393373617518 : check e2393373617518 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373617526 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))
theorem wire_e2393373617526 : Closed e2393373617526 ∧ code e2393373617526 = 11189466639734 := by decide
theorem cert_e2393373617526 : check e2393373617526 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373617546 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373617546 : Closed e2393373617546 ∧ code e2393373617546 = 11189466639754 := by decide
theorem cert_e2393373617546 : check e2393373617546 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617570 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373617570 : Closed e2393373617570 ∧ code e2393373617570 = 11189466639778 := by decide
theorem cert_e2393373617570 : check e2393373617570 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617582 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))
theorem wire_e2393373617582 : Closed e2393373617582 ∧ code e2393373617582 = 11189466639790 := by decide
theorem cert_e2393373617582 : check e2393373617582 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373617590 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1))) (.var 1))))))
theorem wire_e2393373617590 : Closed e2393373617590 ∧ code e2393373617590 = 11189466639798 := by decide
theorem cert_e2393373617590 : check e2393373617590 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373617594 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))
theorem wire_e2393373617594 : Closed e2393373617594 ∧ code e2393373617594 = 11189466639802 := by decide
theorem cert_e2393373617594 : check e2393373617594 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373617622 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))
theorem wire_e2393373617622 : Closed e2393373617622 ∧ code e2393373617622 = 11189466639830 := by decide
theorem cert_e2393373617622 : check e2393373617622 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373617626 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))
theorem wire_e2393373617626 : Closed e2393373617626 ∧ code e2393373617626 = 11189466639834 := by decide
theorem cert_e2393373617626 : check e2393373617626 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373617706 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))) (.var 0))))))
theorem wire_e2393373617706 : Closed e2393373617706 ∧ code e2393373617706 = 11189466639914 := by decide
theorem cert_e2393373617706 : check e2393373617706 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617802 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2393373617802 : Closed e2393373617802 ∧ code e2393373617802 = 11189466640010 := by decide
theorem cert_e2393373617802 : check e2393373617802 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617826 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2393373617826 : Closed e2393373617826 ∧ code e2393373617826 = 11189466640034 := by decide
theorem cert_e2393373617826 : check e2393373617826 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373617838 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))
theorem wire_e2393373617838 : Closed e2393373617838 ∧ code e2393373617838 = 11189466640046 := by decide
theorem cert_e2393373617838 : check e2393373617838 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373617846 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1))) (.var 1))))))
theorem wire_e2393373617846 : Closed e2393373617846 ∧ code e2393373617846 = 11189466640054 := by decide
theorem cert_e2393373617846 : check e2393373617846 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373617850 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))
theorem wire_e2393373617850 : Closed e2393373617850 ∧ code e2393373617850 = 11189466640058 := by decide
theorem cert_e2393373617850 : check e2393373617850 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373617878 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0))) (.var 1))))))
theorem wire_e2393373617878 : Closed e2393373617878 ∧ code e2393373617878 = 11189466640086 := by decide
theorem cert_e2393373617878 : check e2393373617878 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373617882 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 1))) (.var 0))))))
theorem wire_e2393373617882 : Closed e2393373617882 ∧ code e2393373617882 = 11189466640090 := by decide
def e2393373617898 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))
theorem wire_e2393373617898 : Closed e2393373617898 ∧ code e2393373617898 = 11189466640106 := by decide
theorem cert_e2393373617898 : check e2393373617898 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under]] .sourceHead = true := by decide
def e2393373618006 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))
theorem wire_e2393373618006 : Closed e2393373618006 ∧ code e2393373618006 = 11189466640214 := by decide
theorem cert_e2393373618006 : check e2393373618006 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373618010 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))
theorem wire_e2393373618010 : Closed e2393373618010 ∧ code e2393373618010 = 11189466640218 := by decide
theorem cert_e2393373618010 : check e2393373618010 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373618026 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))
theorem wire_e2393373618026 : Closed e2393373618026 ∧ code e2393373618026 = 11189466640234 := by decide
theorem cert_e2393373618026 : check e2393373618026 [[],[.left],[],[.under,.left],[.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under],[.under,.under,.left,.left,.left],[.under,.under,.left,.left],[.under,.under,.left]] .sourceHead = true := by decide
def e2393373618294 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 2))))) (.var 1))))))
theorem wire_e2393373618294 : Closed e2393373618294 ∧ code e2393373618294 = 11189466640502 := by decide
theorem cert_e2393373618294 : check e2393373618294 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373618298 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.lam (.var 3))))) (.var 0))))))
theorem wire_e2393373618298 : Closed e2393373618298 ∧ code e2393373618298 = 11189466640506 := by decide
theorem cert_e2393373618298 : check e2393373618298 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373618390 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))) (.var 1))))))
theorem wire_e2393373618390 : Closed e2393373618390 ∧ code e2393373618390 = 11189466640598 := by decide
theorem cert_e2393373618390 : check e2393373618390 [[],[.left],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2393373618486 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 0) (.var 1)))))))
theorem wire_e2393373618486 : Closed e2393373618486 ∧ code e2393373618486 = 11189466640694 := by decide
theorem cert_e2393373618486 : check e2393373618486 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373618490 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 0)))) (.app (.var 1) (.var 0)))))))
theorem wire_e2393373618490 : Closed e2393373618490 ∧ code e2393373618490 = 11189466640698 := by decide
theorem cert_e2393373618490 : check e2393373618490 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373618574 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.lam (.var 2)))))))
theorem wire_e2393373618574 : Closed e2393373618574 ∧ code e2393373618574 = 11189466640782 := by decide
theorem cert_e2393373618574 : check e2393373618574 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373618630 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.lam (.var 1)))))))
theorem wire_e2393373618630 : Closed e2393373618630 ∧ code e2393373618630 = 11189466640838 := by decide
theorem cert_e2393373618630 : check e2393373618630 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2393373618966 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 0))))) (.var 1))))))
theorem wire_e2393373618966 : Closed e2393373618966 ∧ code e2393373618966 = 11189466641174 := by decide
theorem cert_e2393373618966 : check e2393373618966 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2393373619042 : Term := (.app (.lam (.app (.app (.var 0) (.var 0)) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))) (.lam (.var 0)))))))
theorem wire_e2393373619042 : Closed e2393373619042 ∧ code e2393373619042 = 11189466641250 := by decide
theorem cert_e2393373619042 : check e2393373619042 [[],[.left],[],[.under,.left]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2393373609270
#print axioms Blc.Floor43.cert_e2393373609274
