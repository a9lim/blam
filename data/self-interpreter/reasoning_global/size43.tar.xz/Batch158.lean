import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2260092707638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 0) (.var 1)))))))
theorem wire_e2260092707638 : Closed e2260092707638 ∧ code e2260092707638 = 11056185729846 := by decide
theorem cert_e2260092707638 : check e2260092707638 [[],[.under]] .three = true := by decide
def e2260092707642 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.app (.var 1) (.var 0)))))))
theorem wire_e2260092707642 : Closed e2260092707642 ∧ code e2260092707642 = 11056185729850 := by decide
theorem cert_e2260092707642 : check e2260092707642 [[],[.under]] .three = true := by decide
def e2260092707738 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.app (.var 0) (.var 0)))))))
theorem wire_e2260092707738 : Closed e2260092707738 ∧ code e2260092707738 = 11056185729946 := by decide
theorem cert_e2260092707738 : check e2260092707738 [[],[.under]] .three = true := by decide
def e2260092708406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 1)))) (.var 1))))))
theorem wire_e2260092708406 : Closed e2260092708406 ∧ code e2260092708406 = 11056185730614 := by decide
theorem cert_e2260092708406 : check e2260092708406 [[],[.under]] .three = true := by decide
def e2260092708410 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.lam (.var 2)))) (.var 0))))))
theorem wire_e2260092708410 : Closed e2260092708410 ∧ code e2260092708410 = 11056185730618 := by decide
theorem cert_e2260092708410 : check e2260092708410 [[],[.under]] .three = true := by decide
def e2260092708494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.lam (.var 2)))))))
theorem wire_e2260092708494 : Closed e2260092708494 ∧ code e2260092708494 = 11056185730702 := by decide
theorem cert_e2260092708494 : check e2260092708494 [[],[.under]] .three = true := by decide
def e2260092708550 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.lam (.var 1)))))))
theorem wire_e2260092708550 : Closed e2260092708550 ∧ code e2260092708550 = 11056185730758 := by decide
theorem cert_e2260092708550 : check e2260092708550 [[],[.under]] .three = true := by decide
def e2260092708634 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.lam (.var 1)))) (.var 0))))))
theorem wire_e2260092708634 : Closed e2260092708634 ∧ code e2260092708634 = 11056185730842 := by decide
theorem cert_e2260092708634 : check e2260092708634 [[],[.under]] .three = true := by decide
def e2260092708678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.lam (.var 1)))))))
theorem wire_e2260092708678 : Closed e2260092708678 ∧ code e2260092708678 = 11056185730886 := by decide
theorem cert_e2260092708678 : check e2260092708678 [[],[.under]] .three = true := by decide
def e2260092709262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.lam (.var 2))))))))
theorem wire_e2260092709262 : Closed e2260092709262 ∧ code e2260092709262 = 11056185731470 := by decide
theorem cert_e2260092709262 : check e2260092709262 [[],[.under]] .three = true := by decide
def e2260092709318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.lam (.var 1))))))))
theorem wire_e2260092709318 : Closed e2260092709318 ∧ code e2260092709318 = 11056185731526 := by decide
theorem cert_e2260092709318 : check e2260092709318 [[],[.under]] .three = true := by decide
def e2260092710086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.lam (.var 1))))))))
theorem wire_e2260092710086 : Closed e2260092710086 ∧ code e2260092710086 = 11056185732294 := by decide
theorem cert_e2260092710086 : check e2260092710086 [[],[.under]] .three = true := by decide
def e2260092720862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2260092720862 : Closed e2260092720862 ∧ code e2260092720862 = 11056185743070 := by decide
theorem cert_e2260092720862 : check e2260092720862 [[],[.under]] .three = true := by decide
def e2260092720886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2260092720886 : Closed e2260092720886 ∧ code e2260092720886 = 11056185743094 := by decide
theorem cert_e2260092720886 : check e2260092720886 [[],[.under]] .three = true := by decide
def e2260092720990 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2260092720990 : Closed e2260092720990 ∧ code e2260092720990 = 11056185743198 := by decide
theorem cert_e2260092720990 : check e2260092720990 [[],[.under]] .three = true := by decide
def e2260092721018 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2260092721018 : Closed e2260092721018 ∧ code e2260092721018 = 11056185743226 := by decide
theorem cert_e2260092721018 : check e2260092721018 [[],[.under]] .three = true := by decide
def e2260092721110 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2260092721110 : Closed e2260092721110 ∧ code e2260092721110 = 11056185743318 := by decide
theorem cert_e2260092721110 : check e2260092721110 [[],[.under]] .three = true := by decide
def e2260092721114 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2260092721114 : Closed e2260092721114 ∧ code e2260092721114 = 11056185743322 := by decide
theorem cert_e2260092721114 : check e2260092721114 [[],[.under]] .three = true := by decide
def e2260092721630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2260092721630 : Closed e2260092721630 ∧ code e2260092721630 = 11056185743838 := by decide
theorem cert_e2260092721630 : check e2260092721630 [[],[.under]] .three = true := by decide
def e2260092721654 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2260092721654 : Closed e2260092721654 ∧ code e2260092721654 = 11056185743862 := by decide
theorem cert_e2260092721654 : check e2260092721654 [[],[.under]] .three = true := by decide
def e2260092722398 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2260092722398 : Closed e2260092722398 ∧ code e2260092722398 = 11056185744606 := by decide
theorem cert_e2260092722398 : check e2260092722398 [[],[.under]] .three = true := by decide
def e2260092722426 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2260092722426 : Closed e2260092722426 ∧ code e2260092722426 = 11056185744634 := by decide
theorem cert_e2260092722426 : check e2260092722426 [[],[.under]] .three = true := by decide
def e2260092722998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260092722998 : Closed e2260092722998 ∧ code e2260092722998 = 11056185745206 := by decide
theorem cert_e2260092722998 : check e2260092722998 [[],[.under]] .three = true := by decide
def e2260092723002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260092723002 : Closed e2260092723002 ∧ code e2260092723002 = 11056185745210 := by decide
theorem cert_e2260092723002 : check e2260092723002 [[],[.under]] .three = true := by decide
def e2260092737774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2260092737774 : Closed e2260092737774 ∧ code e2260092737774 = 11056185759982 := by decide
theorem cert_e2260092737774 : check e2260092737774 [[],[.under]] .three = true := by decide
def e2260092737782 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2260092737782 : Closed e2260092737782 ∧ code e2260092737782 = 11056185759990 := by decide
theorem cert_e2260092737782 : check e2260092737782 [[],[.under]] .three = true := by decide
def e2260092738334 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2260092738334 : Closed e2260092738334 ∧ code e2260092738334 = 11056185760542 := by decide
theorem cert_e2260092738334 : check e2260092738334 [[],[.under]] .three = true := by decide
def e2260092738446 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2260092738446 : Closed e2260092738446 ∧ code e2260092738446 = 11056185760654 := by decide
theorem cert_e2260092738446 : check e2260092738446 [[],[.under]] .three = true := by decide
def e2260092738670 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2260092738670 : Closed e2260092738670 ∧ code e2260092738670 = 11056185760878 := by decide
theorem cert_e2260092738670 : check e2260092738670 [[],[.under]] .three = true := by decide
def e2260092738682 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2260092738682 : Closed e2260092738682 ∧ code e2260092738682 = 11056185760890 := by decide
theorem cert_e2260092738682 : check e2260092738682 [[],[.under]] .three = true := by decide
def e2260092738846 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2260092738846 : Closed e2260092738846 ∧ code e2260092738846 = 11056185761054 := by decide
theorem cert_e2260092738846 : check e2260092738846 [[],[.under]] .three = true := by decide
def e2260092739014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2260092739014 : Closed e2260092739014 ∧ code e2260092739014 = 11056185761222 := by decide
theorem cert_e2260092739014 : check e2260092739014 [[],[.under]] .three = true := by decide
def e2260092739126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2260092739126 : Closed e2260092739126 ∧ code e2260092739126 = 11056185761334 := by decide
theorem cert_e2260092739126 : check e2260092739126 [[],[.under]] .three = true := by decide
def e2260092739130 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2260092739130 : Closed e2260092739130 ∧ code e2260092739130 = 11056185761338 := by decide
theorem cert_e2260092739130 : check e2260092739130 [[],[.under]] .three = true := by decide
def e2260092739214 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2260092739214 : Closed e2260092739214 ∧ code e2260092739214 = 11056185761422 := by decide
theorem cert_e2260092739214 : check e2260092739214 [[],[.under]] .three = true := by decide
def e2260092739270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2260092739270 : Closed e2260092739270 ∧ code e2260092739270 = 11056185761478 := by decide
theorem cert_e2260092739270 : check e2260092739270 [[],[.under]] .three = true := by decide
def e2260092741406 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2260092741406 : Closed e2260092741406 ∧ code e2260092741406 = 11056185763614 := by decide
theorem cert_e2260092741406 : check e2260092741406 [[],[.under]] .three = true := by decide
def e2260092741518 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2260092741518 : Closed e2260092741518 ∧ code e2260092741518 = 11056185763726 := by decide
theorem cert_e2260092741518 : check e2260092741518 [[],[.under]] .three = true := by decide
def e2260092744478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2260092744478 : Closed e2260092744478 ∧ code e2260092744478 = 11056185766686 := by decide
theorem cert_e2260092744478 : check e2260092744478 [[],[.under]] .three = true := by decide
def e2260092744646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2260092744646 : Closed e2260092744646 ∧ code e2260092744646 = 11056185766854 := by decide
theorem cert_e2260092744646 : check e2260092744646 [[],[.under]] .three = true := by decide
def e2260092746126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2260092746126 : Closed e2260092746126 ∧ code e2260092746126 = 11056185768334 := by decide
theorem cert_e2260092746126 : check e2260092746126 [[],[.under]] .three = true := by decide
def e2260092746182 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2260092746182 : Closed e2260092746182 ∧ code e2260092746182 = 11056185768390 := by decide
theorem cert_e2260092746182 : check e2260092746182 [[],[.under]] .three = true := by decide
def e2260092783470 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2260092783470 : Closed e2260092783470 ∧ code e2260092783470 = 11056185805678 := by decide
theorem cert_e2260092783470 : check e2260092783470 [[],[.under]] .smaller = true := by decide
def e2260092783478 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2260092783478 : Closed e2260092783478 ∧ code e2260092783478 = 11056185805686 := by decide
theorem cert_e2260092783478 : check e2260092783478 [[],[.under]] .smaller = true := by decide
def e2260092783534 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2260092783534 : Closed e2260092783534 ∧ code e2260092783534 = 11056185805742 := by decide
theorem cert_e2260092783534 : check e2260092783534 [[],[.under]] .smaller = true := by decide
def e2260092783546 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2260092783546 : Closed e2260092783546 ∧ code e2260092783546 = 11056185805754 := by decide
theorem cert_e2260092783546 : check e2260092783546 [[],[.under]] .smaller = true := by decide
def e2260092783574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2260092783574 : Closed e2260092783574 ∧ code e2260092783574 = 11056185805782 := by decide
theorem cert_e2260092783574 : check e2260092783574 [[],[.under]] .smaller = true := by decide
def e2260092783578 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2260092783578 : Closed e2260092783578 ∧ code e2260092783578 = 11056185805786 := by decide
theorem cert_e2260092783578 : check e2260092783578 [[],[.under]] .smaller = true := by decide
def e2260092783854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2260092783854 : Closed e2260092783854 ∧ code e2260092783854 = 11056185806062 := by decide
theorem cert_e2260092783854 : check e2260092783854 [[],[.under]] .smaller = true := by decide
def e2260092783862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2260092783862 : Closed e2260092783862 ∧ code e2260092783862 = 11056185806070 := by decide
theorem cert_e2260092783862 : check e2260092783862 [[],[.under]] .smaller = true := by decide
def e2260092784238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2260092784238 : Closed e2260092784238 ∧ code e2260092784238 = 11056185806446 := by decide
theorem cert_e2260092784238 : check e2260092784238 [[],[.under]] .smaller = true := by decide
def e2260092784250 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2260092784250 : Closed e2260092784250 ∧ code e2260092784250 = 11056185806458 := by decide
theorem cert_e2260092784250 : check e2260092784250 [[],[.under]] .smaller = true := by decide
def e2260092784438 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260092784438 : Closed e2260092784438 ∧ code e2260092784438 = 11056185806646 := by decide
theorem cert_e2260092784438 : check e2260092784438 [[],[.under]] .smaller = true := by decide
def e2260092784442 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260092784442 : Closed e2260092784442 ∧ code e2260092784442 = 11056185806650 := by decide
theorem cert_e2260092784442 : check e2260092784442 [[],[.under]] .smaller = true := by decide
def e2260092791918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2260092791918 : Closed e2260092791918 ∧ code e2260092791918 = 11056185814126 := by decide
theorem cert_e2260092791918 : check e2260092791918 [[],[.under]] .three = true := by decide
def e2260092791930 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2260092791930 : Closed e2260092791930 ∧ code e2260092791930 = 11056185814138 := by decide
theorem cert_e2260092791930 : check e2260092791930 [[],[.under]] .three = true := by decide
def e2260092792094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2260092792094 : Closed e2260092792094 ∧ code e2260092792094 = 11056185814302 := by decide
theorem cert_e2260092792094 : check e2260092792094 [[],[.under]] .three = true := by decide
def e2260092792262 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2260092792262 : Closed e2260092792262 ∧ code e2260092792262 = 11056185814470 := by decide
theorem cert_e2260092792262 : check e2260092792262 [[],[.under]] .three = true := by decide
def e2260092792602 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2260092792602 : Closed e2260092792602 ∧ code e2260092792602 = 11056185814810 := by decide
theorem cert_e2260092792602 : check e2260092792602 [[],[.under]] .three = true := by decide
def e2260092792646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2260092792646 : Closed e2260092792646 ∧ code e2260092792646 = 11056185814854 := by decide
theorem cert_e2260092792646 : check e2260092792646 [[],[.under]] .three = true := by decide
def e2260092793630 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2260092793630 : Closed e2260092793630 ∧ code e2260092793630 = 11056185815838 := by decide
theorem cert_e2260092793630 : check e2260092793630 [[],[.under]] .three = true := by decide
def e2260092793798 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2260092793798 : Closed e2260092793798 ∧ code e2260092793798 = 11056185816006 := by decide
theorem cert_e2260092793798 : check e2260092793798 [[],[.under]] .three = true := by decide
def e2260092796102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2260092796102 : Closed e2260092796102 ∧ code e2260092796102 = 11056185818310 := by decide
theorem cert_e2260092796102 : check e2260092796102 [[],[.under]] .three = true := by decide
def e2260092818998 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2260092818998 : Closed e2260092818998 ∧ code e2260092818998 = 11056185841206 := by decide
theorem cert_e2260092818998 : check e2260092818998 [[],[.under]] .three = true := by decide
def e2260092819002 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2260092819002 : Closed e2260092819002 ∧ code e2260092819002 = 11056185841210 := by decide
theorem cert_e2260092819002 : check e2260092819002 [[],[.under]] .three = true := by decide
def e2260092819086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2260092819086 : Closed e2260092819086 ∧ code e2260092819086 = 11056185841294 := by decide
theorem cert_e2260092819086 : check e2260092819086 [[],[.under]] .three = true := by decide
def e2260092819142 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2260092819142 : Closed e2260092819142 ∧ code e2260092819142 = 11056185841350 := by decide
theorem cert_e2260092819142 : check e2260092819142 [[],[.under]] .three = true := by decide
def e2260092819226 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.lam (.var 1))) (.var 0)))))))
theorem wire_e2260092819226 : Closed e2260092819226 ∧ code e2260092819226 = 11056185841434 := by decide
theorem cert_e2260092819226 : check e2260092819226 [[],[.under]] .three = true := by decide
def e2260092819270 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.lam (.var 1))))))))
theorem wire_e2260092819270 : Closed e2260092819270 ∧ code e2260092819270 = 11056185841478 := by decide
theorem cert_e2260092819270 : check e2260092819270 [[],[.under]] .three = true := by decide
def e2260092819854 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2260092819854 : Closed e2260092819854 ∧ code e2260092819854 = 11056185842062 := by decide
theorem cert_e2260092819854 : check e2260092819854 [[],[.under]] .three = true := by decide
def e2260092819910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2260092819910 : Closed e2260092819910 ∧ code e2260092819910 = 11056185842118 := by decide
theorem cert_e2260092819910 : check e2260092819910 [[],[.under]] .three = true := by decide
def e2260092820678 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.lam (.var 1)))))))))
theorem wire_e2260092820678 : Closed e2260092820678 ∧ code e2260092820678 = 11056185842886 := by decide
theorem cert_e2260092820678 : check e2260092820678 [[],[.under]] .three = true := by decide
def e2260093917422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2260093917422 : Closed e2260093917422 ∧ code e2260093917422 = 11056186939630 := by decide
theorem cert_e2260093917422 : check e2260093917422 [[],[.under]] .chain = true := by decide
def e2260093917430 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2260093917430 : Closed e2260093917430 ∧ code e2260093917430 = 11056186939638 := by decide
theorem cert_e2260093917430 : check e2260093917430 [[],[.under]] .chain = true := by decide
def e2260093917982 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2260093917982 : Closed e2260093917982 ∧ code e2260093917982 = 11056186940190 := by decide
theorem cert_e2260093917982 : check e2260093917982 [[],[.under]] .chain = true := by decide
def e2260093918094 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2260093918094 : Closed e2260093918094 ∧ code e2260093918094 = 11056186940302 := by decide
theorem cert_e2260093918094 : check e2260093918094 [[],[.under]] .chain = true := by decide
def e2260093918318 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2260093918318 : Closed e2260093918318 ∧ code e2260093918318 = 11056186940526 := by decide
theorem cert_e2260093918318 : check e2260093918318 [[],[.under]] .chain = true := by decide
def e2260093918330 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2260093918330 : Closed e2260093918330 ∧ code e2260093918330 = 11056186940538 := by decide
theorem cert_e2260093918330 : check e2260093918330 [[],[.under]] .chain = true := by decide
def e2260093918494 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2260093918494 : Closed e2260093918494 ∧ code e2260093918494 = 11056186940702 := by decide
theorem cert_e2260093918494 : check e2260093918494 [[],[.under]] .chain = true := by decide
def e2260093918662 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2260093918662 : Closed e2260093918662 ∧ code e2260093918662 = 11056186940870 := by decide
theorem cert_e2260093918662 : check e2260093918662 [[],[.under]] .chain = true := by decide
def e2260093918774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2260093918774 : Closed e2260093918774 ∧ code e2260093918774 = 11056186940982 := by decide
theorem cert_e2260093918774 : check e2260093918774 [[],[.under]] .chain = true := by decide
def e2260093918778 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2260093918778 : Closed e2260093918778 ∧ code e2260093918778 = 11056186940986 := by decide
theorem cert_e2260093918778 : check e2260093918778 [[],[.under]] .chain = true := by decide
def e2260093918862 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2260093918862 : Closed e2260093918862 ∧ code e2260093918862 = 11056186941070 := by decide
theorem cert_e2260093918862 : check e2260093918862 [[],[.under]] .chain = true := by decide
def e2260093918918 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2260093918918 : Closed e2260093918918 ∧ code e2260093918918 = 11056186941126 := by decide
theorem cert_e2260093918918 : check e2260093918918 [[],[.under]] .chain = true := by decide
def e2260093921054 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2260093921054 : Closed e2260093921054 ∧ code e2260093921054 = 11056186943262 := by decide
theorem cert_e2260093921054 : check e2260093921054 [[],[.under]] .chain = true := by decide
def e2260093921166 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2260093921166 : Closed e2260093921166 ∧ code e2260093921166 = 11056186943374 := by decide
theorem cert_e2260093921166 : check e2260093921166 [[],[.under]] .chain = true := by decide
def e2260093924126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2260093924126 : Closed e2260093924126 ∧ code e2260093924126 = 11056186946334 := by decide
theorem cert_e2260093924126 : check e2260093924126 [[],[.under]] .chain = true := by decide
def e2260093924294 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2260093924294 : Closed e2260093924294 ∧ code e2260093924294 = 11056186946502 := by decide
theorem cert_e2260093924294 : check e2260093924294 [[],[.under]] .chain = true := by decide
def e2260093925774 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2260093925774 : Closed e2260093925774 ∧ code e2260093925774 = 11056186947982 := by decide
theorem cert_e2260093925774 : check e2260093925774 [[],[.under]] .chain = true := by decide
def e2260093925830 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2260093925830 : Closed e2260093925830 ∧ code e2260093925830 = 11056186948038 := by decide
theorem cert_e2260093925830 : check e2260093925830 [[],[.under]] .chain = true := by decide
def e2260098619102 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2260098619102 : Closed e2260098619102 ∧ code e2260098619102 = 11056191641310 := by decide
theorem cert_e2260098619102 : check e2260098619102 [[],[.under],[.under]] .smaller = true := by decide
def e2260098619126 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2260098619126 : Closed e2260098619126 ∧ code e2260098619126 = 11056191641334 := by decide
theorem cert_e2260098619126 : check e2260098619126 [[],[.under],[.under]] .smaller = true := by decide
def e2260098619230 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2260098619230 : Closed e2260098619230 ∧ code e2260098619230 = 11056191641438 := by decide
theorem cert_e2260098619230 : check e2260098619230 [[],[.under],[.under]] .smaller = true := by decide
def e2260098619258 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2260098619258 : Closed e2260098619258 ∧ code e2260098619258 = 11056191641466 := by decide
theorem cert_e2260098619258 : check e2260098619258 [[],[.under],[.under]] .smaller = true := by decide
def e2260098619350 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2260098619350 : Closed e2260098619350 ∧ code e2260098619350 = 11056191641558 := by decide
theorem cert_e2260098619350 : check e2260098619350 [[],[.under],[.under]] .smaller = true := by decide
def e2260098619354 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2260098619354 : Closed e2260098619354 ∧ code e2260098619354 = 11056191641562 := by decide
theorem cert_e2260098619354 : check e2260098619354 [[],[.under],[.under]] .smaller = true := by decide
def e2260098619870 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2260098619870 : Closed e2260098619870 ∧ code e2260098619870 = 11056191642078 := by decide
theorem cert_e2260098619870 : check e2260098619870 [[],[.under],[.under]] .smaller = true := by decide
def e2260098619894 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2260098619894 : Closed e2260098619894 ∧ code e2260098619894 = 11056191642102 := by decide
theorem cert_e2260098619894 : check e2260098619894 [[],[.under],[.under]] .smaller = true := by decide
def e2260098620638 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2260098620638 : Closed e2260098620638 ∧ code e2260098620638 = 11056191642846 := by decide
theorem cert_e2260098620638 : check e2260098620638 [[],[.under],[.under]] .smaller = true := by decide
def e2260098620666 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2260098620666 : Closed e2260098620666 ∧ code e2260098620666 = 11056191642874 := by decide
theorem cert_e2260098620666 : check e2260098620666 [[],[.under],[.under]] .smaller = true := by decide
def e2260098621238 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2260098621238 : Closed e2260098621238 ∧ code e2260098621238 = 11056191643446 := by decide
theorem cert_e2260098621238 : check e2260098621238 [[],[.under],[.under]] .smaller = true := by decide
def e2260098621242 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2260098621242 : Closed e2260098621242 ∧ code e2260098621242 = 11056191643450 := by decide
theorem cert_e2260098621242 : check e2260098621242 [[],[.under],[.under]] .smaller = true := by decide
def e2260098636014 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2260098636014 : Closed e2260098636014 ∧ code e2260098636014 = 11056191658222 := by decide
theorem cert_e2260098636014 : check e2260098636014 [[],[.under],[.under]] .smaller = true := by decide
def e2260098636022 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2260098636022 : Closed e2260098636022 ∧ code e2260098636022 = 11056191658230 := by decide
theorem cert_e2260098636022 : check e2260098636022 [[],[.under],[.under]] .smaller = true := by decide
def e2260098636574 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2260098636574 : Closed e2260098636574 ∧ code e2260098636574 = 11056191658782 := by decide
theorem cert_e2260098636574 : check e2260098636574 [[],[.under],[.under]] .smaller = true := by decide
def e2260098636686 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2260098636686 : Closed e2260098636686 ∧ code e2260098636686 = 11056191658894 := by decide
theorem cert_e2260098636686 : check e2260098636686 [[],[.under],[.under]] .smaller = true := by decide
def e2260098636910 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2260098636910 : Closed e2260098636910 ∧ code e2260098636910 = 11056191659118 := by decide
theorem cert_e2260098636910 : check e2260098636910 [[],[.under],[.under]] .smaller = true := by decide
def e2260098636922 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2260098636922 : Closed e2260098636922 ∧ code e2260098636922 = 11056191659130 := by decide
theorem cert_e2260098636922 : check e2260098636922 [[],[.under],[.under]] .smaller = true := by decide
def e2260098637086 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2260098637086 : Closed e2260098637086 ∧ code e2260098637086 = 11056191659294 := by decide
theorem cert_e2260098637086 : check e2260098637086 [[],[.under],[.under]] .smaller = true := by decide
def e2260098637254 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2260098637254 : Closed e2260098637254 ∧ code e2260098637254 = 11056191659462 := by decide
theorem cert_e2260098637254 : check e2260098637254 [[],[.under],[.under]] .smaller = true := by decide
def e2260098637366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2260098637366 : Closed e2260098637366 ∧ code e2260098637366 = 11056191659574 := by decide
theorem cert_e2260098637366 : check e2260098637366 [[],[.under],[.under]] .smaller = true := by decide
def e2260098637370 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2260098637370 : Closed e2260098637370 ∧ code e2260098637370 = 11056191659578 := by decide
theorem cert_e2260098637370 : check e2260098637370 [[],[.under],[.under]] .smaller = true := by decide
def e2260098637454 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2260098637454 : Closed e2260098637454 ∧ code e2260098637454 = 11056191659662 := by decide
theorem cert_e2260098637454 : check e2260098637454 [[],[.under],[.under]] .smaller = true := by decide
def e2260098637510 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2260098637510 : Closed e2260098637510 ∧ code e2260098637510 = 11056191659718 := by decide
theorem cert_e2260098637510 : check e2260098637510 [[],[.under],[.under]] .smaller = true := by decide
def e2260098639646 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2260098639646 : Closed e2260098639646 ∧ code e2260098639646 = 11056191661854 := by decide
theorem cert_e2260098639646 : check e2260098639646 [[],[.under],[.under]] .smaller = true := by decide
def e2260098639758 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2260098639758 : Closed e2260098639758 ∧ code e2260098639758 = 11056191661966 := by decide
theorem cert_e2260098639758 : check e2260098639758 [[],[.under],[.under]] .smaller = true := by decide
def e2260098642718 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2260098642718 : Closed e2260098642718 ∧ code e2260098642718 = 11056191664926 := by decide
theorem cert_e2260098642718 : check e2260098642718 [[],[.under],[.under]] .smaller = true := by decide
def e2260098642886 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2260098642886 : Closed e2260098642886 ∧ code e2260098642886 = 11056191665094 := by decide
theorem cert_e2260098642886 : check e2260098642886 [[],[.under],[.under]] .smaller = true := by decide
def e2260098644366 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2260098644366 : Closed e2260098644366 ∧ code e2260098644366 = 11056191666574 := by decide
theorem cert_e2260098644366 : check e2260098644366 [[],[.under],[.under]] .smaller = true := by decide
def e2260098644422 : Term := (.app (.lam (.lam (.app (.var 1) (.lam (.var 2))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2260098644422 : Closed e2260098644422 ∧ code e2260098644422 = 11056191666630 := by decide
theorem cert_e2260098644422 : check e2260098644422 [[],[.under],[.under]] .smaller = true := by decide
def e2260635186714 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635186714 : Closed e2260635186714 ∧ code e2260635186714 = 11056728208922 := by decide
theorem cert_e2260635186714 : check e2260635186714 [[]] .width = true := by decide
def e2260635203098 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635203098 : Closed e2260635203098 ∧ code e2260635203098 = 11056728225306 := by decide
theorem cert_e2260635203098 : check e2260635203098 [[]] .width = true := by decide
def e2260635317786 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635317786 : Closed e2260635317786 ∧ code e2260635317786 = 11056728339994 := by decide
theorem cert_e2260635317786 : check e2260635317786 [[]] .width = true := by decide
def e2260635342362 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635342362 : Closed e2260635342362 ∧ code e2260635342362 = 11056728364570 := by decide
theorem cert_e2260635342362 : check e2260635342362 [[]] .width = true := by decide
def e2260635399706 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635399706 : Closed e2260635399706 ∧ code e2260635399706 = 11056728421914 := by decide
theorem cert_e2260635399706 : check e2260635399706 [[]] .width = true := by decide
def e2260635407898 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635407898 : Closed e2260635407898 ∧ code e2260635407898 = 11056728430106 := by decide
theorem cert_e2260635407898 : check e2260635407898 [[]] .width = true := by decide
def e2260635973146 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635973146 : Closed e2260635973146 ∧ code e2260635973146 = 11056728995354 := by decide
theorem cert_e2260635973146 : check e2260635973146 [[]] .width = true := by decide
def e2260635989530 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260635989530 : Closed e2260635989530 ∧ code e2260635989530 = 11056729011738 := by decide
theorem cert_e2260635989530 : check e2260635989530 [[]] .width = true := by decide
def e2260636759578 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260636759578 : Closed e2260636759578 ∧ code e2260636759578 = 11056729781786 := by decide
theorem cert_e2260636759578 : check e2260636759578 [[]] .width = true := by decide
def e2260636784154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260636784154 : Closed e2260636784154 ∧ code e2260636784154 = 11056729806362 := by decide
theorem cert_e2260636784154 : check e2260636784154 [[]] .width = true := by decide
def e2260637169178 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260637169178 : Closed e2260637169178 ∧ code e2260637169178 = 11056730191386 := by decide
theorem cert_e2260637169178 : check e2260637169178 [[]] .width = true := by decide
def e2260637177370 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 1))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260637177370 : Closed e2260637177370 ∧ code e2260637177370 = 11056730199578 := by decide
theorem cert_e2260637177370 : check e2260637177370 [[]] .width = true := by decide
def e2260680273434 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680273434 : Closed e2260680273434 ∧ code e2260680273434 = 11056773295642 := by decide
theorem cert_e2260680273434 : check e2260680273434 [[]] .width = true := by decide
def e2260680275482 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680275482 : Closed e2260680275482 ∧ code e2260680275482 = 11056773297690 := by decide
theorem cert_e2260680275482 : check e2260680275482 [[]] .width = true := by decide
def e2260680289818 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680289818 : Closed e2260680289818 ∧ code e2260680289818 = 11056773312026 := by decide
theorem cert_e2260680289818 : check e2260680289818 [[]] .width = true := by decide
def e2260680292890 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680292890 : Closed e2260680292890 ∧ code e2260680292890 = 11056773315098 := by decide
theorem cert_e2260680292890 : check e2260680292890 [[]] .width = true := by decide
def e2260680300058 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680300058 : Closed e2260680300058 ∧ code e2260680300058 = 11056773322266 := by decide
theorem cert_e2260680300058 : check e2260680300058 [[]] .width = true := by decide
def e2260680301082 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680301082 : Closed e2260680301082 ∧ code e2260680301082 = 11056773323290 := by decide
theorem cert_e2260680301082 : check e2260680301082 [[]] .width = true := by decide
def e2260680371738 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680371738 : Closed e2260680371738 ∧ code e2260680371738 = 11056773393946 := by decide
theorem cert_e2260680371738 : check e2260680371738 [[]] .width = true := by decide
def e2260680373786 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680373786 : Closed e2260680373786 ∧ code e2260680373786 = 11056773395994 := by decide
theorem cert_e2260680373786 : check e2260680373786 [[]] .width = true := by decide
def e2260680470042 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680470042 : Closed e2260680470042 ∧ code e2260680470042 = 11056773492250 := by decide
theorem cert_e2260680470042 : check e2260680470042 [[]] .width = true := by decide
def e2260680473114 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680473114 : Closed e2260680473114 ∧ code e2260680473114 = 11056773495322 := by decide
theorem cert_e2260680473114 : check e2260680473114 [[]] .width = true := by decide
def e2260680521242 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680521242 : Closed e2260680521242 ∧ code e2260680521242 = 11056773543450 := by decide
theorem cert_e2260680521242 : check e2260680521242 [[]] .width = true := by decide
def e2260680522266 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260680522266 : Closed e2260680522266 ∧ code e2260680522266 = 11056773544474 := by decide
theorem cert_e2260680522266 : check e2260680522266 [[]] .width = true := by decide
def e2260699298330 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699298330 : Closed e2260699298330 ∧ code e2260699298330 = 11056792320538 := by decide
theorem cert_e2260699298330 : check e2260699298330 [[]] .width = true := by decide
def e2260699306522 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699306522 : Closed e2260699306522 ∧ code e2260699306522 = 11056792328730 := by decide
private def t_e2260699306522 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2260699306522 : ¬ IsSelfInterpreter e2260699306522 :=
  wSource (t := t_e2260699306522) (replay_sound (ps := []) (t := e2260699306522) (by decide)) (by decide)
def e2260699363866 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699363866 : Closed e2260699363866 ∧ code e2260699363866 = 11056792386074 := by decide
theorem cert_e2260699363866 : check e2260699363866 [[]] .width = true := by decide
def e2260699376154 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699376154 : Closed e2260699376154 ∧ code e2260699376154 = 11056792398362 := by decide
theorem cert_e2260699376154 : check e2260699376154 [[]] .width = true := by decide
def e2260699404826 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699404826 : Closed e2260699404826 ∧ code e2260699404826 = 11056792427034 := by decide
private def t_e2260699404826 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2260699404826 : ¬ IsSelfInterpreter e2260699404826 :=
  wSource (t := t_e2260699404826) (replay_sound (ps := []) (t := e2260699404826) (by decide)) (by decide)
def e2260699408922 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699408922 : Closed e2260699408922 ∧ code e2260699408922 = 11056792431130 := by decide
theorem cert_e2260699408922 : check e2260699408922 [[]] .width = true := by decide
def e2260699691546 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699691546 : Closed e2260699691546 ∧ code e2260699691546 = 11056792713754 := by decide
theorem cert_e2260699691546 : check e2260699691546 [[]] .width = true := by decide
def e2260699699738 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260699699738 : Closed e2260699699738 ∧ code e2260699699738 = 11056792721946 := by decide
theorem cert_e2260699699738 : check e2260699699738 [[]] .width = true := by decide
def e2260700084762 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260700084762 : Closed e2260700084762 ∧ code e2260700084762 = 11056793106970 := by decide
theorem cert_e2260700084762 : check e2260700084762 [[]] .width = true := by decide
def e2260700097050 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260700097050 : Closed e2260700097050 ∧ code e2260700097050 = 11056793119258 := by decide
theorem cert_e2260700097050 : check e2260700097050 [[]] .width = true := by decide
def e2260700289562 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260700289562 : Closed e2260700289562 ∧ code e2260700289562 = 11056793311770 := by decide
theorem cert_e2260700289562 : check e2260700289562 [[]] .width = true := by decide
def e2260700293658 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260700293658 : Closed e2260700293658 ∧ code e2260700293658 = 11056793315866 := by decide
theorem cert_e2260700293658 : check e2260700293658 [[]] .width = true := by decide
def e2260713827866 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713827866 : Closed e2260713827866 ∧ code e2260713827866 = 11056806850074 := by decide
theorem cert_e2260713827866 : check e2260713827866 [[]] .width = true := by decide
def e2260713829914 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713829914 : Closed e2260713829914 ∧ code e2260713829914 = 11056806852122 := by decide
theorem cert_e2260713829914 : check e2260713829914 [[]] .width = true := by decide
def e2260713844250 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713844250 : Closed e2260713844250 ∧ code e2260713844250 = 11056806866458 := by decide
theorem cert_e2260713844250 : check e2260713844250 [[]] .width = true := by decide
def e2260713847322 : Term := (.app (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2260713847322 : Closed e2260713847322 ∧ code e2260713847322 = 11056806869530 := by decide
theorem cert_e2260713847322 : check e2260713847322 [[]] .width = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2260699306522
#print axioms Blc.Floor43.cert_e2260699404826
