import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2418939792302 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2418939792302 : Closed e2418939792302 ∧ code e2418939792302 = 11215032814510 := by decide
theorem cert_e2418939792302 : check e2418939792302 [[],[]] .smaller = true := by decide
def e2418939792314 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2418939792314 : Closed e2418939792314 ∧ code e2418939792314 = 11215032814522 := by decide
theorem cert_e2418939792314 : check e2418939792314 [[],[]] .smaller = true := by decide
def e2418939792342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2418939792342 : Closed e2418939792342 ∧ code e2418939792342 = 11215032814550 := by decide
theorem cert_e2418939792342 : check e2418939792342 [[],[]] .smaller = true := by decide
def e2418939792346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2418939792346 : Closed e2418939792346 ∧ code e2418939792346 = 11215032814554 := by decide
theorem cert_e2418939792346 : check e2418939792346 [[],[]] .smaller = true := by decide
def e2418939792622 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2418939792622 : Closed e2418939792622 ∧ code e2418939792622 = 11215032814830 := by decide
theorem cert_e2418939792622 : check e2418939792622 [[],[]] .smaller = true := by decide
def e2418939792630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2418939792630 : Closed e2418939792630 ∧ code e2418939792630 = 11215032814838 := by decide
theorem cert_e2418939792630 : check e2418939792630 [[],[]] .smaller = true := by decide
def e2418939793006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2418939793006 : Closed e2418939793006 ∧ code e2418939793006 = 11215032815214 := by decide
theorem cert_e2418939793006 : check e2418939793006 [[],[]] .smaller = true := by decide
def e2418939793018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2418939793018 : Closed e2418939793018 ∧ code e2418939793018 = 11215032815226 := by decide
theorem cert_e2418939793018 : check e2418939793018 [[],[]] .smaller = true := by decide
def e2418939793206 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2418939793206 : Closed e2418939793206 ∧ code e2418939793206 = 11215032815414 := by decide
theorem cert_e2418939793206 : check e2418939793206 [[],[]] .smaller = true := by decide
def e2418939793210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))) (.lam (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2418939793210 : Closed e2418939793210 ∧ code e2418939793210 = 11215032815418 := by decide
theorem cert_e2418939793210 : check e2418939793210 [[],[]] .smaller = true := by decide
def e2419140373870 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))))
theorem wire_e2419140373870 : Closed e2419140373870 ∧ code e2419140373870 = 11215233396078 := by decide
theorem cert_e2419140373870 : check e2419140373870 [[],[]] .smaller = true := by decide
def e2419140373878 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))))
theorem wire_e2419140373878 : Closed e2419140373878 ∧ code e2419140373878 = 11215233396086 := by decide
theorem cert_e2419140373878 : check e2419140373878 [[],[]] .smaller = true := by decide
def e2419140373934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))))
theorem wire_e2419140373934 : Closed e2419140373934 ∧ code e2419140373934 = 11215233396142 := by decide
theorem cert_e2419140373934 : check e2419140373934 [[],[]] .smaller = true := by decide
def e2419140373946 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))))
theorem wire_e2419140373946 : Closed e2419140373946 ∧ code e2419140373946 = 11215233396154 := by decide
theorem cert_e2419140373946 : check e2419140373946 [[],[]] .smaller = true := by decide
def e2419140373974 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))))
theorem wire_e2419140373974 : Closed e2419140373974 ∧ code e2419140373974 = 11215233396182 := by decide
theorem cert_e2419140373974 : check e2419140373974 [[],[]] .smaller = true := by decide
def e2419140373978 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))))
theorem wire_e2419140373978 : Closed e2419140373978 ∧ code e2419140373978 = 11215233396186 := by decide
theorem cert_e2419140373978 : check e2419140373978 [[],[]] .smaller = true := by decide
def e2419140374190 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))))
theorem wire_e2419140374190 : Closed e2419140374190 ∧ code e2419140374190 = 11215233396398 := by decide
theorem cert_e2419140374190 : check e2419140374190 [[],[]] .smaller = true := by decide
def e2419140374202 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))))
theorem wire_e2419140374202 : Closed e2419140374202 ∧ code e2419140374202 = 11215233396410 := by decide
theorem cert_e2419140374202 : check e2419140374202 [[],[]] .smaller = true := by decide
def e2419140374250 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))))
theorem wire_e2419140374250 : Closed e2419140374250 ∧ code e2419140374250 = 11215233396458 := by decide
theorem cert_e2419140374250 : check e2419140374250 [[],[]] .smaller = true := by decide
def e2419140374358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))))
theorem wire_e2419140374358 : Closed e2419140374358 ∧ code e2419140374358 = 11215233396566 := by decide
theorem cert_e2419140374358 : check e2419140374358 [[],[]] .smaller = true := by decide
def e2419140374362 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))))
theorem wire_e2419140374362 : Closed e2419140374362 ∧ code e2419140374362 = 11215233396570 := by decide
theorem cert_e2419140374362 : check e2419140374362 [[],[]] .smaller = true := by decide
def e2419140374378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))))
theorem wire_e2419140374378 : Closed e2419140374378 ∧ code e2419140374378 = 11215233396586 := by decide
theorem cert_e2419140374378 : check e2419140374378 [[],[]] .smaller = true := by decide
def e2419140375406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))))
theorem wire_e2419140375406 : Closed e2419140375406 ∧ code e2419140375406 = 11215233397614 := by decide
theorem cert_e2419140375406 : check e2419140375406 [[],[]] .smaller = true := by decide
def e2419140375414 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))))
theorem wire_e2419140375414 : Closed e2419140375414 ∧ code e2419140375414 = 11215233397622 := by decide
theorem cert_e2419140375414 : check e2419140375414 [[],[]] .smaller = true := by decide
def e2419140375470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))))
theorem wire_e2419140375470 : Closed e2419140375470 ∧ code e2419140375470 = 11215233397678 := by decide
theorem cert_e2419140375470 : check e2419140375470 [[],[]] .smaller = true := by decide
def e2419140375482 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))))
theorem wire_e2419140375482 : Closed e2419140375482 ∧ code e2419140375482 = 11215233397690 := by decide
theorem cert_e2419140375482 : check e2419140375482 [[],[]] .smaller = true := by decide
def e2419140375510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))))
theorem wire_e2419140375510 : Closed e2419140375510 ∧ code e2419140375510 = 11215233397718 := by decide
theorem cert_e2419140375510 : check e2419140375510 [[],[]] .smaller = true := by decide
def e2419140375514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))))
theorem wire_e2419140375514 : Closed e2419140375514 ∧ code e2419140375514 = 11215233397722 := by decide
theorem cert_e2419140375514 : check e2419140375514 [[],[]] .smaller = true := by decide
def e2419140375790 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))))
theorem wire_e2419140375790 : Closed e2419140375790 ∧ code e2419140375790 = 11215233397998 := by decide
theorem cert_e2419140375790 : check e2419140375790 [[],[]] .smaller = true := by decide
def e2419140375798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))))
theorem wire_e2419140375798 : Closed e2419140375798 ∧ code e2419140375798 = 11215233398006 := by decide
theorem cert_e2419140375798 : check e2419140375798 [[],[]] .smaller = true := by decide
def e2419140376174 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419140376174 : Closed e2419140376174 ∧ code e2419140376174 = 11215233398382 := by decide
theorem cert_e2419140376174 : check e2419140376174 [[],[]] .smaller = true := by decide
def e2419140376186 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419140376186 : Closed e2419140376186 ∧ code e2419140376186 = 11215233398394 := by decide
theorem cert_e2419140376186 : check e2419140376186 [[],[]] .smaller = true := by decide
def e2419140376374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419140376374 : Closed e2419140376374 ∧ code e2419140376374 = 11215233398582 := by decide
theorem cert_e2419140376374 : check e2419140376374 [[],[]] .smaller = true := by decide
def e2419140376378 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419140376378 : Closed e2419140376378 ∧ code e2419140376378 = 11215233398586 := by decide
theorem cert_e2419140376378 : check e2419140376378 [[],[]] .smaller = true := by decide
def e2419140377006 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))))
theorem wire_e2419140377006 : Closed e2419140377006 ∧ code e2419140377006 = 11215233399214 := by decide
theorem cert_e2419140377006 : check e2419140377006 [[],[]] .smaller = true := by decide
def e2419140377018 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))))
theorem wire_e2419140377018 : Closed e2419140377018 ∧ code e2419140377018 = 11215233399226 := by decide
theorem cert_e2419140377018 : check e2419140377018 [[],[]] .smaller = true := by decide
def e2419140377066 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))))
theorem wire_e2419140377066 : Closed e2419140377066 ∧ code e2419140377066 = 11215233399274 := by decide
theorem cert_e2419140377066 : check e2419140377066 [[],[]] .smaller = true := by decide
def e2419140377198 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))))
theorem wire_e2419140377198 : Closed e2419140377198 ∧ code e2419140377198 = 11215233399406 := by decide
theorem cert_e2419140377198 : check e2419140377198 [[],[]] .smaller = true := by decide
def e2419140377210 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))))
theorem wire_e2419140377210 : Closed e2419140377210 ∧ code e2419140377210 = 11215233399418 := by decide
theorem cert_e2419140377210 : check e2419140377210 [[],[]] .smaller = true := by decide
def e2419140377498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419140377498 : Closed e2419140377498 ∧ code e2419140377498 = 11215233399706 := by decide
theorem cert_e2419140377498 : check e2419140377498 [[],[]] .smaller = true := by decide
def e2419140377814 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))))
theorem wire_e2419140377814 : Closed e2419140377814 ∧ code e2419140377814 = 11215233400022 := by decide
theorem cert_e2419140377814 : check e2419140377814 [[],[]] .smaller = true := by decide
def e2419140377818 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))))
theorem wire_e2419140377818 : Closed e2419140377818 ∧ code e2419140377818 = 11215233400026 := by decide
theorem cert_e2419140377818 : check e2419140377818 [[],[]] .smaller = true := by decide
def e2419140377834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))))
theorem wire_e2419140377834 : Closed e2419140377834 ∧ code e2419140377834 = 11215233400042 := by decide
theorem cert_e2419140377834 : check e2419140377834 [[],[]] .smaller = true := by decide
def e2419140377910 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))))
theorem wire_e2419140377910 : Closed e2419140377910 ∧ code e2419140377910 = 11215233400118 := by decide
theorem cert_e2419140377910 : check e2419140377910 [[],[]] .smaller = true := by decide
def e2419140377914 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))))
theorem wire_e2419140377914 : Closed e2419140377914 ∧ code e2419140377914 = 11215233400122 := by decide
theorem cert_e2419140377914 : check e2419140377914 [[],[]] .smaller = true := by decide
def e2419140378010 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))))
theorem wire_e2419140378010 : Closed e2419140378010 ∧ code e2419140378010 = 11215233400218 := by decide
theorem cert_e2419140378010 : check e2419140378010 [[],[]] .smaller = true := by decide
def e2419140381550 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))))
theorem wire_e2419140381550 : Closed e2419140381550 ∧ code e2419140381550 = 11215233403758 := by decide
theorem cert_e2419140381550 : check e2419140381550 [[],[]] .smaller = true := by decide
def e2419140381558 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))))
theorem wire_e2419140381558 : Closed e2419140381558 ∧ code e2419140381558 = 11215233403766 := by decide
theorem cert_e2419140381558 : check e2419140381558 [[],[]] .smaller = true := by decide
def e2419140381614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))))
theorem wire_e2419140381614 : Closed e2419140381614 ∧ code e2419140381614 = 11215233403822 := by decide
theorem cert_e2419140381614 : check e2419140381614 [[],[]] .smaller = true := by decide
def e2419140381626 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))))
theorem wire_e2419140381626 : Closed e2419140381626 ∧ code e2419140381626 = 11215233403834 := by decide
theorem cert_e2419140381626 : check e2419140381626 [[],[]] .smaller = true := by decide
def e2419140381654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))))
theorem wire_e2419140381654 : Closed e2419140381654 ∧ code e2419140381654 = 11215233403862 := by decide
theorem cert_e2419140381654 : check e2419140381654 [[],[]] .smaller = true := by decide
def e2419140381658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))))
theorem wire_e2419140381658 : Closed e2419140381658 ∧ code e2419140381658 = 11215233403866 := by decide
theorem cert_e2419140381658 : check e2419140381658 [[],[]] .smaller = true := by decide
def e2419140381934 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))))
theorem wire_e2419140381934 : Closed e2419140381934 ∧ code e2419140381934 = 11215233404142 := by decide
theorem cert_e2419140381934 : check e2419140381934 [[],[]] .smaller = true := by decide
def e2419140381942 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))))
theorem wire_e2419140381942 : Closed e2419140381942 ∧ code e2419140381942 = 11215233404150 := by decide
theorem cert_e2419140381942 : check e2419140381942 [[],[]] .smaller = true := by decide
def e2419140382318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2419140382318 : Closed e2419140382318 ∧ code e2419140382318 = 11215233404526 := by decide
theorem cert_e2419140382318 : check e2419140382318 [[],[]] .smaller = true := by decide
def e2419140382330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2419140382330 : Closed e2419140382330 ∧ code e2419140382330 = 11215233404538 := by decide
theorem cert_e2419140382330 : check e2419140382330 [[],[]] .smaller = true := by decide
def e2419140382518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2419140382518 : Closed e2419140382518 ∧ code e2419140382518 = 11215233404726 := by decide
theorem cert_e2419140382518 : check e2419140382518 [[],[]] .smaller = true := by decide
def e2419140382522 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2419140382522 : Closed e2419140382522 ∧ code e2419140382522 = 11215233404730 := by decide
theorem cert_e2419140382522 : check e2419140382522 [[],[]] .smaller = true := by decide
def e2419140388270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))))
theorem wire_e2419140388270 : Closed e2419140388270 ∧ code e2419140388270 = 11215233410478 := by decide
theorem cert_e2419140388270 : check e2419140388270 [[],[]] .smaller = true := by decide
def e2419140388282 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))))
theorem wire_e2419140388282 : Closed e2419140388282 ∧ code e2419140388282 = 11215233410490 := by decide
theorem cert_e2419140388282 : check e2419140388282 [[],[]] .smaller = true := by decide
def e2419140388330 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))))
theorem wire_e2419140388330 : Closed e2419140388330 ∧ code e2419140388330 = 11215233410538 := by decide
theorem cert_e2419140388330 : check e2419140388330 [[],[]] .smaller = true := by decide
def e2419140388462 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))))
theorem wire_e2419140388462 : Closed e2419140388462 ∧ code e2419140388462 = 11215233410670 := by decide
theorem cert_e2419140388462 : check e2419140388462 [[],[]] .smaller = true := by decide
def e2419140388474 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))))
theorem wire_e2419140388474 : Closed e2419140388474 ∧ code e2419140388474 = 11215233410682 := by decide
theorem cert_e2419140388474 : check e2419140388474 [[],[]] .smaller = true := by decide
def e2419140388762 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2419140388762 : Closed e2419140388762 ∧ code e2419140388762 = 11215233410970 := by decide
theorem cert_e2419140388762 : check e2419140388762 [[],[]] .smaller = true := by decide
def e2419140391638 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))))
theorem wire_e2419140391638 : Closed e2419140391638 ∧ code e2419140391638 = 11215233413846 := by decide
theorem cert_e2419140391638 : check e2419140391638 [[],[]] .smaller = true := by decide
def e2419140391642 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))))
theorem wire_e2419140391642 : Closed e2419140391642 ∧ code e2419140391642 = 11215233413850 := by decide
theorem cert_e2419140391642 : check e2419140391642 [[],[]] .smaller = true := by decide
def e2419140391658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))))
theorem wire_e2419140391658 : Closed e2419140391658 ∧ code e2419140391658 = 11215233413866 := by decide
theorem cert_e2419140391658 : check e2419140391658 [[],[]] .smaller = true := by decide
def e2419140391734 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))))
theorem wire_e2419140391734 : Closed e2419140391734 ∧ code e2419140391734 = 11215233413942 := by decide
theorem cert_e2419140391734 : check e2419140391734 [[],[]] .smaller = true := by decide
def e2419140391738 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))))
theorem wire_e2419140391738 : Closed e2419140391738 ∧ code e2419140391738 = 11215233413946 := by decide
theorem cert_e2419140391738 : check e2419140391738 [[],[]] .smaller = true := by decide
def e2419140391834 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))))
theorem wire_e2419140391834 : Closed e2419140391834 ∧ code e2419140391834 = 11215233414042 := by decide
theorem cert_e2419140391834 : check e2419140391834 [[],[]] .smaller = true := by decide
def e2419140507070 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 4))))))))
theorem wire_e2419140507070 : Closed e2419140507070 ∧ code e2419140507070 = 11215233529278 := by decide
theorem cert_e2419140507070 : check e2419140507070 [[],[]] .three = true := by decide
def e2419140507102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))))
theorem wire_e2419140507102 : Closed e2419140507102 ∧ code e2419140507102 = 11215233529310 := by decide
theorem cert_e2419140507102 : check e2419140507102 [[],[]] .smaller = true := by decide
def e2419140507118 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))))
theorem wire_e2419140507118 : Closed e2419140507118 ∧ code e2419140507118 = 11215233529326 := by decide
theorem cert_e2419140507118 : check e2419140507118 [[],[]] .smaller = true := by decide
def e2419140507126 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 4)) (.var 1))))))))
theorem wire_e2419140507126 : Closed e2419140507126 ∧ code e2419140507126 = 11215233529334 := by decide
theorem cert_e2419140507126 : check e2419140507126 [[],[]] .three = true := by decide
def e2419140507326 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 4))))))))
theorem wire_e2419140507326 : Closed e2419140507326 ∧ code e2419140507326 = 11215233529534 := by decide
theorem cert_e2419140507326 : check e2419140507326 [[],[]] .three = true := by decide
def e2419140507358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))))
theorem wire_e2419140507358 : Closed e2419140507358 ∧ code e2419140507358 = 11215233529566 := by decide
theorem cert_e2419140507358 : check e2419140507358 [[],[]] .smaller = true := by decide
def e2419140507374 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))))
theorem wire_e2419140507374 : Closed e2419140507374 ∧ code e2419140507374 = 11215233529582 := by decide
theorem cert_e2419140507374 : check e2419140507374 [[],[]] .smaller = true := by decide
def e2419140507382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))))
theorem wire_e2419140507382 : Closed e2419140507382 ∧ code e2419140507382 = 11215233529590 := by decide
theorem cert_e2419140507382 : check e2419140507382 [[],[]] .smaller = true := by decide
def e2419140507386 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 4)) (.var 0))))))))
theorem wire_e2419140507386 : Closed e2419140507386 ∧ code e2419140507386 = 11215233529594 := by decide
theorem cert_e2419140507386 : check e2419140507386 [[],[]] .three = true := by decide
def e2419140507486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))))
theorem wire_e2419140507486 : Closed e2419140507486 ∧ code e2419140507486 = 11215233529694 := by decide
theorem cert_e2419140507486 : check e2419140507486 [[],[]] .smaller = true := by decide
def e2419140507502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))))
theorem wire_e2419140507502 : Closed e2419140507502 ∧ code e2419140507502 = 11215233529710 := by decide
theorem cert_e2419140507502 : check e2419140507502 [[],[]] .smaller = true := by decide
def e2419140507510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))))
theorem wire_e2419140507510 : Closed e2419140507510 ∧ code e2419140507510 = 11215233529718 := by decide
theorem cert_e2419140507510 : check e2419140507510 [[],[]] .smaller = true := by decide
def e2419140507514 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))))
theorem wire_e2419140507514 : Closed e2419140507514 ∧ code e2419140507514 = 11215233529722 := by decide
theorem cert_e2419140507514 : check e2419140507514 [[],[]] .smaller = true := by decide
def e2419140507566 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))))
theorem wire_e2419140507566 : Closed e2419140507566 ∧ code e2419140507566 = 11215233529774 := by decide
theorem cert_e2419140507566 : check e2419140507566 [[],[]] .smaller = true := by decide
def e2419140507574 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))))
theorem wire_e2419140507574 : Closed e2419140507574 ∧ code e2419140507574 = 11215233529782 := by decide
theorem cert_e2419140507574 : check e2419140507574 [[],[]] .smaller = true := by decide
def e2419140507578 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))))
theorem wire_e2419140507578 : Closed e2419140507578 ∧ code e2419140507578 = 11215233529786 := by decide
theorem cert_e2419140507578 : check e2419140507578 [[],[]] .smaller = true := by decide
def e2419140507606 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 0)) (.var 1))))))))
theorem wire_e2419140507606 : Closed e2419140507606 ∧ code e2419140507606 = 11215233529814 := by decide
theorem cert_e2419140507606 : check e2419140507606 [[],[]] .three = true := by decide
def e2419140507610 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 4)) (.var 1)) (.var 0))))))))
theorem wire_e2419140507610 : Closed e2419140507610 ∧ code e2419140507610 = 11215233529818 := by decide
theorem cert_e2419140507610 : check e2419140507610 [[],[]] .three = true := by decide
def e2419140508350 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 4))))))))
theorem wire_e2419140508350 : Closed e2419140508350 ∧ code e2419140508350 = 11215233530558 := by decide
theorem cert_e2419140508350 : check e2419140508350 [[],[]] .three = true := by decide
def e2419140508382 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e2419140508382 : Closed e2419140508382 ∧ code e2419140508382 = 11215233530590 := by decide
theorem cert_e2419140508382 : check e2419140508382 [[],[]] .smaller = true := by decide
def e2419140508398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))))
theorem wire_e2419140508398 : Closed e2419140508398 ∧ code e2419140508398 = 11215233530606 := by decide
theorem cert_e2419140508398 : check e2419140508398 [[],[]] .smaller = true := by decide
def e2419140508406 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e2419140508406 : Closed e2419140508406 ∧ code e2419140508406 = 11215233530614 := by decide
theorem cert_e2419140508406 : check e2419140508406 [[],[]] .smaller = true := by decide
def e2419140508410 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 4)) (.var 0))))))))
theorem wire_e2419140508410 : Closed e2419140508410 ∧ code e2419140508410 = 11215233530618 := by decide
theorem cert_e2419140508410 : check e2419140508410 [[],[]] .three = true := by decide
def e2419140508510 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e2419140508510 : Closed e2419140508510 ∧ code e2419140508510 = 11215233530718 := by decide
theorem cert_e2419140508510 : check e2419140508510 [[],[]] .smaller = true := by decide
def e2419140508538 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e2419140508538 : Closed e2419140508538 ∧ code e2419140508538 = 11215233530746 := by decide
theorem cert_e2419140508538 : check e2419140508538 [[],[]] .smaller = true := by decide
def e2419140508590 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))))
theorem wire_e2419140508590 : Closed e2419140508590 ∧ code e2419140508590 = 11215233530798 := by decide
theorem cert_e2419140508590 : check e2419140508590 [[],[]] .smaller = true := by decide
def e2419140508602 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))))
theorem wire_e2419140508602 : Closed e2419140508602 ∧ code e2419140508602 = 11215233530810 := by decide
theorem cert_e2419140508602 : check e2419140508602 [[],[]] .smaller = true := by decide
def e2419140508630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e2419140508630 : Closed e2419140508630 ∧ code e2419140508630 = 11215233530838 := by decide
theorem cert_e2419140508630 : check e2419140508630 [[],[]] .smaller = true := by decide
def e2419140508634 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e2419140508634 : Closed e2419140508634 ∧ code e2419140508634 = 11215233530842 := by decide
theorem cert_e2419140508634 : check e2419140508634 [[],[]] .smaller = true := by decide
def e2419140508650 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 4)) (.var 0)) (.var 0))))))))
theorem wire_e2419140508650 : Closed e2419140508650 ∧ code e2419140508650 = 11215233530858 := by decide
theorem cert_e2419140508650 : check e2419140508650 [[],[]] .three = true := by decide
def e2419140509022 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e2419140509022 : Closed e2419140509022 ∧ code e2419140509022 = 11215233531230 := by decide
theorem cert_e2419140509022 : check e2419140509022 [[],[]] .smaller = true := by decide
def e2419140509038 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e2419140509038 : Closed e2419140509038 ∧ code e2419140509038 = 11215233531246 := by decide
theorem cert_e2419140509038 : check e2419140509038 [[],[]] .smaller = true := by decide
def e2419140509046 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e2419140509046 : Closed e2419140509046 ∧ code e2419140509046 = 11215233531254 := by decide
theorem cert_e2419140509046 : check e2419140509046 [[],[]] .smaller = true := by decide
def e2419140509050 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e2419140509050 : Closed e2419140509050 ∧ code e2419140509050 = 11215233531258 := by decide
theorem cert_e2419140509050 : check e2419140509050 [[],[]] .smaller = true := by decide
def e2419140509102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e2419140509102 : Closed e2419140509102 ∧ code e2419140509102 = 11215233531310 := by decide
theorem cert_e2419140509102 : check e2419140509102 [[],[]] .smaller = true := by decide
def e2419140509114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e2419140509114 : Closed e2419140509114 ∧ code e2419140509114 = 11215233531322 := by decide
theorem cert_e2419140509114 : check e2419140509114 [[],[]] .smaller = true := by decide
def e2419140509142 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e2419140509142 : Closed e2419140509142 ∧ code e2419140509142 = 11215233531350 := by decide
theorem cert_e2419140509142 : check e2419140509142 [[],[]] .smaller = true := by decide
def e2419140509146 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e2419140509146 : Closed e2419140509146 ∧ code e2419140509146 = 11215233531354 := by decide
theorem cert_e2419140509146 : check e2419140509146 [[],[]] .smaller = true := by decide
def e2419140509162 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e2419140509162 : Closed e2419140509162 ∧ code e2419140509162 = 11215233531370 := by decide
theorem cert_e2419140509162 : check e2419140509162 [[],[]] .smaller = true := by decide
def e2419140509358 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))))
theorem wire_e2419140509358 : Closed e2419140509358 ∧ code e2419140509358 = 11215233531566 := by decide
theorem cert_e2419140509358 : check e2419140509358 [[],[]] .smaller = true := by decide
def e2419140509366 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e2419140509366 : Closed e2419140509366 ∧ code e2419140509366 = 11215233531574 := by decide
theorem cert_e2419140509366 : check e2419140509366 [[],[]] .smaller = true := by decide
def e2419140509370 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))))
theorem wire_e2419140509370 : Closed e2419140509370 ∧ code e2419140509370 = 11215233531578 := by decide
theorem cert_e2419140509370 : check e2419140509370 [[],[]] .smaller = true := by decide
def e2419140509398 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e2419140509398 : Closed e2419140509398 ∧ code e2419140509398 = 11215233531606 := by decide
theorem cert_e2419140509398 : check e2419140509398 [[],[]] .smaller = true := by decide
def e2419140509402 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e2419140509402 : Closed e2419140509402 ∧ code e2419140509402 = 11215233531610 := by decide
theorem cert_e2419140509402 : check e2419140509402 [[],[]] .smaller = true := by decide
def e2419140509418 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))))
theorem wire_e2419140509418 : Closed e2419140509418 ∧ code e2419140509418 = 11215233531626 := by decide
theorem cert_e2419140509418 : check e2419140509418 [[],[]] .smaller = true := by decide
def e2419140509526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e2419140509526 : Closed e2419140509526 ∧ code e2419140509526 = 11215233531734 := by decide
theorem cert_e2419140509526 : check e2419140509526 [[],[]] .three = true := by decide
def e2419140509530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e2419140509530 : Closed e2419140509530 ∧ code e2419140509530 = 11215233531738 := by decide
theorem cert_e2419140509530 : check e2419140509530 [[],[]] .three = true := by decide
def e2419140509546 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 4) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e2419140509546 : Closed e2419140509546 ∧ code e2419140509546 = 11215233531754 := by decide
theorem cert_e2419140509546 : check e2419140509546 [[],[]] .three = true := by decide
def e2419140513214 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 4))))))))
theorem wire_e2419140513214 : Closed e2419140513214 ∧ code e2419140513214 = 11215233535422 := by decide
theorem cert_e2419140513214 : check e2419140513214 [[],[]] .three = true := by decide
def e2419140513246 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))))
theorem wire_e2419140513246 : Closed e2419140513246 ∧ code e2419140513246 = 11215233535454 := by decide
theorem cert_e2419140513246 : check e2419140513246 [[],[]] .smaller = true := by decide
def e2419140513262 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))))
theorem wire_e2419140513262 : Closed e2419140513262 ∧ code e2419140513262 = 11215233535470 := by decide
theorem cert_e2419140513262 : check e2419140513262 [[],[]] .smaller = true := by decide
def e2419140513270 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 4))) (.var 1))))))))
theorem wire_e2419140513270 : Closed e2419140513270 ∧ code e2419140513270 = 11215233535478 := by decide
theorem cert_e2419140513270 : check e2419140513270 [[],[]] .three = true := by decide
def e2419140513470 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 4))))))))
theorem wire_e2419140513470 : Closed e2419140513470 ∧ code e2419140513470 = 11215233535678 := by decide
theorem cert_e2419140513470 : check e2419140513470 [[],[]] .three = true := by decide
def e2419140513502 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))))
theorem wire_e2419140513502 : Closed e2419140513502 ∧ code e2419140513502 = 11215233535710 := by decide
theorem cert_e2419140513502 : check e2419140513502 [[],[]] .smaller = true := by decide
def e2419140513518 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))))
theorem wire_e2419140513518 : Closed e2419140513518 ∧ code e2419140513518 = 11215233535726 := by decide
theorem cert_e2419140513518 : check e2419140513518 [[],[]] .smaller = true := by decide
def e2419140513526 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))))
theorem wire_e2419140513526 : Closed e2419140513526 ∧ code e2419140513526 = 11215233535734 := by decide
theorem cert_e2419140513526 : check e2419140513526 [[],[]] .smaller = true := by decide
def e2419140513530 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 4))) (.var 0))))))))
theorem wire_e2419140513530 : Closed e2419140513530 ∧ code e2419140513530 = 11215233535738 := by decide
theorem cert_e2419140513530 : check e2419140513530 [[],[]] .three = true := by decide
def e2419140513630 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))))
theorem wire_e2419140513630 : Closed e2419140513630 ∧ code e2419140513630 = 11215233535838 := by decide
theorem cert_e2419140513630 : check e2419140513630 [[],[]] .smaller = true := by decide
def e2419140513646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))))
theorem wire_e2419140513646 : Closed e2419140513646 ∧ code e2419140513646 = 11215233535854 := by decide
theorem cert_e2419140513646 : check e2419140513646 [[],[]] .smaller = true := by decide
def e2419140513654 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))))
theorem wire_e2419140513654 : Closed e2419140513654 ∧ code e2419140513654 = 11215233535862 := by decide
theorem cert_e2419140513654 : check e2419140513654 [[],[]] .smaller = true := by decide
def e2419140513658 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))))
theorem wire_e2419140513658 : Closed e2419140513658 ∧ code e2419140513658 = 11215233535866 := by decide
theorem cert_e2419140513658 : check e2419140513658 [[],[]] .smaller = true := by decide
def e2419140513710 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))))
theorem wire_e2419140513710 : Closed e2419140513710 ∧ code e2419140513710 = 11215233535918 := by decide
theorem cert_e2419140513710 : check e2419140513710 [[],[]] .smaller = true := by decide
def e2419140513718 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))))
theorem wire_e2419140513718 : Closed e2419140513718 ∧ code e2419140513718 = 11215233535926 := by decide
theorem cert_e2419140513718 : check e2419140513718 [[],[]] .smaller = true := by decide
def e2419140513722 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))))
theorem wire_e2419140513722 : Closed e2419140513722 ∧ code e2419140513722 = 11215233535930 := by decide
theorem cert_e2419140513722 : check e2419140513722 [[],[]] .smaller = true := by decide
def e2419140513750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 0))) (.var 1))))))))
theorem wire_e2419140513750 : Closed e2419140513750 ∧ code e2419140513750 = 11215233535958 := by decide
theorem cert_e2419140513750 : check e2419140513750 [[],[]] .three = true := by decide
def e2419140513754 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 4) (.var 1))) (.var 0))))))))
theorem wire_e2419140513754 : Closed e2419140513754 ∧ code e2419140513754 = 11215233535962 := by decide
theorem cert_e2419140513754 : check e2419140513754 [[],[]] .three = true := by decide
def e2419140514750 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 4)))))))))
theorem wire_e2419140514750 : Closed e2419140514750 ∧ code e2419140514750 = 11215233536958 := by decide
theorem cert_e2419140514750 : check e2419140514750 [[],[]] .three = true := by decide
def e2419140514782 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))))
theorem wire_e2419140514782 : Closed e2419140514782 ∧ code e2419140514782 = 11215233536990 := by decide
theorem cert_e2419140514782 : check e2419140514782 [[],[]] .smaller = true := by decide
def e2419140514798 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))))
theorem wire_e2419140514798 : Closed e2419140514798 ∧ code e2419140514798 = 11215233537006 := by decide
theorem cert_e2419140514798 : check e2419140514798 [[],[]] .smaller = true := by decide
def e2419140514806 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 4) (.var 1)))))))))
theorem wire_e2419140514806 : Closed e2419140514806 ∧ code e2419140514806 = 11215233537014 := by decide
theorem cert_e2419140514806 : check e2419140514806 [[],[]] .three = true := by decide
def e2419140516286 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 4)))))))))
theorem wire_e2419140516286 : Closed e2419140516286 ∧ code e2419140516286 = 11215233538494 := by decide
theorem cert_e2419140516286 : check e2419140516286 [[],[]] .three = true := by decide
def e2419140516318 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))))
theorem wire_e2419140516318 : Closed e2419140516318 ∧ code e2419140516318 = 11215233538526 := by decide
theorem cert_e2419140516318 : check e2419140516318 [[],[]] .smaller = true := by decide
def e2419140516334 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))))
theorem wire_e2419140516334 : Closed e2419140516334 ∧ code e2419140516334 = 11215233538542 := by decide
theorem cert_e2419140516334 : check e2419140516334 [[],[]] .smaller = true := by decide
def e2419140516342 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))))
theorem wire_e2419140516342 : Closed e2419140516342 ∧ code e2419140516342 = 11215233538550 := by decide
theorem cert_e2419140516342 : check e2419140516342 [[],[]] .smaller = true := by decide
def e2419140516346 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 4) (.var 0)))))))))
theorem wire_e2419140516346 : Closed e2419140516346 ∧ code e2419140516346 = 11215233538554 := by decide
theorem cert_e2419140516346 : check e2419140516346 [[],[]] .three = true := by decide
def e2419140517086 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))))
theorem wire_e2419140517086 : Closed e2419140517086 ∧ code e2419140517086 = 11215233539294 := by decide
theorem cert_e2419140517086 : check e2419140517086 [[],[]] .smaller = true := by decide
def e2419140517102 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))))
theorem wire_e2419140517102 : Closed e2419140517102 ∧ code e2419140517102 = 11215233539310 := by decide
theorem cert_e2419140517102 : check e2419140517102 [[],[]] .smaller = true := by decide
def e2419140517110 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))))
theorem wire_e2419140517110 : Closed e2419140517110 ∧ code e2419140517110 = 11215233539318 := by decide
theorem cert_e2419140517110 : check e2419140517110 [[],[]] .smaller = true := by decide
def e2419140517114 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))))
theorem wire_e2419140517114 : Closed e2419140517114 ∧ code e2419140517114 = 11215233539322 := by decide
theorem cert_e2419140517114 : check e2419140517114 [[],[]] .smaller = true := by decide
def e2419140517486 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))))
theorem wire_e2419140517486 : Closed e2419140517486 ∧ code e2419140517486 = 11215233539694 := by decide
theorem cert_e2419140517486 : check e2419140517486 [[],[]] .smaller = true := by decide
def e2419140517494 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))))
theorem wire_e2419140517494 : Closed e2419140517494 ∧ code e2419140517494 = 11215233539702 := by decide
theorem cert_e2419140517494 : check e2419140517494 [[],[]] .smaller = true := by decide
def e2419140517498 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))))
theorem wire_e2419140517498 : Closed e2419140517498 ∧ code e2419140517498 = 11215233539706 := by decide
theorem cert_e2419140517498 : check e2419140517498 [[],[]] .smaller = true := by decide
def e2419140517686 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 0) (.var 1)))))))))
theorem wire_e2419140517686 : Closed e2419140517686 ∧ code e2419140517686 = 11215233539894 := by decide
theorem cert_e2419140517686 : check e2419140517686 [[],[]] .three = true := by decide
def e2419140517690 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 4)) (.app (.var 1) (.var 0)))))))))
theorem wire_e2419140517690 : Closed e2419140517690 ∧ code e2419140517690 = 11215233539898 := by decide
theorem cert_e2419140517690 : check e2419140517690 [[],[]] .three = true := by decide
def e2419140519614 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 4))))))))
theorem wire_e2419140519614 : Closed e2419140519614 ∧ code e2419140519614 = 11215233541822 := by decide
theorem cert_e2419140519614 : check e2419140519614 [[],[]] .three = true := by decide
def e2419140519646 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e2419140519646 : Closed e2419140519646 ∧ code e2419140519646 = 11215233541854 := by decide
theorem cert_e2419140519646 : check e2419140519646 [[],[]] .smaller = true := by decide
def e2419140519662 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))))
theorem wire_e2419140519662 : Closed e2419140519662 ∧ code e2419140519662 = 11215233541870 := by decide
theorem cert_e2419140519662 : check e2419140519662 [[],[]] .smaller = true := by decide
def e2419140519670 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e2419140519670 : Closed e2419140519670 ∧ code e2419140519670 = 11215233541878 := by decide
theorem cert_e2419140519670 : check e2419140519670 [[],[]] .smaller = true := by decide
def e2419140519674 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 4))) (.var 0))))))))
theorem wire_e2419140519674 : Closed e2419140519674 ∧ code e2419140519674 = 11215233541882 := by decide
theorem cert_e2419140519674 : check e2419140519674 [[],[]] .three = true := by decide
def e2419140519774 : Term := (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e2419140519774 : Closed e2419140519774 ∧ code e2419140519774 = 11215233541982 := by decide
theorem cert_e2419140519774 : check e2419140519774 [[],[]] .smaller = true := by decide
end Blc.Floor43
