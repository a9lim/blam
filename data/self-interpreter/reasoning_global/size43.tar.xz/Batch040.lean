import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e611546352494 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e611546352494 : Closed e611546352494 ∧ code e611546352494 = 9407639374702 := by decide
theorem cert_e611546352494 : check e611546352494 [[.under]] .sourceHead = true := by decide
def e611546352502 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e611546352502 : Closed e611546352502 ∧ code e611546352502 = 9407639374710 := by decide
theorem cert_e611546352502 : check e611546352502 [[.under]] .sourceHead = true := by decide
def e611546352558 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e611546352558 : Closed e611546352558 ∧ code e611546352558 = 9407639374766 := by decide
theorem cert_e611546352558 : check e611546352558 [[.under]] .sourceHead = true := by decide
def e611546352570 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e611546352570 : Closed e611546352570 ∧ code e611546352570 = 9407639374778 := by decide
theorem cert_e611546352570 : check e611546352570 [[.under]] .sourceHead = true := by decide
def e611546352598 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e611546352598 : Closed e611546352598 ∧ code e611546352598 = 9407639374806 := by decide
theorem cert_e611546352598 : check e611546352598 [[.under]] .sourceHead = true := by decide
def e611546352602 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e611546352602 : Closed e611546352602 ∧ code e611546352602 = 9407639374810 := by decide
theorem cert_e611546352602 : check e611546352602 [[.under]] .sourceHead = true := by decide
def e611546352878 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e611546352878 : Closed e611546352878 ∧ code e611546352878 = 9407639375086 := by decide
theorem cert_e611546352878 : check e611546352878 [[.under]] .sourceHead = true := by decide
def e611546352886 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e611546352886 : Closed e611546352886 ∧ code e611546352886 = 9407639375094 := by decide
theorem cert_e611546352886 : check e611546352886 [[.under]] .sourceHead = true := by decide
def e611546353262 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e611546353262 : Closed e611546353262 ∧ code e611546353262 = 9407639375470 := by decide
theorem cert_e611546353262 : check e611546353262 [[.under]] .sourceHead = true := by decide
def e611546353274 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e611546353274 : Closed e611546353274 ∧ code e611546353274 = 9407639375482 := by decide
theorem cert_e611546353274 : check e611546353274 [[.under]] .sourceHead = true := by decide
def e611546353462 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e611546353462 : Closed e611546353462 ∧ code e611546353462 = 9407639375670 := by decide
theorem cert_e611546353462 : check e611546353462 [[.under]] .sourceHead = true := by decide
def e611546353466 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e611546353466 : Closed e611546353466 ∧ code e611546353466 = 9407639375674 := by decide
theorem cert_e611546353466 : check e611546353466 [[.under]] .sourceHead = true := by decide
def e611546359214 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e611546359214 : Closed e611546359214 ∧ code e611546359214 = 9407639381422 := by decide
theorem cert_e611546359214 : check e611546359214 [[.under]] .sourceHead = true := by decide
def e611546359226 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e611546359226 : Closed e611546359226 ∧ code e611546359226 = 9407639381434 := by decide
theorem cert_e611546359226 : check e611546359226 [[.under]] .sourceHead = true := by decide
def e611546359274 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e611546359274 : Closed e611546359274 ∧ code e611546359274 = 9407639381482 := by decide
theorem cert_e611546359274 : check e611546359274 [[.under]] .sourceHead = true := by decide
def e611546359406 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e611546359406 : Closed e611546359406 ∧ code e611546359406 = 9407639381614 := by decide
theorem cert_e611546359406 : check e611546359406 [[.under]] .sourceHead = true := by decide
def e611546359418 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e611546359418 : Closed e611546359418 ∧ code e611546359418 = 9407639381626 := by decide
theorem cert_e611546359418 : check e611546359418 [[.under]] .sourceHead = true := by decide
def e611546359706 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e611546359706 : Closed e611546359706 ∧ code e611546359706 = 9407639381914 := by decide
theorem cert_e611546359706 : check e611546359706 [[.under]] .sourceHead = true := by decide
def e611546362582 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e611546362582 : Closed e611546362582 ∧ code e611546362582 = 9407639384790 := by decide
theorem cert_e611546362582 : check e611546362582 [[.under]] .sourceHead = true := by decide
def e611546362586 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e611546362586 : Closed e611546362586 ∧ code e611546362586 = 9407639384794 := by decide
theorem cert_e611546362586 : check e611546362586 [[.under]] .sourceHead = true := by decide
def e611546362602 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e611546362602 : Closed e611546362602 ∧ code e611546362602 = 9407639384810 := by decide
theorem cert_e611546362602 : check e611546362602 [[.under]] .sourceHead = true := by decide
def e611546362678 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e611546362678 : Closed e611546362678 ∧ code e611546362678 = 9407639384886 := by decide
theorem cert_e611546362678 : check e611546362678 [[.under]] .sourceHead = true := by decide
def e611546362682 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e611546362682 : Closed e611546362682 ∧ code e611546362682 = 9407639384890 := by decide
theorem cert_e611546362682 : check e611546362682 [[.under]] .sourceHead = true := by decide
def e611546362778 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e611546362778 : Closed e611546362778 ∧ code e611546362778 = 9407639384986 := by decide
theorem cert_e611546362778 : check e611546362778 [[.under]] .sourceHead = true := by decide
def e611546499950 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e611546499950 : Closed e611546499950 ∧ code e611546499950 = 9407639522158 := by decide
theorem cert_e611546499950 : check e611546499950 [[.under]] .sourceHead = true := by decide
def e611546499958 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e611546499958 : Closed e611546499958 ∧ code e611546499958 = 9407639522166 := by decide
theorem cert_e611546499958 : check e611546499958 [[.under]] .sourceHead = true := by decide
def e611546500014 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e611546500014 : Closed e611546500014 ∧ code e611546500014 = 9407639522222 := by decide
theorem cert_e611546500014 : check e611546500014 [[.under]] .sourceHead = true := by decide
def e611546500026 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e611546500026 : Closed e611546500026 ∧ code e611546500026 = 9407639522234 := by decide
theorem cert_e611546500026 : check e611546500026 [[.under]] .sourceHead = true := by decide
def e611546500054 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e611546500054 : Closed e611546500054 ∧ code e611546500054 = 9407639522262 := by decide
theorem cert_e611546500054 : check e611546500054 [[.under]] .sourceHead = true := by decide
def e611546500058 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e611546500058 : Closed e611546500058 ∧ code e611546500058 = 9407639522266 := by decide
theorem cert_e611546500058 : check e611546500058 [[.under]] .sourceHead = true := by decide
def e611546500334 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e611546500334 : Closed e611546500334 ∧ code e611546500334 = 9407639522542 := by decide
theorem cert_e611546500334 : check e611546500334 [[.under]] .sourceHead = true := by decide
def e611546500342 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e611546500342 : Closed e611546500342 ∧ code e611546500342 = 9407639522550 := by decide
theorem cert_e611546500342 : check e611546500342 [[.under]] .sourceHead = true := by decide
def e611546500718 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e611546500718 : Closed e611546500718 ∧ code e611546500718 = 9407639522926 := by decide
theorem cert_e611546500718 : check e611546500718 [[.under]] .sourceHead = true := by decide
def e611546500730 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e611546500730 : Closed e611546500730 ∧ code e611546500730 = 9407639522938 := by decide
theorem cert_e611546500730 : check e611546500730 [[.under]] .sourceHead = true := by decide
def e611546500918 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e611546500918 : Closed e611546500918 ∧ code e611546500918 = 9407639523126 := by decide
theorem cert_e611546500918 : check e611546500918 [[.under]] .sourceHead = true := by decide
def e611546500922 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e611546500922 : Closed e611546500922 ∧ code e611546500922 = 9407639523130 := by decide
theorem cert_e611546500922 : check e611546500922 [[.under]] .sourceHead = true := by decide
def e611547089774 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e611547089774 : Closed e611547089774 ∧ code e611547089774 = 9407640111982 := by decide
theorem cert_e611547089774 : check e611547089774 [[.under]] .sourceHead = true := by decide
def e611547089782 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e611547089782 : Closed e611547089782 ∧ code e611547089782 = 9407640111990 := by decide
theorem cert_e611547089782 : check e611547089782 [[.under]] .sourceHead = true := by decide
def e611547089838 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e611547089838 : Closed e611547089838 ∧ code e611547089838 = 9407640112046 := by decide
theorem cert_e611547089838 : check e611547089838 [[.under]] .sourceHead = true := by decide
def e611547089850 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e611547089850 : Closed e611547089850 ∧ code e611547089850 = 9407640112058 := by decide
theorem cert_e611547089850 : check e611547089850 [[.under]] .sourceHead = true := by decide
def e611547089878 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e611547089878 : Closed e611547089878 ∧ code e611547089878 = 9407640112086 := by decide
theorem cert_e611547089878 : check e611547089878 [[.under]] .sourceHead = true := by decide
def e611547089882 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e611547089882 : Closed e611547089882 ∧ code e611547089882 = 9407640112090 := by decide
theorem cert_e611547089882 : check e611547089882 [[.under]] .sourceHead = true := by decide
def e611547090158 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e611547090158 : Closed e611547090158 ∧ code e611547090158 = 9407640112366 := by decide
theorem cert_e611547090158 : check e611547090158 [[.under]] .sourceHead = true := by decide
def e611547090166 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e611547090166 : Closed e611547090166 ∧ code e611547090166 = 9407640112374 := by decide
theorem cert_e611547090166 : check e611547090166 [[.under]] .sourceHead = true := by decide
def e611547090542 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e611547090542 : Closed e611547090542 ∧ code e611547090542 = 9407640112750 := by decide
theorem cert_e611547090542 : check e611547090542 [[.under]] .sourceHead = true := by decide
def e611547090554 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e611547090554 : Closed e611547090554 ∧ code e611547090554 = 9407640112762 := by decide
theorem cert_e611547090554 : check e611547090554 [[.under]] .sourceHead = true := by decide
def e611547090742 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e611547090742 : Closed e611547090742 ∧ code e611547090742 = 9407640112950 := by decide
theorem cert_e611547090742 : check e611547090742 [[.under]] .sourceHead = true := by decide
def e611547090746 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 1))))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e611547090746 : Closed e611547090746 ∧ code e611547090746 = 9407640112954 := by decide
theorem cert_e611547090746 : check e611547090746 [[.under]] .sourceHead = true := by decide
def e611630275294 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 3))))))))
theorem wire_e611630275294 : Closed e611630275294 ∧ code e611630275294 = 9407723297502 := by decide
theorem cert_e611630275294 : check e611630275294 [[.under]] .sourceHead = true := by decide
def e611630275318 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 1))))))))
theorem wire_e611630275318 : Closed e611630275318 ∧ code e611630275318 = 9407723297526 := by decide
theorem cert_e611630275318 : check e611630275318 [[.under]] .sourceHead = true := by decide
def e611630275422 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 3))))))))
theorem wire_e611630275422 : Closed e611630275422 ∧ code e611630275422 = 9407723297630 := by decide
theorem cert_e611630275422 : check e611630275422 [[.under]] .sourceHead = true := by decide
def e611630275438 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 2))))))))
theorem wire_e611630275438 : Closed e611630275438 ∧ code e611630275438 = 9407723297646 := by decide
theorem cert_e611630275438 : check e611630275438 [[.under]] .sourceHead = true := by decide
def e611630275446 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 1))))))))
theorem wire_e611630275446 : Closed e611630275446 ∧ code e611630275446 = 9407723297654 := by decide
theorem cert_e611630275446 : check e611630275446 [[.under]] .sourceHead = true := by decide
def e611630275450 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 0))))))))
theorem wire_e611630275450 : Closed e611630275450 ∧ code e611630275450 = 9407723297658 := by decide
theorem cert_e611630275450 : check e611630275450 [[.under]] .sourceHead = true := by decide
def e611630275510 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 1))))))))
theorem wire_e611630275510 : Closed e611630275510 ∧ code e611630275510 = 9407723297718 := by decide
theorem cert_e611630275510 : check e611630275510 [[.under]] .sourceHead = true := by decide
def e611630275542 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 1))))))))
theorem wire_e611630275542 : Closed e611630275542 ∧ code e611630275542 = 9407723297750 := by decide
theorem cert_e611630275542 : check e611630275542 [[.under]] .sourceHead = true := by decide
def e611630275546 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 0))))))))
theorem wire_e611630275546 : Closed e611630275546 ∧ code e611630275546 = 9407723297754 := by decide
theorem cert_e611630275546 : check e611630275546 [[.under]] .sourceHead = true := by decide
def e611630275934 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 3))))))))
theorem wire_e611630275934 : Closed e611630275934 ∧ code e611630275934 = 9407723298142 := by decide
theorem cert_e611630275934 : check e611630275934 [[.under]] .sourceHead = true := by decide
def e611630275950 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 2))))))))
theorem wire_e611630275950 : Closed e611630275950 ∧ code e611630275950 = 9407723298158 := by decide
theorem cert_e611630275950 : check e611630275950 [[.under]] .sourceHead = true := by decide
def e611630275958 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 1))))))))
theorem wire_e611630275958 : Closed e611630275958 ∧ code e611630275958 = 9407723298166 := by decide
theorem cert_e611630275958 : check e611630275958 [[.under]] .sourceHead = true := by decide
def e611630275962 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 0))))))))
theorem wire_e611630275962 : Closed e611630275962 ∧ code e611630275962 = 9407723298170 := by decide
theorem cert_e611630275962 : check e611630275962 [[.under]] .sourceHead = true := by decide
def e611630276014 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 2))))))))
theorem wire_e611630276014 : Closed e611630276014 ∧ code e611630276014 = 9407723298222 := by decide
theorem cert_e611630276014 : check e611630276014 [[.under]] .sourceHead = true := by decide
def e611630276026 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.var 0))))))))
theorem wire_e611630276026 : Closed e611630276026 ∧ code e611630276026 = 9407723298234 := by decide
theorem cert_e611630276026 : check e611630276026 [[.under]] .sourceHead = true := by decide
def e611630276054 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 1))))))))
theorem wire_e611630276054 : Closed e611630276054 ∧ code e611630276054 = 9407723298262 := by decide
theorem cert_e611630276054 : check e611630276054 [[.under]] .sourceHead = true := by decide
def e611630276058 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.var 0))))))))
theorem wire_e611630276058 : Closed e611630276058 ∧ code e611630276058 = 9407723298266 := by decide
theorem cert_e611630276058 : check e611630276058 [[.under]] .sourceHead = true := by decide
def e611630276074 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 0))))))))
theorem wire_e611630276074 : Closed e611630276074 ∧ code e611630276074 = 9407723298282 := by decide
theorem cert_e611630276074 : check e611630276074 [[.under]] .sourceHead = true := by decide
def e611630276278 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 1))))))))
theorem wire_e611630276278 : Closed e611630276278 ∧ code e611630276278 = 9407723298486 := by decide
theorem cert_e611630276278 : check e611630276278 [[.under]] .sourceHead = true := by decide
def e611630276310 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 1))))))))
theorem wire_e611630276310 : Closed e611630276310 ∧ code e611630276310 = 9407723298518 := by decide
theorem cert_e611630276310 : check e611630276310 [[.under]] .sourceHead = true := by decide
def e611630276314 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.var 0))))))))
theorem wire_e611630276314 : Closed e611630276314 ∧ code e611630276314 = 9407723298522 := by decide
theorem cert_e611630276314 : check e611630276314 [[.under]] .sourceHead = true := by decide
def e611630276438 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 1))))))))
theorem wire_e611630276438 : Closed e611630276438 ∧ code e611630276438 = 9407723298646 := by decide
theorem cert_e611630276438 : check e611630276438 [[.under]] .sourceHead = true := by decide
def e611630276442 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 0))))))))
theorem wire_e611630276442 : Closed e611630276442 ∧ code e611630276442 = 9407723298650 := by decide
theorem cert_e611630276442 : check e611630276442 [[.under]] .sourceHead = true := by decide
def e611630276458 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 0))))))))
theorem wire_e611630276458 : Closed e611630276458 ∧ code e611630276458 = 9407723298666 := by decide
theorem cert_e611630276458 : check e611630276458 [[.under]] .sourceHead = true := by decide
def e611630278366 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3))))))))
theorem wire_e611630278366 : Closed e611630278366 ∧ code e611630278366 = 9407723300574 := by decide
theorem cert_e611630278366 : check e611630278366 [[.under]] .sourceHead = true := by decide
def e611630278390 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1))))))))
theorem wire_e611630278390 : Closed e611630278390 ∧ code e611630278390 = 9407723300598 := by decide
theorem cert_e611630278390 : check e611630278390 [[.under]] .sourceHead = true := by decide
def e611630278494 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 3))))))))
theorem wire_e611630278494 : Closed e611630278494 ∧ code e611630278494 = 9407723300702 := by decide
theorem cert_e611630278494 : check e611630278494 [[.under]] .sourceHead = true := by decide
def e611630278510 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 2))))))))
theorem wire_e611630278510 : Closed e611630278510 ∧ code e611630278510 = 9407723300718 := by decide
theorem cert_e611630278510 : check e611630278510 [[.under]] .sourceHead = true := by decide
def e611630278518 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1))))))))
theorem wire_e611630278518 : Closed e611630278518 ∧ code e611630278518 = 9407723300726 := by decide
theorem cert_e611630278518 : check e611630278518 [[.under]] .sourceHead = true := by decide
def e611630278522 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 0))))))))
theorem wire_e611630278522 : Closed e611630278522 ∧ code e611630278522 = 9407723300730 := by decide
theorem cert_e611630278522 : check e611630278522 [[.under]] .sourceHead = true := by decide
def e611630278582 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1))))))))
theorem wire_e611630278582 : Closed e611630278582 ∧ code e611630278582 = 9407723300790 := by decide
theorem cert_e611630278582 : check e611630278582 [[.under]] .sourceHead = true := by decide
def e611630278614 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 1))))))))
theorem wire_e611630278614 : Closed e611630278614 ∧ code e611630278614 = 9407723300822 := by decide
theorem cert_e611630278614 : check e611630278614 [[.under]] .sourceHead = true := by decide
def e611630278618 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 0))))))))
theorem wire_e611630278618 : Closed e611630278618 ∧ code e611630278618 = 9407723300826 := by decide
theorem cert_e611630278618 : check e611630278618 [[.under]] .sourceHead = true := by decide
def e611630279134 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 3)))))))))
theorem wire_e611630279134 : Closed e611630279134 ∧ code e611630279134 = 9407723301342 := by decide
theorem cert_e611630279134 : check e611630279134 [[.under]] .sourceHead = true := by decide
def e611630279158 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 1)))))))))
theorem wire_e611630279158 : Closed e611630279158 ∧ code e611630279158 = 9407723301366 := by decide
theorem cert_e611630279158 : check e611630279158 [[.under]] .sourceHead = true := by decide
def e611630279902 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 3)))))))))
theorem wire_e611630279902 : Closed e611630279902 ∧ code e611630279902 = 9407723302110 := by decide
theorem cert_e611630279902 : check e611630279902 [[.under]] .sourceHead = true := by decide
def e611630279918 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 2)))))))))
theorem wire_e611630279918 : Closed e611630279918 ∧ code e611630279918 = 9407723302126 := by decide
theorem cert_e611630279918 : check e611630279918 [[.under]] .sourceHead = true := by decide
def e611630279926 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 1)))))))))
theorem wire_e611630279926 : Closed e611630279926 ∧ code e611630279926 = 9407723302134 := by decide
theorem cert_e611630279926 : check e611630279926 [[.under]] .sourceHead = true := by decide
def e611630279930 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 0)))))))))
theorem wire_e611630279930 : Closed e611630279930 ∧ code e611630279930 = 9407723302138 := by decide
theorem cert_e611630279930 : check e611630279930 [[.under]] .sourceHead = true := by decide
def e611630280310 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 1)))))))))
theorem wire_e611630280310 : Closed e611630280310 ∧ code e611630280310 = 9407723302518 := by decide
theorem cert_e611630280310 : check e611630280310 [[.under]] .sourceHead = true := by decide
def e611630280502 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 1)))))))))
theorem wire_e611630280502 : Closed e611630280502 ∧ code e611630280502 = 9407723302710 := by decide
theorem cert_e611630280502 : check e611630280502 [[.under]] .sourceHead = true := by decide
def e611630280506 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 0)))))))))
theorem wire_e611630280506 : Closed e611630280506 ∧ code e611630280506 = 9407723302714 := by decide
theorem cert_e611630280506 : check e611630280506 [[.under]] .sourceHead = true := by decide
def e611630281566 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 3))))))))
theorem wire_e611630281566 : Closed e611630281566 ∧ code e611630281566 = 9407723303774 := by decide
theorem cert_e611630281566 : check e611630281566 [[.under]] .sourceHead = true := by decide
def e611630281582 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 2))))))))
theorem wire_e611630281582 : Closed e611630281582 ∧ code e611630281582 = 9407723303790 := by decide
theorem cert_e611630281582 : check e611630281582 [[.under]] .sourceHead = true := by decide
def e611630281590 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 1))))))))
theorem wire_e611630281590 : Closed e611630281590 ∧ code e611630281590 = 9407723303798 := by decide
theorem cert_e611630281590 : check e611630281590 [[.under]] .sourceHead = true := by decide
def e611630281594 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 0))))))))
theorem wire_e611630281594 : Closed e611630281594 ∧ code e611630281594 = 9407723303802 := by decide
theorem cert_e611630281594 : check e611630281594 [[.under]] .sourceHead = true := by decide
def e611630281646 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 2))))))))
theorem wire_e611630281646 : Closed e611630281646 ∧ code e611630281646 = 9407723303854 := by decide
theorem cert_e611630281646 : check e611630281646 [[.under]] .sourceHead = true := by decide
def e611630281658 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 2))) (.var 0))))))))
theorem wire_e611630281658 : Closed e611630281658 ∧ code e611630281658 = 9407723303866 := by decide
theorem cert_e611630281658 : check e611630281658 [[.under]] .sourceHead = true := by decide
def e611630281686 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 1))))))))
theorem wire_e611630281686 : Closed e611630281686 ∧ code e611630281686 = 9407723303894 := by decide
theorem cert_e611630281686 : check e611630281686 [[.under]] .sourceHead = true := by decide
def e611630281690 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 1))) (.var 0))))))))
theorem wire_e611630281690 : Closed e611630281690 ∧ code e611630281690 = 9407723303898 := by decide
theorem cert_e611630281690 : check e611630281690 [[.under]] .sourceHead = true := by decide
def e611630281706 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 0))))))))
theorem wire_e611630281706 : Closed e611630281706 ∧ code e611630281706 = 9407723303914 := by decide
theorem cert_e611630281706 : check e611630281706 [[.under]] .sourceHead = true := by decide
def e611630281950 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 3)))))))))
theorem wire_e611630281950 : Closed e611630281950 ∧ code e611630281950 = 9407723304158 := by decide
theorem cert_e611630281950 : check e611630281950 [[.under]] .sourceHead = true := by decide
def e611630281966 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 2)))))))))
theorem wire_e611630281966 : Closed e611630281966 ∧ code e611630281966 = 9407723304174 := by decide
theorem cert_e611630281966 : check e611630281966 [[.under]] .sourceHead = true := by decide
def e611630281974 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 1)))))))))
theorem wire_e611630281974 : Closed e611630281974 ∧ code e611630281974 = 9407723304182 := by decide
theorem cert_e611630281974 : check e611630281974 [[.under]] .sourceHead = true := by decide
def e611630281978 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 0)))))))))
theorem wire_e611630281978 : Closed e611630281978 ∧ code e611630281978 = 9407723304186 := by decide
theorem cert_e611630281978 : check e611630281978 [[.under]] .sourceHead = true := by decide
def e611630282350 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 2)))))))))
theorem wire_e611630282350 : Closed e611630282350 ∧ code e611630282350 = 9407723304558 := by decide
theorem cert_e611630282350 : check e611630282350 [[.under]] .sourceHead = true := by decide
def e611630282362 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.var 0)))))))))
theorem wire_e611630282362 : Closed e611630282362 ∧ code e611630282362 = 9407723304570 := by decide
theorem cert_e611630282362 : check e611630282362 [[.under]] .sourceHead = true := by decide
def e611630282550 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 1)))))))))
theorem wire_e611630282550 : Closed e611630282550 ∧ code e611630282550 = 9407723304758 := by decide
theorem cert_e611630282550 : check e611630282550 [[.under]] .sourceHead = true := by decide
def e611630282554 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.var 0)))))))))
theorem wire_e611630282554 : Closed e611630282554 ∧ code e611630282554 = 9407723304762 := by decide
theorem cert_e611630282554 : check e611630282554 [[.under]] .sourceHead = true := by decide
def e611630282650 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 0)))))))))
theorem wire_e611630282650 : Closed e611630282650 ∧ code e611630282650 = 9407723304858 := by decide
theorem cert_e611630282650 : check e611630282650 [[.under]] .sourceHead = true := by decide
def e611630283190 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 1))))))))
theorem wire_e611630283190 : Closed e611630283190 ∧ code e611630283190 = 9407723305398 := by decide
theorem cert_e611630283190 : check e611630283190 [[.under]] .sourceHead = true := by decide
def e611630283222 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 1))))))))
theorem wire_e611630283222 : Closed e611630283222 ∧ code e611630283222 = 9407723305430 := by decide
theorem cert_e611630283222 : check e611630283222 [[.under]] .sourceHead = true := by decide
def e611630283226 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 1))) (.var 0))))))))
theorem wire_e611630283226 : Closed e611630283226 ∧ code e611630283226 = 9407723305434 := by decide
theorem cert_e611630283226 : check e611630283226 [[.under]] .sourceHead = true := by decide
def e611630283382 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 1)))))))))
theorem wire_e611630283382 : Closed e611630283382 ∧ code e611630283382 = 9407723305590 := by decide
theorem cert_e611630283382 : check e611630283382 [[.under]] .sourceHead = true := by decide
def e611630283574 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 1)))))))))
theorem wire_e611630283574 : Closed e611630283574 ∧ code e611630283574 = 9407723305782 := by decide
theorem cert_e611630283574 : check e611630283574 [[.under]] .sourceHead = true := by decide
def e611630283578 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 1) (.var 0)))))))))
theorem wire_e611630283578 : Closed e611630283578 ∧ code e611630283578 = 9407723305786 := by decide
theorem cert_e611630283578 : check e611630283578 [[.under]] .sourceHead = true := by decide
def e611630283990 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e611630283990 : Closed e611630283990 ∧ code e611630283990 = 9407723306198 := by decide
theorem cert_e611630283990 : check e611630283990 [[.under]] .sourceHead = true := by decide
def e611630283994 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e611630283994 : Closed e611630283994 ∧ code e611630283994 = 9407723306202 := by decide
theorem cert_e611630283994 : check e611630283994 [[.under]] .sourceHead = true := by decide
def e611630284010 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e611630284010 : Closed e611630284010 ∧ code e611630284010 = 9407723306218 := by decide
theorem cert_e611630284010 : check e611630284010 [[.under]] .sourceHead = true := by decide
def e611630284086 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e611630284086 : Closed e611630284086 ∧ code e611630284086 = 9407723306294 := by decide
theorem cert_e611630284086 : check e611630284086 [[.under]] .sourceHead = true := by decide
def e611630284090 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e611630284090 : Closed e611630284090 ∧ code e611630284090 = 9407723306298 := by decide
theorem cert_e611630284090 : check e611630284090 [[.under]] .sourceHead = true := by decide
def e611630284186 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e611630284186 : Closed e611630284186 ∧ code e611630284186 = 9407723306394 := by decide
theorem cert_e611630284186 : check e611630284186 [[.under]] .sourceHead = true := by decide
def e611630290654 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 3)))))))))
theorem wire_e611630290654 : Closed e611630290654 ∧ code e611630290654 = 9407723312862 := by decide
theorem cert_e611630290654 : check e611630290654 [[.under]] .sourceHead = true := by decide
def e611630290678 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 3)) (.var 1)))))))))
theorem wire_e611630290678 : Closed e611630290678 ∧ code e611630290678 = 9407723312886 := by decide
theorem cert_e611630290678 : check e611630290678 [[.under]] .sourceHead = true := by decide
def e611630290782 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 3)))))))))
theorem wire_e611630290782 : Closed e611630290782 ∧ code e611630290782 = 9407723312990 := by decide
theorem cert_e611630290782 : check e611630290782 [[.under]] .sourceHead = true := by decide
def e611630290798 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 1)) (.var 2)))))))))
theorem wire_e611630290798 : Closed e611630290798 ∧ code e611630290798 = 9407723313006 := by decide
theorem cert_e611630290798 : check e611630290798 [[.under]] .sourceHead = true := by decide
def e611630290806 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 1)))))))))
theorem wire_e611630290806 : Closed e611630290806 ∧ code e611630290806 = 9407723313014 := by decide
theorem cert_e611630290806 : check e611630290806 [[.under]] .sourceHead = true := by decide
def e611630290810 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 3)) (.var 0)))))))))
theorem wire_e611630290810 : Closed e611630290810 ∧ code e611630290810 = 9407723313018 := by decide
theorem cert_e611630290810 : check e611630290810 [[.under]] .sourceHead = true := by decide
def e611630290870 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 1)))))))))
theorem wire_e611630290870 : Closed e611630290870 ∧ code e611630290870 = 9407723313078 := by decide
theorem cert_e611630290870 : check e611630290870 [[.under]] .sourceHead = true := by decide
def e611630290902 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 0)) (.var 1)))))))))
theorem wire_e611630290902 : Closed e611630290902 ∧ code e611630290902 = 9407723313110 := by decide
theorem cert_e611630290902 : check e611630290902 [[.under]] .sourceHead = true := by decide
def e611630290906 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 3) (.var 1)) (.var 0)))))))))
theorem wire_e611630290906 : Closed e611630290906 ∧ code e611630290906 = 9407723313114 := by decide
theorem cert_e611630290906 : check e611630290906 [[.under]] .sourceHead = true := by decide
def e611630291422 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 3))))))))))
theorem wire_e611630291422 : Closed e611630291422 ∧ code e611630291422 = 9407723313630 := by decide
theorem cert_e611630291422 : check e611630291422 [[.under]] .sourceHead = true := by decide
def e611630291446 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 3) (.var 1))))))))))
theorem wire_e611630291446 : Closed e611630291446 ∧ code e611630291446 = 9407723313654 := by decide
theorem cert_e611630291446 : check e611630291446 [[.under]] .sourceHead = true := by decide
def e611630292190 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 3))))))))))
theorem wire_e611630292190 : Closed e611630292190 ∧ code e611630292190 = 9407723314398 := by decide
theorem cert_e611630292190 : check e611630292190 [[.under]] .sourceHead = true := by decide
def e611630292206 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 1) (.var 2))))))))))
theorem wire_e611630292206 : Closed e611630292206 ∧ code e611630292206 = 9407723314414 := by decide
theorem cert_e611630292206 : check e611630292206 [[.under]] .sourceHead = true := by decide
def e611630292214 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 1))))))))))
theorem wire_e611630292214 : Closed e611630292214 ∧ code e611630292214 = 9407723314422 := by decide
theorem cert_e611630292214 : check e611630292214 [[.under]] .sourceHead = true := by decide
def e611630292218 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 3) (.var 0))))))))))
theorem wire_e611630292218 : Closed e611630292218 ∧ code e611630292218 = 9407723314426 := by decide
theorem cert_e611630292218 : check e611630292218 [[.under]] .sourceHead = true := by decide
def e611630292598 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 1))))))))))
theorem wire_e611630292598 : Closed e611630292598 ∧ code e611630292598 = 9407723314806 := by decide
theorem cert_e611630292598 : check e611630292598 [[.under]] .sourceHead = true := by decide
def e611630292790 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 0) (.var 1))))))))))
theorem wire_e611630292790 : Closed e611630292790 ∧ code e611630292790 = 9407723314998 := by decide
theorem cert_e611630292790 : check e611630292790 [[.under]] .sourceHead = true := by decide
def e611630292794 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.app (.var 1) (.var 0))))))))))
theorem wire_e611630292794 : Closed e611630292794 ∧ code e611630292794 = 9407723315002 := by decide
theorem cert_e611630292794 : check e611630292794 [[.under]] .sourceHead = true := by decide
def e611630304094 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 3)))))))))
theorem wire_e611630304094 : Closed e611630304094 ∧ code e611630304094 = 9407723326302 := by decide
theorem cert_e611630304094 : check e611630304094 [[.under]] .sourceHead = true := by decide
def e611630304110 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e611630304110 : Closed e611630304110 ∧ code e611630304110 = 9407723326318 := by decide
theorem cert_e611630304110 : check e611630304110 [[.under]] .sourceHead = true := by decide
def e611630304118 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e611630304118 : Closed e611630304118 ∧ code e611630304118 = 9407723326326 := by decide
theorem cert_e611630304118 : check e611630304118 [[.under]] .sourceHead = true := by decide
def e611630304122 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 3)) (.var 0)))))))))
theorem wire_e611630304122 : Closed e611630304122 ∧ code e611630304122 = 9407723326330 := by decide
theorem cert_e611630304122 : check e611630304122 [[.under]] .sourceHead = true := by decide
def e611630304174 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e611630304174 : Closed e611630304174 ∧ code e611630304174 = 9407723326382 := by decide
theorem cert_e611630304174 : check e611630304174 [[.under]] .sourceHead = true := by decide
def e611630304186 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e611630304186 : Closed e611630304186 ∧ code e611630304186 = 9407723326394 := by decide
theorem cert_e611630304186 : check e611630304186 [[.under]] .sourceHead = true := by decide
def e611630304214 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e611630304214 : Closed e611630304214 ∧ code e611630304214 = 9407723326422 := by decide
theorem cert_e611630304214 : check e611630304214 [[.under]] .sourceHead = true := by decide
def e611630304218 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e611630304218 : Closed e611630304218 ∧ code e611630304218 = 9407723326426 := by decide
theorem cert_e611630304218 : check e611630304218 [[.under]] .sourceHead = true := by decide
def e611630304234 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 3) (.var 0)) (.var 0)))))))))
theorem wire_e611630304234 : Closed e611630304234 ∧ code e611630304234 = 9407723326442 := by decide
theorem cert_e611630304234 : check e611630304234 [[.under]] .sourceHead = true := by decide
def e611630304478 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 3))))))))))
theorem wire_e611630304478 : Closed e611630304478 ∧ code e611630304478 = 9407723326686 := by decide
theorem cert_e611630304478 : check e611630304478 [[.under]] .sourceHead = true := by decide
def e611630304494 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e611630304494 : Closed e611630304494 ∧ code e611630304494 = 9407723326702 := by decide
theorem cert_e611630304494 : check e611630304494 [[.under]] .sourceHead = true := by decide
def e611630304502 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e611630304502 : Closed e611630304502 ∧ code e611630304502 = 9407723326710 := by decide
theorem cert_e611630304502 : check e611630304502 [[.under]] .sourceHead = true := by decide
def e611630304506 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 3) (.var 0))))))))))
theorem wire_e611630304506 : Closed e611630304506 ∧ code e611630304506 = 9407723326714 := by decide
theorem cert_e611630304506 : check e611630304506 [[.under]] .sourceHead = true := by decide
def e611630304878 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e611630304878 : Closed e611630304878 ∧ code e611630304878 = 9407723327086 := by decide
theorem cert_e611630304878 : check e611630304878 [[.under]] .sourceHead = true := by decide
def e611630304890 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e611630304890 : Closed e611630304890 ∧ code e611630304890 = 9407723327098 := by decide
theorem cert_e611630304890 : check e611630304890 [[.under]] .sourceHead = true := by decide
def e611630305078 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e611630305078 : Closed e611630305078 ∧ code e611630305078 = 9407723327286 := by decide
theorem cert_e611630305078 : check e611630305078 [[.under]] .sourceHead = true := by decide
def e611630305082 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e611630305082 : Closed e611630305082 ∧ code e611630305082 = 9407723327290 := by decide
theorem cert_e611630305082 : check e611630305082 [[.under]] .sourceHead = true := by decide
def e611630305178 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.app (.var 0) (.var 0))))))))))
theorem wire_e611630305178 : Closed e611630305178 ∧ code e611630305178 = 9407723327386 := by decide
theorem cert_e611630305178 : check e611630305178 [[.under]] .sourceHead = true := by decide
def e611630310838 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e611630310838 : Closed e611630310838 ∧ code e611630310838 = 9407723333046 := by decide
theorem cert_e611630310838 : check e611630310838 [[.under]] .sourceHead = true := by decide
def e611630310870 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e611630310870 : Closed e611630310870 ∧ code e611630310870 = 9407723333078 := by decide
theorem cert_e611630310870 : check e611630310870 [[.under]] .sourceHead = true := by decide
def e611630310874 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e611630310874 : Closed e611630310874 ∧ code e611630310874 = 9407723333082 := by decide
theorem cert_e611630310874 : check e611630310874 [[.under]] .sourceHead = true := by decide
def e611630311030 : Term := (.lam (.app (.lam (.app (.var 1) (.app (.var 0) (.var 0)))) (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e611630311030 : Closed e611630311030 ∧ code e611630311030 = 9407723333238 := by decide
theorem cert_e611630311030 : check e611630311030 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
