import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e598751600182 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1))))))))
theorem wire_e598751600182 : Closed e598751600182 ∧ code e598751600182 = 9394844622390 := by decide
theorem cert_e598751600182 : check e598751600182 [[.under],[.under,.left]] .chain = true := by decide
def e598751600186 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0))))))))
theorem wire_e598751600186 : Closed e598751600186 ∧ code e598751600186 = 9394844622394 := by decide
theorem cert_e598751600186 : check e598751600186 [[.under],[.under,.left]] .chain = true := by decide
def e598751600270 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e598751600270 : Closed e598751600270 ∧ code e598751600270 = 9394844622478 := by decide
theorem cert_e598751600270 : check e598751600270 [[.under],[.under,.left]] .chain = true := by decide
def e598751600326 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e598751600326 : Closed e598751600326 ∧ code e598751600326 = 9394844622534 := by decide
theorem cert_e598751600326 : check e598751600326 [[.under],[.under,.left]] .chain = true := by decide
def e598751602462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e598751602462 : Closed e598751602462 ∧ code e598751602462 = 9394844624670 := by decide
theorem cert_e598751602462 : check e598751602462 [[.under],[.under,.left]] .chain = true := by decide
def e598751602574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e598751602574 : Closed e598751602574 ∧ code e598751602574 = 9394844624782 := by decide
theorem cert_e598751602574 : check e598751602574 [[.under],[.under,.left]] .chain = true := by decide
def e598751605534 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e598751605534 : Closed e598751605534 ∧ code e598751605534 = 9394844627742 := by decide
theorem cert_e598751605534 : check e598751605534 [[.under],[.under,.left]] .chain = true := by decide
def e598751605702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e598751605702 : Closed e598751605702 ∧ code e598751605702 = 9394844627910 := by decide
theorem cert_e598751605702 : check e598751605702 [[.under],[.under,.left]] .chain = true := by decide
def e598751607182 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e598751607182 : Closed e598751607182 ∧ code e598751607182 = 9394844629390 := by decide
theorem cert_e598751607182 : check e598751607182 [[.under],[.under,.left]] .chain = true := by decide
def e598751607238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.var 1)) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e598751607238 : Closed e598751607238 ∧ code e598751607238 = 9394844629446 := by decide
theorem cert_e598751607238 : check e598751607238 [[.under],[.under,.left]] .chain = true := by decide
def e599171911878 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599171911878 : Closed e599171911878 ∧ code e599171911878 = 9395264934086 := by decide
theorem cert_e599171911878 : check e599171911878 [[.under]] .width = true := by decide
def e599171977414 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599171977414 : Closed e599171977414 ∧ code e599171977414 = 9395264999622 := by decide
theorem cert_e599171977414 : check e599171977414 [[.under]] .width = true := by decide
def e599172436166 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599172436166 : Closed e599172436166 ∧ code e599172436166 = 9395265458374 := by decide
theorem cert_e599172436166 : check e599172436166 [[.under]] .width = true := by decide
def e599172534470 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599172534470 : Closed e599172534470 ∧ code e599172534470 = 9395265556678 := by decide
theorem cert_e599172534470 : check e599172534470 [[.under]] .width = true := by decide
def e599172763846 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599172763846 : Closed e599172763846 ∧ code e599172763846 = 9395265786054 := by decide
theorem cert_e599172763846 : check e599172763846 [[.under]] .width = true := by decide
def e599172796614 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599172796614 : Closed e599172796614 ∧ code e599172796614 = 9395265818822 := by decide
theorem cert_e599172796614 : check e599172796614 [[.under]] .width = true := by decide
def e599175057606 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599175057606 : Closed e599175057606 ∧ code e599175057606 = 9395268079814 := by decide
theorem cert_e599175057606 : check e599175057606 [[.under]] .width = true := by decide
def e599175123142 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599175123142 : Closed e599175123142 ∧ code e599175123142 = 9395268145350 := by decide
theorem cert_e599175123142 : check e599175123142 [[.under]] .width = true := by decide
def e599178203334 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599178203334 : Closed e599178203334 ∧ code e599178203334 = 9395271225542 := by decide
theorem cert_e599178203334 : check e599178203334 [[.under]] .width = true := by decide
def e599178301638 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599178301638 : Closed e599178301638 ∧ code e599178301638 = 9395271323846 := by decide
theorem cert_e599178301638 : check e599178301638 [[.under]] .width = true := by decide
def e599179841734 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599179841734 : Closed e599179841734 ∧ code e599179841734 = 9395272863942 := by decide
theorem cert_e599179841734 : check e599179841734 [[.under]] .width = true := by decide
def e599179874502 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599179874502 : Closed e599179874502 ∧ code e599179874502 = 9395272896710 := by decide
theorem cert_e599179874502 : check e599179874502 [[.under]] .width = true := by decide
def e599366085998 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e599366085998 : Closed e599366085998 ∧ code e599366085998 = 9395459108206 := by decide
theorem cert_e599366085998 : check e599366085998 [[.under]] .sourceHead = true := by decide
def e599366086006 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e599366086006 : Closed e599366086006 ∧ code e599366086006 = 9395459108214 := by decide
theorem cert_e599366086006 : check e599366086006 [[.under]] .sourceHead = true := by decide
def e599366086062 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e599366086062 : Closed e599366086062 ∧ code e599366086062 = 9395459108270 := by decide
theorem cert_e599366086062 : check e599366086062 [[.under]] .sourceHead = true := by decide
def e599366086074 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e599366086074 : Closed e599366086074 ∧ code e599366086074 = 9395459108282 := by decide
theorem cert_e599366086074 : check e599366086074 [[.under]] .sourceHead = true := by decide
def e599366086102 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e599366086102 : Closed e599366086102 ∧ code e599366086102 = 9395459108310 := by decide
theorem cert_e599366086102 : check e599366086102 [[.under]] .sourceHead = true := by decide
def e599366086106 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e599366086106 : Closed e599366086106 ∧ code e599366086106 = 9395459108314 := by decide
theorem cert_e599366086106 : check e599366086106 [[.under]] .sourceHead = true := by decide
def e599366086318 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e599366086318 : Closed e599366086318 ∧ code e599366086318 = 9395459108526 := by decide
theorem cert_e599366086318 : check e599366086318 [[.under]] .sourceHead = true := by decide
def e599366086330 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e599366086330 : Closed e599366086330 ∧ code e599366086330 = 9395459108538 := by decide
theorem cert_e599366086330 : check e599366086330 [[.under]] .sourceHead = true := by decide
def e599366086378 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e599366086378 : Closed e599366086378 ∧ code e599366086378 = 9395459108586 := by decide
theorem cert_e599366086378 : check e599366086378 [[.under]] .sourceHead = true := by decide
def e599366086486 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e599366086486 : Closed e599366086486 ∧ code e599366086486 = 9395459108694 := by decide
theorem cert_e599366086486 : check e599366086486 [[.under]] .sourceHead = true := by decide
def e599366086490 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e599366086490 : Closed e599366086490 ∧ code e599366086490 = 9395459108698 := by decide
theorem cert_e599366086490 : check e599366086490 [[.under]] .sourceHead = true := by decide
def e599366086506 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e599366086506 : Closed e599366086506 ∧ code e599366086506 = 9395459108714 := by decide
theorem cert_e599366086506 : check e599366086506 [[.under]] .sourceHead = true := by decide
def e599366087534 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e599366087534 : Closed e599366087534 ∧ code e599366087534 = 9395459109742 := by decide
theorem cert_e599366087534 : check e599366087534 [[.under]] .sourceHead = true := by decide
def e599366087542 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e599366087542 : Closed e599366087542 ∧ code e599366087542 = 9395459109750 := by decide
theorem cert_e599366087542 : check e599366087542 [[.under]] .sourceHead = true := by decide
def e599366087598 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e599366087598 : Closed e599366087598 ∧ code e599366087598 = 9395459109806 := by decide
theorem cert_e599366087598 : check e599366087598 [[.under]] .sourceHead = true := by decide
def e599366087610 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e599366087610 : Closed e599366087610 ∧ code e599366087610 = 9395459109818 := by decide
theorem cert_e599366087610 : check e599366087610 [[.under]] .sourceHead = true := by decide
def e599366087638 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e599366087638 : Closed e599366087638 ∧ code e599366087638 = 9395459109846 := by decide
theorem cert_e599366087638 : check e599366087638 [[.under]] .sourceHead = true := by decide
def e599366087642 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e599366087642 : Closed e599366087642 ∧ code e599366087642 = 9395459109850 := by decide
theorem cert_e599366087642 : check e599366087642 [[.under]] .sourceHead = true := by decide
def e599366087918 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e599366087918 : Closed e599366087918 ∧ code e599366087918 = 9395459110126 := by decide
theorem cert_e599366087918 : check e599366087918 [[.under]] .sourceHead = true := by decide
def e599366087926 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e599366087926 : Closed e599366087926 ∧ code e599366087926 = 9395459110134 := by decide
theorem cert_e599366087926 : check e599366087926 [[.under]] .sourceHead = true := by decide
def e599366088302 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e599366088302 : Closed e599366088302 ∧ code e599366088302 = 9395459110510 := by decide
theorem cert_e599366088302 : check e599366088302 [[.under]] .sourceHead = true := by decide
def e599366088314 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e599366088314 : Closed e599366088314 ∧ code e599366088314 = 9395459110522 := by decide
theorem cert_e599366088314 : check e599366088314 [[.under]] .sourceHead = true := by decide
def e599366088502 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e599366088502 : Closed e599366088502 ∧ code e599366088502 = 9395459110710 := by decide
theorem cert_e599366088502 : check e599366088502 [[.under]] .sourceHead = true := by decide
def e599366088506 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e599366088506 : Closed e599366088506 ∧ code e599366088506 = 9395459110714 := by decide
theorem cert_e599366088506 : check e599366088506 [[.under]] .sourceHead = true := by decide
def e599366089134 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e599366089134 : Closed e599366089134 ∧ code e599366089134 = 9395459111342 := by decide
theorem cert_e599366089134 : check e599366089134 [[.under]] .sourceHead = true := by decide
def e599366089146 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e599366089146 : Closed e599366089146 ∧ code e599366089146 = 9395459111354 := by decide
theorem cert_e599366089146 : check e599366089146 [[.under]] .sourceHead = true := by decide
def e599366089194 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e599366089194 : Closed e599366089194 ∧ code e599366089194 = 9395459111402 := by decide
theorem cert_e599366089194 : check e599366089194 [[.under]] .sourceHead = true := by decide
def e599366089326 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e599366089326 : Closed e599366089326 ∧ code e599366089326 = 9395459111534 := by decide
theorem cert_e599366089326 : check e599366089326 [[.under]] .sourceHead = true := by decide
def e599366089338 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e599366089338 : Closed e599366089338 ∧ code e599366089338 = 9395459111546 := by decide
theorem cert_e599366089338 : check e599366089338 [[.under]] .sourceHead = true := by decide
def e599366089626 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e599366089626 : Closed e599366089626 ∧ code e599366089626 = 9395459111834 := by decide
theorem cert_e599366089626 : check e599366089626 [[.under]] .sourceHead = true := by decide
def e599366089942 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e599366089942 : Closed e599366089942 ∧ code e599366089942 = 9395459112150 := by decide
theorem cert_e599366089942 : check e599366089942 [[.under]] .sourceHead = true := by decide
def e599366089946 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e599366089946 : Closed e599366089946 ∧ code e599366089946 = 9395459112154 := by decide
theorem cert_e599366089946 : check e599366089946 [[.under]] .sourceHead = true := by decide
def e599366089962 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e599366089962 : Closed e599366089962 ∧ code e599366089962 = 9395459112170 := by decide
theorem cert_e599366089962 : check e599366089962 [[.under]] .sourceHead = true := by decide
def e599366090038 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e599366090038 : Closed e599366090038 ∧ code e599366090038 = 9395459112246 := by decide
theorem cert_e599366090038 : check e599366090038 [[.under]] .sourceHead = true := by decide
def e599366090042 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e599366090042 : Closed e599366090042 ∧ code e599366090042 = 9395459112250 := by decide
theorem cert_e599366090042 : check e599366090042 [[.under]] .sourceHead = true := by decide
def e599366090138 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e599366090138 : Closed e599366090138 ∧ code e599366090138 = 9395459112346 := by decide
theorem cert_e599366090138 : check e599366090138 [[.under]] .sourceHead = true := by decide
def e599366093678 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e599366093678 : Closed e599366093678 ∧ code e599366093678 = 9395459115886 := by decide
theorem cert_e599366093678 : check e599366093678 [[.under]] .sourceHead = true := by decide
def e599366093686 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e599366093686 : Closed e599366093686 ∧ code e599366093686 = 9395459115894 := by decide
theorem cert_e599366093686 : check e599366093686 [[.under]] .sourceHead = true := by decide
def e599366093742 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e599366093742 : Closed e599366093742 ∧ code e599366093742 = 9395459115950 := by decide
theorem cert_e599366093742 : check e599366093742 [[.under]] .sourceHead = true := by decide
def e599366093754 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e599366093754 : Closed e599366093754 ∧ code e599366093754 = 9395459115962 := by decide
theorem cert_e599366093754 : check e599366093754 [[.under]] .sourceHead = true := by decide
def e599366093782 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e599366093782 : Closed e599366093782 ∧ code e599366093782 = 9395459115990 := by decide
theorem cert_e599366093782 : check e599366093782 [[.under]] .sourceHead = true := by decide
def e599366093786 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e599366093786 : Closed e599366093786 ∧ code e599366093786 = 9395459115994 := by decide
theorem cert_e599366093786 : check e599366093786 [[.under]] .sourceHead = true := by decide
def e599366094062 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e599366094062 : Closed e599366094062 ∧ code e599366094062 = 9395459116270 := by decide
theorem cert_e599366094062 : check e599366094062 [[.under]] .sourceHead = true := by decide
def e599366094070 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e599366094070 : Closed e599366094070 ∧ code e599366094070 = 9395459116278 := by decide
theorem cert_e599366094070 : check e599366094070 [[.under]] .sourceHead = true := by decide
def e599366094446 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e599366094446 : Closed e599366094446 ∧ code e599366094446 = 9395459116654 := by decide
theorem cert_e599366094446 : check e599366094446 [[.under]] .sourceHead = true := by decide
def e599366094458 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e599366094458 : Closed e599366094458 ∧ code e599366094458 = 9395459116666 := by decide
theorem cert_e599366094458 : check e599366094458 [[.under]] .sourceHead = true := by decide
def e599366094646 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e599366094646 : Closed e599366094646 ∧ code e599366094646 = 9395459116854 := by decide
theorem cert_e599366094646 : check e599366094646 [[.under]] .sourceHead = true := by decide
def e599366094650 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e599366094650 : Closed e599366094650 ∧ code e599366094650 = 9395459116858 := by decide
theorem cert_e599366094650 : check e599366094650 [[.under]] .sourceHead = true := by decide
def e599366100398 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e599366100398 : Closed e599366100398 ∧ code e599366100398 = 9395459122606 := by decide
theorem cert_e599366100398 : check e599366100398 [[.under]] .sourceHead = true := by decide
def e599366100410 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e599366100410 : Closed e599366100410 ∧ code e599366100410 = 9395459122618 := by decide
theorem cert_e599366100410 : check e599366100410 [[.under]] .sourceHead = true := by decide
def e599366100458 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e599366100458 : Closed e599366100458 ∧ code e599366100458 = 9395459122666 := by decide
theorem cert_e599366100458 : check e599366100458 [[.under]] .sourceHead = true := by decide
def e599366100590 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e599366100590 : Closed e599366100590 ∧ code e599366100590 = 9395459122798 := by decide
theorem cert_e599366100590 : check e599366100590 [[.under]] .sourceHead = true := by decide
def e599366100602 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e599366100602 : Closed e599366100602 ∧ code e599366100602 = 9395459122810 := by decide
theorem cert_e599366100602 : check e599366100602 [[.under]] .sourceHead = true := by decide
def e599366100890 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e599366100890 : Closed e599366100890 ∧ code e599366100890 = 9395459123098 := by decide
theorem cert_e599366100890 : check e599366100890 [[.under]] .sourceHead = true := by decide
def e599366103766 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e599366103766 : Closed e599366103766 ∧ code e599366103766 = 9395459125974 := by decide
theorem cert_e599366103766 : check e599366103766 [[.under]] .sourceHead = true := by decide
def e599366103770 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e599366103770 : Closed e599366103770 ∧ code e599366103770 = 9395459125978 := by decide
theorem cert_e599366103770 : check e599366103770 [[.under]] .sourceHead = true := by decide
def e599366103786 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e599366103786 : Closed e599366103786 ∧ code e599366103786 = 9395459125994 := by decide
theorem cert_e599366103786 : check e599366103786 [[.under]] .sourceHead = true := by decide
def e599366103862 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e599366103862 : Closed e599366103862 ∧ code e599366103862 = 9395459126070 := by decide
theorem cert_e599366103862 : check e599366103862 [[.under]] .sourceHead = true := by decide
def e599366103866 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e599366103866 : Closed e599366103866 ∧ code e599366103866 = 9395459126074 := by decide
theorem cert_e599366103866 : check e599366103866 [[.under]] .sourceHead = true := by decide
def e599366103962 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e599366103962 : Closed e599366103962 ∧ code e599366103962 = 9395459126170 := by decide
theorem cert_e599366103962 : check e599366103962 [[.under]] .sourceHead = true := by decide
def e599366241134 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e599366241134 : Closed e599366241134 ∧ code e599366241134 = 9395459263342 := by decide
theorem cert_e599366241134 : check e599366241134 [[.under]] .sourceHead = true := by decide
def e599366241142 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e599366241142 : Closed e599366241142 ∧ code e599366241142 = 9395459263350 := by decide
theorem cert_e599366241142 : check e599366241142 [[.under]] .sourceHead = true := by decide
def e599366241198 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e599366241198 : Closed e599366241198 ∧ code e599366241198 = 9395459263406 := by decide
theorem cert_e599366241198 : check e599366241198 [[.under]] .sourceHead = true := by decide
def e599366241210 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e599366241210 : Closed e599366241210 ∧ code e599366241210 = 9395459263418 := by decide
theorem cert_e599366241210 : check e599366241210 [[.under]] .sourceHead = true := by decide
def e599366241238 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e599366241238 : Closed e599366241238 ∧ code e599366241238 = 9395459263446 := by decide
theorem cert_e599366241238 : check e599366241238 [[.under]] .sourceHead = true := by decide
def e599366241242 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e599366241242 : Closed e599366241242 ∧ code e599366241242 = 9395459263450 := by decide
theorem cert_e599366241242 : check e599366241242 [[.under]] .sourceHead = true := by decide
def e599366241518 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e599366241518 : Closed e599366241518 ∧ code e599366241518 = 9395459263726 := by decide
theorem cert_e599366241518 : check e599366241518 [[.under]] .sourceHead = true := by decide
def e599366241526 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e599366241526 : Closed e599366241526 ∧ code e599366241526 = 9395459263734 := by decide
theorem cert_e599366241526 : check e599366241526 [[.under]] .sourceHead = true := by decide
def e599366241902 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e599366241902 : Closed e599366241902 ∧ code e599366241902 = 9395459264110 := by decide
theorem cert_e599366241902 : check e599366241902 [[.under]] .sourceHead = true := by decide
def e599366241914 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e599366241914 : Closed e599366241914 ∧ code e599366241914 = 9395459264122 := by decide
theorem cert_e599366241914 : check e599366241914 [[.under]] .sourceHead = true := by decide
def e599366242102 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e599366242102 : Closed e599366242102 ∧ code e599366242102 = 9395459264310 := by decide
theorem cert_e599366242102 : check e599366242102 [[.under]] .sourceHead = true := by decide
def e599366242106 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e599366242106 : Closed e599366242106 ∧ code e599366242106 = 9395459264314 := by decide
theorem cert_e599366242106 : check e599366242106 [[.under]] .sourceHead = true := by decide
def e599366830958 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e599366830958 : Closed e599366830958 ∧ code e599366830958 = 9395459853166 := by decide
theorem cert_e599366830958 : check e599366830958 [[.under]] .sourceHead = true := by decide
def e599366830966 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e599366830966 : Closed e599366830966 ∧ code e599366830966 = 9395459853174 := by decide
theorem cert_e599366830966 : check e599366830966 [[.under]] .sourceHead = true := by decide
def e599366831022 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e599366831022 : Closed e599366831022 ∧ code e599366831022 = 9395459853230 := by decide
theorem cert_e599366831022 : check e599366831022 [[.under]] .sourceHead = true := by decide
def e599366831034 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e599366831034 : Closed e599366831034 ∧ code e599366831034 = 9395459853242 := by decide
theorem cert_e599366831034 : check e599366831034 [[.under]] .sourceHead = true := by decide
def e599366831062 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e599366831062 : Closed e599366831062 ∧ code e599366831062 = 9395459853270 := by decide
theorem cert_e599366831062 : check e599366831062 [[.under]] .sourceHead = true := by decide
def e599366831066 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e599366831066 : Closed e599366831066 ∧ code e599366831066 = 9395459853274 := by decide
theorem cert_e599366831066 : check e599366831066 [[.under]] .sourceHead = true := by decide
def e599366831342 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e599366831342 : Closed e599366831342 ∧ code e599366831342 = 9395459853550 := by decide
theorem cert_e599366831342 : check e599366831342 [[.under]] .sourceHead = true := by decide
def e599366831350 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e599366831350 : Closed e599366831350 ∧ code e599366831350 = 9395459853558 := by decide
theorem cert_e599366831350 : check e599366831350 [[.under]] .sourceHead = true := by decide
def e599366831726 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e599366831726 : Closed e599366831726 ∧ code e599366831726 = 9395459853934 := by decide
theorem cert_e599366831726 : check e599366831726 [[.under]] .sourceHead = true := by decide
def e599366831738 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e599366831738 : Closed e599366831738 ∧ code e599366831738 = 9395459853946 := by decide
theorem cert_e599366831738 : check e599366831738 [[.under]] .sourceHead = true := by decide
def e599366831926 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e599366831926 : Closed e599366831926 ∧ code e599366831926 = 9395459854134 := by decide
theorem cert_e599366831926 : check e599366831926 [[.under]] .sourceHead = true := by decide
def e599366831930 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e599366831930 : Closed e599366831930 ∧ code e599366831930 = 9395459854138 := by decide
theorem cert_e599366831930 : check e599366831930 [[.under]] .sourceHead = true := by decide
def e599690801350 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599690801350 : Closed e599690801350 ∧ code e599690801350 = 9395783823558 := by decide
theorem cert_e599690801350 : check e599690801350 [[.under]] .width = true := by decide
def e599690817734 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599690817734 : Closed e599690817734 ∧ code e599690817734 = 9395783839942 := by decide
theorem cert_e599690817734 : check e599690817734 [[.under]] .width = true := by decide
def e599690932422 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599690932422 : Closed e599690932422 ∧ code e599690932422 = 9395783954630 := by decide
theorem cert_e599690932422 : check e599690932422 [[.under]] .width = true := by decide
def e599690956998 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599690956998 : Closed e599690956998 ∧ code e599690956998 = 9395783979206 := by decide
theorem cert_e599690956998 : check e599690956998 [[.under]] .width = true := by decide
def e599691014342 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599691014342 : Closed e599691014342 ∧ code e599691014342 = 9395784036550 := by decide
theorem cert_e599691014342 : check e599691014342 [[.under]] .width = true := by decide
def e599691022534 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599691022534 : Closed e599691022534 ∧ code e599691022534 = 9395784044742 := by decide
theorem cert_e599691022534 : check e599691022534 [[.under]] .width = true := by decide
def e599691587782 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599691587782 : Closed e599691587782 ∧ code e599691587782 = 9395784609990 := by decide
theorem cert_e599691587782 : check e599691587782 [[.under]] .width = true := by decide
def e599691604166 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599691604166 : Closed e599691604166 ∧ code e599691604166 = 9395784626374 := by decide
theorem cert_e599691604166 : check e599691604166 [[.under]] .width = true := by decide
def e599692374214 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599692374214 : Closed e599692374214 ∧ code e599692374214 = 9395785396422 := by decide
theorem cert_e599692374214 : check e599692374214 [[.under]] .width = true := by decide
def e599692398790 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599692398790 : Closed e599692398790 ∧ code e599692398790 = 9395785420998 := by decide
theorem cert_e599692398790 : check e599692398790 [[.under]] .width = true := by decide
def e599692783814 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599692783814 : Closed e599692783814 ∧ code e599692783814 = 9395785806022 := by decide
theorem cert_e599692783814 : check e599692783814 [[.under]] .width = true := by decide
def e599692792006 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e599692792006 : Closed e599692792006 ∧ code e599692792006 = 9395785814214 := by decide
theorem cert_e599692792006 : check e599692792006 [[.under]] .width = true := by decide
def e599735184750 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e599735184750 : Closed e599735184750 ∧ code e599735184750 = 9395828206958 := by decide
theorem cert_e599735184750 : check e599735184750 [[.under]] .sourceHead = true := by decide
def e599735184758 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e599735184758 : Closed e599735184758 ∧ code e599735184758 = 9395828206966 := by decide
theorem cert_e599735184758 : check e599735184758 [[.under]] .sourceHead = true := by decide
def e599735184814 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e599735184814 : Closed e599735184814 ∧ code e599735184814 = 9395828207022 := by decide
theorem cert_e599735184814 : check e599735184814 [[.under]] .sourceHead = true := by decide
def e599735184826 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e599735184826 : Closed e599735184826 ∧ code e599735184826 = 9395828207034 := by decide
theorem cert_e599735184826 : check e599735184826 [[.under]] .sourceHead = true := by decide
def e599735184854 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e599735184854 : Closed e599735184854 ∧ code e599735184854 = 9395828207062 := by decide
theorem cert_e599735184854 : check e599735184854 [[.under]] .sourceHead = true := by decide
def e599735184858 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e599735184858 : Closed e599735184858 ∧ code e599735184858 = 9395828207066 := by decide
theorem cert_e599735184858 : check e599735184858 [[.under]] .sourceHead = true := by decide
def e599735185070 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e599735185070 : Closed e599735185070 ∧ code e599735185070 = 9395828207278 := by decide
theorem cert_e599735185070 : check e599735185070 [[.under]] .sourceHead = true := by decide
def e599735185082 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e599735185082 : Closed e599735185082 ∧ code e599735185082 = 9395828207290 := by decide
theorem cert_e599735185082 : check e599735185082 [[.under]] .sourceHead = true := by decide
def e599735185130 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e599735185130 : Closed e599735185130 ∧ code e599735185130 = 9395828207338 := by decide
theorem cert_e599735185130 : check e599735185130 [[.under]] .sourceHead = true := by decide
def e599735185238 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e599735185238 : Closed e599735185238 ∧ code e599735185238 = 9395828207446 := by decide
theorem cert_e599735185238 : check e599735185238 [[.under]] .sourceHead = true := by decide
def e599735185242 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e599735185242 : Closed e599735185242 ∧ code e599735185242 = 9395828207450 := by decide
theorem cert_e599735185242 : check e599735185242 [[.under]] .sourceHead = true := by decide
def e599735185258 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e599735185258 : Closed e599735185258 ∧ code e599735185258 = 9395828207466 := by decide
theorem cert_e599735185258 : check e599735185258 [[.under]] .sourceHead = true := by decide
def e599735186286 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e599735186286 : Closed e599735186286 ∧ code e599735186286 = 9395828208494 := by decide
theorem cert_e599735186286 : check e599735186286 [[.under]] .sourceHead = true := by decide
def e599735186294 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e599735186294 : Closed e599735186294 ∧ code e599735186294 = 9395828208502 := by decide
theorem cert_e599735186294 : check e599735186294 [[.under]] .sourceHead = true := by decide
def e599735186350 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e599735186350 : Closed e599735186350 ∧ code e599735186350 = 9395828208558 := by decide
theorem cert_e599735186350 : check e599735186350 [[.under]] .sourceHead = true := by decide
def e599735186362 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e599735186362 : Closed e599735186362 ∧ code e599735186362 = 9395828208570 := by decide
theorem cert_e599735186362 : check e599735186362 [[.under]] .sourceHead = true := by decide
def e599735186390 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e599735186390 : Closed e599735186390 ∧ code e599735186390 = 9395828208598 := by decide
theorem cert_e599735186390 : check e599735186390 [[.under]] .sourceHead = true := by decide
def e599735186394 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e599735186394 : Closed e599735186394 ∧ code e599735186394 = 9395828208602 := by decide
theorem cert_e599735186394 : check e599735186394 [[.under]] .sourceHead = true := by decide
def e599735186670 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e599735186670 : Closed e599735186670 ∧ code e599735186670 = 9395828208878 := by decide
theorem cert_e599735186670 : check e599735186670 [[.under]] .sourceHead = true := by decide
def e599735186678 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e599735186678 : Closed e599735186678 ∧ code e599735186678 = 9395828208886 := by decide
theorem cert_e599735186678 : check e599735186678 [[.under]] .sourceHead = true := by decide
def e599735187054 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e599735187054 : Closed e599735187054 ∧ code e599735187054 = 9395828209262 := by decide
theorem cert_e599735187054 : check e599735187054 [[.under]] .sourceHead = true := by decide
def e599735187066 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e599735187066 : Closed e599735187066 ∧ code e599735187066 = 9395828209274 := by decide
theorem cert_e599735187066 : check e599735187066 [[.under]] .sourceHead = true := by decide
def e599735187254 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e599735187254 : Closed e599735187254 ∧ code e599735187254 = 9395828209462 := by decide
theorem cert_e599735187254 : check e599735187254 [[.under]] .sourceHead = true := by decide
def e599735187258 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e599735187258 : Closed e599735187258 ∧ code e599735187258 = 9395828209466 := by decide
theorem cert_e599735187258 : check e599735187258 [[.under]] .sourceHead = true := by decide
def e599735187886 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e599735187886 : Closed e599735187886 ∧ code e599735187886 = 9395828210094 := by decide
theorem cert_e599735187886 : check e599735187886 [[.under]] .sourceHead = true := by decide
def e599735187898 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e599735187898 : Closed e599735187898 ∧ code e599735187898 = 9395828210106 := by decide
theorem cert_e599735187898 : check e599735187898 [[.under]] .sourceHead = true := by decide
def e599735187946 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e599735187946 : Closed e599735187946 ∧ code e599735187946 = 9395828210154 := by decide
theorem cert_e599735187946 : check e599735187946 [[.under]] .sourceHead = true := by decide
def e599735188078 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e599735188078 : Closed e599735188078 ∧ code e599735188078 = 9395828210286 := by decide
theorem cert_e599735188078 : check e599735188078 [[.under]] .sourceHead = true := by decide
def e599735188090 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e599735188090 : Closed e599735188090 ∧ code e599735188090 = 9395828210298 := by decide
theorem cert_e599735188090 : check e599735188090 [[.under]] .sourceHead = true := by decide
def e599735188378 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e599735188378 : Closed e599735188378 ∧ code e599735188378 = 9395828210586 := by decide
theorem cert_e599735188378 : check e599735188378 [[.under]] .sourceHead = true := by decide
def e599735188694 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e599735188694 : Closed e599735188694 ∧ code e599735188694 = 9395828210902 := by decide
theorem cert_e599735188694 : check e599735188694 [[.under]] .sourceHead = true := by decide
def e599735188698 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e599735188698 : Closed e599735188698 ∧ code e599735188698 = 9395828210906 := by decide
theorem cert_e599735188698 : check e599735188698 [[.under]] .sourceHead = true := by decide
def e599735188714 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e599735188714 : Closed e599735188714 ∧ code e599735188714 = 9395828210922 := by decide
theorem cert_e599735188714 : check e599735188714 [[.under]] .sourceHead = true := by decide
def e599735188790 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e599735188790 : Closed e599735188790 ∧ code e599735188790 = 9395828210998 := by decide
theorem cert_e599735188790 : check e599735188790 [[.under]] .sourceHead = true := by decide
def e599735188794 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e599735188794 : Closed e599735188794 ∧ code e599735188794 = 9395828211002 := by decide
theorem cert_e599735188794 : check e599735188794 [[.under]] .sourceHead = true := by decide
def e599735188890 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e599735188890 : Closed e599735188890 ∧ code e599735188890 = 9395828211098 := by decide
theorem cert_e599735188890 : check e599735188890 [[.under]] .sourceHead = true := by decide
def e599735192430 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e599735192430 : Closed e599735192430 ∧ code e599735192430 = 9395828214638 := by decide
theorem cert_e599735192430 : check e599735192430 [[.under]] .sourceHead = true := by decide
def e599735192438 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e599735192438 : Closed e599735192438 ∧ code e599735192438 = 9395828214646 := by decide
theorem cert_e599735192438 : check e599735192438 [[.under]] .sourceHead = true := by decide
def e599735192494 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e599735192494 : Closed e599735192494 ∧ code e599735192494 = 9395828214702 := by decide
theorem cert_e599735192494 : check e599735192494 [[.under]] .sourceHead = true := by decide
def e599735192506 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e599735192506 : Closed e599735192506 ∧ code e599735192506 = 9395828214714 := by decide
theorem cert_e599735192506 : check e599735192506 [[.under]] .sourceHead = true := by decide
def e599735192534 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e599735192534 : Closed e599735192534 ∧ code e599735192534 = 9395828214742 := by decide
theorem cert_e599735192534 : check e599735192534 [[.under]] .sourceHead = true := by decide
def e599735192538 : Term := (.lam (.app (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e599735192538 : Closed e599735192538 ∧ code e599735192538 = 9395828214746 := by decide
theorem cert_e599735192538 : check e599735192538 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
