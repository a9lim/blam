import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422373821562 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.lam (.var 3))) (.var 0))))))))
theorem wire_e2422373821562 : Closed e2422373821562 ∧ code e2422373821562 = 11218466843770 := by decide
theorem cert_e2422373821562 : check e2422373821562 [[],[]] .smaller = true := by decide
def e2422373821726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e2422373821726 : Closed e2422373821726 ∧ code e2422373821726 = 11218466843934 := by decide
theorem cert_e2422373821726 : check e2422373821726 [[],[]] .smaller = true := by decide
def e2422373821894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e2422373821894 : Closed e2422373821894 ∧ code e2422373821894 = 11218466844102 := by decide
theorem cert_e2422373821894 : check e2422373821894 [[],[]] .smaller = true := by decide
def e2422373821918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 3))))))))
theorem wire_e2422373821918 : Closed e2422373821918 ∧ code e2422373821918 = 11218466844126 := by decide
theorem cert_e2422373821918 : check e2422373821918 [[],[]] .three = true := by decide
def e2422373821922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 3)) (.lam (.var 0)))))))))
theorem wire_e2422373821922 : Closed e2422373821922 ∧ code e2422373821922 = 11218466844130 := by decide
theorem cert_e2422373821922 : check e2422373821922 [[],[]] .three = true := by decide
def e2422373821934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 0) (.var 3)) (.var 2))))))))
theorem wire_e2422373821934 : Closed e2422373821934 ∧ code e2422373821934 = 11218466844142 := by decide
theorem cert_e2422373821934 : check e2422373821934 [[],[]] .three = true := by decide
def e2422373822234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422373822234 : Closed e2422373822234 ∧ code e2422373822234 = 11218466844442 := by decide
theorem cert_e2422373822234 : check e2422373822234 [[],[]] .smaller = true := by decide
def e2422373822278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422373822278 : Closed e2422373822278 ∧ code e2422373822278 = 11218466844486 := by decide
theorem cert_e2422373822278 : check e2422373822278 [[],[]] .smaller = true := by decide
def e2422373822302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 3))))))))
theorem wire_e2422373822302 : Closed e2422373822302 ∧ code e2422373822302 = 11218466844510 := by decide
theorem cert_e2422373822302 : check e2422373822302 [[],[]] .three = true := by decide
def e2422373822330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 2) (.var 3)) (.var 0))))))))
theorem wire_e2422373822330 : Closed e2422373822330 ∧ code e2422373822330 = 11218466844538 := by decide
theorem cert_e2422373822330 : check e2422373822330 [[],[]] .three = true := by decide
def e2422373822346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373822346 : Closed e2422373822346 ∧ code e2422373822346 = 11218466844554 := by decide
theorem cert_e2422373822346 : check e2422373822346 [[],[]] .three = true := by decide
def e2422373822370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373822370 : Closed e2422373822370 ∧ code e2422373822370 = 11218466844578 := by decide
theorem cert_e2422373822370 : check e2422373822370 [[],[]] .three = true := by decide
def e2422373822382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 0)) (.var 2))))))))
theorem wire_e2422373822382 : Closed e2422373822382 ∧ code e2422373822382 = 11218466844590 := by decide
theorem cert_e2422373822382 : check e2422373822382 [[],[]] .three = true := by decide
def e2422373822394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.app (.var 3) (.var 2)) (.var 0))))))))
theorem wire_e2422373822394 : Closed e2422373822394 ∧ code e2422373822394 = 11218466844602 := by decide
theorem cert_e2422373822394 : check e2422373822394 [[],[]] .three = true := by decide
def e2422373822590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.lam (.var 5))))))))))
theorem wire_e2422373822590 : Closed e2422373822590 ∧ code e2422373822590 = 11218466844798 := by decide
theorem cert_e2422373822590 : check e2422373822590 [[],[]] .three = true := by decide
def e2422373822686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 0) (.var 3))))))))))
theorem wire_e2422373822686 : Closed e2422373822686 ∧ code e2422373822686 = 11218466844894 := by decide
theorem cert_e2422373822686 : check e2422373822686 [[],[]] .smaller = true := by decide
def e2422373822714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.lam (.app (.var 3) (.var 0))))))))))
theorem wire_e2422373822714 : Closed e2422373822714 ∧ code e2422373822714 = 11218466844922 := by decide
theorem cert_e2422373822714 : check e2422373822714 [[],[]] .smaller = true := by decide
def e2422373823262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 0) (.lam (.var 3))))))))))
theorem wire_e2422373823262 : Closed e2422373823262 ∧ code e2422373823262 = 11218466845470 := by decide
theorem cert_e2422373823262 : check e2422373823262 [[],[]] .smaller = true := by decide
def e2422373823430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.lam (.var 1))))))))))
theorem wire_e2422373823430 : Closed e2422373823430 ∧ code e2422373823430 = 11218466845638 := by decide
theorem cert_e2422373823430 : check e2422373823430 [[],[]] .smaller = true := by decide
def e2422373823454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373823454 : Closed e2422373823454 ∧ code e2422373823454 = 11218466845662 := by decide
theorem cert_e2422373823454 : check e2422373823454 [[],[]] .three = true := by decide
def e2422373823458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 3) (.lam (.var 0))))))))))
theorem wire_e2422373823458 : Closed e2422373823458 ∧ code e2422373823458 = 11218466845666 := by decide
theorem cert_e2422373823458 : check e2422373823458 [[],[]] .three = true := by decide
def e2422373823470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373823470 : Closed e2422373823470 ∧ code e2422373823470 = 11218466845678 := by decide
theorem cert_e2422373823470 : check e2422373823470 [[],[]] .three = true := by decide
def e2422373825590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373825590 : Closed e2422373825590 ∧ code e2422373825590 = 11218466847798 := by decide
theorem cert_e2422373825590 : check e2422373825590 [[],[]] .smaller = true := by decide
def e2422373825594 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373825594 : Closed e2422373825594 ∧ code e2422373825594 = 11218466847802 := by decide
theorem cert_e2422373825594 : check e2422373825594 [[],[]] .smaller = true := by decide
def e2422373825734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422373825734 : Closed e2422373825734 ∧ code e2422373825734 = 11218466847942 := by decide
theorem cert_e2422373825734 : check e2422373825734 [[],[]] .smaller = true := by decide
def e2422373825758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373825758 : Closed e2422373825758 ∧ code e2422373825758 = 11218466847966 := by decide
theorem cert_e2422373825758 : check e2422373825758 [[],[]] .three = true := by decide
def e2422373825786 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 2) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373825786 : Closed e2422373825786 ∧ code e2422373825786 = 11218466847994 := by decide
theorem cert_e2422373825786 : check e2422373825786 [[],[]] .three = true := by decide
def e2422373826062 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373826062 : Closed e2422373826062 ∧ code e2422373826062 = 11218466848270 := by decide
theorem cert_e2422373826062 : check e2422373826062 [[],[]] .three = true := by decide
def e2422373826146 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373826146 : Closed e2422373826146 ∧ code e2422373826146 = 11218466848354 := by decide
theorem cert_e2422373826146 : check e2422373826146 [[],[]] .three = true := by decide
def e2422373826158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373826158 : Closed e2422373826158 ∧ code e2422373826158 = 11218466848366 := by decide
theorem cert_e2422373826158 : check e2422373826158 [[],[]] .three = true := by decide
def e2422373826170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373826170 : Closed e2422373826170 ∧ code e2422373826170 = 11218466848378 := by decide
theorem cert_e2422373826170 : check e2422373826170 [[],[]] .three = true := by decide
def e2422373843438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.lam (.app (.var 2) (.var 2))))))))))
theorem wire_e2422373843438 : Closed e2422373843438 ∧ code e2422373843438 = 11218466865646 := by decide
theorem cert_e2422373843438 : check e2422373843438 [[],[]] .smaller = true := by decide
def e2422373844406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))))))))
theorem wire_e2422373844406 : Closed e2422373844406 ∧ code e2422373844406 = 11218466866614 := by decide
theorem cert_e2422373844406 : check e2422373844406 [[],[]] .smaller = true := by decide
def e2422373844438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))))))))
theorem wire_e2422373844438 : Closed e2422373844438 ∧ code e2422373844438 = 11218466866646 := by decide
theorem cert_e2422373844438 : check e2422373844438 [[],[]] .smaller = true := by decide
def e2422373844442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.app (.var 1) (.var 1)) (.var 0)))))))))
theorem wire_e2422373844442 : Closed e2422373844442 ∧ code e2422373844442 = 11218466866650 := by decide
theorem cert_e2422373844442 : check e2422373844442 [[],[]] .smaller = true := by decide
def e2422373844598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 0) (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373844598 : Closed e2422373844598 ∧ code e2422373844598 = 11218466866806 := by decide
theorem cert_e2422373844598 : check e2422373844598 [[],[]] .smaller = true := by decide
def e2422373844766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e2422373844766 : Closed e2422373844766 ∧ code e2422373844766 = 11218466866974 := by decide
theorem cert_e2422373844766 : check e2422373844766 [[],[]] .smaller = true := by decide
def e2422373844790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373844790 : Closed e2422373844790 ∧ code e2422373844790 = 11218466866998 := by decide
theorem cert_e2422373844790 : check e2422373844790 [[],[]] .smaller = true := by decide
def e2422373844794 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 1) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373844794 : Closed e2422373844794 ∧ code e2422373844794 = 11218466867002 := by decide
theorem cert_e2422373844794 : check e2422373844794 [[],[]] .smaller = true := by decide
def e2422373844878 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e2422373844878 : Closed e2422373844878 ∧ code e2422373844878 = 11218466867086 := by decide
theorem cert_e2422373844878 : check e2422373844878 [[],[]] .smaller = true := by decide
def e2422373844926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 2) (.var 4)))))))))
theorem wire_e2422373844926 : Closed e2422373844926 ∧ code e2422373844926 = 11218466867134 := by decide
theorem cert_e2422373844926 : check e2422373844926 [[],[]] .three = true := by decide
def e2422373844974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.app (.var 4) (.var 2)))))))))
theorem wire_e2422373844974 : Closed e2422373844974 ∧ code e2422373844974 = 11218466867182 := by decide
theorem cert_e2422373844974 : check e2422373844974 [[],[]] .three = true := by decide
def e2422373848490 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 0))))))))
theorem wire_e2422373848490 : Closed e2422373848490 ∧ code e2422373848490 = 11218466870698 := by decide
theorem cert_e2422373848490 : check e2422373848490 [[],[]] .smaller = true := by decide
def e2422373848586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.var 0))))))))
theorem wire_e2422373848586 : Closed e2422373848586 ∧ code e2422373848586 = 11218466870794 := by decide
theorem cert_e2422373848586 : check e2422373848586 [[],[]] .smaller = true := by decide
def e2422373848622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 0))) (.var 2))))))))
theorem wire_e2422373848622 : Closed e2422373848622 ∧ code e2422373848622 = 11218466870830 := by decide
theorem cert_e2422373848622 : check e2422373848622 [[],[]] .smaller = true := by decide
def e2422373848630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 1))) (.var 1))))))))
theorem wire_e2422373848630 : Closed e2422373848630 ∧ code e2422373848630 = 11218466870838 := by decide
theorem cert_e2422373848630 : check e2422373848630 [[],[]] .smaller = true := by decide
def e2422373848634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.lam (.var 2))) (.var 0))))))))
theorem wire_e2422373848634 : Closed e2422373848634 ∧ code e2422373848634 = 11218466870842 := by decide
theorem cert_e2422373848634 : check e2422373848634 [[],[]] .smaller = true := by decide
def e2422373848682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e2422373848682 : Closed e2422373848682 ∧ code e2422373848682 = 11218466870890 := by decide
theorem cert_e2422373848682 : check e2422373848682 [[],[]] .smaller = true := by decide
def e2422373848706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 0))))))))))
theorem wire_e2422373848706 : Closed e2422373848706 ∧ code e2422373848706 = 11218466870914 := by decide
theorem cert_e2422373848706 : check e2422373848706 [[],[]] .smaller = true := by decide
def e2422373848718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e2422373848718 : Closed e2422373848718 ∧ code e2422373848718 = 11218466870926 := by decide
theorem cert_e2422373848718 : check e2422373848718 [[],[]] .smaller = true := by decide
def e2422373848730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373848730 : Closed e2422373848730 ∧ code e2422373848730 = 11218466870938 := by decide
theorem cert_e2422373848730 : check e2422373848730 [[],[]] .smaller = true := by decide
def e2422373848774 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e2422373848774 : Closed e2422373848774 ∧ code e2422373848774 = 11218466870982 := by decide
theorem cert_e2422373848774 : check e2422373848774 [[],[]] .smaller = true := by decide
def e2422373848798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 3))))))))
theorem wire_e2422373848798 : Closed e2422373848798 ∧ code e2422373848798 = 11218466871006 := by decide
theorem cert_e2422373848798 : check e2422373848798 [[],[]] .three = true := by decide
def e2422373848802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.lam (.var 0)))))))))
theorem wire_e2422373848802 : Closed e2422373848802 ∧ code e2422373848802 = 11218466871010 := by decide
theorem cert_e2422373848802 : check e2422373848802 [[],[]] .smaller = true := by decide
def e2422373848814 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 2)) (.var 2))))))))
theorem wire_e2422373848814 : Closed e2422373848814 ∧ code e2422373848814 = 11218466871022 := by decide
theorem cert_e2422373848814 : check e2422373848814 [[],[]] .smaller = true := by decide
def e2422373848822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 0) (.var 3)) (.var 1))))))))
theorem wire_e2422373848822 : Closed e2422373848822 ∧ code e2422373848822 = 11218466871030 := by decide
theorem cert_e2422373848822 : check e2422373848822 [[],[]] .three = true := by decide
def e2422373848858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422373848858 : Closed e2422373848858 ∧ code e2422373848858 = 11218466871066 := by decide
theorem cert_e2422373848858 : check e2422373848858 [[],[]] .smaller = true := by decide
def e2422373848902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422373848902 : Closed e2422373848902 ∧ code e2422373848902 = 11218466871110 := by decide
theorem cert_e2422373848902 : check e2422373848902 [[],[]] .smaller = true := by decide
def e2422373848926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 3))))))))
theorem wire_e2422373848926 : Closed e2422373848926 ∧ code e2422373848926 = 11218466871134 := by decide
theorem cert_e2422373848926 : check e2422373848926 [[],[]] .three = true := by decide
def e2422373848954 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 1) (.var 3)) (.var 0))))))))
theorem wire_e2422373848954 : Closed e2422373848954 ∧ code e2422373848954 = 11218466871162 := by decide
theorem cert_e2422373848954 : check e2422373848954 [[],[]] .three = true := by decide
def e2422373848970 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373848970 : Closed e2422373848970 ∧ code e2422373848970 = 11218466871178 := by decide
theorem cert_e2422373848970 : check e2422373848970 [[],[]] .smaller = true := by decide
def e2422373848994 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373848994 : Closed e2422373848994 ∧ code e2422373848994 = 11218466871202 := by decide
theorem cert_e2422373848994 : check e2422373848994 [[],[]] .smaller = true := by decide
def e2422373849006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 0)) (.var 2))))))))
theorem wire_e2422373849006 : Closed e2422373849006 ∧ code e2422373849006 = 11218466871214 := by decide
theorem cert_e2422373849006 : check e2422373849006 [[],[]] .smaller = true := by decide
def e2422373849018 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 2) (.var 2)) (.var 0))))))))
theorem wire_e2422373849018 : Closed e2422373849018 ∧ code e2422373849018 = 11218466871226 := by decide
theorem cert_e2422373849018 : check e2422373849018 [[],[]] .smaller = true := by decide
def e2422373849046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2422373849046 : Closed e2422373849046 ∧ code e2422373849046 = 11218466871254 := by decide
theorem cert_e2422373849046 : check e2422373849046 [[],[]] .three = true := by decide
def e2422373849050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2422373849050 : Closed e2422373849050 ∧ code e2422373849050 = 11218466871258 := by decide
theorem cert_e2422373849050 : check e2422373849050 [[],[]] .three = true := by decide
def e2422373849114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.app (.var 0) (.var 0)))))))))))
theorem wire_e2422373849114 : Closed e2422373849114 ∧ code e2422373849114 = 11218466871322 := by decide
theorem cert_e2422373849114 : check e2422373849114 [[],[]] .smaller = true := by decide
def e2422373849150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.lam (.var 4))))))))))
theorem wire_e2422373849150 : Closed e2422373849150 ∧ code e2422373849150 = 11218466871358 := by decide
theorem cert_e2422373849150 : check e2422373849150 [[],[]] .smaller = true := by decide
def e2422373849198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 0) (.var 2))))))))))
theorem wire_e2422373849198 : Closed e2422373849198 ∧ code e2422373849198 = 11218466871406 := by decide
theorem cert_e2422373849198 : check e2422373849198 [[],[]] .smaller = true := by decide
def e2422373849206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 1) (.var 1))))))))))
theorem wire_e2422373849206 : Closed e2422373849206 ∧ code e2422373849206 = 11218466871414 := by decide
theorem cert_e2422373849206 : check e2422373849206 [[],[]] .smaller = true := by decide
def e2422373849210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.lam (.app (.var 2) (.var 0))))))))))
theorem wire_e2422373849210 : Closed e2422373849210 ∧ code e2422373849210 = 11218466871418 := by decide
theorem cert_e2422373849210 : check e2422373849210 [[],[]] .smaller = true := by decide
def e2422373849450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0)))))))))
theorem wire_e2422373849450 : Closed e2422373849450 ∧ code e2422373849450 = 11218466871658 := by decide
theorem cert_e2422373849450 : check e2422373849450 [[],[]] .smaller = true := by decide
def e2422373849474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0)))))))))))
theorem wire_e2422373849474 : Closed e2422373849474 ∧ code e2422373849474 = 11218466871682 := by decide
theorem cert_e2422373849474 : check e2422373849474 [[],[]] .smaller = true := by decide
def e2422373849486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.lam (.var 2))))))))))
theorem wire_e2422373849486 : Closed e2422373849486 ∧ code e2422373849486 = 11218466871694 := by decide
theorem cert_e2422373849486 : check e2422373849486 [[],[]] .smaller = true := by decide
def e2422373849498 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373849498 : Closed e2422373849498 ∧ code e2422373849498 = 11218466871706 := by decide
theorem cert_e2422373849498 : check e2422373849498 [[],[]] .smaller = true := by decide
def e2422373849542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.lam (.var 1))))))))))
theorem wire_e2422373849542 : Closed e2422373849542 ∧ code e2422373849542 = 11218466871750 := by decide
theorem cert_e2422373849542 : check e2422373849542 [[],[]] .smaller = true := by decide
def e2422373849566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2422373849566 : Closed e2422373849566 ∧ code e2422373849566 = 11218466871774 := by decide
theorem cert_e2422373849566 : check e2422373849566 [[],[]] .three = true := by decide
def e2422373849570 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.lam (.var 0))))))))))
theorem wire_e2422373849570 : Closed e2422373849570 ∧ code e2422373849570 = 11218466871778 := by decide
theorem cert_e2422373849570 : check e2422373849570 [[],[]] .smaller = true := by decide
def e2422373849582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 2) (.var 2)))))))))
theorem wire_e2422373849582 : Closed e2422373849582 ∧ code e2422373849582 = 11218466871790 := by decide
theorem cert_e2422373849582 : check e2422373849582 [[],[]] .smaller = true := by decide
def e2422373849590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2422373849590 : Closed e2422373849590 ∧ code e2422373849590 = 11218466871798 := by decide
theorem cert_e2422373849590 : check e2422373849590 [[],[]] .three = true := by decide
def e2422373850166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373850166 : Closed e2422373850166 ∧ code e2422373850166 = 11218466872374 := by decide
theorem cert_e2422373850166 : check e2422373850166 [[],[]] .smaller = true := by decide
def e2422373850170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373850170 : Closed e2422373850170 ∧ code e2422373850170 = 11218466872378 := by decide
theorem cert_e2422373850170 : check e2422373850170 [[],[]] .smaller = true := by decide
def e2422373850310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422373850310 : Closed e2422373850310 ∧ code e2422373850310 = 11218466872518 := by decide
theorem cert_e2422373850310 : check e2422373850310 [[],[]] .smaller = true := by decide
def e2422373850334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373850334 : Closed e2422373850334 ∧ code e2422373850334 = 11218466872542 := by decide
theorem cert_e2422373850334 : check e2422373850334 [[],[]] .three = true := by decide
def e2422373850362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373850362 : Closed e2422373850362 ∧ code e2422373850362 = 11218466872570 := by decide
theorem cert_e2422373850362 : check e2422373850362 [[],[]] .three = true := by decide
def e2422373850638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373850638 : Closed e2422373850638 ∧ code e2422373850638 = 11218466872846 := by decide
theorem cert_e2422373850638 : check e2422373850638 [[],[]] .smaller = true := by decide
def e2422373850686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.lam (.var 4)))))))))
theorem wire_e2422373850686 : Closed e2422373850686 ∧ code e2422373850686 = 11218466872894 := by decide
theorem cert_e2422373850686 : check e2422373850686 [[],[]] .three = true := by decide
def e2422373850722 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373850722 : Closed e2422373850722 ∧ code e2422373850722 = 11218466872930 := by decide
theorem cert_e2422373850722 : check e2422373850722 [[],[]] .smaller = true := by decide
def e2422373850734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373850734 : Closed e2422373850734 ∧ code e2422373850734 = 11218466872942 := by decide
theorem cert_e2422373850734 : check e2422373850734 [[],[]] .smaller = true := by decide
def e2422373850746 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373850746 : Closed e2422373850746 ∧ code e2422373850746 = 11218466872954 := by decide
theorem cert_e2422373850746 : check e2422373850746 [[],[]] .smaller = true := by decide
def e2422373850910 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.lam (.var 3)))))))))
theorem wire_e2422373850910 : Closed e2422373850910 ∧ code e2422373850910 = 11218466873118 := by decide
theorem cert_e2422373850910 : check e2422373850910 [[],[]] .three = true := by decide
def e2422373850934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373850934 : Closed e2422373850934 ∧ code e2422373850934 = 11218466873142 := by decide
theorem cert_e2422373850934 : check e2422373850934 [[],[]] .three = true := by decide
def e2422373850938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373850938 : Closed e2422373850938 ∧ code e2422373850938 = 11218466873146 := by decide
theorem cert_e2422373850938 : check e2422373850938 [[],[]] .three = true := by decide
def e2422373860054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e2422373860054 : Closed e2422373860054 ∧ code e2422373860054 = 11218466882262 := by decide
theorem cert_e2422373860054 : check e2422373860054 [[],[]] .three = true := by decide
def e2422373860058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e2422373860058 : Closed e2422373860058 ∧ code e2422373860058 = 11218466882266 := by decide
theorem cert_e2422373860058 : check e2422373860058 [[],[]] .three = true := by decide
def e2422373860074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e2422373860074 : Closed e2422373860074 ∧ code e2422373860074 = 11218466882282 := by decide
theorem cert_e2422373860074 : check e2422373860074 [[],[]] .three = true := by decide
def e2422373860150 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373860150 : Closed e2422373860150 ∧ code e2422373860150 = 11218466882358 := by decide
theorem cert_e2422373860150 : check e2422373860150 [[],[]] .three = true := by decide
def e2422373860154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373860154 : Closed e2422373860154 ∧ code e2422373860154 = 11218466882362 := by decide
theorem cert_e2422373860154 : check e2422373860154 [[],[]] .three = true := by decide
def e2422373860238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e2422373860238 : Closed e2422373860238 ∧ code e2422373860238 = 11218466882446 := by decide
theorem cert_e2422373860238 : check e2422373860238 [[],[]] .three = true := by decide
def e2422373860250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e2422373860250 : Closed e2422373860250 ∧ code e2422373860250 = 11218466882458 := by decide
theorem cert_e2422373860250 : check e2422373860250 [[],[]] .three = true := by decide
def e2422373860286 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 1) (.var 4)))))))))
theorem wire_e2422373860286 : Closed e2422373860286 ∧ code e2422373860286 = 11218466882494 := by decide
theorem cert_e2422373860286 : check e2422373860286 [[],[]] .three = true := by decide
def e2422373860318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 2) (.var 3)))))))))
theorem wire_e2422373860318 : Closed e2422373860318 ∧ code e2422373860318 = 11218466882526 := by decide
theorem cert_e2422373860318 : check e2422373860318 [[],[]] .three = true := by decide
def e2422373860334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 3) (.var 2)))))))))
theorem wire_e2422373860334 : Closed e2422373860334 ∧ code e2422373860334 = 11218466882542 := by decide
theorem cert_e2422373860334 : check e2422373860334 [[],[]] .three = true := by decide
def e2422373860342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.lam (.app (.var 4) (.var 1)))))))))
theorem wire_e2422373860342 : Closed e2422373860342 ∧ code e2422373860342 = 11218466882550 := by decide
theorem cert_e2422373860342 : check e2422373860342 [[],[]] .three = true := by decide
def e2422373862166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.lam (.var 0))) (.var 1))))))))
theorem wire_e2422373862166 : Closed e2422373862166 ∧ code e2422373862166 = 11218466884374 := by decide
theorem cert_e2422373862166 : check e2422373862166 [[],[]] .three = true := by decide
def e2422373862170 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.lam (.var 1))) (.var 0))))))))
theorem wire_e2422373862170 : Closed e2422373862170 ∧ code e2422373862170 = 11218466884378 := by decide
theorem cert_e2422373862170 : check e2422373862170 [[],[]] .three = true := by decide
def e2422373862214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.lam (.var 1)))))))))
theorem wire_e2422373862214 : Closed e2422373862214 ∧ code e2422373862214 = 11218466884422 := by decide
theorem cert_e2422373862214 : check e2422373862214 [[],[]] .three = true := by decide
def e2422373862238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 0)) (.var 3))))))))
theorem wire_e2422373862238 : Closed e2422373862238 ∧ code e2422373862238 = 11218466884446 := by decide
theorem cert_e2422373862238 : check e2422373862238 [[],[]] .three = true := by decide
def e2422373862242 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 1)) (.lam (.var 0)))))))))
theorem wire_e2422373862242 : Closed e2422373862242 ∧ code e2422373862242 = 11218466884450 := by decide
theorem cert_e2422373862242 : check e2422373862242 [[],[]] .three = true := by decide
def e2422373862254 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e2422373862254 : Closed e2422373862254 ∧ code e2422373862254 = 11218466884462 := by decide
theorem cert_e2422373862254 : check e2422373862254 [[],[]] .three = true := by decide
def e2422373862262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e2422373862262 : Closed e2422373862262 ∧ code e2422373862262 = 11218466884470 := by decide
theorem cert_e2422373862262 : check e2422373862262 [[],[]] .three = true := by decide
def e2422373862266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 0) (.var 3)) (.var 0))))))))
theorem wire_e2422373862266 : Closed e2422373862266 ∧ code e2422373862266 = 11218466884474 := by decide
theorem cert_e2422373862266 : check e2422373862266 [[],[]] .three = true := by decide
def e2422373862282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.lam (.var 0))) (.var 0))))))))
theorem wire_e2422373862282 : Closed e2422373862282 ∧ code e2422373862282 = 11218466884490 := by decide
theorem cert_e2422373862282 : check e2422373862282 [[],[]] .three = true := by decide
def e2422373862306 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 0)) (.lam (.var 0)))))))))
theorem wire_e2422373862306 : Closed e2422373862306 ∧ code e2422373862306 = 11218466884514 := by decide
theorem cert_e2422373862306 : check e2422373862306 [[],[]] .three = true := by decide
def e2422373862318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e2422373862318 : Closed e2422373862318 ∧ code e2422373862318 = 11218466884526 := by decide
theorem cert_e2422373862318 : check e2422373862318 [[],[]] .three = true := by decide
def e2422373862330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e2422373862330 : Closed e2422373862330 ∧ code e2422373862330 = 11218466884538 := by decide
theorem cert_e2422373862330 : check e2422373862330 [[],[]] .three = true := by decide
def e2422373862358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e2422373862358 : Closed e2422373862358 ∧ code e2422373862358 = 11218466884566 := by decide
theorem cert_e2422373862358 : check e2422373862358 [[],[]] .three = true := by decide
def e2422373862362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e2422373862362 : Closed e2422373862362 ∧ code e2422373862362 = 11218466884570 := by decide
theorem cert_e2422373862362 : check e2422373862362 [[],[]] .three = true := by decide
def e2422373862378 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.app (.var 3) (.var 0)) (.var 0))))))))
theorem wire_e2422373862378 : Closed e2422373862378 ∧ code e2422373862378 = 11218466884586 := by decide
theorem cert_e2422373862378 : check e2422373862378 [[],[]] .three = true := by decide
def e2422373862430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.lam (.var 3))))))))))
theorem wire_e2422373862430 : Closed e2422373862430 ∧ code e2422373862430 = 11218466884638 := by decide
theorem cert_e2422373862430 : check e2422373862430 [[],[]] .three = true := by decide
def e2422373862454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.app (.var 0) (.var 1))))))))))
theorem wire_e2422373862454 : Closed e2422373862454 ∧ code e2422373862454 = 11218466884662 := by decide
theorem cert_e2422373862454 : check e2422373862454 [[],[]] .three = true := by decide
def e2422373862458 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.lam (.app (.var 1) (.var 0))))))))))
theorem wire_e2422373862458 : Closed e2422373862458 ∧ code e2422373862458 = 11218466884666 := by decide
theorem cert_e2422373862458 : check e2422373862458 [[],[]] .three = true := by decide
def e2422373862598 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.lam (.var 1))))))))))
theorem wire_e2422373862598 : Closed e2422373862598 ∧ code e2422373862598 = 11218466884806 := by decide
theorem cert_e2422373862598 : check e2422373862598 [[],[]] .three = true := by decide
def e2422373862622 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 0) (.var 3)))))))))
theorem wire_e2422373862622 : Closed e2422373862622 ∧ code e2422373862622 = 11218466884830 := by decide
theorem cert_e2422373862622 : check e2422373862622 [[],[]] .three = true := by decide
def e2422373862626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 1) (.lam (.var 0))))))))))
theorem wire_e2422373862626 : Closed e2422373862626 ∧ code e2422373862626 = 11218466884834 := by decide
theorem cert_e2422373862626 : check e2422373862626 [[],[]] .three = true := by decide
def e2422373862638 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e2422373862638 : Closed e2422373862638 ∧ code e2422373862638 = 11218466884846 := by decide
theorem cert_e2422373862638 : check e2422373862638 [[],[]] .three = true := by decide
def e2422373862646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e2422373862646 : Closed e2422373862646 ∧ code e2422373862646 = 11218466884854 := by decide
theorem cert_e2422373862646 : check e2422373862646 [[],[]] .three = true := by decide
def e2422373862650 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.app (.var 3) (.var 0)))))))))
theorem wire_e2422373862650 : Closed e2422373862650 ∧ code e2422373862650 = 11218466884858 := by decide
theorem cert_e2422373862650 : check e2422373862650 [[],[]] .three = true := by decide
def e2422373862926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.lam (.lam (.var 2))))))))))
theorem wire_e2422373862926 : Closed e2422373862926 ∧ code e2422373862926 = 11218466885134 := by decide
theorem cert_e2422373862926 : check e2422373862926 [[],[]] .three = true := by decide
def e2422373863010 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 0) (.lam (.var 0))))))))))
theorem wire_e2422373863010 : Closed e2422373863010 ∧ code e2422373863010 = 11218466885218 := by decide
theorem cert_e2422373863010 : check e2422373863010 [[],[]] .three = true := by decide
def e2422373863022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e2422373863022 : Closed e2422373863022 ∧ code e2422373863022 = 11218466885230 := by decide
theorem cert_e2422373863022 : check e2422373863022 [[],[]] .three = true := by decide
def e2422373863034 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e2422373863034 : Closed e2422373863034 ∧ code e2422373863034 = 11218466885242 := by decide
theorem cert_e2422373863034 : check e2422373863034 [[],[]] .three = true := by decide
def e2422373863198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.lam (.var 3)))))))))
theorem wire_e2422373863198 : Closed e2422373863198 ∧ code e2422373863198 = 11218466885406 := by decide
theorem cert_e2422373863198 : check e2422373863198 [[],[]] .three = true := by decide
def e2422373863222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373863222 : Closed e2422373863222 ∧ code e2422373863222 = 11218466885430 := by decide
theorem cert_e2422373863222 : check e2422373863222 [[],[]] .three = true := by decide
def e2422373863226 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373863226 : Closed e2422373863226 ∧ code e2422373863226 = 11218466885434 := by decide
theorem cert_e2422373863226 : check e2422373863226 [[],[]] .three = true := by decide
def e2422373863322 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 3) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373863322 : Closed e2422373863322 ∧ code e2422373863322 = 11218466885530 := by decide
theorem cert_e2422373863322 : check e2422373863322 [[],[]] .three = true := by decide
def e2422373879094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373879094 : Closed e2422373879094 ∧ code e2422373879094 = 11218466901302 := by decide
theorem cert_e2422373879094 : check e2422373879094 [[],[]] .smaller = true := by decide
def e2422373879098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 0) (.var 0))))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373879098 : Closed e2422373879098 ∧ code e2422373879098 = 11218466901306 := by decide
theorem cert_e2422373879098 : check e2422373879098 [[],[]] .smaller = true := by decide
def e2422373879670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 2))))) (.var 1)))))))
theorem wire_e2422373879670 : Closed e2422373879670 ∧ code e2422373879670 = 11218466901878 := by decide
theorem cert_e2422373879670 : check e2422373879670 [[],[]] .smaller = true := by decide
def e2422373879674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 2) (.var 3))))) (.var 0)))))))
theorem wire_e2422373879674 : Closed e2422373879674 ∧ code e2422373879674 = 11218466901882 := by decide
theorem cert_e2422373879674 : check e2422373879674 [[],[]] .smaller = true := by decide
def e2422373879738 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.app (.var 3) (.var 2))))) (.var 0)))))))
theorem wire_e2422373879738 : Closed e2422373879738 ∧ code e2422373879738 = 11218466901946 := by decide
theorem cert_e2422373879738 : check e2422373879738 [[],[]] .smaller = true := by decide
def e2422373880534 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e2422373880534 : Closed e2422373880534 ∧ code e2422373880534 = 11218466902742 := by decide
theorem cert_e2422373880534 : check e2422373880534 [[],[]] .smaller = true := by decide
def e2422373880538 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e2422373880538 : Closed e2422373880538 ∧ code e2422373880538 = 11218466902746 := by decide
theorem cert_e2422373880538 : check e2422373880538 [[],[]] .smaller = true := by decide
def e2422373880554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e2422373880554 : Closed e2422373880554 ∧ code e2422373880554 = 11218466902762 := by decide
theorem cert_e2422373880554 : check e2422373880554 [[],[]] .smaller = true := by decide
def e2422373880630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e2422373880630 : Closed e2422373880630 ∧ code e2422373880630 = 11218466902838 := by decide
theorem cert_e2422373880630 : check e2422373880630 [[],[]] .smaller = true := by decide
def e2422373880634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e2422373880634 : Closed e2422373880634 ∧ code e2422373880634 = 11218466902842 := by decide
theorem cert_e2422373880634 : check e2422373880634 [[],[]] .smaller = true := by decide
def e2422373880730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 0)))) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e2422373880730 : Closed e2422373880730 ∧ code e2422373880730 = 11218466902938 := by decide
theorem cert_e2422373880730 : check e2422373880730 [[],[]] .smaller = true := by decide
def e2422373883102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 0) (.var 3))))))))
theorem wire_e2422373883102 : Closed e2422373883102 ∧ code e2422373883102 = 11218466905310 := by decide
theorem cert_e2422373883102 : check e2422373883102 [[],[]] .three = true := by decide
def e2422373883118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 1) (.var 2))))))))
theorem wire_e2422373883118 : Closed e2422373883118 ∧ code e2422373883118 = 11218466905326 := by decide
theorem cert_e2422373883118 : check e2422373883118 [[],[]] .smaller = true := by decide
def e2422373883126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 2) (.var 1))))))))
theorem wire_e2422373883126 : Closed e2422373883126 ∧ code e2422373883126 = 11218466905334 := by decide
theorem cert_e2422373883126 : check e2422373883126 [[],[]] .smaller = true := by decide
def e2422373883130 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 2)))) (.app (.var 3) (.var 0))))))))
theorem wire_e2422373883130 : Closed e2422373883130 ∧ code e2422373883130 = 11218466905338 := by decide
theorem cert_e2422373883130 : check e2422373883130 [[],[]] .three = true := by decide
def e2422373883502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 0) (.var 2))))))))
theorem wire_e2422373883502 : Closed e2422373883502 ∧ code e2422373883502 = 11218466905710 := by decide
theorem cert_e2422373883502 : check e2422373883502 [[],[]] .smaller = true := by decide
def e2422373883514 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 3)))) (.app (.var 2) (.var 0))))))))
theorem wire_e2422373883514 : Closed e2422373883514 ∧ code e2422373883514 = 11218466905722 := by decide
theorem cert_e2422373883514 : check e2422373883514 [[],[]] .smaller = true := by decide
def e2422373883702 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.app (.var 0) (.var 1))))))))
theorem wire_e2422373883702 : Closed e2422373883702 ∧ code e2422373883702 = 11218466905910 := by decide
theorem cert_e2422373883702 : check e2422373883702 [[],[]] .smaller = true := by decide
def e2422373883706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 4)))) (.app (.var 1) (.var 0))))))))
theorem wire_e2422373883706 : Closed e2422373883706 ∧ code e2422373883706 = 11218466905914 := by decide
theorem cert_e2422373883706 : check e2422373883706 [[],[]] .smaller = true := by decide
def e2422373883802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.lam (.var 5)))) (.app (.var 0) (.var 0))))))))
theorem wire_e2422373883802 : Closed e2422373883802 ∧ code e2422373883802 = 11218466906010 := by decide
theorem cert_e2422373883802 : check e2422373883802 [[],[]] .three = true := by decide
def e2422373887414 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 1)))) (.var 1)))))))
theorem wire_e2422373887414 : Closed e2422373887414 ∧ code e2422373887414 = 11218466909622 := by decide
theorem cert_e2422373887414 : check e2422373887414 [[],[]] .smaller = true := by decide
def e2422373887418 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))) (.var 0)))))))
theorem wire_e2422373887418 : Closed e2422373887418 ∧ code e2422373887418 = 11218466909626 := by decide
theorem cert_e2422373887418 : check e2422373887418 [[],[]] .smaller = true := by decide
def e2422373887450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))) (.var 0)))))))
theorem wire_e2422373887450 : Closed e2422373887450 ∧ code e2422373887450 = 11218466909658 := by decide
theorem cert_e2422373887450 : check e2422373887450 [[],[]] .smaller = true := by decide
def e2422373887670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.lam (.app (.app (.var 1) (.var 0)) (.var 1)))) (.var 1)))))))
theorem wire_e2422373887670 : Closed e2422373887670 ∧ code e2422373887670 = 11218466909878 := by decide
theorem cert_e2422373887670 : check e2422373887670 [[],[]] .smaller = true := by decide
end Blc.Floor43
