import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2389752944598 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 0)) (.var 1))))))))
theorem wire_e2389752944598 : Closed e2389752944598 ∧ code e2389752944598 = 11185845966806 := by decide
theorem cert_e2389752944598 : check e2389752944598 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752944602 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 3) (.var 1)) (.var 0))))))))
theorem wire_e2389752944602 : Closed e2389752944602 ∧ code e2389752944602 = 11185845966810 := by decide
theorem cert_e2389752944602 : check e2389752944602 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752945118 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 3)))))))))
theorem wire_e2389752945118 : Closed e2389752945118 ∧ code e2389752945118 = 11185845967326 := by decide
theorem cert_e2389752945118 : check e2389752945118 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752945142 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 3) (.var 1)))))))))
theorem wire_e2389752945142 : Closed e2389752945142 ∧ code e2389752945142 = 11185845967350 := by decide
theorem cert_e2389752945142 : check e2389752945142 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752945886 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 3)))))))))
theorem wire_e2389752945886 : Closed e2389752945886 ∧ code e2389752945886 = 11185845968094 := by decide
theorem cert_e2389752945886 : check e2389752945886 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752945914 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 3) (.var 0)))))))))
theorem wire_e2389752945914 : Closed e2389752945914 ∧ code e2389752945914 = 11185845968122 := by decide
theorem cert_e2389752945914 : check e2389752945914 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752946486 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 0) (.var 1)))))))))
theorem wire_e2389752946486 : Closed e2389752946486 ∧ code e2389752946486 = 11185845968694 := by decide
theorem cert_e2389752946486 : check e2389752946486 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752946490 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.lam (.app (.var 3) (.app (.var 1) (.var 0)))))))))
theorem wire_e2389752946490 : Closed e2389752946490 ∧ code e2389752946490 = 11185845968698 := by decide
theorem cert_e2389752946490 : check e2389752946490 [[],[.left],[.left],[],[],[]] .smaller = true := by decide
def e2389752961262 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2389752961262 : Closed e2389752961262 ∧ code e2389752961262 = 11185845983470 := by decide
theorem cert_e2389752961262 : check e2389752961262 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2389752961270 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2389752961270 : Closed e2389752961270 ∧ code e2389752961270 = 11185845983478 := by decide
theorem cert_e2389752961270 : check e2389752961270 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2389752961822 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2389752961822 : Closed e2389752961822 ∧ code e2389752961822 = 11185845984030 := by decide
theorem cert_e2389752961822 : check e2389752961822 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2389752961934 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2389752961934 : Closed e2389752961934 ∧ code e2389752961934 = 11185845984142 := by decide
theorem cert_e2389752961934 : check e2389752961934 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2389752962158 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2389752962158 : Closed e2389752962158 ∧ code e2389752962158 = 11185845984366 := by decide
theorem cert_e2389752962158 : check e2389752962158 [[],[.left],[.left],[],[],[],[.under,.left],[.under],[.under,.left]] .chain = true := by decide
def e2389752962170 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2389752962170 : Closed e2389752962170 ∧ code e2389752962170 = 11185845984378 := by decide
theorem cert_e2389752962170 : check e2389752962170 [[],[.left],[.left],[],[],[],[.under,.left],[.under],[.under,.left]] .smaller = true := by decide
def e2389752962334 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2389752962334 : Closed e2389752962334 ∧ code e2389752962334 = 11185845984542 := by decide
theorem cert_e2389752962334 : check e2389752962334 [[],[.left],[.left],[],[],[],[.under,.left],[.under]] .sourceHead = true := by decide
def e2389752962502 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2389752962502 : Closed e2389752962502 ∧ code e2389752962502 = 11185845984710 := by decide
private def t_e2389752962502 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.lam (.var 1))))))))
theorem cert_e2389752962502 : ¬ IsSelfInterpreter e2389752962502 :=
  wSource (t := t_e2389752962502) (replay_sound (ps := [[],[.left],[.left]]) (t := e2389752962502) (by decide)) (by decide)
def e2389752962614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2389752962614 : Closed e2389752962614 ∧ code e2389752962614 = 11185845984822 := by decide
theorem cert_e2389752962614 : check e2389752962614 [[],[.left],[.left],[],[],[],[.under,.left]] .chain = true := by decide
def e2389752962618 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2389752962618 : Closed e2389752962618 ∧ code e2389752962618 = 11185845984826 := by decide
theorem cert_e2389752962618 : check e2389752962618 [[],[.left],[.left],[],[],[],[.under,.left],[.under,.left]] .chain = true := by decide
def e2389752962702 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2389752962702 : Closed e2389752962702 ∧ code e2389752962702 = 11185845984910 := by decide
theorem cert_e2389752962702 : check e2389752962702 [[],[.left],[.left],[],[],[],[.under,.left]] .chain = true := by decide
def e2389752962758 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2389752962758 : Closed e2389752962758 ∧ code e2389752962758 = 11185845984966 := by decide
private def t_e2389752962758 : Term := (.app (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.lam (.var 1))))))))
theorem cert_e2389752962758 : ¬ IsSelfInterpreter e2389752962758 :=
  wSource (t := t_e2389752962758) (replay_sound (ps := [[],[.left],[.left]]) (t := e2389752962758) (by decide)) (by decide)
def e2389752964894 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.lam (.var 3)))))))))
theorem wire_e2389752964894 : Closed e2389752964894 ∧ code e2389752964894 = 11185845987102 := by decide
theorem cert_e2389752964894 : check e2389752964894 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2389752965006 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.lam (.var 2)))))))))
theorem wire_e2389752965006 : Closed e2389752965006 ∧ code e2389752965006 = 11185845987214 := by decide
theorem cert_e2389752965006 : check e2389752965006 [[],[.left],[.left],[],[],[]] .sourceHead = true := by decide
def e2389752967966 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.lam (.var 3)))))))))
theorem wire_e2389752967966 : Closed e2389752967966 ∧ code e2389752967966 = 11185845990174 := by decide
theorem cert_e2389752967966 : checkPay e2389752967966 [[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[]] 0 [] = true := by decide
def e2389752968134 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.lam (.var 1)))))))))
theorem wire_e2389752968134 : Closed e2389752968134 ∧ code e2389752968134 = 11185845990342 := by decide
theorem cert_e2389752968134 : check e2389752968134 [[],[.left],[.left],[],[],[],[.under],[.under,.under,.left]] .chain = true := by decide
def e2389752969614 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.lam (.var 2)))))))))
theorem wire_e2389752969614 : Closed e2389752969614 ∧ code e2389752969614 = 11185845991822 := by decide
theorem cert_e2389752969614 : check e2389752969614 [[],[.left],[.left],[],[],[],[.under]] .sourceHead = true := by decide
def e2389752969670 : Term := (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.lam (.var 1)))))))))
theorem wire_e2389752969670 : Closed e2389752969670 ∧ code e2389752969670 = 11185845991878 := by decide
theorem cert_e2389752969670 : check e2389752969670 [[],[.left],[.left],[],[],[],[.under],[.under,.left],[.under],[.under],[.under,.under],[.under,.under,.left,.left]] .chain = true := by decide
def e2391226038810 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226038810 : Closed e2391226038810 ∧ code e2391226038810 = 11187319061018 := by decide
theorem cert_e2391226038810 : check e2391226038810 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left,.left]] .chain = true := by decide
def e2391226047002 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226047002 : Closed e2391226047002 ∧ code e2391226047002 = 11187319069210 := by decide
theorem cert_e2391226047002 : check e2391226047002 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2391226104346 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226104346 : Closed e2391226104346 ∧ code e2391226104346 = 11187319126554 := by decide
theorem cert_e2391226104346 : check e2391226104346 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2391226116634 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226116634 : Closed e2391226116634 ∧ code e2391226116634 = 11187319138842 := by decide
theorem cert_e2391226116634 : check e2391226116634 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left,.left]] .chain = true := by decide
def e2391226145306 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226145306 : Closed e2391226145306 ∧ code e2391226145306 = 11187319167514 := by decide
theorem cert_e2391226145306 : check e2391226145306 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left]] .smaller = true := by decide
def e2391226149402 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226149402 : Closed e2391226149402 ∧ code e2391226149402 = 11187319171610 := by decide
theorem cert_e2391226149402 : check e2391226149402 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391226432026 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226432026 : Closed e2391226432026 ∧ code e2391226432026 = 11187319454234 := by decide
theorem cert_e2391226432026 : check e2391226432026 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left,.left]] .chain = true := by decide
def e2391226440218 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226440218 : Closed e2391226440218 ∧ code e2391226440218 = 11187319462426 := by decide
theorem cert_e2391226440218 : check e2391226440218 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[]] .sourceHead = true := by decide
def e2391226825242 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226825242 : Closed e2391226825242 ∧ code e2391226825242 = 11187319847450 := by decide
theorem cert_e2391226825242 : check e2391226825242 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2391226837530 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391226837530 : Closed e2391226837530 ∧ code e2391226837530 = 11187319859738 := by decide
theorem cert_e2391226837530 : check e2391226837530 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2391227030042 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391227030042 : Closed e2391227030042 ∧ code e2391227030042 = 11187320052250 := by decide
theorem cert_e2391227030042 : check e2391227030042 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left],[.under,.under,.left,.left]] .chain = true := by decide
def e2391227034138 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391227034138 : Closed e2391227034138 ∧ code e2391227034138 = 11187320056346 := by decide
theorem cert_e2391227034138 : check e2391227034138 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.under,.left,.left]] .chain = true := by decide
def e2391235027482 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391235027482 : Closed e2391235027482 ∧ code e2391235027482 = 11187328049690 := by decide
theorem cert_e2391235027482 : check e2391235027482 [[]] .width = true := by decide
def e2391235029018 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391235029018 : Closed e2391235029018 ∧ code e2391235029018 = 11187328051226 := by decide
theorem cert_e2391235029018 : check e2391235029018 [[]] .width = true := by decide
def e2391235060250 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391235060250 : Closed e2391235060250 ∧ code e2391235060250 = 11187328082458 := by decide
theorem cert_e2391235060250 : check e2391235060250 [[]] .width = true := by decide
def e2391235061786 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391235061786 : Closed e2391235061786 ∧ code e2391235061786 = 11187328083994 := by decide
theorem cert_e2391235061786 : check e2391235061786 [[]] .width = true := by decide
def e2391235289626 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391235289626 : Closed e2391235289626 ∧ code e2391235289626 = 11187328311834 := by decide
theorem cert_e2391235289626 : check e2391235289626 [[]] .width = true := by decide
def e2391235291162 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391235291162 : Closed e2391235291162 ∧ code e2391235291162 = 11187328313370 := by decide
theorem cert_e2391235291162 : check e2391235291162 [[]] .width = true := by decide
def e2391235338778 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391235338778 : Closed e2391235338778 ∧ code e2391235338778 = 11187328360986 := by decide
private def t_e2391235338778 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391235338778 : ¬ IsSelfInterpreter e2391235338778 :=
  wSource (t := t_e2391235338778) (replay_sound (ps := []) (t := e2391235338778) (by decide)) (by decide)
def e2391235340314 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391235340314 : Closed e2391235340314 ∧ code e2391235340314 = 11187328362522 := by decide
theorem cert_e2391235340314 : check e2391235340314 [[]] .width = true := by decide
def e2391235453466 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391235453466 : Closed e2391235453466 ∧ code e2391235453466 = 11187328475674 := by decide
theorem cert_e2391235453466 : check e2391235453466 [[]] .width = true := by decide
def e2391235455002 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391235455002 : Closed e2391235455002 ∧ code e2391235455002 = 11187328477210 := by decide
theorem cert_e2391235455002 : check e2391235455002 [[]] .width = true := by decide
def e2391235469850 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391235469850 : Closed e2391235469850 ∧ code e2391235469850 = 11187328492058 := by decide
private def t_e2391235469850 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391235469850 : ¬ IsSelfInterpreter e2391235469850 :=
  wSource (t := t_e2391235469850) (replay_sound (ps := []) (t := e2391235469850) (by decide)) (by decide)
def e2391235471386 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391235471386 : Closed e2391235471386 ∧ code e2391235471386 = 11187328493594 := by decide
theorem cert_e2391235471386 : check e2391235471386 [[]] .width = true := by decide
def e2391236600346 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391236600346 : Closed e2391236600346 ∧ code e2391236600346 = 11187329622554 := by decide
theorem cert_e2391236600346 : check e2391236600346 [[]] .width = true := by decide
def e2391236601882 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391236601882 : Closed e2391236601882 ∧ code e2391236601882 = 11187329624090 := by decide
theorem cert_e2391236601882 : check e2391236601882 [[]] .width = true := by decide
def e2391236633114 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391236633114 : Closed e2391236633114 ∧ code e2391236633114 = 11187329655322 := by decide
theorem cert_e2391236633114 : check e2391236633114 [[]] .width = true := by decide
def e2391236634650 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391236634650 : Closed e2391236634650 ∧ code e2391236634650 = 11187329656858 := by decide
theorem cert_e2391236634650 : check e2391236634650 [[]] .width = true := by decide
def e2391238173210 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391238173210 : Closed e2391238173210 ∧ code e2391238173210 = 11187331195418 := by decide
theorem cert_e2391238173210 : check e2391238173210 [[]] .width = true := by decide
def e2391238174746 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391238174746 : Closed e2391238174746 ∧ code e2391238174746 = 11187331196954 := by decide
theorem cert_e2391238174746 : check e2391238174746 [[]] .width = true := by decide
def e2391238222362 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391238222362 : Closed e2391238222362 ∧ code e2391238222362 = 11187331244570 := by decide
theorem cert_e2391238222362 : check e2391238222362 [[]] .width = true := by decide
def e2391238223898 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391238223898 : Closed e2391238223898 ∧ code e2391238223898 = 11187331246106 := by decide
theorem cert_e2391238223898 : check e2391238223898 [[]] .width = true := by decide
def e2391238992410 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391238992410 : Closed e2391238992410 ∧ code e2391238992410 = 11187332014618 := by decide
theorem cert_e2391238992410 : check e2391238992410 [[]] .width = true := by decide
def e2391238993946 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391238993946 : Closed e2391238993946 ∧ code e2391238993946 = 11187332016154 := by decide
theorem cert_e2391238993946 : check e2391238993946 [[]] .width = true := by decide
def e2391239008794 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.var 0)))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391239008794 : Closed e2391239008794 ∧ code e2391239008794 = 11187332031002 := by decide
theorem cert_e2391239008794 : check e2391239008794 [[]] .width = true := by decide
def e2391239010330 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.var 0))) (.lam (.lam (.app (.var 0) (.var 0)))))
theorem wire_e2391239010330 : Closed e2391239010330 ∧ code e2391239010330 = 11187332032538 := by decide
theorem cert_e2391239010330 : check e2391239010330 [[]] .width = true := by decide
def e2391290899994 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391290899994 : Closed e2391290899994 ∧ code e2391290899994 = 11187383922202 := by decide
theorem cert_e2391290899994 : check e2391290899994 [[]] .width = true := by decide
def e2391290902042 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391290902042 : Closed e2391290902042 ∧ code e2391290902042 = 11187383924250 := by decide
theorem cert_e2391290902042 : check e2391290902042 [[]] .width = true := by decide
def e2391290916378 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391290916378 : Closed e2391290916378 ∧ code e2391290916378 = 11187383938586 := by decide
theorem cert_e2391290916378 : check e2391290916378 [[]] .width = true := by decide
def e2391290919450 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391290919450 : Closed e2391290919450 ∧ code e2391290919450 = 11187383941658 := by decide
theorem cert_e2391290919450 : check e2391290919450 [[]] .width = true := by decide
def e2391290926618 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391290926618 : Closed e2391290926618 ∧ code e2391290926618 = 11187383948826 := by decide
theorem cert_e2391290926618 : check e2391290926618 [[]] .width = true := by decide
def e2391290927642 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391290927642 : Closed e2391290927642 ∧ code e2391290927642 = 11187383949850 := by decide
theorem cert_e2391290927642 : check e2391290927642 [[]] .width = true := by decide
def e2391290998298 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391290998298 : Closed e2391290998298 ∧ code e2391290998298 = 11187384020506 := by decide
theorem cert_e2391290998298 : check e2391290998298 [[]] .width = true := by decide
def e2391291000346 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391291000346 : Closed e2391291000346 ∧ code e2391291000346 = 11187384022554 := by decide
theorem cert_e2391291000346 : check e2391291000346 [[]] .width = true := by decide
def e2391291096602 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391291096602 : Closed e2391291096602 ∧ code e2391291096602 = 11187384118810 := by decide
theorem cert_e2391291096602 : check e2391291096602 [[]] .width = true := by decide
def e2391291099674 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391291099674 : Closed e2391291099674 ∧ code e2391291099674 = 11187384121882 := by decide
theorem cert_e2391291099674 : check e2391291099674 [[]] .width = true := by decide
def e2391291147802 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391291147802 : Closed e2391291147802 ∧ code e2391291147802 = 11187384170010 := by decide
theorem cert_e2391291147802 : check e2391291147802 [[]] .width = true := by decide
def e2391291148826 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391291148826 : Closed e2391291148826 ∧ code e2391291148826 = 11187384171034 := by decide
theorem cert_e2391291148826 : check e2391291148826 [[]] .width = true := by decide
def e2391306972526 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2391306972526 : Closed e2391306972526 ∧ code e2391306972526 = 11187399994734 := by decide
theorem cert_e2391306972526 : check e2391306972526 [[],[.left],[]] .sourceHead = true := by decide
def e2391306972534 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2391306972534 : Closed e2391306972534 ∧ code e2391306972534 = 11187399994742 := by decide
theorem cert_e2391306972534 : check e2391306972534 [[],[.left],[]] .sourceHead = true := by decide
def e2391306972590 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2391306972590 : Closed e2391306972590 ∧ code e2391306972590 = 11187399994798 := by decide
theorem cert_e2391306972590 : check e2391306972590 [[],[.left],[]] .sourceHead = true := by decide
def e2391306972602 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2391306972602 : Closed e2391306972602 ∧ code e2391306972602 = 11187399994810 := by decide
theorem cert_e2391306972602 : check e2391306972602 [[],[.left],[]] .sourceHead = true := by decide
def e2391306972630 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2391306972630 : Closed e2391306972630 ∧ code e2391306972630 = 11187399994838 := by decide
theorem cert_e2391306972630 : check e2391306972630 [[],[.left],[]] .sourceHead = true := by decide
def e2391306972634 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2391306972634 : Closed e2391306972634 ∧ code e2391306972634 = 11187399994842 := by decide
theorem cert_e2391306972634 : check e2391306972634 [[],[.left],[]] .sourceHead = true := by decide
def e2391306972846 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2391306972846 : Closed e2391306972846 ∧ code e2391306972846 = 11187399995054 := by decide
theorem cert_e2391306972846 : check e2391306972846 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under]] .sourceHead = true := by decide
def e2391306972858 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2391306972858 : Closed e2391306972858 ∧ code e2391306972858 = 11187399995066 := by decide
theorem cert_e2391306972858 : check e2391306972858 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2391306972906 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2391306972906 : Closed e2391306972906 ∧ code e2391306972906 = 11187399995114 := by decide
theorem cert_e2391306972906 : check e2391306972906 [[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391306973014 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2391306973014 : Closed e2391306973014 ∧ code e2391306973014 = 11187399995222 := by decide
theorem cert_e2391306973014 : check e2391306973014 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2391306973018 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2391306973018 : Closed e2391306973018 ∧ code e2391306973018 = 11187399995226 := by decide
theorem cert_e2391306973018 : check e2391306973018 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left,.left,.left],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2391306973034 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2391306973034 : Closed e2391306973034 ∧ code e2391306973034 = 11187399995242 := by decide
theorem cert_e2391306973034 : check e2391306973034 [[],[.left],[],[.under,.left,.left,.left],[.under,.left,.left]] .chain = true := by decide
def e2391306974062 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2391306974062 : Closed e2391306974062 ∧ code e2391306974062 = 11187399996270 := by decide
theorem cert_e2391306974062 : check e2391306974062 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974070 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2391306974070 : Closed e2391306974070 ∧ code e2391306974070 = 11187399996278 := by decide
theorem cert_e2391306974070 : check e2391306974070 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974126 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2391306974126 : Closed e2391306974126 ∧ code e2391306974126 = 11187399996334 := by decide
theorem cert_e2391306974126 : check e2391306974126 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974138 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2391306974138 : Closed e2391306974138 ∧ code e2391306974138 = 11187399996346 := by decide
theorem cert_e2391306974138 : check e2391306974138 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974166 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2391306974166 : Closed e2391306974166 ∧ code e2391306974166 = 11187399996374 := by decide
theorem cert_e2391306974166 : check e2391306974166 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974170 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2391306974170 : Closed e2391306974170 ∧ code e2391306974170 = 11187399996378 := by decide
theorem cert_e2391306974170 : check e2391306974170 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974446 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2391306974446 : Closed e2391306974446 ∧ code e2391306974446 = 11187399996654 := by decide
theorem cert_e2391306974446 : check e2391306974446 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974454 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2391306974454 : Closed e2391306974454 ∧ code e2391306974454 = 11187399996662 := by decide
theorem cert_e2391306974454 : check e2391306974454 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974830 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2391306974830 : Closed e2391306974830 ∧ code e2391306974830 = 11187399997038 := by decide
theorem cert_e2391306974830 : check e2391306974830 [[],[.left],[]] .sourceHead = true := by decide
def e2391306974842 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2391306974842 : Closed e2391306974842 ∧ code e2391306974842 = 11187399997050 := by decide
theorem cert_e2391306974842 : check e2391306974842 [[],[.left],[]] .sourceHead = true := by decide
def e2391306975030 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2391306975030 : Closed e2391306975030 ∧ code e2391306975030 = 11187399997238 := by decide
theorem cert_e2391306975030 : check e2391306975030 [[],[.left],[]] .sourceHead = true := by decide
def e2391306975034 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2391306975034 : Closed e2391306975034 ∧ code e2391306975034 = 11187399997242 := by decide
theorem cert_e2391306975034 : check e2391306975034 [[],[.left],[]] .sourceHead = true := by decide
def e2391306975662 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2))))))
theorem wire_e2391306975662 : Closed e2391306975662 ∧ code e2391306975662 = 11187399997870 := by decide
theorem cert_e2391306975662 : check e2391306975662 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306975674 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0))))))
theorem wire_e2391306975674 : Closed e2391306975674 ∧ code e2391306975674 = 11187399997882 := by decide
theorem cert_e2391306975674 : check e2391306975674 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391306975722 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0))))))
theorem wire_e2391306975722 : Closed e2391306975722 ∧ code e2391306975722 = 11187399997930 := by decide
theorem cert_e2391306975722 : check e2391306975722 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391306975854 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2)))))))
theorem wire_e2391306975854 : Closed e2391306975854 ∧ code e2391306975854 = 11187399998062 := by decide
theorem cert_e2391306975854 : check e2391306975854 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306975866 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0)))))))
theorem wire_e2391306975866 : Closed e2391306975866 ∧ code e2391306975866 = 11187399998074 := by decide
theorem cert_e2391306975866 : check e2391306975866 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306976154 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0)))))))
theorem wire_e2391306976154 : Closed e2391306976154 ∧ code e2391306976154 = 11187399998362 := by decide
theorem cert_e2391306976154 : check e2391306976154 [[],[.left],[],[.under,.left]] .chain = true := by decide
def e2391306976470 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1))))))
theorem wire_e2391306976470 : Closed e2391306976470 ∧ code e2391306976470 = 11187399998678 := by decide
theorem cert_e2391306976470 : check e2391306976470 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left]] .chain = true := by decide
def e2391306976474 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0))))))
theorem wire_e2391306976474 : Closed e2391306976474 ∧ code e2391306976474 = 11187399998682 := by decide
theorem cert_e2391306976474 : check e2391306976474 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2391306976490 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0))))))
theorem wire_e2391306976490 : Closed e2391306976490 ∧ code e2391306976490 = 11187399998698 := by decide
theorem cert_e2391306976490 : check e2391306976490 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2391306976566 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1)))))))
theorem wire_e2391306976566 : Closed e2391306976566 ∧ code e2391306976566 = 11187399998774 := by decide
theorem cert_e2391306976566 : check e2391306976566 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left]] .sourceHead = true := by decide
def e2391306976570 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0)))))))
theorem wire_e2391306976570 : Closed e2391306976570 ∧ code e2391306976570 = 11187399998778 := by decide
theorem cert_e2391306976570 : check e2391306976570 [[],[.left],[],[.under,.left,.left],[.under,.left],[.under],[.under,.left],[.under,.left],[.under]] .chain = true := by decide
def e2391306976666 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0)))))))
theorem wire_e2391306976666 : Closed e2391306976666 ∧ code e2391306976666 = 11187399998874 := by decide
theorem cert_e2391306976666 : check e2391306976666 [[],[.left],[],[.under,.left,.left],[.under,.left]] .chain = true := by decide
def e2391306980206 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2391306980206 : Closed e2391306980206 ∧ code e2391306980206 = 11187400002414 := by decide
theorem cert_e2391306980206 : check e2391306980206 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980214 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2391306980214 : Closed e2391306980214 ∧ code e2391306980214 = 11187400002422 := by decide
theorem cert_e2391306980214 : check e2391306980214 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980270 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2391306980270 : Closed e2391306980270 ∧ code e2391306980270 = 11187400002478 := by decide
theorem cert_e2391306980270 : check e2391306980270 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980282 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2391306980282 : Closed e2391306980282 ∧ code e2391306980282 = 11187400002490 := by decide
theorem cert_e2391306980282 : check e2391306980282 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980310 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2391306980310 : Closed e2391306980310 ∧ code e2391306980310 = 11187400002518 := by decide
theorem cert_e2391306980310 : check e2391306980310 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980314 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2391306980314 : Closed e2391306980314 ∧ code e2391306980314 = 11187400002522 := by decide
theorem cert_e2391306980314 : check e2391306980314 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980590 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2391306980590 : Closed e2391306980590 ∧ code e2391306980590 = 11187400002798 := by decide
theorem cert_e2391306980590 : check e2391306980590 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980598 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2391306980598 : Closed e2391306980598 ∧ code e2391306980598 = 11187400002806 := by decide
theorem cert_e2391306980598 : check e2391306980598 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980974 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2391306980974 : Closed e2391306980974 ∧ code e2391306980974 = 11187400003182 := by decide
theorem cert_e2391306980974 : check e2391306980974 [[],[.left],[]] .sourceHead = true := by decide
def e2391306980986 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2391306980986 : Closed e2391306980986 ∧ code e2391306980986 = 11187400003194 := by decide
theorem cert_e2391306980986 : check e2391306980986 [[],[.left],[]] .sourceHead = true := by decide
def e2391306981174 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2391306981174 : Closed e2391306981174 ∧ code e2391306981174 = 11187400003382 := by decide
theorem cert_e2391306981174 : check e2391306981174 [[],[.left],[]] .sourceHead = true := by decide
def e2391306981178 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2391306981178 : Closed e2391306981178 ∧ code e2391306981178 = 11187400003386 := by decide
theorem cert_e2391306981178 : check e2391306981178 [[],[.left],[]] .sourceHead = true := by decide
def e2391306986926 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))
theorem wire_e2391306986926 : Closed e2391306986926 ∧ code e2391306986926 = 11187400009134 := by decide
theorem cert_e2391306986926 : check e2391306986926 [[],[.left],[],[.under]] .three = true := by decide
def e2391306986938 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))
theorem wire_e2391306986938 : Closed e2391306986938 ∧ code e2391306986938 = 11187400009146 := by decide
theorem cert_e2391306986938 : check e2391306986938 [[],[.left],[],[.under]] .three = true := by decide
def e2391306986986 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))
theorem wire_e2391306986986 : Closed e2391306986986 ∧ code e2391306986986 = 11187400009194 := by decide
theorem cert_e2391306986986 : check e2391306986986 [[],[.left],[],[.under]] .three = true := by decide
def e2391306987118 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))
theorem wire_e2391306987118 : Closed e2391306987118 ∧ code e2391306987118 = 11187400009326 := by decide
theorem cert_e2391306987118 : check e2391306987118 [[],[.left],[],[.under]] .three = true := by decide
def e2391306987130 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))
theorem wire_e2391306987130 : Closed e2391306987130 ∧ code e2391306987130 = 11187400009338 := by decide
theorem cert_e2391306987130 : check e2391306987130 [[],[.left],[],[.under]] .three = true := by decide
def e2391306987418 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))
theorem wire_e2391306987418 : Closed e2391306987418 ∧ code e2391306987418 = 11187400009626 := by decide
theorem cert_e2391306987418 : check e2391306987418 [[],[.left],[],[.under]] .three = true := by decide
def e2391306990294 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))
theorem wire_e2391306990294 : Closed e2391306990294 ∧ code e2391306990294 = 11187400012502 := by decide
theorem cert_e2391306990294 : check e2391306990294 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306990298 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))
theorem wire_e2391306990298 : Closed e2391306990298 ∧ code e2391306990298 = 11187400012506 := by decide
theorem cert_e2391306990298 : check e2391306990298 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306990314 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))
theorem wire_e2391306990314 : Closed e2391306990314 ∧ code e2391306990314 = 11187400012522 := by decide
theorem cert_e2391306990314 : check e2391306990314 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306990390 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))
theorem wire_e2391306990390 : Closed e2391306990390 ∧ code e2391306990390 = 11187400012598 := by decide
theorem cert_e2391306990390 : check e2391306990390 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306990394 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))
theorem wire_e2391306990394 : Closed e2391306990394 ∧ code e2391306990394 = 11187400012602 := by decide
theorem cert_e2391306990394 : check e2391306990394 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391306990490 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))
theorem wire_e2391306990490 : Closed e2391306990490 ∧ code e2391306990490 = 11187400012698 := by decide
theorem cert_e2391306990490 : check e2391306990490 [[],[.left],[],[.under,.left],[.under]] .chain = true := by decide
def e2391307127662 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2391307127662 : Closed e2391307127662 ∧ code e2391307127662 = 11187400149870 := by decide
theorem cert_e2391307127662 : check e2391307127662 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307127670 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2391307127670 : Closed e2391307127670 ∧ code e2391307127670 = 11187400149878 := by decide
theorem cert_e2391307127670 : check e2391307127670 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307127726 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2391307127726 : Closed e2391307127726 ∧ code e2391307127726 = 11187400149934 := by decide
theorem cert_e2391307127726 : check e2391307127726 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307127738 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2391307127738 : Closed e2391307127738 ∧ code e2391307127738 = 11187400149946 := by decide
theorem cert_e2391307127738 : check e2391307127738 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307127766 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2391307127766 : Closed e2391307127766 ∧ code e2391307127766 = 11187400149974 := by decide
theorem cert_e2391307127766 : check e2391307127766 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307127770 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2391307127770 : Closed e2391307127770 ∧ code e2391307127770 = 11187400149978 := by decide
theorem cert_e2391307127770 : check e2391307127770 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307128046 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2391307128046 : Closed e2391307128046 ∧ code e2391307128046 = 11187400150254 := by decide
theorem cert_e2391307128046 : check e2391307128046 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307128054 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2391307128054 : Closed e2391307128054 ∧ code e2391307128054 = 11187400150262 := by decide
theorem cert_e2391307128054 : check e2391307128054 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307128430 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2391307128430 : Closed e2391307128430 ∧ code e2391307128430 = 11187400150638 := by decide
theorem cert_e2391307128430 : check e2391307128430 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307128442 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2391307128442 : Closed e2391307128442 ∧ code e2391307128442 = 11187400150650 := by decide
theorem cert_e2391307128442 : check e2391307128442 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307128630 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2391307128630 : Closed e2391307128630 ∧ code e2391307128630 = 11187400150838 := by decide
theorem cert_e2391307128630 : check e2391307128630 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307128634 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2391307128634 : Closed e2391307128634 ∧ code e2391307128634 = 11187400150842 := by decide
theorem cert_e2391307128634 : check e2391307128634 [[],[.left],[],[]] .sourceHead = true := by decide
def e2391307717486 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))
theorem wire_e2391307717486 : Closed e2391307717486 ∧ code e2391307717486 = 11187400739694 := by decide
theorem cert_e2391307717486 : check e2391307717486 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[.left],[],[.left],[]] .sourceHead = true := by decide
def e2391307717494 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))
theorem wire_e2391307717494 : Closed e2391307717494 ∧ code e2391307717494 = 11187400739702 := by decide
theorem cert_e2391307717494 : check e2391307717494 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left]] .chain = true := by decide
def e2391307717550 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))
theorem wire_e2391307717550 : Closed e2391307717550 ∧ code e2391307717550 = 11187400739758 := by decide
theorem cert_e2391307717550 : check e2391307717550 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left]] .chain = true := by decide
def e2391307717562 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))
theorem wire_e2391307717562 : Closed e2391307717562 ∧ code e2391307717562 = 11187400739770 := by decide
theorem cert_e2391307717562 : check e2391307717562 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.left],[.left]] .chain = true := by decide
def e2391307717590 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))
theorem wire_e2391307717590 : Closed e2391307717590 ∧ code e2391307717590 = 11187400739798 := by decide
theorem cert_e2391307717590 : check e2391307717590 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[],[.under,.left,.left]] .chain = true := by decide
def e2391307717594 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))
theorem wire_e2391307717594 : Closed e2391307717594 ∧ code e2391307717594 = 11187400739802 := by decide
theorem cert_e2391307717594 : check e2391307717594 [[],[.left],[.left,.left],[.left,.left],[.left],[],[.left],[],[.under,.left,.left]] .chain = true := by decide
def e2391307717870 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))
theorem wire_e2391307717870 : Closed e2391307717870 ∧ code e2391307717870 = 11187400740078 := by decide
theorem cert_e2391307717870 : check e2391307717870 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[],[]] .sourceHead = true := by decide
def e2391307717878 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))
theorem wire_e2391307717878 : Closed e2391307717878 ∧ code e2391307717878 = 11187400740086 := by decide
theorem cert_e2391307717878 : check e2391307717878 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.left],[]] .sourceHead = true := by decide
def e2391307718254 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))
theorem wire_e2391307718254 : Closed e2391307718254 ∧ code e2391307718254 = 11187400740462 := by decide
theorem cert_e2391307718254 : check e2391307718254 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left]] .chain = true := by decide
def e2391307718266 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))
theorem wire_e2391307718266 : Closed e2391307718266 ∧ code e2391307718266 = 11187400740474 := by decide
theorem cert_e2391307718266 : check e2391307718266 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[.under,.left],[.under],[.under,.left,.left]] .chain = true := by decide
def e2391307718454 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))
theorem wire_e2391307718454 : Closed e2391307718454 ∧ code e2391307718454 = 11187400740662 := by decide
theorem cert_e2391307718454 : check e2391307718454 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[],[],[.under,.left]] .chain = true := by decide
def e2391307718458 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 0))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))
theorem wire_e2391307718458 : Closed e2391307718458 ∧ code e2391307718458 = 11187400740666 := by decide
theorem cert_e2391307718458 : check e2391307718458 [[],[.left],[.left,.left],[.left,.left],[.left],[],[],[],[.under,.left]] .chain = true := by decide
def e2391492226586 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492226586 : Closed e2391492226586 ∧ code e2391492226586 = 11187585248794 := by decide
private def t_e2391492226586 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492226586 : ¬ IsSelfInterpreter e2391492226586 :=
  wSource (t := t_e2391492226586) (replay_sound (ps := []) (t := e2391492226586) (by decide)) (by decide)
def e2391492228634 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem wire_e2391492228634 : Closed e2391492228634 ∧ code e2391492228634 = 11187585250842 := by decide
private def t_e2391492228634 : Term := (.app (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2391492228634 : ¬ IsSelfInterpreter e2391492228634 :=
  wSource (t := t_e2391492228634) (replay_sound (ps := []) (t := e2391492228634) (by decide)) (by decide)
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2389752962502
#print axioms Blc.Floor43.cert_e2389752962758
#print axioms Blc.Floor43.cert_e2391235338778
#print axioms Blc.Floor43.cert_e2391235469850
#print axioms Blc.Floor43.cert_e2391492226586
#print axioms Blc.Floor43.cert_e2391492228634
