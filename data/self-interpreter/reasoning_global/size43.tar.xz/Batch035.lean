import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e606396406202 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e606396406202 : Closed e606396406202 ∧ code e606396406202 = 9402489428410 := by decide
theorem cert_e606396406202 : check e606396406202 [[.under]] .sourceHead = true := by decide
def e606396406250 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e606396406250 : Closed e606396406250 ∧ code e606396406250 = 9402489428458 := by decide
theorem cert_e606396406250 : check e606396406250 [[.under]] .sourceHead = true := by decide
def e606396406382 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e606396406382 : Closed e606396406382 ∧ code e606396406382 = 9402489428590 := by decide
theorem cert_e606396406382 : check e606396406382 [[.under]] .sourceHead = true := by decide
def e606396406394 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e606396406394 : Closed e606396406394 ∧ code e606396406394 = 9402489428602 := by decide
theorem cert_e606396406394 : check e606396406394 [[.under]] .sourceHead = true := by decide
def e606396406558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e606396406558 : Closed e606396406558 ∧ code e606396406558 = 9402489428766 := by decide
theorem cert_e606396406558 : check e606396406558 [[.under]] .sourceHead = true := by decide
def e606396406670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e606396406670 : Closed e606396406670 ∧ code e606396406670 = 9402489428878 := by decide
theorem cert_e606396406670 : check e606396406670 [[.under]] .sourceHead = true := by decide
def e606396406682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396406682 : Closed e606396406682 ∧ code e606396406682 = 9402489428890 := by decide
theorem cert_e606396406682 : check e606396406682 [[.under]] .sourceHead = true := by decide
def e606396406902 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e606396406902 : Closed e606396406902 ∧ code e606396406902 = 9402489429110 := by decide
theorem cert_e606396406902 : check e606396406902 [[.under]] .sourceHead = true := by decide
def e606396406998 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e606396406998 : Closed e606396406998 ∧ code e606396406998 = 9402489429206 := by decide
theorem cert_e606396406998 : check e606396406998 [[.under]] .sourceHead = true := by decide
def e606396407002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e606396407002 : Closed e606396407002 ∧ code e606396407002 = 9402489429210 := by decide
theorem cert_e606396407002 : check e606396407002 [[.under]] .sourceHead = true := by decide
def e606396407018 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e606396407018 : Closed e606396407018 ∧ code e606396407018 = 9402489429226 := by decide
theorem cert_e606396407018 : check e606396407018 [[.under]] .sourceHead = true := by decide
def e606396407094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396407094 : Closed e606396407094 ∧ code e606396407094 = 9402489429302 := by decide
theorem cert_e606396407094 : check e606396407094 [[.under]] .sourceHead = true := by decide
def e606396407098 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396407098 : Closed e606396407098 ∧ code e606396407098 = 9402489429306 := by decide
theorem cert_e606396407098 : check e606396407098 [[.under]] .sourceHead = true := by decide
def e606396407182 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e606396407182 : Closed e606396407182 ∧ code e606396407182 = 9402489429390 := by decide
theorem cert_e606396407182 : check e606396407182 [[.under]] .sourceHead = true := by decide
def e606396407194 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396407194 : Closed e606396407194 ∧ code e606396407194 = 9402489429402 := by decide
theorem cert_e606396407194 : check e606396407194 [[.under]] .sourceHead = true := by decide
def e606396408686 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 1)) (.var 2))))))))
theorem wire_e606396408686 : Closed e606396408686 ∧ code e606396408686 = 9402489430894 := by decide
theorem cert_e606396408686 : check e606396408686 [[.under]] .sourceHead = true := by decide
def e606396408694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 1))) (.var 2)) (.var 1))))))))
theorem wire_e606396408694 : Closed e606396408694 ∧ code e606396408694 = 9402489430902 := by decide
theorem cert_e606396408694 : check e606396408694 [[.under]] .sourceHead = true := by decide
def e606396408750 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 0)) (.var 2))))))))
theorem wire_e606396408750 : Closed e606396408750 ∧ code e606396408750 = 9402489430958 := by decide
theorem cert_e606396408750 : check e606396408750 [[.under]] .sourceHead = true := by decide
def e606396408762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 2))) (.var 2)) (.var 0))))))))
theorem wire_e606396408762 : Closed e606396408762 ∧ code e606396408762 = 9402489430970 := by decide
theorem cert_e606396408762 : check e606396408762 [[.under]] .sourceHead = true := by decide
def e606396408790 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 0)) (.var 1))))))))
theorem wire_e606396408790 : Closed e606396408790 ∧ code e606396408790 = 9402489430998 := by decide
theorem cert_e606396408790 : check e606396408790 [[.under]] .sourceHead = true := by decide
def e606396408794 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.lam (.var 3))) (.var 1)) (.var 0))))))))
theorem wire_e606396408794 : Closed e606396408794 ∧ code e606396408794 = 9402489431002 := by decide
theorem cert_e606396408794 : check e606396408794 [[.under]] .sourceHead = true := by decide
def e606396409518 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 0)) (.var 2))))))))
theorem wire_e606396409518 : Closed e606396409518 ∧ code e606396409518 = 9402489431726 := by decide
theorem cert_e606396409518 : check e606396409518 [[.under]] .sourceHead = true := by decide
def e606396409530 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)) (.var 0))))))))
theorem wire_e606396409530 : Closed e606396409530 ∧ code e606396409530 = 9402489431738 := by decide
theorem cert_e606396409530 : check e606396409530 [[.under]] .sourceHead = true := by decide
def e606396409578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)) (.var 0))))))))
theorem wire_e606396409578 : Closed e606396409578 ∧ code e606396409578 = 9402489431786 := by decide
theorem cert_e606396409578 : check e606396409578 [[.under]] .sourceHead = true := by decide
def e606396409770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e606396409770 : Closed e606396409770 ∧ code e606396409770 = 9402489431978 := by decide
theorem cert_e606396409770 : check e606396409770 [[.under]] .sourceHead = true := by decide
def e606396410094 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 2))) (.var 2))))))))
theorem wire_e606396410094 : Closed e606396410094 ∧ code e606396410094 = 9402489432302 := by decide
theorem cert_e606396410094 : check e606396410094 [[.under]] .sourceHead = true := by decide
def e606396410102 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.lam (.var 3))) (.var 1))))))))
theorem wire_e606396410102 : Closed e606396410102 ∧ code e606396410102 = 9402489432310 := by decide
theorem cert_e606396410102 : check e606396410102 [[.under]] .sourceHead = true := by decide
def e606396410286 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 0))) (.var 2))))))))
theorem wire_e606396410286 : Closed e606396410286 ∧ code e606396410286 = 9402489432494 := by decide
theorem cert_e606396410286 : check e606396410286 [[.under]] .sourceHead = true := by decide
def e606396410298 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))) (.var 0))))))))
theorem wire_e606396410298 : Closed e606396410298 ∧ code e606396410298 = 9402489432506 := by decide
theorem cert_e606396410298 : check e606396410298 [[.under]] .sourceHead = true := by decide
def e606396410346 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))) (.var 0))))))))
theorem wire_e606396410346 : Closed e606396410346 ∧ code e606396410346 = 9402489432554 := by decide
theorem cert_e606396410346 : check e606396410346 [[.under]] .sourceHead = true := by decide
def e606396410478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 0) (.var 2)))))))))
theorem wire_e606396410478 : Closed e606396410478 ∧ code e606396410478 = 9402489432686 := by decide
theorem cert_e606396410478 : check e606396410478 [[.under]] .sourceHead = true := by decide
def e606396410490 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.app (.var 2) (.var 0)))))))))
theorem wire_e606396410490 : Closed e606396410490 ∧ code e606396410490 = 9402489432698 := by decide
theorem cert_e606396410490 : check e606396410490 [[.under]] .sourceHead = true := by decide
def e606396410654 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.lam (.var 3)))))))))
theorem wire_e606396410654 : Closed e606396410654 ∧ code e606396410654 = 9402489432862 := by decide
theorem cert_e606396410654 : check e606396410654 [[.under]] .sourceHead = true := by decide
def e606396410766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.lam (.var 2)))))))))
theorem wire_e606396410766 : Closed e606396410766 ∧ code e606396410766 = 9402489432974 := by decide
theorem cert_e606396410766 : check e606396410766 [[.under]] .sourceHead = true := by decide
def e606396410778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396410778 : Closed e606396410778 ∧ code e606396410778 = 9402489432986 := by decide
theorem cert_e606396410778 : check e606396410778 [[.under]] .sourceHead = true := by decide
def e606396410990 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 1))) (.var 2))))))))
theorem wire_e606396410990 : Closed e606396410990 ∧ code e606396410990 = 9402489433198 := by decide
theorem cert_e606396410990 : check e606396410990 [[.under]] .sourceHead = true := by decide
def e606396411002 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.lam (.var 3))) (.var 0))))))))
theorem wire_e606396411002 : Closed e606396411002 ∧ code e606396411002 = 9402489433210 := by decide
theorem cert_e606396411002 : check e606396411002 [[.under]] .sourceHead = true := by decide
def e606396411166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.lam (.var 3)))))))))
theorem wire_e606396411166 : Closed e606396411166 ∧ code e606396411166 = 9402489433374 := by decide
theorem cert_e606396411166 : check e606396411166 [[.under]] .sourceHead = true := by decide
def e606396411334 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 2)) (.lam (.var 1)))))))))
theorem wire_e606396411334 : Closed e606396411334 ∧ code e606396411334 = 9402489433542 := by decide
theorem cert_e606396411334 : check e606396411334 [[.under]] .sourceHead = true := by decide
def e606396411446 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e606396411446 : Closed e606396411446 ∧ code e606396411446 = 9402489433654 := by decide
theorem cert_e606396411446 : check e606396411446 [[.under]] .sourceHead = true := by decide
def e606396411450 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e606396411450 : Closed e606396411450 ∧ code e606396411450 = 9402489433658 := by decide
theorem cert_e606396411450 : check e606396411450 [[.under]] .sourceHead = true := by decide
def e606396411498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e606396411498 : Closed e606396411498 ∧ code e606396411498 = 9402489433706 := by decide
theorem cert_e606396411498 : check e606396411498 [[.under]] .sourceHead = true := by decide
def e606396411534 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e606396411534 : Closed e606396411534 ∧ code e606396411534 = 9402489433742 := by decide
theorem cert_e606396411534 : check e606396411534 [[.under]] .sourceHead = true := by decide
def e606396411546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396411546 : Closed e606396411546 ∧ code e606396411546 = 9402489433754 := by decide
theorem cert_e606396411546 : check e606396411546 [[.under]] .sourceHead = true := by decide
def e606396411590 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e606396411590 : Closed e606396411590 ∧ code e606396411590 = 9402489433798 := by decide
theorem cert_e606396411590 : check e606396411590 [[.under]] .sourceHead = true := by decide
def e606396412342 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 1))) (.var 1)) (.var 1))))))))
theorem wire_e606396412342 : Closed e606396412342 ∧ code e606396412342 = 9402489434550 := by decide
theorem cert_e606396412342 : check e606396412342 [[.under]] .sourceHead = true := by decide
def e606396412374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 0)) (.var 1))))))))
theorem wire_e606396412374 : Closed e606396412374 ∧ code e606396412374 = 9402489434582 := by decide
theorem cert_e606396412374 : check e606396412374 [[.under]] .sourceHead = true := by decide
def e606396412378 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.lam (.var 2))) (.var 1)) (.var 0))))))))
theorem wire_e606396412378 : Closed e606396412378 ∧ code e606396412378 = 9402489434586 := by decide
theorem cert_e606396412378 : check e606396412378 [[.under]] .sourceHead = true := by decide
def e606396412758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 0)) (.var 1))))))))
theorem wire_e606396412758 : Closed e606396412758 ∧ code e606396412758 = 9402489434966 := by decide
theorem cert_e606396412758 : check e606396412758 [[.under]] .sourceHead = true := by decide
def e606396412762 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)) (.var 0))))))))
theorem wire_e606396412762 : Closed e606396412762 ∧ code e606396412762 = 9402489434970 := by decide
theorem cert_e606396412762 : check e606396412762 [[.under]] .sourceHead = true := by decide
def e606396412778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)) (.var 0))))))))
theorem wire_e606396412778 : Closed e606396412778 ∧ code e606396412778 = 9402489434986 := by decide
theorem cert_e606396412778 : check e606396412778 [[.under]] .sourceHead = true := by decide
def e606396412842 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)) (.var 0))))))))
theorem wire_e606396412842 : Closed e606396412842 ∧ code e606396412842 = 9402489435050 := by decide
theorem cert_e606396412842 : check e606396412842 [[.under]] .sourceHead = true := by decide
def e606396413046 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.lam (.var 2))) (.var 1))))))))
theorem wire_e606396413046 : Closed e606396413046 ∧ code e606396413046 = 9402489435254 := by decide
theorem cert_e606396413046 : check e606396413046 [[.under]] .sourceHead = true := by decide
def e606396413142 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 0))) (.var 1))))))))
theorem wire_e606396413142 : Closed e606396413142 ∧ code e606396413142 = 9402489435350 := by decide
theorem cert_e606396413142 : check e606396413142 [[.under]] .sourceHead = true := by decide
def e606396413146 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))) (.var 0))))))))
theorem wire_e606396413146 : Closed e606396413146 ∧ code e606396413146 = 9402489435354 := by decide
theorem cert_e606396413146 : check e606396413146 [[.under]] .sourceHead = true := by decide
def e606396413162 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))) (.var 0))))))))
theorem wire_e606396413162 : Closed e606396413162 ∧ code e606396413162 = 9402489435370 := by decide
theorem cert_e606396413162 : check e606396413162 [[.under]] .sourceHead = true := by decide
def e606396413238 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396413238 : Closed e606396413238 ∧ code e606396413238 = 9402489435446 := by decide
theorem cert_e606396413238 : check e606396413238 [[.under]] .sourceHead = true := by decide
def e606396413242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396413242 : Closed e606396413242 ∧ code e606396413242 = 9402489435450 := by decide
theorem cert_e606396413242 : check e606396413242 [[.under]] .sourceHead = true := by decide
def e606396413326 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.lam (.var 2)))))))))
theorem wire_e606396413326 : Closed e606396413326 ∧ code e606396413326 = 9402489435534 := by decide
theorem cert_e606396413326 : check e606396413326 [[.under]] .sourceHead = true := by decide
def e606396413338 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396413338 : Closed e606396413338 ∧ code e606396413338 = 9402489435546 := by decide
theorem cert_e606396413338 : check e606396413338 [[.under]] .sourceHead = true := by decide
def e606396413494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 1))) (.var 1))))))))
theorem wire_e606396413494 : Closed e606396413494 ∧ code e606396413494 = 9402489435702 := by decide
theorem cert_e606396413494 : check e606396413494 [[.under]] .sourceHead = true := by decide
def e606396413498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.lam (.var 2))) (.var 0))))))))
theorem wire_e606396413498 : Closed e606396413498 ∧ code e606396413498 = 9402489435706 := by decide
theorem cert_e606396413498 : check e606396413498 [[.under]] .sourceHead = true := by decide
def e606396413546 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))) (.var 0))))))))
theorem wire_e606396413546 : Closed e606396413546 ∧ code e606396413546 = 9402489435754 := by decide
theorem cert_e606396413546 : check e606396413546 [[.under]] .sourceHead = true := by decide
def e606396413582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.lam (.var 2)))))))))
theorem wire_e606396413582 : Closed e606396413582 ∧ code e606396413582 = 9402489435790 := by decide
theorem cert_e606396413582 : check e606396413582 [[.under]] .sourceHead = true := by decide
def e606396413594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396413594 : Closed e606396413594 ∧ code e606396413594 = 9402489435802 := by decide
theorem cert_e606396413594 : check e606396413594 [[.under]] .sourceHead = true := by decide
def e606396413638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 1)) (.lam (.var 1)))))))))
theorem wire_e606396413638 : Closed e606396413638 ∧ code e606396413638 = 9402489435846 := by decide
theorem cert_e606396413638 : check e606396413638 [[.under]] .sourceHead = true := by decide
def e606396419822 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 2)))) (.var 2))))))))
theorem wire_e606396419822 : Closed e606396419822 ∧ code e606396419822 = 9402489442030 := by decide
theorem cert_e606396419822 : check e606396419822 [[.under]] .sourceHead = true := by decide
def e606396419830 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 1) (.var 3)))) (.var 1))))))))
theorem wire_e606396419830 : Closed e606396419830 ∧ code e606396419830 = 9402489442038 := by decide
theorem cert_e606396419830 : check e606396419830 [[.under]] .sourceHead = true := by decide
def e606396419950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 1)))) (.var 2))))))))
theorem wire_e606396419950 : Closed e606396419950 ∧ code e606396419950 = 9402489442158 := by decide
theorem cert_e606396419950 : check e606396419950 [[.under]] .sourceHead = true := by decide
def e606396419962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 2) (.var 3)))) (.var 0))))))))
theorem wire_e606396419962 : Closed e606396419962 ∧ code e606396419962 = 9402489442170 := by decide
theorem cert_e606396419962 : check e606396419962 [[.under]] .sourceHead = true := by decide
def e606396420022 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 1)))) (.var 1))))))))
theorem wire_e606396420022 : Closed e606396420022 ∧ code e606396420022 = 9402489442230 := by decide
theorem cert_e606396420022 : check e606396420022 [[.under]] .sourceHead = true := by decide
def e606396420026 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.app (.var 3) (.var 2)))) (.var 0))))))))
theorem wire_e606396420026 : Closed e606396420026 ∧ code e606396420026 = 9402489442234 := by decide
theorem cert_e606396420026 : check e606396420026 [[.under]] .sourceHead = true := by decide
def e606396423406 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 1) (.var 2)))))))))
theorem wire_e606396423406 : Closed e606396423406 ∧ code e606396423406 = 9402489445614 := by decide
theorem cert_e606396423406 : check e606396423406 [[.under]] .sourceHead = true := by decide
def e606396423414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 2))) (.app (.var 2) (.var 1)))))))))
theorem wire_e606396423414 : Closed e606396423414 ∧ code e606396423414 = 9402489445622 := by decide
theorem cert_e606396423414 : check e606396423414 [[.under]] .sourceHead = true := by decide
def e606396423798 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1)))))))))
theorem wire_e606396423798 : Closed e606396423798 ∧ code e606396423798 = 9402489446006 := by decide
theorem cert_e606396423798 : check e606396423798 [[.under]] .sourceHead = true := by decide
def e606396427630 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2))))))))
theorem wire_e606396427630 : Closed e606396427630 ∧ code e606396427630 = 9402489449838 := by decide
theorem cert_e606396427630 : check e606396427630 [[.under]] .sourceHead = true := by decide
def e606396427638 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1))))))))
theorem wire_e606396427638 : Closed e606396427638 ∧ code e606396427638 = 9402489449846 := by decide
theorem cert_e606396427638 : check e606396427638 [[.under]] .sourceHead = true := by decide
def e606396427694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2))))))))
theorem wire_e606396427694 : Closed e606396427694 ∧ code e606396427694 = 9402489449902 := by decide
theorem cert_e606396427694 : check e606396427694 [[.under]] .sourceHead = true := by decide
def e606396427706 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0))))))))
theorem wire_e606396427706 : Closed e606396427706 ∧ code e606396427706 = 9402489449914 := by decide
theorem cert_e606396427706 : check e606396427706 [[.under]] .sourceHead = true := by decide
def e606396427734 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1))))))))
theorem wire_e606396427734 : Closed e606396427734 ∧ code e606396427734 = 9402489449942 := by decide
theorem cert_e606396427734 : check e606396427734 [[.under]] .sourceHead = true := by decide
def e606396427738 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0))))))))
theorem wire_e606396427738 : Closed e606396427738 ∧ code e606396427738 = 9402489449946 := by decide
theorem cert_e606396427738 : check e606396427738 [[.under]] .sourceHead = true := by decide
def e606396427950 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e606396427950 : Closed e606396427950 ∧ code e606396427950 = 9402489450158 := by decide
theorem cert_e606396427950 : check e606396427950 [[.under]] .sourceHead = true := by decide
def e606396427962 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0))))))))
theorem wire_e606396427962 : Closed e606396427962 ∧ code e606396427962 = 9402489450170 := by decide
theorem cert_e606396427962 : check e606396427962 [[.under]] .sourceHead = true := by decide
def e606396428010 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0))))))))
theorem wire_e606396428010 : Closed e606396428010 ∧ code e606396428010 = 9402489450218 := by decide
theorem cert_e606396428010 : check e606396428010 [[.under]] .sourceHead = true := by decide
def e606396428118 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1))))))))
theorem wire_e606396428118 : Closed e606396428118 ∧ code e606396428118 = 9402489450326 := by decide
theorem cert_e606396428118 : check e606396428118 [[.under]] .sourceHead = true := by decide
def e606396428122 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0))))))))
theorem wire_e606396428122 : Closed e606396428122 ∧ code e606396428122 = 9402489450330 := by decide
theorem cert_e606396428122 : check e606396428122 [[.under]] .sourceHead = true := by decide
def e606396428138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0))))))))
theorem wire_e606396428138 : Closed e606396428138 ∧ code e606396428138 = 9402489450346 := by decide
theorem cert_e606396428138 : check e606396428138 [[.under]] .sourceHead = true := by decide
def e606396429166 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2))))))))
theorem wire_e606396429166 : Closed e606396429166 ∧ code e606396429166 = 9402489451374 := by decide
theorem cert_e606396429166 : check e606396429166 [[.under]] .sourceHead = true := by decide
def e606396429174 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1))))))))
theorem wire_e606396429174 : Closed e606396429174 ∧ code e606396429174 = 9402489451382 := by decide
theorem cert_e606396429174 : check e606396429174 [[.under]] .sourceHead = true := by decide
def e606396429230 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2))))))))
theorem wire_e606396429230 : Closed e606396429230 ∧ code e606396429230 = 9402489451438 := by decide
theorem cert_e606396429230 : check e606396429230 [[.under]] .sourceHead = true := by decide
def e606396429242 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0))))))))
theorem wire_e606396429242 : Closed e606396429242 ∧ code e606396429242 = 9402489451450 := by decide
theorem cert_e606396429242 : check e606396429242 [[.under]] .sourceHead = true := by decide
def e606396429270 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1))))))))
theorem wire_e606396429270 : Closed e606396429270 ∧ code e606396429270 = 9402489451478 := by decide
theorem cert_e606396429270 : check e606396429270 [[.under]] .sourceHead = true := by decide
def e606396429274 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0))))))))
theorem wire_e606396429274 : Closed e606396429274 ∧ code e606396429274 = 9402489451482 := by decide
theorem cert_e606396429274 : check e606396429274 [[.under]] .sourceHead = true := by decide
def e606396429550 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2)))))))))
theorem wire_e606396429550 : Closed e606396429550 ∧ code e606396429550 = 9402489451758 := by decide
theorem cert_e606396429550 : check e606396429550 [[.under]] .sourceHead = true := by decide
def e606396429558 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1)))))))))
theorem wire_e606396429558 : Closed e606396429558 ∧ code e606396429558 = 9402489451766 := by decide
theorem cert_e606396429558 : check e606396429558 [[.under]] .sourceHead = true := by decide
def e606396429934 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2)))))))))
theorem wire_e606396429934 : Closed e606396429934 ∧ code e606396429934 = 9402489452142 := by decide
theorem cert_e606396429934 : check e606396429934 [[.under]] .sourceHead = true := by decide
def e606396429946 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0)))))))))
theorem wire_e606396429946 : Closed e606396429946 ∧ code e606396429946 = 9402489452154 := by decide
theorem cert_e606396429946 : check e606396429946 [[.under]] .sourceHead = true := by decide
def e606396430134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396430134 : Closed e606396430134 ∧ code e606396430134 = 9402489452342 := by decide
theorem cert_e606396430134 : check e606396430134 [[.under]] .sourceHead = true := by decide
def e606396430138 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396430138 : Closed e606396430138 ∧ code e606396430138 = 9402489452346 := by decide
theorem cert_e606396430138 : check e606396430138 [[.under]] .sourceHead = true := by decide
def e606396430574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2))))))))
theorem wire_e606396430574 : Closed e606396430574 ∧ code e606396430574 = 9402489452782 := by decide
theorem cert_e606396430574 : check e606396430574 [[.under]] .sourceHead = true := by decide
def e606396430582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1))))))))
theorem wire_e606396430582 : Closed e606396430582 ∧ code e606396430582 = 9402489452790 := by decide
theorem cert_e606396430582 : check e606396430582 [[.under]] .sourceHead = true := by decide
def e606396430766 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2))))))))
theorem wire_e606396430766 : Closed e606396430766 ∧ code e606396430766 = 9402489452974 := by decide
theorem cert_e606396430766 : check e606396430766 [[.under]] .sourceHead = true := by decide
def e606396430778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0))))))))
theorem wire_e606396430778 : Closed e606396430778 ∧ code e606396430778 = 9402489452986 := by decide
theorem cert_e606396430778 : check e606396430778 [[.under]] .sourceHead = true := by decide
def e606396430826 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0))))))))
theorem wire_e606396430826 : Closed e606396430826 ∧ code e606396430826 = 9402489453034 := by decide
theorem cert_e606396430826 : check e606396430826 [[.under]] .sourceHead = true := by decide
def e606396430958 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 0) (.var 2)))))))))
theorem wire_e606396430958 : Closed e606396430958 ∧ code e606396430958 = 9402489453166 := by decide
theorem cert_e606396430958 : check e606396430958 [[.under]] .sourceHead = true := by decide
def e606396430970 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.app (.var 2) (.var 0)))))))))
theorem wire_e606396430970 : Closed e606396430970 ∧ code e606396430970 = 9402489453178 := by decide
theorem cert_e606396430970 : check e606396430970 [[.under]] .sourceHead = true := by decide
def e606396431134 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.lam (.var 3)))))))))
theorem wire_e606396431134 : Closed e606396431134 ∧ code e606396431134 = 9402489453342 := by decide
theorem cert_e606396431134 : check e606396431134 [[.under]] .sourceHead = true := by decide
def e606396431246 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.lam (.var 2)))))))))
theorem wire_e606396431246 : Closed e606396431246 ∧ code e606396431246 = 9402489453454 := by decide
theorem cert_e606396431246 : check e606396431246 [[.under]] .sourceHead = true := by decide
def e606396431258 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396431258 : Closed e606396431258 ∧ code e606396431258 = 9402489453466 := by decide
theorem cert_e606396431258 : check e606396431258 [[.under]] .sourceHead = true := by decide
def e606396431478 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.lam (.var 2)))) (.var 1))))))))
theorem wire_e606396431478 : Closed e606396431478 ∧ code e606396431478 = 9402489453686 := by decide
theorem cert_e606396431478 : check e606396431478 [[.under]] .sourceHead = true := by decide
def e606396431574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 0)))) (.var 1))))))))
theorem wire_e606396431574 : Closed e606396431574 ∧ code e606396431574 = 9402489453782 := by decide
theorem cert_e606396431574 : check e606396431574 [[.under]] .sourceHead = true := by decide
def e606396431578 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))) (.var 0))))))))
theorem wire_e606396431578 : Closed e606396431578 ∧ code e606396431578 = 9402489453786 := by decide
theorem cert_e606396431578 : check e606396431578 [[.under]] .sourceHead = true := by decide
def e606396431594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))) (.var 0))))))))
theorem wire_e606396431594 : Closed e606396431594 ∧ code e606396431594 = 9402489453802 := by decide
theorem cert_e606396431594 : check e606396431594 [[.under]] .sourceHead = true := by decide
def e606396431670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396431670 : Closed e606396431670 ∧ code e606396431670 = 9402489453878 := by decide
theorem cert_e606396431670 : check e606396431670 [[.under]] .sourceHead = true := by decide
def e606396431674 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396431674 : Closed e606396431674 ∧ code e606396431674 = 9402489453882 := by decide
theorem cert_e606396431674 : check e606396431674 [[.under]] .sourceHead = true := by decide
def e606396431758 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 2)))))))))
theorem wire_e606396431758 : Closed e606396431758 ∧ code e606396431758 = 9402489453966 := by decide
theorem cert_e606396431758 : check e606396431758 [[.under]] .sourceHead = true := by decide
def e606396431770 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.app (.var 0) (.var 0)))))))))
theorem wire_e606396431770 : Closed e606396431770 ∧ code e606396431770 = 9402489453978 := by decide
theorem cert_e606396431770 : check e606396431770 [[.under]] .sourceHead = true := by decide
def e606396433374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 2) (.var 3))))))))))
theorem wire_e606396433374 : Closed e606396433374 ∧ code e606396433374 = 9402489455582 := by decide
theorem cert_e606396433374 : check e606396433374 [[.under]] .sourceHead = true := by decide
def e606396433390 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 3) (.var 2))))))))))
theorem wire_e606396433390 : Closed e606396433390 ∧ code e606396433390 = 9402489455598 := by decide
theorem cert_e606396433390 : check e606396433390 [[.under]] .sourceHead = true := by decide
def e606396435310 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e606396435310 : Closed e606396435310 ∧ code e606396435310 = 9402489457518 := by decide
theorem cert_e606396435310 : check e606396435310 [[.under]] .sourceHead = true := by decide
def e606396435318 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e606396435318 : Closed e606396435318 ∧ code e606396435318 = 9402489457526 := by decide
theorem cert_e606396435318 : check e606396435318 [[.under]] .sourceHead = true := by decide
def e606396435374 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e606396435374 : Closed e606396435374 ∧ code e606396435374 = 9402489457582 := by decide
theorem cert_e606396435374 : check e606396435374 [[.under]] .sourceHead = true := by decide
def e606396435386 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e606396435386 : Closed e606396435386 ∧ code e606396435386 = 9402489457594 := by decide
theorem cert_e606396435386 : check e606396435386 [[.under]] .sourceHead = true := by decide
def e606396435414 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e606396435414 : Closed e606396435414 ∧ code e606396435414 = 9402489457622 := by decide
theorem cert_e606396435414 : check e606396435414 [[.under]] .sourceHead = true := by decide
def e606396435418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e606396435418 : Closed e606396435418 ∧ code e606396435418 = 9402489457626 := by decide
theorem cert_e606396435418 : check e606396435418 [[.under]] .sourceHead = true := by decide
def e606396435694 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e606396435694 : Closed e606396435694 ∧ code e606396435694 = 9402489457902 := by decide
theorem cert_e606396435694 : check e606396435694 [[.under]] .sourceHead = true := by decide
def e606396435702 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e606396435702 : Closed e606396435702 ∧ code e606396435702 = 9402489457910 := by decide
theorem cert_e606396435702 : check e606396435702 [[.under]] .sourceHead = true := by decide
def e606396436078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e606396436078 : Closed e606396436078 ∧ code e606396436078 = 9402489458286 := by decide
theorem cert_e606396436078 : check e606396436078 [[.under]] .sourceHead = true := by decide
def e606396436090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e606396436090 : Closed e606396436090 ∧ code e606396436090 = 9402489458298 := by decide
theorem cert_e606396436090 : check e606396436090 [[.under]] .sourceHead = true := by decide
def e606396436278 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e606396436278 : Closed e606396436278 ∧ code e606396436278 = 9402489458486 := by decide
theorem cert_e606396436278 : check e606396436278 [[.under]] .sourceHead = true := by decide
def e606396436282 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e606396436282 : Closed e606396436282 ∧ code e606396436282 = 9402489458490 := by decide
theorem cert_e606396436282 : check e606396436282 [[.under]] .sourceHead = true := by decide
def e606396441054 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 1) (.var 3))))))))))
theorem wire_e606396441054 : Closed e606396441054 ∧ code e606396441054 = 9402489463262 := by decide
theorem cert_e606396441054 : check e606396441054 [[.under]] .sourceHead = true := by decide
def e606396441078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.lam (.app (.var 3) (.var 1))))))))))
theorem wire_e606396441078 : Closed e606396441078 ∧ code e606396441078 = 9402489463286 := by decide
theorem cert_e606396441078 : check e606396441078 [[.under]] .sourceHead = true := by decide
def e606396442030 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e606396442030 : Closed e606396442030 ∧ code e606396442030 = 9402489464238 := by decide
theorem cert_e606396442030 : check e606396442030 [[.under]] .sourceHead = true := by decide
def e606396442042 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e606396442042 : Closed e606396442042 ∧ code e606396442042 = 9402489464250 := by decide
theorem cert_e606396442042 : check e606396442042 [[.under]] .sourceHead = true := by decide
def e606396442090 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e606396442090 : Closed e606396442090 ∧ code e606396442090 = 9402489464298 := by decide
theorem cert_e606396442090 : check e606396442090 [[.under]] .sourceHead = true := by decide
def e606396442222 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e606396442222 : Closed e606396442222 ∧ code e606396442222 = 9402489464430 := by decide
theorem cert_e606396442222 : check e606396442222 [[.under]] .sourceHead = true := by decide
def e606396442234 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e606396442234 : Closed e606396442234 ∧ code e606396442234 = 9402489464442 := by decide
theorem cert_e606396442234 : check e606396442234 [[.under]] .sourceHead = true := by decide
def e606396442398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.lam (.var 3))))))))))
theorem wire_e606396442398 : Closed e606396442398 ∧ code e606396442398 = 9402489464606 := by decide
theorem cert_e606396442398 : check e606396442398 [[.under]] .sourceHead = true := by decide
def e606396442510 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.lam (.var 2))))))))))
theorem wire_e606396442510 : Closed e606396442510 ∧ code e606396442510 = 9402489464718 := by decide
theorem cert_e606396442510 : check e606396442510 [[.under]] .sourceHead = true := by decide
def e606396442522 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396442522 : Closed e606396442522 ∧ code e606396442522 = 9402489464730 := by decide
theorem cert_e606396442522 : check e606396442522 [[.under]] .sourceHead = true := by decide
def e606396444910 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 1) (.var 2))))))))))
theorem wire_e606396444910 : Closed e606396444910 ∧ code e606396444910 = 9402489467118 := by decide
theorem cert_e606396444910 : check e606396444910 [[.under]] .sourceHead = true := by decide
def e606396444918 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.lam (.app (.var 2) (.var 1))))))))))
theorem wire_e606396444918 : Closed e606396444918 ∧ code e606396444918 = 9402489467126 := by decide
theorem cert_e606396444918 : check e606396444918 [[.under]] .sourceHead = true := by decide
def e606396445398 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e606396445398 : Closed e606396445398 ∧ code e606396445398 = 9402489467606 := by decide
theorem cert_e606396445398 : check e606396445398 [[.under]] .sourceHead = true := by decide
def e606396445402 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e606396445402 : Closed e606396445402 ∧ code e606396445402 = 9402489467610 := by decide
theorem cert_e606396445402 : check e606396445402 [[.under]] .sourceHead = true := by decide
def e606396445418 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e606396445418 : Closed e606396445418 ∧ code e606396445418 = 9402489467626 := by decide
theorem cert_e606396445418 : check e606396445418 [[.under]] .sourceHead = true := by decide
def e606396445494 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e606396445494 : Closed e606396445494 ∧ code e606396445494 = 9402489467702 := by decide
theorem cert_e606396445494 : check e606396445494 [[.under]] .sourceHead = true := by decide
def e606396445498 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e606396445498 : Closed e606396445498 ∧ code e606396445498 = 9402489467706 := by decide
theorem cert_e606396445498 : check e606396445498 [[.under]] .sourceHead = true := by decide
def e606396445582 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.lam (.var 2))))))))))
theorem wire_e606396445582 : Closed e606396445582 ∧ code e606396445582 = 9402489467790 := by decide
theorem cert_e606396445582 : check e606396445582 [[.under]] .sourceHead = true := by decide
def e606396445594 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e606396445594 : Closed e606396445594 ∧ code e606396445594 = 9402489467802 := by decide
theorem cert_e606396445594 : check e606396445594 [[.under]] .sourceHead = true := by decide
def e606396450670 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 1)))) (.var 2))))))))
theorem wire_e606396450670 : Closed e606396450670 ∧ code e606396450670 = 9402489472878 := by decide
theorem cert_e606396450670 : check e606396450670 [[.under]] .sourceHead = true := by decide
def e606396450682 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 1) (.var 3)))) (.var 0))))))))
theorem wire_e606396450682 : Closed e606396450682 ∧ code e606396450682 = 9402489472890 := by decide
theorem cert_e606396450682 : check e606396450682 [[.under]] .sourceHead = true := by decide
def e606396450778 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.app (.var 3) (.var 1)))) (.var 0))))))))
theorem wire_e606396450778 : Closed e606396450778 ∧ code e606396450778 = 9402489472986 := by decide
theorem cert_e606396450778 : check e606396450778 [[.under]] .sourceHead = true := by decide
def e606396452078 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 1) (.var 2)))))))))
theorem wire_e606396452078 : Closed e606396452078 ∧ code e606396452078 = 9402489474286 := by decide
theorem cert_e606396452078 : check e606396452078 [[.under]] .sourceHead = true := by decide
def e606396452086 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 1))) (.app (.var 2) (.var 1)))))))))
theorem wire_e606396452086 : Closed e606396452086 ∧ code e606396452086 = 9402489474294 := by decide
theorem cert_e606396452086 : check e606396452086 [[.under]] .sourceHead = true := by decide
def e606396452462 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 0) (.var 2)))))))))
theorem wire_e606396452462 : Closed e606396452462 ∧ code e606396452462 = 9402489474670 := by decide
theorem cert_e606396452462 : check e606396452462 [[.under]] .sourceHead = true := by decide
def e606396452474 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 2))) (.app (.var 2) (.var 0)))))))))
theorem wire_e606396452474 : Closed e606396452474 ∧ code e606396452474 = 9402489474682 := by decide
theorem cert_e606396452474 : check e606396452474 [[.under]] .sourceHead = true := by decide
def e606396452662 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 0) (.var 1)))))))))
theorem wire_e606396452662 : Closed e606396452662 ∧ code e606396452662 = 9402489474870 := by decide
theorem cert_e606396452662 : check e606396452662 [[.under]] .sourceHead = true := by decide
def e606396452666 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.lam (.var 3))) (.app (.var 1) (.var 0)))))))))
theorem wire_e606396452666 : Closed e606396452666 ∧ code e606396452666 = 9402489474874 := by decide
theorem cert_e606396452666 : check e606396452666 [[.under]] .sourceHead = true := by decide
def e606396454574 : Term := (.lam (.app (.lam (.app (.var 0) (.var 0))) (.app (.var 0) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2))))))))
theorem wire_e606396454574 : Closed e606396454574 ∧ code e606396454574 = 9402489476782 := by decide
theorem cert_e606396454574 : check e606396454574 [[.under]] .sourceHead = true := by decide
end Blc.Floor43
