import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422372857078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372857078 : Closed e2422372857078 ∧ code e2422372857078 = 11218465879286 := by decide
theorem cert_e2422372857078 : check e2422372857078 [[],[]] .smaller = true := by decide
def e2422372857082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 0)) (.app (.var 3) (.var 0))))))))
theorem wire_e2422372857082 : Closed e2422372857082 ∧ code e2422372857082 = 11218465879290 := by decide
theorem cert_e2422372857082 : check e2422372857082 [[],[]] .three = true := by decide
def e2422372857406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2422372857406 : Closed e2422372857406 ∧ code e2422372857406 = 11218465879614 := by decide
theorem cert_e2422372857406 : check e2422372857406 [[],[]] .three = true := by decide
def e2422372857454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372857454 : Closed e2422372857454 ∧ code e2422372857454 = 11218465879662 := by decide
theorem cert_e2422372857454 : check e2422372857454 [[],[]] .smaller = true := by decide
def e2422372857466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372857466 : Closed e2422372857466 ∧ code e2422372857466 = 11218465879674 := by decide
theorem cert_e2422372857466 : check e2422372857466 [[],[]] .smaller = true := by decide
def e2422372857630 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.lam (.var 3))))))))
theorem wire_e2422372857630 : Closed e2422372857630 ∧ code e2422372857630 = 11218465879838 := by decide
theorem cert_e2422372857630 : check e2422372857630 [[],[]] .smaller = true := by decide
def e2422372857654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372857654 : Closed e2422372857654 ∧ code e2422372857654 = 11218465879862 := by decide
theorem cert_e2422372857654 : check e2422372857654 [[],[]] .smaller = true := by decide
def e2422372857658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372857658 : Closed e2422372857658 ∧ code e2422372857658 = 11218465879866 := by decide
theorem cert_e2422372857658 : check e2422372857658 [[],[]] .smaller = true := by decide
def e2422372857742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2422372857742 : Closed e2422372857742 ∧ code e2422372857742 = 11218465879950 := by decide
theorem cert_e2422372857742 : check e2422372857742 [[],[]] .three = true := by decide
def e2422372857754 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 2))) (.var 3)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372857754 : Closed e2422372857754 ∧ code e2422372857754 = 11218465879962 := by decide
theorem cert_e2422372857754 : check e2422372857754 [[],[]] .three = true := by decide
def e2422372858078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372858078 : Closed e2422372858078 ∧ code e2422372858078 = 11218465880286 := by decide
theorem cert_e2422372858078 : check e2422372858078 [[],[]] .three = true := by decide
def e2422372858094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422372858094 : Closed e2422372858094 ∧ code e2422372858094 = 11218465880302 := by decide
theorem cert_e2422372858094 : check e2422372858094 [[],[]] .smaller = true := by decide
def e2422372858102 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422372858102 : Closed e2422372858102 ∧ code e2422372858102 = 11218465880310 := by decide
theorem cert_e2422372858102 : check e2422372858102 [[],[]] .smaller = true := by decide
def e2422372858106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372858106 : Closed e2422372858106 ∧ code e2422372858106 = 11218465880314 := by decide
theorem cert_e2422372858106 : check e2422372858106 [[],[]] .three = true := by decide
def e2422372858294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 0) (.var 1))) (.var 1)))))))
theorem wire_e2422372858294 : Closed e2422372858294 ∧ code e2422372858294 = 11218465880502 := by decide
theorem cert_e2422372858294 : check e2422372858294 [[],[]] .smaller = true := by decide
def e2422372858326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 0))) (.var 1)))))))
theorem wire_e2422372858326 : Closed e2422372858326 ∧ code e2422372858326 = 11218465880534 := by decide
theorem cert_e2422372858326 : check e2422372858326 [[],[]] .smaller = true := by decide
def e2422372858330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.app (.var 1) (.var 1))) (.var 0)))))))
theorem wire_e2422372858330 : Closed e2422372858330 ∧ code e2422372858330 = 11218465880538 := by decide
theorem cert_e2422372858330 : check e2422372858330 [[],[]] .smaller = true := by decide
def e2422372858430 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372858430 : Closed e2422372858430 ∧ code e2422372858430 = 11218465880638 := by decide
theorem cert_e2422372858430 : check e2422372858430 [[],[]] .three = true := by decide
def e2422372858486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 0)) (.app (.var 1) (.var 1))))))))
theorem wire_e2422372858486 : Closed e2422372858486 ∧ code e2422372858486 = 11218465880694 := by decide
theorem cert_e2422372858486 : check e2422372858486 [[],[]] .smaller = true := by decide
def e2422372858654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422372858654 : Closed e2422372858654 ∧ code e2422372858654 = 11218465880862 := by decide
theorem cert_e2422372858654 : check e2422372858654 [[],[]] .smaller = true := by decide
def e2422372858678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372858678 : Closed e2422372858678 ∧ code e2422372858678 = 11218465880886 := by decide
theorem cert_e2422372858678 : check e2422372858678 [[],[]] .smaller = true := by decide
def e2422372858682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 1)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372858682 : Closed e2422372858682 ∧ code e2422372858682 = 11218465880890 := by decide
theorem cert_e2422372858682 : check e2422372858682 [[],[]] .smaller = true := by decide
def e2422372858766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422372858766 : Closed e2422372858766 ∧ code e2422372858766 = 11218465880974 := by decide
theorem cert_e2422372858766 : check e2422372858766 [[],[]] .smaller = true := by decide
def e2422372858822 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372858822 : Closed e2422372858822 ∧ code e2422372858822 = 11218465881030 := by decide
theorem cert_e2422372858822 : check e2422372858822 [[],[]] .three = true := by decide
def e2422372858846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 3))) (.var 3)) (.var 3)))))))
theorem wire_e2422372858846 : Closed e2422372858846 ∧ code e2422372858846 = 11218465881054 := by decide
theorem cert_e2422372858846 : check e2422372858846 [[],[]] .three = true := by decide
def e2422372858990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 1))) (.var 2)))))))
theorem wire_e2422372858990 : Closed e2422372858990 ∧ code e2422372858990 = 11218465881198 := by decide
theorem cert_e2422372858990 : check e2422372858990 [[],[]] .three = true := by decide
def e2422372858998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422372858998 : Closed e2422372858998 ∧ code e2422372858998 = 11218465881206 := by decide
theorem cert_e2422372858998 : check e2422372858998 [[],[]] .three = true := by decide
def e2422372859002 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.lam (.var 3))) (.var 0)))))))
theorem wire_e2422372859002 : Closed e2422372859002 ∧ code e2422372859002 = 11218465881210 := by decide
theorem cert_e2422372859002 : check e2422372859002 [[],[]] .three = true := by decide
def e2422372859094 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422372859094 : Closed e2422372859094 ∧ code e2422372859094 = 11218465881302 := by decide
theorem cert_e2422372859094 : check e2422372859094 [[],[]] .three = true := by decide
def e2422372859098 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422372859098 : Closed e2422372859098 ∧ code e2422372859098 = 11218465881306 := by decide
theorem cert_e2422372859098 : check e2422372859098 [[],[]] .three = true := by decide
def e2422372859114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422372859114 : Closed e2422372859114 ∧ code e2422372859114 = 11218465881322 := by decide
theorem cert_e2422372859114 : check e2422372859114 [[],[]] .three = true := by decide
def e2422372859166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.lam (.var 3))))))))
theorem wire_e2422372859166 : Closed e2422372859166 ∧ code e2422372859166 = 11218465881374 := by decide
theorem cert_e2422372859166 : check e2422372859166 [[],[]] .three = true := by decide
def e2422372859190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372859190 : Closed e2422372859190 ∧ code e2422372859190 = 11218465881398 := by decide
theorem cert_e2422372859190 : check e2422372859190 [[],[]] .three = true := by decide
def e2422372859194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372859194 : Closed e2422372859194 ∧ code e2422372859194 = 11218465881402 := by decide
theorem cert_e2422372859194 : check e2422372859194 [[],[]] .three = true := by decide
def e2422372859278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422372859278 : Closed e2422372859278 ∧ code e2422372859278 = 11218465881486 := by decide
theorem cert_e2422372859278 : check e2422372859278 [[],[]] .three = true := by decide
def e2422372859290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372859290 : Closed e2422372859290 ∧ code e2422372859290 = 11218465881498 := by decide
theorem cert_e2422372859290 : check e2422372859290 [[],[]] .three = true := by decide
def e2422372859334 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 2)) (.lam (.var 1))))))))
theorem wire_e2422372859334 : Closed e2422372859334 ∧ code e2422372859334 = 11218465881542 := by decide
theorem cert_e2422372859334 : check e2422372859334 [[],[]] .three = true := by decide
def e2422372859358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 2)) (.var 3)))))))
theorem wire_e2422372859358 : Closed e2422372859358 ∧ code e2422372859358 = 11218465881566 := by decide
theorem cert_e2422372859358 : check e2422372859358 [[],[]] .three = true := by decide
def e2422372859374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.lam (.var 4))) (.var 3)) (.var 2)))))))
theorem wire_e2422372859374 : Closed e2422372859374 ∧ code e2422372859374 = 11218465881582 := by decide
theorem cert_e2422372859374 : check e2422372859374 [[],[]] .three = true := by decide
def e2422372873582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 1)) (.var 2)))))))
theorem wire_e2422372873582 : Closed e2422372873582 ∧ code e2422372873582 = 11218465895790 := by decide
theorem cert_e2422372873582 : check e2422372873582 [[],[]] .smaller = true := by decide
def e2422372873590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 0))) (.var 2)) (.var 1)))))))
theorem wire_e2422372873590 : Closed e2422372873590 ∧ code e2422372873590 = 11218465895798 := by decide
theorem cert_e2422372873590 : check e2422372873590 [[],[]] .smaller = true := by decide
def e2422372873646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 0)) (.var 2)))))))
theorem wire_e2422372873646 : Closed e2422372873646 ∧ code e2422372873646 = 11218465895854 := by decide
theorem cert_e2422372873646 : check e2422372873646 [[],[]] .smaller = true := by decide
def e2422372873658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 1))) (.var 2)) (.var 0)))))))
theorem wire_e2422372873658 : Closed e2422372873658 ∧ code e2422372873658 = 11218465895866 := by decide
theorem cert_e2422372873658 : check e2422372873658 [[],[]] .smaller = true := by decide
def e2422372873686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 0)) (.var 1)))))))
theorem wire_e2422372873686 : Closed e2422372873686 ∧ code e2422372873686 = 11218465895894 := by decide
theorem cert_e2422372873686 : check e2422372873686 [[],[]] .smaller = true := by decide
def e2422372873690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 0)) (.var 2))) (.var 1)) (.var 0)))))))
theorem wire_e2422372873690 : Closed e2422372873690 ∧ code e2422372873690 = 11218465895898 := by decide
theorem cert_e2422372873690 : check e2422372873690 [[],[]] .smaller = true := by decide
def e2422372873902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372873902 : Closed e2422372873902 ∧ code e2422372873902 = 11218465896110 := by decide
theorem cert_e2422372873902 : check e2422372873902 [[],[]] .smaller = true := by decide
def e2422372873914 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372873914 : Closed e2422372873914 ∧ code e2422372873914 = 11218465896122 := by decide
theorem cert_e2422372873914 : check e2422372873914 [[],[]] .smaller = true := by decide
def e2422372873962 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372873962 : Closed e2422372873962 ∧ code e2422372873962 = 11218465896170 := by decide
theorem cert_e2422372873962 : check e2422372873962 [[],[]] .smaller = true := by decide
def e2422372874070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372874070 : Closed e2422372874070 ∧ code e2422372874070 = 11218465896278 := by decide
theorem cert_e2422372874070 : check e2422372874070 [[],[]] .smaller = true := by decide
def e2422372874074 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372874074 : Closed e2422372874074 ∧ code e2422372874074 = 11218465896282 := by decide
theorem cert_e2422372874074 : check e2422372874074 [[],[]] .smaller = true := by decide
def e2422372874090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422372874090 : Closed e2422372874090 ∧ code e2422372874090 = 11218465896298 := by decide
theorem cert_e2422372874090 : check e2422372874090 [[],[]] .smaller = true := by decide
def e2422372874926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 0)) (.var 2)))))))
theorem wire_e2422372874926 : Closed e2422372874926 ∧ code e2422372874926 = 11218465897134 := by decide
theorem cert_e2422372874926 : check e2422372874926 [[],[]] .smaller = true := by decide
def e2422372874938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 0))) (.var 2)) (.var 0)))))))
theorem wire_e2422372874938 : Closed e2422372874938 ∧ code e2422372874938 = 11218465897146 := by decide
theorem cert_e2422372874938 : check e2422372874938 [[],[]] .smaller = true := by decide
def e2422372874986 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))) (.var 0)) (.var 0)))))))
theorem wire_e2422372874986 : Closed e2422372874986 ∧ code e2422372874986 = 11218465897194 := by decide
theorem cert_e2422372874986 : check e2422372874986 [[],[]] .smaller = true := by decide
def e2422372875178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372875178 : Closed e2422372875178 ∧ code e2422372875178 = 11218465897386 := by decide
theorem cert_e2422372875178 : check e2422372875178 [[],[]] .smaller = true := by decide
def e2422372875606 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 0)) (.var 1)))))))
theorem wire_e2422372875606 : Closed e2422372875606 ∧ code e2422372875606 = 11218465897814 := by decide
theorem cert_e2422372875606 : check e2422372875606 [[],[]] .smaller = true := by decide
def e2422372875610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 0))) (.var 1)) (.var 0)))))))
theorem wire_e2422372875610 : Closed e2422372875610 ∧ code e2422372875610 = 11218465897818 := by decide
theorem cert_e2422372875610 : check e2422372875610 [[],[]] .smaller = true := by decide
def e2422372875626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))) (.var 0)) (.var 0)))))))
theorem wire_e2422372875626 : Closed e2422372875626 ∧ code e2422372875626 = 11218465897834 := by decide
theorem cert_e2422372875626 : check e2422372875626 [[],[]] .smaller = true := by decide
def e2422372875690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))) (.var 0)) (.var 0)))))))
theorem wire_e2422372875690 : Closed e2422372875690 ∧ code e2422372875690 = 11218465897898 := by decide
theorem cert_e2422372875690 : check e2422372875690 [[],[]] .smaller = true := by decide
def e2422372876654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 1)) (.var 2)))))))
theorem wire_e2422372876654 : Closed e2422372876654 ∧ code e2422372876654 = 11218465898862 := by decide
theorem cert_e2422372876654 : check e2422372876654 [[],[]] .smaller = true := by decide
def e2422372876662 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.lam (.var 0))))) (.var 2)) (.var 1)))))))
theorem wire_e2422372876662 : Closed e2422372876662 ∧ code e2422372876662 = 11218465898870 := by decide
theorem cert_e2422372876662 : check e2422372876662 [[],[]] .smaller = true := by decide
def e2422372877790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 3)))))))
theorem wire_e2422372877790 : Closed e2422372877790 ∧ code e2422372877790 = 11218465899998 := by decide
theorem cert_e2422372877790 : check e2422372877790 [[],[]] .three = true := by decide
def e2422372877806 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 0)))) (.var 3)) (.var 2)))))))
theorem wire_e2422372877806 : Closed e2422372877806 ∧ code e2422372877806 = 11218465900014 := by decide
theorem cert_e2422372877806 : check e2422372877806 [[],[]] .three = true := by decide
def e2422372878046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 1)) (.var 3)))))))
theorem wire_e2422372878046 : Closed e2422372878046 ∧ code e2422372878046 = 11218465900254 := by decide
theorem cert_e2422372878046 : check e2422372878046 [[],[]] .three = true := by decide
def e2422372878070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 1)))) (.var 3)) (.var 1)))))))
theorem wire_e2422372878070 : Closed e2422372878070 ∧ code e2422372878070 = 11218465900278 := by decide
theorem cert_e2422372878070 : check e2422372878070 [[],[]] .three = true := by decide
def e2422372878174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372878174 : Closed e2422372878174 ∧ code e2422372878174 = 11218465900382 := by decide
theorem cert_e2422372878174 : check e2422372878174 [[],[]] .three = true := by decide
def e2422372878190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372878190 : Closed e2422372878190 ∧ code e2422372878190 = 11218465900398 := by decide
theorem cert_e2422372878190 : check e2422372878190 [[],[]] .smaller = true := by decide
def e2422372878198 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372878198 : Closed e2422372878198 ∧ code e2422372878198 = 11218465900406 := by decide
theorem cert_e2422372878198 : check e2422372878198 [[],[]] .smaller = true := by decide
def e2422372878202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 2)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372878202 : Closed e2422372878202 ∧ code e2422372878202 = 11218465900410 := by decide
theorem cert_e2422372878202 : check e2422372878202 [[],[]] .three = true := by decide
def e2422372878262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 3)))) (.var 1)) (.var 1)))))))
theorem wire_e2422372878262 : Closed e2422372878262 ∧ code e2422372878262 = 11218465900470 := by decide
theorem cert_e2422372878262 : check e2422372878262 [[],[]] .smaller = true := by decide
def e2422372878294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372878294 : Closed e2422372878294 ∧ code e2422372878294 = 11218465900502 := by decide
theorem cert_e2422372878294 : check e2422372878294 [[],[]] .three = true := by decide
def e2422372878298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.lam (.var 4)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372878298 : Closed e2422372878298 ∧ code e2422372878298 = 11218465900506 := by decide
theorem cert_e2422372878298 : check e2422372878298 [[],[]] .three = true := by decide
def e2422372879726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372879726 : Closed e2422372879726 ∧ code e2422372879726 = 11218465901934 := by decide
theorem cert_e2422372879726 : check e2422372879726 [[],[]] .smaller = true := by decide
def e2422372879734 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 0)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372879734 : Closed e2422372879734 ∧ code e2422372879734 = 11218465901942 := by decide
theorem cert_e2422372879734 : check e2422372879734 [[],[]] .smaller = true := by decide
def e2422372879790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372879790 : Closed e2422372879790 ∧ code e2422372879790 = 11218465901998 := by decide
theorem cert_e2422372879790 : check e2422372879790 [[],[]] .smaller = true := by decide
def e2422372879802 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 1)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372879802 : Closed e2422372879802 ∧ code e2422372879802 = 11218465902010 := by decide
theorem cert_e2422372879802 : check e2422372879802 [[],[]] .smaller = true := by decide
def e2422372879830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372879830 : Closed e2422372879830 ∧ code e2422372879830 = 11218465902038 := by decide
theorem cert_e2422372879830 : check e2422372879830 [[],[]] .smaller = true := by decide
def e2422372879834 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 0) (.var 2)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372879834 : Closed e2422372879834 ∧ code e2422372879834 = 11218465902042 := by decide
theorem cert_e2422372879834 : check e2422372879834 [[],[]] .smaller = true := by decide
def e2422372880046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372880046 : Closed e2422372880046 ∧ code e2422372880046 = 11218465902254 := by decide
theorem cert_e2422372880046 : check e2422372880046 [[],[]] .smaller = true := by decide
def e2422372880058 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372880058 : Closed e2422372880058 ∧ code e2422372880058 = 11218465902266 := by decide
theorem cert_e2422372880058 : check e2422372880058 [[],[]] .smaller = true := by decide
def e2422372880106 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372880106 : Closed e2422372880106 ∧ code e2422372880106 = 11218465902314 := by decide
theorem cert_e2422372880106 : check e2422372880106 [[],[]] .smaller = true := by decide
def e2422372880214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372880214 : Closed e2422372880214 ∧ code e2422372880214 = 11218465902422 := by decide
theorem cert_e2422372880214 : check e2422372880214 [[],[]] .smaller = true := by decide
def e2422372880218 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 0)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372880218 : Closed e2422372880218 ∧ code e2422372880218 = 11218465902426 := by decide
theorem cert_e2422372880218 : check e2422372880218 [[],[]] .smaller = true := by decide
def e2422372880234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372880234 : Closed e2422372880234 ∧ code e2422372880234 = 11218465902442 := by decide
theorem cert_e2422372880234 : check e2422372880234 [[],[]] .smaller = true := by decide
def e2422372880862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 2))) (.var 3)))))))
theorem wire_e2422372880862 : Closed e2422372880862 ∧ code e2422372880862 = 11218465903070 := by decide
theorem cert_e2422372880862 : check e2422372880862 [[],[]] .three = true := by decide
def e2422372880886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.lam (.var 4))) (.var 1)))))))
theorem wire_e2422372880886 : Closed e2422372880886 ∧ code e2422372880886 = 11218465903094 := by decide
theorem cert_e2422372880886 : check e2422372880886 [[],[]] .three = true := by decide
def e2422372881262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e2422372881262 : Closed e2422372881262 ∧ code e2422372881262 = 11218465903470 := by decide
theorem cert_e2422372881262 : check e2422372881262 [[],[]] .smaller = true := by decide
def e2422372881270 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e2422372881270 : Closed e2422372881270 ∧ code e2422372881270 = 11218465903478 := by decide
theorem cert_e2422372881270 : check e2422372881270 [[],[]] .smaller = true := by decide
def e2422372881326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e2422372881326 : Closed e2422372881326 ∧ code e2422372881326 = 11218465903534 := by decide
theorem cert_e2422372881326 : check e2422372881326 [[],[]] .smaller = true := by decide
def e2422372881338 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e2422372881338 : Closed e2422372881338 ∧ code e2422372881338 = 11218465903546 := by decide
theorem cert_e2422372881338 : check e2422372881338 [[],[]] .smaller = true := by decide
def e2422372881366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e2422372881366 : Closed e2422372881366 ∧ code e2422372881366 = 11218465903574 := by decide
theorem cert_e2422372881366 : check e2422372881366 [[],[]] .smaller = true := by decide
def e2422372881370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e2422372881370 : Closed e2422372881370 ∧ code e2422372881370 = 11218465903578 := by decide
theorem cert_e2422372881370 : check e2422372881370 [[],[]] .smaller = true := by decide
def e2422372881646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e2422372881646 : Closed e2422372881646 ∧ code e2422372881646 = 11218465903854 := by decide
theorem cert_e2422372881646 : check e2422372881646 [[],[]] .smaller = true := by decide
def e2422372881654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e2422372881654 : Closed e2422372881654 ∧ code e2422372881654 = 11218465903862 := by decide
theorem cert_e2422372881654 : check e2422372881654 [[],[]] .smaller = true := by decide
def e2422372881982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.lam (.var 4))))))))
theorem wire_e2422372881982 : Closed e2422372881982 ∧ code e2422372881982 = 11218465904190 := by decide
theorem cert_e2422372881982 : check e2422372881982 [[],[]] .three = true := by decide
def e2422372882030 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372882030 : Closed e2422372882030 ∧ code e2422372882030 = 11218465904238 := by decide
theorem cert_e2422372882030 : check e2422372882030 [[],[]] .smaller = true := by decide
def e2422372882042 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372882042 : Closed e2422372882042 ∧ code e2422372882042 = 11218465904250 := by decide
theorem cert_e2422372882042 : check e2422372882042 [[],[]] .smaller = true := by decide
def e2422372882230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372882230 : Closed e2422372882230 ∧ code e2422372882230 = 11218465904438 := by decide
theorem cert_e2422372882230 : check e2422372882230 [[],[]] .smaller = true := by decide
def e2422372882234 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372882234 : Closed e2422372882234 ∧ code e2422372882234 = 11218465904442 := by decide
theorem cert_e2422372882234 : check e2422372882234 [[],[]] .smaller = true := by decide
def e2422372882318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 0))) (.var 3)) (.lam (.var 2))))))))
theorem wire_e2422372882318 : Closed e2422372882318 ∧ code e2422372882318 = 11218465904526 := by decide
theorem cert_e2422372882318 : check e2422372882318 [[],[]] .three = true := by decide
def e2422372882478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372882478 : Closed e2422372882478 ∧ code e2422372882478 = 11218465904686 := by decide
theorem cert_e2422372882478 : check e2422372882478 [[],[]] .smaller = true := by decide
def e2422372882654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372882654 : Closed e2422372882654 ∧ code e2422372882654 = 11218465904862 := by decide
theorem cert_e2422372882654 : check e2422372882654 [[],[]] .three = true := by decide
def e2422372882670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 2))) (.var 2)))))))
theorem wire_e2422372882670 : Closed e2422372882670 ∧ code e2422372882670 = 11218465904878 := by decide
theorem cert_e2422372882670 : check e2422372882670 [[],[]] .smaller = true := by decide
def e2422372882678 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 3))) (.var 1)))))))
theorem wire_e2422372882678 : Closed e2422372882678 ∧ code e2422372882678 = 11218465904886 := by decide
theorem cert_e2422372882678 : check e2422372882678 [[],[]] .smaller = true := by decide
def e2422372882682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.lam (.var 4))) (.var 0)))))))
theorem wire_e2422372882682 : Closed e2422372882682 ∧ code e2422372882682 = 11218465904890 := by decide
theorem cert_e2422372882682 : check e2422372882682 [[],[]] .three = true := by decide
def e2422372882862 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e2422372882862 : Closed e2422372882862 ∧ code e2422372882862 = 11218465905070 := by decide
theorem cert_e2422372882862 : check e2422372882862 [[],[]] .smaller = true := by decide
def e2422372882874 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e2422372882874 : Closed e2422372882874 ∧ code e2422372882874 = 11218465905082 := by decide
theorem cert_e2422372882874 : check e2422372882874 [[],[]] .smaller = true := by decide
def e2422372882922 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e2422372882922 : Closed e2422372882922 ∧ code e2422372882922 = 11218465905130 := by decide
theorem cert_e2422372882922 : check e2422372882922 [[],[]] .smaller = true := by decide
def e2422372883006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.lam (.var 4))))))))
theorem wire_e2422372883006 : Closed e2422372883006 ∧ code e2422372883006 = 11218465905214 := by decide
theorem cert_e2422372883006 : check e2422372883006 [[],[]] .three = true := by decide
def e2422372883054 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e2422372883054 : Closed e2422372883054 ∧ code e2422372883054 = 11218465905262 := by decide
theorem cert_e2422372883054 : check e2422372883054 [[],[]] .smaller = true := by decide
def e2422372883066 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e2422372883066 : Closed e2422372883066 ∧ code e2422372883066 = 11218465905274 := by decide
theorem cert_e2422372883066 : check e2422372883066 [[],[]] .smaller = true := by decide
def e2422372883230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 1)) (.lam (.var 3))))))))
theorem wire_e2422372883230 : Closed e2422372883230 ∧ code e2422372883230 = 11218465905438 := by decide
theorem cert_e2422372883230 : check e2422372883230 [[],[]] .smaller = true := by decide
def e2422372883330 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372883330 : Closed e2422372883330 ∧ code e2422372883330 = 11218465905538 := by decide
theorem cert_e2422372883330 : check e2422372883330 [[],[]] .smaller = true := by decide
def e2422372883342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 2))))))))
theorem wire_e2422372883342 : Closed e2422372883342 ∧ code e2422372883342 = 11218465905550 := by decide
theorem cert_e2422372883342 : check e2422372883342 [[],[]] .smaller = true := by decide
def e2422372883354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372883354 : Closed e2422372883354 ∧ code e2422372883354 = 11218465905562 := by decide
theorem cert_e2422372883354 : check e2422372883354 [[],[]] .smaller = true := by decide
def e2422372883398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.lam (.var 1))))))))
theorem wire_e2422372883398 : Closed e2422372883398 ∧ code e2422372883398 = 11218465905606 := by decide
theorem cert_e2422372883398 : check e2422372883398 [[],[]] .three = true := by decide
def e2422372883422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 3)) (.var 3)))))))
theorem wire_e2422372883422 : Closed e2422372883422 ∧ code e2422372883422 = 11218465905630 := by decide
theorem cert_e2422372883422 : check e2422372883422 [[],[]] .three = true := by decide
def e2422372883478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.lam (.var 0)))) (.var 1)))))))
theorem wire_e2422372883478 : Closed e2422372883478 ∧ code e2422372883478 = 11218465905686 := by decide
theorem cert_e2422372883478 : check e2422372883478 [[],[]] .smaller = true := by decide
def e2422372883550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 3)))))))
theorem wire_e2422372883550 : Closed e2422372883550 ∧ code e2422372883550 = 11218465905758 := by decide
theorem cert_e2422372883550 : check e2422372883550 [[],[]] .three = true := by decide
def e2422372883574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.lam (.var 2))) (.var 1)))))))
theorem wire_e2422372883574 : Closed e2422372883574 ∧ code e2422372883574 = 11218465905782 := by decide
theorem cert_e2422372883574 : check e2422372883574 [[],[]] .smaller = true := by decide
def e2422372883670 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e2422372883670 : Closed e2422372883670 ∧ code e2422372883670 = 11218465905878 := by decide
theorem cert_e2422372883670 : check e2422372883670 [[],[]] .smaller = true := by decide
def e2422372883674 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e2422372883674 : Closed e2422372883674 ∧ code e2422372883674 = 11218465905882 := by decide
theorem cert_e2422372883674 : check e2422372883674 [[],[]] .smaller = true := by decide
def e2422372883690 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e2422372883690 : Closed e2422372883690 ∧ code e2422372883690 = 11218465905898 := by decide
theorem cert_e2422372883690 : check e2422372883690 [[],[]] .smaller = true := by decide
def e2422372883766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e2422372883766 : Closed e2422372883766 ∧ code e2422372883766 = 11218465905974 := by decide
theorem cert_e2422372883766 : check e2422372883766 [[],[]] .smaller = true := by decide
def e2422372883770 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e2422372883770 : Closed e2422372883770 ∧ code e2422372883770 = 11218465905978 := by decide
theorem cert_e2422372883770 : check e2422372883770 [[],[]] .smaller = true := by decide
def e2422372883842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.lam (.var 0)))))))))
theorem wire_e2422372883842 : Closed e2422372883842 ∧ code e2422372883842 = 11218465906050 := by decide
theorem cert_e2422372883842 : check e2422372883842 [[],[]] .smaller = true := by decide
def e2422372883854 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 2))))))))
theorem wire_e2422372883854 : Closed e2422372883854 ∧ code e2422372883854 = 11218465906062 := by decide
theorem cert_e2422372883854 : check e2422372883854 [[],[]] .smaller = true := by decide
def e2422372883866 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e2422372883866 : Closed e2422372883866 ∧ code e2422372883866 = 11218465906074 := by decide
theorem cert_e2422372883866 : check e2422372883866 [[],[]] .smaller = true := by decide
def e2422372883934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 2)) (.var 3)))))))
theorem wire_e2422372883934 : Closed e2422372883934 ∧ code e2422372883934 = 11218465906142 := by decide
theorem cert_e2422372883934 : check e2422372883934 [[],[]] .three = true := by decide
def e2422372883938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)) (.lam (.var 0))))))))
theorem wire_e2422372883938 : Closed e2422372883938 ∧ code e2422372883938 = 11218465906146 := by decide
theorem cert_e2422372883938 : check e2422372883938 [[],[]] .three = true := by decide
def e2422372883950 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3)) (.var 2)))))))
theorem wire_e2422372883950 : Closed e2422372883950 ∧ code e2422372883950 = 11218465906158 := by decide
theorem cert_e2422372883950 : check e2422372883950 [[],[]] .three = true := by decide
def e2422372884014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 0))) (.var 2)))))))
theorem wire_e2422372884014 : Closed e2422372884014 ∧ code e2422372884014 = 11218465906222 := by decide
theorem cert_e2422372884014 : check e2422372884014 [[],[]] .three = true := by decide
def e2422372884022 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 1))) (.var 1)))))))
theorem wire_e2422372884022 : Closed e2422372884022 ∧ code e2422372884022 = 11218465906230 := by decide
theorem cert_e2422372884022 : check e2422372884022 [[],[]] .three = true := by decide
def e2422372884026 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.lam (.var 2))) (.var 0)))))))
theorem wire_e2422372884026 : Closed e2422372884026 ∧ code e2422372884026 = 11218465906234 := by decide
theorem cert_e2422372884026 : check e2422372884026 [[],[]] .three = true := by decide
def e2422372884110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 0)) (.lam (.var 2))))))))
theorem wire_e2422372884110 : Closed e2422372884110 ∧ code e2422372884110 = 11218465906318 := by decide
theorem cert_e2422372884110 : check e2422372884110 [[],[]] .three = true := by decide
def e2422372884166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.lam (.var 1))))))))
theorem wire_e2422372884166 : Closed e2422372884166 ∧ code e2422372884166 = 11218465906374 := by decide
theorem cert_e2422372884166 : check e2422372884166 [[],[]] .three = true := by decide
def e2422372884190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 1)) (.var 3)))))))
theorem wire_e2422372884190 : Closed e2422372884190 ∧ code e2422372884190 = 11218465906398 := by decide
theorem cert_e2422372884190 : check e2422372884190 [[],[]] .three = true := by decide
def e2422372884194 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)) (.lam (.var 0))))))))
theorem wire_e2422372884194 : Closed e2422372884194 ∧ code e2422372884194 = 11218465906402 := by decide
theorem cert_e2422372884194 : check e2422372884194 [[],[]] .three = true := by decide
def e2422372884206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2)) (.var 2)))))))
theorem wire_e2422372884206 : Closed e2422372884206 ∧ code e2422372884206 = 11218465906414 := by decide
theorem cert_e2422372884206 : check e2422372884206 [[],[]] .three = true := by decide
def e2422372884214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 3)) (.var 1)))))))
theorem wire_e2422372884214 : Closed e2422372884214 ∧ code e2422372884214 = 11218465906422 := by decide
theorem cert_e2422372884214 : check e2422372884214 [[],[]] .three = true := by decide
def e2422372884654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 0)) (.var 2)))))))
theorem wire_e2422372884654 : Closed e2422372884654 ∧ code e2422372884654 = 11218465906862 := by decide
theorem cert_e2422372884654 : check e2422372884654 [[],[]] .smaller = true := by decide
def e2422372884666 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.lam (.var 0))))) (.var 2)) (.var 0)))))))
theorem wire_e2422372884666 : Closed e2422372884666 ∧ code e2422372884666 = 11218465906874 := by decide
theorem cert_e2422372884666 : check e2422372884666 [[],[]] .smaller = true := by decide
def e2422372885214 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 1)) (.var 3)))))))
theorem wire_e2422372885214 : Closed e2422372885214 ∧ code e2422372885214 = 11218465907422 := by decide
theorem cert_e2422372885214 : check e2422372885214 [[],[]] .three = true := by decide
def e2422372885230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 2)))))))
theorem wire_e2422372885230 : Closed e2422372885230 ∧ code e2422372885230 = 11218465907438 := by decide
theorem cert_e2422372885230 : check e2422372885230 [[],[]] .smaller = true := by decide
def e2422372885238 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 0)))) (.var 3)) (.var 1)))))))
theorem wire_e2422372885238 : Closed e2422372885238 ∧ code e2422372885238 = 11218465907446 := by decide
theorem cert_e2422372885238 : check e2422372885238 [[],[]] .three = true := by decide
def e2422372885342 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 0)) (.var 3)))))))
theorem wire_e2422372885342 : Closed e2422372885342 ∧ code e2422372885342 = 11218465907550 := by decide
theorem cert_e2422372885342 : check e2422372885342 [[],[]] .three = true := by decide
def e2422372885358 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 1)) (.var 2)))))))
theorem wire_e2422372885358 : Closed e2422372885358 ∧ code e2422372885358 = 11218465907566 := by decide
theorem cert_e2422372885358 : check e2422372885358 [[],[]] .smaller = true := by decide
def e2422372885366 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 2)) (.var 1)))))))
theorem wire_e2422372885366 : Closed e2422372885366 ∧ code e2422372885366 = 11218465907574 := by decide
theorem cert_e2422372885366 : check e2422372885366 [[],[]] .smaller = true := by decide
def e2422372885370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 1)))) (.var 3)) (.var 0)))))))
theorem wire_e2422372885370 : Closed e2422372885370 ∧ code e2422372885370 = 11218465907578 := by decide
theorem cert_e2422372885370 : check e2422372885370 [[],[]] .three = true := by decide
def e2422372885422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372885422 : Closed e2422372885422 ∧ code e2422372885422 = 11218465907630 := by decide
theorem cert_e2422372885422 : check e2422372885422 [[],[]] .smaller = true := by decide
def e2422372885434 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 2)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372885434 : Closed e2422372885434 ∧ code e2422372885434 = 11218465907642 := by decide
theorem cert_e2422372885434 : check e2422372885434 [[],[]] .smaller = true := by decide
def e2422372885462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 0)) (.var 1)))))))
theorem wire_e2422372885462 : Closed e2422372885462 ∧ code e2422372885462 = 11218465907670 := by decide
theorem cert_e2422372885462 : check e2422372885462 [[],[]] .smaller = true := by decide
def e2422372885466 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 3)))) (.var 1)) (.var 0)))))))
theorem wire_e2422372885466 : Closed e2422372885466 ∧ code e2422372885466 = 11218465907674 := by decide
theorem cert_e2422372885466 : check e2422372885466 [[],[]] .smaller = true := by decide
def e2422372885482 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.lam (.var 4)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372885482 : Closed e2422372885482 ∧ code e2422372885482 = 11218465907690 := by decide
theorem cert_e2422372885482 : check e2422372885482 [[],[]] .three = true := by decide
def e2422372886190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 0)) (.var 2)))))))
theorem wire_e2422372886190 : Closed e2422372886190 ∧ code e2422372886190 = 11218465908398 := by decide
theorem cert_e2422372886190 : check e2422372886190 [[],[]] .smaller = true := by decide
def e2422372886202 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 0)))) (.var 2)) (.var 0)))))))
theorem wire_e2422372886202 : Closed e2422372886202 ∧ code e2422372886202 = 11218465908410 := by decide
theorem cert_e2422372886202 : check e2422372886202 [[],[]] .smaller = true := by decide
def e2422372886250 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372886250 : Closed e2422372886250 ∧ code e2422372886250 = 11218465908458 := by decide
theorem cert_e2422372886250 : check e2422372886250 [[],[]] .smaller = true := by decide
def e2422372886442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))) (.var 0)) (.var 0)))))))
theorem wire_e2422372886442 : Closed e2422372886442 ∧ code e2422372886442 = 11218465908650 := by decide
theorem cert_e2422372886442 : check e2422372886442 [[],[]] .smaller = true := by decide
def e2422372886574 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.lam (.var 0)))) (.var 2)))))))
theorem wire_e2422372886574 : Closed e2422372886574 ∧ code e2422372886574 = 11218465908782 := by decide
theorem cert_e2422372886574 : check e2422372886574 [[],[]] .smaller = true := by decide
def e2422372886750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.lam (.var 1))) (.var 3)))))))
theorem wire_e2422372886750 : Closed e2422372886750 ∧ code e2422372886750 = 11218465908958 := by decide
theorem cert_e2422372886750 : check e2422372886750 [[],[]] .three = true := by decide
end Blc.Floor43
