import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e700955244986 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e700955244986 : Closed e700955244986 ∧ code e700955244986 = 9497048267194 := by decide
theorem cert_e700955244986 : check e700955244986 [[.under,.left],[.under,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left,.left],[.under,.left],[.under,.left],[.under],[.under,.left],[.under],[.under]] .sourceHead = true := by decide
def e700955245034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e700955245034 : Closed e700955245034 ∧ code e700955245034 = 9497048267242 := by decide
theorem cert_e700955245034 : checkPay e700955245034 [[.left],[.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left,.left],[.left,.left],[.left,.left],[.left],[.left],[],[.left],[.left,.left],[.left]] 0 [[],[],[.under],[.under,.under,.left,.left],[.under,.under,.left],[.under,.under,.left,.right],[.under,.under,.right],[.under,.under,.right,.under,.right,.left],[.under,.under,.right,.under,.right],[.under,.under,.right,.under,.right,.right]] = true := by decide
def e700955245786 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e700955245786 : Closed e700955245786 ∧ code e700955245786 = 9497048267994 := by decide
def e700955245802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.app (.var 0) (.var 0)))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e700955245802 : Closed e700955245802 ∧ code e700955245802 = 9497048268010 := by decide
def e701153588666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))) (.var 0)))
theorem wire_e701153588666 : Closed e701153588666 ∧ code e701153588666 = 9497246610874 := by decide
theorem cert_e701153588666 : check e701153588666 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153588698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))) (.var 0)))
theorem wire_e701153588698 : Closed e701153588698 ∧ code e701153588698 = 9497246610906 := by decide
theorem cert_e701153588698 : check e701153588698 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153588922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701153588922 : Closed e701153588922 ∧ code e701153588922 = 9497246611130 := by decide
theorem cert_e701153588922 : check e701153588922 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153588970 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701153588970 : Closed e701153588970 ∧ code e701153588970 = 9497246611178 := by decide
theorem cert_e701153588970 : check e701153588970 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153589082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701153589082 : Closed e701153589082 ∧ code e701153589082 = 9497246611290 := by decide
theorem cert_e701153589082 : check e701153589082 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153589098 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701153589098 : Closed e701153589098 ∧ code e701153589098 = 9497246611306 := by decide
theorem cert_e701153589098 : check e701153589098 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153589946 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))) (.var 0)))
theorem wire_e701153589946 : Closed e701153589946 ∧ code e701153589946 = 9497246612154 := by decide
theorem cert_e701153589946 : check e701153589946 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153589994 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))) (.var 0)))
theorem wire_e701153589994 : Closed e701153589994 ∧ code e701153589994 = 9497246612202 := by decide
theorem cert_e701153589994 : check e701153589994 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153590186 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701153590186 : Closed e701153590186 ∧ code e701153590186 = 9497246612394 := by decide
theorem cert_e701153590186 : check e701153590186 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153590618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))) (.var 0)))
theorem wire_e701153590618 : Closed e701153590618 ∧ code e701153590618 = 9497246612826 := by decide
theorem cert_e701153590618 : check e701153590618 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153590634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))) (.var 0)))
theorem wire_e701153590634 : Closed e701153590634 ∧ code e701153590634 = 9497246612842 := by decide
theorem cert_e701153590634 : check e701153590634 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153590698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))) (.var 0)))
theorem wire_e701153590698 : Closed e701153590698 ∧ code e701153590698 = 9497246612906 := by decide
theorem cert_e701153590698 : check e701153590698 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153594810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))) (.var 0)))
theorem wire_e701153594810 : Closed e701153594810 ∧ code e701153594810 = 9497246617018 := by decide
theorem cert_e701153594810 : check e701153594810 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153594842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))) (.var 0)))
theorem wire_e701153594842 : Closed e701153594842 ∧ code e701153594842 = 9497246617050 := by decide
theorem cert_e701153594842 : check e701153594842 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153595066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))) (.var 0)))
theorem wire_e701153595066 : Closed e701153595066 ∧ code e701153595066 = 9497246617274 := by decide
theorem cert_e701153595066 : check e701153595066 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153595114 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))) (.var 0)))
theorem wire_e701153595114 : Closed e701153595114 ∧ code e701153595114 = 9497246617322 := by decide
theorem cert_e701153595114 : check e701153595114 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153595226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))) (.var 0)))
theorem wire_e701153595226 : Closed e701153595226 ∧ code e701153595226 = 9497246617434 := by decide
theorem cert_e701153595226 : check e701153595226 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153595242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))) (.var 0)))
theorem wire_e701153595242 : Closed e701153595242 ∧ code e701153595242 = 9497246617450 := by decide
theorem cert_e701153595242 : check e701153595242 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153596346 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))) (.var 0)))
theorem wire_e701153596346 : Closed e701153596346 ∧ code e701153596346 = 9497246618554 := by decide
theorem cert_e701153596346 : check e701153596346 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153596378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))) (.var 0)))
theorem wire_e701153596378 : Closed e701153596378 ∧ code e701153596378 = 9497246618586 := by decide
theorem cert_e701153596378 : check e701153596378 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153597882 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701153597882 : Closed e701153597882 ∧ code e701153597882 = 9497246620090 := by decide
theorem cert_e701153597882 : check e701153597882 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153597930 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701153597930 : Closed e701153597930 ∧ code e701153597930 = 9497246620138 := by decide
theorem cert_e701153597930 : check e701153597930 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153598682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701153598682 : Closed e701153598682 ∧ code e701153598682 = 9497246620890 := by decide
theorem cert_e701153598682 : check e701153598682 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153598698 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701153598698 : Closed e701153598698 ∧ code e701153598698 = 9497246620906 := by decide
theorem cert_e701153598698 : check e701153598698 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153601210 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))) (.var 0)))
theorem wire_e701153601210 : Closed e701153601210 ∧ code e701153601210 = 9497246623418 := by decide
theorem cert_e701153601210 : check e701153601210 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153601258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))) (.var 0)))
theorem wire_e701153601258 : Closed e701153601258 ∧ code e701153601258 = 9497246623466 := by decide
theorem cert_e701153601258 : check e701153601258 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153601450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))) (.var 0)))
theorem wire_e701153601450 : Closed e701153601450 ∧ code e701153601450 = 9497246623658 := by decide
theorem cert_e701153601450 : check e701153601450 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153601978 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))) (.var 0)))
theorem wire_e701153601978 : Closed e701153601978 ∧ code e701153601978 = 9497246624186 := by decide
theorem cert_e701153601978 : check e701153601978 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153602026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))) (.var 0)))
theorem wire_e701153602026 : Closed e701153602026 ∧ code e701153602026 = 9497246624234 := by decide
theorem cert_e701153602026 : check e701153602026 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153603178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701153603178 : Closed e701153603178 ∧ code e701153603178 = 9497246625386 := by decide
theorem cert_e701153603178 : check e701153603178 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153604442 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))) (.var 0)))
theorem wire_e701153604442 : Closed e701153604442 ∧ code e701153604442 = 9497246626650 := by decide
theorem cert_e701153604442 : check e701153604442 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153604458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))) (.var 0)))
theorem wire_e701153604458 : Closed e701153604458 ∧ code e701153604458 = 9497246626666 := by decide
theorem cert_e701153604458 : check e701153604458 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153604522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))) (.var 0)))
theorem wire_e701153604522 : Closed e701153604522 ∧ code e701153604522 = 9497246626730 := by decide
theorem cert_e701153604522 : check e701153604522 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153604826 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))) (.var 0)))
theorem wire_e701153604826 : Closed e701153604826 ∧ code e701153604826 = 9497246627034 := by decide
theorem cert_e701153604826 : check e701153604826 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153604842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))) (.var 0)))
theorem wire_e701153604842 : Closed e701153604842 ∧ code e701153604842 = 9497246627050 := by decide
theorem cert_e701153604842 : check e701153604842 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153605226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))) (.var 0)))
theorem wire_e701153605226 : Closed e701153605226 ∧ code e701153605226 = 9497246627434 := by decide
theorem cert_e701153605226 : check e701153605226 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153619386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))) (.var 0)))
theorem wire_e701153619386 : Closed e701153619386 ∧ code e701153619386 = 9497246641594 := by decide
theorem cert_e701153619386 : check e701153619386 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153619418 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))) (.var 0)))
theorem wire_e701153619418 : Closed e701153619418 ∧ code e701153619418 = 9497246641626 := by decide
theorem cert_e701153619418 : check e701153619418 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153619642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))) (.var 0)))
theorem wire_e701153619642 : Closed e701153619642 ∧ code e701153619642 = 9497246641850 := by decide
theorem cert_e701153619642 : check e701153619642 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153619690 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))) (.var 0)))
theorem wire_e701153619690 : Closed e701153619690 ∧ code e701153619690 = 9497246641898 := by decide
theorem cert_e701153619690 : check e701153619690 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153619802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))) (.var 0)))
theorem wire_e701153619802 : Closed e701153619802 ∧ code e701153619802 = 9497246642010 := by decide
theorem cert_e701153619802 : check e701153619802 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153619818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))) (.var 0)))
theorem wire_e701153619818 : Closed e701153619818 ∧ code e701153619818 = 9497246642026 := by decide
theorem cert_e701153619818 : check e701153619818 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153620922 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))) (.var 0)))
theorem wire_e701153620922 : Closed e701153620922 ∧ code e701153620922 = 9497246643130 := by decide
theorem cert_e701153620922 : check e701153620922 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153620954 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))) (.var 0)))
theorem wire_e701153620954 : Closed e701153620954 ∧ code e701153620954 = 9497246643162 := by decide
theorem cert_e701153620954 : check e701153620954 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153622458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))) (.var 0)))
theorem wire_e701153622458 : Closed e701153622458 ∧ code e701153622458 = 9497246644666 := by decide
theorem cert_e701153622458 : check e701153622458 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153622506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))) (.var 0)))
theorem wire_e701153622506 : Closed e701153622506 ∧ code e701153622506 = 9497246644714 := by decide
theorem cert_e701153622506 : check e701153622506 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153623258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))) (.var 0)))
theorem wire_e701153623258 : Closed e701153623258 ∧ code e701153623258 = 9497246645466 := by decide
theorem cert_e701153623258 : check e701153623258 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153623274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))) (.var 0)))
theorem wire_e701153623274 : Closed e701153623274 ∧ code e701153623274 = 9497246645482 := by decide
theorem cert_e701153623274 : check e701153623274 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153646266 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))) (.var 0)))
theorem wire_e701153646266 : Closed e701153646266 ∧ code e701153646266 = 9497246668474 := by decide
theorem cert_e701153646266 : check e701153646266 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153646314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))) (.var 0)))
theorem wire_e701153646314 : Closed e701153646314 ∧ code e701153646314 = 9497246668522 := by decide
theorem cert_e701153646314 : check e701153646314 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153646506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))) (.var 0)))
theorem wire_e701153646506 : Closed e701153646506 ∧ code e701153646506 = 9497246668714 := by decide
theorem cert_e701153646506 : check e701153646506 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153647034 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))) (.var 0)))
theorem wire_e701153647034 : Closed e701153647034 ∧ code e701153647034 = 9497246669242 := by decide
theorem cert_e701153647034 : check e701153647034 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153647082 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))) (.var 0)))
theorem wire_e701153647082 : Closed e701153647082 ∧ code e701153647082 = 9497246669290 := by decide
theorem cert_e701153647082 : check e701153647082 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153648234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))) (.var 0)))
theorem wire_e701153648234 : Closed e701153648234 ∧ code e701153648234 = 9497246670442 := by decide
theorem cert_e701153648234 : check e701153648234 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153659738 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))) (.var 0)))
theorem wire_e701153659738 : Closed e701153659738 ∧ code e701153659738 = 9497246681946 := by decide
theorem cert_e701153659738 : check e701153659738 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153659754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))) (.var 0)))
theorem wire_e701153659754 : Closed e701153659754 ∧ code e701153659754 = 9497246681962 := by decide
theorem cert_e701153659754 : check e701153659754 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153659818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))) (.var 0)))
theorem wire_e701153659818 : Closed e701153659818 ∧ code e701153659818 = 9497246682026 := by decide
theorem cert_e701153659818 : check e701153659818 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153660122 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))) (.var 0)))
theorem wire_e701153660122 : Closed e701153660122 ∧ code e701153660122 = 9497246682330 := by decide
theorem cert_e701153660122 : check e701153660122 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153660138 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))) (.var 0)))
theorem wire_e701153660138 : Closed e701153660138 ∧ code e701153660138 = 9497246682346 := by decide
theorem cert_e701153660138 : check e701153660138 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701153660522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))) (.var 0)))
theorem wire_e701153660522 : Closed e701153660522 ∧ code e701153660522 = 9497246682730 := by decide
theorem cert_e701153660522 : check e701153660522 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154121594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 3))))))) (.var 0)))
theorem wire_e701154121594 : Closed e701154121594 ∧ code e701154121594 = 9497247143802 := by decide
theorem cert_e701154121594 : check e701154121594 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154121658 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 3)) (.var 2))))))) (.var 0)))
theorem wire_e701154121658 : Closed e701154121658 ∧ code e701154121658 = 9497247143866 := by decide
theorem cert_e701154121658 : check e701154121658 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154122618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 1)) (.var 3))))))) (.var 0)))
theorem wire_e701154122618 : Closed e701154122618 ∧ code e701154122618 = 9497247144826 := by decide
theorem cert_e701154122618 : check e701154122618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154122682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 2))))))) (.var 0)))
theorem wire_e701154122682 : Closed e701154122682 ∧ code e701154122682 = 9497247144890 := by decide
theorem cert_e701154122682 : check e701154122682 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154122714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 3)) (.var 1))))))) (.var 0)))
theorem wire_e701154122714 : Closed e701154122714 ∧ code e701154122714 = 9497247144922 := by decide
theorem cert_e701154122714 : check e701154122714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154123130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 3))))))) (.var 0)))
theorem wire_e701154123130 : Closed e701154123130 ∧ code e701154123130 = 9497247145338 := by decide
theorem cert_e701154123130 : check e701154123130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154123194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701154123194 : Closed e701154123194 ∧ code e701154123194 = 9497247145402 := by decide
theorem cert_e701154123194 : check e701154123194 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154123226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701154123226 : Closed e701154123226 ∧ code e701154123226 = 9497247145434 := by decide
theorem cert_e701154123226 : check e701154123226 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154123242 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 3)) (.var 0))))))) (.var 0)))
theorem wire_e701154123242 : Closed e701154123242 ∧ code e701154123242 = 9497247145450 := by decide
theorem cert_e701154123242 : check e701154123242 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154123450 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701154123450 : Closed e701154123450 ∧ code e701154123450 = 9497247145658 := by decide
theorem cert_e701154123450 : check e701154123450 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154123482 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e701154123482 : Closed e701154123482 ∧ code e701154123482 = 9497247145690 := by decide
theorem cert_e701154123482 : check e701154123482 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154123498 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 3)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701154123498 : Closed e701154123498 ∧ code e701154123498 = 9497247145706 := by decide
theorem cert_e701154123498 : check e701154123498 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154126714 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 1)) (.var 3))))))) (.var 0)))
theorem wire_e701154126714 : Closed e701154126714 ∧ code e701154126714 = 9497247148922 := by decide
theorem cert_e701154126714 : check e701154126714 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154126778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 2))))))) (.var 0)))
theorem wire_e701154126778 : Closed e701154126778 ∧ code e701154126778 = 9497247148986 := by decide
theorem cert_e701154126778 : check e701154126778 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154126810 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 3)) (.var 1))))))) (.var 0)))
theorem wire_e701154126810 : Closed e701154126810 ∧ code e701154126810 = 9497247149018 := by decide
theorem cert_e701154126810 : check e701154126810 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154127226 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 0)) (.var 3))))))) (.var 0)))
theorem wire_e701154127226 : Closed e701154127226 ∧ code e701154127226 = 9497247149434 := by decide
theorem cert_e701154127226 : check e701154127226 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154127338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 1)) (.var 3)) (.var 0))))))) (.var 0)))
theorem wire_e701154127338 : Closed e701154127338 ∧ code e701154127338 = 9497247149546 := by decide
theorem cert_e701154127338 : check e701154127338 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154127546 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701154127546 : Closed e701154127546 ∧ code e701154127546 = 9497247149754 := by decide
theorem cert_e701154127546 : check e701154127546 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154127594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701154127594 : Closed e701154127594 ∧ code e701154127594 = 9497247149802 := by decide
theorem cert_e701154127594 : check e701154127594 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154127706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701154127706 : Closed e701154127706 ∧ code e701154127706 = 9497247149914 := by decide
theorem cert_e701154127706 : check e701154127706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154127722 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 3)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701154127722 : Closed e701154127722 ∧ code e701154127722 = 9497247149930 := by decide
theorem cert_e701154127722 : check e701154127722 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154129274 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 3))))))) (.var 0)))
theorem wire_e701154129274 : Closed e701154129274 ∧ code e701154129274 = 9497247151482 := by decide
theorem cert_e701154129274 : check e701154129274 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154129338 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 2))))))) (.var 0)))
theorem wire_e701154129338 : Closed e701154129338 ∧ code e701154129338 = 9497247151546 := by decide
theorem cert_e701154129338 : check e701154129338 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154129370 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 2)) (.var 1))))))) (.var 0)))
theorem wire_e701154129370 : Closed e701154129370 ∧ code e701154129370 = 9497247151578 := by decide
theorem cert_e701154129370 : check e701154129370 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154129386 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 3)) (.var 0))))))) (.var 0)))
theorem wire_e701154129386 : Closed e701154129386 ∧ code e701154129386 = 9497247151594 := by decide
theorem cert_e701154129386 : check e701154129386 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154129594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701154129594 : Closed e701154129594 ∧ code e701154129594 = 9497247151802 := by decide
theorem cert_e701154129594 : check e701154129594 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154129642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701154129642 : Closed e701154129642 ∧ code e701154129642 = 9497247151850 := by decide
theorem cert_e701154129642 : check e701154129642 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154129754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701154129754 : Closed e701154129754 ∧ code e701154129754 = 9497247151962 := by decide
theorem cert_e701154129754 : check e701154129754 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154129770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 2)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701154129770 : Closed e701154129770 ∧ code e701154129770 = 9497247151978 := by decide
theorem cert_e701154129770 : check e701154129770 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154129834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 3)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701154129834 : Closed e701154129834 ∧ code e701154129834 = 9497247152042 := by decide
theorem cert_e701154129834 : check e701154129834 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154130618 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 0)) (.var 2))))))) (.var 0)))
theorem wire_e701154130618 : Closed e701154130618 ∧ code e701154130618 = 9497247152826 := by decide
theorem cert_e701154130618 : check e701154130618 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154130650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 1)) (.var 1))))))) (.var 0)))
theorem wire_e701154130650 : Closed e701154130650 ∧ code e701154130650 = 9497247152858 := by decide
theorem cert_e701154130650 : check e701154130650 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154130666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 0)) (.var 2)) (.var 0))))))) (.var 0)))
theorem wire_e701154130666 : Closed e701154130666 ∧ code e701154130666 = 9497247152874 := by decide
theorem cert_e701154130666 : check e701154130666 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154130778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 0)) (.var 1))))))) (.var 0)))
theorem wire_e701154130778 : Closed e701154130778 ∧ code e701154130778 = 9497247152986 := by decide
theorem cert_e701154130778 : check e701154130778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154130794 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 1)) (.var 1)) (.var 0))))))) (.var 0)))
theorem wire_e701154130794 : Closed e701154130794 ∧ code e701154130794 = 9497247153002 := by decide
theorem cert_e701154130794 : check e701154130794 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154130858 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.app (.var 3) (.var 2)) (.var 0)) (.var 0))))))) (.var 0)))
theorem wire_e701154130858 : Closed e701154130858 ∧ code e701154130858 = 9497247153066 := by decide
theorem cert_e701154130858 : check e701154130858 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154146170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 3))))))) (.var 0)))
theorem wire_e701154146170 : Closed e701154146170 ∧ code e701154146170 = 9497247168378 := by decide
theorem cert_e701154146170 : check e701154146170 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154146234 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 3))) (.var 2))))))) (.var 0)))
theorem wire_e701154146234 : Closed e701154146234 ∧ code e701154146234 = 9497247168442 := by decide
theorem cert_e701154146234 : check e701154146234 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154147194 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 1))) (.var 3))))))) (.var 0)))
theorem wire_e701154147194 : Closed e701154147194 ∧ code e701154147194 = 9497247169402 := by decide
theorem cert_e701154147194 : check e701154147194 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154147258 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e701154147258 : Closed e701154147258 ∧ code e701154147258 = 9497247169466 := by decide
theorem cert_e701154147258 : check e701154147258 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154147290 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e701154147290 : Closed e701154147290 ∧ code e701154147290 = 9497247169498 := by decide
theorem cert_e701154147290 : check e701154147290 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154147706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 3))))))) (.var 0)))
theorem wire_e701154147706 : Closed e701154147706 ∧ code e701154147706 = 9497247169914 := by decide
theorem cert_e701154147706 : check e701154147706 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154147770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701154147770 : Closed e701154147770 ∧ code e701154147770 = 9497247169978 := by decide
theorem cert_e701154147770 : check e701154147770 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154147802 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701154147802 : Closed e701154147802 ∧ code e701154147802 = 9497247170010 := by decide
theorem cert_e701154147802 : check e701154147802 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154147818 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e701154147818 : Closed e701154147818 ∧ code e701154147818 = 9497247170026 := by decide
theorem cert_e701154147818 : check e701154147818 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154148026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701154148026 : Closed e701154148026 ∧ code e701154148026 = 9497247170234 := by decide
theorem cert_e701154148026 : check e701154148026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154148058 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 1))) (.var 1))))))) (.var 0)))
theorem wire_e701154148058 : Closed e701154148058 ∧ code e701154148058 = 9497247170266 := by decide
theorem cert_e701154148058 : check e701154148058 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154148074 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 3) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701154148074 : Closed e701154148074 ∧ code e701154148074 = 9497247170282 := by decide
theorem cert_e701154148074 : check e701154148074 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154152314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 3)))))))) (.var 0)))
theorem wire_e701154152314 : Closed e701154152314 ∧ code e701154152314 = 9497247174522 := by decide
theorem cert_e701154152314 : check e701154152314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154152378 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 3) (.var 2)))))))) (.var 0)))
theorem wire_e701154152378 : Closed e701154152378 ∧ code e701154152378 = 9497247174586 := by decide
theorem cert_e701154152378 : check e701154152378 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154158458 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 1) (.var 3)))))))) (.var 0)))
theorem wire_e701154158458 : Closed e701154158458 ∧ code e701154158458 = 9497247180666 := by decide
theorem cert_e701154158458 : check e701154158458 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154158522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 2)))))))) (.var 0)))
theorem wire_e701154158522 : Closed e701154158522 ∧ code e701154158522 = 9497247180730 := by decide
theorem cert_e701154158522 : check e701154158522 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154158554 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 3) (.var 1)))))))) (.var 0)))
theorem wire_e701154158554 : Closed e701154158554 ∧ code e701154158554 = 9497247180762 := by decide
theorem cert_e701154158554 : check e701154158554 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154161530 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 3)))))))) (.var 0)))
theorem wire_e701154161530 : Closed e701154161530 ∧ code e701154161530 = 9497247183738 := by decide
theorem cert_e701154161530 : check e701154161530 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154161594 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701154161594 : Closed e701154161594 ∧ code e701154161594 = 9497247183802 := by decide
theorem cert_e701154161594 : check e701154161594 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154161626 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701154161626 : Closed e701154161626 ∧ code e701154161626 = 9497247183834 := by decide
theorem cert_e701154161626 : check e701154161626 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154161642 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 3) (.var 0)))))))) (.var 0)))
theorem wire_e701154161642 : Closed e701154161642 ∧ code e701154161642 = 9497247183850 := by decide
theorem cert_e701154161642 : check e701154161642 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154163130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701154163130 : Closed e701154163130 ∧ code e701154163130 = 9497247185338 := by decide
theorem cert_e701154163130 : check e701154163130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154163162 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 1) (.var 1)))))))) (.var 0)))
theorem wire_e701154163162 : Closed e701154163162 ∧ code e701154163162 = 9497247185370 := by decide
theorem cert_e701154163162 : check e701154163162 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154163178 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 0) (.var 3)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701154163178 : Closed e701154163178 ∧ code e701154163178 = 9497247185386 := by decide
theorem cert_e701154163178 : check e701154163178 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154171770 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 1))) (.var 3))))))) (.var 0)))
theorem wire_e701154171770 : Closed e701154171770 ∧ code e701154171770 = 9497247193978 := by decide
theorem cert_e701154171770 : check e701154171770 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154171834 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 2))))))) (.var 0)))
theorem wire_e701154171834 : Closed e701154171834 ∧ code e701154171834 = 9497247194042 := by decide
theorem cert_e701154171834 : check e701154171834 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154171866 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 3))) (.var 1))))))) (.var 0)))
theorem wire_e701154171866 : Closed e701154171866 ∧ code e701154171866 = 9497247194074 := by decide
theorem cert_e701154171866 : check e701154171866 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154172282 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 0))) (.var 3))))))) (.var 0)))
theorem wire_e701154172282 : Closed e701154172282 ∧ code e701154172282 = 9497247194490 := by decide
theorem cert_e701154172282 : check e701154172282 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154172394 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 1) (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e701154172394 : Closed e701154172394 ∧ code e701154172394 = 9497247194602 := by decide
theorem cert_e701154172394 : check e701154172394 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154172602 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701154172602 : Closed e701154172602 ∧ code e701154172602 = 9497247194810 := by decide
theorem cert_e701154172602 : check e701154172602 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154172650 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701154172650 : Closed e701154172650 ∧ code e701154172650 = 9497247194858 := by decide
theorem cert_e701154172650 : check e701154172650 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154172762 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701154172762 : Closed e701154172762 ∧ code e701154172762 = 9497247194970 := by decide
theorem cert_e701154172762 : check e701154172762 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154172778 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 3) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701154172778 : Closed e701154172778 ∧ code e701154172778 = 9497247194986 := by decide
theorem cert_e701154172778 : check e701154172778 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154174842 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 1) (.var 3)))))))) (.var 0)))
theorem wire_e701154174842 : Closed e701154174842 ∧ code e701154174842 = 9497247197050 := by decide
theorem cert_e701154174842 : check e701154174842 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154174906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 2)))))))) (.var 0)))
theorem wire_e701154174906 : Closed e701154174906 ∧ code e701154174906 = 9497247197114 := by decide
theorem cert_e701154174906 : check e701154174906 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154174938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 3) (.var 1)))))))) (.var 0)))
theorem wire_e701154174938 : Closed e701154174938 ∧ code e701154174938 = 9497247197146 := by decide
theorem cert_e701154174938 : check e701154174938 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154177914 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 0) (.var 3)))))))) (.var 0)))
theorem wire_e701154177914 : Closed e701154177914 ∧ code e701154177914 = 9497247200122 := by decide
theorem cert_e701154177914 : check e701154177914 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154178026 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 1)) (.app (.var 3) (.var 0)))))))) (.var 0)))
theorem wire_e701154178026 : Closed e701154178026 ∧ code e701154178026 = 9497247200234 := by decide
theorem cert_e701154178026 : check e701154178026 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154179514 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701154179514 : Closed e701154179514 ∧ code e701154179514 = 9497247201722 := by decide
theorem cert_e701154179514 : check e701154179514 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154179562 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701154179562 : Closed e701154179562 ∧ code e701154179562 = 9497247201770 := by decide
theorem cert_e701154179562 : check e701154179562 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154180314 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701154180314 : Closed e701154180314 ∧ code e701154180314 = 9497247202522 := by decide
theorem cert_e701154180314 : check e701154180314 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154180330 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 1) (.var 3)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701154180330 : Closed e701154180330 ∧ code e701154180330 = 9497247202538 := by decide
theorem cert_e701154180330 : check e701154180330 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154184570 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 3))))))) (.var 0)))
theorem wire_e701154184570 : Closed e701154184570 ∧ code e701154184570 = 9497247206778 := by decide
theorem cert_e701154184570 : check e701154184570 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154184634 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 2))))))) (.var 0)))
theorem wire_e701154184634 : Closed e701154184634 ∧ code e701154184634 = 9497247206842 := by decide
theorem cert_e701154184634 : check e701154184634 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154184666 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 2))) (.var 1))))))) (.var 0)))
theorem wire_e701154184666 : Closed e701154184666 ∧ code e701154184666 = 9497247206874 := by decide
theorem cert_e701154184666 : check e701154184666 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154184682 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 3))) (.var 0))))))) (.var 0)))
theorem wire_e701154184682 : Closed e701154184682 ∧ code e701154184682 = 9497247206890 := by decide
theorem cert_e701154184682 : check e701154184682 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154184890 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 2))))))) (.var 0)))
theorem wire_e701154184890 : Closed e701154184890 ∧ code e701154184890 = 9497247207098 := by decide
theorem cert_e701154184890 : check e701154184890 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154184938 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 2))) (.var 0))))))) (.var 0)))
theorem wire_e701154184938 : Closed e701154184938 ∧ code e701154184938 = 9497247207146 := by decide
theorem cert_e701154184938 : check e701154184938 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154185050 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 0))) (.var 1))))))) (.var 0)))
theorem wire_e701154185050 : Closed e701154185050 ∧ code e701154185050 = 9497247207258 := by decide
theorem cert_e701154185050 : check e701154185050 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154185066 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 2) (.var 1))) (.var 0))))))) (.var 0)))
theorem wire_e701154185066 : Closed e701154185066 ∧ code e701154185066 = 9497247207274 := by decide
theorem cert_e701154185066 : check e701154185066 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154185130 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 3) (.var 0))) (.var 0))))))) (.var 0)))
theorem wire_e701154185130 : Closed e701154185130 ∧ code e701154185130 = 9497247207338 := by decide
theorem cert_e701154185130 : check e701154185130 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154186106 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 3)))))))) (.var 0)))
theorem wire_e701154186106 : Closed e701154186106 ∧ code e701154186106 = 9497247208314 := by decide
theorem cert_e701154186106 : check e701154186106 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154186170 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 2)))))))) (.var 0)))
theorem wire_e701154186170 : Closed e701154186170 ∧ code e701154186170 = 9497247208378 := by decide
theorem cert_e701154186170 : check e701154186170 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154186202 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 2) (.var 1)))))))) (.var 0)))
theorem wire_e701154186202 : Closed e701154186202 ∧ code e701154186202 = 9497247208410 := by decide
theorem cert_e701154186202 : check e701154186202 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154186218 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 3) (.var 0)))))))) (.var 0)))
theorem wire_e701154186218 : Closed e701154186218 ∧ code e701154186218 = 9497247208426 := by decide
theorem cert_e701154186218 : check e701154186218 [[.under,.left],[.under,.left]] .chain = true := by decide
def e701154187706 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 2)))))))) (.var 0)))
theorem wire_e701154187706 : Closed e701154187706 ∧ code e701154187706 = 9497247209914 := by decide
theorem cert_e701154187706 : check e701154187706 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154187754 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 2) (.var 0)))))))) (.var 0)))
theorem wire_e701154187754 : Closed e701154187754 ∧ code e701154187754 = 9497247209962 := by decide
theorem cert_e701154187754 : check e701154187754 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154188506 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 0) (.var 1)))))))) (.var 0)))
theorem wire_e701154188506 : Closed e701154188506 ∧ code e701154188506 = 9497247210714 := by decide
theorem cert_e701154188506 : check e701154188506 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154188522 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 2)) (.app (.var 1) (.var 0)))))))) (.var 0)))
theorem wire_e701154188522 : Closed e701154188522 ∧ code e701154188522 = 9497247210730 := by decide
theorem cert_e701154188522 : check e701154188522 [[.under,.left],[.under,.left]] .smaller = true := by decide
def e701154188906 : Term := (.lam (.app (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.lam (.app (.app (.var 2) (.var 3)) (.app (.var 0) (.var 0)))))))) (.var 0)))
theorem wire_e701154188906 : Closed e701154188906 ∧ code e701154188906 = 9497247211114 := by decide
theorem cert_e701154188906 : check e701154188906 [[.under,.left],[.under,.left]] .chain = true := by decide
end Blc.Floor43
