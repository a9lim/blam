import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e565643890486 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e565643890486 : Closed e565643890486 ∧ code e565643890486 = 9361736912694 := by decide
theorem cert_e565643890486 : checkPay e565643890486 [[.left],[.left],[]] 0 [] = true := by decide
def e565643890490 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e565643890490 : Closed e565643890490 ∧ code e565643890490 = 9361736912698 := by decide
theorem cert_e565643890490 : checkPay e565643890490 [[.left],[.left],[]] 0 [] = true := by decide
def e565643896238 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2)))))))))
theorem wire_e565643896238 : Closed e565643896238 ∧ code e565643896238 = 9361736918446 := by decide
theorem cert_e565643896238 : checkPay e565643896238 [[.left],[.left],[]] 0 [] = true := by decide
def e565643896250 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0)))))))))
theorem wire_e565643896250 : Closed e565643896250 ∧ code e565643896250 = 9361736918458 := by decide
theorem cert_e565643896250 : checkPay e565643896250 [[.left],[.left],[]] 0 [] = true := by decide
def e565643896298 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0)))))))))
theorem wire_e565643896298 : Closed e565643896298 ∧ code e565643896298 = 9361736918506 := by decide
theorem cert_e565643896298 : checkPay e565643896298 [[.left],[.left],[]] 0 [] = true := by decide
def e565643896430 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2))))))))))
theorem wire_e565643896430 : Closed e565643896430 ∧ code e565643896430 = 9361736918638 := by decide
theorem cert_e565643896430 : checkPay e565643896430 [[.left],[.left],[]] 0 [] = true := by decide
def e565643896442 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0))))))))))
theorem wire_e565643896442 : Closed e565643896442 ∧ code e565643896442 = 9361736918650 := by decide
theorem cert_e565643896442 : checkPay e565643896442 [[.left],[.left],[]] 0 [] = true := by decide
def e565643896730 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0))))))))))
theorem wire_e565643896730 : Closed e565643896730 ∧ code e565643896730 = 9361736918938 := by decide
theorem cert_e565643896730 : checkPay e565643896730 [[.left],[.left],[]] 0 [] = true := by decide
def e565643899606 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1)))))))))
theorem wire_e565643899606 : Closed e565643899606 ∧ code e565643899606 = 9361736921814 := by decide
theorem cert_e565643899606 : checkPay e565643899606 [[.left],[.left],[]] 0 [] = true := by decide
def e565643899610 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0)))))))))
theorem wire_e565643899610 : Closed e565643899610 ∧ code e565643899610 = 9361736921818 := by decide
theorem cert_e565643899610 : checkPay e565643899610 [[.left],[.left],[]] 0 [] = true := by decide
def e565643899626 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0)))))))))
theorem wire_e565643899626 : Closed e565643899626 ∧ code e565643899626 = 9361736921834 := by decide
theorem cert_e565643899626 : checkPay e565643899626 [[.left],[.left],[]] 0 [] = true := by decide
def e565643899702 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1))))))))))
theorem wire_e565643899702 : Closed e565643899702 ∧ code e565643899702 = 9361736921910 := by decide
theorem cert_e565643899702 : checkPay e565643899702 [[.left],[.left],[]] 0 [] = true := by decide
def e565643899706 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0))))))))))
theorem wire_e565643899706 : Closed e565643899706 ∧ code e565643899706 = 9361736921914 := by decide
theorem cert_e565643899706 : checkPay e565643899706 [[.left],[.left],[]] 0 [] = true := by decide
def e565643899802 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0))))))))))
theorem wire_e565643899802 : Closed e565643899802 ∧ code e565643899802 = 9361736922010 := by decide
theorem cert_e565643899802 : checkPay e565643899802 [[.left],[.left],[]] 0 [] = true := by decide
def e565644036974 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e565644036974 : Closed e565644036974 ∧ code e565644036974 = 9361737059182 := by decide
theorem cert_e565644036974 : checkPay e565644036974 [[.left],[.left],[]] 0 [] = true := by decide
def e565644036982 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e565644036982 : Closed e565644036982 ∧ code e565644036982 = 9361737059190 := by decide
theorem cert_e565644036982 : checkPay e565644036982 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037038 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e565644037038 : Closed e565644037038 ∧ code e565644037038 = 9361737059246 := by decide
theorem cert_e565644037038 : checkPay e565644037038 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037050 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e565644037050 : Closed e565644037050 ∧ code e565644037050 = 9361737059258 := by decide
theorem cert_e565644037050 : checkPay e565644037050 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037078 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e565644037078 : Closed e565644037078 ∧ code e565644037078 = 9361737059286 := by decide
theorem cert_e565644037078 : checkPay e565644037078 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037082 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e565644037082 : Closed e565644037082 ∧ code e565644037082 = 9361737059290 := by decide
theorem cert_e565644037082 : checkPay e565644037082 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037358 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e565644037358 : Closed e565644037358 ∧ code e565644037358 = 9361737059566 := by decide
theorem cert_e565644037358 : checkPay e565644037358 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037366 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e565644037366 : Closed e565644037366 ∧ code e565644037366 = 9361737059574 := by decide
theorem cert_e565644037366 : checkPay e565644037366 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037742 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e565644037742 : Closed e565644037742 ∧ code e565644037742 = 9361737059950 := by decide
theorem cert_e565644037742 : checkPay e565644037742 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037754 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e565644037754 : Closed e565644037754 ∧ code e565644037754 = 9361737059962 := by decide
theorem cert_e565644037754 : checkPay e565644037754 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037942 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e565644037942 : Closed e565644037942 ∧ code e565644037942 = 9361737060150 := by decide
theorem cert_e565644037942 : checkPay e565644037942 [[.left],[.left],[]] 0 [] = true := by decide
def e565644037946 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e565644037946 : Closed e565644037946 ∧ code e565644037946 = 9361737060154 := by decide
theorem cert_e565644037946 : checkPay e565644037946 [[.left],[.left],[]] 0 [] = true := by decide
def e565644626798 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2)))))))))
theorem wire_e565644626798 : Closed e565644626798 ∧ code e565644626798 = 9361737649006 := by decide
theorem cert_e565644626798 : checkPay e565644626798 [[.left],[.left],[]] 0 [] = true := by decide
def e565644626806 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1)))))))))
theorem wire_e565644626806 : Closed e565644626806 ∧ code e565644626806 = 9361737649014 := by decide
theorem cert_e565644626806 : checkPay e565644626806 [[.left],[.left],[]] 0 [] = true := by decide
def e565644626862 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2)))))))))
theorem wire_e565644626862 : Closed e565644626862 ∧ code e565644626862 = 9361737649070 := by decide
theorem cert_e565644626862 : checkPay e565644626862 [[.left],[.left],[]] 0 [] = true := by decide
def e565644626874 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0)))))))))
theorem wire_e565644626874 : Closed e565644626874 ∧ code e565644626874 = 9361737649082 := by decide
theorem cert_e565644626874 : checkPay e565644626874 [[.left],[.left],[]] 0 [] = true := by decide
def e565644626902 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1)))))))))
theorem wire_e565644626902 : Closed e565644626902 ∧ code e565644626902 = 9361737649110 := by decide
theorem cert_e565644626902 : checkPay e565644626902 [[.left],[.left],[]] 0 [] = true := by decide
def e565644626906 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0)))))))))
theorem wire_e565644626906 : Closed e565644626906 ∧ code e565644626906 = 9361737649114 := by decide
theorem cert_e565644626906 : checkPay e565644626906 [[.left],[.left],[]] 0 [] = true := by decide
def e565644627182 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2))))))))))
theorem wire_e565644627182 : Closed e565644627182 ∧ code e565644627182 = 9361737649390 := by decide
theorem cert_e565644627182 : checkPay e565644627182 [[.left],[.left],[]] 0 [] = true := by decide
def e565644627190 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1))))))))))
theorem wire_e565644627190 : Closed e565644627190 ∧ code e565644627190 = 9361737649398 := by decide
theorem cert_e565644627190 : checkPay e565644627190 [[.left],[.left],[]] 0 [] = true := by decide
def e565644627566 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2))))))))))
theorem wire_e565644627566 : Closed e565644627566 ∧ code e565644627566 = 9361737649774 := by decide
theorem cert_e565644627566 : checkPay e565644627566 [[.left],[.left],[]] 0 [] = true := by decide
def e565644627578 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0))))))))))
theorem wire_e565644627578 : Closed e565644627578 ∧ code e565644627578 = 9361737649786 := by decide
theorem cert_e565644627578 : checkPay e565644627578 [[.left],[.left],[]] 0 [] = true := by decide
def e565644627766 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1))))))))))
theorem wire_e565644627766 : Closed e565644627766 ∧ code e565644627766 = 9361737649974 := by decide
theorem cert_e565644627766 : checkPay e565644627766 [[.left],[.left],[]] 0 [] = true := by decide
def e565644627770 : Term := (.lam (.app (.lam (.lam (.app (.var 1) (.var 1)))) (.app (.var 0) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0))))))))))
theorem wire_e565644627770 : Closed e565644627770 ∧ code e565644627770 = 9361737649978 := by decide
theorem cert_e565644627770 : checkPay e565644627770 [[.left],[.left],[]] 0 [] = true := by decide
def e597048403482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597048403482 : Closed e597048403482 ∧ code e597048403482 = 9393141425690 := by decide
theorem cert_e597048403482 : check e597048403482 [[.under]] .width = true := by decide
def e597048406214 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597048406214 : Closed e597048406214 ∧ code e597048406214 = 9393141428422 := by decide
theorem cert_e597048406214 : check e597048406214 [[.under]] .width = true := by decide
def e597048534554 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597048534554 : Closed e597048534554 ∧ code e597048534554 = 9393141556762 := by decide
theorem cert_e597048534554 : check e597048534554 [[.under]] .width = true := by decide
def e597048537286 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597048537286 : Closed e597048537286 ∧ code e597048537286 = 9393141559494 := by decide
theorem cert_e597048537286 : check e597048537286 [[.under]] .width = true := by decide
def e597049452058 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597049452058 : Closed e597049452058 ∧ code e597049452058 = 9393142474266 := by decide
theorem cert_e597049452058 : check e597049452058 [[.under]] .width = true := by decide
def e597049454790 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597049454790 : Closed e597049454790 ∧ code e597049454790 = 9393142476998 := by decide
theorem cert_e597049454790 : check e597049454790 [[.under]] .width = true := by decide
def e597049648666 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597049648666 : Closed e597049648666 ∧ code e597049648666 = 9393142670874 := by decide
theorem cert_e597049648666 : check e597049648666 [[.under]] .width = true := by decide
def e597049651398 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597049651398 : Closed e597049651398 ∧ code e597049651398 = 9393142673606 := by decide
theorem cert_e597049651398 : check e597049651398 [[.under]] .width = true := by decide
def e597050107418 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597050107418 : Closed e597050107418 ∧ code e597050107418 = 9393143129626 := by decide
theorem cert_e597050107418 : check e597050107418 [[.under]] .width = true := by decide
def e597050110150 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597050110150 : Closed e597050110150 ∧ code e597050110150 = 9393143132358 := by decide
theorem cert_e597050110150 : check e597050110150 [[.under]] .width = true := by decide
def e597050172954 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597050172954 : Closed e597050172954 ∧ code e597050172954 = 9393143195162 := by decide
theorem cert_e597050172954 : check e597050172954 [[.under]] .width = true := by decide
def e597050175686 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597050175686 : Closed e597050175686 ∧ code e597050175686 = 9393143197894 := by decide
theorem cert_e597050175686 : check e597050175686 [[.under]] .width = true := by decide
def e597054694938 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597054694938 : Closed e597054694938 ∧ code e597054694938 = 9393147717146 := by decide
theorem cert_e597054694938 : check e597054694938 [[.under]] .width = true := by decide
def e597054697670 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597054697670 : Closed e597054697670 ∧ code e597054697670 = 9393147719878 := by decide
theorem cert_e597054697670 : check e597054697670 [[.under]] .width = true := by decide
def e597054826010 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597054826010 : Closed e597054826010 ∧ code e597054826010 = 9393147848218 := by decide
theorem cert_e597054826010 : check e597054826010 [[.under]] .width = true := by decide
def e597054828742 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597054828742 : Closed e597054828742 ∧ code e597054828742 = 9393147850950 := by decide
theorem cert_e597054828742 : check e597054828742 [[.under]] .width = true := by decide
def e597060986394 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597060986394 : Closed e597060986394 ∧ code e597060986394 = 9393154008602 := by decide
theorem cert_e597060986394 : check e597060986394 [[.under]] .width = true := by decide
def e597060989126 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597060989126 : Closed e597060989126 ∧ code e597060989126 = 9393154011334 := by decide
theorem cert_e597060989126 : check e597060989126 [[.under]] .width = true := by decide
def e597061183002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597061183002 : Closed e597061183002 ∧ code e597061183002 = 9393154205210 := by decide
theorem cert_e597061183002 : check e597061183002 [[.under]] .width = true := by decide
def e597061185734 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597061185734 : Closed e597061185734 ∧ code e597061185734 = 9393154207942 := by decide
theorem cert_e597061185734 : check e597061185734 [[.under]] .width = true := by decide
def e597064263194 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597064263194 : Closed e597064263194 ∧ code e597064263194 = 9393157285402 := by decide
theorem cert_e597064263194 : check e597064263194 [[.under]] .width = true := by decide
def e597064265926 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597064265926 : Closed e597064265926 ∧ code e597064265926 = 9393157288134 := by decide
theorem cert_e597064265926 : check e597064265926 [[.under]] .width = true := by decide
def e597064328730 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 0))) (.app (.var 0) (.lam (.app (.var 0) (.var 0))))))
theorem wire_e597064328730 : Closed e597064328730 ∧ code e597064328730 = 9393157350938 := by decide
theorem cert_e597064328730 : check e597064328730 [[.under]] .width = true := by decide
def e597064331462 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))) (.var 1))) (.lam (.app (.var 0) (.lam (.var 1))))))
theorem wire_e597064331462 : Closed e597064331462 ∧ code e597064331462 = 9393157353670 := by decide
theorem cert_e597064331462 : check e597064331462 [[.under]] .width = true := by decide
def e597453483374 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e597453483374 : Closed e597453483374 ∧ code e597453483374 = 9393546505582 := by decide
theorem cert_e597453483374 : check e597453483374 [[.under],[.under,.left]] .chain = true := by decide
def e597453483382 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e597453483382 : Closed e597453483382 ∧ code e597453483382 = 9393546505590 := by decide
theorem cert_e597453483382 : check e597453483382 [[.under],[.under,.left]] .chain = true := by decide
def e597453483438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e597453483438 : Closed e597453483438 ∧ code e597453483438 = 9393546505646 := by decide
theorem cert_e597453483438 : check e597453483438 [[.under],[.under,.left]] .chain = true := by decide
def e597453483450 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e597453483450 : Closed e597453483450 ∧ code e597453483450 = 9393546505658 := by decide
theorem cert_e597453483450 : check e597453483450 [[.under],[.under,.left]] .chain = true := by decide
def e597453483478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e597453483478 : Closed e597453483478 ∧ code e597453483478 = 9393546505686 := by decide
theorem cert_e597453483478 : check e597453483478 [[.under],[.under,.left]] .chain = true := by decide
def e597453483482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e597453483482 : Closed e597453483482 ∧ code e597453483482 = 9393546505690 := by decide
theorem cert_e597453483482 : check e597453483482 [[.under],[.under,.left]] .chain = true := by decide
def e597453483694 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e597453483694 : Closed e597453483694 ∧ code e597453483694 = 9393546505902 := by decide
theorem cert_e597453483694 : check e597453483694 [[.under],[.under,.left]] .chain = true := by decide
def e597453483706 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e597453483706 : Closed e597453483706 ∧ code e597453483706 = 9393546505914 := by decide
theorem cert_e597453483706 : check e597453483706 [[.under],[.under,.left]] .chain = true := by decide
def e597453483754 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e597453483754 : Closed e597453483754 ∧ code e597453483754 = 9393546505962 := by decide
theorem cert_e597453483754 : check e597453483754 [[.under],[.under,.left]] .chain = true := by decide
def e597453483862 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e597453483862 : Closed e597453483862 ∧ code e597453483862 = 9393546506070 := by decide
theorem cert_e597453483862 : check e597453483862 [[.under],[.under,.left]] .chain = true := by decide
def e597453483866 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e597453483866 : Closed e597453483866 ∧ code e597453483866 = 9393546506074 := by decide
theorem cert_e597453483866 : check e597453483866 [[.under],[.under,.left]] .chain = true := by decide
def e597453483882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e597453483882 : Closed e597453483882 ∧ code e597453483882 = 9393546506090 := by decide
theorem cert_e597453483882 : check e597453483882 [[.under],[.under,.left]] .chain = true := by decide
def e597453484910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e597453484910 : Closed e597453484910 ∧ code e597453484910 = 9393546507118 := by decide
theorem cert_e597453484910 : check e597453484910 [[.under],[.under,.left]] .chain = true := by decide
def e597453484918 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e597453484918 : Closed e597453484918 ∧ code e597453484918 = 9393546507126 := by decide
theorem cert_e597453484918 : check e597453484918 [[.under],[.under,.left]] .chain = true := by decide
def e597453484974 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 0))) (.var 2)))))))
theorem wire_e597453484974 : Closed e597453484974 ∧ code e597453484974 = 9393546507182 := by decide
theorem cert_e597453484974 : check e597453484974 [[.under],[.under,.left]] .chain = true := by decide
def e597453484986 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)))))))
theorem wire_e597453484986 : Closed e597453484986 ∧ code e597453484986 = 9393546507194 := by decide
theorem cert_e597453484986 : check e597453484986 [[.under],[.under,.left]] .chain = true := by decide
def e597453485014 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)))))))
theorem wire_e597453485014 : Closed e597453485014 ∧ code e597453485014 = 9393546507222 := by decide
theorem cert_e597453485014 : check e597453485014 [[.under],[.under,.left]] .chain = true := by decide
def e597453485018 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)))))))
theorem wire_e597453485018 : Closed e597453485018 ∧ code e597453485018 = 9393546507226 := by decide
theorem cert_e597453485018 : check e597453485018 [[.under],[.under,.left]] .chain = true := by decide
def e597453485294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))))))))
theorem wire_e597453485294 : Closed e597453485294 ∧ code e597453485294 = 9393546507502 := by decide
theorem cert_e597453485294 : check e597453485294 [[.under],[.under,.left]] .chain = true := by decide
def e597453485302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))))))))
theorem wire_e597453485302 : Closed e597453485302 ∧ code e597453485302 = 9393546507510 := by decide
theorem cert_e597453485302 : check e597453485302 [[.under],[.under,.left]] .chain = true := by decide
def e597453485678 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 0) (.var 2))))))))
theorem wire_e597453485678 : Closed e597453485678 ∧ code e597453485678 = 9393546507886 := by decide
theorem cert_e597453485678 : check e597453485678 [[.under],[.under,.left]] .chain = true := by decide
def e597453485690 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 1)) (.app (.var 2) (.var 0))))))))
theorem wire_e597453485690 : Closed e597453485690 ∧ code e597453485690 = 9393546507898 := by decide
theorem cert_e597453485690 : check e597453485690 [[.under],[.under,.left]] .chain = true := by decide
def e597453485878 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 0) (.var 1))))))))
theorem wire_e597453485878 : Closed e597453485878 ∧ code e597453485878 = 9393546508086 := by decide
theorem cert_e597453485878 : check e597453485878 [[.under],[.under,.left]] .chain = true := by decide
def e597453485882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 0) (.var 2)) (.app (.var 1) (.var 0))))))))
theorem wire_e597453485882 : Closed e597453485882 ∧ code e597453485882 = 9393546508090 := by decide
theorem cert_e597453485882 : check e597453485882 [[.under],[.under,.left]] .chain = true := by decide
def e597453486510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 0))) (.var 2)))))))
theorem wire_e597453486510 : Closed e597453486510 ∧ code e597453486510 = 9393546508718 := by decide
theorem cert_e597453486510 : check e597453486510 [[.under],[.under,.left]] .chain = true := by decide
def e597453486522 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 0) (.var 2))) (.var 0)))))))
theorem wire_e597453486522 : Closed e597453486522 ∧ code e597453486522 = 9393546508730 := by decide
theorem cert_e597453486522 : check e597453486522 [[.under],[.under,.left]] .chain = true := by decide
def e597453486570 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.app (.var 2) (.var 0))) (.var 0)))))))
theorem wire_e597453486570 : Closed e597453486570 ∧ code e597453486570 = 9393546508778 := by decide
theorem cert_e597453486570 : check e597453486570 [[.under],[.under,.left]] .chain = true := by decide
def e597453486702 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 0) (.var 2))))))))
theorem wire_e597453486702 : Closed e597453486702 ∧ code e597453486702 = 9393546508910 := by decide
theorem cert_e597453486702 : check e597453486702 [[.under],[.under,.left]] .chain = true := by decide
def e597453486714 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 0)) (.app (.var 2) (.var 0))))))))
theorem wire_e597453486714 : Closed e597453486714 ∧ code e597453486714 = 9393546508922 := by decide
theorem cert_e597453486714 : check e597453486714 [[.under],[.under,.left]] .chain = true := by decide
def e597453487002 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 1) (.var 2)) (.app (.var 0) (.var 0))))))))
theorem wire_e597453487002 : Closed e597453487002 ∧ code e597453487002 = 9393546509210 := by decide
theorem cert_e597453487002 : check e597453487002 [[.under],[.under,.left]] .chain = true := by decide
def e597453487318 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 0))) (.var 1)))))))
theorem wire_e597453487318 : Closed e597453487318 ∧ code e597453487318 = 9393546509526 := by decide
theorem cert_e597453487318 : check e597453487318 [[.under],[.under,.left]] .chain = true := by decide
def e597453487322 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 0) (.var 1))) (.var 0)))))))
theorem wire_e597453487322 : Closed e597453487322 ∧ code e597453487322 = 9393546509530 := by decide
theorem cert_e597453487322 : check e597453487322 [[.under],[.under,.left]] .chain = true := by decide
def e597453487338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.app (.var 1) (.var 0))) (.var 0)))))))
theorem wire_e597453487338 : Closed e597453487338 ∧ code e597453487338 = 9393546509546 := by decide
theorem cert_e597453487338 : check e597453487338 [[.under],[.under,.left]] .chain = true := by decide
def e597453487414 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 0) (.var 1))))))))
theorem wire_e597453487414 : Closed e597453487414 ∧ code e597453487414 = 9393546509622 := by decide
theorem cert_e597453487414 : check e597453487414 [[.under],[.under,.left]] .chain = true := by decide
def e597453487418 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 0)) (.app (.var 1) (.var 0))))))))
theorem wire_e597453487418 : Closed e597453487418 ∧ code e597453487418 = 9393546509626 := by decide
theorem cert_e597453487418 : check e597453487418 [[.under],[.under,.left]] .chain = true := by decide
def e597453487514 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.app (.var 2) (.var 1)) (.app (.var 0) (.var 0))))))))
theorem wire_e597453487514 : Closed e597453487514 ∧ code e597453487514 = 9393546509722 := by decide
theorem cert_e597453487514 : check e597453487514 [[.under],[.under,.left]] .chain = true := by decide
def e597453491054 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597453491054 : Closed e597453491054 ∧ code e597453491054 = 9393546513262 := by decide
theorem cert_e597453491054 : check e597453491054 [[.under],[.under,.left]] .chain = true := by decide
def e597453491062 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597453491062 : Closed e597453491062 ∧ code e597453491062 = 9393546513270 := by decide
theorem cert_e597453491062 : check e597453491062 [[.under],[.under,.left]] .chain = true := by decide
def e597453491118 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597453491118 : Closed e597453491118 ∧ code e597453491118 = 9393546513326 := by decide
theorem cert_e597453491118 : check e597453491118 [[.under],[.under,.left]] .chain = true := by decide
def e597453491130 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597453491130 : Closed e597453491130 ∧ code e597453491130 = 9393546513338 := by decide
theorem cert_e597453491130 : check e597453491130 [[.under],[.under,.left]] .chain = true := by decide
def e597453491158 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597453491158 : Closed e597453491158 ∧ code e597453491158 = 9393546513366 := by decide
theorem cert_e597453491158 : check e597453491158 [[.under],[.under,.left]] .chain = true := by decide
def e597453491162 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597453491162 : Closed e597453491162 ∧ code e597453491162 = 9393546513370 := by decide
theorem cert_e597453491162 : check e597453491162 [[.under],[.under,.left]] .chain = true := by decide
def e597453491438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597453491438 : Closed e597453491438 ∧ code e597453491438 = 9393546513646 := by decide
theorem cert_e597453491438 : check e597453491438 [[.under],[.under,.left]] .chain = true := by decide
def e597453491446 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597453491446 : Closed e597453491446 ∧ code e597453491446 = 9393546513654 := by decide
theorem cert_e597453491446 : check e597453491446 [[.under],[.under,.left]] .chain = true := by decide
def e597453491822 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597453491822 : Closed e597453491822 ∧ code e597453491822 = 9393546514030 := by decide
theorem cert_e597453491822 : check e597453491822 [[.under],[.under,.left]] .chain = true := by decide
def e597453491834 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597453491834 : Closed e597453491834 ∧ code e597453491834 = 9393546514042 := by decide
theorem cert_e597453491834 : check e597453491834 [[.under],[.under,.left]] .chain = true := by decide
def e597453492022 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597453492022 : Closed e597453492022 ∧ code e597453492022 = 9393546514230 := by decide
theorem cert_e597453492022 : check e597453492022 [[.under],[.under,.left]] .chain = true := by decide
def e597453492026 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 0) (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597453492026 : Closed e597453492026 ∧ code e597453492026 = 9393546514234 := by decide
theorem cert_e597453492026 : check e597453492026 [[.under],[.under,.left]] .chain = true := by decide
def e597453497774 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 0)) (.var 2))))))))
theorem wire_e597453497774 : Closed e597453497774 ∧ code e597453497774 = 9393546519982 := by decide
theorem cert_e597453497774 : check e597453497774 [[.under],[.under,.left]] .chain = true := by decide
def e597453497786 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 0) (.var 2)) (.var 0))))))))
theorem wire_e597453497786 : Closed e597453497786 ∧ code e597453497786 = 9393546519994 := by decide
theorem cert_e597453497786 : check e597453497786 [[.under],[.under,.left]] .chain = true := by decide
def e597453497834 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.app (.var 2) (.var 0)) (.var 0))))))))
theorem wire_e597453497834 : Closed e597453497834 ∧ code e597453497834 = 9393546520042 := by decide
theorem cert_e597453497834 : check e597453497834 [[.under],[.under,.left]] .chain = true := by decide
def e597453497966 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 0) (.var 2)))))))))
theorem wire_e597453497966 : Closed e597453497966 ∧ code e597453497966 = 9393546520174 := by decide
theorem cert_e597453497966 : check e597453497966 [[.under],[.under,.left]] .chain = true := by decide
def e597453497978 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 0) (.app (.var 2) (.var 0)))))))))
theorem wire_e597453497978 : Closed e597453497978 ∧ code e597453497978 = 9393546520186 := by decide
theorem cert_e597453497978 : check e597453497978 [[.under],[.under,.left]] .chain = true := by decide
def e597453498266 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 1) (.app (.var 2) (.app (.var 0) (.var 0)))))))))
theorem wire_e597453498266 : Closed e597453498266 ∧ code e597453498266 = 9393546520474 := by decide
theorem cert_e597453498266 : check e597453498266 [[.under],[.under,.left]] .chain = true := by decide
def e597453501142 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 0)) (.var 1))))))))
theorem wire_e597453501142 : Closed e597453501142 ∧ code e597453501142 = 9393546523350 := by decide
theorem cert_e597453501142 : check e597453501142 [[.under],[.under,.left]] .chain = true := by decide
def e597453501146 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 0) (.var 1)) (.var 0))))))))
theorem wire_e597453501146 : Closed e597453501146 ∧ code e597453501146 = 9393546523354 := by decide
theorem cert_e597453501146 : check e597453501146 [[.under],[.under,.left]] .chain = true := by decide
def e597453501162 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.app (.var 1) (.var 0)) (.var 0))))))))
theorem wire_e597453501162 : Closed e597453501162 ∧ code e597453501162 = 9393546523370 := by decide
theorem cert_e597453501162 : check e597453501162 [[.under],[.under,.left]] .chain = true := by decide
def e597453501238 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 0) (.var 1)))))))))
theorem wire_e597453501238 : Closed e597453501238 ∧ code e597453501238 = 9393546523446 := by decide
theorem cert_e597453501238 : check e597453501238 [[.under],[.under,.left]] .chain = true := by decide
def e597453501242 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 0) (.app (.var 1) (.var 0)))))))))
theorem wire_e597453501242 : Closed e597453501242 ∧ code e597453501242 = 9393546523450 := by decide
theorem cert_e597453501242 : check e597453501242 [[.under],[.under,.left]] .chain = true := by decide
def e597453501338 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.lam (.app (.var 2) (.app (.var 1) (.app (.var 0) (.var 0)))))))))
theorem wire_e597453501338 : Closed e597453501338 ∧ code e597453501338 = 9393546523546 := by decide
theorem cert_e597453501338 : check e597453501338 [[.under],[.under,.left]] .chain = true := by decide
def e597453638510 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597453638510 : Closed e597453638510 ∧ code e597453638510 = 9393546660718 := by decide
theorem cert_e597453638510 : check e597453638510 [[.under],[.under,.left]] .chain = true := by decide
def e597453638518 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597453638518 : Closed e597453638518 ∧ code e597453638518 = 9393546660726 := by decide
theorem cert_e597453638518 : check e597453638518 [[.under],[.under,.left]] .chain = true := by decide
def e597453638574 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597453638574 : Closed e597453638574 ∧ code e597453638574 = 9393546660782 := by decide
theorem cert_e597453638574 : check e597453638574 [[.under],[.under,.left]] .chain = true := by decide
def e597453638586 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597453638586 : Closed e597453638586 ∧ code e597453638586 = 9393546660794 := by decide
theorem cert_e597453638586 : check e597453638586 [[.under],[.under,.left]] .chain = true := by decide
def e597453638614 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597453638614 : Closed e597453638614 ∧ code e597453638614 = 9393546660822 := by decide
theorem cert_e597453638614 : check e597453638614 [[.under],[.under,.left]] .chain = true := by decide
def e597453638618 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597453638618 : Closed e597453638618 ∧ code e597453638618 = 9393546660826 := by decide
theorem cert_e597453638618 : check e597453638618 [[.under],[.under,.left]] .chain = true := by decide
def e597453638894 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597453638894 : Closed e597453638894 ∧ code e597453638894 = 9393546661102 := by decide
theorem cert_e597453638894 : check e597453638894 [[.under],[.under,.left]] .chain = true := by decide
def e597453638902 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597453638902 : Closed e597453638902 ∧ code e597453638902 = 9393546661110 := by decide
theorem cert_e597453638902 : check e597453638902 [[.under],[.under,.left]] .chain = true := by decide
def e597453639278 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597453639278 : Closed e597453639278 ∧ code e597453639278 = 9393546661486 := by decide
theorem cert_e597453639278 : check e597453639278 [[.under],[.under,.left]] .chain = true := by decide
def e597453639290 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597453639290 : Closed e597453639290 ∧ code e597453639290 = 9393546661498 := by decide
theorem cert_e597453639290 : check e597453639290 [[.under],[.under,.left]] .chain = true := by decide
def e597453639478 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597453639478 : Closed e597453639478 ∧ code e597453639478 = 9393546661686 := by decide
theorem cert_e597453639478 : check e597453639478 [[.under],[.under,.left]] .chain = true := by decide
def e597453639482 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.lam (.app (.var 0) (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597453639482 : Closed e597453639482 ∧ code e597453639482 = 9393546661690 := by decide
theorem cert_e597453639482 : check e597453639482 [[.under],[.under,.left]] .chain = true := by decide
def e597454228334 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 1)) (.var 2))))))))
theorem wire_e597454228334 : Closed e597454228334 ∧ code e597454228334 = 9393547250542 := by decide
theorem cert_e597454228334 : check e597454228334 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454228342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 0) (.var 2)) (.var 1))))))))
theorem wire_e597454228342 : Closed e597454228342 ∧ code e597454228342 = 9393547250550 := by decide
theorem cert_e597454228342 : check e597454228342 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454228398 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 0)) (.var 2))))))))
theorem wire_e597454228398 : Closed e597454228398 ∧ code e597454228398 = 9393547250606 := by decide
theorem cert_e597454228398 : check e597454228398 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454228410 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 1) (.var 2)) (.var 0))))))))
theorem wire_e597454228410 : Closed e597454228410 ∧ code e597454228410 = 9393547250618 := by decide
theorem cert_e597454228410 : check e597454228410 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454228438 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 0)) (.var 1))))))))
theorem wire_e597454228438 : Closed e597454228438 ∧ code e597454228438 = 9393547250646 := by decide
theorem cert_e597454228438 : check e597454228438 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454228442 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.app (.var 2) (.var 1)) (.var 0))))))))
theorem wire_e597454228442 : Closed e597454228442 ∧ code e597454228442 = 9393547250650 := by decide
theorem cert_e597454228442 : check e597454228442 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454228718 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 1) (.var 2)))))))))
theorem wire_e597454228718 : Closed e597454228718 ∧ code e597454228718 = 9393547250926 := by decide
theorem cert_e597454228718 : check e597454228718 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454228726 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 0) (.app (.var 2) (.var 1)))))))))
theorem wire_e597454228726 : Closed e597454228726 ∧ code e597454228726 = 9393547250934 := by decide
theorem cert_e597454228726 : check e597454228726 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454229102 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 0) (.var 2)))))))))
theorem wire_e597454229102 : Closed e597454229102 ∧ code e597454229102 = 9393547251310 := by decide
theorem cert_e597454229102 : check e597454229102 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454229114 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 1) (.app (.var 2) (.var 0)))))))))
theorem wire_e597454229114 : Closed e597454229114 ∧ code e597454229114 = 9393547251322 := by decide
theorem cert_e597454229114 : check e597454229114 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454229302 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 0) (.var 1)))))))))
theorem wire_e597454229302 : Closed e597454229302 ∧ code e597454229302 = 9393547251510 := by decide
theorem cert_e597454229302 : check e597454229302 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597454229306 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 1))) (.var 1))) (.lam (.app (.var 0) (.lam (.lam (.app (.var 2) (.app (.var 1) (.var 0)))))))))
theorem wire_e597454229306 : Closed e597454229306 ∧ code e597454229306 = 9393547251514 := by decide
theorem cert_e597454229306 : check e597454229306 [[.under],[.under,.left],[.under,.left]] .smaller = true := by decide
def e597487037806 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)))))))
theorem wire_e597487037806 : Closed e597487037806 ∧ code e597487037806 = 9393580060014 := by decide
theorem cert_e597487037806 : check e597487037806 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487037814 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.var 1)))))))
theorem wire_e597487037814 : Closed e597487037814 ∧ code e597487037814 = 9393580060022 := by decide
theorem cert_e597487037814 : check e597487037814 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487037870 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 0)) (.var 2)))))))
theorem wire_e597487037870 : Closed e597487037870 ∧ code e597487037870 = 9393580060078 := by decide
theorem cert_e597487037870 : check e597487037870 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487037882 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 1)) (.var 2)) (.var 0)))))))
theorem wire_e597487037882 : Closed e597487037882 ∧ code e597487037882 = 9393580060090 := by decide
theorem cert_e597487037882 : check e597487037882 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487037910 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 0)) (.var 1)))))))
theorem wire_e597487037910 : Closed e597487037910 ∧ code e597487037910 = 9393580060118 := by decide
theorem cert_e597487037910 : check e597487037910 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487037914 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 0) (.var 2)) (.var 1)) (.var 0)))))))
theorem wire_e597487037914 : Closed e597487037914 ∧ code e597487037914 = 9393580060122 := by decide
theorem cert_e597487037914 : check e597487037914 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487038126 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 0)) (.var 2)))))))
theorem wire_e597487038126 : Closed e597487038126 ∧ code e597487038126 = 9393580060334 := by decide
theorem cert_e597487038126 : check e597487038126 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487038138 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 0)) (.var 2)) (.var 0)))))))
theorem wire_e597487038138 : Closed e597487038138 ∧ code e597487038138 = 9393580060346 := by decide
theorem cert_e597487038138 : check e597487038138 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487038186 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 1) (.var 2)) (.var 0)) (.var 0)))))))
theorem wire_e597487038186 : Closed e597487038186 ∧ code e597487038186 = 9393580060394 := by decide
theorem cert_e597487038186 : check e597487038186 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487038294 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 0)) (.var 1)))))))
theorem wire_e597487038294 : Closed e597487038294 ∧ code e597487038294 = 9393580060502 := by decide
theorem cert_e597487038294 : check e597487038294 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487038298 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 0)) (.var 1)) (.var 0)))))))
theorem wire_e597487038298 : Closed e597487038298 ∧ code e597487038298 = 9393580060506 := by decide
theorem cert_e597487038298 : check e597487038298 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487038314 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.var 2) (.var 1)) (.var 0)) (.var 0)))))))
theorem wire_e597487038314 : Closed e597487038314 ∧ code e597487038314 = 9393580060522 := by decide
theorem cert_e597487038314 : check e597487038314 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487039342 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 1))) (.var 2)))))))
theorem wire_e597487039342 : Closed e597487039342 ∧ code e597487039342 = 9393580061550 := by decide
theorem cert_e597487039342 : check e597487039342 [[.under],[.under,.left],[.under]] .chain = true := by decide
def e597487039350 : Term := (.lam (.app (.lam (.app (.app (.var 0) (.lam (.var 2))) (.var 0))) (.lam (.lam (.lam (.app (.app (.var 0) (.app (.var 0) (.var 2))) (.var 1)))))))
theorem wire_e597487039350 : Closed e597487039350 ∧ code e597487039350 = 9393580061558 := by decide
theorem cert_e597487039350 : check e597487039350 [[.under],[.under,.left],[.under]] .chain = true := by decide
end Blc.Floor43
