import Floor43
namespace Blc.Floor43
open Term SelfintSharp SelfintLowerBound Round3Floor38
set_option maxRecDepth 20000
def e2422406442682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406442682 : Closed e2422406442682 ∧ code e2422406442682 = 11218499464890 := by decide
theorem cert_e2422406442682 : check e2422406442682 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406442710 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406442710 : Closed e2422406442710 ∧ code e2422406442710 = 11218499464918 := by decide
theorem cert_e2422406442710 : check e2422406442710 [[],[]] .chain = true := by decide
def e2422406442714 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406442714 : Closed e2422406442714 ∧ code e2422406442714 = 11218499464922 := by decide
theorem cert_e2422406442714 : check e2422406442714 [[],[]] .chain = true := by decide
def e2422406442730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 1) (.var 2))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406442730 : Closed e2422406442730 ∧ code e2422406442730 = 11218499464938 := by decide
theorem cert_e2422406442730 : check e2422406442730 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left]] .identityHead = true := by decide
def e2422406443350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406443350 : Closed e2422406443350 ∧ code e2422406443350 = 11218499465558 := by decide
theorem cert_e2422406443350 : check e2422406443350 [[],[]] .chain = true := by decide
def e2422406443354 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406443354 : Closed e2422406443354 ∧ code e2422406443354 = 11218499465562 := by decide
theorem cert_e2422406443354 : check e2422406443354 [[],[]] .chain = true := by decide
def e2422406443370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406443370 : Closed e2422406443370 ∧ code e2422406443370 = 11218499465578 := by decide
theorem cert_e2422406443370 : check e2422406443370 [[],[]] .chain = true := by decide
def e2422406444118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 0)) (.var 1))))))
theorem wire_e2422406444118 : Closed e2422406444118 ∧ code e2422406444118 = 11218499466326 := by decide
theorem cert_e2422406444118 : check e2422406444118 [[],[]] .chain = true := by decide
def e2422406444122 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1)) (.var 0))))))
theorem wire_e2422406444122 : Closed e2422406444122 ∧ code e2422406444122 = 11218499466330 := by decide
theorem cert_e2422406444122 : check e2422406444122 [[],[]] .chain = true := by decide
def e2422406444310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406444310 : Closed e2422406444310 ∧ code e2422406444310 = 11218499466518 := by decide
theorem cert_e2422406444310 : check e2422406444310 [[],[]] .chain = true := by decide
def e2422406444386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406444386 : Closed e2422406444386 ∧ code e2422406444386 = 11218499466594 := by decide
theorem cert_e2422406444386 : check e2422406444386 [[],[]] .chain = true := by decide
def e2422406444398 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 1)) (.var 2))))))
theorem wire_e2422406444398 : Closed e2422406444398 ∧ code e2422406444398 = 11218499466606 := by decide
theorem cert_e2422406444398 : check e2422406444398 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406444406 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 0)) (.var 2)) (.var 1))))))
theorem wire_e2422406444406 : Closed e2422406444406 ∧ code e2422406444406 = 11218499466614 := by decide
theorem cert_e2422406444406 : checkPay e2422406444406 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422406444426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406444426 : Closed e2422406444426 ∧ code e2422406444426 = 11218499466634 := by decide
theorem cert_e2422406444426 : check e2422406444426 [[],[]] .chain = true := by decide
def e2422406444450 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406444450 : Closed e2422406444450 ∧ code e2422406444450 = 11218499466658 := by decide
theorem cert_e2422406444450 : check e2422406444450 [[],[]] .chain = true := by decide
def e2422406444462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 0)) (.var 2))))))
theorem wire_e2422406444462 : Closed e2422406444462 ∧ code e2422406444462 = 11218499466670 := by decide
theorem cert_e2422406444462 : check e2422406444462 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406444470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 1)) (.var 1))))))
theorem wire_e2422406444470 : Closed e2422406444470 ∧ code e2422406444470 = 11218499466678 := by decide
theorem cert_e2422406444470 : check e2422406444470 [[],[]] .chain = true := by decide
def e2422406444474 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 1)) (.var 2)) (.var 0))))))
theorem wire_e2422406444474 : Closed e2422406444474 ∧ code e2422406444474 = 11218499466682 := by decide
theorem cert_e2422406444474 : check e2422406444474 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left]] .identityHead = true := by decide
def e2422406444502 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 0)) (.var 1))))))
theorem wire_e2422406444502 : Closed e2422406444502 ∧ code e2422406444502 = 11218499466710 := by decide
theorem cert_e2422406444502 : checkPay e2422406444502 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] 1 [] = true := by decide
def e2422406444506 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 0))) (.var 2)) (.var 1)) (.var 0))))))
theorem wire_e2422406444506 : Closed e2422406444506 ∧ code e2422406444506 = 11218499466714 := by decide
theorem cert_e2422406444506 : check e2422406444506 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406444586 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0)) (.var 0))))))
theorem wire_e2422406444586 : Closed e2422406444586 ∧ code e2422406444586 = 11218499466794 := by decide
theorem cert_e2422406444586 : check e2422406444586 [[],[]] .chain = true := by decide
def e2422406444682 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406444682 : Closed e2422406444682 ∧ code e2422406444682 = 11218499466890 := by decide
theorem cert_e2422406444682 : check e2422406444682 [[],[]] .chain = true := by decide
def e2422406444706 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406444706 : Closed e2422406444706 ∧ code e2422406444706 = 11218499466914 := by decide
theorem cert_e2422406444706 : check e2422406444706 [[],[]] .chain = true := by decide
def e2422406444718 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 0)) (.var 2))))))
theorem wire_e2422406444718 : Closed e2422406444718 ∧ code e2422406444718 = 11218499466926 := by decide
theorem cert_e2422406444718 : check e2422406444718 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406444726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 1)) (.var 1))))))
theorem wire_e2422406444726 : Closed e2422406444726 ∧ code e2422406444726 = 11218499466934 := by decide
theorem cert_e2422406444726 : check e2422406444726 [[],[]] .chain = true := by decide
def e2422406444730 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 0)) (.var 2)) (.var 0))))))
theorem wire_e2422406444730 : Closed e2422406444730 ∧ code e2422406444730 = 11218499466938 := by decide
theorem cert_e2422406444730 : check e2422406444730 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406444758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 0)) (.var 1))))))
theorem wire_e2422406444758 : Closed e2422406444758 ∧ code e2422406444758 = 11218499466966 := by decide
theorem cert_e2422406444758 : check e2422406444758 [[],[]] .chain = true := by decide
def e2422406444762 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 1)) (.var 1)) (.var 0))))))
theorem wire_e2422406444762 : Closed e2422406444762 ∧ code e2422406444762 = 11218499466970 := by decide
theorem cert_e2422406444762 : check e2422406444762 [[],[]] .chain = true := by decide
def e2422406444778 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 1))) (.var 2)) (.var 0)) (.var 0))))))
theorem wire_e2422406444778 : Closed e2422406444778 ∧ code e2422406444778 = 11218499466986 := by decide
theorem cert_e2422406444778 : check e2422406444778 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406444886 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 0)) (.var 1))))))
theorem wire_e2422406444886 : Closed e2422406444886 ∧ code e2422406444886 = 11218499467094 := by decide
theorem cert_e2422406444886 : check e2422406444886 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406444890 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 0)) (.var 1)) (.var 0))))))
theorem wire_e2422406444890 : Closed e2422406444890 ∧ code e2422406444890 = 11218499467098 := by decide
theorem cert_e2422406444890 : check e2422406444890 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406444906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.app (.var 2) (.var 2))) (.var 1)) (.var 0)) (.var 0))))))
theorem wire_e2422406444906 : Closed e2422406444906 ∧ code e2422406444906 = 11218499467114 := by decide
theorem cert_e2422406444906 : check e2422406444906 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406447470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 1)) (.var 2))))))
theorem wire_e2422406447470 : Closed e2422406447470 ∧ code e2422406447470 = 11218499469678 := by decide
theorem cert_e2422406447470 : check e2422406447470 [[],[]] .chain = true := by decide
def e2422406447478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.lam (.var 0))))) (.var 2)) (.var 1))))))
theorem wire_e2422406447478 : Closed e2422406447478 ∧ code e2422406447478 = 11218499469686 := by decide
theorem cert_e2422406447478 : check e2422406447478 [[],[]] .chain = true := by decide
def e2422406449006 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2)))) (.var 1)) (.var 2))))))
theorem wire_e2422406449006 : Closed e2422406449006 ∧ code e2422406449006 = 11218499471214 := by decide
theorem cert_e2422406449006 : check e2422406449006 [[],[]] .chain = true := by decide
def e2422406449014 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 2)))) (.var 2)) (.var 1))))))
theorem wire_e2422406449014 : Closed e2422406449014 ∧ code e2422406449014 = 11218499471222 := by decide
theorem cert_e2422406449014 : check e2422406449014 [[],[]] .chain = true := by decide
def e2422406449070 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 0)) (.var 2))))))
theorem wire_e2422406449070 : Closed e2422406449070 ∧ code e2422406449070 = 11218499471278 := by decide
theorem cert_e2422406449070 : check e2422406449070 [[],[]] .chain = true := by decide
def e2422406449082 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 3)))) (.var 2)) (.var 0))))))
theorem wire_e2422406449082 : Closed e2422406449082 ∧ code e2422406449082 = 11218499471290 := by decide
theorem cert_e2422406449082 : check e2422406449082 [[],[]] .chain = true := by decide
def e2422406449110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 0)) (.var 1))))))
theorem wire_e2422406449110 : Closed e2422406449110 ∧ code e2422406449110 = 11218499471318 := by decide
theorem cert_e2422406449110 : check e2422406449110 [[],[]] .chain = true := by decide
def e2422406449114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.lam (.var 4)))) (.var 1)) (.var 0))))))
theorem wire_e2422406449114 : Closed e2422406449114 ∧ code e2422406449114 = 11218499471322 := by decide
theorem cert_e2422406449114 : check e2422406449114 [[],[]] .chain = true := by decide
def e2422406450542 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406450542 : Closed e2422406450542 ∧ code e2422406450542 = 11218499472750 := by decide
theorem cert_e2422406450542 : check e2422406450542 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406450550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.var 0) (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406450550 : Closed e2422406450550 ∧ code e2422406450550 = 11218499472758 := by decide
theorem cert_e2422406450550 : check e2422406450550 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406452078 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 1))) (.var 2))))))
theorem wire_e2422406452078 : Closed e2422406452078 ∧ code e2422406452078 = 11218499474286 := by decide
theorem cert_e2422406452078 : check e2422406452078 [[],[]] .chain = true := by decide
def e2422406452086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 0) (.var 2))) (.var 1))))))
theorem wire_e2422406452086 : Closed e2422406452086 ∧ code e2422406452086 = 11218499474294 := by decide
theorem cert_e2422406452086 : check e2422406452086 [[],[]] .chain = true := by decide
def e2422406452142 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 0))) (.var 2))))))
theorem wire_e2422406452142 : Closed e2422406452142 ∧ code e2422406452142 = 11218499474350 := by decide
theorem cert_e2422406452142 : check e2422406452142 [[],[]] .chain = true := by decide
def e2422406452154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2))) (.var 0))))))
theorem wire_e2422406452154 : Closed e2422406452154 ∧ code e2422406452154 = 11218499474362 := by decide
theorem cert_e2422406452154 : check e2422406452154 [[],[]] .chain = true := by decide
def e2422406452182 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 0))) (.var 1))))))
theorem wire_e2422406452182 : Closed e2422406452182 ∧ code e2422406452182 = 11218499474390 := by decide
theorem cert_e2422406452182 : check e2422406452182 [[],[]] .chain = true := by decide
def e2422406452186 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1))) (.var 0))))))
theorem wire_e2422406452186 : Closed e2422406452186 ∧ code e2422406452186 = 11218499474394 := by decide
theorem cert_e2422406452186 : check e2422406452186 [[],[]] .chain = true := by decide
def e2422406452462 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406452462 : Closed e2422406452462 ∧ code e2422406452462 = 11218499474670 := by decide
theorem cert_e2422406452462 : check e2422406452462 [[],[]] .chain = true := by decide
def e2422406452470 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 0)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406452470 : Closed e2422406452470 ∧ code e2422406452470 = 11218499474678 := by decide
theorem cert_e2422406452470 : check e2422406452470 [[],[]] .chain = true := by decide
def e2422406452846 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406452846 : Closed e2422406452846 ∧ code e2422406452846 = 11218499475054 := by decide
theorem cert_e2422406452846 : check e2422406452846 [[],[]] .chain = true := by decide
def e2422406452858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 1)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406452858 : Closed e2422406452858 ∧ code e2422406452858 = 11218499475066 := by decide
theorem cert_e2422406452858 : check e2422406452858 [[],[]] .chain = true := by decide
def e2422406453046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406453046 : Closed e2422406453046 ∧ code e2422406453046 = 11218499475254 := by decide
theorem cert_e2422406453046 : check e2422406453046 [[],[]] .chain = true := by decide
def e2422406453050 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 0))) (.var 2)) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406453050 : Closed e2422406453050 ∧ code e2422406453050 = 11218499475258 := by decide
theorem cert_e2422406453050 : check e2422406453050 [[],[]] .chain = true := by decide
def e2422406453486 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.lam (.var 2))) (.var 2))))))
theorem wire_e2422406453486 : Closed e2422406453486 ∧ code e2422406453486 = 11218499475694 := by decide
theorem cert_e2422406453486 : check e2422406453486 [[],[]] .chain = true := by decide
def e2422406453494 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.lam (.var 3))) (.var 1))))))
theorem wire_e2422406453494 : Closed e2422406453494 ∧ code e2422406453494 = 11218499475702 := by decide
theorem cert_e2422406453494 : check e2422406453494 [[],[]] .chain = true := by decide
def e2422406454046 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 1)) (.lam (.var 3)))))))
theorem wire_e2422406454046 : Closed e2422406454046 ∧ code e2422406454046 = 11218499476254 := by decide
theorem cert_e2422406454046 : check e2422406454046 [[],[]] .chain = true := by decide
def e2422406454158 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 1))) (.var 2)) (.lam (.var 2)))))))
theorem wire_e2422406454158 : Closed e2422406454158 ∧ code e2422406454158 = 11218499476366 := by decide
theorem cert_e2422406454158 : check e2422406454158 [[],[]] .chain = true := by decide
def e2422406454382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 1))) (.var 2))))))
theorem wire_e2422406454382 : Closed e2422406454382 ∧ code e2422406454382 = 11218499476590 := by decide
theorem cert_e2422406454382 : check e2422406454382 [[],[]] .chain = true := by decide
def e2422406454394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.lam (.var 3))) (.var 0))))))
theorem wire_e2422406454394 : Closed e2422406454394 ∧ code e2422406454394 = 11218499476602 := by decide
theorem cert_e2422406454394 : check e2422406454394 [[],[]] .chain = true := by decide
def e2422406454558 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 0)) (.lam (.var 3)))))))
theorem wire_e2422406454558 : Closed e2422406454558 ∧ code e2422406454558 = 11218499476766 := by decide
theorem cert_e2422406454558 : check e2422406454558 [[],[]] .chain = true := by decide
def e2422406454726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 2))) (.var 2)) (.lam (.var 1)))))))
theorem wire_e2422406454726 : Closed e2422406454726 ∧ code e2422406454726 = 11218499476934 := by decide
theorem cert_e2422406454726 : check e2422406454726 [[],[]] .chain = true := by decide
def e2422406454838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 1))) (.var 1))))))
theorem wire_e2422406454838 : Closed e2422406454838 ∧ code e2422406454838 = 11218499477046 := by decide
theorem cert_e2422406454838 : check e2422406454838 [[],[]] .chain = true := by decide
def e2422406454842 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.lam (.var 2))) (.var 0))))))
theorem wire_e2422406454842 : Closed e2422406454842 ∧ code e2422406454842 = 11218499477050 := by decide
theorem cert_e2422406454842 : check e2422406454842 [[],[]] .chain = true := by decide
def e2422406454926 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 0)) (.lam (.var 2)))))))
theorem wire_e2422406454926 : Closed e2422406454926 ∧ code e2422406454926 = 11218499477134 := by decide
theorem cert_e2422406454926 : check e2422406454926 [[],[]] .chain = true := by decide
def e2422406454982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.var 3))) (.var 1)) (.lam (.var 1)))))))
theorem wire_e2422406454982 : Closed e2422406454982 ∧ code e2422406454982 = 11218499477190 := by decide
theorem cert_e2422406454982 : check e2422406454982 [[],[]] .chain = true := by decide
def e2422406459758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 1)) (.var 2))))))
theorem wire_e2422406459758 : Closed e2422406459758 ∧ code e2422406459758 = 11218499481966 := by decide
theorem cert_e2422406459758 : check e2422406459758 [[],[]] .chain = true := by decide
def e2422406459766 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.lam (.var 0)))) (.var 2)) (.var 1))))))
theorem wire_e2422406459766 : Closed e2422406459766 ∧ code e2422406459766 = 11218499481974 := by decide
theorem cert_e2422406459766 : check e2422406459766 [[],[]] .chain = true := by decide
def e2422406460974 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406460974 : Closed e2422406460974 ∧ code e2422406460974 = 11218499483182 := by decide
theorem cert_e2422406460974 : check e2422406460974 [[],[]] .chain = true := by decide
def e2422406461154 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406461154 : Closed e2422406461154 ∧ code e2422406461154 = 11218499483362 := by decide
theorem cert_e2422406461154 : check e2422406461154 [[],[]] .chain = true := by decide
def e2422406461166 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 1))) (.var 2)) (.var 2))))))
theorem wire_e2422406461166 : Closed e2422406461166 ∧ code e2422406461166 = 11218499483374 := by decide
theorem cert_e2422406461166 : check e2422406461166 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406461206 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406461206 : Closed e2422406461206 ∧ code e2422406461206 = 11218499483414 := by decide
theorem cert_e2422406461206 : check e2422406461206 [[],[]] .chain = true := by decide
def e2422406461282 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406461282 : Closed e2422406461282 ∧ code e2422406461282 = 11218499483490 := by decide
theorem cert_e2422406461282 : check e2422406461282 [[],[]] .chain = true := by decide
def e2422406461294 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 1)) (.var 2))))))
theorem wire_e2422406461294 : Closed e2422406461294 ∧ code e2422406461294 = 11218499483502 := by decide
theorem cert_e2422406461294 : check e2422406461294 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406461302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 0) (.var 2))) (.var 2)) (.var 1))))))
theorem wire_e2422406461302 : Closed e2422406461302 ∧ code e2422406461302 = 11218499483510 := by decide
theorem cert_e2422406461302 : check e2422406461302 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406461614 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 0)) (.var 2))))))
theorem wire_e2422406461614 : Closed e2422406461614 ∧ code e2422406461614 = 11218499483822 := by decide
theorem cert_e2422406461614 : check e2422406461614 [[],[]] .chain = true := by decide
def e2422406461626 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2)) (.var 0))))))
theorem wire_e2422406461626 : Closed e2422406461626 ∧ code e2422406461626 = 11218499483834 := by decide
theorem cert_e2422406461626 : check e2422406461626 [[],[]] .chain = true := by decide
def e2422406461998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.lam (.var 0))) (.var 2))))))
theorem wire_e2422406461998 : Closed e2422406461998 ∧ code e2422406461998 = 11218499484206 := by decide
theorem cert_e2422406461998 : check e2422406461998 [[],[]] .chain = true := by decide
def e2422406462178 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.lam (.var 0)))))))
theorem wire_e2422406462178 : Closed e2422406462178 ∧ code e2422406462178 = 11218499484386 := by decide
theorem cert_e2422406462178 : check e2422406462178 [[],[]] .chain = true := by decide
def e2422406462190 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 0))) (.var 2)) (.var 2))))))
theorem wire_e2422406462190 : Closed e2422406462190 ∧ code e2422406462190 = 11218499484398 := by decide
theorem cert_e2422406462190 : check e2422406462190 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406462318 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 1)) (.var 2))))))
theorem wire_e2422406462318 : Closed e2422406462318 ∧ code e2422406462318 = 11218499484526 := by decide
theorem cert_e2422406462318 : check e2422406462318 [[],[]] .chain = true := by decide
def e2422406462326 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 1))) (.var 2)) (.var 1))))))
theorem wire_e2422406462326 : Closed e2422406462326 ∧ code e2422406462326 = 11218499484534 := by decide
theorem cert_e2422406462326 : check e2422406462326 [[],[]] .chain = true := by decide
def e2422406462346 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406462346 : Closed e2422406462346 ∧ code e2422406462346 = 11218499484554 := by decide
theorem cert_e2422406462346 : check e2422406462346 [[],[]] .chain = true := by decide
def e2422406462370 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406462370 : Closed e2422406462370 ∧ code e2422406462370 = 11218499484578 := by decide
theorem cert_e2422406462370 : check e2422406462370 [[],[]] .chain = true := by decide
def e2422406462382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 0)) (.var 2))))))
theorem wire_e2422406462382 : Closed e2422406462382 ∧ code e2422406462382 = 11218499484590 := by decide
theorem cert_e2422406462382 : check e2422406462382 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406462390 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 1)) (.var 1))))))
theorem wire_e2422406462390 : Closed e2422406462390 ∧ code e2422406462390 = 11218499484598 := by decide
theorem cert_e2422406462390 : check e2422406462390 [[],[]] .chain = true := by decide
def e2422406462394 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 1) (.var 2))) (.var 2)) (.var 0))))))
theorem wire_e2422406462394 : Closed e2422406462394 ∧ code e2422406462394 = 11218499484602 := by decide
theorem cert_e2422406462394 : check e2422406462394 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406462550 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 0)) (.var 1))))))
theorem wire_e2422406462550 : Closed e2422406462550 ∧ code e2422406462550 = 11218499484758 := by decide
theorem cert_e2422406462550 : check e2422406462550 [[],[]] .chain = true := by decide
def e2422406462554 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1)) (.var 0))))))
theorem wire_e2422406462554 : Closed e2422406462554 ∧ code e2422406462554 = 11218499484762 := by decide
theorem cert_e2422406462554 : check e2422406462554 [[],[]] .chain = true := by decide
def e2422406462742 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.lam (.var 0))) (.var 1))))))
theorem wire_e2422406462742 : Closed e2422406462742 ∧ code e2422406462742 = 11218499484950 := by decide
theorem cert_e2422406462742 : check e2422406462742 [[],[]] .chain = true := by decide
def e2422406462818 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.lam (.var 0)))))))
theorem wire_e2422406462818 : Closed e2422406462818 ∧ code e2422406462818 = 11218499485026 := by decide
theorem cert_e2422406462818 : check e2422406462818 [[],[]] .chain = true := by decide
def e2422406462830 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 1)) (.var 2))))))
theorem wire_e2422406462830 : Closed e2422406462830 ∧ code e2422406462830 = 11218499485038 := by decide
theorem cert_e2422406462830 : check e2422406462830 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406462838 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 0))) (.var 2)) (.var 1))))))
theorem wire_e2422406462838 : Closed e2422406462838 ∧ code e2422406462838 = 11218499485046 := by decide
theorem cert_e2422406462838 : check e2422406462838 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406462858 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0))) (.var 0))))))
theorem wire_e2422406462858 : Closed e2422406462858 ∧ code e2422406462858 = 11218499485066 := by decide
theorem cert_e2422406462858 : check e2422406462858 [[],[]] .chain = true := by decide
def e2422406462882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.lam (.var 0)))))))
theorem wire_e2422406462882 : Closed e2422406462882 ∧ code e2422406462882 = 11218499485090 := by decide
theorem cert_e2422406462882 : check e2422406462882 [[],[]] .chain = true := by decide
def e2422406462894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 0)) (.var 2))))))
theorem wire_e2422406462894 : Closed e2422406462894 ∧ code e2422406462894 = 11218499485102 := by decide
theorem cert_e2422406462894 : check e2422406462894 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406462902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 1)) (.var 1))))))
theorem wire_e2422406462902 : Closed e2422406462902 ∧ code e2422406462902 = 11218499485110 := by decide
theorem cert_e2422406462902 : check e2422406462902 [[],[]] .chain = true := by decide
def e2422406462906 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 1))) (.var 2)) (.var 0))))))
theorem wire_e2422406462906 : Closed e2422406462906 ∧ code e2422406462906 = 11218499485114 := by decide
theorem cert_e2422406462906 : check e2422406462906 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406462934 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 0)) (.var 1))))))
theorem wire_e2422406462934 : Closed e2422406462934 ∧ code e2422406462934 = 11218499485142 := by decide
theorem cert_e2422406462934 : check e2422406462934 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406462938 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.app (.var 2) (.var 2))) (.var 1)) (.var 0))))))
theorem wire_e2422406462938 : Closed e2422406462938 ∧ code e2422406462938 = 11218499485146 := by decide
theorem cert_e2422406462938 : check e2422406462938 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406463982 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.var 3)))) (.var 2))))))
theorem wire_e2422406463982 : Closed e2422406463982 ∧ code e2422406463982 = 11218499486190 := by decide
theorem cert_e2422406463982 : check e2422406463982 [[],[]] .chain = true := by decide
def e2422406463990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.lam (.var 4)))) (.var 1))))))
theorem wire_e2422406463990 : Closed e2422406463990 ∧ code e2422406463990 = 11218499486198 := by decide
theorem cert_e2422406463990 : check e2422406463990 [[],[]] .chain = true := by decide
def e2422406464750 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0))) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406464750 : Closed e2422406464750 ∧ code e2422406464750 = 11218499486958 := by decide
theorem cert_e2422406464750 : check e2422406464750 [[],[]] .chain = true := by decide
def e2422406464758 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 0))) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406464758 : Closed e2422406464758 ∧ code e2422406464758 = 11218499486966 := by decide
theorem cert_e2422406464758 : check e2422406464758 [[],[]] .chain = true := by decide
def e2422406465310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 2))) (.lam (.var 3)))))))
theorem wire_e2422406465310 : Closed e2422406465310 ∧ code e2422406465310 = 11218499487518 := by decide
theorem cert_e2422406465310 : check e2422406465310 [[],[]] .chain = true := by decide
def e2422406465422 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.lam (.var 3))) (.lam (.var 2)))))))
theorem wire_e2422406465422 : Closed e2422406465422 ∧ code e2422406465422 = 11218499487630 := by decide
theorem cert_e2422406465422 : check e2422406465422 [[],[]] .chain = true := by decide
def e2422406467118 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406467118 : Closed e2422406467118 ∧ code e2422406467118 = 11218499489326 := by decide
theorem cert_e2422406467118 : check e2422406467118 [[],[]] .chain = true := by decide
def e2422406467298 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406467298 : Closed e2422406467298 ∧ code e2422406467298 = 11218499489506 := by decide
theorem cert_e2422406467298 : check e2422406467298 [[],[]] .chain = true := by decide
def e2422406467310 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 1) (.var 2))) (.var 2))))))
theorem wire_e2422406467310 : Closed e2422406467310 ∧ code e2422406467310 = 11218499489518 := by decide
theorem cert_e2422406467310 : check e2422406467310 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406467350 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406467350 : Closed e2422406467350 ∧ code e2422406467350 = 11218499489558 := by decide
theorem cert_e2422406467350 : check e2422406467350 [[],[]] .chain = true := by decide
def e2422406467426 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406467426 : Closed e2422406467426 ∧ code e2422406467426 = 11218499489634 := by decide
theorem cert_e2422406467426 : check e2422406467426 [[],[]] .chain = true := by decide
def e2422406467438 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 1))) (.var 2))))))
theorem wire_e2422406467438 : Closed e2422406467438 ∧ code e2422406467438 = 11218499489646 := by decide
theorem cert_e2422406467438 : check e2422406467438 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406467446 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.app (.var 2) (.var 2))) (.var 1))))))
theorem wire_e2422406467446 : Closed e2422406467446 ∧ code e2422406467446 = 11218499489654 := by decide
theorem cert_e2422406467446 : check e2422406467446 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406469694 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406469694 : Closed e2422406469694 ∧ code e2422406469694 = 11218499491902 := by decide
theorem cert_e2422406469694 : check e2422406469694 [[],[]] .chain = true := by decide
def e2422406470114 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406470114 : Closed e2422406470114 ∧ code e2422406470114 = 11218499492322 := by decide
theorem cert_e2422406470114 : check e2422406470114 [[],[]] .chain = true := by decide
def e2422406470126 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 1)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406470126 : Closed e2422406470126 ∧ code e2422406470126 = 11218499492334 := by decide
theorem cert_e2422406470126 : check e2422406470126 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left]] .identityHead = true := by decide
def e2422406470686 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.lam (.lam (.var 3))))))))
theorem wire_e2422406470686 : Closed e2422406470686 ∧ code e2422406470686 = 11218499492894 := by decide
theorem cert_e2422406470686 : check e2422406470686 [[],[]] .chain = true := by decide
def e2422406470882 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.lam (.var 0))))))))
theorem wire_e2422406470882 : Closed e2422406470882 ∧ code e2422406470882 = 11218499493090 := by decide
theorem cert_e2422406470882 : check e2422406470882 [[],[]] .chain = true := by decide
def e2422406470894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406470894 : Closed e2422406470894 ∧ code e2422406470894 = 11218499493102 := by decide
theorem cert_e2422406470894 : check e2422406470894 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406470902 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 0)) (.var 2)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406470902 : Closed e2422406470902 ∧ code e2422406470902 = 11218499493110 := by decide
def e2422406471726 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.lam (.var 0))))) (.var 2))))))
theorem wire_e2422406471726 : Closed e2422406471726 ∧ code e2422406471726 = 11218499493934 := by decide
theorem cert_e2422406471726 : check e2422406471726 [[],[]] .chain = true := by decide
def e2422406471918 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 2)))) (.var 2))))))
theorem wire_e2422406471918 : Closed e2422406471918 ∧ code e2422406471918 = 11218499494126 := by decide
theorem cert_e2422406471918 : check e2422406471918 [[],[]] .chain = true := by decide
def e2422406471930 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.lam (.var 4)))) (.var 0))))))
theorem wire_e2422406471930 : Closed e2422406471930 ∧ code e2422406471930 = 11218499494138 := by decide
theorem cert_e2422406471930 : check e2422406471930 [[],[]] .chain = true := by decide
def e2422406472110 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.app (.var 0) (.var 0)))) (.var 2))))))
theorem wire_e2422406472110 : Closed e2422406472110 ∧ code e2422406472110 = 11218499494318 := by decide
theorem cert_e2422406472110 : check e2422406472110 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406472302 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406472302 : Closed e2422406472302 ∧ code e2422406472302 = 11218499494510 := by decide
theorem cert_e2422406472302 : check e2422406472302 [[],[]] .chain = true := by decide
def e2422406472314 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 0))) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406472314 : Closed e2422406472314 ∧ code e2422406472314 = 11218499494522 := by decide
theorem cert_e2422406472314 : check e2422406472314 [[],[]] .chain = true := by decide
def e2422406472478 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 1))) (.lam (.var 3)))))))
theorem wire_e2422406472478 : Closed e2422406472478 ∧ code e2422406472478 = 11218499494686 := by decide
theorem cert_e2422406472478 : check e2422406472478 [[],[]] .chain = true := by decide
def e2422406472646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.lam (.var 3))) (.lam (.var 1)))))))
theorem wire_e2422406472646 : Closed e2422406472646 ∧ code e2422406472646 = 11218499494854 := by decide
theorem cert_e2422406472646 : check e2422406472646 [[],[]] .chain = true := by decide
def e2422406473262 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.lam (.var 0)))) (.var 2))))))
theorem wire_e2422406473262 : Closed e2422406473262 ∧ code e2422406473262 = 11218499495470 := by decide
theorem cert_e2422406473262 : check e2422406473262 [[],[]] .chain = true := by decide
def e2422406473442 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.lam (.var 0)))))))
theorem wire_e2422406473442 : Closed e2422406473442 ∧ code e2422406473442 = 11218499495650 := by decide
theorem cert_e2422406473442 : check e2422406473442 [[],[]] .chain = true := by decide
def e2422406473454 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 0) (.var 2))) (.var 2))))))
theorem wire_e2422406473454 : Closed e2422406473454 ∧ code e2422406473454 = 11218499495662 := by decide
theorem cert_e2422406473454 : check e2422406473454 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406473582 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 1))) (.var 2))))))
theorem wire_e2422406473582 : Closed e2422406473582 ∧ code e2422406473582 = 11218499495790 := by decide
theorem cert_e2422406473582 : check e2422406473582 [[],[]] .chain = true := by decide
def e2422406473590 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 1) (.var 2))) (.var 1))))))
theorem wire_e2422406473590 : Closed e2422406473590 ∧ code e2422406473590 = 11218499495798 := by decide
theorem cert_e2422406473590 : check e2422406473590 [[],[]] .chain = true := by decide
def e2422406473610 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.lam (.var 0)))) (.var 0))))))
theorem wire_e2422406473610 : Closed e2422406473610 ∧ code e2422406473610 = 11218499495818 := by decide
theorem cert_e2422406473610 : check e2422406473610 [[],[]] .chain = true := by decide
def e2422406473634 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.lam (.var 0)))))))
theorem wire_e2422406473634 : Closed e2422406473634 ∧ code e2422406473634 = 11218499495842 := by decide
theorem cert_e2422406473634 : check e2422406473634 [[],[]] .chain = true := by decide
def e2422406473646 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 0))) (.var 2))))))
theorem wire_e2422406473646 : Closed e2422406473646 ∧ code e2422406473646 = 11218499495854 := by decide
theorem cert_e2422406473646 : check e2422406473646 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406473654 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 1))) (.var 1))))))
theorem wire_e2422406473654 : Closed e2422406473654 ∧ code e2422406473654 = 11218499495862 := by decide
theorem cert_e2422406473654 : check e2422406473654 [[],[]] .chain = true := by decide
def e2422406473658 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.app (.var 2) (.var 2))) (.var 0))))))
theorem wire_e2422406473658 : Closed e2422406473658 ∧ code e2422406473658 = 11218499495866 := by decide
theorem cert_e2422406473658 : check e2422406473658 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left]] .identityHead = true := by decide
def e2422406473790 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.lam (.lam (.var 4))))))))
theorem wire_e2422406473790 : Closed e2422406473790 ∧ code e2422406473790 = 11218499495998 := by decide
theorem cert_e2422406473790 : check e2422406473790 [[],[]] .chain = true := by decide
def e2422406474210 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.lam (.var 0))))))))
theorem wire_e2422406474210 : Closed e2422406474210 ∧ code e2422406474210 = 11218499496418 := by decide
theorem cert_e2422406474210 : check e2422406474210 [[],[]] .chain = true := by decide
def e2422406474222 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 0)) (.app (.var 2) (.var 2)))))))
theorem wire_e2422406474222 : Closed e2422406474222 ∧ code e2422406474222 = 11218499496430 := by decide
theorem cert_e2422406474222 : check e2422406474222 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406474990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.app (.var 1) (.var 2)))))))
theorem wire_e2422406474990 : Closed e2422406474990 ∧ code e2422406474990 = 11218499497198 := by decide
theorem cert_e2422406474990 : check e2422406474990 [[],[]] .chain = true := by decide
def e2422406474998 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 1)) (.app (.var 2) (.var 1)))))))
theorem wire_e2422406474998 : Closed e2422406474998 ∧ code e2422406474998 = 11218499497206 := by decide
theorem cert_e2422406474998 : check e2422406474998 [[],[]] .chain = true := by decide
def e2422406475266 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.lam (.var 0)))))))))
theorem wire_e2422406475266 : Closed e2422406475266 ∧ code e2422406475266 = 11218499497474 := by decide
theorem cert_e2422406475266 : check e2422406475266 [[],[]] .chain = true := by decide
def e2422406475278 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.lam (.var 2))))))))
theorem wire_e2422406475278 : Closed e2422406475278 ∧ code e2422406475278 = 11218499497486 := by decide
theorem cert_e2422406475278 : check e2422406475278 [[],[]] .chain = true := by decide
def e2422406475290 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.lam (.app (.var 0) (.var 0))))))))
theorem wire_e2422406475290 : Closed e2422406475290 ∧ code e2422406475290 = 11218499497498 := by decide
private def t_e2422406475290 : Term := (.app (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.lam (.app (.app (.var 0) (.lam (.lam (.var 0)))) (.lam (.app (.app (.var 0) (.lam (.lam (.var 1)))) (.var 3)))))) (.lam (.lam (.var 1)))) (.lam (.app (.var 0) (.var 0))))) (.lam (.app (.var 0) (.var 0))))
theorem cert_e2422406475290 : ¬ IsSelfInterpreter e2422406475290 :=
  wIdentity (t := t_e2422406475290) (replay_sound (ps := [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left]]) (t := (inv e2422406475290)) (by decide)) (by decide)
def e2422406475362 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.lam (.var 0))))))))
theorem wire_e2422406475362 : Closed e2422406475362 ∧ code e2422406475362 = 11218499497570 := by decide
theorem cert_e2422406475362 : check e2422406475362 [[],[]] .chain = true := by decide
def e2422406475374 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 0) (.var 2)))))))
theorem wire_e2422406475374 : Closed e2422406475374 ∧ code e2422406475374 = 11218499497582 := by decide
def e2422406475382 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 1) (.var 1)))))))
theorem wire_e2422406475382 : Closed e2422406475382 ∧ code e2422406475382 = 11218499497590 := by decide
theorem cert_e2422406475382 : check e2422406475382 [[],[]] .chain = true := by decide
def e2422406475386 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 1)) (.var 2)) (.app (.var 2) (.var 0)))))))
theorem wire_e2422406475386 : Closed e2422406475386 ∧ code e2422406475386 = 11218499497594 := by decide
theorem cert_e2422406475386 : check e2422406475386 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left],[],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left]] .identityHead = true := by decide
def e2422406475798 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.lam (.var 0))))) (.var 1))))))
theorem wire_e2422406475798 : Closed e2422406475798 ∧ code e2422406475798 = 11218499498006 := by decide
theorem cert_e2422406475798 : check e2422406475798 [[],[]] .chain = true := by decide
def e2422406475894 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 2)))) (.var 1))))))
theorem wire_e2422406475894 : Closed e2422406475894 ∧ code e2422406475894 = 11218499498102 := by decide
theorem cert_e2422406475894 : check e2422406475894 [[],[]] .chain = true := by decide
def e2422406475898 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.lam (.var 3)))) (.var 0))))))
theorem wire_e2422406475898 : Closed e2422406475898 ∧ code e2422406475898 = 11218499498106 := by decide
theorem cert_e2422406475898 : check e2422406475898 [[],[]] .chain = true := by decide
def e2422406475990 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.app (.var 0) (.var 0)))) (.var 1))))))
theorem wire_e2422406475990 : Closed e2422406475990 ∧ code e2422406475990 = 11218499498198 := by decide
theorem cert_e2422406475990 : check e2422406475990 [[.left,.left],[.left,.left],[.left],[],[.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left,.left,.left],[.left,.left,.left,.left],[.left,.left,.left],[.left,.left],[.left],[.left,.left],[.left,.left],[.left],[]] .identityHead = true := by decide
def e2422406476086 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.app (.var 0) (.var 1)))))))
theorem wire_e2422406476086 : Closed e2422406476086 ∧ code e2422406476086 = 11218499498294 := by decide
theorem cert_e2422406476086 : check e2422406476086 [[],[]] .chain = true := by decide
def e2422406476090 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 0))) (.app (.var 1) (.var 0)))))))
theorem wire_e2422406476090 : Closed e2422406476090 ∧ code e2422406476090 = 11218499498298 := by decide
theorem cert_e2422406476090 : check e2422406476090 [[],[]] .chain = true := by decide
def e2422406476174 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 1))) (.lam (.var 2)))))))
theorem wire_e2422406476174 : Closed e2422406476174 ∧ code e2422406476174 = 11218499498382 := by decide
theorem cert_e2422406476174 : check e2422406476174 [[],[]] .chain = true := by decide
def e2422406476230 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.lam (.var 2))) (.lam (.var 1)))))))
theorem wire_e2422406476230 : Closed e2422406476230 ∧ code e2422406476230 = 11218499498438 := by decide
theorem cert_e2422406476230 : check e2422406476230 [[],[]] .chain = true := by decide
def e2422406476566 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.lam (.var 0)))) (.var 1))))))
theorem wire_e2422406476566 : Closed e2422406476566 ∧ code e2422406476566 = 11218499498774 := by decide
theorem cert_e2422406476566 : check e2422406476566 [[],[]] .chain = true := by decide
def e2422406476642 : Term := (.app (.lam (.app (.var 0) (.var 0))) (.lam (.lam (.lam (.app (.app (.app (.app (.var 0) (.var 0)) (.var 2)) (.app (.var 0) (.var 1))) (.lam (.var 0)))))))
theorem wire_e2422406476642 : Closed e2422406476642 ∧ code e2422406476642 = 11218499498850 := by decide
theorem cert_e2422406476642 : check e2422406476642 [[],[]] .chain = true := by decide
end Blc.Floor43
#print axioms Blc.Floor43.cert_e2422406475290
